<?php
if (isset($_FILES['uploaded_file'])) {
    // Example:
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], "./assets/" . $_FILES['uploaded_file']['name'])){
        echo "success";
    } else {
        echo "fail";
    }
    exit;
} else {
    echo "fail";
}