const PRECACHE = 'UOEBANano-Data-v1';
const RUNTIME = 'UOEBANano-runtime';
const PRECACHE_URLS = [
'/index.html',
'/scripts/app.js',
'/manifest.json',
'/styles/all.min.css',
'/scripts/FileSaver.min.js',
'/styles/jquery.sweet-modal.min.css',
'/scripts/jquery.sweet-modal.min.js',
'/scripts/jquery.timeago.min.js',
'/styles/jquery.toolbar.css',
'/scripts/jquery.toolbar.min.js',
'/scripts/jquery-3.3.1.min.js',
'/styles/materialfont.css',
'/styles/materialize.min.css',
'/scripts/materialize.min.js',
'/scripts/all.min.js',
'/styles/nouislider.css',
'/scripts/nouislider.min.js',
'/styles/preloader.css',
'/scripts/printThis.js',
'/scripts/support.js',
'/scripts/tableHTMLExport.js',
'/assets/txt.svg',
'/assets/xls.svg',
'/assets/xlsx.svg',
'/styles/billboard.min.css',
'/scripts/billboard.pkgd.min.js',
'/scripts/Blob.min.js',
'/scripts/canvas-toBlob.js',
'/scripts/colors.js',
'/assets/csv.svg',
'/scripts/dom-to-image.min.js'
];
self.addEventListener('install', event => {
event.waitUntil(
caches.open(PRECACHE)
.then(cache => cache.addAll(PRECACHE_URLS))
.then(self.skipWaiting())
);
});
self.addEventListener('activate', event => {
const currentCaches = [PRECACHE, RUNTIME];
event.waitUntil(
caches.keys().then(cacheNames => {
return cacheNames.filter(cacheName => !currentCaches.includes(cacheName));
}).then(cachesToDelete => {
return Promise.all(cachesToDelete.map(cacheToDelete => {
return caches.delete(cacheToDelete);
}));
}).then(() => self.clients.claim())
);
});
self.addEventListener('fetch', event => {
if (event.request.url.startsWith(self.location.origin) && event.request.url.indexOf('donotdelete.gif')==-1) {
event.respondWith(
caches.match(event.request).then(cachedResponse => {
if (cachedResponse) {
return cachedResponse;
}
return caches.open(RUNTIME).then(cache => {
return fetch(event.request).then(response => {
return cache.put(event.request, response.clone()).then(() => {
return response;
});
});
});
})
);
}
});
