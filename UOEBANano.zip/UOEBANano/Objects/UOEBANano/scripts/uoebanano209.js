<!-- This WebApp/WebSite was created using BANano v2.09, a B4X library written by Alain Bailleul (2018 - 2019). -->
// =========================== Umbrella (modified by Alain Bailleul) ===========================
var u = function (t, e) {
    return this instanceof u ? t instanceof u ? t : ("string" == typeof t && (t = this.select(t, e)), t && t.nodeName && (t = [t]), void(this.nodes = this.slice(t))) : new u(t, e)
};
u.prototype = {
    get length() {
        return this.nodes.length
    }
}, u.prototype.nodes = [], u.prototype.addClass = function () {
    return this.eacharg(arguments, function (t, e) {
        t.classList.add(e)
    })
}, u.prototype.adjacent = function (i, t, n) {
    return "number" == typeof t && (t = 0 === t ? [] : new Array(t).join().split(",").map(Number.call, Number)), this.each(function (r, o) {
        var e = document.createDocumentFragment();
        u(t || {}).map(function (t, e) {
            var n = "function" == typeof i ? i.call(this, t, e, r, o) : i;
            return "string" == typeof n ? this.generate(n) : u(n)
        }).each(function (t) {
            this.isInPage(t) ? e.appendChild(u(t).clone().first()) : e.appendChild(t)
        }), n.call(this, r, e)
    })
}, u.prototype.after = function (t, e) {
    return this.adjacent(t, e, function (t, e) {
        t.parentNode.insertBefore(e, t.nextSibling)
    })
}, u.prototype.append = function (t, e) {
    return this.adjacent(t, e, function (t, e) {
        t.appendChild(e)
    })
}, u.prototype.args = function (t, e, n) {
    return "function" == typeof t && (t = t(e, n)), "string" != typeof t && (t = this.slice(t).map(this.str(e, n))), t.toString().split(/[\s,]+/).filter(function (t) {
        return t.length
    })
}, u.prototype.array = function (o) {
    o = o;
    var i = this;
    return this.nodes.reduce(function (t, e, n) {
        var r;
        return o ? ((r = o.call(i, e, n)) || (r = !1), "string" == typeof r && (r = u(r)), r instanceof u && (r = r.nodes)) : r = e.innerHTML, t.concat(!1 !== r ? r : [])
    }, [])
}, u.prototype.attr = function (t, e, r) {
    return r = r ? "data-" : "", this.pairs(t, e, function (t, e) {
        return t.getAttribute(r + e)
    }, function (t, e, n) {
        t.setAttribute(r + e, n)
    })
}, u.prototype.before = function (t, e) {
    return this.adjacent(t, e, function (t, e) {
        t.parentNode.insertBefore(e, t)
    })
}, u.prototype.children = function (t) {
    return this.map(function (t) {
        return this.slice(t.children)
    }).filter(t)
}, u.prototype.clone = function () {
    return this.map(function (t, e) {
        var n = t.cloneNode(!0),
            r = this.getAll(n);
        return this.getAll(t).each(function (t, e) {
            for (var n in this.mirror) this.mirror[n] && this.mirror[n](t, r.nodes[e])
        }), n
    })
}, u.prototype.toU = function () {
    for (var t = [], e = 0; e < this.nodes.length; e++) t.push(u(this.nodes[e]));
    return t
}, u.prototype.css = function (t, e) {
    return this.pairs(t, e, function (t, e) {
        return getStyle(t, e)
    }, function (t, e, n) {
        setStyle(t, e, n)
    })
}, u.prototype.getAll = function (t) {
    return u([t].concat(u("*", t).nodes))
}, u.prototype.mirror = {}, u.prototype.mirror.events = function (t, e) {
    if (t._e)
        for (var n in t._e) t._e[n].forEach(function (t) {
            u(e).on(n, t)
        })
}, u.prototype.mirror.select = function (t, e) {
    u(t).is("select") && (e.value = t.value)
}, u.prototype.mirror.textarea = function (t, e) {
    u(t).is("textarea") && (e.value = t.value)
}, u.prototype.closest = function (e) {
    return this.map(function (t) {
        do {
            if (u(t).is(e)) return t
        } while ((t = t.parentNode) && t !== document)
    })
}, u.prototype.data = function (t, e) {
    return this.attr(t, e, !0)
}, u.prototype.each = function (t) {
    return this.nodes.forEach(t.bind(this)), this
}, u.prototype.eacharg = function (n, r) {
    return this.each(function (e, t) {
        this.args(n, e, t).forEach(function (t) {
            r.call(this, e, t)
        }, this)
    })
}, u.prototype.empty = function () {
    return this.each(function (e) {
        for (var t = e.children, r = 0; r < t.length; r++) {
            var i = t[r];
            var n = document.getElementById(i.id);
            if (n) {
                var o = n.cloneNode(!0);
                n.parentNode.replaceChild(o, n)
            }
        }
        for (; e.firstChild;) e.removeChild(e.firstChild)
    })
}, u.prototype.filter = function (e) {
    var t = function (t) {
        return t.matches = t.matches || t.msMatchesSelector || t.webkitMatchesSelector, t.matches(e || "*")
    };
    return "function" == typeof e && (t = e), e instanceof u && (t = function (t) {
        return -1 !== e.nodes.indexOf(t)
    }), u(this.nodes.filter(t))
}, u.prototype.find = function (e) {
    return this.map(function (t) {
        return u(e || "*", t)
    })
}, u.prototype.first = function () {
    return this.nodes[0] || !1
}, u.prototype.bananofirst = function () {
    return u(this.nodes[0]) || !1
}, u.prototype.generate = function (t) {
    return /^\s*<tr[> ]/.test(t) ? u(document.createElement("table")).html(t).children().children().nodes : /^\s*<t(h|d)[> ]/.test(t) ? u(document.createElement("table")).html(t).children().children().children().nodes : /^\s*</.test(t) ? u(document.createElement("div")).html(t).children().nodes : document.createTextNode(t)
}, u.prototype.handle = function () {
    var t = this.slice(arguments).map(function (e) {
        return "function" == typeof e ? function (t) {
            t.preventDefault(), e.apply(this, arguments)
        } : e
    }, this);
    return this.on.apply(this, t)
}, u.prototype.hasClass = function () {
    return this.is("." + this.args(arguments).join("."))
}, u.prototype.html = function (e) {
    return void 0 === e ? this.first().innerHTML || "" : this.each(function (t) {
        t.innerHTML = e
    })
}, u.prototype.is = function (t) {
    return 0 < this.filter(t).length
}, u.prototype.isInPage = function (t) {
    return t !== document.body && document.body.contains(t)
}, u.prototype.bananolastlast = function () {
    return u(this.nodes[this.length - 1]) || !1
}, u.prototype.last = function () {
    return this.nodes[this.length - 1] || !1
}, u.prototype.map = function (t) {
    return t ? u(this.array(t)).unique() : this
}, u.prototype.not = function (e) {
    return this.filter(function (t) {
        return !u(t).is(e || !0)
    })
}, u.prototype.off = function (t) {
    return this.eacharg(t, function (e, n) {
        u(e._e ? e._e[n] : []).each(function (t) {
            e.removeEventListener(n, t)
        })
    })
}, u.prototype.on = function (t, e, r) {
    if ("string" == typeof e) {
        var o = e;
        e = function (e) {
            var n = arguments;
            u(e.currentTarget).find(o).each(function (t) {
                if (t === e.target || t.contains(e.target)) {
                    try {
                        Object.defineProperty(e, "currentTarget", {
                            get: function () {
                                return t
                            }
                        })
                    } catch (t) {}
                    r.apply(t, n)
                }
            })
        }
    }
    var n = function (t) {
        return e.apply(this, [t].concat(t.detail || []))
    };
    return this.eacharg(t, function (t, e) {
        t.addEventListener(e, n), t._e = t._e || {}, t._e[e] = t._e[e] || [], t._e[e].push(n)
    })
}, u.prototype.pairs = function (n, t, e, r) {
    if (void 0 !== t) {
        var o = n;
        (n = {})[o] = t
    }
    return "object" == typeof n ? this.each(function (t) {
        for (var e in n) r(t, e, n[e])
    }) : this.length ? e(this.first(), n) : ""
}, u.prototype.param = function (e) {
    return Object.keys(e).map(function (t) {
        return this.uri(t) + "=" + this.uri(e[t])
    }.bind(this)).join("&")
}, u.prototype.parent = function (t) {
    return this.map(function (t) {
        return t.parentNode
    }).filter(t)
}, u.prototype.prepend = function (t, e) {
    return this.adjacent(t, e, function (t, e) {
        t.insertBefore(e, t.firstChild)
    })
}, u.prototype.remove = function () {
    return this.each(function (t) {
        u(t).empty();
        t.parentNode && t.parentNode.removeChild(t)
    })
}, u.prototype.removeClass = function () {
    return this.eacharg(arguments, function (t, e) {
        t.classList.remove(e)
    })
}, u.prototype.replace = function (t, e) {
    var n = [];
    return this.adjacent(t, e, function (t, e) {
        n = n.concat(this.slice(e.children)), t.parentNode.replaceChild(e, t)
    }), u(n)
}, u.prototype.scroll = function () {
    return this.first().scrollIntoView({
        behavior: "smooth"
    }), this
}, u.prototype.select = function (t, e) {
    return t = t.replace(/^\s*/, "").replace(/\s*$/, ""), /^</.test(t) ? u().generate(t) : (e || document).querySelectorAll(t)
}, u.prototype.serialize = function () {
    var r = this;
    return this.slice(this.first().elements).reduce(function (e, n) {
        return !n.name || n.disabled || "file" === n.type ? e : /(checkbox|radio)/.test(n.type) && !n.checked ? e : "select-multiple" === n.type ? (u(n.options).each(function (t) {
            t.selected && (e += "&" + r.uri(n.name) + "=" + r.uri(t.value))
        }), e) : e + "&" + r.uri(n.name) + "=" + r.uri(n.value)
    }, "").slice(1)
}, u.prototype.siblings = function (t) {
    return this.parent().children(t).not(this)
}, u.prototype.size = function () {
    return this.first().getBoundingClientRect()
}, u.prototype.hasAttr = function (t) {
    return null != this.attr(t)
}, u.prototype.slice = function (t) {
    return t && 0 !== t.length && "string" != typeof t && "[object Function]" !== t.toString() ? t.length ? [].slice.call(t.nodes || t) : [t] : []
}, u.prototype.str = function (e, n) {
    return function (t) {
        return "function" == typeof t ? t.call(this, e, n) : t.toString()
    }
}, u.prototype.text = function (e) {
    return void 0 === e ? this.first().textContent || "" : this.each(function (t) {
        t.textContent = e
    })
}, u.prototype.toggleClass = function (t, e) {
    return !!e === e ? this[e ? "addClass" : "removeClass"](t) : this.eacharg(t, function (t, e) {
        t.classList.toggle(e)
    })
}, u.prototype.trigger = function (t) {
    var o = this.slice(arguments).slice(1);
    return this.eacharg(t, function (t, e) {
        var n, r = {
            bubbles: !0,
            cancelable: !0,
            detail: o
        };
        try {
            n = new window.CustomEvent(e, r)
        } catch (t) {
            (n = document.createEvent("CustomEvent")).initCustomEvent(e, !0, !0, o)
        }
        t.dispatchEvent(n)
    })
}, u.prototype.checked = function (bool) {
    if (bool === undefined) {
        return this.checked().value || false;
    }
    return this.each(function (node) {
        node.checked = bool;
    });
}, u.prototype.value = function (text) {
    if (text === undefined) {
        return this.first().value || '';
    }
    return this.each(function (node) {
        node.value = text;
    });
}, u.prototype.unique = function () {
    return u(this.nodes.reduce(function (t, e) {
        return null != e && !1 !== e && -1 === t.indexOf(e) ? t.concat(e) : t
    }, []))
}, u.prototype.uri = function (t) {
    return encodeURIComponent(t).replace(/!/g, "%21").replace(/'/g, "%27").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\*/g, "%2A").replace(/%20/g, "+")
}, u.prototype.wrap = function (t) {
    return this.map(function (e) {
        return u(t).each(function (t) {
            (function (t) {
                for (; t.firstElementChild;) t = t.firstElementChild;
                return u(t)
            })(t).append(e.cloneNode(!0)), e.parentNode.replaceChild(t, e)
        })
    })
}, "object" == typeof module && module.exports && (module.exports = u, module.exports.u = u);
// =========================== Vault ===========================
! function (e, t) {
    "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t : e.vault = t()
}(this, function () {
    "use strict";
    var e = window.localStorage;
    return {
        set: function (t, n) {
            t && void 0 !== n && (e[t] = JSON.stringify(n))
        },
        get: function (t) {
            var n = e[t];
            return void 0 !== n ? JSON.parse(n) : void 0
        },
        remove: function (t) {
            e.hasOwnProperty(t) && delete e[t]
        },
        empty: function () {
            e.clear()
        }
    }
});
// =========================== BANano jCore ===========================
var bananoglobal = this;
var DateTime;
var _BANUnique = 0;
const sleep = (milliseconds) => {
    return new Promise(resolve => setTimeout(resolve, milliseconds))
};

function BANAnoMethodVarsToMap(m, b, n) {
    if (b) {
        m['subname'] = n;
    }
    return m;
};

function BANanoExec(functionName, context, args) {
    var args = Array.prototype.slice.call(arguments, 2);
    var namespaces = functionName.split('.');
    var func = namespaces.pop();
    for (var i = 0; i < namespaces.length; i++) {
        context = context[namespaces[i]];
    }
    return context[func].apply(context, args);
};

function BANanoSuffixFromID(id) {
    var i = id.lastIndexOf('_');
    if (i > 0) {
        return id.substring(i + 1);
    }
    return -1;
};

function banano_isconnected(tag, returnMethod, obj) {
    var img = document.createElement('img');
    img.onerror = function () {
        obj[returnMethod](tag, false);
    };
    img.onload = function () {
        obj[returnMethod](tag, true);
    };
    img.src = './assets/donotdelete.gif?rand=' + ((new Date()).getTime());
}
async function banano_isconnectedWait() {
    return new Promise(function (resolve, reject) {
        var img = document.createElement('img');
        img.onerror = function () {
            resolve(false);
        };
        img.onload = function () {
            resolve(true);
        };
        img.src = './assets/donotdelete.gif?rand=' + ((new Date()).getTime());
    })
};

function setStyle(el, property, value) {
    el.style[property] = value;
}

function getStyle(el, property) {
    var style = window.getComputedStyle ? getComputedStyle(el, null) : el.currentStyle;
    return style[property];
}(function () {
    var DateFormat = "MM/dd/yyyy";
    var TimeFormat = "HH:mm:ss";
    var _TZOffset = new Date().getTimezoneOffset() * -1 / 60;
    var self = this;
    var DateTime = {
        DateParse: function (s) {
            var ddres = Date.parse(s);
            return DateTime.WithTZ(ddres).getTime();
        },
        TimeParse: function (s) {
            var dd = new Date();
            s = dd.format('yyyy-MM-dd') + ' ' + s;
            var ddres = Date.parse(s);
            return DateTime.WithTZ(ddres).getTime();
        },
        Date: function (n) {
            var ddres = DateTime.WithTZ(n);
            return ddres.format(DateFormat);
        },
        Time: function (n) {
            var ddres = DateTime.WithTZ(n);
            return ddres.format(TimeFormat);
        },
        GetDateFormat: function () {
            return DateFormat;
        },
        SetDateFormat: function (s) {
            DateFormat = s;
        },
        GetTimeFormat: function () {
            return TimeFormat;
        },
        SetTimeFormat: function (s) {
            TimeFormat = s;
        },
        Add: function (dd, y, m, d) {
            var ddres = DateTime.WithTZ(dd);
            var res = DateTime.InnerAdd(ddres, y, 'y');
            res = DateTime.InnerAdd(res, m, 'm');
            res = DateTime.InnerAdd(res, d, 'd');
            return res.getTime();
        },
        InnerAdd: function (d, c, t) {
            c = (c === undefined) ? 0 : c;
            var result = null;
            switch (t) {
                case 'mill':
                    result = new Date(d.setMilliseconds(d.getMilliseconds() + c));
                    break;
                case 's':
                    result = new Date(d.setSeconds(d.getSeconds() + c));
                    break;
                case 'min':
                    result = new Date(d.setMinutes(d.getMinutes() + c));
                    break;
                case 'h':
                    result = new Date(d.setHours(d.getHours() + c));
                    break;
                case 'd':
                    result = new Date(d.setDate(d.getDate() + c));
                    break;
                case 'm':
                    result = new Date(d.setMonth(d.getMonth() + c));
                    break;
                case 'y':
                    result = new Date(d.setFullYear(d.getFullYear() + c));
                    break;
                default:
                    console.error("[timeSolver.js] Input Type Error");
                    break;
            }
            return result;
        },
        WithTZ: function (n) {
            if (_TZOffset != new Date().getTimezoneOffset() * -1 / 60) {
                var d = DateTime.InnerAdd(new Date(n), new Date(n).getTimezoneOffset() / 60, 'h');
                d = DateTime.InnerAdd(d, _TZOffset, 'h');
                return d;
            } else {
                return new Date(n);
            }
        },
        Now: function () {
            return new Date().getTime();
        },
        GetYear: function (n) {
            return DateTime.WithTZ(new Date(n)).getFullYear();
        },
        GetMonth: function (n) {
            return DateTime.WithTZ(new Date(n)).getMonth() + 1;
        },
        GetDayOfMonth: function (n) {
            return DateTime.WithTZ(new Date(n)).getDate();
        },
        GetDayOfYear: function (n) {
            var t = new Date(n);
            var dayCount = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
            var mn = t.getMonth();
            var dn = t.getDate();
            var dayOfYear = dayCount[mn] + dn;
            var year = t.getFullYear();
            var isLeap = false;
            if ((year & 3) != 0) {
                isLeap = false;
            } else {
                isLeap = ((year % 100) != 0 || (year % 400) == 0);
            }
            if (mn > 1 && isLeap) dayOfYear++;
            return dayOfYear;
        },
        GetDayOfWeek: function (n) {
            return DateTime.WithTZ(new Date(n)).getDay() + 1;
        },
        GetHour: function (n) {
            return DateTime.WithTZ(new Date(n)).getHours();
        },
        GetMinute: function (n) {
            return DateTime.WithTZ(new Date(n)).getMinutes();
        },
        GetSecond: function (n) {
            return DateTime.WithTZ(new Date(n)).getSeconds();
        },
        GetTimeZoneOffsetAt: function (n) {
            if (_TZOffset != new Date().getTimezoneOffset() * -1 / 60) {
                return _TZOffset;
            } else {
                return new Date(n).getTimezoneOffset() * -1 / 60;
            }
        },
        GetWeekInYear: function (n) {
            var onejan = new Date(n.getFullYear(), 0, 1);
            return Math.ceil((((n - onejan) / 86400000) + onejan.getDay() + 1) / 7);
        },
        GetWeekInMonth: function (n, exact) {
            var month = n.getMonth(),
                year = n.getFullYear(),
                firstWeekday = new Date(year, month, 1).getDay(),
                lastDateOfMonth = new Date(year, month + 1, 0).getDate(),
                offsetDate = n.getDate() + firstWeekday - 1,
                index = 1,
                weeksInMonth = index + Math.ceil((lastDateOfMonth + firstWeekday - 7) / 7),
                week = index + Math.floor(offsetDate / 7);
            if (exact || week < 2 + index) return week;
            return week === weeksInMonth ? index + 5 : week;
        },
        TicksPerDay: function () {
            return 86400000;
        },
        TicksPerHour: function () {
            return 3600000;
        },
        TicksPerMinute: function () {
            return 60000;
        },
        TicksPerSecond: function () {
            return 1000;
        },
        TimeZoneOffset: function () {
            return _TZOffset;
        },
        SetTimeZone: function (n) {
            _TZOffset = n;
        }
    };
    if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
        module.exports = DateTime;
    } else {
        if (typeof window !== 'undefined') {
            window.DateTime = DateTime;
        } else {
            bananoglobal.DateTime = DateTime;
        }
    }
})();
var dateFormat = function () {
    var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
        timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
        timezoneClip = /[^-+\dA-Z]/g,
        pad = function (val, len) {
            val = String(val);
            len = len || 2;
            while (val.length < len) val = "0" + val;
            return val;
        };
    return function (date, mask, utc) {
        var dF = dateFormat;
        if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {
            mask = date;
            date = undefined;
        }
        date = date ? new Date(date) : new Date;
        if (isNaN(date)) throw SyntaxError("invalid date");
        if (mask.slice(0, 4) == "UTC:") {
            mask = mask.slice(4);
            utc = true;
        }
        var _ = utc ? "getUTC" : "get",
            d = date[_ + "Date"](),
            D = date[_ + "Day"](),
            m = date[_ + "Month"](),
            y = date[_ + "FullYear"](),
            H = date[_ + "Hours"](),
            M = date[_ + "Minutes"](),
            s = date[_ + "Seconds"](),
            L = date[_ + "Milliseconds"](),
            o = utc ? 0 : date.getTimezoneOffset(),
            DD = DateTime.GetDayOfYear(date),
            w = DateTime.GetWeekInYear(date),
            W = DateTime.GetWeekInMonth(date, true),
            flags = {
                d: d,
                dd: pad(d),
                E: dF.i18n.dayNames[D],
                EE: dF.i18n.dayNames[D + 7],
                M: m + 1,
                MM: pad(m + 1),
                MMM: dF.i18n.monthNames[m],
                MMMM: dF.i18n.monthNames[m + 12],
                yy: String(y).slice(2),
                yyyy: y,
                h: H % 12 || 12,
                K: pad(H % 12 || 12),
                H: H,
                HH: pad(H),
                m: M,
                mm: pad(M),
                s: s,
                ss: pad(s),
                S: pad(L > 99 ? Math.round(L / 10) : L),
                a: H < 12 ? "AM" : "PM",
                Z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                X: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),
                o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
                u: D,
                D: DD,
                w: w,
                W: W
            };
        return mask.replace(token, function ($0) {
            return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);
        });
    };
}();
dateFormat.i18n = {
    dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
};
Date.prototype.format = function (mask, utc) {
    return dateFormat(this, mask, utc);
};
String.prototype.equalsIgnoreCase = function (otherString) {
    return (this.toUpperCase().localeCompare(otherString.toUpperCase()) === 0);
};
String.prototype.contains = function (otherString) {
    return (this.indexOf(otherString) > -1);
};
String.prototype.getBytes = function () {
    var utf8 = [];
    var str = this;
    for (var i = 0; i < str.length; i++) {
        var charcode = str.charCodeAt(i);
        if (charcode < 0x80) utf8.push(charcode);
        else if (charcode < 0x800) {
            utf8.push(0xffffffc0 | (charcode >> 6), 0xffffff80 | (charcode & 0x3f));
        } else if (charcode < 0xd800 || charcode >= 0xe000) {
            utf8.push(0xffffffe0 | (charcode >> 12), 0xffffff80 | ((charcode >> 6) & 0x3f), 0xffffff80 | (charcode & 0x3f));
        } else {
            utf8.push(0xef, 0xbf, 0xbd);
        }
    }
    return utf8;
};

function banano_bytesToString(array) {
    var str = '',
        i;
    var data = new Uint8Array(array);
    for (i = 0; i < data.length; i++) {
        var value = data[i];
        if (value < 0x80) {
            str += String.fromCharCode(value);
        } else if (value > 0xBF && value < 0xE0) {
            str += String.fromCharCode((value & 0x1F) << 6 | data[i + 1] & 0x3F);
            i += 1;
        } else if (value > 0xDF && value < 0xF0) {
            str += String.fromCharCode((value & 0x0F) << 12 | (data[i + 1] & 0x3F) << 6 | data[i + 2] & 0x3F);
            i += 2;
        }
    }
    return str;
};

function banano_getB4JKeyAt(outof, index) {
    var getkeyatkeycounter = 0;
    for (var getkeyatkey in outof) {
        if (outof.hasOwnProperty(getkeyatkey)) {
            if (getkeyatkeycounter == index) {
                return getkeyatkey;
            }
            getkeyatkeycounter++;
        }
    }
    return '';
};

function banano_getB4JValueAt(outof, index) {
    var getkeyatkeycounter = 0;
    for (var getkeyatkey in outof) {
        if (outof.hasOwnProperty(getkeyatkey)) {
            if (getkeyatkeycounter == index) {
                return outof[getkeyatkey];
            }
            getkeyatkeycounter++;
        }
    }
    return '';
};

function StringBuilder() {
    this.strings = new Array("");
};
StringBuilder.prototype.append = function (value) {
    var self = this;
    if (value) {
        this.strings.push(value);
    }
    return self;
};
StringBuilder.prototype.insert = function (offset, value) {
    var self = this;
    var str = this.strings.join("");
    this.strings = new Array("");
    this.strings.push([str.slice(0, offset), value, str.slice(offset)].join(''));
    return self;
};
StringBuilder.prototype.remove = function (startoffset, endoffset) {
    var self = this;
    var str = this.strings.join("");
    this.strings = new Array("");
    this.strings.push([str.slice(0, startoffset), str.slice(endoffset)].join(''));
    return self;
};
StringBuilder.prototype.length = function () {
    return this.strings.join("").length;
};
StringBuilder.prototype.toString = function () {
    return this.strings.join("");
};

function Param(obj) {
    if (typeof (obj) === 'string' || Object.prototype.toString.call(obj) === '[object FormData]') return obj;
    if (/application\/json/i.test(settings.headers['Content-type']) || Object.prototype.toString.call(obj) === '[object Array]') return JSON.stringify(obj);
    var encoded = [];
    for (var prop in obj) {
        if (obj.hasOwnProperty(prop)) {
            encoded.push(encodeURIComponent(prop) + '=' + encodeURIComponent(obj[prop]));
        }
    }
    return encoded.join('&');
};

function banano_sf(_text, _onlynbsp) {
    try {
        var _s = new StringBuilder();
        var _v = '' + _text;
        if (_onlynbsp) {
            _v = _v.split("{NBSP}").join(" ");
        } else {
            _v = _v.split("(\r\n|\n\r|\r|\n)").join("<br>");
            _v = _v.split("{B}").join("<b>");
            _v = _v.split("{/B}").join("</b>");
            _v = _v.split("{I}").join("<i>");
            _v = _v.split("{/I}").join("</i>");
            _v = _v.split("{U}").join("<ins>");
            _v = _v.split("{/U}").join("</ins>");
            _v = _v.split("{SUB}").join("<sub>");
            _v = _v.split("{/SUB}").join("</sub>");
            _v = _v.split("{SUP}").join("<sup>");
            _v = _v.split("{/SUP}").join("</sup>");
            _v = _v.split("{BR}").join("<br>");
            _v = _v.split("{WBR}").join("<wbr>");
            _v = _v.split("{NBSP}").join("&nbsp;");
            _v = _v.split("{AL}").join("<a rel=\"nofollow\" target=\"_blank\" href=\"");
            _v = _v.split("{AT}").join("\">");
            _v = _v.split("{/AL}").join("</a>");
            _v = _v.split("{AS}").join(" title=\"");
            _v = _v.split("{/AS}").join("\"");
            while (_v.indexOf("{C:") > -1) {
                _v = self.replacefirst(_v, "{C:", "<span style=\"color:");
                _v = self.replacefirst(_v, "}", "\">");
                _v = self.replacefirst(_v, "{/C}", "</span>");
            }
            _v = _v.split("{CODE}").join("<pre><code>");
            _v = _v.split("{/CODE}").join("</code></pre>");
            while (_v.indexOf("{ST:") > -1) {
                _v = self.replacefirst(_v, "{ST:", "<span style=\"");
                _v = self.replacefirst(_v, "}", "\">");
                _v = self.replacefirst(_v, "{/ST}", "</span>");
            }
            var _start = _v.indexOf("{IC:");
            while (_start > -1) {
                var _stop = _v.indexOf("{/IC}");
                var _vv = "";
                if (_stop > 0) {
                    _vv = _v.substring(_start, _stop + 5);
                } else {
                    break;
                }
                var _iconcolor = _vv.substring(4, 11);
                var _iconname = _vv.substring(12, _vv.length - 5);
                var _repl = "";
                switch (_iconname.substring(0, 3).toLowerCase()) {
                    case "mdi":
                        _repl = "<i style=\"color: " + _iconcolor + "\" class=\"" + _iconname + "\"></i>";
                        break;
                    case "fa ":
                        _repl = "<i style=\"color: " + _iconcolor + "\" class=\"" + _iconname + "\"></i>";
                        break;
                    case "fa-":
                        _repl = "<i style=\"color: " + _iconcolor + "\" class=\"" + _iconname + "\"></i>";
                        break;
                    default:
                        _repl = "<i style=\"color: " + _iconcolor + "\" class=\"material-icons\">" + _iconname + "</i>";
                        break;
                }
                _v = _v.split(_vv).join(_repl);
                _start = _v.indexOf("{IC:");
            }
        }
        _s.append(_v);
        return _s.toString();
    } catch (err) {
        console.log(err.message + ' ' + err.stack);
    }
};

function replacefirst(_s, _searchfor, _replacewith) {
    try {
        var _i = _s.indexOf(_searchfor);
        if (_i > -1) {
            return _s.substring(0, _i) + _replacewith + _s.substring(_i + _searchfor.length);
        } else {
            return _s;
        }
    } catch (err) {
        console.log(err.message + ' ' + err.stack);
    }
};
var _banano_uoebanano = new banano_uoebanano();
var _banano_uoebanano_moduoe = new banano_uoebanano_moduoe();
// =========================== UOEPage  ===========================
function banano_uoebanano_uoepage() {
    var self;
    this._theme = '';

    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._pagemain = new banano_uoebanano_uoehtml();

    this._content = new banano_uoebanano_uoecontainer();

    this._pageheader = new banano_uoebanano_uoehtml();

    this._pagefooter = new banano_uoebanano_uoehtml();

    this._footer = new banano_uoebanano_uoecontainer();

    this._hasfooter = false;

    this._fixedfooter = false;

    this._hascopyright = false;

    this._backgroundimage = '';

    this._navbar = new banano_uoebanano_uoenavbar();

    this._drawer = new banano_uoebanano_uoesidebar();

    this._autosizelogo = false;

    // [30] Sub CallMethod(sAppName As String, sClassName As String, sMethod As String) As String 
    this.callmethod = function (_sappname, _sclassname, _smethod) {
        if (self == null) self = this;
        var _script;
        // [31]  sAppName = sAppName.ToLowerCase 
        _sappname = _sappname.toLowerCase();
        // [32]  sClassName = sClassName.ToLowerCase 
        _sclassname = _sclassname.toLowerCase();
        // [33]  sMethod = sMethod.ToLowerCase 
        _smethod = _smethod.toLowerCase();
        // [34]  Dim script As String = {1} 
        _script = "_banano_" + _sappname + "_" + _sclassname + "." + _smethod + "";
        // [35]  script = script.Replace( {30} , {31} ) 
        _script = _script.split("__").join("_");
        // [36]  Return script 
        return _script;
        // End Sub
    };

    // [40] Sub PrintThis(elID As String) As String 
    this.printthis = function (_elid) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [41]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [42]  Dim j As String = {32} 
        _j = "$";
        // [43]  Dim script As String = {2} 
        _script = "" + _j + "('#" + _elid + "').printThis();";
        // [44]  Return script 
        return _script;
        // End Sub
    };

    // [47] Sub GetLocalStorage(sKey As String) As String 
    this.getlocalstorage = function (_skey) {
        if (self == null) self = this;
        var _svalue;
        // [48]  sKey = sKey.ToLowerCase 
        _skey = _skey.toLowerCase();
        // [49]  Dim svalue As String = Banano.GetLocalStorage(sKey) 
        _svalue = vault.get(_skey);
        // [50]  svalue = App.CStr(svalue) 
        _svalue = self._app.cstr(_svalue);
        // [51]  svalue = svalue.Replace( {33} , {34} ) 
        _svalue = _svalue.split("undefined").join("");
        // [52]  svalue = svalue.Replace( {35} , {36} ) 
        _svalue = _svalue.split("null").join("");
        // [53]  svalue = svalue.trim 
        _svalue = _svalue.trim();
        // [54]  Return svalue 
        return _svalue;
        // End Sub
    };

    // [57] Sub SetLocalStorage(sKey As String, sValue As String) 
    this.setlocalstorage = function (_skey, _svalue) {
        if (self == null) self = this;
        // [58]  sKey = sKey.ToLowerCase 
        _skey = _skey.toLowerCase();
        // [59]  Banano.SetLocalStorage(sKey,sValue) 
        vault.set(_skey, _svalue);
        // End Sub
    };

    // [63] Sub ToastError(sError As String) 
    this.toasterror = function (_serror) {
        if (self == null) self = this;
        // [64]  Execute(ShowError(sError)) 
        self.execute(self.showerror(_serror));
        // End Sub
    };

    // [67] Sub ToastSuccess(sSuccess As String) 
    this.toastsuccess = function (_ssuccess) {
        if (self == null) self = this;
        // [68]  Execute(ShowSuccess(sSuccess)) 
        self.execute(self.showsuccess(_ssuccess));
        // End Sub
    };

    // [72] Sub GetTextBox(elID As String) As String 
    this.gettextbox = function (_elid) {
        if (self == null) self = this;
        var _elkey;
        var _stext;
        // [73]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [74]  Dim elKey As String = {3} 
        _elkey = "#" + _elid + "";
        // [75]  Dim sText As String = Banano.GetElement(elKey).GetValue 
        _stext = u(_elkey).value();
        // [76]  sText = sText.trim 
        _stext = _stext.trim();
        // [77]  Return sText 
        return _stext;
        // End Sub
    };

    // [80] Sub Refresh 
    this.refresh = function () {
        if (self == null) self = this;
        // [82]  Banano.Eval( {37} ) 
        eval("M.updateTextFields();");
        // End Sub
    };

    // [86] Sub setTextBox(elID As String, txtValue As String) 
    this.settextbox = function (_elid, _txtvalue) {
        if (self == null) self = this;
        var _j;
        var _el;
        var _slength;
        var _itype;
        var _sbcode;
        var _script;
        // [87]  Dim j As String = {38} 
        _j = "$";
        // [88]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [89]  elID = {4} 
        _elid = "#" + _elid + "";
        // [90]  Dim el As BANanoElement = Banano.GetElement(elID) 
        _el = u(_elid);
        // [91]  el.SetValue(txtValue) 
        _el.value(_txtvalue);
        // [93]  Dim slength As String = el.GetAttr( {39} ) 
        _slength = _el.attr("data-length");
        // [94]  Dim itype As String = el.GetAttr( {40} ) 
        _itype = _el.attr("data-instance");
        // [95]  If itype = {41} Then 
        if (_itype == "textarea") {
            // [96]  Dim sbcode As StringBuilder 
            _sbcode = new StringBuilder();
            // [97]  sbcode.Initialize 
            _sbcode.isinitialized = true;
            // [98]  Dim script As String = {5} 
            _script = "M.textareaAutoResize(" + _j + "('" + _elid + "'));";
            // [99]  sbcode.Append(script) 
            _sbcode.append(_script);
            // [100]  If slength <> {42} Then 
            if (_slength != "0") {
                // [101]  Dim script As String = {6} 
                _script = "" + _j + "('textarea" + _elid + "').characterCounter();";
                // [102]  sbcode.Append(script) 
                _sbcode.append(_script);
                // [103]  End If 
            }
            // [104]  Banano.Eval(sbcode.ToString) 
            eval(_sbcode.toString());
            // [105]  else If itype = {43} Then 
        } else if (_itype == "input") {
            // [106]  If slength <> {44} Then 
            if (_slength != "0") {
                // [107]  Dim script As String = {7} 
                _script = "" + _j + "('input" + _elid + "').characterCounter();";
                // [108]  Banano.Eval(script) 
                eval(_script);
                // [109]  End If 
            }
            // [110]  End If 
        }
        // End Sub
    };

    // [114] Sub SetRadio(elID As String,elValue As String) 
    this.setradio = function (_elid, _elvalue) {
        if (self == null) self = this;
        // [115]  Banano.RunJavascriptMethod( {45} ,Array As String(elID,elValue)) 
        BANanoExec("setRadio", window, _elid, _elvalue);
        // End Sub
    };

    // [121] Sub getElementByName(elID As String) As BANanoElement 
    this.getelementbyname = function (_elid) {
        if (self == null) self = this;
        var _el;
        // [122]  Dim el As BANanoElement = Banano.GetElement( {8} ) 
        _el = u("[name='" + _elid + "']");
        // [123]  Return el 
        return _el;
        // End Sub
    };

    // [127] Sub GetRadio(elID As String) As String 
    this.getradio = function (_elid) {
        if (self == null) self = this;
        var _svalue;
        // [128]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [129]  Dim sValue As String 
        _svalue = '';
        // [130]  sValue = Banano.RunJavascriptMethod( {46} ,Array As String(elID)) 
        _svalue = BANanoExec("getRadio", window, _elid);
        // [131]  Return sValue 
        return _svalue;
        // End Sub
    };

    // [135] Sub SweetModalAlert(sTitle As String, sContent As String) As String 
    this.sweetmodalalert = function (_stitle, _scontent) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [136]  Dim j As String = {47} 
        _j = "$";
        // [137]  Dim script As String = {9} 
        _script = "" + _j + ".sweetModal('" + _stitle + "', '" + _scontent + "');";
        // [138]  Return script 
        return _script;
        // End Sub
    };

    // [142] Sub SweetModal(sTitle As String, sContent As String) 
    this.sweetmodal = function (_stitle, _scontent) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [143]  Dim j As String = {48} 
        _j = "$";
        // [144]  Dim script As String = {10} 
        _script = "" + _j + ".sweetModal({ \n	title: '" + _stitle + "', \n	content: '" + _scontent + "' \n});";
        // [145]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [150] Sub SweetModalWarning(sTitle As String, sContent As String) 
    this.sweetmodalwarning = function (_stitle, _scontent) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [151]  Dim j As String = {49} 
        _j = "$";
        // [152]  Dim script As String = {11} 
        _script = "" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_WARNING \n	});";
        // [153]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [157] Sub SweetModalSuccess(sTitle As String, sContent As String) 
    this.sweetmodalsuccess = function (_stitle, _scontent) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [158]  Dim j As String = {50} 
        _j = "$";
        // [159]  Dim script As String = {12} 
        _script = "" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_SUCCESS \n	});";
        // [160]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [165] Sub SweetModalError(sTitle As String, sContent As String) 
    this.sweetmodalerror = function (_stitle, _scontent) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [166]  Dim j As String = {51} 
        _j = "$";
        // [167]  Dim script As String = {13} 
        _script = "" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_ERROR \n	});";
        // [168]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [172] Sub SweetModalConfirm(sTitle As String, sContent As String, onYes As String, onCancel As String) 
    this.sweetmodalconfirm = function (_stitle, _scontent, _onyes, _oncancel) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [173]  Dim j As String = {52} 
        _j = "$";
        // [174]  Dim script As String = {14} 
        _script = "" + _j + ".sweetModal.confirm('" + _stitle + "', '" + _scontent + "', function() { \n	" + _onyes + " \n}, function() { \n	" + _oncancel + " \n});";
        // [175]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [179] Sub SweetModalPrompt(sTitle As String, sContent As String, sDefault As String, onVal As String) 
    this.sweetmodalprompt = function (_stitle, _scontent, _sdefault, _onval) {
        if (self == null) self = this;
        var _j;
        var _script;
        // [180]  Dim j As String = {53} 
        _j = "$";
        // [181]  Dim script As String = {15} 
        _script = "" + _j + ".sweetModal.prompt('" + _stitle + "', '" + _scontent + "', '" + _sdefault + "', function(val) { \n	" + _onval + " \n});";
        // [182]  Execute(script) 
        self.execute(_script);
        // End Sub
    };

    // [186] Public Sub Initialize(thisApp As UOEApp, sID As String, bCenter As Boolean, sNavBarTitle As String, sNavBarTitlePosition As String, bNavBarFixed As Boolean, bFixDrawer As Boolean, sTheme As String, sclass As String) 
    this.initialize = function (_thisapp, _sid, _bcenter, _snavbartitle, _snavbartitleposition, _bnavbarfixed, _bfixdrawer, _stheme, _sclass) {
        if (self == null) self = this;
        // [187]  App = thisApp 
        self._app = _thisapp;
        // [188]  App.NewPage 
        self._app.newpage();
        // [189]  App.M.Initialize( {54} ) 
        self._app._m = M;
        // [190]  App.jQ.Initialize( {55} ) 
        self._app._jq = $;
        // [191]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [192]  Theme = sTheme 
        self._theme = _stheme;
        // [193]  pageMain.Initialize( {56} , {57} ) 
        self._pagemain.initialize("main", "main");
        // [194]  pageHeader.Initialize( {58} , {59} ) 
        self._pageheader.initialize("header", "header");
        // [195]  Content.Initialize(App,sID,bCenter,sTheme) 
        self._content.initialize(self._app, _sid, _bcenter, _stheme);
        // [196]  Content.AddClass(sclass) 
        self._content.addclass(_sclass);
        // [197]  pageFooter.Initialize( {60} , {61} ) 
        self._pagefooter.initialize("footer", "footer");
        // [198]  pageFooter.AddClass( {62} ) 
        self._pagefooter.addclass("page-footer");
        // [199]  Footer.Initialize(App, {63} & sID,bCenter,sTheme) 
        self._footer.initialize(self._app, "footer" + _sid, _bcenter, _stheme);
        // [200]  HasFooter = False 
        self._hasfooter = false;
        // [201]  FixedFooter = False 
        self._fixedfooter = false;
        // [202]  HasCopyright = False 
        self._hascopyright = false;
        // [203]  BackgroundImage = {64} 
        self._backgroundimage = "";
        // [204]  NavBar.Initialize(App, {65} ,sNavBarTitle,sNavBarTitlePosition,bNavBarFixed,bFixDrawer,sTheme) 
        self._navbar.initialize(self._app, "navbar", _snavbartitle, _snavbartitleposition, _bnavbarfixed, _bfixdrawer, _stheme);
        // [205]  Drawer = NavBar.drawer 
        self._drawer = self._navbar._drawer;
        // End Sub
    };

    // [209] Sub AddTooltip1(sID As String, text As String) 
    this.addtooltip1 = function (_sid, _text) {
        if (self == null) self = this;
        // [210]  AddToolTip(sID,text, {66} ,-1) 
        self.addtooltip(_sid, _text, "", -1);
        // End Sub
    };

    // [214] Sub AddToolTip(sID As String, text As String, position As String, delay As Int) 
    this.addtooltip = function (_sid, _text, _position, _delay) {
        if (self == null) self = this;
        var _tt;
        // [215]  sID = sID.tolowercase 
        _sid = _sid.toLowerCase();
        // [216]  If position = {67} Then position = App.TooltipPosition 
        if (_position == "") {
            _position = self._app._tooltipposition;
        }
        // [217]  If delay = -1 Or delay = 0 Then delay = App.TooltipDelay 
        if (_delay == -1 || _delay == 0) {
            _delay = self._app._tooltipdelay;
        }
        // [218]  Dim tt As UOEToolTip 
        _tt = new banano_uoebanano_uoetooltip();
        // [219]  tt.Initialize(sID,text,position,delay, {68} ) 
        _tt.initialize(_sid, _text, _position, _delay, "");
        // [220]  App.ToolTips.Put(sID,tt) 
        self._app._tooltips[_sid] = _tt;
        // End Sub
    };

    // [225] Sub Enable(elID As String, bStatus As Boolean) 
    this.enable = function (_elid, _bstatus) {
        if (self == null) self = this;
        var _elkey;
        // [226]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [227]  Dim elKey As String = {16} 
        _elkey = "#" + _elid + "";
        // [228]  If bStatus Then 
        if (_bstatus) {
            // [229]  removeAttr(elID, {69} ) 
            self.removeattr(_elid, "disabled");
            // [230]  Else 
        } else {
            // [231]  Banano.GetElement(elKey).SetAttr( {70} , {71} ) 
            u(_elkey).attr("disabled", "true");
            // [232]  End If 
        }
        // End Sub
    };

    // [236] Sub removeAttr1(elID As String, attrName As String) 
    this.removeattr1 = function (_elid, _attrname) {
        if (self == null) self = this;
        var _ekey;
        // [237]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [238]  Dim eKey As String = {17} 
        _ekey = "#" + _elid + "";
        // [239]  Banano.GetElement(eKey).SetAttr(attrName, Null) 
        u(_ekey).attr(_attrname, null);
        // End Sub
    };

    // [243] Sub removeAttr(elID As String, attrName As String) 
    this.removeattr = function (_elid, _attrname) {
        if (self == null) self = this;
        // [244]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [245]  App.jQ.Selector( {18} ).RunMethod( {72} , Array(attrName)) 
        self._app._jq("#" + _elid + "")["removeAttr"](_attrname);
        // End Sub
    };

    // [250] Sub ShowSuccess(sContent As String) As String 
    this.showsuccess = function (_scontent) {
        if (self == null) self = this;
        var _script;
        // [251]  Dim script As String = ShowToast(sContent,3000,True, {73} ) 
        _script = self.showtoast(_scontent, 3000, true, "white.green");
        // [252]  Return script 
        return _script;
        // End Sub
    };

    // [256] Sub ShowError(sContent As String) As String 
    this.showerror = function (_scontent) {
        if (self == null) self = this;
        var _script;
        // [257]  Dim script As String = ShowToast(sContent,3000,True, {74} ) 
        _script = self.showtoast(_scontent, 3000, true, "white.red");
        // [258]  Return script 
        return _script;
        // End Sub
    };

    // [262] Sub ShowToast(sContent As String, Duration As Int, bRounded As Boolean,themeName As String) As String 
    this.showtoast = function (_scontent, _duration, _brounded, _themename) {
        if (self == null) self = this;
        var _tclass;
        var _div;
        var _srounded;
        var _sout;
        var _str;
        // [263]  Dim tClass As String = App.MaterialGetTheme(themeName) 
        _tclass = self._app.materialgettheme(_themename);
        // [264]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [265]  div.Initialize( {75} , {76} ) 
        _div.initialize("", "div");
        // [266]  div.AddContent(sContent) 
        _div.addcontent(_scontent);
        // [267]  Dim srounded As String = {77} 
        _srounded = "";
        // [268]  srounded = App.iif(bRounded, {78} , {79} ) 
        _srounded = self._app.iif(_brounded, "rounded", "");
        // [269]  Dim sout As String = div.HTML 
        _sout = _div.html();
        // [270]  sout = sout.Replace(CRLF, {80} ) 
        _sout = _sout.split("\n").join("");
        // [271]  Dim str As String = {19} 
        _str = "M.toast({html:'" + _sout + "', displayLength:" + _duration + ", classes:'" + _srounded + " " + _tclass + "'});";
        // [272]  Return str 
        return _str;
        // End Sub
    };

    // [276] Sub ShowSuccess1(varName As String) As String 
    this.showsuccess1 = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [277]  Dim script As String = {20} 
        _script = "M.toast({html:" + _varname + ", displayLength:3000, classes:'rounded white-text green'});";
        // [278]  Return script 
        return _script;
        // End Sub
    };

    // [282] Sub ShowError1(varName As String) As String 
    this.showerror1 = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [283]  Dim script As String = {21} 
        _script = "M.toast({html:" + _varname + ", displayLength:3000, classes:'rounded white-text red'});";
        // [284]  Return script 
        return _script;
        // End Sub
    };

    // [288] Sub Execute(jsCode As String) 
    this.execute = function (_jscode) {
        if (self == null) self = this;
        // [289]  Banano.Eval(jsCode) 
        eval(_jscode);
        // End Sub
    };

    // [292] public Sub CreateE(EventsMethod As String, EVentHandler As Object) 
    this.createe = function (_eventsmethod, _eventhandler) {
        if (self == null) self = this;
        // [294]  Create 
        self.create();
        // [296]  App.BindEvents(EventsMethod, EVentHandler) 
        self._app.bindevents(_eventsmethod, _eventhandler);
        // End Sub
    };

    // [300] public Sub Create() 
    this.create = function () {
        if (self == null) self = this;
        var _fcolor;
        var _bcolor;
        var _body;
        var _sdrawer;
        var _strx;
        var _foot;
        var _sbody;
        var _elbody;
        var _jsonstyle;
        var _dptot;
        var _dpcnt;
        var _strds;
        var _dpmap;
        var _instancetype;
        var _instanceid;
        var _dp;
        var _jstot;
        var _jscnt;
        var _jscode;
        var _csstot;
        var _csscnt;
        var _strcss;
        var _cssmap;
        var _cssid;
        var _cssobj;
        // [302]  Dim fColor As String = App.GetForeColorHex(Theme) 
        _fcolor = self._app.getforecolorhex(self._theme);
        // [303]  Dim bColor As String = App.GetBackGroundColorHex(Theme) 
        _bcolor = self._app.getbackgroundcolorhex(self._theme);
        // [304]  If Footer.Theme = {81} Then Footer.Theme = App.theme 
        if (self._footer._theme == "") {
            self._footer._theme = self._app._theme;
        }
        // [306]  Dim body As StringBuilder 
        _body = new StringBuilder();
        // [307]  body.Initialize 
        _body.isinitialized = true;
        // [339]  pageMain.AddContent(Content.ToString) 
        self._pagemain.addcontent(self._content.tostring());
        // [342]  Dim sdrawer As String = Drawer.ToString 
        _sdrawer = self._drawer.tostring();
        // [343]  Dim strx As String = Drawer.getSettings 
        _strx = self._drawer.getsettings();
        // [344]  App.Components.Add(strx) 
        self._app._components.push(_strx);
        // [345]  Drawer.getCSS 
        self._drawer.getcss();
        // [346]  pageHeader.AddContent(sdrawer) 
        self._pageheader.addcontent(_sdrawer);
        // [347]  pageHeader.AddContent(NavBar.ToString) 
        self._pageheader.addcontent(self._navbar.tostring());
        // [348]  body.Append(pageHeader.html) 
        _body.append(self._pageheader.html());
        // [349]  body.Append(pageMain.html) 
        _body.append(self._pagemain.html());
        // [351]  If HasFooter Then 
        if (self._hasfooter) {
            // [352]  App.MaterialUseTheme(Footer.Theme,Footer.element) 
            self._app.materialusetheme(self._footer._theme, self._footer._element);
            // [353]  App.MaterialUseTheme(Footer.Theme,pageFooter) 
            self._app.materialusetheme(self._footer._theme, self._pagefooter);
            // [354]  pageFooter.AddContent(Footer.ToString) 
            self._pagefooter.addcontent(self._footer.tostring());
            // [355]  If HasCopyright Then 
            if (self._hascopyright) {
                // [356]  Dim foot As UOECopyRights 
                _foot = new banano_uoebanano_uoecopyrights();
                // [357]  foot.Initialize(App, {88} ,Footer.theme) 
                _foot.initialize(self._app, "foot", self._footer._theme);
                // [358]  foot.AddTermsAndConditions 
                _foot.addtermsandconditions();
                // [359]  foot.AddDisclaimer 
                _foot.adddisclaimer();
                // [360]  foot.AddPrivacyPolicy 
                _foot.addprivacypolicy();
                // [361]  pageFooter.AddContent(foot.tostring) 
                self._pagefooter.addcontent(_foot.tostring());
                // [362]  End If 
            }
            // [363]  body.Append(pageFooter.HTML) 
            _body.append(self._pagefooter.html());
            // [364]  End If 
        }
        // [373]  Dim sBody As String = body.tostring 
        _sbody = _body.toString();
        // [375]  Dim elBody As BANanoElement = Banano.GetElement( {90} ) 
        _elbody = u("#body");
        // [376]  elBody.Empty 
        _elbody.empty();
        // [377]  elBody.SetHTML(sBody) 
        _elbody.html(_sbody);
        // [378]  elBody.AddClass(bColor) 
        _elbody.addClass(_bcolor);
        // [380]  Banano.Eval( {91} ) 
        eval("M.AutoInit();");
        // [383]  If AutoSizeLogo Then 
        if (self._autosizelogo) {
            // [384]  Dim jsonStyle As String = {22} 
            _jsonstyle = "{ \"font-size\": \"2.1vw\", \"font-weight\": \"bold\" }";
            // [385]  Banano.GetElement( {92} ).SetStyle(jsonStyle) 
            u("#navbar").css(JSON.parse(_jsonstyle));
            // [388]  End If 
        }
        // [389]  Dim jsonStyle As String = {23} 
        _jsonstyle = "{ \"padding-top\": \"0px\" }";
        // [390]  Banano.GetElement( {95} ).SetStyle(jsonStyle) 
        u(".page-footer").css(JSON.parse(_jsonstyle));
        // [392]  If FixedFooter Then 
        if (self._fixedfooter) {
            // [393]  Dim jsonStyle As String = {24} 
            _jsonstyle = "{ \"display\": \"flex\", \"min-height\": \"100vh\", \"flex-direction\": \"column\" }";
            // [394]  Banano.GetElement( {97} ).SetStyle(jsonStyle) 
            u("body").css(JSON.parse(_jsonstyle));
            // [395]  Dim jsonStyle As String = {25} 
            _jsonstyle = "{ \"flex\": \"1 0 auto\" }";
            // [396]  Banano.GetElement( {98} ).SetStyle(jsonStyle) 
            u("main").css(JSON.parse(_jsonstyle));
            // [399]  End If 
        }
        // [401]  Banano.Eval( {99} ) 
        eval("M.updateTextFields();");
        // [402]  Dim dpTot As Int = App.Components.Size - 1 
        _dptot = self._app._components.length - 1;
        // [403]  Dim dpCnt As Int 
        _dpcnt = 0;
        // [404]  For dpCnt = 0 To dpTot 
        for (_dpcnt = 0; _dpcnt <= _dptot; _dpcnt++) {
            // [405]  Dim strDS As String = App.Components.Get(dpCnt) 
            _strds = self._app._components[_dpcnt];
            // [406]  Dim dpMap As Map = App.Json2Map(strDS) 
            _dpmap = self._app.json2map(_strds);
            // [407]  Dim instancetype As String = dpMap.get( {100} ) 
            _instancetype = _dpmap["instance"];
            // [408]  Dim instanceID As String = dpMap.Get( {101} ) 
            _instanceid = _dpmap["id"];
            // [410]  dpMap.Remove( {102} ) 
            delete _dpmap["instance"];
            // [411]  dpMap.Remove( {103} ) 
            delete _dpmap["id"];
            // [413]  Dim dp As BANanoObject 
            _dp = null;
            // [414]  dp = App.jQ.Selector( {28} ) 
            _dp = self._app._jq("#" + _instanceid + "");
            // [415]  dp.RunMethod(instancetype, dpMap) 
            _dp[_instancetype](_dpmap);
            // [416]  Next 
        }
        // [418]  Dim jsTot As Int = App.JS.Size - 1 
        _jstot = self._app._js.length - 1;
        // [419]  Dim jsCnt As Int 
        _jscnt = 0;
        // [420]  For jsCnt = 0 To jsTot 
        for (_jscnt = 0; _jscnt <= _jstot; _jscnt++) {
            // [421]  Dim jsCode As String = App.JS.Get(jsCnt) 
            _jscode = self._app._js[_jscnt];
            // [422]  Banano.eval(jsCode) 
            eval(_jscode);
            // [423]  Next 
        }
        // [425]  Dim cssTot As Int = App.CSS.Size - 1 
        _csstot = self._app._css.length - 1;
        // [426]  Dim cssCnt As Int 
        _csscnt = 0;
        // [427]  For cssCnt = 0 To cssTot 
        for (_csscnt = 0; _csscnt <= _csstot; _csscnt++) {
            // [428]  Dim strcss As String = App.CSS.Get(cssCnt) 
            _strcss = self._app._css[_csscnt];
            // [429]  Dim cssmap As Map = App.Json2Map(strcss) 
            _cssmap = self._app.json2map(_strcss);
            // [430]  Dim cssid As String = cssmap.Get( {104} ) 
            _cssid = _cssmap["id"];
            // [431]  cssmap.Remove( {105} ) 
            delete _cssmap["id"];
            // [432]  strcss = App.Map2Json(cssmap) 
            _strcss = self._app.map2json(_cssmap);
            // [433]  Dim cssobj As BANanoElement 
            _cssobj = null;
            // [434]  cssobj = Banano.GetElement(cssid) 
            _cssobj = u(_cssid);
            // [435]  cssobj.SetStyle(strcss) 
            _cssobj.css(JSON.parse(_strcss));
            // [436]  Next 
        }
        // End Sub
    };

    // [440] Sub Pulse(elID As String, bStatus As Boolean) 
    this.pulse = function (_elid, _bstatus) {
        if (self == null) self = this;
        var _elkey;
        // [441]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [442]  Dim elKey As String = {29} 
        _elkey = "#" + _elid + "";
        // [443]  If bStatus Then 
        if (_bstatus) {
            // [444]  Banano.GetElement(elKey).AddClass( {106} ) 
            u(_elkey).addClass("pulse");
            // [445]  Else 
        } else {
            // [446]  Banano.GetElement(elKey).RemoveClass( {107} ) 
            u(_elkey).removeClass("pulse");
            // [447]  End If 
        }
        // End Sub
    };

}

function setRadio(vRadioObj, vValue) {
    var radios = document.getElementsByName(vRadioObj);
    for (var j = 0; j < radios.length; j++) {
        if (radios[j].value == vValue) {
            radios[j].checked = true;
            break;
        }
    }
}

function getRadio(vRadioObj) {
    var radios = document.getElementsByName(vRadioObj);
    for (var j = 0; j < radios.length; j++) {
        if (radios[j].checked) {
            return radios[j].value;
        }

    }
    return "";
}

// =========================== UOECarousel  ===========================
function banano_uoebanano_uoecarousel() {
    var self;
    this._id = '';

    this._theme = '';

    this._visibility = '';

    this._zdepth = '';

    this._enabled = false;

    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._items = [];

    this._isslider = false;

    this._duration = 0;

    this._dist = 0;

    this._shift = 0;

    this._padding = 0;

    this._fullwidth = false;

    this._indicators = false;

    this._nowrap = false;

    this._center = false;

    this._hoverable = false;

    this._interval = 0;

    this._numvisible = 0;

    this._instance = '';

    // [29] Sub AddStyleAttribute(attribute As String, value As String) As UOECarousel 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [30]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [31]  Return Me 
        return self;
        // End Sub
    };

    // [35] Sub AddClass(sClass As String) As UOECarousel 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [36]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [37]  Return Me 
        return self;
        // End Sub
    };

    // [41] Sub RemoveClass(sClass As String) As UOECarousel 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [42]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [43]  Return Me 
        return self;
        // End Sub
    };

    // [47] Sub AddAttribute(attr As String, value As String) As UOECarousel 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [48]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [49]  Return Me 
        return self;
        // End Sub
    };

    // [53] Sub RemoveAttribute(attr As String) As UOECarousel 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [54]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Public Sub Initialize(thisApp As UOEApp, mvarID As String) 
    this.initialize = function (_thisapp, _mvarid) {
        if (self == null) self = this;
        // [61]  App = thisApp 
        self._app = _thisapp;
        // [62]  ID = mvarID.tolowercase 
        self._id = _mvarid.toLowerCase();
        // [63]  Element.Initialize(ID, {4} ) 
        self._element.initialize(self._id, "div");
        // [64]  Theme = {5} 
        self._theme = "";
        // [65]  Center = False 
        self._center = false;
        // [66]  Visibility = {6} 
        self._visibility = "";
        // [67]  ZDepth = {7} 
        self._zdepth = "";
        // [68]  Enabled = True 
        self._enabled = true;
        // [69]  Items.Initialize 
        self._items.length = 0;
        // [70]  Items.clear 
        self._items.length = 0;
        // [71]  IsSlider = False 
        self._isslider = false;
        // [72]  Duration = 200 
        self._duration = 200;
        // [73]  Dist = -100 
        self._dist = -100;
        // [74]  Shift = 0 
        self._shift = 0;
        // [75]  Padding = 0 
        self._padding = 0;
        // [76]  FullWidth = True 
        self._fullwidth = true;
        // [77]  Indicators = True 
        self._indicators = true;
        // [78]  NoWrap = False 
        self._nowrap = false;
        // [79]  Interval = 2000 
        self._interval = 2000;
        // [80]  numVisible = 5 
        self._numvisible = 5;
        // [81]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [85] Sub AddCarouselFixedItem As UOECarousel 
    this.addcarouselfixeditem = function () {
        if (self == null) self = this;
        var _fi;
        // [86]  Dim fi As UOEHTML 
        _fi = new banano_uoebanano_uoehtml();
        // [87]  fi.Initialize( {8} , {9} ) 
        _fi.initialize("", "div");
        // [88]  fi.AddClass( {10} ) 
        _fi.addclass("carousel-fixed-item");
        // [89]  fi.AddClass( {11} ) 
        _fi.addclass("center");
        // [90]  Items.Add(fi.HTML) 
        self._items.push(_fi.html());
        // [91]  Return Me 
        return self;
        // End Sub
    };

    // [95] Sub AddItem(itemid As String, itemHTML As String) As UOECarousel 
    this.additem = function (_itemid, _itemhtml) {
        if (self == null) self = this;
        var _div;
        // [96]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [97]  div.Initialize(itemid, {12} ) 
        _div.initialize(_itemid, "div");
        // [98]  div.AddClass( {13} ) 
        _div.addclass("carousel-item");
        // [99]  div.AddContent(itemHTML) 
        _div.addcontent(_itemhtml);
        // [100]  Items.Add(div.HTML) 
        self._items.push(_div.html());
        // [101]  Return Me 
        return self;
        // End Sub
    };

    // [105] Sub AddContainer(cont As UOEContainer) As UOECarousel 
    this.addcontainer = function (_cont) {
        if (self == null) self = this;
        var _div;
        // [106]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [107]  div.Initialize(cont.id & {14} , {15} ) 
        _div.initialize(_cont._id + "parent", "div");
        // [108]  div.AddClass( {16} ) 
        _div.addclass("carousel-item");
        // [109]  div.AddCursor 
        _div.addcursor();
        // [110]  If cont <> Null Then 
        if (_cont != null) {
            // [111]  div.AddContent(cont.tostring) 
            _div.addcontent(_cont.tostring());
            // [112]  End If 
        }
        // [113]  Items.Add(div.HTML) 
        self._items.push(_div.html());
        // [114]  Return Me 
        return self;
        // End Sub
    };

    // [118] Sub AddSlide(itemID As String, href As String, imgURL As String) As UOECarousel 
    this.addslide = function (_itemid, _href, _imgurl) {
        if (self == null) self = this;
        var _slideitem;
        // [119]  Dim slideItem As UOEAnchor 
        _slideitem = new banano_uoebanano_uoeanchor();
        // [120]  slideItem.Initialize(App,itemID) 
        _slideitem.initialize(self._app, _itemid);
        // [121]  slideItem.AddClass( {17} ) 
        _slideitem.addclass("carousel-item");
        // [122]  slideItem.HREF = href 
        _slideitem._href = _href;
        // [123]  modUOE.MaterialAddImage(App,slideItem.element,imgURL, {18} , {19} , {20} ,False,True,True, {21} ) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _slideitem._element, _imgurl, "", "", "", false, true, true, "");
        // [124]  slideItem.WavesEffect = False 
        _slideitem._waveseffect = false;
        // [125]  Items.Add(slideItem.ToString) 
        self._items.push(_slideitem.tostring());
        // [126]  Return Me 
        return self;
        // End Sub
    };

    // [130] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [131]  Element.ID = ID 
        self._element._id = self._id;
        // [132]  Element.AddClass( {22} ) 
        self._element.addclass("carousel");
        // [133]  Element.AddClassOnCondition(IsSlider, {23} ) 
        self._element.addclassoncondition(self._isslider, "carousel-slider");
        // [134]  Element.AddAttributeOnCondition(Indicators, {24} , {25} ) 
        self._element.addattributeoncondition(self._indicators, "data-indicators", "true");
        // [135]  Element.AddClassOnCondition(Center, {26} ) 
        self._element.addclassoncondition(self._center, "center");
        // [136]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [137]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [138]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [139]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [140]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [141]  Element.AddContentList(Items) 
        self._element.addcontentlist(self._items);
        // [147]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

    // [151] Sub NextSlide() 
    this.nextslide = function () {
        if (self == null) self = this;
        var _script;
        // [152]  Dim script As String = {1} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".next();";
        // [153]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [157] Sub PreviousSlide() 
    this.previousslide = function () {
        if (self == null) self = this;
        var _script;
        // [158]  Dim script As String = {2} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".prev();";
        // [159]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [163] Sub SetSlide(slidePos As Int) 
    this.setslide = function (_slidepos) {
        if (self == null) self = this;
        var _script;
        // [164]  Dim script As String = {3} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".set(" + _slidepos + ");";
        // [165]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [168] public Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _dpsettings;
        var _strds;
        // [169]  Dim dpSettings As Map 
        _dpsettings = {};
        // [170]  dpSettings.Initialize 
        _dpsettings = {};
        // [171]  dpSettings.clear 
        _dpsettings = {};
        // [172]  dpSettings.Put( {29} , ID) 
        _dpsettings["id"] = self._id;
        // [173]  dpSettings.Put( {30} , {31} ) 
        _dpsettings["instance"] = "carousel";
        // [174]  dpSettings.Put( {32} , FullWidth) 
        _dpsettings["fullwidth"] = self._fullwidth;
        // [175]  dpSettings.Put( {33} , Duration) 
        _dpsettings["duration"] = self._duration;
        // [176]  dpSettings.Put( {34} , numVisible) 
        _dpsettings["numVisible"] = self._numvisible;
        // [177]  dpSettings.Put( {35} , Dist) 
        _dpsettings["dist"] = self._dist;
        // [178]  dpSettings.Put( {36} , Shift) 
        _dpsettings["shift"] = self._shift;
        // [179]  dpSettings.Put( {37} , Padding) 
        _dpsettings["padding"] = self._padding;
        // [180]  dpSettings.Put( {38} , Indicators) 
        _dpsettings["indicators"] = self._indicators;
        // [181]  dpSettings.Put( {39} , NoWrap) 
        _dpsettings["nowrap"] = self._nowrap;
        // [182]  Dim strDS As String = App.Map2JSON(dpSettings) 
        _strds = self._app.map2json(_dpsettings);
        // [183]  Return strDS 
        return _strds;
        // End Sub
    };

}
// =========================== UOECheckBox  ===========================
function banano_uoebanano_uoecheckbox() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._enabled = false;

    this._hoverable = false;

    this._filledin = false;

    this._checked = false;

    this._visibility = '';

    this._element = new banano_uoebanano_uoehtml();

    this._zdepth = '';

    this._lbl = new banano_uoebanano_uoehtml();

    this._inp = new banano_uoebanano_uoehtml();

    this._spn = new banano_uoebanano_uoehtml();

    this._inline = false;

    this._theme = '';

    // [24] Sub AddStyleAttribute(attribute As String, value As String) As UOECheckBox 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [25]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Public Sub Initialize(thisApp As UOEApp, sID As String, sName As String, sValue As String, sTitle As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _sname, _svalue, _stitle, _themename) {
        if (self == null) self = this;
        // [31]  App = thisApp 
        self._app = _thisapp;
        // [32]  If themeName = {1} Then themeName = App.theme 
        if (_themename == "") {
            _themename = self._app._theme;
        }
        // [33]  Theme = themeName 
        self._theme = _themename;
        // [34]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [35]  FilledIn = False 
        self._filledin = false;
        // [36]  Checked = False 
        self._checked = false;
        // [37]  Enabled = True 
        self._enabled = true;
        // [38]  Visibility = {2} 
        self._visibility = "";
        // [39]  Element.Initialize(ID, {3} ) 
        self._element.initialize(self._id, "p");
        // [40]  lbl.Initialize(ID & {4} , {5} ) 
        self._lbl.initialize(self._id + "lbl", "label");
        // [41]  inp.Initialize(ID & {6} , {7} ) 
        self._inp.initialize(self._id + "inp", "input");
        // [42]  inp.SetTYPE( {8} ).SetNAME(sName).SetVALUE(sValue) 
        self._inp.settype("checkbox").setname(_sname).setvalue(_svalue);
        // [43]  spn.Initialize(ID & {9} , {10} ) 
        self._spn.initialize(self._id + "-span", "span");
        // [44]  spn.AddContent(sTitle & {11} ) 
        self._spn.addcontent(_stitle + "{NBSP}{NBSP}");
        // [45]  Inline = False 
        self._inline = false;
        // End Sub
    };

    // [49] Sub AddClass(sClass As String) As UOECheckBox 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [50]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveClass(sClass As String) As UOECheckBox 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [56]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub AddAttribute(attr As String, value As String) As UOECheckBox 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [62]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [63]  Return Me 
        return self;
        // End Sub
    };

    // [67] Sub RemoveAttribute(attr As String) As UOECheckBox 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [68]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [73] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [74]  Element.ID = ID 
        self._element._id = self._id;
        // [75]  If Theme = {12} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [76]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [77]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [78]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [79]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [80]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [81]  inp.AddAttributeOnCondition(Not(Enabled), {13} , {14} ) 
        self._inp.addattributeoncondition(!(self._enabled), "disabled", "disabled");
        // [82]  inp.AddAttributeOnCondition(Checked, {15} , {16} ) 
        self._inp.addattributeoncondition(self._checked, "checked", "checked");
        // [83]  inp.AddClassOnCondition(FilledIn, {17} ) 
        self._inp.addclassoncondition(self._filledin, "filled-in");
        // [84]  lbl.AddElement(inp) 
        self._lbl.addelement(self._inp);
        // [85]  lbl.AddElement(spn) 
        self._lbl.addelement(self._spn);
        // [86]  Element.AddElement(lbl) 
        self._element.addelement(self._lbl);
        // [87]  Element.AddClassOnCondition(Inline, {18} ) 
        self._element.addclassoncondition(self._inline, "inline");
        // [88]  Element.AddStyleAttributeOnCondition(Inline, {19} , {20} ) 
        self._element.addstyleattributeoncondition(self._inline, "display", "inline-block");
        // [89]  Element.AddStyleAttributeOnCondition(Inline, {21} , {22} ) 
        self._element.addstyleattributeoncondition(self._inline, "padding", "0 12px");
        // [94]  Return Element.html 
        return self._element.html();
        // End Sub
    };

    // [98] public Sub setIndeterminate() 
    this.setindeterminate = function () {
        if (self == null) self = this;
        var _script;
        // [99]  Dim script As String = {0} 
        _script = "// Set checkbox on forms.html to indeterminate \n    var chk" + self._id + " = document.getElementById('" + self._id + "inp'); \n    if (chk" + self._id + " !== null) chk" + self._id + ".indeterminate = true;";
        // [100]  BANano.Eval(script) 
        eval(_script);
        // End Sub
    };

}
// =========================== UOECheckBoxGroup  ===========================
function banano_uoebanano_uoecheckboxgroup() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._title = '';

    this._theme = '';

    this._enabled = false;

    this._container = new banano_uoebanano_uoehtml();

    this._visibility = '';

    this._zdepth = '';

    // [16] Sub CheckAll(bStatus As String) 
    this.checkall = function (_bstatus) {
        if (self == null) self = this;
        var _script;
        // [17]  If bStatus = {1} Then bStatus = {2} 
        if (_bstatus == "1") {
            _bstatus = "true";
        }
        // [18]  If bStatus = {3} Then bStatus = {4} 
        if (_bstatus == "0") {
            _bstatus = "false";
        }
        // [19]  If bStatus = {5} Then bStatus = {6} 
        if (_bstatus == "y") {
            _bstatus = "true";
        }
        // [20]  If bStatus = {7} Then bStatus = {8} 
        if (_bstatus == "n") {
            _bstatus = "false";
        }
        // [21]  If bStatus = True Then bStatus = {9} 
        if (_bstatus == true) {
            _bstatus = "true";
        }
        // [22]  If bStatus = False Then bStatus = {10} 
        if (_bstatus == false) {
            _bstatus = "false";
        }
        // [23]  Dim script As String = {0} 
        _script = "var tblChkBox" + self._id + " = $('#" + self._id + " input:checkbox'); \n	console.log(tblChkBox" + self._id + "); \n	$(tblChkBox" + self._id + ").prop('checked', " + _bstatus + ");";
        // [24]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [28] Sub AddStyleAttribute(attribute As String, value As String) As UOECheckBoxGroup 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [29]  Container.AddStyleAttribute(attribute,value) 
        self._container.addstyleattribute(_attribute, _value);
        // [30]  Return Me 
        return self;
        // End Sub
    };

    // [35] Public Sub Initialize(thisApp As UOEApp, sID As String, sTitle As String, bShowTitle As Boolean, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _bshowtitle, _themename) {
        if (self == null) self = this;
        var _lbl;
        // [36]  App = thisApp 
        self._app = _thisapp;
        // [37]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [38]  Theme = themeName 
        self._theme = _themename;
        // [39]  Enabled = True 
        self._enabled = true;
        // [40]  Container.Initialize(ID, {11} ) 
        self._container.initialize(self._id, "div");
        // [41]  If bShowTitle Then 
        if (_bshowtitle) {
            // [42]  Dim lbl As UOEHTML 
            _lbl = new banano_uoebanano_uoehtml();
            // [43]  lbl.Initialize(ID & {12} , {13} ) 
            _lbl.initialize(self._id + "lbl", "label");
            // [44]  lbl.SetFOR(ID).AddContent(sTitle) 
            _lbl.setfor(self._id).addcontent(_stitle);
            // [45]  App.MaterialUseTheme(themeName,lbl) 
            self._app.materialusetheme(_themename, _lbl);
            // [46]  Container.AddElement(lbl) 
            self._container.addelement(_lbl);
            // [47]  End If 
        }
        // End Sub
    };

    // [52] Sub AddClass(sClass As String) As UOECheckBoxGroup 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [53]  Container.AddClass(sClass) 
        self._container.addclass(_sclass);
        // [54]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub RemoveClass(sClass As String) As UOECheckBoxGroup 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [59]  Container.RemoveClass(sClass) 
        self._container.removeclass(_sclass);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub AddAttribute(attr As String, value As String) As UOECheckBoxGroup 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [65]  Container.AddAttribute(attr,value) 
        self._container.addattribute(_attr, _value);
        // [66]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub RemoveAttribute(attr As String) As UOECheckBoxGroup 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [71]  Container.RemoveAttribute(attr) 
        self._container.removeattribute(_attr);
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub AddItem(itemID As String, itemValue As String, itemText As String, bInline As Boolean, bEnabled As Boolean, bSelected As Boolean) 
    this.additem = function (_itemid, _itemvalue, _itemtext, _binline, _benabled, _bselected) {
        if (self == null) self = this;
        var _rad;
        // [77]  Dim rad As UOECheckBox 
        _rad = new banano_uoebanano_uoecheckbox();
        // [78]  rad.Initialize(App,itemID,ID,itemValue,itemText, {14} ) 
        _rad.initialize(self._app, _itemid, self._id, _itemvalue, _itemtext, "");
        // [79]  rad.Checked = bSelected 
        _rad._checked = _bselected;
        // [80]  rad.Enabled = bEnabled 
        _rad._enabled = _benabled;
        // [81]  rad.Inline = bInline 
        _rad._inline = _binline;
        // [82]  Container.AddContent(rad.tostring) 
        self._container.addcontent(_rad.tostring());
        // End Sub
    };

    // [86] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [87]  Container.MaterialVisibility(Visibility).MaterialEnable(Enabled) 
        self._container.materialvisibility(self._visibility).materialenable(self._enabled);
        // [88]  App.MaterialUseTheme(Theme,Container) 
        self._app.materialusetheme(self._theme, self._container);
        // [89]  Container.MaterialZDepth(ZDepth).MaterialVisibility(Visibility) 
        self._container.materialzdepth(self._zdepth).materialvisibility(self._visibility);
        // [94]  App.ApplyToolTip(ID,Container) 
        self._app.applytooltip(self._id, self._container);
        // [95]  Return Container.html 
        return self._container.html();
        // End Sub
    };

}
// =========================== UOEChip  ===========================
function banano_uoebanano_uoechip() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._imageurl = '';

    this._text = '';

    this._element = new banano_uoebanano_uoehtml();

    this._imagealt = '';

    this._canclose = false;

    this._theme = '';

    this._visibility = '';

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._zdepth = '';

    this._enabled = false;

    this._hoverable = false;

    // [22] Sub AddStyleAttribute(attribute As String, value As String) As UOEChip 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [23]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [24]  Return Me 
        return self;
        // End Sub
    };

    // [28] Public Sub Initialize(thisApp As UOEApp, chipID As String,chipText As String, chipImg As String, chipImgAlt As String, chipTheme As String) 
    this.initialize = function (_thisapp, _chipid, _chiptext, _chipimg, _chipimgalt, _chiptheme) {
        if (self == null) self = this;
        // [30]  App = thisApp 
        self._app = _thisapp;
        // [31]  Enabled = True 
        self._enabled = true;
        // [32]  ImageURL = chipImg 
        self._imageurl = _chipimg;
        // [33]  Text = chipText 
        self._text = _chiptext;
        // [34]  ID = chipID.tolowercase 
        self._id = _chipid.toLowerCase();
        // [35]  CanClose = False 
        self._canclose = false;
        // [36]  Theme = chipTheme 
        self._theme = _chiptheme;
        // [37]  Element.Initialize(ID, {2} ) 
        self._element.initialize(self._id, "div");
        // [38]  Element.AddClass( {3} ) 
        self._element.addclass("chip");
        // [39]  WavesType = App.EnumWavesType.Light 
        self._wavestype = self._app._enumwavestype._light;
        // [40]  WavesCircle = False 
        self._wavescircle = false;
        // [41]  WavesEffect = True 
        self._waveseffect = true;
        // End Sub
    };

    // [45] Sub AddClass(sClass As String) As UOEChip 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [46]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [47]  Return Me 
        return self;
        // End Sub
    };

    // [51] Sub RemoveClass(sClass As String) As UOEChip 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [52]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [57] Sub AddAttribute(attr As String, value As String) As UOEChip 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [58]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [59]  Return Me 
        return self;
        // End Sub
    };

    // [63] Sub RemoveAttribute(attr As String) As UOEChip 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [64]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [65]  Return Me 
        return self;
        // End Sub
    };

    // [69] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [70]  Element.ID = ID 
        self._element._id = self._id;
        // [71]  If Theme = {4} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [76]  modUOE.MaterialAddImage(App,Element,ImageURL,ImageAlt, {5} , {6} ,False,True,True, {7} ) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, self._element, self._imageurl, self._imagealt, "", "", false, true, true, "");
        // [77]  Element.AddContent(Text) 
        self._element.addcontent(self._text);
        // [78]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [79]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [80]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [81]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [82]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [83]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [84]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [85]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [86]  If CanClose = True Then 
        if (self._canclose == true) {
            // [87]  modUOE.MaterialAddIcon(App,Element, {8} ,Theme, {9} ,False,True,True,False,CanClose) 
            _banano_uoebanano_moduoe.materialaddicon(self._app, self._element, "mdi-close", self._theme, "", false, true, true, false, self._canclose);
            // [88]  End If 
        }
        // [93]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEChips  ===========================
function banano_uoebanano_uoechips() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._visibility = '';

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._zdepth = '';

    this._enabled = false;

    this._initialwith = [];

    this._autocomplete = [];

    this._placeholder = '';

    this._secondaryplaceholder = '';

    this._onselect = '';

    this._ondelete = '';

    this._onadd = '';

    this._hoverable = false;

    this._instance = '';

    // [27] Sub AddStyleAttribute(attribute As String, value As String) As UOEChips 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [28]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [29]  Return Me 
        return self;
        // End Sub
    };

    // [33] Sub AddClass(sClass As String) As UOEChips 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [34]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [35]  Return Me 
        return self;
        // End Sub
    };

    // [39] Sub RemoveClass(sClass As String) As UOEChips 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [40]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [41]  Return Me 
        return self;
        // End Sub
    };

    // [45] Sub AddAttribute(attr As String, value As String) As UOEChips 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [46]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [47]  Return Me 
        return self;
        // End Sub
    };

    // [51] Sub RemoveAttribute(attr As String) As UOEChips 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [52]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [57] Public Sub Initialize(thisApp As UOEApp, chipID As String,themeName As String) 
    this.initialize = function (_thisapp, _chipid, _themename) {
        if (self == null) self = this;
        // [59]  App = thisApp 
        self._app = _thisapp;
        // [60]  InitialWith.Initialize 
        self._initialwith.length = 0;
        // [61]  InitialWith.clear 
        self._initialwith.length = 0;
        // [62]  AutoComplete.Initialize 
        self._autocomplete.length = 0;
        // [63]  AutoComplete.clear 
        self._autocomplete.length = 0;
        // [64]  PlaceHolder= {10} 
        self._placeholder = "";
        // [65]  SecondaryPlaceHolder= {11} 
        self._secondaryplaceholder = "";
        // [66]  OnSelect= {12} 
        self._onselect = "";
        // [67]  OnDelete= {13} 
        self._ondelete = "";
        // [68]  OnAdd= {14} 
        self._onadd = "";
        // [69]  Enabled = True 
        self._enabled = true;
        // [70]  ID = chipID.tolowercase 
        self._id = _chipid.toLowerCase();
        // [71]  Theme = themeName 
        self._theme = _themename;
        // [72]  Element.Initialize(ID, {15} ) 
        self._element.initialize(self._id, "div");
        // [73]  Element.AddClass( {16} ).AddClass( {17} ).AddClass( {18} ).AddClass( {19} ) 
        self._element.addclass("col").addclass("s12").addclass("m12").addclass("l12");
        // [74]  Element.AddClass( {20} ).AddClass( {21} ) 
        self._element.addclass("chips-initial").addclass("chips-placeholder");
        // [75]  Element.AddClass( {22} ).AddClass( {23} ) 
        self._element.addclass("chips-autocomplete").addclass("chips");
        // [76]  WavesType = App.EnumWavesType.Light 
        self._wavestype = self._app._enumwavestype._light;
        // [77]  WavesCircle = False 
        self._wavescircle = false;
        // [78]  WavesEffect = True 
        self._waveseffect = true;
        // [79]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [83] Sub AddInitialWith(sValue As String) As UOEChips 
    this.addinitialwith = function (_svalue) {
        if (self == null) self = this;
        // [84]  If sValue = {24} Then Return Me 
        if (_svalue == "") {
            return self;
        }
        // [85]  If InitialWith.IndexOf(sValue) = -1 Then InitialWith.Add(sValue) 
        if (self._initialwith.indexOf(_svalue) == -1) {
            self._initialwith.push(_svalue);
        }
        // [86]  Return Me 
        return self;
        // End Sub
    };

    // [90] Sub AddAutoComplete(sValue As String) As UOEChips 
    this.addautocomplete = function (_svalue) {
        if (self == null) self = this;
        // [91]  If sValue = {25} Then Return Me 
        if (_svalue == "") {
            return self;
        }
        // [92]  If AutoComplete.IndexOf(sValue) = -1 Then AutoComplete.Add(sValue) 
        if (self._autocomplete.indexOf(_svalue) == -1) {
            self._autocomplete.push(_svalue);
        }
        // [93]  Return Me 
        return self;
        // End Sub
    };

    // [118] Sub DeleteChip(idx As Int) As String 
    this.deletechip = function (_idx) {
        if (self == null) self = this;
        var _script;
        // [119]  Dim script As String = {3} 
        _script = "" + self._instance + ".deleteChip(" + _idx + ");";
        // [120]  Return script 
        return _script;
        // End Sub
    };

    // [124] Sub SelectChip(idx As Int) As String 
    this.selectchip = function (_idx) {
        if (self == null) self = this;
        var _script;
        // [125]  Dim script As String = {4} 
        _script = "" + self._instance + ".selectChip(" + _idx + ");";
        // [126]  Return script 
        return _script;
        // End Sub
    };

    // [150] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [151]  Element.ID = ID 
        self._element._id = self._id;
        // [152]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [153]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [154]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [155]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [156]  App.materialusetheme(ID,Element) 
        self._app.materialusetheme(self._id, self._element);
        // [157]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [158]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [159]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [181]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOECollapsible  ===========================
function banano_uoebanano_uoecollapsible() {
    var self;
    this._id = '';

    this._theme = '';

    this._element = new banano_uoebanano_uoehtml();

    this._app = new banano_uoebanano_uoeapp();

    this._visibility = '';

    this._headers = {};

    this._bodies = {};

    this._popout = false;

    this._nopadding = false;

    this._zdepth = '';

    this._enabled = false;

    this._hoverable = false;

    this._haschildren = {};

    this._normalize = false;

    this._lastheader = '';

    this._lastheadertitle = '';

    this._showarrows = false;

    this._links = {};

    this._itemnames = {};

    this._instance = '';

    // [28] Sub AddStyleAttribute(attribute As String, value As String) As UOECollapsible 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [29]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [30]  Return Me 
        return self;
        // End Sub
    };

    // [34] Sub AddClass(sClass As String) As UOECollapsible 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [35]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [36]  Return Me 
        return self;
        // End Sub
    };

    // [40] Sub BodyOf(sID As String) As String 
    this.bodyof = function (_sid) {
        if (self == null) self = this;
        // [41]  sID = sID.ToLowerCase 
        _sid = _sid.toLowerCase();
        // [42]  If Headers.ContainsKey(sID) Then 
        if ((_sid in self._headers)) {
            // [43]  Return sID & {3} 
            return _sid + "bdy";
            // [44]  Else 
        } else {
            // [45]  Return {4} 
            return "";
            // [46]  End If 
        }
        // End Sub
    };

    // [50] Sub AddHiddenHeaderTitle2Body() As UOECollapsible 
    this.addhiddenheadertitle2body = function () {
        if (self == null) self = this;
        var _ml;
        // [51]  If Headers.ContainsKey(LastHeader) Then 
        if ((self._lastheader in self._headers)) {
            // [52]  Dim ml As UOELabel 
            _ml = new banano_uoebanano_uoelabel();
            // [53]  ml.Initialize(App,LastHeader,App.EnumLabelSize.paragraph,LastHeaderTitle & {5} , {6} , {7} ) 
            _ml.initialize(self._app, self._lastheader, self._app._enumlabelsize._paragraph, self._lastheadertitle + ". ", "", "");
            // [54]  ml.Visibility = App.EnumVisibility.hide 
            _ml._visibility = self._app._enumvisibility._hide;
            // [55]  AddHeaderBody(LastHeader,ml.tostring) 
            self.addheaderbody(self._lastheader, _ml.tostring());
            // [56]  End If 
        }
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub RemoveClass(sClass As String) As UOECollapsible 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [71]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub AddAttribute(attr As String, value As String) As UOECollapsible 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [77]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [78]  Return Me 
        return self;
        // End Sub
    };

    // [82] Sub RemoveAttribute(attr As String) As UOECollapsible 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [83]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [84]  Return Me 
        return self;
        // End Sub
    };

    // [88] Public Sub Initialize(thisApp As UOEApp, itemID As String, itemType As String, bNoPadding As Boolean, themeName As String) 
    this.initialize = function (_thisapp, _itemid, _itemtype, _bnopadding, _themename) {
        if (self == null) self = this;
        // [89]  App = thisApp 
        self._app = _thisapp;
        // [90]  ID = itemID.tolowercase 
        self._id = _itemid.toLowerCase();
        // [91]  Theme = themeName 
        self._theme = _themename;
        // [92]  Enabled = True 
        self._enabled = true;
        // [93]  Element.Initialize(ID, {12} ) 
        self._element.initialize(self._id, "ul");
        // [94]  Element.AddClass( {13} ) 
        self._element.addclass("collapsible");
        // [95]  Element.AddAttribute( {14} ,itemType) 
        self._element.addattribute("data-collapsible", _itemtype);
        // [96]  Visibility = {15} 
        self._visibility = "";
        // [97]  Headers.Initialize 
        self._headers = {};
        // [98]  Headers.clear 
        self._headers = {};
        // [99]  Bodies.Initialize 
        self._bodies = {};
        // [100]  Bodies.clear 
        self._bodies = {};
        // [101]  PopOut = False 
        self._popout = false;
        // [102]  NoPadding = bNoPadding 
        self._nopadding = _bnopadding;
        // [103]  hasChildren.Initialize 
        self._haschildren = {};
        // [104]  hasChildren.clear 
        self._haschildren = {};
        // [105]  Normalize = False 
        self._normalize = false;
        // [106]  ShowArrows = True 
        self._showarrows = true;
        // [107]  Links.Initialize 
        self._links = {};
        // [108]  Links.clear 
        self._links = {};
        // [109]  ItemNames.Initialize 
        self._itemnames = {};
        // [110]  ItemNames.clear 
        self._itemnames = {};
        // [111]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [115] Sub Open(idx As Int) 
    this.open = function (_idx) {
        if (self == null) self = this;
        var _script;
        // [116]  Dim script As String = {1} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Collapsible.getInstance(inst" + self._id + "); \n	" + self._instance + ".open(" + _idx + ");";
        // [117]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [121] Sub Close(idx As Int) 
    this.close = function (_idx) {
        if (self == null) self = this;
        var _script;
        // [122]  Dim script As String = {2} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Collapsible.getInstance(inst" + self._id + "); \n	" + self._instance + ".close(" + _idx + ");";
        // [123]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [127] Sub AddHeaderSimple(itemID As String, itemIcon As String, itemText As String,itemTheme As String, iconTheme As String, hasDivider As Boolean) 
    this.addheadersimple = function (_itemid, _itemicon, _itemtext, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [128]  AddHeader(itemID,itemIcon,itemText, {16} ,False, {17} ,itemTheme,iconTheme,hasDivider) 
        self.addheader(_itemid, _itemicon, _itemtext, "", false, "", _itemtheme, _icontheme, _hasdivider);
        // End Sub
    };

    // [132] Sub AddItemSimple(itemID As String, itemIcon As String, itemText As String,itemGoTo As String,itemTheme As String,iconTheme As String,hasDivider As Boolean) 
    this.additemsimple = function (_itemid, _itemicon, _itemtext, _itemgoto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [133]  AddItem(itemID,itemIcon,itemText, {18} ,False,itemGoTo,itemTheme,iconTheme,hasDivider) 
        self.additem(_itemid, _itemicon, _itemtext, "", false, _itemgoto, _itemtheme, _icontheme, _hasdivider);
        // End Sub
    };

    // [137] Sub AddHeader(itemID As String, itemIcon As String, itemText As String, itemBadge As String, badgeNew As Boolean, itemNavigateTo As String, itemTheme As String, iconTheme As String,hasDivider As Boolean) 
    this.addheader = function (_itemid, _itemicon, _itemtext, _itembadge, _badgenew, _itemnavigateto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        var _div;
        var _spn;
        var _md;
        var _sout;
        var _lst;
        var _lst1;
        var _lst2;
        // [138]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [139]  hasChildren.Put(itemID,False) 
        self._haschildren[_itemid] = false;
        // [141]  Dim div As UOEAnchor 
        _div = new banano_uoebanano_uoeanchor();
        // [142]  div.Initialize(App,itemID) 
        _div.initialize(self._app, _itemid);
        // [143]  div.element.MaterialCollapsibleHeader(True) 
        _div._element.materialcollapsibleheader(true);
        // [144]  div.IsDiv = Normalize 
        _div._isdiv = self._normalize;
        // [145]  modUOE.materialAddIcon(App,div.Element,itemIcon, {19} ,iconTheme,False,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, _div._element, _itemicon, "", _icontheme, false, false, false, false, false);
        // [148]  Dim spn As UOEHTML 
        _spn = new banano_uoebanano_uoehtml();
        // [149]  spn.Initialize(itemID & {20} , {21} ) 
        _spn.initialize(_itemid + "-span", "span");
        // [150]  spn.AddContent(itemText) 
        _spn.addcontent(_itemtext);
        // [151]  div.Element.AddElement(spn) 
        _div._element.addelement(_spn);
        // [153]  modUOE.MaterialAddBadge(App,div.Element,itemBadge,badgeNew,App.EnumVisibility.visible,True, {22} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _div._element, _itembadge, _badgenew, self._app._enumvisibility._visible, true, "", false);
        // [154]  If ShowArrows Then 
        if (self._showarrows) {
            // [155]  modUOE.MaterialAddIcon(App,div.element, {23} , {24} , {25} ,False,False,False,False,False) 
            _banano_uoebanano_moduoe.materialaddicon(self._app, _div._element, "mdi-keyboard_arrow_right", "right", "", false, false, false, false, false);
            // [156]  End If 
        }
        // [157]  div.WavesEffect = True 
        _div._waveseffect = true;
        // [158]  div.WavesType = App.EnumWavesType.Light 
        _div._wavestype = self._app._enumwavestype._light;
        // [159]  div.TextVisible = True 
        _div._textvisible = true;
        // [160]  div.Theme = itemTheme 
        _div._theme = _itemtheme;
        // [161]  div.href = itemNavigateTo 
        _div._href = _itemnavigateto;
        // [162]  If hasDivider = True Then 
        if (_hasdivider == true) {
            // [163]  Dim md As UOEDivider 
            _md = new banano_uoebanano_uoedivider();
            // [164]  md.Initialize(App, {26} , {27} ) 
            _md.initialize(self._app, "", "");
            // [165]  Dim sout As String = div.tostring & md.tostring 
            _sout = _div.tostring(+_md.tostring());
            // [166]  Headers.Put(itemID,sout) 
            self._headers[_itemid] = _sout;
            // [167]  Else 
        } else {
            // [169]  Headers.Put(itemID,div.tostring) 
            self._headers[_itemid] = _div.tostring();
            // [170]  End If 
        }
        // [171]  Dim lst As List 
        _lst = [];
        // [172]  lst.Initialize 
        _lst.length = 0;
        // [173]  lst.clear 
        _lst.length = 0;
        // [174]  Dim lst1 As List 
        _lst1 = [];
        // [175]  lst1.Initialize 
        _lst1.length = 0;
        // [176]  lst1.clear 
        _lst1.length = 0;
        // [177]  Dim lst2 As List 
        _lst2 = [];
        // [178]  lst2.Initialize 
        _lst2.length = 0;
        // [179]  lst2.clear 
        _lst2.length = 0;
        // [180]  Bodies.Put(itemID,lst) 
        self._bodies[_itemid] = _lst;
        // [181]  Links.Put(itemID,lst1) 
        self._links[_itemid] = _lst1;
        // [182]  ItemNames.Put(itemID,lst2) 
        self._itemnames[_itemid] = _lst2;
        // [183]  LastHeader = itemID 
        self._lastheader = _itemid;
        // [184]  LastHeaderTitle = itemText 
        self._lastheadertitle = _itemtext;
        // [185]  App.AddEvent(itemID, {28} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [189] Sub AddItem(itemID As String, itemIcon As String, itemText As String, itemBadge As String, badgeNew As Boolean, itemNavigateTo As String, itemTheme As String, iconTheme As String,hasDivider As Boolean) 
    this.additem = function (_itemid, _itemicon, _itemtext, _itembadge, _badgenew, _itemnavigateto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        var _div;
        var _md;
        var _sout;
        var _lst1;
        var _lst2;
        // [190]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [191]  hasChildren.Put(itemID,False) 
        self._haschildren[_itemid] = false;
        // [193]  Dim div As UOEAnchor 
        _div = new banano_uoebanano_uoeanchor();
        // [194]  div.Initialize(App,itemID) 
        _div.initialize(self._app, _itemid);
        // [195]  div.IsDiv = Normalize 
        _div._isdiv = self._normalize;
        // [196]  div.element.MaterialCollapsibleHeader(True) 
        _div._element.materialcollapsibleheader(true);
        // [197]  modUOE.materialAddIcon(App,div.Element,itemIcon, {29} ,iconTheme,False,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, _div._element, _itemicon, "", _icontheme, false, false, false, false, false);
        // [198]  div.Element.AddContent(itemText) 
        _div._element.addcontent(_itemtext);
        // [199]  modUOE.MaterialAddBadge(App,div.Element,itemBadge,badgeNew,App.EnumVisibility.visible,True, {30} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _div._element, _itembadge, _badgenew, self._app._enumvisibility._visible, true, "", false);
        // [200]  div.WavesEffect = True 
        _div._waveseffect = true;
        // [201]  div.WavesType = App.EnumWavesType.Light 
        _div._wavestype = self._app._enumwavestype._light;
        // [202]  div.TextVisible = True 
        _div._textvisible = true;
        // [203]  div.Theme = itemTheme 
        _div._theme = _itemtheme;
        // [204]  div.href = itemNavigateTo 
        _div._href = _itemnavigateto;
        // [205]  If hasDivider = True Then 
        if (_hasdivider == true) {
            // [206]  Dim md As UOEDivider 
            _md = new banano_uoebanano_uoedivider();
            // [207]  md.Initialize(App, {31} , {32} ) 
            _md.initialize(self._app, "", "");
            // [208]  Dim sout As String = div.tostring & md.tostring 
            _sout = _div.tostring(+_md.tostring());
            // [209]  Headers.Put(itemID,sout) 
            self._headers[_itemid] = _sout;
            // [210]  Else 
        } else {
            // [212]  Headers.Put(itemID,div.tostring) 
            self._headers[_itemid] = _div.tostring();
            // [213]  End If 
        }
        // [215]  If Links.ContainsKey(itemID) And itemNavigateTo.Length > 0 Then 
        if ((_itemid in self._links) && _itemnavigateto.length > 0) {
            // [216]  Dim lst1 As List 
            _lst1 = [];
            // [217]  lst1 = Links.Get(itemID) 
            _lst1 = self._links[_itemid];
            // [218]  lst1.Add(itemNavigateTo) 
            _lst1.push(_itemnavigateto);
            // [219]  Links.Put(itemID,lst1) 
            self._links[_itemid] = _lst1;
            // [220]  Dim lst2 As List 
            _lst2 = [];
            // [221]  lst2 = ItemNames.Get(itemID) 
            _lst2 = self._itemnames[_itemid];
            // [222]  lst2.Add(itemText) 
            _lst2.push(_itemtext);
            // [223]  ItemNames.Put(itemID,lst2) 
            self._itemnames[_itemid] = _lst2;
            // [224]  End If 
        }
        // [225]  App.AddEvent(itemID, {33} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [229] Sub AddHeaderItemSimple(parentID As String,itemID As String,itemIcon As String,itemText As String,itemGoto As String,itemTheme As String,iconTheme As String,hasDivider As Boolean) 
    this.addheaderitemsimple = function (_parentid, _itemid, _itemicon, _itemtext, _itemgoto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [230]  AddHeaderItem(parentID,itemID,itemIcon,itemText,itemGoto, {34} ,False,hasDivider,itemTheme,iconTheme) 
        self.addheaderitem(_parentid, _itemid, _itemicon, _itemtext, _itemgoto, "", false, _hasdivider, _itemtheme, _icontheme);
        // End Sub
    };

    // [234] Sub AddHeaderItem(parentID As String, itemID As String, iconName As String, itemText As String, itemNavigateTo As String, itemBadge As String, badgeNew As Boolean, bHasDivider As Boolean, itemTheme As String, iconTheme As String) 
    this.addheaderitem = function (_parentid, _itemid, _iconname, _itemtext, _itemnavigateto, _itembadge, _badgenew, _bhasdivider, _itemtheme, _icontheme) {
        if (self == null) self = this;
        var _div;
        var _li;
        var _hdr;
        var _div1;
        var _divx;
        var _divider;
        var _lst;
        var _lst1;
        var _lst2;
        // [235]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [236]  parentID = parentID.tolowercase 
        _parentid = _parentid.toLowerCase();
        // [237]  hasChildren.Put(parentID,True) 
        self._haschildren[_parentid] = true;
        // [238]  If Headers.ContainsKey(parentID) = False Then 
        if ((_parentid in self._headers) == false) {
            // [239]  Log(parentID & {35} ) 
            console.log(_parentid + " header does not exist on sidebar");
            // [240]  Return 
            return;
            // [241]  End If 
        }
        // [243]  Dim div As UOEAnchor 
        _div = new banano_uoebanano_uoeanchor();
        // [244]  div.Initialize(App,itemID) 
        _div.initialize(self._app, _itemid);
        // [245]  div.IsDiv = Normalize 
        _div._isdiv = self._normalize;
        // [246]  modUOE.MaterialAddBadge(App,div.Element,itemBadge,badgeNew,App.EnumVisibility.visible,True, {36} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _div._element, _itembadge, _badgenew, self._app._enumvisibility._visible, true, "", false);
        // [247]  modUOE.MaterialAddIcon(App,div.Element,iconName, {37} ,iconTheme,False,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, _div._element, _iconname, "", _icontheme, false, false, false, false, false);
        // [248]  div.WavesEffect = True 
        _div._waveseffect = true;
        // [249]  div.WavesType = App.EnumWavesType.Light 
        _div._wavestype = self._app._enumwavestype._light;
        // [250]  div.TextVisible = True 
        _div._textvisible = true;
        // [251]  div.Theme = itemTheme 
        _div._theme = _itemtheme;
        // [252]  div.Text = itemText 
        _div._text = _itemtext;
        // [253]  div.href = itemNavigateTo 
        _div._href = _itemnavigateto;
        // [254]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [255]  li.Initialize( {38} , {39} ) 
        _li.initialize("", "li");
        // [256]  li.AddContent(div.tostring) 
        _li.addcontent(_div.tostring());
        // [257]  Dim hdr As String = li.html 
        _hdr = _li.html();
        // [258]  If bHasDivider = True Then 
        if (_bhasdivider == true) {
            // [259]  Dim div1 As UOEHTML 
            _div1 = new banano_uoebanano_uoehtml();
            // [260]  div1.Initialize( {40} , {41} ) 
            _div1.initialize("", "li");
            // [262]  Dim divx As UOEHTML 
            _divx = new banano_uoebanano_uoehtml();
            // [263]  divx.Initialize( {42} , {43} ) 
            _divx.initialize("", "div");
            // [264]  divx.AddClass( {44} ) 
            _divx.addclass("divider");
            // [265]  div1.AddElement(divx) 
            _div1.addelement(_divx);
            // [267]  Dim divider As UOEDivider 
            _divider = new banano_uoebanano_uoedivider();
            // [268]  divider.Initialize(App, {45} ,itemTheme) 
            _divider.initialize(self._app, "", _itemtheme);
            // [269]  hdr = hdr & divider.tostring 
            _hdr = _hdr + _divider.tostring();
            // [270]  End If 
        }
        // [271]  If Headers.ContainsKey(parentID) Then 
        if ((_parentid in self._headers)) {
            // [272]  Dim lst As List = Bodies.Get(parentID) 
            _lst = self._bodies[_parentid];
            // [273]  lst.Add(hdr) 
            _lst.push(_hdr);
            // [274]  Bodies.Put(parentID,lst) 
            self._bodies[_parentid] = _lst;
            // [275]  End If 
        }
        // [277]  If Links.ContainsKey(parentID) And itemNavigateTo.Length > 0 Then 
        if ((_parentid in self._links) && _itemnavigateto.length > 0) {
            // [278]  Dim lst1 As List 
            _lst1 = [];
            // [279]  lst1 = Links.Get(parentID) 
            _lst1 = self._links[_parentid];
            // [280]  lst1.Add(itemNavigateTo) 
            _lst1.push(_itemnavigateto);
            // [281]  Links.Put(parentID,lst1) 
            self._links[_parentid] = _lst1;
            // [282]  Dim lst2 As List 
            _lst2 = [];
            // [283]  lst2 = ItemNames.Get(parentID) 
            _lst2 = self._itemnames[_parentid];
            // [284]  lst2.Add(itemText) 
            _lst2.push(_itemtext);
            // [285]  ItemNames.Put(parentID,lst2) 
            self._itemnames[_parentid] = _lst2;
            // [286]  End If 
        }
        // [287]  App.AddEvent(itemID, {46} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [291] Sub AddHeaderBody(itemID As String, itemBody As String) 
    this.addheaderbody = function (_itemid, _itembody) {
        if (self == null) self = this;
        var _lst;
        // [292]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [293]  If Headers.ContainsKey(itemID) Then 
        if ((_itemid in self._headers)) {
            // [294]  Dim lst As List = Bodies.Get(itemID) 
            _lst = self._bodies[_itemid];
            // [295]  lst.Add(itemBody) 
            _lst.push(_itembody);
            // [296]  Bodies.Put(itemID,lst) 
            self._bodies[_itemid] = _lst;
            // [297]  End If 
        }
        // End Sub
    };

    // [301] Sub AddHeaderContainer(itemID As String, cont As UOEContainer) 
    this.addheadercontainer = function (_itemid, _cont) {
        if (self == null) self = this;
        var _lst;
        // [302]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [303]  If Headers.ContainsKey(itemID) Then 
        if ((_itemid in self._headers)) {
            // [304]  Dim lst As List = Bodies.Get(itemID) 
            _lst = self._bodies[_itemid];
            // [305]  lst.Add(cont.tostring) 
            _lst.push(_cont.tostring());
            // [306]  Bodies.Put(itemID,lst) 
            self._bodies[_itemid] = _lst;
            // [307]  End If 
        }
        // End Sub
    };

    // [311] private Sub GetStructure As String 
    this.getstructure = function () {
        if (self == null) self = this;
        var _sb;
        var _ktot;
        var _kcnt;
        var _drpitem;
        var _hdr;
        var _li;
        var _div;
        var _bhaschildren;
        var _ul;
        var _lstx;
        // [312]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [313]  sb.Initialize 
        _sb.isinitialized = true;
        // [314]  Dim kTot As Int = Headers.Size - 1 
        _ktot = Object.keys(self._headers).length - 1;
        // [315]  Dim kCnt As Int 
        _kcnt = 0;
        // [316]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [317]  Dim drpItem As String = Headers.GetKeyAt(kCnt) 
            _drpitem = banano_getB4JKeyAt(self._headers, _kcnt);
            // [318]  Dim hdr As String = Headers.GetDefault(drpItem, {47} ) 
            _hdr = (self._headers[_drpitem] || "");
            // [320]  Dim li As UOEHTML 
            _li = new banano_uoebanano_uoehtml();
            // [321]  li.Initialize(drpItem & {48} , {49} ) 
            _li.initialize(_drpitem + "hdr", "li");
            // [322]  li.AddContent(hdr) 
            _li.addcontent(_hdr);
            // [324]  Dim div As UOEHTML 
            _div = new banano_uoebanano_uoehtml();
            // [325]  div.Initialize(drpItem & {50} , {51} ) 
            _div.initialize(_drpitem + "bdy", "div");
            // [326]  div.AddClass( {52} ) 
            _div.addclass("collapsible-body");
            // [327]  Dim bHasChildren As Boolean = hasChildren.Get(drpItem) 
            _bhaschildren = self._haschildren[_drpitem];
            // [328]  If bHasChildren Then 
            if (_bhaschildren) {
                // [329]  Dim ul As UOEHTML 
                _ul = new banano_uoebanano_uoehtml();
                // [330]  ul.Initialize( {53} , {54} ) 
                _ul.initialize("", "ul");
                // [331]  Dim lstx As List = Bodies.Get(drpItem) 
                _lstx = self._bodies[_drpitem];
                // [332]  ul.AddContentList(lstx) 
                _ul.addcontentlist(_lstx);
                // [333]  div.AddContent(ul.HTML) 
                _div.addcontent(_ul.html());
                // [334]  li.AddContent(div.HTML) 
                _li.addcontent(_div.html());
                // [335]  Else 
            } else {
                // [336]  If Bodies.ContainsKey(drpItem) Then 
                if ((_drpitem in self._bodies)) {
                    // [337]  Dim lstx As List = Bodies.Get(drpItem) 
                    _lstx = self._bodies[_drpitem];
                    // [338]  div.AddContentList(lstx) 
                    _div.addcontentlist(_lstx);
                    // [339]  li.AddContent(div.HTML) 
                    _li.addcontent(_div.html());
                    // [340]  End If 
                }
                // [341]  End If 
            }
            // [342]  sb.Append(li.HTML) 
            _sb.append(_li.html());
            // [343]  Next 
        }
        // [344]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [348] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _lim;
        // [349]  Element.AddClassOnCondition(PopOut, {55} ) 
        self._element.addclassoncondition(self._popout, "popout");
        // [350]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [351]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [352]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [353]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [354]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [356]  Element.AddContent(GetStructure) 
        self._element.addcontent(self.getstructure());
        // [361]  If NoPadding = True Then 
        if (self._nopadding == true) {
            // [362]  Dim lim As UOEHTML 
            _lim = new banano_uoebanano_uoehtml();
            // [363]  lim.Initialize( {58} , {59} ) 
            _lim.initialize("", "li");
            // [364]  lim.AddClass( {60} ) 
            _lim.addclass("no-padding");
            // [365]  lim.AddContent(Element.HTML) 
            _lim.addcontent(self._element.html());
            // [366]  Return lim.html 
            return _lim.html();
            // [367]  Else 
        } else {
            // [368]  Return Element.html 
            return self._element.html();
            // [369]  End If 
        }
        // End Sub
    };

}
// =========================== UOEContainer  ===========================
function banano_uoebanano_uoecontainer() {
    var self;
    this._id = '';

    this._element = new banano_uoebanano_uoehtml();

    this._items = [];

    this._enabled = false;

    this._theme = '';

    this._visibility = '';

    this._zdepth = '';

    this._grid = new banano_uoebanano_uoegrid();

    this._hoverable = false;

    this._centerinpage = false;

    this._scrollspy = false;

    this._section = false;

    this._app = new banano_uoebanano_uoeapp();

    this._divcounter = 0;

    this._j = '';

    // [24] Sub RemoveComponent(elID As String) 
    this.removecomponent = function (_elid) {
        if (self == null) self = this;
        // End Sub
    };

    // [40] Sub ReplaceRC(row As Int, col As Int, elHTML As String) 
    this.replacerc = function (_row, _col, _elhtml) {
        if (self == null) self = this;
        // [41]  Grid.ReplaceRC(row, col, elHTML) 
        self._grid.replacerc(_row, _col, _elhtml);
        // End Sub
    };

    // [45] Sub AddTable(row As Int, column As Int, tblTable As UOETable) 
    this.addtable = function (_row, _column, _tbltable) {
        if (self == null) self = this;
        // [46]  RemoveComponent(tblTable.ID) 
        self.removecomponent(_tbltable._id);
        // [47]  AddComponent(row,column,tblTable.tostring) 
        self.addcomponent(_row, _column, _tbltable.tostring());
        // End Sub
    };

    // [51] Sub AddRadioGroup(row As Int, col As Int, rg As UOERadioGroup) 
    this.addradiogroup = function (_row, _col, _rg) {
        if (self == null) self = this;
        // [52]  RemoveComponent(rg.ID) 
        self.removecomponent(_rg._id);
        // [53]  AddComponent(row,col, rg.ToString) 
        self.addcomponent(_row, _col, _rg.tostring());
        // End Sub
    };

    // [57] Sub AddPreloader(row As Int, col As Int, prl As UOEPreloader) 
    this.addpreloader = function (_row, _col, _prl) {
        if (self == null) self = this;
        // [58]  RemoveComponent(prl.ID) 
        self.removecomponent(_prl._id);
        // [59]  AddComponent(row,col,prl.tostring) 
        self.addcomponent(_row, _col, _prl.tostring());
        // End Sub
    };

    // [63] Sub AddModal(mdl As UOEModal) 
    this.addmodal = function (_mdl) {
        if (self == null) self = this;
        var _mdls;
        var _cssset;
        // [64]  RemoveComponent(mdl.ID) 
        self.removecomponent(_mdl._id);
        // [65]  Dim mdls As String = mdl.getSettings 
        _mdls = _mdl.getsettings();
        // [66]  App.Components.add(mdls) 
        self._app._components.push(_mdls);
        // [68]  If mdl.HideScrollBar Then 
        if (_mdl._hidescrollbar) {
            // [69]  Dim cssset As String = mdl.getCSS 
            _cssset = _mdl.getcss();
            // [70]  App.CSS.Add(cssset) 
            self._app._css.push(_cssset);
            // [71]  End If 
        }
        // [72]  AddComponent(0,0,mdl.ToString) 
        self.addcomponent(0, 0, _mdl.tostring());
        // End Sub
    };

    // [76] Sub AddList(row As Int, col As Int, lst As UOEList) 
    this.addlist = function (_row, _col, _lst) {
        if (self == null) self = this;
        // [77]  RemoveComponent(lst.ID) 
        self.removecomponent(_lst._id);
        // [78]  AddComponent(row,col,lst.ToString) 
        self.addcomponent(_row, _col, _lst.tostring());
        // End Sub
    };

    // [82] Sub AddRangeSlider1(row As Int, column As Int, cID As String, cTitle As String, cStart As Float, cStop As Float,cMin As Float, cMax As Float, cStep As Float, cConnect As Boolean, cTheme As String, cClass As String) 
    this.addrangeslider1 = function (_row, _column, _cid, _ctitle, _cstart, _cstop, _cmin, _cmax, _cstep, _cconnect, _ctheme, _cclass) {
        if (self == null) self = this;
        var _rangeslider;
        // [83]  Dim rangeslider As UOERangeSlider 
        _rangeslider = new banano_uoebanano_uoerangeslider();
        // [84]  rangeslider.Initialize(App,cID,cTitle,cStart,cStop,cMin,cMax,cStep,False,cTheme) 
        _rangeslider.initialize(self._app, _cid, _ctitle, _cstart, _cstop, _cmin, _cmax, _cstep, false, _ctheme);
        // [85]  rangeslider.AddClass(cClass) 
        _rangeslider.addclass(_cclass);
        // [86]  AddRangeSlider(row,column,rangeslider) 
        self.addrangeslider(_row, _column, _rangeslider);
        // End Sub
    };

    // [90] Sub AddRangeSlider(row As Int, column As Int, rangeslider As UOERangeSlider) 
    this.addrangeslider = function (_row, _column, _rangeslider) {
        if (self == null) self = this;
        var _rs;
        // [91]  RemoveComponent(rangeslider.ID) 
        self.removecomponent(_rangeslider._id);
        // [92]  Dim rs As String = rangeslider.getSettings 
        _rs = _rangeslider.getsettings();
        // [93]  App.JS.Add(rs) 
        self._app._js.push(_rs);
        // [94]  AddComponent(row,column,rangeslider.tostring) 
        self.addcomponent(_row, _column, _rangeslider.tostring());
        // End Sub
    };

    // [98] Sub AddRange(row As Int, column As Int, range As UOERange) 
    this.addrange = function (_row, _column, _range) {
        if (self == null) self = this;
        // [99]  RemoveComponent(range.ID) 
        self.removecomponent(_range._id);
        // [100]  AddComponent(row,column,range.tostring) 
        self.addcomponent(_row, _column, _range.tostring());
        // End Sub
    };

    // [104] Sub AddProgress(row As Int, column As Int, progress As UOEProgress) 
    this.addprogress = function (_row, _column, _progress) {
        if (self == null) self = this;
        // [105]  RemoveComponent(progress.ID) 
        self.removecomponent(_progress._id);
        // [106]  AddComponent(row,column,progress.tostring) 
        self.addcomponent(_row, _column, _progress.tostring());
        // End Sub
    };

    // [110] Sub AddProgress1(row As Int, column As Int, cID As String, bDeterminate As Boolean, cPercentage As Int, cTheme As String, cClass As String) 
    this.addprogress1 = function (_row, _column, _cid, _bdeterminate, _cpercentage, _ctheme, _cclass) {
        if (self == null) self = this;
        var _prg;
        // [111]  Dim prg As UOEProgress 
        _prg = new banano_uoebanano_uoeprogress();
        // [112]  prg.Initialize(App,cID,bDeterminate,cTheme) 
        _prg.initialize(self._app, _cid, _bdeterminate, _ctheme);
        // [113]  prg.Percentage = cPercentage 
        _prg._percentage = _cpercentage;
        // [114]  prg.AddClass(cClass) 
        _prg.addclass(_cclass);
        // [115]  AddProgress(row,column,prg) 
        self.addprogress(_row, _column, _prg);
        // End Sub
    };

    // [119] Sub AddPagination(row As Int, column As Int, pagination As UOEPagination) 
    this.addpagination = function (_row, _column, _pagination) {
        if (self == null) self = this;
        // [120]  RemoveComponent(pagination.ID) 
        self.removecomponent(_pagination._id);
        // [121]  AddComponent(row,column,pagination.tostring) 
        self.addcomponent(_row, _column, _pagination.tostring());
        // End Sub
    };

    // [125] Sub AddPagination1(row As Int, column As Int, cID As String, cActive As Int, cPages As Int, cTheme As String, cClass As String) 
    this.addpagination1 = function (_row, _column, _cid, _cactive, _cpages, _ctheme, _cclass) {
        if (self == null) self = this;
        var _tbl;
        // [126]  Dim tbl As UOEPagination 
        _tbl = new banano_uoebanano_uoepagination();
        // [127]  tbl.Initialize(App,cID,cPages,cTheme,cClass) 
        _tbl.initialize(self._app, _cid, _cpages, _ctheme, _cclass);
        // [128]  tbl.ActivePageNumber = cActive 
        _tbl._activepagenumber = _cactive;
        // [129]  AddPagination(row,column,tbl) 
        self.addpagination(_row, _column, _tbl);
        // End Sub
    };

    // [134] Sub AddTextArea(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cPlaceHolder As String, cHelperText As String, cLength As Int, cTheme As String, cClass As String) 
    this.addtextarea = function (_row, _column, _cid, _ciconname, _ctitle, _cplaceholder, _chelpertext, _clength, _ctheme, _cclass) {
        if (self == null) self = this;
        var _inp;
        // [135]  Dim inp As UOEInput 
        _inp = new banano_uoebanano_uoeinput();
        // [136]  inp.Initialize(App,cID,cTitle,cPlaceHolder,App.EnumInputType.textarea,cTheme) 
        _inp.initialize(self._app, _cid, _ctitle, _cplaceholder, self._app._enuminputtype._textarea, _ctheme);
        // [137]  inp.HelperText = cHelperText 
        _inp._helpertext = _chelpertext;
        // [138]  inp.IconName = cIconName 
        _inp._iconname = _ciconname;
        // [139]  inp.MaxLength = cLength 
        _inp._maxlength = _clength;
        // [140]  inp.AddClass(cClass) 
        _inp.addclass(_cclass);
        // [141]  AddInput(row,column,inp) 
        self.addinput(_row, _column, _inp);
        // End Sub
    };

    // [146] Sub AddTelephone(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cPlaceHolder As String, cHelperText As String, cLength As Int, cTheme As String, cClass As String) 
    this.addtelephone = function (_row, _column, _cid, _ciconname, _ctitle, _cplaceholder, _chelpertext, _clength, _ctheme, _cclass) {
        if (self == null) self = this;
        var _inp;
        // [147]  Dim inp As UOEInput 
        _inp = new banano_uoebanano_uoeinput();
        // [148]  inp.Initialize(App,cID,cTitle,cPlaceHolder,App.EnumInputType.Tel,cTheme) 
        _inp.initialize(self._app, _cid, _ctitle, _cplaceholder, self._app._enuminputtype._tel, _ctheme);
        // [149]  inp.HelperText = cHelperText 
        _inp._helpertext = _chelpertext;
        // [150]  inp.IconName = cIconName 
        _inp._iconname = _ciconname;
        // [151]  inp.MaxLength = cLength 
        _inp._maxlength = _clength;
        // [152]  inp.AddClass(cClass) 
        _inp.addclass(_cclass);
        // [153]  AddInput(row,column,inp) 
        self.addinput(_row, _column, _inp);
        // End Sub
    };

    // [158] Sub AddEmail(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cPlaceHolder As String, cHelperText As String, cLength As Int,cTheme As String, cClass As String) 
    this.addemail = function (_row, _column, _cid, _ciconname, _ctitle, _cplaceholder, _chelpertext, _clength, _ctheme, _cclass) {
        if (self == null) self = this;
        var _inp;
        // [159]  Dim inp As UOEInput 
        _inp = new banano_uoebanano_uoeinput();
        // [160]  inp.Initialize(App,cID,cTitle,cPlaceHolder,App.EnumInputType.email,cTheme) 
        _inp.initialize(self._app, _cid, _ctitle, _cplaceholder, self._app._enuminputtype._email, _ctheme);
        // [161]  inp.HelperText = cHelperText 
        _inp._helpertext = _chelpertext;
        // [162]  inp.IconName = cIconName 
        _inp._iconname = _ciconname;
        // [163]  inp.MaxLength = cLength 
        _inp._maxlength = _clength;
        // [164]  inp.AddClass(cClass) 
        _inp.addclass(_cclass);
        // [165]  AddInput(row,column,inp) 
        self.addinput(_row, _column, _inp);
        // End Sub
    };

    // [170] Sub AddTextBox(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cPlaceHolder As String, cHelperText As String, cLength As Int, cTheme As String, cClass As String) 
    this.addtextbox = function (_row, _column, _cid, _ciconname, _ctitle, _cplaceholder, _chelpertext, _clength, _ctheme, _cclass) {
        if (self == null) self = this;
        var _inp;
        // [171]  Dim inp As UOEInput 
        _inp = new banano_uoebanano_uoeinput();
        // [172]  inp.Initialize(App,cID,cTitle,cPlaceHolder,App.EnumInputType.text,cTheme) 
        _inp.initialize(self._app, _cid, _ctitle, _cplaceholder, self._app._enuminputtype._text, _ctheme);
        // [173]  inp.HelperText = cHelperText 
        _inp._helpertext = _chelpertext;
        // [174]  inp.IconName = cIconName 
        _inp._iconname = _ciconname;
        // [175]  inp.MaxLength = cLength 
        _inp._maxlength = _clength;
        // [176]  inp.AddClass(cClass) 
        _inp.addclass(_cclass);
        // [177]  AddInput(row,column,inp) 
        self.addinput(_row, _column, _inp);
        // End Sub
    };

    // [181] Sub AddIcon1(row As Int, column As Int, cID As String, cIconName As String, cIconSize As String, cTheme As String, cClass As String) 
    this.addicon1 = function (_row, _column, _cid, _ciconname, _ciconsize, _ctheme, _cclass) {
        if (self == null) self = this;
        var _icon;
        // [182]  Dim icon As UOEIcon 
        _icon = new banano_uoebanano_uoeicon();
        // [183]  icon.Initialize(App,cID,cIconName,cTheme) 
        _icon.initialize(self._app, _cid, _ciconname, _ctheme);
        // [184]  icon.IconSize = cIconSize 
        _icon._iconsize = _ciconsize;
        // [185]  icon.AddClass(cClass) 
        _icon.addclass(_cclass);
        // [186]  AddIcon(row,column,icon) 
        self.addicon(_row, _column, _icon);
        // End Sub
    };

    // [190] Sub AddHTML5Video1(row As Int, column As Int, cID As String, cURL As String, bAutoPlay As Boolean, bAllowFullScreen As Boolean, bShowControls As Boolean, bLoop As Boolean, sVideoType As String, cClass As String) 
    this.addhtml5video1 = function (_row, _column, _cid, _curl, _bautoplay, _ballowfullscreen, _bshowcontrols, _bloop, _svideotype, _cclass) {
        if (self == null) self = this;
        var _vid1;
        // [191]  Dim vid1 As UOEHTML5Video 
        _vid1 = new banano_uoebanano_uoehtml5video();
        // [192]  vid1.Initialize(App,cID, cURL) 
        _vid1.initialize(self._app, _cid, _curl);
        // [193]  vid1.AddClass(cClass) 
        _vid1.addclass(_cclass);
        // [194]  vid1.AutoPlay = bAutoPlay 
        _vid1._autoplay = _bautoplay;
        // [195]  vid1.AllowFullScreen = bAllowFullScreen 
        _vid1._allowfullscreen = _ballowfullscreen;
        // [196]  vid1.VideoType = sVideoType 
        _vid1._videotype = _svideotype;
        // [197]  vid1.ShowControls = bShowControls 
        _vid1._showcontrols = _bshowcontrols;
        // [198]  vid1.LoopIT = bLoop 
        _vid1._loopit = _bloop;
        // [199]  vid1.Responsive = True 
        _vid1._responsive = true;
        // [200]  AddHTML5Video(row,column,vid1) 
        self.addhtml5video(_row, _column, _vid1);
        // End Sub
    };

    // [204] Sub AddFile1(row As Int, column As Int, cID As String, cTitle As String, cPlaceHolder As String, cHelperText As String, bMultiple As Boolean, bHideInput As Boolean, bFitWidth As Boolean, cTheme As String, cClass As String) 
    this.addfile1 = function (_row, _column, _cid, _ctitle, _cplaceholder, _chelpertext, _bmultiple, _bhideinput, _bfitwidth, _ctheme, _cclass) {
        if (self == null) self = this;
        var _fu;
        // [205]  Dim fu As UOEFile 
        _fu = new banano_uoebanano_uoefile();
        // [206]  fu.Initialize(App,cID,cTitle,cPlaceHolder,bMultiple,cTheme) 
        _fu.initialize(self._app, _cid, _ctitle, _cplaceholder, _bmultiple, _ctheme);
        // [207]  fu.HelperText = cHelperText 
        _fu._helpertext = _chelpertext;
        // [208]  fu.AddClass(cClass) 
        _fu.addclass(_cclass);
        // [209]  fu.HideInput = bHideInput 
        _fu._hideinput = _bhideinput;
        // [210]  fu.FitWidth = bFitWidth 
        _fu._fitwidth = _bfitwidth;
        // [211]  AddFile(row,column,fu) 
        self.addfile(_row, _column, _fu);
        // End Sub
    };

    // [216] Sub AddPassword(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cPlaceHolder As String, cHelperText As String, cLength As Int,cTheme As String, cClass As String) 
    this.addpassword = function (_row, _column, _cid, _ciconname, _ctitle, _cplaceholder, _chelpertext, _clength, _ctheme, _cclass) {
        if (self == null) self = this;
        var _inp;
        // [217]  Dim inp As UOEInput 
        _inp = new banano_uoebanano_uoeinput();
        // [218]  inp.Initialize(App,cID,cTitle,cPlaceHolder,App.EnumInputType.password,cTheme) 
        _inp.initialize(self._app, _cid, _ctitle, _cplaceholder, self._app._enuminputtype._password, _ctheme);
        // [219]  inp.HelperText = cHelperText 
        _inp._helpertext = _chelpertext;
        // [220]  inp.IconName = cIconName 
        _inp._iconname = _ciconname;
        // [221]  inp.MaxLength = cLength 
        _inp._maxlength = _clength;
        // [222]  inp.AddClass(cClass) 
        _inp.addclass(_cclass);
        // [223]  AddInput(row,column,inp) 
        self.addinput(_row, _column, _inp);
        // End Sub
    };

    // [228] Sub AddNavBar(row As Int, column As Int, Nav As UOENavBar) 
    this.addnavbar = function (_row, _column, _nav) {
        if (self == null) self = this;
        // [229]  RemoveComponent(Nav.ID) 
        self.removecomponent(_nav._id);
        // [230]  AddComponent(row,column,Nav.tostring) 
        self.addcomponent(_row, _column, _nav.tostring());
        // End Sub
    };

    // [235] Sub AddParallax(row As Int, column As Int, parallax As UOEParallax) 
    this.addparallax = function (_row, _column, _parallax) {
        if (self == null) self = this;
        // [236]  RemoveComponent(parallax.ID) 
        self.removecomponent(_parallax._id);
        // [237]  AddComponent(row,column,parallax.tostring) 
        self.addcomponent(_row, _column, _parallax.tostring());
        // End Sub
    };

    // [241] Sub AddParallax1(row As Int, column As Int, cID As String, cURL As String, cClass As String) 
    this.addparallax1 = function (_row, _column, _cid, _curl, _cclass) {
        if (self == null) self = this;
        var _par;
        // [242]  Dim par As UOEParallax 
        _par = new banano_uoebanano_uoeparallax();
        // [243]  par.Initialize(App,cID,cURL) 
        _par.initialize(self._app, _cid, _curl);
        // [244]  par.AddClass(cClass) 
        _par.addclass(_cclass);
        // [245]  AddParallax(row,column,par) 
        self.addparallax(_row, _column, _par);
        // End Sub
    };

    // [250] Sub AddFeature1(fID As String, sTitle As String, sDescription As String, target As String, sThemeName As String, cClass As String) 
    this.addfeature1 = function (_fid, _stitle, _sdescription, _target, _sthemename, _cclass) {
        if (self == null) self = this;
        var _md;
        // [251]  Dim md As UOEFeature 
        _md = new banano_uoebanano_uoefeature();
        // [252]  md.Initialize(App,fID,sTitle,sDescription,sThemeName,target) 
        _md.initialize(self._app, _fid, _stitle, _sdescription, _sthemename, _target);
        // [253]  md.addclass(cClass) 
        _md.addclass(_cclass);
        // [254]  AddFeature(md) 
        self.addfeature(_md);
        // End Sub
    };

    // [259] Sub AddRadio1(row As Int, column As Int, cID As String, cName As String, cValue As String, cTitle As String, bChecked As Boolean, bEnabled As Boolean, bWithGap As Boolean, cTheme As String, cClass As String) 
    this.addradio1 = function (_row, _column, _cid, _cname, _cvalue, _ctitle, _bchecked, _benabled, _bwithgap, _ctheme, _cclass) {
        if (self == null) self = this;
        var _radio;
        // [260]  Dim radio As UOERadio 
        _radio = new banano_uoebanano_uoeradio();
        // [261]  radio.Initialize(App,cID,cName,cValue,cTitle,cTheme) 
        _radio.initialize(self._app, _cid, _cname, _cvalue, _ctitle, _ctheme);
        // [262]  radio.AddClass(cClass) 
        _radio.addclass(_cclass);
        // [263]  radio.WithGap = bWithGap 
        _radio._withgap = _bwithgap;
        // [264]  radio.Checked = bChecked 
        _radio._checked = _bchecked;
        // [265]  radio.Enabled = bEnabled 
        _radio._enabled = _benabled;
        // [266]  AddRadio(row,column,radio) 
        self.addradio(_row, _column, _radio);
        // End Sub
    };

    // [270] Sub AddRadio(row As Int, column As Int, radio As UOERadio) 
    this.addradio = function (_row, _column, _radio) {
        if (self == null) self = this;
        // [271]  RemoveComponent(radio.ID) 
        self.removecomponent(_radio._id);
        // [272]  AddComponent(row,column,radio.tostring) 
        self.addcomponent(_row, _column, _radio.tostring());
        // End Sub
    };

    // [278] Sub AddVideo1(row As Int, column As Int, cID As String, cURL As String, bAutoPlay As Boolean, bAllowFullScreen As Boolean, FrameBorder As Int, bLoop As Boolean, bShowControls As Boolean, cClass As String) 
    this.addvideo1 = function (_row, _column, _cid, _curl, _bautoplay, _ballowfullscreen, _frameborder, _bloop, _bshowcontrols, _cclass) {
        if (self == null) self = this;
        var _vid1;
        // [279]  Dim vid1 As UOEVideo 
        _vid1 = new banano_uoebanano_uoevideo();
        // [280]  vid1.Initialize(App,cID, cURL) 
        _vid1.initialize(self._app, _cid, _curl);
        // [281]  vid1.AddClass(cClass) 
        _vid1.addclass(_cclass);
        // [282]  vid1.AutoPlay = bAutoPlay 
        _vid1._autoplay = _bautoplay;
        // [283]  vid1.AllowFullScreen = bAllowFullScreen 
        _vid1._allowfullscreen = _ballowfullscreen;
        // [284]  vid1.FrameBorder = FrameBorder 
        _vid1._frameborder = _frameborder;
        // [285]  vid1.LoopIt = bLoop 
        _vid1._loopit = _bloop;
        // [286]  vid1.ShowControls = bShowControls 
        _vid1._showcontrols = _bshowcontrols;
        // [287]  AddVideo(row,column,vid1) 
        self.addvideo(_row, _column, _vid1);
        // End Sub
    };

    // [291] Sub AddSwitch(row As Int, column As Int, switch As UOESwitch) 
    this.addswitch = function (_row, _column, _switch) {
        if (self == null) self = this;
        // [292]  RemoveComponent(switch.ID) 
        self.removecomponent(_switch._id);
        // [293]  AddComponent(row,column,switch.tostring) 
        self.addcomponent(_row, _column, _switch.tostring());
        // End Sub
    };

    // [297] Sub AddSwitch1(row As Int, column As Int, cID As String, cTitle As String, cOnText As String, cOffText As String, bChecked As Boolean, bEnabled As Boolean, cTheme As String, cClass As String) 
    this.addswitch1 = function (_row, _column, _cid, _ctitle, _context, _cofftext, _bchecked, _benabled, _ctheme, _cclass) {
        if (self == null) self = this;
        var _switch;
        // [298]  Dim switch As UOESwitch 
        _switch = new banano_uoebanano_uoeswitch();
        // [299]  switch.Initialize(App,cID,cTitle,cOnText,cOffText,cTheme) 
        _switch.initialize(self._app, _cid, _ctitle, _context, _cofftext, _ctheme);
        // [300]  switch.addclass(cClass) 
        _switch.addclass(_cclass);
        // [301]  switch.Enabled = bEnabled 
        _switch._enabled = _benabled;
        // [302]  switch.checked = bChecked 
        _switch._checked = _bchecked;
        // [303]  AddSwitch(row,column,switch) 
        self.addswitch(_row, _column, _switch);
        // End Sub
    };

    // [307] Sub AddSlider(row As Int, column As Int, slider As UOESlider) 
    this.addslider = function (_row, _column, _slider) {
        if (self == null) self = this;
        // [308]  RemoveComponent(slider.ID) 
        self.removecomponent(_slider._id);
        // [309]  AddComponent(row,column,slider.tostring) 
        self.addcomponent(_row, _column, _slider.tostring());
        // End Sub
    };

    // [313] Sub AddInput(row As Int, col As Int, inp As UOEInput) 
    this.addinput = function (_row, _col, _inp) {
        if (self == null) self = this;
        var _script;
        // [314]  RemoveComponent(inp.ID) 
        self.removecomponent(_inp._id);
        // [315]  If inp.inpType = {7} Then 
        if (_inp._inptype == "textarea") {
            // [316]  Dim script As String = {1} 
            _script = "M.textareaAutoResize(" + self._j + "('#" + _inp._id + "'));";
            // [317]  App.js.add(script) 
            self._app._js.push(_script);
            // [318]  If inp.MaxLength > 0 Then 
            if (_inp._maxlength > 0) {
                // [319]  Dim script As String = {2} 
                _script = "" + self._j + "('textarea#" + _inp._id + "').characterCounter();";
                // [320]  App.JS.add(script) 
                self._app._js.push(_script);
                // [321]  End If 
            }
            // [322]  Else 
        } else {
            // [323]  If inp.maxlength > 0 Then 
            if (_inp._maxlength > 0) {
                // [324]  Dim script As String = {3} 
                _script = "" + self._j + "('input#" + _inp._id + "').characterCounter();";
                // [325]  App.JS.Add(script) 
                self._app._js.push(_script);
                // [326]  End If 
            }
            // [327]  End If 
        }
        // [328]  AddComponent(row,col,inp.tostring) 
        self.addcomponent(_row, _col, _inp.tostring());
        // End Sub
    };

    // [332] Sub AddImage(row As Int, col As Int, img As UOEImage) 
    this.addimage = function (_row, _col, _img) {
        if (self == null) self = this;
        // [333]  RemoveComponent(img.id) 
        self.removecomponent(_img._id);
        // [334]  AddComponent(row,col,img.ToString) 
        self.addcomponent(_row, _col, _img.tostring());
        // End Sub
    };

    // [338] Sub AddIcon(row As Int, col As Int, icon As UOEIcon) 
    this.addicon = function (_row, _col, _icon) {
        if (self == null) self = this;
        // [339]  RemoveComponent(icon.ID) 
        self.removecomponent(_icon._id);
        // [340]  AddComponent(row,col,icon.ToString) 
        self.addcomponent(_row, _col, _icon.tostring());
        // End Sub
    };

    // [344] Sub AddHTML5Video(row As Int, col As Int, video As UOEHTML5Video) 
    this.addhtml5video = function (_row, _col, _video) {
        if (self == null) self = this;
        // [345]  RemoveComponent(video.ID) 
        self.removecomponent(_video._id);
        // [346]  AddComponent(row,col,video.ToString) 
        self.addcomponent(_row, _col, _video.tostring());
        // End Sub
    };

    // [350] Sub AddVideo(row As Int, col As Int, video As UOEVideo) 
    this.addvideo = function (_row, _col, _video) {
        if (self == null) self = this;
        // [351]  RemoveComponent(video.ID) 
        self.removecomponent(_video._id);
        // [352]  AddComponent(row,col,video.tostring) 
        self.addcomponent(_row, _col, _video.tostring());
        // End Sub
    };

    // [356] Sub AddFeature(feat As UOEFeature) 
    this.addfeature = function (_feat) {
        if (self == null) self = this;
        // [357]  RemoveComponent(feat.ID) 
        self.removecomponent(_feat._id);
        // [358]  AddComponent(0,0,feat.ToString) 
        self.addcomponent(0, 0, _feat.tostring());
        // End Sub
    };

    // [362] Sub AddFile(row As Int, col As Int, elFile As UOEFile) 
    this.addfile = function (_row, _col, _elfile) {
        if (self == null) self = this;
        // [363]  RemoveComponent(elFile.ID) 
        self.removecomponent(_elfile._id);
        // [364]  AddComponent(row,col,elFile.ToString) 
        self.addcomponent(_row, _col, _elfile.tostring());
        // End Sub
    };

    // [368] Sub AddDropdown(row As Int, col As Int, elDropDown As UOEDropDown) 
    this.adddropdown = function (_row, _col, _eldropdown) {
        if (self == null) self = this;
        var _dds;
        // [369]  RemoveComponent(elDropDown.ID) 
        self.removecomponent(_eldropdown._id);
        // [370]  Dim dds As String = elDropDown.getSettings 
        _dds = _eldropdown.getsettings();
        // [371]  App.Components.Add(dds) 
        self._app._components.push(_dds);
        // [372]  AddComponent(row,col,elDropDown.ToString) 
        self.addcomponent(_row, _col, _eldropdown.tostring());
        // End Sub
    };

    // [376] Sub AddSelect(row As Int, col As Int, elSelect As UOESelect) 
    this.addselect = function (_row, _col, _elselect) {
        if (self == null) self = this;
        // [377]  RemoveComponent(elSelect.ID) 
        self.removecomponent(_elselect._id);
        // [378]  AddComponent(row,col,elSelect.ToString) 
        self.addcomponent(_row, _col, _elselect.tostring());
        // End Sub
    };

    // [382] Sub AddDatePicker(row As Int, column As Int, DatePicker As UOEDatePicker) 
    this.adddatepicker = function (_row, _column, _datepicker) {
        if (self == null) self = this;
        var _dps;
        // [383]  RemoveComponent(DatePicker.ID) 
        self.removecomponent(_datepicker._id);
        // [385]  Dim dpS As String = DatePicker.getSettings 
        _dps = _datepicker.getsettings();
        // [388]  App.Components.Add(dpS) 
        self._app._components.push(_dps);
        // [389]  AddComponent(row,column,DatePicker.tostring) 
        self.addcomponent(_row, _column, _datepicker.tostring());
        // End Sub
    };

    // [393] Sub AddFooter(foot As UOEFooter) 
    this.addfooter = function (_foot) {
        if (self == null) self = this;
        // [394]  RemoveComponent(foot.id) 
        self.removecomponent(_foot._id);
        // [395]  AddComponent(0,0,foot.ToString) 
        self.addcomponent(0, 0, _foot.tostring());
        // End Sub
    };

    // [399] Sub AddListView(row As Int, column As Int, lv As UOEListView) 
    this.addlistview = function (_row, _column, _lv) {
        if (self == null) self = this;
        // [400]  RemoveComponent(lv.ID) 
        self.removecomponent(_lv._id);
        // [401]  AddComponent(row,column,lv.ToString) 
        self.addcomponent(_row, _column, _lv.tostring());
        // End Sub
    };

    // [405] Sub AddChip(row As Int, column As Int, chip As UOEChip) 
    this.addchip = function (_row, _column, _chip) {
        if (self == null) self = this;
        // [406]  RemoveComponent(chip.ID) 
        self.removecomponent(_chip._id);
        // [407]  AddComponent(row,column,chip.ToString) 
        self.addcomponent(_row, _column, _chip.tostring());
        // End Sub
    };

    // [411] Sub AddChip1(row As Int, column As Int, cID As String, cTitle As String, cImageURL As String, cCanClose As Boolean, cTheme As String, cClass As String) 
    this.addchip1 = function (_row, _column, _cid, _ctitle, _cimageurl, _ccanclose, _ctheme, _cclass) {
        if (self == null) self = this;
        var _chip;
        // [412]  Dim chip As UOEChip 
        _chip = new banano_uoebanano_uoechip();
        // [413]  chip.Initialize(App,cID,cTitle, cImageURL, {8} ,cTheme) 
        _chip.initialize(self._app, _cid, _ctitle, _cimageurl, "", _ctheme);
        // [414]  chip.CanClose = cCanClose 
        _chip._canclose = _ccanclose;
        // [415]  chip.AddClass(cClass) 
        _chip.addclass(_cclass);
        // [416]  AddChip(row,column,chip) 
        self.addchip(_row, _column, _chip);
        // End Sub
    };

    // [420] Sub AddCollapsible(row As Int, column As Int, rg As UOECollapsible) 
    this.addcollapsible = function (_row, _column, _rg) {
        if (self == null) self = this;
        // [421]  RemoveComponent(rg.ID) 
        self.removecomponent(_rg._id);
        // [422]  AddComponent(row,column,rg.ToString) 
        self.addcomponent(_row, _column, _rg.tostring());
        // End Sub
    };

    // [427] Sub AddCheckBoxGroup(row As Int, column As Int, rg As UOECheckBoxGroup) 
    this.addcheckboxgroup = function (_row, _column, _rg) {
        if (self == null) self = this;
        // [428]  RemoveComponent(rg.ID) 
        self.removecomponent(_rg._id);
        // [429]  AddComponent(row,column,rg.ToString) 
        self.addcomponent(_row, _column, _rg.tostring());
        // End Sub
    };

    // [433] Sub AddCheckBox(row As Int, column As Int, checkBox As UOECheckBox) 
    this.addcheckbox = function (_row, _column, _checkbox) {
        if (self == null) self = this;
        // [434]  RemoveComponent(checkBox.ID) 
        self.removecomponent(_checkbox._id);
        // [435]  AddComponent(row,column,checkBox.tostring) 
        self.addcomponent(_row, _column, _checkbox.tostring());
        // End Sub
    };

    // [439] Sub AddCheckBox1(row As Int, column As Int, cID As String, cValue As String, cTitle As String, bChecked As Boolean, bFilledIn As Boolean, bEnabled As Boolean, cTheme As String, cClass As String) 
    this.addcheckbox1 = function (_row, _column, _cid, _cvalue, _ctitle, _bchecked, _bfilledin, _benabled, _ctheme, _cclass) {
        if (self == null) self = this;
        var _c1;
        // [440]  Dim c1 As UOECheckBox 
        _c1 = new banano_uoebanano_uoecheckbox();
        // [441]  c1.Initialize(App,cID,cID,cValue,cTitle,cTheme) 
        _c1.initialize(self._app, _cid, _cid, _cvalue, _ctitle, _ctheme);
        // [442]  c1.AddClass(cClass) 
        _c1.addclass(_cclass);
        // [443]  c1.Checked = bChecked 
        _c1._checked = _bchecked;
        // [444]  c1.FilledIn = bFilledIn 
        _c1._filledin = _bfilledin;
        // [445]  c1.Enabled = bEnabled 
        _c1._enabled = _benabled;
        // [446]  AddCheckBox(row,column,c1) 
        self.addcheckbox(_row, _column, _c1);
        // End Sub
    };

    // [451] Sub AddCarousel(row As Int, column As Int, carousel As UOECarousel) 
    this.addcarousel = function (_row, _column, _carousel) {
        if (self == null) self = this;
        var _settings;
        // [452]  RemoveComponent(carousel.ID) 
        self.removecomponent(_carousel._id);
        // [454]  Dim settings As String = carousel.getSettings 
        _settings = _carousel.getsettings();
        // [455]  App.Components.Add(settings) 
        self._app._components.push(_settings);
        // [456]  AddComponent(row,column,carousel.tostring) 
        self.addcomponent(_row, _column, _carousel.tostring());
        // End Sub
    };

    // [460] Sub AddTabs(row As Int,column As Int, vtab As UOETabs) 
    this.addtabs = function (_row, _column, _vtab) {
        if (self == null) self = this;
        var _dps;
        // [461]  RemoveComponent(vtab.ID) 
        self.removecomponent(_vtab._id);
        // [463]  Dim dpS As String = vtab.getSettings 
        _dps = _vtab.getsettings();
        // [466]  App.Components.Add(dpS) 
        self._app._components.push(_dps);
        // [467]  AddComponent(row,column,vtab.tostring) 
        self.addcomponent(_row, _column, _vtab.tostring());
        // End Sub
    };

    // [470] Sub AddBreak(row As Int, column As Int) 
    this.addbreak = function (_row, _column) {
        if (self == null) self = this;
        // [471]  AddParagraph(row,column, {9} , {10} , {11} , {12} ) 
        self.addparagraph(_row, _column, "", "{BR}", "", "");
        // End Sub
    };

    // [475] Sub AddCard(row As Int, column As Int, card As UOECard) 
    this.addcard = function (_row, _column, _card) {
        if (self == null) self = this;
        // [476]  RemoveComponent(card.ID) 
        self.removecomponent(_card._id);
        // [477]  AddComponent(row,column,card.tostring) 
        self.addcomponent(_row, _column, _card.tostring());
        // End Sub
    };

    // [481] Sub AddBreadCrumbs(row As Int,col As Int,cont As UOEBreadCrumbs) 
    this.addbreadcrumbs = function (_row, _col, _cont) {
        if (self == null) self = this;
        // [482]  RemoveComponent(cont.ID) 
        self.removecomponent(_cont._id);
        // [490]  AddComponent(row,col,cont.tostring) 
        self.addcomponent(_row, _col, _cont.tostring());
        // End Sub
    };

    // [495] Sub AddContainer(row As Int, column As Int, cont As UOEContainer) 
    this.addcontainer = function (_row, _column, _cont) {
        if (self == null) self = this;
        // [496]  RemoveComponent(cont.ID) 
        self.removecomponent(_cont._id);
        // [497]  AddComponent(row,column,cont.tostring) 
        self.addcomponent(_row, _column, _cont.tostring());
        // End Sub
    };

    // [501] Sub AddButton(row As Int,column As Int, btnDef As UOEButton) 
    this.addbutton = function (_row, _column, _btndef) {
        if (self == null) self = this;
        // [502]  RemoveComponent(btnDef.ID) 
        self.removecomponent(_btndef._id);
        // [503]  AddComponent(row,column,btnDef.tostring) 
        self.addcomponent(_row, _column, _btndef.tostring());
        // [504]  App.AddEvent(btnDef.id, {15} ) 
        self._app.addevent(_btndef._id, "click");
        // End Sub
    };

    // [508] Sub AddFAB(fab As UOEFAB) 
    this.addfab = function (_fab) {
        if (self == null) self = this;
        var _dps;
        // [509]  RemoveComponent(fab.ID) 
        self.removecomponent(_fab._id);
        // [510]  Dim dpS As String = fab.getSettings 
        _dps = _fab.getsettings();
        // [513]  App.Components.Add(dpS) 
        self._app._components.push(_dps);
        // [514]  AddComponent(0,0,fab.tostring) 
        self.addcomponent(0, 0, _fab.tostring());
        // [515]  App.AddEvent(fab.ID, {16} ) 
        self._app.addevent(_fab._id, "click");
        // End Sub
    };

    // [518] Sub AddFab1(fabID As String, href As String, icon As String, svisibility As String, iconTheme As String, fabClass As String) 
    this.addfab1 = function (_fabid, _href, _icon, _svisibility, _icontheme, _fabclass) {
        if (self == null) self = this;
        var _fab;
        // [519]  Dim fab As UOEFAB 
        _fab = new banano_uoebanano_uoefab();
        // [520]  fab.Initialize(App,fabID,href,icon, App.EnumButtonSize.LARGE, svisibility,iconTheme) 
        _fab.initialize(self._app, _fabid, _href, _icon, self._app._enumbuttonsize._large, _svisibility, _icontheme);
        // [521]  fab.AddClass(fabClass) 
        _fab.addclass(_fabclass);
        // [522]  AddFAB(fab) 
        self.addfab(_fab);
        // End Sub
    };

    // [526] Sub AddButton1(row As Int,column As Int, btnID As String,btnText As String, btnNavigateTo As String, btnType As String, btnIcon As String, btnSize As String, btnFitWidth As Boolean, bPulse As Boolean, bEnabled As Boolean, btnTheme As String, cClass As String) 
    this.addbutton1 = function (_row, _column, _btnid, _btntext, _btnnavigateto, _btntype, _btnicon, _btnsize, _btnfitwidth, _bpulse, _benabled, _btntheme, _cclass) {
        if (self == null) self = this;
        var _btn;
        // [527]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [528]  btn.Initialize(App,btnID,btnText,btnTheme) 
        _btn.initialize(self._app, _btnid, _btntext, _btntheme);
        // [529]  btn.HREF = btnNavigateTo 
        _btn._href = _btnnavigateto;
        // [530]  btn.SetButtonType(btnType) 
        _btn.setbuttontype(_btntype);
        // [531]  btn.Size = btnSize 
        _btn._size = _btnsize;
        // [532]  btn.Pulsing = bPulse 
        _btn._pulsing = _bpulse;
        // [533]  btn.Enabled = bEnabled 
        _btn._enabled = _benabled;
        // [534]  btn.AddClass(cClass) 
        _btn.addclass(_cclass);
        // [535]  btn.WavesType = App.EnumWavesType.light 
        _btn._wavestype = self._app._enumwavestype._light;
        // [536]  btn.AddJustIcon(btnIcon) 
        _btn.addjusticon(_btnicon);
        // [537]  btn.FitWidth = btnFitWidth 
        _btn._fitwidth = _btnfitwidth;
        // [538]  AddButton(row,column,btn) 
        self.addbutton(_row, _column, _btn);
        // End Sub
    };

    // [543] Sub AddRaisedButton(row As Int,column As Int, btnID As String,btnText As String,btnVisibility As String,btnNavigateTo As String, btnTheme As String, cClass As String) 
    this.addraisedbutton = function (_row, _column, _btnid, _btntext, _btnvisibility, _btnnavigateto, _btntheme, _cclass) {
        if (self == null) self = this;
        var _btn;
        // [544]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [545]  btn.Initialize(App,btnID,btnText,btnTheme) 
        _btn.initialize(self._app, _btnid, _btntext, _btntheme);
        // [546]  btn.Visibility = btnVisibility 
        _btn._visibility = _btnvisibility;
        // [547]  btn.HREF = btnNavigateTo 
        _btn._href = _btnnavigateto;
        // [548]  btn.SetButtonType(App.EnumButtonType.raised) 
        _btn.setbuttontype(self._app._enumbuttontype._raised);
        // [549]  btn.Size = App.EnumButtonSize.medium 
        _btn._size = self._app._enumbuttonsize._medium;
        // [550]  btn.AddClass(cClass) 
        _btn.addclass(_cclass);
        // [551]  btn.FitWidth = False 
        _btn._fitwidth = false;
        // [552]  AddButton(row,column,btn) 
        self.addbutton(_row, _column, _btn);
        // End Sub
    };

    // [556] Sub AddFloatingButton(row As Int,column As Int, btnID As String,btnIcon As String,btnVisibility As String,btnNavigateTo As String, btnTheme As String, cClass As String) 
    this.addfloatingbutton = function (_row, _column, _btnid, _btnicon, _btnvisibility, _btnnavigateto, _btntheme, _cclass) {
        if (self == null) self = this;
        var _btn;
        // [557]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [558]  btn.Initialize(App,btnID, {17} ,btnTheme) 
        _btn.initialize(self._app, _btnid, "", _btntheme);
        // [559]  btn.Visibility = btnVisibility 
        _btn._visibility = _btnvisibility;
        // [560]  btn.HREF = btnNavigateTo 
        _btn._href = _btnnavigateto;
        // [561]  btn.SetButtonType(App.EnumButtonType.floating) 
        _btn.setbuttontype(self._app._enumbuttontype._floating);
        // [562]  btn.Size = App.EnumButtonSize.medium 
        _btn._size = self._app._enumbuttonsize._medium;
        // [563]  btn.AddClass(cClass) 
        _btn.addclass(_cclass);
        // [564]  btn.AddJustIcon(btnIcon) 
        _btn.addjusticon(_btnicon);
        // [565]  btn.FitWidth = False 
        _btn._fitwidth = false;
        // [566]  AddButton(row,column,btn) 
        self.addbutton(_row, _column, _btn);
        // End Sub
    };

    // [570] Sub getFloatingButton(btnID As String,btnIcon As String,btnTheme As String, cClass As String) As UOEButton 
    this.getfloatingbutton = function (_btnid, _btnicon, _btntheme, _cclass) {
        if (self == null) self = this;
        var _btn;
        // [571]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [572]  btn.Initialize(App,btnID, {18} ,btnTheme) 
        _btn.initialize(self._app, _btnid, "", _btntheme);
        // [573]  btn.SetButtonType(App.EnumButtonType.floating) 
        _btn.setbuttontype(self._app._enumbuttontype._floating);
        // [574]  btn.Size = App.EnumButtonSize.medium 
        _btn._size = self._app._enumbuttonsize._medium;
        // [575]  btn.AddClass(cClass) 
        _btn.addclass(_cclass);
        // [576]  btn.AddJustIcon(btnIcon) 
        _btn.addjusticon(_btnicon);
        // [577]  btn.FitWidth = False 
        _btn._fitwidth = false;
        // [578]  RemoveComponent(btnID) 
        self.removecomponent(_btnid);
        // [579]  Return btn 
        return _btn;
        // End Sub
    };

    // [583] Sub AddFlatButton(row As Int,column As Int, btnID As String,btnText As String,btnVisibility As String,btnNavigateTo As String, btnTheme As String, cClass As String) 
    this.addflatbutton = function (_row, _column, _btnid, _btntext, _btnvisibility, _btnnavigateto, _btntheme, _cclass) {
        if (self == null) self = this;
        var _btn;
        // [584]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [585]  btn.Initialize(App,btnID,btnText,btnTheme) 
        _btn.initialize(self._app, _btnid, _btntext, _btntheme);
        // [586]  btn.Visibility = btnVisibility 
        _btn._visibility = _btnvisibility;
        // [587]  btn.HREF = btnNavigateTo 
        _btn._href = _btnnavigateto;
        // [588]  btn.SetButtonType(App.EnumButtonType.flat) 
        _btn.setbuttontype(self._app._enumbuttontype._flat);
        // [589]  btn.Size = App.enumbuttonsize.medium 
        _btn._size = self._app._enumbuttonsize._medium;
        // [590]  btn.AddClass(cClass) 
        _btn.addclass(_cclass);
        // [591]  btn.FitWidth = False 
        _btn._fitwidth = false;
        // [592]  AddButton(row,column,btn) 
        self.addbutton(_row, _column, _btn);
        // End Sub
    };

    // [596] Sub AddToC(row As Int, column As Int, tbl As UOETOC) 
    this.addtoc = function (_row, _column, _tbl) {
        if (self == null) self = this;
        // [597]  RemoveComponent(tbl.ID) 
        self.removecomponent(_tbl._id);
        // [598]  AddComponent(row,column,tbl.ToString) 
        self.addcomponent(_row, _column, _tbl.tostring());
        // End Sub
    };

    // [602] Sub AddLabel(row As Int,column As Int, lbl As UOELabel) 
    this.addlabel = function (_row, _column, _lbl) {
        if (self == null) self = this;
        var _scode;
        // [603]  RemoveComponent(lbl.ID) 
        self.removecomponent(_lbl._id);
        // [604]  Dim scode As String = lbl.tostring 
        _scode = _lbl.tostring();
        // [605]  scode = scode.Replace(CRLF, {19} ) 
        _scode = _scode.split("\n").join("");
        // [606]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [610] Sub AddParagraph(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addparagraph = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [611]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [612]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [613]  ml.Initialize(App,paraid, {20} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "p", _paratext, _paratheme, _cclass);
        // [614]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [615]  scode = scode.Replace(CRLF, {21} ) 
        _scode = _scode.split("\n").join("");
        // [616]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [617]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [621] Sub AddH1(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh1 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [622]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [623]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [624]  ml.Initialize(App,paraid, {22} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h1", _paratext, _paratheme, _cclass);
        // [625]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [626]  scode = scode.Replace(CRLF, {23} ) 
        _scode = _scode.split("\n").join("");
        // [627]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [628]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [632] Sub AddH2(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh2 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [633]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [634]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [635]  ml.Initialize(App,paraid, {24} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h2", _paratext, _paratheme, _cclass);
        // [636]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [637]  scode = scode.Replace(CRLF, {25} ) 
        _scode = _scode.split("\n").join("");
        // [638]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [639]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [643] Sub AddH3(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh3 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [644]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [645]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [646]  ml.Initialize(App,paraid, {26} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h3", _paratext, _paratheme, _cclass);
        // [647]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [648]  scode = scode.Replace(CRLF, {27} ) 
        _scode = _scode.split("\n").join("");
        // [649]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [650]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [654] Sub AddH4(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh4 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [655]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [656]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [657]  ml.Initialize(App,paraid, {28} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h4", _paratext, _paratheme, _cclass);
        // [658]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [659]  scode = scode.Replace(CRLF, {29} ) 
        _scode = _scode.split("\n").join("");
        // [660]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [661]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [665] Sub AddH5(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh5 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [666]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [667]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [668]  ml.Initialize(App,paraid, {30} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h5", _paratext, _paratheme, _cclass);
        // [669]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [670]  scode = scode.Replace(CRLF, {31} ) 
        _scode = _scode.split("\n").join("");
        // [671]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [672]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [676] Sub AddH6(row As Int,column As Int, paraid As String, paraText As String, paraTheme As String, cClass As String) 
    this.addh6 = function (_row, _column, _paraid, _paratext, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [677]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [678]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [679]  ml.Initialize(App,paraid, {32} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h6", _paratext, _paratheme, _cclass);
        // [680]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [681]  scode = scode.Replace(CRLF, {33} ) 
        _scode = _scode.split("\n").join("");
        // [682]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [683]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [688] Sub AddHiddenParagraph(row As Int,column As Int, paraid As String, paratext As String) 
    this.addhiddenparagraph = function (_row, _column, _paraid, _paratext) {
        if (self == null) self = this;
        var _ml;
        // [689]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [690]  ml.Initialize(App,paraid, {34} ,paratext, {35} , {36} ) 
        _ml.initialize(self._app, _paraid, "p", _paratext, "", "");
        // [691]  ml.Visibility = {37} 
        _ml._visibility = "hide";
        // [692]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [693]  AddComponent(row,column,ml.tostring) 
        self.addcomponent(_row, _column, _ml.tostring());
        // End Sub
    };

    // [697] Sub AddBlockQuote(row As Int,column As Int, paraid As String, paraText As String, paraWidth As Int, paraTheme As String, cClass As String) 
    this.addblockquote = function (_row, _column, _paraid, _paratext, _parawidth, _paratheme, _cclass) {
        if (self == null) self = this;
        var _ml;
        var _scode;
        // [698]  paraid = paraid.tolowercase 
        _paraid = _paraid.toLowerCase();
        // [699]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [700]  ml.Initialize(App,paraid, {38} ,paraText,paraTheme,cClass) 
        _ml.initialize(self._app, _paraid, "h5", _paratext, _paratheme, _cclass);
        // [701]  ml.BlockQuote = True 
        _ml._blockquote = true;
        // [702]  ml.BlockQuoteWidth = paraWidth 
        _ml._blockquotewidth = _parawidth;
        // [703]  Dim scode As String = ml.tostring 
        _scode = _ml.tostring();
        // [704]  scode = scode.Replace(CRLF, {39} ) 
        _scode = _scode.split("\n").join("");
        // [705]  RemoveComponent(paraid) 
        self.removecomponent(_paraid);
        // [706]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [710] Sub AddLink(row As Int, column As Int, lnkID As String, lnkText As String, lnkURL As String) 
    this.addlink = function (_row, _column, _lnkid, _lnktext, _lnkurl) {
        if (self == null) self = this;
        var _a;
        var _scode;
        // [711]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [712]  a.Initialize(lnkID, {40} ) 
        _a.initialize(_lnkid, "a");
        // [713]  a.SetHREF(lnkURL).AddContent(lnkText) 
        _a.sethref(_lnkurl).addcontent(_lnktext);
        // [714]  Dim scode As String = a.tostring 
        _scode = _a.tostring();
        // [715]  scode = scode.Replace(CRLF, {41} ) 
        _scode = _scode.split("\n").join("");
        // [716]  RemoveComponent(lnkID) 
        self.removecomponent(_lnkid);
        // [717]  AddComponent(row,column,scode) 
        self.addcomponent(_row, _column, _scode);
        // End Sub
    };

    // [721] Sub AddDivider(row As Int, column As Int, cTheme As String) 
    this.adddivider = function (_row, _column, _ctheme) {
        if (self == null) self = this;
        var _dkey;
        var _div;
        // [722]  divCounter = divCounter + 1 
        self._divcounter = self._divcounter + 1;
        // [723]  Dim dKey As String = {4} 
        _dkey = "divider" + self._divcounter + "";
        // [724]  Dim div As UOEDivider 
        _div = new banano_uoebanano_uoedivider();
        // [725]  div.Initialize(App,dKey,cTheme) 
        _div.initialize(self._app, _dkey, _ctheme);
        // [726]  AddComponent(row,column,div.tostring) 
        self.addcomponent(_row, _column, _div.tostring());
        // End Sub
    };

    // [730] Sub AddStyleAttribute(attribute As String, value As String) As UOEContainer 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [731]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [732]  Return Me 
        return self;
        // End Sub
    };

    // [736] Sub AddStyleAttributeOnCondition(bCondition As Boolean, attr As String, value As String) As UOEContainer 
    this.addstyleattributeoncondition = function (_bcondition, _attr, _value) {
        if (self == null) self = this;
        // [737]  Element.removeStyle(attr) 
        self._element.removestyle(_attr);
        // [738]  If bCondition = True Then 
        if (_bcondition == true) {
            // [739]  AddStyleAttribute(attr,value) 
            self.addstyleattribute(_attr, _value);
            // [740]  End If 
        }
        // [741]  Return Me 
        return self;
        // End Sub
    };

    // [746] Sub AddRowsMV(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, rVisibility As String, themeName As String , className As String) As UOEGrid 
    this.addrowsmv = function (_rows2add, _margintoppx, _marginbottompx, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [747]  Grid.AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx , 0,0,0,0,0,0, themeName , rVisibility, className ) 
        self._grid.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, 0, 0, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [748]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [752] Sub AddRowsMV2(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, marginLeftPx As Int, marginRightPx As Int, rVisibility As String, themeName As String, className As String) As UOEGrid 
    this.addrowsmv2 = function (_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [753]  Grid.AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx , marginLeftPx, marginRightPx , 0,0,0,0,themeName, rVisibility, className) 
        self._grid.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [754]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [759] Sub AddRowsM2(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, marginLeftPx As Int, marginRightPx As Int, themeName As String, className As String) As UOEGrid 
    this.addrowsm2 = function (_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, _themename, _classname) {
        if (self == null) self = this;
        // [760]  Grid.AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx, marginLeftPx, marginRightPx, 0,0,0,0, themeName, {42} , className) 
        self._grid.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, 0, 0, 0, 0, _themename, "", _classname);
        // [761]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [765] Sub AddRowsM(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, themeName As String, className As String) As UOEGrid 
    this.addrowsm = function (_rows2add, _margintoppx, _marginbottompx, _themename, _classname) {
        if (self == null) self = this;
        // [766]  Grid.AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx, 0,0,0,0,0,0,themeName , {43} , className) 
        self._grid.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, 0, 0, 0, 0, 0, 0, _themename, "", _classname);
        // [767]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [771] Sub AddRowsV(Rows2Add As Int, rVisibility As String, themeName As String, className As String) As UOEGrid 
    this.addrowsv = function (_rows2add, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [772]  Grid.AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName,rVisibility, className) 
        self._grid.addrowsmpv(_rows2add, 0, 20, 0, 0, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [773]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [777] Sub AddRows(Rows2Add As Int, themeName As String,className As String) As UOEGrid 
    this.addrows = function (_rows2add, _themename, _classname) {
        if (self == null) self = this;
        // [778]  Grid.AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName, {44} ,className) 
        self._grid.addrowsmpv(_rows2add, 0, 20, 0, 0, 0, 0, 0, 0, _themename, "", _classname);
        // [779]  Return Grid 
        return self._grid;
        // End Sub
    };

    // [784] Sub AddElement(el As UOEHTML) 
    this.addelement = function (_el) {
        if (self == null) self = this;
        var _scode;
        // [785]  If el <> Null Then 
        if (_el != null) {
            // [786]  Dim scode As String = el.tostring 
            _scode = _el.tostring();
            // [787]  RemoveComponent(el.ID) 
            self.removecomponent(_el._id);
            // [788]  Element.AddContent(scode) 
            self._element.addcontent(_scode);
            // [789]  End If 
        }
        // End Sub
    };

    // [793] private Sub Refresh 
    this.refresh = function () {
        if (self == null) self = this;
        var _grd;
        // [794]  Dim grd As String = Grid.tostring 
        _grd = self._grid.tostring();
        // [795]  Element.AddContent(grd) 
        self._element.addcontent(_grd);
        // End Sub
    };

    // [799] Sub AddRowClass(rowPos As Int, className As String) As UOEContainer 
    this.addrowclass = function (_rowpos, _classname) {
        if (self == null) self = this;
        // [800]  Grid.setRowClass(rowPos,className) 
        self._grid.setrowclass(_rowpos, _classname);
        // [801]  Return Me 
        return self;
        // End Sub
    };

    // [805] Sub setRowMargins(rowPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) As UOEContainer 
    this.setrowmargins = function (_rowpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        // [807]  Grid.setRowMargins(rowPos, marginTop, marginBottom, marginLeft, marginRight) 
        self._grid.setrowmargins(_rowpos, _margintop, _marginbottom, _marginleft, _marginright);
        // [808]  Return Me 
        return self;
        // End Sub
    };

    // [812] Sub setRowPadding(rowPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) As UOEContainer 
    this.setrowpadding = function (_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        // [814]  Grid.setRowPadding(rowPos, paddingTop, paddingBottom, paddingLeft, paddingRight) 
        self._grid.setrowpadding(_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright);
        // [815]  Return Me 
        return self;
        // End Sub
    };

    // [819] Sub setColumnPadding(rowPos As Int, colPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) As UOEContainer 
    this.setcolumnpadding = function (_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        // [821]  Grid.setColumnPadding(rowPos, colPos, paddingTop, paddingBottom, paddingLeft, paddingRight) 
        self._grid.setcolumnpadding(_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright);
        // [822]  Return Me 
        return self;
        // End Sub
    };

    // [826] Sub setColumnMargins(rowPos As Int, colPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) As UOEContainer 
    this.setcolumnmargins = function (_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        // [828]  Grid.setColumnMargins(rowPos, colPos, marginTop, marginBottom, marginLeft, marginRight) 
        self._grid.setcolumnmargins(_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright);
        // [829]  Return Me 
        return self;
        // End Sub
    };

    // [833] Sub setRowMargins1(rowPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) As UOEContainer 
    this.setrowmargins1 = function (_rowpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        // [834]  Grid.setRowMargins1(rowPos, marginTop, marginBottom, marginLeft, marginRight) 
        self._grid.setrowmargins1(_rowpos, _margintop, _marginbottom, _marginleft, _marginright);
        // [835]  Return Me 
        return self;
        // End Sub
    };

    // [839] Sub setColumnMargins1(rowPos As Int, colPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) As UOEContainer 
    this.setcolumnmargins1 = function (_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        // [840]  Grid.setColumnMargins1(rowPos, colPos, marginTop, marginBottom , marginLeft, marginRight) 
        self._grid.setcolumnmargins1(_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright);
        // [841]  Return Me 
        return self;
        // End Sub
    };

    // [845] Sub AddColumnClass(rowPos As Int, columnPos As Int, className As String) As UOEContainer 
    this.addcolumnclass = function (_rowpos, _columnpos, _classname) {
        if (self == null) self = this;
        // [846]  Grid.setColumnClass(rowPos,columnPos,className) 
        self._grid.setcolumnclass(_rowpos, _columnpos, _classname);
        // [847]  Return Me 
        return self;
        // End Sub
    };

    // [851] Sub setRowPadding1(rowPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) As UOEContainer 
    this.setrowpadding1 = function (_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        // [852]  Grid.setRowPadding1(rowPos, paddingTop, paddingBottom, paddingLeft, paddingRight) 
        self._grid.setrowpadding1(_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright);
        // [853]  Return Me 
        return self;
        // End Sub
    };

    // [857] Sub setColumnPadding1(rowPos As Int, colPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) As UOEContainer 
    this.setcolumnpadding1 = function (_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        // [859]  Grid.setColumnPadding1(rowPos, colPos, paddingTop, paddingBottom, paddingLeft, paddingRight) 
        self._grid.setcolumnpadding1(_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright);
        // [860]  Return Me 
        return self;
        // End Sub
    };

    // [864] Public Sub Initialize(thisApp As UOEApp, mvarID As String, bCenterInPage As Boolean,themeName As String) 
    this.initialize = function (_thisapp, _mvarid, _bcenterinpage, _themename) {
        if (self == null) self = this;
        // [865]  App = thisApp 
        self._app = _thisapp;
        // [866]  ID = mvarID.tolowercase 
        self._id = _mvarid.toLowerCase();
        // [867]  CenterInPage = bCenterInPage 
        self._centerinpage = _bcenterinpage;
        // [868]  Element.Initialize(ID, {45} ) 
        self._element.initialize(self._id, "div");
        // [869]  Element.AddClassOnCondition(bCenterInPage, {46} ) 
        self._element.addclassoncondition(_bcenterinpage, "container");
        // [870]  Items.Initialize 
        self._items.length = 0;
        // [871]  Items.clear 
        self._items.length = 0;
        // [872]  Enabled = True 
        self._enabled = true;
        // [873]  Theme = themeName 
        self._theme = _themename;
        // [874]  App.MaterialUseTheme(themeName,Element) 
        self._app.materialusetheme(_themename, self._element);
        // [875]  Grid.Initialize(App,mvarID) 
        self._grid.initialize(self._app, _mvarid);
        // [876]  Visibility = {47} 
        self._visibility = "";
        // [877]  ZDepth = {48} 
        self._zdepth = "";
        // [878]  ScrollSpy = False 
        self._scrollspy = false;
        // [879]  Section = False 
        self._section = false;
        // [880]  divCounter = 0 
        self._divcounter = 0;
        // [881]  j = {49} 
        self._j = "$";
        // End Sub
    };

    // [885] Sub AddClass(sClass As String) As UOEContainer 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [886]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [887]  Return Me 
        return self;
        // End Sub
    };

    // [891] Sub RemoveClass(sClass As String) As UOEContainer 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [892]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [893]  Return Me 
        return self;
        // End Sub
    };

    // [897] Sub AddAttribute(attr As String, value As String) As UOEContainer 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [898]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [899]  Return Me 
        return self;
        // End Sub
    };

    // [903] Sub RemoveAttribute(attr As String) As UOEContainer 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [904]  Element.RemoveAttr(attr) 
        self._element.removeattr(_attr);
        // [905]  Return Me 
        return self;
        // End Sub
    };

    // [909] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [910]  Refresh 
        self.refresh();
        // [911]  Element.AddClassOnCondition(ScrollSpy, {50} ) 
        self._element.addclassoncondition(self._scrollspy, "scrollspy");
        // [912]  Element.AddClassOnCondition(Section, {51} ) 
        self._element.addclassoncondition(self._section, "section");
        // [913]  Element.ID = ID 
        self._element._id = self._id;
        // [914]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [915]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [916]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [917]  Element.RemoveClassOnCondition(Section, {52} ) 
        self._element.removeclassoncondition(self._section, "container");
        // [918]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

    // [923] Sub AddContent(sContent As String) As UOEContainer 
    this.addcontent = function (_scontent) {
        if (self == null) self = this;
        // [924]  Element.AddContent(sContent) 
        self._element.addcontent(_scontent);
        // [925]  Return Me 
        return self;
        // End Sub
    };

    // [929] Sub AddComponent(rowPos As Int, colPos As Int, elHTML As String) 
    this.addcomponent = function (_rowpos, _colpos, _elhtml) {
        if (self == null) self = this;
        // [931]  If rowPos = 0 And colPos = 0 Then 
        if (_rowpos == 0 && _colpos == 0) {
            // [932]  AddContent(elHTML) 
            self.addcontent(_elhtml);
            // [933]  Else 
        } else {
            // [934]  Grid.AddComponent(rowPos,colPos,elHTML) 
            self._grid.addcomponent(_rowpos, _colpos, _elhtml);
            // [935]  End If 
        }
        // End Sub
    };

    // [939] Sub AddRange1(row As Int, column As Int, rngID As String, rngCaption As String,lMin As Float,lMax As Float,lValue As Float,lStep As Float, lTheme As String, cClass As String) 
    this.addrange1 = function (_row, _column, _rngid, _rngcaption, _lmin, _lmax, _lvalue, _lstep, _ltheme, _cclass) {
        if (self == null) self = this;
        var _range;
        // [940]  Dim range As UOERange 
        _range = new banano_uoebanano_uoerange();
        // [941]  range.Initialize(App,rngID,rngCaption, lMin,lMax,lValue,lStep,lTheme) 
        _range.initialize(self._app, _rngid, _rngcaption, _lmin, _lmax, _lvalue, _lstep, _ltheme);
        // [942]  range.AddClass(cClass) 
        _range.addclass(_cclass);
        // [943]  AddRange(row,column,range) 
        self.addrange(_row, _column, _range);
        // End Sub
    };

    // [948] Sub AddDatePicker1(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cTheme As String, cClass As String) 
    this.adddatepicker1 = function (_row, _column, _cid, _ciconname, _ctitle, _ctheme, _cclass) {
        if (self == null) self = this;
        var _dp;
        // [949]  Dim dp As UOEDatePicker 
        _dp = new banano_uoebanano_uoedatepicker();
        // [950]  dp.Initialize(App,cID,cTitle,App.EnumDateTimeType.datepicker,cTheme) 
        _dp.initialize(self._app, _cid, _ctitle, self._app._enumdatetimetype._datepicker, _ctheme);
        // [951]  dp.showClearBtn = True 
        _dp._showclearbtn = true;
        // [952]  dp.DateTimeFormat = {53} 
        _dp._datetimeformat = "YYYY-MM-DD";
        // [953]  dp.IconName = cIconName 
        _dp._iconname = _ciconname;
        // [954]  dp.AddClass(cClass) 
        _dp.addclass(_cclass);
        // [955]  AddDatePicker(row,column,dp) 
        self.adddatepicker(_row, _column, _dp);
        // End Sub
    };

    // [960] Sub AddTimePicker1(row As Int, column As Int, cID As String, cIconName As String, cTitle As String, cTheme As String, cClass As String) 
    this.addtimepicker1 = function (_row, _column, _cid, _ciconname, _ctitle, _ctheme, _cclass) {
        if (self == null) self = this;
        var _dp1;
        // [961]  Dim dp1 As UOEDatePicker 
        _dp1 = new banano_uoebanano_uoedatepicker();
        // [962]  dp1.Initialize(App,cID,cTitle,App.EnumDateTimeType.timepicker,cTheme) 
        _dp1.initialize(self._app, _cid, _ctitle, self._app._enumdatetimetype._timepicker, _ctheme);
        // [963]  dp1.showClearBtn = True 
        _dp1._showclearbtn = true;
        // [964]  dp1.IconName = cIconName 
        _dp1._iconname = _ciconname;
        // [965]  dp1.AddClass(cClass) 
        _dp1.addclass(_cclass);
        // [966]  AddDatePicker(row,column,dp1) 
        self.adddatepicker(_row, _column, _dp1);
        // End Sub
    };

    // [971] Sub AddContentList(lst As List) 
    this.addcontentlist = function (_lst) {
        if (self == null) self = this;
        var _strcontent;
        // [972]  For Each strContent As String In lst 
        for (var _strcontentindex = 0; _strcontentindex < _lst.length; _strcontentindex++) {
            _strcontent = _lst[_strcontentindex];
            // [973]  AddContent(strContent) 
            self.addcontent(_strcontent);
            // [974]  Next 
        }
        // End Sub
    };

    // [978] Sub AddContentListReverse(lst As List) 
    this.addcontentlistreverse = function (_lst) {
        if (self == null) self = this;
        var _ltot;
        var _lcnt;
        var _strcontent;
        // [979]  Dim lTot As Int = lst.Size - 1 
        _ltot = _lst.length - 1;
        // [980]  Dim lCnt As Int 
        _lcnt = 0;
        // [981]  For lCnt = lTot To 0 Step -1 
        for (_lcnt = _ltot; _lcnt >= 0; _lcnt -= 1) {
            // [982]  Dim strContent As String = lst.Get(lCnt) 
            _strcontent = _lst[_lcnt];
            // [983]  AddContent(strContent) 
            self.addcontent(_strcontent);
            // [984]  Next 
        }
        // End Sub
    };

    // [988] Sub AddImage1(row As Int,column As Int, imgID As String,imgURL As String,imgAlt As String,imgCircle As Boolean,imgZDepth As String,bStatic As Boolean,bFixSize As Boolean,bResponsive As Boolean,imgHeight As String,imgWidth As String,cClass As String,cVisibility As String) 
    this.addimage1 = function (_row, _column, _imgid, _imgurl, _imgalt, _imgcircle, _imgzdepth, _bstatic, _bfixsize, _bresponsive, _imgheight, _imgwidth, _cclass, _cvisibility) {
        if (self == null) self = this;
        var _imgx;
        // [989]  imgID = imgID.ToLowerCase 
        _imgid = _imgid.toLowerCase();
        // [990]  Dim imgx As UOEImage 
        _imgx = new banano_uoebanano_uoeimage();
        // [991]  imgx.Initialize(App,imgID,imgURL,imgAlt,bStatic) 
        _imgx.initialize(self._app, _imgid, _imgurl, _imgalt, _bstatic);
        // [992]  imgx.ZDepth = imgZDepth 
        _imgx._zdepth = _imgzdepth;
        // [993]  imgx.Circle = imgCircle 
        _imgx._circle = _imgcircle;
        // [994]  imgx.Responsive = bResponsive 
        _imgx._responsive = _bresponsive;
        // [995]  imgx.MaterialBoxed = bResponsive 
        _imgx._materialboxed = _bresponsive;
        // [996]  imgx.AddClass(cClass) 
        _imgx.addclass(_cclass);
        // [997]  imgx.Visibility = cVisibility 
        _imgx._visibility = _cvisibility;
        // [998]  If bFixSize Then 
        if (_bfixsize) {
            // [999]  imgx.SetSize(imgHeight,imgWidth) 
            _imgx.setsize(_imgheight, _imgwidth);
            // [1000]  End If 
        }
        // [1001]  AddImage(row,column,imgx) 
        self.addimage(_row, _column, _imgx);
        // End Sub
    };

}
// =========================== UOECopyRights  ===========================
function banano_uoebanano_uoecopyrights() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._copyright = '';

    this._links = [];

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._visibility = '';

    // [13] Sub AddStyleAttribute(attribute As String, value As String) As UOECopyRights 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [14]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [15]  Return Me 
        return self;
        // End Sub
    };

    // [20] Public Sub Initialize(thisApp As UOEApp,sTheme As String, sClass As String) 
    this.initialize = function (_thisapp, _stheme, _sclass) {
        if (self == null) self = this;
        // [21]  App = thisApp 
        self._app = _thisapp;
        // [22]  Theme = sTheme 
        self._theme = _stheme;
        // [23]  CopyRight = App.Copyrights 
        self._copyright = self._app._copyrights;
        // [24]  Element.Initialize( {0} , {1} ) 
        self._element.initialize("", "div");
        // [25]  Element.AddClass( {2} ).addClass(sClass) 
        self._element.addclass("footer-copyright").addclass(_sclass);
        // [26]  Links.Initialize 
        self._links.length = 0;
        // [27]  Links.clear 
        self._links.length = 0;
        // End Sub
    };

    // [31] Sub AddTermsAndConditions() As UOECopyRights 
    this.addtermsandconditions = function () {
        if (self == null) self = this;
        // [32]  AddLink( {3} , {4} ,App.TermsAndConditionsURL, {5} ) 
        self.addlink("footerts", "Terms and Conditions{NBSP}|", self._app._termsandconditionsurl, "");
        // [33]  Return Me 
        return self;
        // End Sub
    };

    // [37] Sub AddDisclaimer() As UOECopyRights 
    this.adddisclaimer = function () {
        if (self == null) self = this;
        // [38]  AddLink( {6} , {7} ,App.DisclaimerURL, {8} ) 
        self.addlink("footerdisclaimer", "{NBSP}Disclaimer{NBSP}|", self._app._disclaimerurl, "");
        // [39]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub AddPrivacyPolicy() As UOECopyRights 
    this.addprivacypolicy = function () {
        if (self == null) self = this;
        // [44]  AddLink( {9} , {10} ,App.PrivacyPolicyURL, {11} ) 
        self.addlink("footerprivacy", "{NBSP}Privacy Policy", self._app._privacypolicyurl, "");
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [49] Sub AddClass(sClass As String) As UOECopyRights 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [50]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveClass(sClass As String) As UOECopyRights 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [56]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub AddAttribute(attr As String, value As String) As UOECopyRights 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [62]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [63]  Return Me 
        return self;
        // End Sub
    };

    // [67] Sub RemoveAttribute(attr As String) As UOECopyRights 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [68]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [73] Sub AddLink(lnkID As String, lnkText As String, lnkURL As String, lnkTheme As String) As UOECopyRights 
    this.addlink = function (_lnkid, _lnktext, _lnkurl, _lnktheme) {
        if (self == null) self = this;
        var _a;
        // [74]  Dim a As UOEAnchorIcon 
        _a = new banano_uoebanano_uoeanchoricon();
        // [75]  a.Initialize(App,lnkID, {12} , {13} ,False,lnkText,lnkURL,True,lnkTheme, {14} ) 
        _a.initialize(self._app, _lnkid, "", "", false, _lnktext, _lnkurl, true, _lnktheme, "");
        // [76]  a.a.AddClass( {15} ) 
        _a._a.addclass("right");
        // [77]  Links.Add(a.tostring) 
        self._links.push(_a.tostring());
        // [78]  Return Me 
        return self;
        // End Sub
    };

    // [82] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _pcont;
        // [83]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [84]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [85]  Dim pcont As UOEHTML 
        _pcont = new banano_uoebanano_uoehtml();
        // [86]  pcont.Initialize( {16} , {17} ) 
        _pcont.initialize("", "div");
        // [87]  pcont.AddClass( {18} ) 
        _pcont.addclass("container");
        // [88]  App.MaterialUseTheme(Theme,pcont) 
        self._app.materialusetheme(self._theme, _pcont);
        // [89]  If CopyRight <> {19} Then 
        if (self._copyright != "") {
            // [90]  pcont.AddContent( {20} ).AddContent(CopyRight) 
            _pcont.addcontent("© ").addcontent(self._copyright);
            // [91]  End If 
        }
        // [92]  pcont.AddContentListReverse(Links) 
        _pcont.addcontentlistreverse(self._links);
        // [93]  Element.AddElement(pcont) 
        self._element.addelement(_pcont);
        // [98]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEDatePicker  ===========================
function banano_uoebanano_uoedatepicker() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._title = '';

    this._theme = '';

    this._enabled = false;

    this._iconname = '';

    this._visibility = '';

    this._element = new banano_uoebanano_uoehtml();

    this._displaytype = '';

    this._autoclose = false;

    this._datetimeformat = '';

    this._defaultdate = '';

    this._setdefaultdate = false;

    this._disableweekends = false;

    this._firstday = 0;

    this._yearrange = 0;

    this._showmonthafteryear = false;

    this._showdaysinnextandpreviousmonths = false;

    this._showclearbtn = false;

    this._twelvehour = false;

    this._defaulttime = '';

    this._vibrate = false;

    this._timeformat = '';

    this._timeview = '';

    this._instance = '';

    this._settings = '';

    // [33] Sub AddStyleAttribute(attribute As String, value As String) 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [34]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // End Sub
    };

    // [39] Sub AddClass(sClass As String) 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [40]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // End Sub
    };

    // [44] Sub RemoveClass(sClass As String) 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [45]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // End Sub
    };

    // [49] Sub AddAttribute(attr As String, value As String) 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [50]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // End Sub
    };

    // [54] Sub RemoveAttribute(attr As String) 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [55]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // End Sub
    };

    // [59] Public Sub Initialize(thisApp As UOEApp, sID As String,sTitle As String, sDisplayType As String, sTHeme As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _sdisplaytype, _stheme) {
        if (self == null) self = this;
        // [61]  App = thisApp 
        self._app = _thisapp;
        // [62]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [63]  Enabled = True 
        self._enabled = true;
        // [64]  Element.Initialize(ID, {9} ) 
        self._element.initialize(self._id, "input");
        // [65]  Element.SetTYPE( {10} ) 
        self._element.settype("text");
        // [66]  DisplayType = sDisplayType 
        self._displaytype = _sdisplaytype;
        // [67]  autoClose = False 
        self._autoclose = false;
        // [68]  DateTimeFormat = {11} 
        self._datetimeformat = "yyyy-mm-dd";
        // [69]  TimeFormat = {12} 
        self._timeformat = "HH:mm";
        // [70]  Title = sTitle 
        self._title = _stitle;
        // [71]  Theme = sTHeme 
        self._theme = _stheme;
        // [72]  Enabled = True 
        self._enabled = true;
        // [73]  IconName = {13} 
        self._iconname = "";
        // [74]  defaultDate = {14} 
        self._defaultdate = "now";
        // [75]  disableWeekends = False 
        self._disableweekends = false;
        // [76]  firstDay = 0 
        self._firstday = 0;
        // [77]  yearRange = 10 
        self._yearrange = 10;
        // [78]  showMonthAfterYear = True 
        self._showmonthafteryear = true;
        // [79]  showDaysInNextAndPreviousMonths = True 
        self._showdaysinnextandpreviousmonths = true;
        // [80]  showClearBtn = True 
        self._showclearbtn = true;
        // [81]  defaultTime = {15} 
        self._defaulttime = "now";
        // [82]  vibrate = True 
        self._vibrate = true;
        // [83]  twelveHour = False 
        self._twelvehour = false;
        // [84]  setDefaultDate = True 
        self._setdefaultdate = true;
        // [85]  TimeView = {16} 'minutes 
        self._timeview = "hours";
        // [86]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [89] public Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _dpsettings;
        var _strds;
        // [90]  Dim dpSettings As Map 
        _dpsettings = {};
        // [91]  dpSettings.Initialize 
        _dpsettings = {};
        // [92]  dpSettings.clear 
        _dpsettings = {};
        // [93]  dpSettings.Put( {17} , ID) 
        _dpsettings["id"] = self._id;
        // [94]  dpSettings.Put( {18} , DisplayType) 
        _dpsettings["instance"] = self._displaytype;
        // [95]  dpSettings.Put( {19} , DisplayType) 
        _dpsettings["displayType"] = self._displaytype;
        // [96]  dpSettings.Put( {20} , showClearBtn) 
        _dpsettings["showClearBtn"] = self._showclearbtn;
        // [97]  dpSettings.Put( {21} , showDaysInNextAndPreviousMonths) 
        _dpsettings["showDaysInNextAndPreviousMonths"] = self._showdaysinnextandpreviousmonths;
        // [98]  dpSettings.Put( {22} , showMonthAfterYear) 
        _dpsettings["showMonthAfterYear"] = self._showmonthafteryear;
        // [99]  dpSettings.Put( {23} , yearRange) 
        _dpsettings["yearRange"] = self._yearrange;
        // [100]  dpSettings.Put( {24} , firstDay) 
        _dpsettings["firstDay"] = self._firstday;
        // [101]  dpSettings.Put( {25} , disableWeekends) 
        _dpsettings["disableWeekends"] = self._disableweekends;
        // [102]  dpSettings.Put( {26} , setDefaultDate) 
        _dpsettings["setDefaultDate"] = self._setdefaultdate;
        // [103]  dpSettings.Put( {27} , DateTimeFormat) 
        _dpsettings["format"] = self._datetimeformat;
        // [104]  dpSettings.Put( {28} , autoClose) 
        _dpsettings["autoClose"] = self._autoclose;
        // [105]  dpSettings.Put( {29} , twelveHour) 
        _dpsettings["twelveHour"] = self._twelvehour;
        // [106]  dpSettings.Put( {30} , defaultTime) 
        _dpsettings["defaultTime"] = self._defaulttime;
        // [107]  dpSettings.Put( {31} , vibrate) 
        _dpsettings["vibrate"] = self._vibrate;
        // [108]  dpSettings.Put( {32} , TimeView) 
        _dpsettings["TimeView"] = self._timeview;
        // [109]  Dim strDS As String = App.Map2JSON(dpSettings) 
        _strds = self._app.map2json(_dpsettings);
        // [110]  Return strDS 
        return _strds;
        // End Sub
    };

    // [114] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _div;
        var _lbl;
        // [115]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [116]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [117]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [118]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [119]  Element.AddClass(DisplayType) 
        self._element.addclass(self._displaytype);
        // [120]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [121]  div.Initialize(ID & {33} , {34} ) 
        _div.initialize(self._id + "div", "div");
        // [122]  div.AddClass( {35} ) 
        _div.addclass("input-field");
        // [123]  div.AddClass( {36} ).AddClass( {37} ).AddClass( {38} ).AddClass( {39} ) 
        _div.addclass("col").addclass("s12").addclass("m12").addclass("l12");
        // [124]  div.AddElement(Element) 
        _div.addelement(self._element);
        // [126]  Dim lbl As UOEHTML 
        _lbl = new banano_uoebanano_uoehtml();
        // [127]  lbl.Initialize(ID & {40} , {41} ) 
        _lbl.initialize(self._id + "lbl", "label");
        // [128]  lbl.SetFOR(ID).AddContent(Title).AddClass( {42} ) 
        _lbl.setfor(self._id).addcontent(self._title).addclass("active");
        // [129]  div.AddElement(lbl) 
        _div.addelement(_lbl);
        // [130]  Select Case DisplayType 
        switch ("" + self._displaytype) {
            // [131]  Case App.EnumDateTimeType.datepicker 
            case "" + self._app._enumdatetimetype._datepicker:
                // [135]  Case App.EnumDateTimeType.timepicker 
                break;
            case "" + self._app._enumdatetimetype._timepicker:
                // [139]  End Select 
                break;
        }
        // [145]  Return div.html 
        return _div.html();
        // End Sub
    };

    // [159] Sub GetDate(varName As String) As String 
    this.getdate = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [160]  Dim script As String = {5} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + _varname + " = " + self._instance + ".toString();";
        // [161]  Return script 
        return _script;
        // End Sub
    };

    // [165] Sub GetTime(varName As String) As String 
    this.gettime = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [166]  Dim script As String = {6} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Timepicker.getInstance(inst" + self._id + "); \n	" + _varname + " = " + self._instance + ".time();";
        // [167]  Return script 
        return _script;
        // End Sub
    };

    // [172] Sub SetDate(varName As String) As String 
    this.setdate = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [173]  Dim script As String = {7} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + self._instance + ".setDate(" + _varname + ");";
        // [174]  Return script 
        return _script;
        // End Sub
    };

    // [178] Sub GoToDate(varName As String) As String 
    this.gotodate = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [179]  Dim script As String = {8} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + self._instance + ".gotoDate(" + _varname + ");";
        // [180]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOEDivider  ===========================
function banano_uoebanano_uoedivider() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._visibility = '';

    this._theme = '';

    this._element = new banano_uoebanano_uoehtml();

    // [12] Sub AddStyleAttribute(attribute As String, value As String) As UOEDivider 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [13]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [14]  Return Me 
        return self;
        // End Sub
    };

    // [18] Sub AddClass(sClass As String) As UOEDivider 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [19]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [20]  Return Me 
        return self;
        // End Sub
    };

    // [24] Sub RemoveClass(sClass As String) As UOEDivider 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [25]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Sub AddAttribute(attr As String, value As String) As UOEDivider 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [31]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Sub RemoveAttribute(attr As String) As UOEDivider 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [37]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [38]  Return Me 
        return self;
        // End Sub
    };

    // [42] Sub Initialize(thisApp As UOEApp, sid As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _themename) {
        if (self == null) self = this;
        // [44]  App = thisApp 
        self._app = _thisapp;
        // [45]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [46]  Visibility = {0} 
        self._visibility = "";
        // [47]  Theme = themeName 
        self._theme = _themename;
        // [48]  Element.Initialize(sid, {1} ) 
        self._element.initialize(_sid, "div");
        // [49]  Element.AddClass( {2} ) 
        self._element.addclass("divider");
        // End Sub
    };

    // [53] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [54]  Element.ID = ID 
        self._element._id = self._id;
        // [55]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [56]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

}
// =========================== UOETabs  ===========================
function banano_uoebanano_uoetabs() {
    var self;
    this._id = '';

    this._theme = '';

    this._app = new banano_uoebanano_uoeapp();

    this._visibility = '';

    this._enabled = false;

    this._el = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._tabs = [];

    this._zdepth = '';

    this._pdiv = new banano_uoebanano_uoehtml();

    this._instance = '';

    this._swipeable = false;

    // [21] Sub AddStyleAttribute(attribute As String, value As String) As UOETabs 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [22]  el.AddStyleAttribute(attribute,value) 
        self._el.addstyleattribute(_attribute, _value);
        // [23]  Return Me 
        return self;
        // End Sub
    };

    // [27] Public Sub Initialize(thisApp As UOEApp, sID As String, fixedWidth As Boolean, themeName As String, cClass As String) 
    this.initialize = function (_thisapp, _sid, _fixedwidth, _themename, _cclass) {
        if (self == null) self = this;
        // [28]  App = thisApp 
        self._app = _thisapp;
        // [29]  ID = sID.ToLowerCase 
        self._id = _sid.toLowerCase();
        // [30]  el.Initialize(ID, {12} ) 
        self._el.initialize(self._id, "ul");
        // [31]  el.AddClass( {13} ) 
        self._el.addclass("tabs");
        // [32]  el.AddClassOnCondition(fixedWidth, {14} ) 
        self._el.addclassoncondition(_fixedwidth, "tabs-fixed-width tab-demo");
        // [33]  pdiv.Initialize(ID & {15} , {16} ) 
        self._pdiv.initialize(self._id + "parent", "div");
        // [34]  pdiv.AddClass(cClass) 
        self._pdiv.addclass(_cclass);
        // [35]  Enabled = True 
        self._enabled = true;
        // [36]  tabs.Initialize 
        self._tabs.length = 0;
        // [37]  tabs.clear 
        self._tabs.length = 0;
        // [38]  ZDepth = {17} 
        self._zdepth = "";
        // [39]  Theme = themeName 
        self._theme = _themename;
        // [40]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // [41]  swipeable = True 
        self._swipeable = true;
        // End Sub
    };

    // [58] Sub GetTabID(stabid As String) As String 
    this.gettabid = function (_stabid) {
        if (self == null) self = this;
        // [59]  Return {2} 
        return "tab" + self._id + "" + _stabid + "a";
        // End Sub
    };

    // [64] Sub AddTab(TabID As String,tabTitle As String,tabActive As Boolean,tabDisabled As Boolean,SizeSmall As Int, SizeMedium As Int,SizeLarge As Int, cont As UOEContainer) 
    this.addtab = function (_tabid, _tabtitle, _tabactive, _tabdisabled, _sizesmall, _sizemedium, _sizelarge, _cont) {
        if (self == null) self = this;
        var _skey;
        var _tabkey;
        var _tabkeya;
        var _li;
        var _a;
        var _tabdiv;
        // [65]  Dim sKey As String = {3} 
        _skey = "" + self._id + "" + _tabid + "";
        // [66]  Dim tabKey As String = {4} 
        _tabkey = "tab" + self._id + "" + _tabid + "";
        // [67]  Dim tabKeyA As String = {5} 
        _tabkeya = "tab" + self._id + "" + _tabid + "a";
        // [68]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [69]  li.Initialize(sKey, {18} ) 
        _li.initialize(_skey, "li");
        // [70]  li.AddClass( {19} ) 
        _li.addclass("tab");
        // [71]  li.AddClass( {20} ).AddClass( {21} & SizeSmall).AddClass( {22} & SizeMedium).AddClass( {23} & SizeLarge) 
        _li.addclass("col").addclass("s" + _sizesmall).addclass("m" + _sizemedium).addclass("l" + _sizelarge);
        // [72]  li.AddClassOnCondition(tabDisabled, {24} ) 
        _li.addclassoncondition(_tabdisabled, "disabled");
        // [73]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [74]  a.Initialize(tabKeyA, {25} ) 
        _a.initialize(_tabkeya, "a");
        // [75]  a.SetHREF( {26} & tabKey) 
        _a.sethref("#" + _tabkey);
        // [76]  a.AddContent(tabTitle) 
        _a.addcontent(_tabtitle);
        // [77]  a.AddClassOnCondition(tabActive, {27} ) 
        _a.addclassoncondition(_tabactive, "active");
        // [78]  App.MaterialUseTheme(Theme,a) 
        self._app.materialusetheme(self._theme, _a);
        // [79]  li.AddElement(a) 
        _li.addelement(_a);
        // [80]  el.AddElement(li) 
        self._el.addelement(_li);
        // [82]  Dim tabdiv As UOEHTML 
        _tabdiv = new banano_uoebanano_uoehtml();
        // [83]  tabdiv.Initialize(tabKey, {28} ) 
        _tabdiv.initialize(_tabkey, "div");
        // [84]  tabdiv.AddClass( {29} ).AddClass( {30} ) 
        _tabdiv.addclass("col").addclass("s12");
        // [85]  If cont <> Null Then 
        if (_cont != null) {
            // [86]  tabdiv.AddContent(cont.tostring) 
            _tabdiv.addcontent(_cont.tostring());
            // [87]  End If 
        }
        // [88]  tabs.Add(tabdiv.html) 
        self._tabs.push(_tabdiv.html());
        // End Sub
    };

    // [92] Sub AddTabExternal(TabID As String,tabTitle As String,tabActive As Boolean,tabDisabled As Boolean,SizeSmall As Int, SizeMedium As Int,SizeLarge As Int, URL As String,Target As String) 
    this.addtabexternal = function (_tabid, _tabtitle, _tabactive, _tabdisabled, _sizesmall, _sizemedium, _sizelarge, _url, _target) {
        if (self == null) self = this;
        var _skey;
        var _tabkeya;
        var _li;
        var _a;
        // [93]  Dim sKey As String = {6} 
        _skey = "" + self._id + "" + _tabid + "";
        // [94]  Dim tabKeyA As String = {7} 
        _tabkeya = "tab" + self._id + "" + _tabid + "a";
        // [96]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [97]  li.Initialize(sKey, {31} ) 
        _li.initialize(_skey, "li");
        // [98]  li.AddClass( {32} ) 
        _li.addclass("tab");
        // [99]  li.AddClass( {33} ).AddClass( {34} & SizeSmall).AddClass( {35} & SizeMedium).AddClass( {36} & SizeLarge) 
        _li.addclass("col").addclass("s" + _sizesmall).addclass("m" + _sizemedium).addclass("l" + _sizelarge);
        // [100]  li.AddClassOnCondition(tabDisabled, {37} ) 
        _li.addclassoncondition(_tabdisabled, "disabled");
        // [101]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [102]  a.Initialize(tabKeyA, {38} ) 
        _a.initialize(_tabkeya, "a");
        // [103]  a.SetHREF(URL).AddContent(tabTitle).AddClassOnCondition(tabActive, {39} ) 
        _a.sethref(_url).addcontent(_tabtitle).addclassoncondition(_tabactive, "active");
        // [104]  App.MaterialUseTheme(Theme,a) 
        self._app.materialusetheme(self._theme, _a);
        // [105]  li.AddElement(a) 
        _li.addelement(_a);
        // [106]  el.AddElement(li) 
        self._el.addelement(_li);
        // End Sub
    };

    // [118] public Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _dpsettings;
        var _strds;
        // [119]  Dim dpSettings As Map 
        _dpsettings = {};
        // [120]  dpSettings.Initialize 
        _dpsettings = {};
        // [121]  dpSettings.clear 
        _dpsettings = {};
        // [122]  dpSettings.Put( {42} , ID) 
        _dpsettings["id"] = self._id;
        // [123]  dpSettings.Put( {43} , {44} ) 
        _dpsettings["instance"] = "tabs";
        // [124]  dpSettings.Put( {45} , swipeable) 
        _dpsettings["swipeable"] = self._swipeable;
        // [125]  Dim strDS As String = App.Map2JSON(dpSettings) 
        _strds = self._app.map2json(_dpsettings);
        // [126]  Return strDS 
        return _strds;
        // End Sub
    };

    // [131] Sub SelectTab(TabID As String) 
    this.selecttab = function (_tabid) {
        if (self == null) self = this;
        var _skey;
        var _script;
        // [132]  Dim sKey As String = {10} 
        _skey = "" + self._id + "" + _tabid + "";
        // [133]  Dim script As String = {11} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Tabs.getInstance(inst" + self._id + "); \n	" + self._instance + ".select('" + _skey + "'); \n	" + self._instance + ".updateTabIndicator();";
        // [134]  Banano.eval(script) 
        eval(_script);
        // End Sub
    };

    // [139] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [140]  el.ID = ID 
        self._el._id = self._id;
        // [141]  el.MaterialEnable(Enabled).MaterialVisibility(Visibility).MaterialZDepth(ZDepth) 
        self._el.materialenable(self._enabled).materialvisibility(self._visibility).materialzdepth(self._zdepth);
        // [142]  pdiv.AddElement(el) 
        self._pdiv.addelement(self._el);
        // [143]  pdiv.AddContentList(tabs) 
        self._pdiv.addcontentlist(self._tabs);
        // [148]  App.ApplyToolTip(ID,pdiv) 
        self._app.applytooltip(self._id, self._pdiv);
        // [149]  Return pdiv.html 
        return self._pdiv.html();
        // End Sub
    };

    // [153] Sub AddClass(sClass As String) As UOETabs 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [154]  el.AddClass(sClass) 
        self._el.addclass(_sclass);
        // [155]  Return Me 
        return self;
        // End Sub
    };

    // [159] Sub RemoveClass(sClass As String) As UOETabs 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [160]  el.RemoveClass(sClass) 
        self._el.removeclass(_sclass);
        // [161]  Return Me 
        return self;
        // End Sub
    };

    // [165] Sub AddAttribute(attr As String, value As String) As UOETabs 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [166]  el.AddAttribute(attr,value) 
        self._el.addattribute(_attr, _value);
        // [167]  Return Me 
        return self;
        // End Sub
    };

    // [171] Sub RemoveAttribute(attr As String) As UOETabs 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [172]  el.RemoveAttribute(attr) 
        self._el.removeattribute(_attr);
        // [173]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEDropDown  ===========================
function banano_uoebanano_uoedropdown() {
    var self;
    this._id = '';

    this._text = '';

    this._iconname = '';

    this._theme = '';

    this._dp = new banano_uoebanano_uoehtml();

    this._a = new banano_uoebanano_uoehtml();

    this._app = new banano_uoebanano_uoeapp();

    this._zdepth = '';

    this._visibility = '';

    this._enabled = false;

    this._dropdownitems = {};

    this._isbutton = false;

    this._hoverable = false;

    this._constrainwidth = false;

    this._covertrigger = false;

    this._closeonclick = false;

    this._hover = false;

    this._instance = '';

    // [26] Sub AddStyleAttribute(attribute As String, value As String) As UOEDropDown 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [27]  dp.AddStyleAttribute(attribute,value) 
        self._dp.addstyleattribute(_attribute, _value);
        // [28]  Return Me 
        return self;
        // End Sub
    };

    // [32] Sub AddClass(sClass As String) As UOEDropDown 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [33]  dp.AddClass(sClass) 
        self._dp.addclass(_sclass);
        // [34]  Return Me 
        return self;
        // End Sub
    };

    // [38] Sub RemoveClass(sClass As String) As UOEDropDown 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [39]  dp.RemoveClass(sClass) 
        self._dp.removeclass(_sclass);
        // [40]  Return Me 
        return self;
        // End Sub
    };

    // [44] Sub AddAttribute(attr As String, value As String) As UOEDropDown 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [45]  dp.AddAttribute(attr,value) 
        self._dp.addattribute(_attr, _value);
        // [46]  Return Me 
        return self;
        // End Sub
    };

    // [50] Sub RemoveAttribute(attr As String) As UOEDropDown 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [51]  dp.RemoveAttribute(attr) 
        self._dp.removeattribute(_attr);
        // [52]  Return Me 
        return self;
        // End Sub
    };

    // [56] Public Sub Initialize(thisApp As UOEApp, itemID As String, itemText As String, itemVisibility As String, bIsButton As Boolean, bConstrainWidth As Boolean, itemTheme As String) 
    this.initialize = function (_thisapp, _itemid, _itemtext, _itemvisibility, _bisbutton, _bconstrainwidth, _itemtheme) {
        if (self == null) self = this;
        var _lst;
        // [58]  App = thisApp 
        self._app = _thisapp;
        // [59]  ID = itemID.tolowercase 
        self._id = _itemid.toLowerCase();
        // [60]  Text = itemText 
        self._text = _itemtext;
        // [61]  IconName = {10} 
        self._iconname = "keyboard_arrow_right";
        // [62]  Theme = itemTheme 
        self._theme = _itemtheme;
        // [63]  dp.Initialize(ID & {11} , {12} ) 
        self._dp.initialize(self._id + "li", "li");
        // [64]  a.Initialize(ID, {13} ) 
        self._a.initialize(self._id, "a");
        // [65]  App.MaterialUseTheme(itemTheme,a) 
        self._app.materialusetheme(_itemtheme, self._a);
        // [66]  a.MaterialVisibility(itemVisibility) 
        self._a.materialvisibility(_itemvisibility);
        // [67]  a.AddClass( {14} ).AddAttribute( {15} , {16} ) 
        self._a.addclass("dropdown-trigger").addattribute("href", "#");
        // [68]  a.AddAttribute( {17} ,ID & {18} ) 
        self._a.addattribute("data-target", self._id + "items");
        // [69]  constrainWidth = bConstrainWidth 
        self._constrainwidth = _bconstrainwidth;
        // [70]  IsButton = bIsButton 
        self._isbutton = _bisbutton;
        // [71]  If bIsButton = False Then 
        if (_bisbutton == false) {
            // [72]  a.AddStyleAttribute( {19} , {20} ) 
            self._a.addstyleattribute("text-align", "center");
            // [73]  End If 
        }
        // [76]  ZDepth= {24} 
        self._zdepth = "";
        // [77]  Visibility = itemVisibility 
        self._visibility = _itemvisibility;
        // [78]  coverTrigger = False 
        self._covertrigger = false;
        // [79]  Enabled = True 
        self._enabled = true;
        // [80]  DropDownItems.Initialize 
        self._dropdownitems = {};
        // [81]  DropDownItems.clear 
        self._dropdownitems = {};
        // [82]  closeOnClick = True 
        self._closeonclick = true;
        // [83]  hover = True 
        self._hover = true;
        // [84]  Dim lst As List 
        _lst = [];
        // [85]  lst.Initialize 
        _lst.length = 0;
        // [86]  lst.clear 
        _lst.length = 0;
        // [87]  DropDownItems.Put(ID,lst) 
        self._dropdownitems[self._id] = _lst;
        // [88]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [92] Sub AddContent(sContent As String) As UOEDropDown 
    this.addcontent = function (_scontent) {
        if (self == null) self = this;
        // [93]  dp.AddContent(sContent) 
        self._dp.addcontent(_scontent);
        // [94]  Return Me 
        return self;
        // End Sub
    };

    // [98] Sub AddDivider(themeName As String) As UOEDropDown 
    this.adddivider = function (_themename) {
        if (self == null) self = this;
        var _div;
        var _lstitems;
        // [99]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [100]  div.Initialize( {25} , {26} ) 
        _div.initialize("", "li");
        // [101]  div.AddClass( {27} ) 
        _div.addclass("divider");
        // [102]  App.MaterialUseTheme(themeName,div) 
        self._app.materialusetheme(_themename, _div);
        // [103]  If DropDownItems.ContainsKey(ID) Then 
        if ((self._id in self._dropdownitems)) {
            // [104]  Dim lstItems As List = DropDownItems.Get(ID) 
            _lstitems = self._dropdownitems[self._id];
            // [105]  lstItems.Add(div.html) 
            _lstitems.push(_div.html());
            // [106]  DropDownItems.Put(ID,lstItems) 
            self._dropdownitems[self._id] = _lstitems;
            // [107]  End If 
        }
        // [108]  Return Me 
        return self;
        // End Sub
    };

    // [112] Sub AddItem(itemID As String, itemIcon As String, itemText As String, itemNavigateTo As String, bhasDivider As Boolean, itemActive As Boolean, itemTheme As String) 
    this.additem = function (_itemid, _itemicon, _itemtext, _itemnavigateto, _bhasdivider, _itemactive, _itemtheme) {
        if (self == null) self = this;
        var _dpi;
        var _lstitems;
        // [113]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [114]  Dim dpi As UOEDropDownItem 
        _dpi = new banano_uoebanano_uoedropdownitem();
        // [115]  dpi.Initialize(App,ID,itemID,itemIcon,itemText,itemNavigateTo,itemActive,itemTheme) 
        _dpi.initialize(self._app, self._id, _itemid, _itemicon, _itemtext, _itemnavigateto, _itemactive, _itemtheme);
        // [116]  modUOE.MaterialAddBadge(App,dpi.ai.a, {28} ,False,App.EnumVisibility.hide,True, {29} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _dpi._ai._a, "", false, self._app._enumvisibility._hide, true, "", false);
        // [117]  dpi.li.MaterialAddDividerOnCondition(bhasDivider,App.EnumVisibility.visible,itemTheme) 
        _dpi._li.materialadddivideroncondition(_bhasdivider, self._app._enumvisibility._visible, _itemtheme);
        // [119]  If DropDownItems.ContainsKey(ID) Then 
        if ((self._id in self._dropdownitems)) {
            // [120]  Dim lstItems As List = DropDownItems.Get(ID) 
            _lstitems = self._dropdownitems[self._id];
            // [121]  lstItems.Add(dpi.tostring) 
            _lstitems.push(_dpi.tostring());
            // [122]  DropDownItems.Put(ID,lstItems) 
            self._dropdownitems[self._id] = _lstitems;
            // [123]  End If 
        }
        // End Sub
    };

    // [127] Sub AddItemBadge(itemID As String, itemText As String, href As String, itemActive As Boolean, badgeText As String, badgeNew As Boolean, bhasDivider As Boolean, itemTheme As String, badgeTheme As String) 
    this.additembadge = function (_itemid, _itemtext, _href, _itemactive, _badgetext, _badgenew, _bhasdivider, _itemtheme, _badgetheme) {
        if (self == null) self = this;
        var _dpi;
        var _lstitems;
        // [128]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [129]  Dim dpi As UOEDropDownItem 
        _dpi = new banano_uoebanano_uoedropdownitem();
        // [130]  dpi.Initialize(App,ID,itemID, {30} ,itemText,href,itemActive,itemTheme) 
        _dpi.initialize(self._app, self._id, _itemid, "", _itemtext, _href, _itemactive, _itemtheme);
        // [131]  modUOE.MaterialAddBadge(App,dpi.ai.a,badgeText,badgeNew,App.EnumVisibility.visible,True,badgeTheme,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _dpi._ai._a, _badgetext, _badgenew, self._app._enumvisibility._visible, true, _badgetheme, false);
        // [132]  dpi.li.MaterialAddDividerOnCondition(bhasDivider,App.EnumVisibility.visible,itemTheme) 
        _dpi._li.materialadddivideroncondition(_bhasdivider, self._app._enumvisibility._visible, _itemtheme);
        // [134]  If DropDownItems.ContainsKey(ID) Then 
        if ((self._id in self._dropdownitems)) {
            // [135]  Dim lstItems As List = DropDownItems.Get(ID) 
            _lstitems = self._dropdownitems[self._id];
            // [136]  lstItems.Add(dpi.tostring) 
            _lstitems.push(_dpi.tostring());
            // [137]  DropDownItems.Put(ID,lstItems) 
            self._dropdownitems[self._id] = _lstitems;
            // [138]  End If 
        }
        // End Sub
    };

    // [141] private Sub GetStructure(sout As String) As String 
    this.getstructure = function (_sout) {
        if (self == null) self = this;
        var _mains;
        var _sb;
        var _kcnt;
        var _ktot;
        var _drpitem;
        var _lstx;
        var _stritem;
        var _sb1;
        // [142]  Dim mains As String 
        _mains = '';
        // [143]  mains = sout 
        _mains = _sout;
        // [144]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [145]  sb.Initialize 
        _sb.isinitialized = true;
        // [146]  Dim kCnt As Int = 0 
        _kcnt = 0;
        // [147]  Dim kTot As Int = DropDownItems.Size - 1 
        _ktot = Object.keys(self._dropdownitems).length - 1;
        // [148]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [149]  Dim drpItem As String = DropDownItems.GetKeyAt(kCnt) 
            _drpitem = banano_getB4JKeyAt(self._dropdownitems, _kcnt);
            // [150]  Dim lstx As List = DropDownItems.Get(drpItem) 
            _lstx = self._dropdownitems[_drpitem];
            // [151]  Dim sb As StringBuilder 
            _sb = new StringBuilder();
            // [152]  sb.Initialize 
            _sb.isinitialized = true;
            // [153]  For Each stritem As String In lstx 
            for (var _stritemindex = 0; _stritemindex < _lstx.length; _stritemindex++) {
                _stritem = _lstx[_stritemindex];
                // [154]  sb.Append(stritem) 
                _sb.append(_stritem);
                // [155]  Next 
            }
            // [156]  Dim sb1 As String = sb.tostring 
            _sb1 = _sb.toString();
            // [157]  mains = mains.Replace(drpItem & {31} ,sb1) 
            _mains = _mains.split(_drpitem + "dropitems").join(_sb1);
            // [158]  Next 
        }
        // [159]  Return mains 
        return _mains;
        // End Sub
    };

    // [163] Sub Open As String 
    this.open = function () {
        if (self == null) self = this;
        var _script;
        // [164]  Dim script As String = {1} 
        _script = "" + self._instance + ".open();";
        // [165]  Return script 
        return _script;
        // End Sub
    };

    // [169] Sub Close As String 
    this.close = function () {
        if (self == null) self = this;
        var _script;
        // [170]  Dim script As String = {2} 
        _script = "" + self._instance + ".close();";
        // [171]  Return script 
        return _script;
        // End Sub
    };

    // [175] Sub Destroy As String 
    this.destroy = function () {
        if (self == null) self = this;
        var _script;
        // [176]  Dim script As String = {3} 
        _script = "" + self._instance + ".destroy();";
        // [177]  Return script 
        return _script;
        // End Sub
    };

    // [181] Sub recalculateDimensions As String 
    this.recalculatedimensions = function () {
        if (self == null) self = this;
        var _script;
        // [182]  Dim script As String = {4} 
        _script = "" + self._instance + ".recalculateDimensions();";
        // [183]  Return script 
        return _script;
        // End Sub
    };

    // [187] Sub focusedIndex(varName As String) As String 
    this.focusedindex = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [188]  Dim script As String = {5} 
        _script = "" + _varname + " = " + self._instance + ".focusedIndex;";
        // [189]  Return script 
        return _script;
        // End Sub
    };

    // [193] Sub dropdownEl(varName As String) As String 
    this.dropdownel = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [194]  Dim script As String = {6} 
        _script = "" + _varname + " = " + self._instance + ".dropdownEl;";
        // [195]  Return script 
        return _script;
        // End Sub
    };

    // [199] Sub isOpen(varName As String) As String 
    this.isopen = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [200]  Dim script As String = {7} 
        _script = "" + _varname + " = " + self._instance + ".isOpen;";
        // [201]  Return script 
        return _script;
        // End Sub
    };

    // [205] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _ul;
        var _sout;
        // [206]  a.ID = ID 
        self._a._id = self._id;
        // [207]  a.MaterialVisibility(Visibility) 
        self._a.materialvisibility(self._visibility);
        // [208]  a.MaterialZDepth(ZDepth) 
        self._a.materialzdepth(self._zdepth);
        // [209]  a.MaterialEnable(Enabled) 
        self._a.materialenable(self._enabled);
        // [210]  a.MaterialButton(IsButton) 
        self._a.materialbutton(self._isbutton);
        // [211]  a.addcontent(Text) 
        self._a.addcontent(self._text);
        // [212]  modUOE.MaterialAddIcon(App,a,IconName, {32} ,Theme,False,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._a, self._iconname, "right", self._theme, false, false, false, false, false);
        // [213]  App.MaterialUseTheme(Theme,a) 
        self._app.materialusetheme(self._theme, self._a);
        // [214]  dp.Addelement(a) 
        self._dp.addelement(self._a);
        // [216]  Dim ul As UOEHTML 
        _ul = new banano_uoebanano_uoehtml();
        // [217]  ul.Initialize(ID & {33} , {34} ) 
        _ul.initialize(self._id + "items", "ul");
        // [218]  ul.AddClass( {35} ) 
        _ul.addclass("dropdown-content");
        // [219]  ul.AddContent(ID & {36} ) 
        _ul.addcontent(self._id + "dropitems");
        // [220]  dp.AddElement(ul) 
        self._dp.addelement(_ul);
        // [221]  dp.SetElementTypeOnCondition(IsButton, {37} ) 
        self._dp.setelementtypeoncondition(self._isbutton, "div");
        // [222]  Dim sout As String = dp.html 
        _sout = self._dp.html();
        // [223]  sout = GetStructure(sout) 
        _sout = self.getstructure(_sout);
        // [224]  sout = sout.Replace(CRLF, {38} ) 
        _sout = _sout.split("\n").join("");
        // [229]  App.ApplyToolTip(ID,dp) 
        self._app.applytooltip(self._id, self._dp);
        // [230]  Return sout 
        return _sout;
        // End Sub
    };

    // [234] private Sub InjectJS() 
    this.injectjs = function () {
        if (self == null) self = this;
        // End Sub
    };

    // [243] Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _mset;
        var _sset;
        // [244]  Dim mset As Map 
        _mset = {};
        // [245]  mset.Initialize 
        _mset = {};
        // [246]  mset.clear 
        _mset = {};
        // [247]  mset.Put( {49} , ID) 
        _mset["id"] = self._id;
        // [248]  mset.Put( {50} , {51} ) 
        _mset["instance"] = "dropdown";
        // [249]  mset.Put( {52} , hover) 
        _mset["hover"] = self._hover;
        // [250]  mset.Put( {53} , closeOnClick) 
        _mset["closeOnClick"] = self._closeonclick;
        // [251]  mset.Put( {54} , coverTrigger) 
        _mset["coverTrigger"] = self._covertrigger;
        // [252]  mset.Put( {55} , constrainWidth) 
        _mset["constrainWidth"] = self._constrainwidth;
        // [253]  Dim sset As String = App.Map2Json(mset) 
        _sset = self._app.map2json(_mset);
        // [254]  Return sset 
        return _sset;
        // End Sub
    };

}
// =========================== UOEDropDownItem  ===========================
function banano_uoebanano_uoedropdownitem() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._li = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._itemkey = '';

    this._href = '';

    this._text = '';

    this._enabled = false;

    this._icon = '';

    this._ai = new banano_uoebanano_uoeanchoricon();

    this._hoverable = false;

    // [18] Sub AddStyleAttribute(attribute As String, value As String) As UOEDropDownItem 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [19]  ai.AddStyleAttribute(attribute,value) 
        self._ai.addstyleattribute(_attribute, _value);
        // [20]  Return Me 
        return self;
        // End Sub
    };

    // [24] Sub AddClass(sClass As String) As UOEDropDownItem 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [25]  ai.AddClass(sClass) 
        self._ai.addclass(_sclass);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Sub RemoveClass(sClass As String) As UOEDropDownItem 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [31]  ai.RemoveClass(sClass) 
        self._ai.removeclass(_sclass);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Sub AddAttribute(attr As String, value As String) As UOEDropDownItem 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [37]  ai.AddAttribute(attr,value) 
        self._ai.addattribute(_attr, _value);
        // [38]  Return Me 
        return self;
        // End Sub
    };

    // [42] Sub RemoveAttribute(attr As String) As UOEDropDownItem 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [43]  ai.RemoveAttribute(attr) 
        self._ai.removeattribute(_attr);
        // [44]  Return Me 
        return self;
        // End Sub
    };

    // [48] Public Sub Initialize(thisApp As UOEApp,parentID As String, itemID As String, itemIcon As String, itemText As String, itemNavigateTo As String, itemActive As Boolean, itemTheme As String) As UOEHTML 
    this.initialize = function (_thisapp, _parentid, _itemid, _itemicon, _itemtext, _itemnavigateto, _itemactive, _itemtheme) {
        if (self == null) self = this;
        // [50]  App = thisApp 
        self._app = _thisapp;
        // [51]  parentID = parentID.ToLowerCase 
        _parentid = _parentid.toLowerCase();
        // [52]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [53]  ID = itemID 
        self._id = _itemid;
        // [54]  Icon = itemIcon 
        self._icon = _itemicon;
        // [55]  ItemKey = parentID & itemID 
        self._itemkey = _parentid + _itemid;
        // [56]  href = itemNavigateTo 
        self._href = _itemnavigateto;
        // [57]  Text = itemText 
        self._text = _itemtext;
        // [58]  li.Initialize(ItemKey & {0} , {1} ) 
        self._li.initialize(self._itemkey + "li", "li");
        // [59]  If itemActive = True Then 
        if (_itemactive == true) {
            // [60]  li.AddClass( {2} ) 
            self._li.addclass("active");
            // [61]  End If 
        }
        // [62]  Theme = itemTheme 
        self._theme = _itemtheme;
        // [63]  Enabled = False 
        self._enabled = false;
        // [64]  ai.Initialize(App,ItemKey,Icon, {3} ,False,Text,href,True,Theme, {4} ) 
        self._ai.initialize(self._app, self._itemkey, self._icon, "left", false, self._text, self._href, true, self._theme, "");
        // [65]  ai.a.materialenable(Enabled) 
        self._ai._a.materialenable(self._enabled);
        // [66]  Return li 
        return self._li;
        // End Sub
    };

    // [70] Sub SetToolTip(position As String, delay As String, tooltip As String) 
    this.settooltip = function (_position, _delay, _tooltip) {
        if (self == null) self = this;
        // [71]  ai.a.MaterialSetToolTip(position,delay,tooltip) 
        self._ai._a.materialsettooltip(_position, _delay, _tooltip);
        // End Sub
    };

    // [75] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [77]  ai.ID = ItemKey 
        self._ai._id = self._itemkey;
        // [78]  ai.Text = Text 
        self._ai._text = self._text;
        // [79]  ai.href = href 
        self._ai._href = self._href;
        // [80]  ai.a.MaterialEnable(Enabled) 
        self._ai._a.materialenable(self._enabled);
        // [81]  App.MaterialUseTheme(Theme,ai.a) 
        self._app.materialusetheme(self._theme, self._ai._a);
        // [82]  li.AddContent(ai.tostring) 
        self._li.addcontent(self._ai.tostring());
        // [83]  Return li.html 
        return self._li.html();
        // End Sub
    };

}
// =========================== UOEFAB  ===========================
function banano_uoebanano_uoefab() {
    var self;
    this._ai = new banano_uoebanano_uoeanchoricon();

    this._id = '';

    this._app = new banano_uoebanano_uoeapp();

    this._href = '';

    this._iconname = '';

    this._icontheme = '';

    this._theme = '';

    this._pulse = false;

    this._zdepth = '';

    this._visibility = '';

    this._size = '';

    this._click2toggle = false;

    this._buttons = [];

    this._direction = '';

    this._hoverenabled = false;

    this._toolbarenabled = false;

    this._instance = '';

    // [25] Sub AddStyleAttribute(attribute As String, value As String) As UOEFAB 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [26]  ai.AddStyleAttribute(attribute,value) 
        self._ai.addstyleattribute(_attribute, _value);
        // [27]  Return Me 
        return self;
        // End Sub
    };

    // [32] Public Sub Initialize(thisApp As UOEApp, sID As String, shref As String, sIconName As String, sSize As String, sVisibility As String, sIconTheme As String) 
    this.initialize = function (_thisapp, _sid, _shref, _siconname, _ssize, _svisibility, _sicontheme) {
        if (self == null) self = this;
        // [33]  If sIconTheme = {5} Then sIconTheme = {6} 
        if (_sicontheme == "") {
            _sicontheme = "white.lb";
        }
        // [34]  App = thisApp 
        self._app = _thisapp;
        // [35]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [36]  IconName = sIconName 
        self._iconname = _siconname;
        // [37]  IconTheme = sIconTheme 
        self._icontheme = _sicontheme;
        // [38]  href = shref 
        self._href = _shref;
        // [39]  ZDepth= {7} 
        self._zdepth = "";
        // [40]  Size = sSize 
        self._size = _ssize;
        // [41]  Click2Toggle =False 
        self._click2toggle = false;
        // [42]  ai.Initialize(App,ID,IconName, {8} ,False, {9} ,href,False,sIconTheme, {10} ) 
        self._ai.initialize(self._app, self._id, self._iconname, "", false, "", self._href, false, _sicontheme, "");
        // [43]  ai.Floating = True 
        self._ai._floating = true;
        // [44]  Theme = sIconTheme 
        self._theme = _sicontheme;
        // [45]  Direction = App.EnumFABDirection.Top 
        self._direction = self._app._enumfabdirection._top;
        // [46]  Visibility = sVisibility 
        self._visibility = _svisibility;
        // [47]  hoverEnabled = True 
        self._hoverenabled = true;
        // [48]  toolbarEnabled = False 
        self._toolbarenabled = false;
        // [49]  buttons.Initialize 
        self._buttons.length = 0;
        // [50]  buttons.clear 
        self._buttons.length = 0;
        // [51]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [55] Sub AddClass(sClass As String) As UOEFAB 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        var _bh;
        // [56]  ai.AddClass(sClass) 
        self._ai.addclass(_sclass);
        // [57]  Dim bh As Boolean = sClass.Contains( {11} ) 
        _bh = _sclass.contains("pulse");
        // [58]  If bh Then 
        if (_bh) {
            // [59]  Pulse = True 
            self._pulse = true;
            // [60]  End If 
        }
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [65] Sub RemoveClass(sClass As String) As UOEFAB 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [66]  ai.RemoveClass(sClass) 
        self._ai.removeclass(_sclass);
        // [67]  Return Me 
        return self;
        // End Sub
    };

    // [71] Sub AddAttribute(attr As String, value As String) As UOEFAB 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [72]  ai.AddAttribute(attr,value) 
        self._ai.addattribute(_attr, _value);
        // [73]  Return Me 
        return self;
        // End Sub
    };

    // [77] Sub RemoveAttribute(attr As String) As UOEFAB 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [78]  ai.RemoveAttribute(attr) 
        self._ai.removeattribute(_attr);
        // [79]  Return Me 
        return self;
        // End Sub
    };

    // [83] Sub AddButton(btnID As String, btnIcon As String, btnNav2 As String, btnTheme As String) 
    this.addbutton = function (_btnid, _btnicon, _btnnav2, _btntheme) {
        if (self == null) self = this;
        var _li;
        var _b;
        // [84]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [85]  li.Initialize( {12} , {13} ) 
        _li.initialize("", "li");
        // [86]  Dim b As UOEButton 
        _b = new banano_uoebanano_uoebutton();
        // [87]  b.Initialize(App,btnID, {14} ,btnTheme) 
        _b.initialize(self._app, _btnid, "", _btntheme);
        // [88]  b.Setbuttontype(App.EnumButtonType.floating) 
        _b.setbuttontype(self._app._enumbuttontype._floating);
        // [89]  b.href = btnNav2 
        _b._href = _btnnav2;
        // [90]  b.AddIcon(btnIcon, {15} ,btnTheme,False,False) 
        _b.addicon(_btnicon, "", _btntheme, false, false);
        // [91]  b.waveseffect = False 
        _b._waveseffect = false;
        // [92]  b.FitWidth = False 
        _b._fitwidth = false;
        // [93]  li.AddContent(b.tostring) 
        _li.addcontent(_b.tostring());
        // [94]  buttons.Add(li.html) 
        self._buttons.push(_li.html());
        // End Sub
    };

    // [99] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [100]  ai.ID = ID 
        self._ai._id = self._id;
        // [101]  If Theme = {16} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [102]  ai.a.ID = ID 
        self._ai._a._id = self._id;
        // [108]  modUOE.MaterialAddIcon(App,ai.a,IconName, {17} ,IconTheme,True,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._ai._a, self._iconname, "", self._icontheme, true, false, false, false, false);
        // [109]  ai.a.MaterialPulse(Pulse) 
        self._ai._a.materialpulse(self._pulse);
        // [110]  ai.a.MaterialVisibility(Visibility) 
        self._ai._a.materialvisibility(self._visibility);
        // [111]  ai.a.MaterialButtonSize(Size) 
        self._ai._a.materialbuttonsize(self._size);
        // [112]  ai.Click2Toggle = Click2Toggle 
        self._ai._click2toggle = self._click2toggle;
        // [113]  ai.Horizontal = toolbarEnabled 
        self._ai._horizontal = self._toolbarenabled;
        // [114]  ai.buttons = buttons 
        self._ai._buttons = self._buttons;
        // [115]  ai.isfab = True 
        self._ai._isfab = true;
        // [116]  ai.IsToolBar = toolbarEnabled 
        self._ai._istoolbar = self._toolbarenabled;
        // [121]  App.ApplyToolTip(ID,ai.a) 
        self._app.applytooltip(self._id, self._ai._a);
        // [122]  Return ai.tostring 
        return self._ai.tostring();
        // End Sub
    };

    // [126] Sub Open 
    this.open = function () {
        if (self == null) self = this;
        var _script;
        // [127]  Dim script As String = {3} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "div'); \n	var " + self._instance + " = M.FloatingActionButton.getInstance(inst" + self._id + "); \n	" + self._instance + ".open();";
        // [128]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [132] Sub Close 
    this.close = function () {
        if (self == null) self = this;
        var _script;
        // [133]  Dim script As String = {4} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "div'); \n	var " + self._instance + " = M.FloatingActionButton.getInstance(inst" + self._id + "); \n	" + self._instance + ".close();";
        // [134]  Banano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [137] public Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _dpsettings;
        var _strds;
        // [138]  Dim dpSettings As Map 
        _dpsettings = {};
        // [139]  dpSettings.Initialize 
        _dpsettings = {};
        // [140]  dpSettings.clear 
        _dpsettings = {};
        // [141]  dpSettings.Put( {20} , ID) 
        _dpsettings["id"] = self._id;
        // [142]  dpSettings.Put( {21} , {22} ) 
        _dpsettings["instance"] = "floatingActionButton";
        // [143]  dpSettings.Put( {23} , hoverEnabled) 
        _dpsettings["hoverEnabled"] = self._hoverenabled;
        // [144]  dpSettings.Put( {24} , Direction) 
        _dpsettings["direction"] = self._direction;
        // [145]  dpSettings.Put( {25} , toolbarEnabled) 
        _dpsettings["toolbarEnabled"] = self._toolbarenabled;
        // [146]  Dim strDS As String = App.Map2JSON(dpSettings) 
        _strds = self._app.map2json(_dpsettings);
        // [147]  Return strDS 
        return _strds;
        // End Sub
    };

}
// =========================== UOEFeature  ===========================
function banano_uoebanano_uoefeature() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._enabled = false;

    this._id = '';

    this._theme = '';

    this._visibility = '';

    this._zdepth = '';

    this._title = '';

    this._description = '';

    this._ttc = new banano_uoebanano_uoehtml();

    // [18] Sub AddClass(sClass As String) As UOEFeature 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [19]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [20]  Return Me 
        return self;
        // End Sub
    };

    // [24] Sub RemoveClass(sClass As String) As UOEFeature 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [25]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Sub AddAttribute(attr As String, value As String) As UOEFeature 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [31]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Sub RemoveAttribute(attr As String) As UOEFeature 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [37]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [38]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub AddStyleAttribute(attribute As String, value As String) As UOEFeature 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [44]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [50] Public Sub Initialize(thisApp As UOEApp, mvarID As String, sTitle As String, sDescription As String, sThemeName As String, targetFAB As String) 
    this.initialize = function (_thisapp, _mvarid, _stitle, _sdescription, _sthemename, _targetfab) {
        if (self == null) self = this;
        // [51]  targetFAB = targetFAB.tolowercase 
        _targetfab = _targetfab.toLowerCase();
        // [53]  App = thisApp 
        self._app = _thisapp;
        // [54]  ID = mvarID.tolowercase 
        self._id = _mvarid.toLowerCase();
        // [55]  Element.Initialize(ID, {2} ) 
        self._element.initialize(self._id, "div");
        // [56]  Element.AddClass( {3} ) 
        self._element.addclass("tap-target");
        // [57]  Element.AddAttribute( {4} ,targetFAB) 
        self._element.addattribute("data-target", _targetfab);
        // [58]  ttc.Initialize( {5} , {6} ) 
        self._ttc.initialize("", "div");
        // [59]  ttc.AddClass( {7} ) 
        self._ttc.addclass("tap-target-content");
        // [60]  Enabled = True 
        self._enabled = true;
        // [61]  Theme = sThemeName 
        self._theme = _sthemename;
        // [62]  Visibility = {8} 
        self._visibility = "";
        // [63]  ZDepth = {9} 
        self._zdepth = "";
        // [64]  Title = sTitle 
        self._title = _stitle;
        // [65]  Description = sDescription 
        self._description = _sdescription;
        // End Sub
    };

    // [69] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [71]  ttc.AddHeading(5,Title) 
        self._ttc.addheading(5, self._title);
        // [72]  ttc.AddParagraph(Description) 
        self._ttc.addparagraph(self._description);
        // [73]  App.MaterialUseTheme(Theme,ttc) 
        self._app.materialusetheme(self._theme, self._ttc);
        // [74]  Element.ID = ID 
        self._element._id = self._id;
        // [75]  Element.sethref( {10} ) 
        self._element.sethref("");
        // [76]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [77]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [78]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [79]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [80]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [81]  Element.AddElement(ttc) 
        self._element.addelement(self._ttc);
        // [86]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

    // [90] Sub Open 
    this.open = function () {
        if (self == null) self = this;
        var _f;
        // [91]  Dim f As BANanoObject 
        _f = null;
        // [92]  f = App.JQ.Selector( {0} ) 
        _f = self._app._jq("#" + self._id + "");
        // [93]  f.RunMethod( {13} , {14} ) 
        _f["tapTarget"]("open");
        // End Sub
    };

    // [97] Sub Close 
    this.close = function () {
        if (self == null) self = this;
        var _f;
        // [98]  Dim f As BANanoObject 
        _f = null;
        // [99]  f = App.JQ.Selector( {1} ) 
        _f = self._app._jq("#" + self._id + "");
        // [100]  f.RunMethod( {15} , {16} ) 
        _f["tapTarget"]("close");
        // End Sub
    };

}
// =========================== UOEFile  ===========================
function banano_uoebanano_uoefile() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._fu = new banano_uoebanano_uoehtml();

    this._placeholder = '';

    this._hoverable = false;

    this._theme = '';

    this._enabled = false;

    this._zdepth = '';

    this._visibility = '';

    this._onchange = '';

    this._fixcell = false;

    this._validate = false;

    this._helpertext = '';

    this._errormsg = '';

    this._successmsg = '';

    this._btn = new banano_uoebanano_uoehtml();

    this._fpw = new banano_uoebanano_uoehtml();

    this._help = new banano_uoebanano_uoehtml();

    this._hideinput = false;

    this._fitwidth = false;

    this._title = '';

    this._multiple = false;

    // [30] Sub AddStyleAttribute(attribute As String, value As String) As UOEFile 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [31]  fu.AddStyleAttribute(attribute,value) 
        self._fu.addstyleattribute(_attribute, _value);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Public Sub Initialize(thisApp As UOEApp,sid As String, sTitle As String, sPlaceholder As String, bMultiple As Boolean, sTheme As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _splaceholder, _bmultiple, _stheme) {
        if (self == null) self = this;
        // [38]  App = thisApp 
        self._app = _thisapp;
        // [39]  If sTheme = {8} Then 
        if (_stheme == "") {
            // [40]  sTheme = App.Theme 
            _stheme = self._app._theme;
            // [41]  End If 
        }
        // [42]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [43]  Placeholder = sPlaceholder 
        self._placeholder = _splaceholder;
        // [44]  Theme = sTheme 
        self._theme = _stheme;
        // [45]  Enabled = True 
        self._enabled = true;
        // [46]  ErrorMsg = {9} 
        self._errormsg = "Error";
        // [47]  SuccessMsg = {10} 
        self._successmsg = "Success";
        // [48]  HelperText = {11} 
        self._helpertext = "";
        // [49]  OnChange = {12} 
        self._onchange = "";
        // [50]  HideInput = False 
        self._hideinput = false;
        // [51]  FitWidth = False 
        self._fitwidth = false;
        // [52]  Title = sTitle 
        self._title = _stitle;
        // [53]  Theme = sTheme 
        self._theme = _stheme;
        // [54]  Multiple = bMultiple 
        self._multiple = _bmultiple;
        // End Sub
    };

    // [58] Sub AddClass(sClass As String) As UOEFile 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [59]  fu.AddClass(sClass) 
        self._fu.addclass(_sclass);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub RemoveClass(sClass As String) As UOEFile 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [65]  fu.RemoveClass(sClass) 
        self._fu.removeclass(_sclass);
        // [66]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub AddAttribute(attr As String, value As String) As UOEFile 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [71]  fu.AddAttribute(attr,value) 
        self._fu.addattribute(_attr, _value);
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub RemoveAttribute(attr As String) As UOEFile 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [77]  fu.RemoveAttribute(attr) 
        self._fu.removeattribute(_attr);
        // [78]  Return Me 
        return self;
        // End Sub
    };

    // [82] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _spn;
        var _inp;
        var _fa;
        // [83]  If FitWidth Then 
        if (self._fitwidth) {
            // [84]  HideInput = True 
            self._hideinput = true;
            // [85]  End If 
        }
        // [86]  If HideInput Then 
        if (self._hideinput) {
            // [87]  HelperText= {13} 
            self._helpertext = "";
            // [88]  End If 
        }
        // [90]  help.Initialize(ID & {14} , {15} ) 
        self._help.initialize(self._id + "-span", "span");
        // [91]  help.AddClass( {16} ) 
        self._help.addclass("helper-text");
        // [92]  fu.Initialize(ID & {17} , {18} ) 
        self._fu.initialize(self._id + "div", "div");
        // [93]  fu.AddClass( {19} ) 
        self._fu.addclass("file-field");
        // [94]  fu.AddClass( {20} ) 
        self._fu.addclass("input-field");
        // [95]  fu.AddClass( {21} ) 
        self._fu.addclass("col");
        // [96]  fu.AddClass( {22} ) 
        self._fu.addclass("s12");
        // [97]  fu.AddClass( {23} ) 
        self._fu.addclass("m12");
        // [98]  fu.AddClass( {24} ) 
        self._fu.addclass("l12");
        // [99]  btn.Initialize(ID & {25} , {26} ) 
        self._btn.initialize(self._id + "btn", "div");
        // [100]  btn.AddClass( {27} ) 
        self._btn.addclass("btn");
        // [101]  btn.AddStyleAttributeOnCondition(FitWidth, {28} , {29} ) 
        self._btn.addstyleattributeoncondition(self._fitwidth, "width", "100%");
        // [103]  Dim spn As UOEHTML 
        _spn = new banano_uoebanano_uoehtml();
        // [104]  spn.Initialize(ID & {30} , {31} ) 
        _spn.initialize(self._id + "-span", "span");
        // [105]  spn.AddContent(Title) 
        _spn.addcontent(self._title);
        // [106]  btn.AddElement(spn) 
        self._btn.addelement(_spn);
        // [108]  Dim inp As UOEHTML 
        _inp = new banano_uoebanano_uoehtml();
        // [109]  inp.Initialize(ID, {32} ) 
        _inp.initialize(self._id, "input");
        // [110]  inp.SetTYPE( {33} ) 
        _inp.settype("file");
        // [111]  inp.AddLooseAttributeOnCondition(Multiple, {34} ) 
        _inp.addlooseattributeoncondition(self._multiple, "multiple");
        // [112]  btn.AddElement(inp) 
        self._btn.addelement(_inp);
        // [115]  App.MaterialUseTheme(Theme,btn) 
        self._app.materialusetheme(self._theme, self._btn);
        // [116]  fu.AddElement(btn) 
        self._fu.addelement(self._btn);
        // [117]  fpw.Initialize( {35} , {36} ) 
        self._fpw.initialize("", "div");
        // [118]  fpw.AddClass( {37} ) 
        self._fpw.addclass("file-path-wrapper");
        // [119]  fu.MaterialVisibility(Visibility) 
        self._fu.materialvisibility(self._visibility);
        // [120]  fu.MaterialHoverable(Hoverable) 
        self._fu.materialhoverable(self._hoverable);
        // [121]  fu.MaterialZdepth(ZDepth) 
        self._fu.materialzdepth(self._zdepth);
        // [122]  App.ApplyToolTip(ID,fu) 
        self._app.applytooltip(self._id, self._fu);
        // [123]  help.AddAttribute( {38} ,ErrorMsg) 
        self._help.addattribute("data-error", self._errormsg);
        // [124]  help.AddAttribute( {39} ,SuccessMsg) 
        self._help.addattribute("data-success", self._successmsg);
        // [125]  help.AddContent(HelperText) 
        self._help.addcontent(self._helpertext);
        // [127]  Dim inp As UOEHTML 
        _inp = new banano_uoebanano_uoehtml();
        // [128]  inp.Initialize( {40} , {41} ) 
        _inp.initialize("", "input");
        // [129]  inp.AddClass( {42} ) 
        _inp.addclass("file-path");
        // [130]  inp.AddClassOnCondition(Validate, {43} ) 
        _inp.addclassoncondition(self._validate, "validate");
        // [131]  inp.SetTYPE( {44} ) 
        _inp.settype("text");
        // [132]  inp.AddAttribute( {45} ,Placeholder) 
        _inp.addattribute("placeholder", self._placeholder);
        // [133]  inp.AddStyleAttributeOnCondition(HideInput, {46} , {47} ) 
        _inp.addstyleattributeoncondition(self._hideinput, "display", "none");
        // [134]  fpw.addelement(inp) 
        self._fpw.addelement(_inp);
        // [140]  Dim fa As UOEHTML 
        _fa = new banano_uoebanano_uoehtml();
        // [141]  fa.Initialize( {50} , {51} ) 
        _fa.initialize("", "form");
        // [142]  fa.AddAttribute( {52} , {53} ) 
        _fa.addattribute("action", "#");
        // [143]  fa.AddElement(fu) 
        _fa.addelement(self._fu);
        // [144]  Return fa.HTML 
        return _fa.html();
        // End Sub
    };

}
// =========================== UOEFooter  ===========================
function banano_uoebanano_uoefooter() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._visibility = '';

    this._fixedfooter = false;

    this._content = new banano_uoebanano_uoecontainer();

    this._hascopyrights = false;

    this._fcenter = false;

    this._id = '';

    // [16] Sub AddStyleAttribute(attribute As String, value As String) As UOEFooter 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [17]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [18]  Return Me 
        return self;
        // End Sub
    };

    // [23] Public Sub Initialize(thisApp As UOEApp, bCenter As Boolean, bFixedFooter As Boolean, bHasCopyRights As Boolean, sTheme As String, sClass As String) 
    this.initialize = function (_thisapp, _bcenter, _bfixedfooter, _bhascopyrights, _stheme, _sclass) {
        if (self == null) self = this;
        // [24]  ID = {0} 
        self._id = "footer";
        // [25]  App = thisApp 
        self._app = _thisapp;
        // [26]  Theme = sTheme 
        self._theme = _stheme;
        // [27]  Element.Initialize( {1} , {2} ) 
        self._element.initialize("footer", "footer");
        // [28]  Element.AddClass( {3} ) 
        self._element.addclass("page-footer");
        // [29]  Content.Initialize(App, {4} ,bCenter,sTheme) 
        self._content.initialize(self._app, "footer-content", _bcenter, _stheme);
        // [30]  App.MaterialUseTheme(sTheme,Element) 
        self._app.materialusetheme(_stheme, self._element);
        // [31]  HasCopyRights = bHasCopyRights 
        self._hascopyrights = _bhascopyrights;
        // [32]  FixedFooter = bFixedFooter 
        self._fixedfooter = _bfixedfooter;
        // [33]  fCenter = bCenter 
        self._fcenter = _bcenter;
        // End Sub
    };

    // [37] Sub AddClass(sClass As String) As UOEFooter 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [38]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [39]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub RemoveClass(sClass As String) As UOEFooter 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [44]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [49] Sub AddAttribute(attr As String, value As String) As UOEFooter 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [50]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveAttribute(attr As String) As UOEFooter 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [56]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [60] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _foot;
        // [61]  Element.AddContent(Content.ToString) 
        self._element.addcontent(self._content.tostring());
        // [62]  If HasCopyRights Then 
        if (self._hascopyrights) {
            // [63]  Dim foot As UOECopyRights 
            _foot = new banano_uoebanano_uoecopyrights();
            // [64]  foot.Initialize(App, {5} ,Theme) 
            _foot.initialize(self._app, "pgcopyrights", self._theme);
            // [65]  foot.AddTermsAndConditions 
            _foot.addtermsandconditions();
            // [66]  foot.AddDisclaimer 
            _foot.adddisclaimer();
            // [67]  foot.AddPrivacyPolicy 
            _foot.addprivacypolicy();
            // [68]  Element.AddContent(foot.tostring) 
            self._element.addcontent(_foot.tostring());
            // [69]  End If 
        }
        // [70]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

}
// =========================== UOEGrid  ===========================
function banano_uoebanano_uoegrid() {
    var self;
    this._rows = {};

    this._columns = {};

    this._lastrow = 0;

    this._colclass = {
        "s": "s",
        "m": "m",
        "l": "l"
    };

    this._padclass = {
        "pt": "padding-top:",
        "pb": "padding-bottom:",
        "pl": "padding-left:",
        "pr": "padding-right:"
    };

    this._marclass = {
        "mt": "margin-top:",
        "mb": "margin-bottom:",
        "ml": "margin-left:",
        "mr": "margin-right:"
    };

    this._offclass = {
        "s": "offset-s",
        "m": "offset-m",
        "l": "offset-l"
    };

    this._rc = {};

    this._rowclass = "row";

    this._cellclass = "col";

    this._showid = false;

    this._parentid = '';

    this._components = {};

    this._rowclasses = {};

    this._columnclasses = {};

    this._app = new banano_uoebanano_uoeapp();

    this._rowpadding = {};

    this._rowmargins = {};

    // [37] private Sub CStr(o As Object) As String 
    this.cstr = function (_o) {
        if (self == null) self = this;
        // [38]  Return {56} & o 
        return "" + _o;
        // End Sub
    };

    // [42] Sub AddRowsMV(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, rVisibility As String, themeName As String , className As String) As UOEGrid 
    this.addrowsmv = function (_rows2add, _margintoppx, _marginbottompx, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [43]  AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx , 0,0,0,0,0,0, themeName , rVisibility, className ) 
        self.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, 0, 0, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [44]  Return Me 
        return self;
        // End Sub
    };

    // [48] Sub AddRowsMV2(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, marginLeftPx As Int, marginRightPx As Int, rVisibility As String, themeName As String, className As String) As UOEGrid 
    this.addrowsmv2 = function (_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [49]  AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx , marginLeftPx, marginRightPx , 0,0,0,0,themeName, rVisibility, className) 
        self.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [50]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub AddRowsM2(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, marginLeftPx As Int, marginRightPx As Int, themeName As String, className As String) As UOEGrid 
    this.addrowsm2 = function (_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, _themename, _classname) {
        if (self == null) self = this;
        // [56]  AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx, marginLeftPx, marginRightPx, 0,0,0,0, themeName, {57} , className) 
        self.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, _marginleftpx, _marginrightpx, 0, 0, 0, 0, _themename, "", _classname);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub AddRowsM(Rows2Add As Int, marginTopPx As Int, marginBottomPx As Int, themeName As String, className As String) As UOEGrid 
    this.addrowsm = function (_rows2add, _margintoppx, _marginbottompx, _themename, _classname) {
        if (self == null) self = this;
        // [62]  AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx, 0,0,0,0,0,0,themeName , {58} , className) 
        self.addrowsmpv(_rows2add, _margintoppx, _marginbottompx, 0, 0, 0, 0, 0, 0, _themename, "", _classname);
        // [63]  Return Me 
        return self;
        // End Sub
    };

    // [67] Sub AddRowsV(Rows2Add As Int, rVisibility As String, themeName As String, className As String) As UOEGrid 
    this.addrowsv = function (_rows2add, _rvisibility, _themename, _classname) {
        if (self == null) self = this;
        // [68]  AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName,rVisibility, className) 
        self.addrowsmpv(_rows2add, 0, 20, 0, 0, 0, 0, 0, 0, _themename, _rvisibility, _classname);
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [73] Sub AddRows(Rows2Add As Int, themeName As String,className As String) As UOEGrid 
    this.addrows = function (_rows2add, _themename, _classname) {
        if (self == null) self = this;
        // [74]  AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName, {59} ,className) 
        self.addrowsmpv(_rows2add, 0, 20, 0, 0, 0, 0, 0, 0, _themename, "", _classname);
        // [75]  Return Me 
        return self;
        // End Sub
    };

    // [80] Sub setRowClass(rowPos As Int, className As String) 
    this.setrowclass = function (_rowpos, _classname) {
        if (self == null) self = this;
        var _rowc;
        var _rowkey;
        // [82]  Dim rowc As Map 
        _rowc = {};
        // [83]  Dim rowKey As String = {0} 
        _rowkey = "r" + _rowpos + "";
        // [84]  If rowClasses.ContainsKey(rowKey) Then 
        if ((_rowkey in self._rowclasses)) {
            // [85]  rowc = rowClasses.Get(rowKey) 
            _rowc = self._rowclasses[_rowkey];
            // [86]  Else 
        } else {
            // [87]  rowc.Initialize 
            _rowc = {};
            // [88]  rowc.clear 
            _rowc = {};
            // [89]  End If 
        }
        // [90]  rowc.Put(className,className) 
        _rowc[_classname] = _classname;
        // [91]  rowClasses.Put(rowKey,rowc) 
        self._rowclasses[_rowkey] = _rowc;
        // End Sub
    };

    // [95] Sub setColumnMargins(rowPos As Int, colPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) 
    this.setcolumnmargins = function (_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        var _srow;
        var _scol;
        var _rowkey;
        var _rowcy;
        // [97]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [98]  Dim sCol As String = CStr(colPos) 
        _scol = self.cstr(_colpos);
        // [99]  Dim rowKey As String = {1} 
        _rowkey = "r" + _srow + "c" + _scol + "";
        // [100]  Dim rowcy As Map = CreateMap( {60} : CStr(marginTop), {61} : CStr(marginBottom), {62} : CStr(marginLeft), {63} : CStr(marginRight)) 
        _rowcy = {
            "mt": self.cstr(_margintop),
            "mb": self.cstr(_marginbottom),
            "ml": self.cstr(_marginleft),
            "mr": self.cstr(_marginright)
        };
        // [101]  rowMargins.Put(rowKey,rowcy) 
        self._rowmargins[_rowkey] = _rowcy;
        // End Sub
    };

    // [105] Sub setRowMargins(rowPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) 
    this.setrowmargins = function (_rowpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        var _srow;
        var _rowkey;
        var _rowcb;
        // [107]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [108]  Dim rowKey As String = {2} 
        _rowkey = "r" + _srow + "";
        // [109]  Dim rowcb As Map = CreateMap( {64} : CStr(marginTop), {65} : CStr(marginBottom), {66} : CStr(marginLeft), {67} : CStr(marginRight)) 
        _rowcb = {
            "mt": self.cstr(_margintop),
            "mb": self.cstr(_marginbottom),
            "ml": self.cstr(_marginleft),
            "mr": self.cstr(_marginright)
        };
        // [110]  rowMargins.Put(rowKey,rowcb) 
        self._rowmargins[_rowkey] = _rowcb;
        // End Sub
    };

    // [114] Sub setColumnPadding(rowPos As Int, colPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) 
    this.setcolumnpadding = function (_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        var _srow;
        var _scol;
        var _rowkey;
        var _rowcx;
        // [116]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [117]  Dim sCol As String = CStr(colPos) 
        _scol = self.cstr(_colpos);
        // [118]  Dim rowKey As String = {3} 
        _rowkey = "r" + _srow + "c" + _scol + "";
        // [119]  Dim rowcx As Map = CreateMap( {68} : CStr(paddingTop), {69} : CStr(paddingBottom), {70} : CStr(paddingLeft), {71} : CStr(paddingRight)) 
        _rowcx = {
            "pt": self.cstr(_paddingtop),
            "pb": self.cstr(_paddingbottom),
            "pl": self.cstr(_paddingleft),
            "pr": self.cstr(_paddingright)
        };
        // [120]  rowPadding.Put(rowKey,rowcx) 
        self._rowpadding[_rowkey] = _rowcx;
        // End Sub
    };

    // [124] Sub setColumnPadding1(rowPos As Int, colPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) 
    this.setcolumnpadding1 = function (_rowpos, _colpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        var _srow;
        var _scol;
        var _rowkey;
        var _rowcx;
        var _str;
        var _el;
        // [126]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [127]  Dim sCol As String = CStr(colPos) 
        _scol = self.cstr(_colpos);
        // [128]  Dim rowKey As String = {4} 
        _rowkey = "#" + self._parentid + "r" + _srow + "c" + _scol + "";
        // [129]  Dim rowcx As Map 
        _rowcx = {};
        // [130]  rowcx.Initialize 
        _rowcx = {};
        // [131]  rowcx.clear 
        _rowcx = {};
        // [132]  rowcx.Put( {72} , CStr(paddingTop) & {73} ) 
        _rowcx["padding-top"] = self.cstr(_paddingtop) + "px";
        // [133]  rowcx.Put( {74} , CStr(paddingBottom) & {75} ) 
        _rowcx["padding-bottom"] = self.cstr(_paddingbottom) + "px";
        // [134]  rowcx.Put( {76} , CStr(paddingLeft) & {77} ) 
        _rowcx["padding-left"] = self.cstr(_paddingleft) + "px";
        // [135]  rowcx.Put( {78} , CStr(paddingRight) & {79} ) 
        _rowcx["padding-right"] = self.cstr(_paddingright) + "px";
        // [136]  Dim str As String = App.Map2Json(rowcx) 
        _str = self._app.map2json(_rowcx);
        // [137]  Dim el As BANanoElement 
        _el = null;
        // [138]  el = BANano.GetElement(rowKey) 
        _el = u(_rowkey);
        // [139]  el.SetStyle(str) 
        _el.css(JSON.parse(_str));
        // End Sub
    };

    // [143] Sub setRowPadding1(rowPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) 
    this.setrowpadding1 = function (_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        var _srow;
        var _rowkey;
        var _rowcx;
        var _str;
        var _el;
        // [145]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [146]  Dim rowKey As String = {5} 
        _rowkey = "#" + self._parentid + "r" + _srow + "";
        // [147]  Dim rowcx As Map 
        _rowcx = {};
        // [148]  rowcx.Initialize 
        _rowcx = {};
        // [149]  rowcx.clear 
        _rowcx = {};
        // [150]  rowcx.Put( {80} , CStr(paddingTop) & {81} ) 
        _rowcx["padding-top"] = self.cstr(_paddingtop) + "px";
        // [151]  rowcx.Put( {82} , CStr(paddingBottom) & {83} ) 
        _rowcx["padding-bottom"] = self.cstr(_paddingbottom) + "px";
        // [152]  rowcx.Put( {84} , CStr(paddingLeft) & {85} ) 
        _rowcx["padding-left"] = self.cstr(_paddingleft) + "px";
        // [153]  rowcx.Put( {86} , CStr(paddingRight) & {87} ) 
        _rowcx["padding-right"] = self.cstr(_paddingright) + "px";
        // [154]  Dim str As String = App.Map2Json(rowcx) 
        _str = self._app.map2json(_rowcx);
        // [155]  Dim el As BANanoElement 
        _el = null;
        // [156]  el = BANano.GetElement(rowKey) 
        _el = u(_rowkey);
        // [157]  el.SetStyle(str) 
        _el.css(JSON.parse(_str));
        // End Sub
    };

    // [162] Sub setColumnMargins1(rowPos As Int, colPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) 
    this.setcolumnmargins1 = function (_rowpos, _colpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        var _srow;
        var _scol;
        var _rowkey;
        var _rowcx;
        var _str;
        var _el;
        // [164]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [165]  Dim sCol As String = CStr(colPos) 
        _scol = self.cstr(_colpos);
        // [166]  Dim rowKey As String = {6} 
        _rowkey = "#" + self._parentid + "r" + _srow + "c" + _scol + "";
        // [167]  Dim rowcx As Map 
        _rowcx = {};
        // [168]  rowcx.Initialize 
        _rowcx = {};
        // [169]  rowcx.clear 
        _rowcx = {};
        // [170]  rowcx.Put( {88} , CStr(marginTop) & {89} ) 
        _rowcx["margin-top"] = self.cstr(_margintop) + "px";
        // [171]  rowcx.Put( {90} , CStr(marginBottom) & {91} ) 
        _rowcx["margin-bottom"] = self.cstr(_marginbottom) + "px";
        // [172]  rowcx.Put( {92} , CStr(marginLeft) & {93} ) 
        _rowcx["margin-left"] = self.cstr(_marginleft) + "px";
        // [173]  rowcx.Put( {94} , CStr(marginRight) & {95} ) 
        _rowcx["margin-right"] = self.cstr(_marginright) + "px";
        // [174]  Dim str As String = App.Map2Json(rowcx) 
        _str = self._app.map2json(_rowcx);
        // [175]  Dim el As BANanoElement 
        _el = null;
        // [176]  el = BANano.GetElement(rowKey) 
        _el = u(_rowkey);
        // [177]  el.SetStyle(str) 
        _el.css(JSON.parse(_str));
        // End Sub
    };

    // [181] Sub setRowMargins1(rowPos As Int, marginTop As Int, marginBottom As Int, marginLeft As Int, marginRight As Int) 
    this.setrowmargins1 = function (_rowpos, _margintop, _marginbottom, _marginleft, _marginright) {
        if (self == null) self = this;
        var _srow;
        var _rowkey;
        var _rowcx;
        var _str;
        var _el;
        // [183]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [184]  Dim rowKey As String = {7} 
        _rowkey = "#" + self._parentid + "r" + _srow + "";
        // [185]  Dim rowcx As Map 
        _rowcx = {};
        // [186]  rowcx.Initialize 
        _rowcx = {};
        // [187]  rowcx.clear 
        _rowcx = {};
        // [188]  rowcx.Put( {96} , CStr(marginTop) & {97} ) 
        _rowcx["margin-top"] = self.cstr(_margintop) + "px";
        // [189]  rowcx.Put( {98} , CStr(marginBottom) & {99} ) 
        _rowcx["margin-bottom"] = self.cstr(_marginbottom) + "px";
        // [190]  rowcx.Put( {100} , CStr(marginLeft) & {101} ) 
        _rowcx["margin-left"] = self.cstr(_marginleft) + "px";
        // [191]  rowcx.Put( {102} , CStr(marginRight) & {103} ) 
        _rowcx["margin-right"] = self.cstr(_marginright) + "px";
        // [192]  Dim str As String = App.Map2Json(rowcx) 
        _str = self._app.map2json(_rowcx);
        // [193]  Dim el As BANanoElement 
        _el = null;
        // [194]  el = BANano.GetElement(rowKey) 
        _el = u(_rowkey);
        // [195]  el.SetStyle(str) 
        _el.css(JSON.parse(_str));
        // End Sub
    };

    // [199] Sub setRowPadding(rowPos As Int, paddingTop As Int, paddingBottom As Int, paddingLeft As Int, paddingRight As Int) 
    this.setrowpadding = function (_rowpos, _paddingtop, _paddingbottom, _paddingleft, _paddingright) {
        if (self == null) self = this;
        var _srow;
        var _rowkey;
        var _rowca;
        // [201]  Dim sRow As String = CStr(rowPos) 
        _srow = self.cstr(_rowpos);
        // [202]  Dim rowKey As String = {8} 
        _rowkey = "r" + _srow + "";
        // [203]  Dim rowca As Map = CreateMap( {104} : CStr(paddingTop), {105} : CStr(paddingBottom), {106} : CStr(paddingLeft), {107} : CStr(paddingRight)) 
        _rowca = {
            "pt": self.cstr(_paddingtop),
            "pb": self.cstr(_paddingbottom),
            "pl": self.cstr(_paddingleft),
            "pr": self.cstr(_paddingright)
        };
        // [204]  rowPadding.Put(rowKey,rowca) 
        self._rowpadding[_rowkey] = _rowca;
        // End Sub
    };

    // [208] Sub setColumnClass(rowPos As Int, columnPos As Int, className As String) 
    this.setcolumnclass = function (_rowpos, _columnpos, _classname) {
        if (self == null) self = this;
        var _rowc;
        var _rowkey;
        // [210]  Dim rowc As Map 
        _rowc = {};
        // [211]  Dim rowKey As String = {9} 
        _rowkey = "r" + _rowpos + "c" + _columnpos + "";
        // [212]  If columnClasses.ContainsKey(rowKey) Then 
        if ((_rowkey in self._columnclasses)) {
            // [213]  rowc = columnClasses.Get(rowKey) 
            _rowc = self._columnclasses[_rowkey];
            // [214]  Else 
        } else {
            // [215]  rowc.Initialize 
            _rowc = {};
            // [216]  rowc.clear 
            _rowc = {};
            // [217]  End If 
        }
        // [218]  rowc.Put(className,className) 
        _rowc[_classname] = _classname;
        // [219]  columnClasses.Put(rowKey,rowc) 
        self._columnclasses[_rowkey] = _rowc;
        // End Sub
    };

    // [224] private Sub CreateRow(Rows2Add As Int, MarginTop As Int, MarginBottom As Int, MarginLeft As Int, MarginRight As Int, PaddingTop As Int, PaddingBottom As Int, PaddingLeft As Int, PaddingRight As Int, Visibility As String, ThemeName As String,CenterInPage As Boolean,ClassName As String) As UOERow 
    this.createrow = function (_rows2add, _margintop, _marginbottom, _marginleft, _marginright, _paddingtop, _paddingbottom, _paddingleft, _paddingright, _visibility, _themename, _centerinpage, _classname) {
        if (self == null) self = this;
        var _nr;
        // [225]  Dim nr As UOERow 
        _nr = new banano_uoebanano_uoerow();
        // [226]  nr.Initialize 
        _nr.initialize();
        // [227]  nr.MarginBottom = MarginBottom 
        _nr._marginbottom = _marginbottom;
        // [228]  nr.MarginLeft = MarginLeft 
        _nr._marginleft = _marginleft;
        // [229]  nr.MarginRight = MarginRight 
        _nr._marginright = _marginright;
        // [230]  nr.MarginTop = MarginTop 
        _nr._margintop = _margintop;
        // [231]  nr.PaddingBottom = PaddingBottom 
        _nr._paddingbottom = _paddingbottom;
        // [232]  nr.PaddingLeft = PaddingLeft 
        _nr._paddingleft = _paddingleft;
        // [233]  nr.PaddingRight = PaddingRight 
        _nr._paddingright = _paddingright;
        // [234]  nr.PaddingTop = PaddingTop 
        _nr._paddingtop = _paddingtop;
        // [235]  nr.ThemeName = ThemeName 
        _nr._themename = _themename;
        // [236]  nr.Visibility = Visibility 
        _nr._visibility = _visibility;
        // [237]  nr.ClassName = ClassName 
        _nr._classname = _classname;
        // [238]  nr.Rows = Rows2Add 
        _nr._rows = _rows2add;
        // [239]  Return nr 
        return _nr;
        // End Sub
    };

    // [243] private Sub CreateColumn(Columns2Add As Int, OffsetSmall As Int, OffsetMedium As Int, OffsetLarge As Int, OffsetXLarge As Int, SpanSmall As Int, SpanMedium As Int, SpanLarge As Int, SpanXLarge As String, MarginTop As Int, MarginBottom As Int, MarginLeft As Int, MarginRight As Int, PaddingTop As Int, PaddingBottom As Int, PaddingLeft As Int, PaddingRight As Int, Theme As String,Visibility As String,ClassName As String) As UOEColumn 
    this.createcolumn = function (_columns2add, _offsetsmall, _offsetmedium, _offsetlarge, _offsetxlarge, _spansmall, _spanmedium, _spanlarge, _spanxlarge, _margintop, _marginbottom, _marginleft, _marginright, _paddingtop, _paddingbottom, _paddingleft, _paddingright, _theme, _visibility, _classname) {
        if (self == null) self = this;
        var _ncell;
        // [245]  Dim nCell As UOEColumn 
        _ncell = new banano_uoebanano_uoecolumn();
        // [246]  nCell.Initialize 
        _ncell.initialize();
        // [247]  nCell.Columns = Columns2Add 
        _ncell._columns = _columns2add;
        // [248]  nCell.OffsetSmall = OffsetSmall 
        _ncell._offsetsmall = _offsetsmall;
        // [249]  nCell.OffsetMedium = OffsetMedium 
        _ncell._offsetmedium = _offsetmedium;
        // [250]  nCell.OffsetLarge = OffsetLarge 
        _ncell._offsetlarge = _offsetlarge;
        // [251]  nCell.SpanSmall = SpanSmall 
        _ncell._spansmall = _spansmall;
        // [252]  nCell.SpanMedium = SpanMedium 
        _ncell._spanmedium = _spanmedium;
        // [253]  nCell.SpanLarge = SpanLarge 
        _ncell._spanlarge = _spanlarge;
        // [254]  nCell.MarginTop = MarginTop 
        _ncell._margintop = _margintop;
        // [255]  nCell.MarginBottom = MarginBottom 
        _ncell._marginbottom = _marginbottom;
        // [256]  nCell.MarginLeft = MarginLeft 
        _ncell._marginleft = _marginleft;
        // [257]  nCell.MarginRight = MarginRight 
        _ncell._marginright = _marginright;
        // [258]  nCell.PaddingBottom = PaddingBottom 
        _ncell._paddingbottom = _paddingbottom;
        // [259]  nCell.PaddingLeft = PaddingLeft 
        _ncell._paddingleft = _paddingleft;
        // [260]  nCell.PaddingTop = PaddingTop 
        _ncell._paddingtop = _paddingtop;
        // [261]  nCell.PaddingRight = PaddingRight 
        _ncell._paddingright = _paddingright;
        // [262]  nCell.Visibility = Visibility 
        _ncell._visibility = _visibility;
        // [263]  nCell.ClassName = ClassName 
        _ncell._classname = _classname;
        // [264]  nCell.Theme = Theme 
        _ncell._theme = _theme;
        // [265]  Return nCell 
        return _ncell;
        // End Sub
    };

    // [269] Public Sub Initialize(thisApp As UOEApp, parent As String) 
    this.initialize = function (_thisapp, _parent) {
        if (self == null) self = this;
        // [270]  App = thisApp 
        self._app = _thisapp;
        // [271]  Rows.Initialize 
        self._rows = {};
        // [272]  Rows.clear 
        self._rows = {};
        // [273]  LastRow = 0 
        self._lastrow = 0;
        // [274]  RC.Initialize 
        self._rc = {};
        // [275]  RC.clear 
        self._rc = {};
        // [276]  Columns.Initialize 
        self._columns = {};
        // [277]  Columns.clear 
        self._columns = {};
        // [278]  ShowID = False 
        self._showid = false;
        // [279]  parentID = parent.tolowercase 
        self._parentid = _parent.toLowerCase();
        // [280]  Components.Initialize 
        self._components = {};
        // [281]  Components.clear 
        self._components = {};
        // [282]  rowClasses.Initialize 
        self._rowclasses = {};
        // [283]  rowClasses.clear 
        self._rowclasses = {};
        // [284]  columnClasses.Initialize 
        self._columnclasses = {};
        // [285]  columnClasses.clear 
        self._columnclasses = {};
        // [286]  rowPadding.Initialize 
        self._rowpadding = {};
        // [287]  rowPadding.clear 
        self._rowpadding = {};
        // [288]  rowMargins.Initialize 
        self._rowmargins = {};
        // [289]  rowMargins.clear 
        self._rowmargins = {};
        // End Sub
    };

    // [293] Sub AddRowsMPV(iRows As Int, iMarginTop As Int, iMarginBottom As Int, iMarginLeft As Int, iMarginRight As Int, iPaddingTop As Int, iPaddingBottom As Int, iPaddingLeft As Int, iPaddingRight As Int, sThemeName As String,sVisibility As String, sClassName As String) As UOEGrid 
    this.addrowsmpv = function (_irows, _imargintop, _imarginbottom, _imarginleft, _imarginright, _ipaddingtop, _ipaddingbottom, _ipaddingleft, _ipaddingright, _sthemename, _svisibility, _sclassname) {
        if (self == null) self = this;
        var _nrow;
        var _rowkey;
        // [297]  LastRow = Rows.size 
        self._lastrow = Object.keys(self._rows).length;
        // [299]  Dim nRow As UOERow 
        _nrow = new banano_uoebanano_uoerow();
        // [300]  nRow.Initialize 
        _nrow.initialize();
        // [301]  nRow = CreateRow(iRows,iMarginTop,iMarginBottom,iMarginLeft,iMarginRight,iPaddingTop,iPaddingBottom,iPaddingLeft,iPaddingRight,sVisibility,sThemeName,False,sClassName) 
        _nrow = self.createrow(_irows, _imargintop, _imarginbottom, _imarginleft, _imarginright, _ipaddingtop, _ipaddingbottom, _ipaddingleft, _ipaddingright, _svisibility, _sthemename, false, _sclassname);
        // [303]  Dim rowKey As String = {10} 
        _rowkey = "r" + self._lastrow + "";
        // [305]  Rows.Put(rowKey,nRow) 
        self._rows[_rowkey] = _nrow;
        // [306]  Return Me 
        return self;
        // End Sub
    };

    // [310] Sub AddColumnOSMPV(iColumns As Int,iOffsetSmall As Int, iOffsetMedium As Int, iOffsetLarge As Int, iSizeSmall As Int, iSizeMedium As Int, iSizeLarge As Int, iMarginTop As Int,iMarginBottom As Int, iMarginLeft As Int, iMarginRight As Int, iPaddingTop As Int, iPaddingBottom As Int, iPaddingLeft As Int, iPaddingRight As Int, sThemeName As String,sVisibility As String, sClassName As String) As UOEGrid 
    this.addcolumnosmpv = function (_icolumns, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, _isizesmall, _isizemedium, _isizelarge, _imargintop, _imarginbottom, _imarginleft, _imarginright, _ipaddingtop, _ipaddingbottom, _ipaddingleft, _ipaddingright, _sthemename, _svisibility, _sclassname) {
        if (self == null) self = this;
        var _ncell;
        var _rowkey;
        var _oldrow;
        var _cols;
        // [314]  Dim nCell As UOEColumn 
        _ncell = new banano_uoebanano_uoecolumn();
        // [315]  nCell.Initialize 
        _ncell.initialize();
        // [316]  nCell = CreateColumn(iColumns,iOffsetSmall,iOffsetMedium,iOffsetLarge,0,iSizeSmall,iSizeMedium,iSizeLarge,0,iMarginTop,iMarginBottom,iMarginLeft,iMarginRight,iPaddingTop,iPaddingBottom,iPaddingLeft,iPaddingRight,sThemeName,sVisibility,sClassName) 
        _ncell = self.createcolumn(_icolumns, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, 0, _isizesmall, _isizemedium, _isizelarge, 0, _imargintop, _imarginbottom, _imarginleft, _imarginright, _ipaddingtop, _ipaddingbottom, _ipaddingleft, _ipaddingright, _sthemename, _svisibility, _sclassname);
        // [318]  Dim rowkey As String = {11} 
        _rowkey = "r" + self._lastrow + "";
        // [320]  If Rows.ContainsKey(rowkey) Then 
        if ((_rowkey in self._rows)) {
            // [322]  Dim oldRow As UOERow 
            _oldrow = new banano_uoebanano_uoerow();
            // [323]  oldRow.Initialize 
            _oldrow.initialize();
            // [324]  oldRow = Rows.Get(rowkey) 
            _oldrow = self._rows[_rowkey];
            // [326]  Dim cols As List = oldRow.Columns 
            _cols = _oldrow._columns;
            // [327]  cols.add(nCell) 
            _cols.push(_ncell);
            // [328]  Rows.Put(rowkey,oldRow) 
            self._rows[_rowkey] = _oldrow;
            // [329]  Else 
        } else {
            // [330]  Log( {108} ) 
            console.log("UOEGrid - AddColumnOSMPV: A row has not been added yet to the grid!");
            // [331]  End If 
        }
        // [332]  Return Me 
        return self;
        // End Sub
    };

    // [336] Sub AddColumnsOS(Columns2Add As Int, iOffsetSmall As Int, iOffsetMedium As Int, iOffsetLarge As Int, iSizeSmall As Int, iSizeMedium As Int, iSizeLarge As Int, sThemeName As String, className As String) As UOEGrid 
    this.addcolumnsos = function (_columns2add, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, _isizesmall, _isizemedium, _isizelarge, _sthemename, _classname) {
        if (self == null) self = this;
        // [337]  AddColumnOSMPV(Columns2Add, iOffsetSmall, iOffsetMedium, iOffsetLarge , iSizeSmall, iSizeMedium, iSizeLarge,0,0,0,0,0,0,0,0, sThemeName, {109} , className ) 
        self.addcolumnosmpv(_columns2add, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, _isizesmall, _isizemedium, _isizelarge, 0, 0, 0, 0, 0, 0, 0, 0, _sthemename, "", _classname);
        // [338]  Return Me 
        return self;
        // End Sub
    };

    // [342] Sub AddColumns12MPV(Columns2Add As Int, iMarginTopPx As Int, iMarginBottomPx As Int, iPaddingLeftPx As Int, iPaddingRightPx As Int, sVisibility As String, sThemeName As String, className As String) As UOEGrid 
    this.addcolumns12mpv = function (_columns2add, _imargintoppx, _imarginbottompx, _ipaddingleftpx, _ipaddingrightpx, _svisibility, _sthemename, _classname) {
        if (self == null) self = this;
        // [343]  AddColumnOSMPV(Columns2Add ,0,0,0,12,12,12, iMarginTopPx , iMarginBottomPx ,0,0, 0,0,iPaddingLeftPx , iPaddingRightPx, sThemeName, sVisibility, className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, 12, 12, 12, _imargintoppx, _imarginbottompx, 0, 0, 0, 0, _ipaddingleftpx, _ipaddingrightpx, _sthemename, _svisibility, _classname);
        // [344]  Return Me 
        return self;
        // End Sub
    };

    // [349] Sub AddColumns12MP(Columns2Add As Int, iMarginTopPx As Int, iMarginBottomPx As Int, iPaddingLeftPx As Int, iPaddingRightPx As Int, sThemeName As String, className As String) As UOEGrid 
    this.addcolumns12mp = function (_columns2add, _imargintoppx, _imarginbottompx, _ipaddingleftpx, _ipaddingrightpx, _sthemename, _classname) {
        if (self == null) self = this;
        // [350]  AddColumnOSMPV(Columns2Add, 0,0,0,12,12,12, iMarginTopPx , iMarginBottomPx, iPaddingLeftPx , iPaddingRightPx, 0,0,0,0,sThemeName, {110} , className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, 12, 12, 12, _imargintoppx, _imarginbottompx, _ipaddingleftpx, _ipaddingrightpx, 0, 0, 0, 0, _sthemename, "", _classname);
        // [351]  Return Me 
        return self;
        // End Sub
    };

    // [355] Sub AddColumnsOSMPV(Columns2Add As Int, OffsetSmall As Int, OffsetMedium As Int, OffsetLarge As Int, SizeSmall As Int, SizeMedium As Int, SizeLarge As Int, MarginTopPx As Int, MarginBottomPx As Int, PaddingLeftPx As Int, PaddingRightPx As Int, sVisibility As String, sThemeName As String,className As String) As UOEGrid 
    this.addcolumnsosmpv = function (_columns2add, _offsetsmall, _offsetmedium, _offsetlarge, _sizesmall, _sizemedium, _sizelarge, _margintoppx, _marginbottompx, _paddingleftpx, _paddingrightpx, _svisibility, _sthemename, _classname) {
        if (self == null) self = this;
        // [357]  AddColumnOSMPV(Columns2Add, OffsetSmall, OffsetMedium, OffsetLarge, SizeSmall, SizeMedium, SizeLarge, MarginTopPx, MarginBottomPx,0,0,0,0, PaddingLeftPx, PaddingRightPx, sThemeName,sVisibility, className) 
        self.addcolumnosmpv(_columns2add, _offsetsmall, _offsetmedium, _offsetlarge, _sizesmall, _sizemedium, _sizelarge, _margintoppx, _marginbottompx, 0, 0, 0, 0, _paddingleftpx, _paddingrightpx, _sthemename, _svisibility, _classname);
        // [359]  Return Me 
        return self;
        // End Sub
    };

    // [364] Sub AddColumnsSP(Columns2Add As Int, SizeSmall As Int, SizeMedium As Int, SizeLarge As Int, rPaddingLeft As Int, rPaddingRight As Int, sThemeName As String,className As String) As UOEGrid 
    this.addcolumnssp = function (_columns2add, _sizesmall, _sizemedium, _sizelarge, _rpaddingleft, _rpaddingright, _sthemename, _classname) {
        if (self == null) self = this;
        // [365]  AddColumnOSMPV(Columns2Add, 0,0,0,SizeSmall, SizeMedium, SizeLarge ,0,0,0,0,0,0, rPaddingLeft, rPaddingRight, sThemeName, {111} ,className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, _sizesmall, _sizemedium, _sizelarge, 0, 0, 0, 0, 0, 0, _rpaddingleft, _rpaddingright, _sthemename, "", _classname);
        // [366]  Return Me 
        return self;
        // End Sub
    };

    // [370] Sub AddColumnsOSMP(Columns2Add As Int, OffsetSmall As Int, OffsetMedium As Int, OffsetLarge As Int, SizeSmall As Int, SizeMedium As Int, SizeLarge As Int, rMarginTop As Int, rMarginBottom As Int, rPaddingLeft As Int, rPaddingRight As Int, sThemeName As String,className As String) As UOEGrid 
    this.addcolumnsosmp = function (_columns2add, _offsetsmall, _offsetmedium, _offsetlarge, _sizesmall, _sizemedium, _sizelarge, _rmargintop, _rmarginbottom, _rpaddingleft, _rpaddingright, _sthemename, _classname) {
        if (self == null) self = this;
        // [371]  AddColumnOSMPV(Columns2Add,OffsetSmall, OffsetMedium , OffsetLarge, SizeSmall, SizeMedium, SizeLarge, rMarginTop, rMarginBottom, 0,0,0,0,rPaddingLeft, rPaddingRight, sThemeName , {112} ,className) 
        self.addcolumnosmpv(_columns2add, _offsetsmall, _offsetmedium, _offsetlarge, _sizesmall, _sizemedium, _sizelarge, _rmargintop, _rmarginbottom, 0, 0, 0, 0, _rpaddingleft, _rpaddingright, _sthemename, "", _classname);
        // [372]  Return Me 
        return self;
        // End Sub
    };

    // [377] Sub AddColumns12V(Columns2Add As Int, sVisibility As String, sThemeName As String,className As String) As UOEGrid 
    this.addcolumns12v = function (_columns2add, _svisibility, _sthemename, _classname) {
        if (self == null) self = this;
        // [378]  AddColumnOSMPV(Columns2Add,0,0,0,12,12,12,0,0,0,0,0,0,0,0, sThemeName,sVisibility,className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, 12, 12, 12, 0, 0, 0, 0, 0, 0, 0, 0, _sthemename, _svisibility, _classname);
        // [379]  Return Me 
        return self;
        // End Sub
    };

    // [383] Sub AddColumns12(Columns2Add As Int, sThemeName As String,className As String) As UOEGrid 
    this.addcolumns12 = function (_columns2add, _sthemename, _classname) {
        if (self == null) self = this;
        // [384]  AddColumnOSMPV(Columns2Add,0,0,0,12,12,12,0,0,0,0,0,0,0,0, sThemeName, {113} ,className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, 12, 12, 12, 0, 0, 0, 0, 0, 0, 0, 0, _sthemename, "", _classname);
        // [385]  Return Me 
        return self;
        // End Sub
    };

    // [389] Sub AddColumns(Columns2Add As Int, SpanSmall As Int, SpanMedium As Int, SpanLarge As Int,themeName As String, className As String) As UOEGrid 
    this.addcolumns = function (_columns2add, _spansmall, _spanmedium, _spanlarge, _themename, _classname) {
        if (self == null) self = this;
        // [390]  AddColumnOSMPV(Columns2Add, 0,0,0,SpanSmall, SpanMedium, SpanLarge,0,0,0,0,0,0,0,0,themeName, {114} , className) 
        self.addcolumnosmpv(_columns2add, 0, 0, 0, _spansmall, _spanmedium, _spanlarge, 0, 0, 0, 0, 0, 0, 0, 0, _themename, "", _classname);
        // [391]  Return Me 
        return self;
        // End Sub
    };

    // [396] Sub AddColumnsOSV(Columns2Add As Int, iOffsetSmall As Int, iOffsetMedium As Int, iOffsetLarge As Int, iSizeSmall As Int, iSizeMedium As Int, iSizeLarge As Int, sVisibility As String, sThemeName As String,className As String) As UOEGrid 
    this.addcolumnsosv = function (_columns2add, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, _isizesmall, _isizemedium, _isizelarge, _svisibility, _sthemename, _classname) {
        if (self == null) self = this;
        // [397]  AddColumnOSMPV(Columns2Add , iOffsetSmall , iOffsetMedium, iOffsetLarge, iSizeSmall, iSizeMedium , iSizeLarge, 0,0,0,0,0,0,0,0,sThemeName,sVisibility, className) 
        self.addcolumnosmpv(_columns2add, _ioffsetsmall, _ioffsetmedium, _ioffsetlarge, _isizesmall, _isizemedium, _isizelarge, 0, 0, 0, 0, 0, 0, 0, 0, _sthemename, _svisibility, _classname);
        // [398]  Return Me 
        return self;
        // End Sub
    };

    // [402] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _sb;
        var _rowcnt;
        var _rowtot;
        var _rowkey;
        var _currentrow;
        var _strrow;
        // [404]  LastRow = 0 
        self._lastrow = 0;
        // [405]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [406]  sb.Initialize 
        _sb.isinitialized = true;
        // [408]  Dim rowCnt As Int = 0 
        _rowcnt = 0;
        // [409]  Dim rowTot As Int = Rows.Size - 1 
        _rowtot = Object.keys(self._rows).length - 1;
        // [410]  For rowCnt = 0 To rowTot 
        for (_rowcnt = 0; _rowcnt <= _rowtot; _rowcnt++) {
            // [411]  Dim rowKey As String = Rows.GetKeyAt(rowCnt) 
            _rowkey = banano_getB4JKeyAt(self._rows, _rowcnt);
            // [412]  Dim currentRow As UOERow 
            _currentrow = new banano_uoebanano_uoerow();
            // [413]  currentRow.Initialize 
            _currentrow.initialize();
            // [414]  currentRow = Rows.Get(rowKey) 
            _currentrow = self._rows[_rowkey];
            // [415]  Dim strRow As String = BuildRow(currentRow) 
            _strrow = self.buildrow(_currentrow);
            // [416]  sb.Append(strRow) 
            _sb.append(_strrow);
            // [417]  sb.append(CRLF) 
            _sb.append("\n");
            // [418]  Next 
        }
        // [419]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [423] Sub ReplaceRC(rowPos As Int, colPos As Int, elHTML As String) 
    this.replacerc = function (_rowpos, _colpos, _elhtml) {
        if (self == null) self = this;
        var _cellkey;
        var _elbody;
        // [424]  Dim cellKey As String = {12} 
        _cellkey = "#" + self._parentid + "r" + _rowpos + "c" + _colpos + "";
        // [425]  Dim elBody As BANanoElement 
        _elbody = null;
        // [426]  elBody = BANano.GetElement(cellKey) 
        _elbody = u(_cellkey);
        // [427]  If elBody <> Null Then 
        if (_elbody != null) {
            // [428]  elBody.Empty 
            _elbody.empty();
            // [429]  elBody.SetHTML(elHTML) 
            _elbody.html(_elhtml);
            // [430]  End If 
        }
        // End Sub
    };

    // [435] Sub AddComponent(rowPos As Int, colPos As Int, elHTML As String) 
    this.addcomponent = function (_rowpos, _colpos, _elhtml) {
        if (self == null) self = this;
        var _cellkey;
        var _lst;
        // [436]  Dim cellKey As String = {13} 
        _cellkey = "" + self._parentid + "r" + _rowpos + "c" + _colpos + "";
        // [437]  Dim lst As List 
        _lst = [];
        // [438]  If Components.ContainsKey(cellKey) Then 
        if ((_cellkey in self._components)) {
            // [439]  lst = Components.Get(cellKey) 
            _lst = self._components[_cellkey];
            // [440]  Else 
        } else {
            // [441]  lst.Initialize 
            _lst.length = 0;
            // [442]  lst.clear 
            _lst.length = 0;
            // [443]  End If 
        }
        // [444]  lst.Add(elHTML) 
        _lst.push(_elhtml);
        // [445]  Components.Put(cellKey,lst) 
        self._components[_cellkey] = _lst;
        // End Sub
    };

    // [448] private Sub MapKeys2Delim(m As Map, delim As String) As String 
    this.mapkeys2delim = function (_m, _delim) {
        if (self == null) self = this;
        var _sb;
        var _ktot;
        var _kcnt;
        var _strkey;
        // [449]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [450]  sb.Initialize 
        _sb.isinitialized = true;
        // [451]  Dim kTot As Int = m.Size - 1 
        _ktot = Object.keys(_m).length - 1;
        // [452]  Dim kCnt As Int 
        _kcnt = 0;
        // [453]  Dim strKey As String = m.getkeyat(0) 
        _strkey = banano_getB4JKeyAt(_m, 0);
        // [454]  sb.Append(strKey) 
        _sb.append(_strkey);
        // [455]  For kCnt = 1 To kTot 
        for (_kcnt = 1; _kcnt <= _ktot; _kcnt++) {
            // [456]  Dim strKey As String = m.getkeyat(kCnt) 
            _strkey = banano_getB4JKeyAt(_m, _kcnt);
            // [457]  sb.Append(delim).append(strKey) 
            _sb.append(_delim).append(_strkey);
            // [458]  Next 
        }
        // [459]  Return sb.ToString 
        return _sb.toString();
        // End Sub
    };

    // [463] private Sub BuildRow(row As UOERow) As String 
    this.buildrow = function (_row) {
        if (self == null) self = this;
        var _rowtot;
        var _rowcnt;
        var _sb;
        var _rowkey;
        var _trow;
        var _strrowclass;
        var _strrowstyle;
        var _classkey;
        var _cm;
        var _cols;
        var _colcnt;
        var _coltot;
        var _lastcolumn;
        var _column;
        var _colcnt1;
        var _coltot1;
        var _cellkey;
        var _tcolumn;
        var _strcolumnclass;
        var _strcolumnstyle;
        var _lst;
        var _strrow;
        // [465]  Dim rowTot As Int = row.Rows 
        _rowtot = _row._rows;
        // [466]  Dim rowCnt As Int 
        _rowcnt = 0;
        // [467]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [468]  sb.Initialize 
        _sb.isinitialized = true;
        // [470]  For rowCnt = 1 To rowTot 
        for (_rowcnt = 1; _rowcnt <= _rowtot; _rowcnt++) {
            // [471]  LastRow = LastRow + 1 
            self._lastrow = self._lastrow + 1;
            // [472]  row.Row = LastRow 
            _row._row = self._lastrow;
            // [473]  Dim rowKey As String = {14} 
            _rowkey = "" + self._parentid + "r" + self._lastrow + "";
            // [474]  Dim tRow As UOEHTML 
            _trow = new banano_uoebanano_uoehtml();
            // [475]  tRow.Initialize(rowKey, {115} ) 
            _trow.initialize(_rowkey, "div");
            // [476]  Dim strRowClass As String = BuildRowClass 
            _strrowclass = self.buildrowclass();
            // [477]  Dim strRowStyle As String = BuildRowStyle(row) 
            _strrowstyle = self.buildrowstyle(_row);
            // [478]  tRow.AddClass(strRowClass) 
            _trow.addclass(_strrowclass);
            // [479]  tRow.AddAttribute( {116} ,strRowStyle) 
            _trow.addattribute("style", _strrowstyle);
            // [480]  tRow.AddClass(row.ClassName) 
            _trow.addclass(_row._classname);
            // [482]  App.MaterialUseTheme(row.ThemeName,tRow) 
            self._app.materialusetheme(_row._themename, _trow);
            // [484]  Dim classKey As String = {15} 
            _classkey = "r" + self._lastrow + "";
            // [485]  If rowClasses.ContainsKey(classKey) Then 
            if ((_classkey in self._rowclasses)) {
                // [487]  Dim cm As Map = rowClasses.Get(classKey) 
                _cm = self._rowclasses[_classkey];
                // [488]  tRow.AddClass(MapKeys2Delim(cm, {117} )) 
                _trow.addclass(self.mapkeys2delim(_cm, " "));
                // [489]  End If 
            }
            // [493]  Dim cols As List = row.Columns 
            _cols = _row._columns;
            // [495]  Dim colCnt As Int = 0 
            _colcnt = 0;
            // [496]  Dim colTot As Int = cols.Size - 1 
            _coltot = _cols.length - 1;
            // [498]  Dim LastColumn As Int = 0 
            _lastcolumn = 0;
            // [499]  For colCnt = 0 To colTot 
            for (_colcnt = 0; _colcnt <= _coltot; _colcnt++) {
                // [501]  Dim column As UOEColumn 
                _column = new banano_uoebanano_uoecolumn();
                // [502]  column.Initialize 
                _column.initialize();
                // [503]  column = cols.Get(colCnt) 
                _column = _cols[_colcnt];
                // [504]  Dim colCnt1 As Int = 0 
                _colcnt1 = 0;
                // [505]  Dim colTot1 As Int = column.Columns 
                _coltot1 = _column._columns;
                // [506]  For colCnt1 = 1 To colTot1 
                for (_colcnt1 = 1; _colcnt1 <= _coltot1; _colcnt1++) {
                    // [508]  LastColumn = LastColumn + 1 
                    _lastcolumn = _lastcolumn + 1;
                    // [509]  column.Row = LastRow 
                    _column._row = self._lastrow;
                    // [510]  column.Col = LastColumn 
                    _column._col = _lastcolumn;
                    // [511]  Dim cellKey As String = {17} 
                    _cellkey = "" + _rowkey + "c" + _lastcolumn + "";
                    // [513]  RC.Put(cellKey,cellKey) 
                    self._rc[_cellkey] = _cellkey;
                    // [520]  Dim tColumn As UOEHTML 
                    _tcolumn = new banano_uoebanano_uoehtml();
                    // [521]  tColumn.Initialize(cellKey, {119} ) 
                    _tcolumn.initialize(_cellkey, "div");
                    // [522]  Dim strColumnClass As String = BuildColumnClass(column) 
                    _strcolumnclass = self.buildcolumnclass(_column);
                    // [523]  Dim strColumnStyle As String = BuildColumnStyle(column) 
                    _strcolumnstyle = self.buildcolumnstyle(_column);
                    // [524]  tColumn.AddClass(strColumnClass) 
                    _tcolumn.addclass(_strcolumnclass);
                    // [525]  tColumn.AddAttribute( {120} ,strColumnStyle) 
                    _tcolumn.addattribute("style", _strcolumnstyle);
                    // [526]  tColumn.AddClass(column.ClassName) 
                    _tcolumn.addclass(_column._classname);
                    // [528]  App.MaterialUseTheme(column.Theme,tColumn) 
                    self._app.materialusetheme(_column._theme, _tcolumn);
                    // [530]  Dim classKey As String = {19} 
                    _classkey = "r" + self._lastrow + "c" + _lastcolumn + "";
                    // [531]  If columnClasses.ContainsKey(classKey) Then 
                    if ((_classkey in self._columnclasses)) {
                        // [533]  Dim cm As Map = columnClasses.Get(classKey) 
                        _cm = self._columnclasses[_classkey];
                        // [534]  tColumn.AddClass(MapKeys2Delim(cm, {121} )) 
                        _tcolumn.addclass(self.mapkeys2delim(_cm, " "));
                        // [535]  End If 
                    }
                    // [536]  If Components.ContainsKey(cellKey) Then 
                    if ((_cellkey in self._components)) {
                        // [537]  Dim lst As List = Components.Get(cellKey) 
                        _lst = self._components[_cellkey];
                        // [538]  tColumn.AddContentList(lst) 
                        _tcolumn.addcontentlist(_lst);
                        // [539]  End If 
                    }
                    // [540]  tRow.AddElement(tColumn) 
                    _trow.addelement(_tcolumn);
                    // [542]  Next 
                }
                // [543]  Next 
            }
            // [544]  Dim strRow As String = tRow.tostring 
            _strrow = _trow.tostring();
            // [545]  sb.Append(strRow).Append(CRLF) 
            _sb.append(_strrow).append("\n");
            // [547]  Next 
        }
        // [548]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [552] private Sub BuildColumnClass(col As UOEColumn) As String 
    this.buildcolumnclass = function (_col) {
        if (self == null) self = this;
        var _strspans;
        var _stroffsets;
        var _sb;
        // [553]  Dim strSpans As String = BuildSpans(col.SpanSmall,col.SpanMedium,col.SpanLarge) 
        _strspans = self.buildspans(_col._spansmall, _col._spanmedium, _col._spanlarge);
        // [554]  Dim strOffSets As String = BuildOffsets(col.offsetsmall,col.offsetmedium,col.Offsetlarge) 
        _stroffsets = self.buildoffsets(_col._offsetsmall, _col._offsetmedium, _col._offsetlarge);
        // [556]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [557]  sb.Initialize 
        _sb.isinitialized = true;
        // [558]  sb.Append( {20} ) 
        _sb.append("" + self._cellclass + " ");
        // [559]  sb.Append(strSpans) 
        _sb.append(_strspans);
        // [561]  sb.Append(strOffSets) 
        _sb.append(_stroffsets);
        // [562]  Return sb.tostring.trim 
        return _sb.toString().trim();
        // End Sub
    };

    // [565] private Sub BuildRowStyle(row As UOERow) As String 
    this.buildrowstyle = function (_row) {
        if (self == null) self = this;
        var _rowc;
        var _rowkey;
        var _hasrow;
        var _strmargins;
        var _strpadding;
        var _sb;
        // [566]  Dim rowc As Map 
        _rowc = {};
        // [567]  rowc.Initialize 
        _rowc = {};
        // [568]  rowc.clear 
        _rowc = {};
        // [569]  Dim rowKey As String = {21} 
        _rowkey = "r" + _row._row + "";
        // [570]  Dim hasrow As Boolean = rowPadding.ContainsKey(rowKey) 
        _hasrow = (_rowkey in self._rowpadding);
        // [571]  If hasrow Then 
        if (_hasrow) {
            // [572]  rowc = rowPadding.Get(rowKey) 
            _rowc = self._rowpadding[_rowkey];
            // [573]  row.PaddingTop = rowc.get( {123} ) 
            _row._paddingtop = _rowc["pt"];
            // [574]  row.PaddingBottom = rowc.get( {124} ) 
            _row._paddingbottom = _rowc["pb"];
            // [575]  row.PaddingLeft = rowc.get( {125} ) 
            _row._paddingleft = _rowc["pl"];
            // [576]  row.PaddingRight = rowc.get( {126} ) 
            _row._paddingright = _rowc["pr"];
            // [577]  End If 
        }
        // [578]  Dim hasrow As Boolean = rowMargins.ContainsKey(rowKey) 
        _hasrow = (_rowkey in self._rowmargins);
        // [579]  If hasrow Then 
        if (_hasrow) {
            // [580]  rowc = rowMargins.Get(rowKey) 
            _rowc = self._rowmargins[_rowkey];
            // [581]  row.MarginTop = rowc.get( {127} ) 
            _row._margintop = _rowc["mt"];
            // [582]  row.MarginBottom = rowc.get( {128} ) 
            _row._marginbottom = _rowc["mb"];
            // [583]  row.MarginLeft = rowc.get( {129} ) 
            _row._marginleft = _rowc["ml"];
            // [584]  row.MarginRight = rowc.get( {130} ) 
            _row._marginright = _rowc["mr"];
            // [585]  End If 
        }
        // [587]  Dim strMargins As String = BuildMargins(row.MarginTop,row.MarginBottom,row.MarginLeft,row.MarginRight) 
        _strmargins = self.buildmargins(_row._margintop, _row._marginbottom, _row._marginleft, _row._marginright);
        // [588]  Dim strPadding As String = BuildPadding(row.PaddingTop,row.PaddingBottom,row.PaddingLeft,row.PaddingRight) 
        _strpadding = self.buildpadding(_row._paddingtop, _row._paddingbottom, _row._paddingleft, _row._paddingright);
        // [589]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [590]  sb.Initialize 
        _sb.isinitialized = true;
        // [592]  sb.Append(strMargins) 
        _sb.append(_strmargins);
        // [594]  sb.Append(strPadding) 
        _sb.append(_strpadding);
        // [595]  Return sb.tostring.trim 
        return _sb.toString().trim();
        // End Sub
    };

    // [598] private Sub BuildColumnStyle(col As UOEColumn) As String 
    this.buildcolumnstyle = function (_col) {
        if (self == null) self = this;
        var _rowc;
        var _rowkey;
        var _hascolumn;
        var _strmargins;
        var _strpadding;
        var _sb;
        // [599]  Dim rowc As Map 
        _rowc = {};
        // [600]  rowc.Initialize 
        _rowc = {};
        // [601]  rowc.clear 
        _rowc = {};
        // [602]  Dim rowKey As String = {22} 
        _rowkey = "r" + _col._row + "c" + _col._col + "";
        // [603]  Dim hascolumn As Boolean = rowPadding.ContainsKey(rowKey) 
        _hascolumn = (_rowkey in self._rowpadding);
        // [604]  If hascolumn Then 
        if (_hascolumn) {
            // [605]  rowc = rowPadding.Get(rowKey) 
            _rowc = self._rowpadding[_rowkey];
            // [606]  col.PaddingTop = rowc.get( {131} ) 
            _col._paddingtop = _rowc["pt"];
            // [607]  col.PaddingBottom = rowc.get( {132} ) 
            _col._paddingbottom = _rowc["pb"];
            // [608]  col.PaddingLeft = rowc.get( {133} ) 
            _col._paddingleft = _rowc["pl"];
            // [609]  col.PaddingRight = rowc.get( {134} ) 
            _col._paddingright = _rowc["pr"];
            // [610]  End If 
        }
        // [611]  Dim hascolumn As Boolean = rowMargins.ContainsKey(rowKey) 
        _hascolumn = (_rowkey in self._rowmargins);
        // [612]  If hascolumn Then 
        if (_hascolumn) {
            // [613]  rowc = rowMargins.Get(rowKey) 
            _rowc = self._rowmargins[_rowkey];
            // [614]  col.MarginTop = rowc.get( {135} ) 
            _col._margintop = _rowc["mt"];
            // [615]  col.MarginBottom = rowc.get( {136} ) 
            _col._marginbottom = _rowc["mb"];
            // [616]  col.MarginLeft = rowc.get( {137} ) 
            _col._marginleft = _rowc["ml"];
            // [617]  col.MarginRight = rowc.get( {138} ) 
            _col._marginright = _rowc["mr"];
            // [618]  End If 
        }
        // [620]  Dim strMargins As String = BuildMargins(col.MarginTop,col.MarginBottom,col.MarginLeft,col.MarginRight) 
        _strmargins = self.buildmargins(_col._margintop, _col._marginbottom, _col._marginleft, _col._marginright);
        // [621]  Dim strPadding As String = BuildPadding(col.PaddingTop,col.PaddingBottom,col.PaddingLeft,col.PaddingRight) 
        _strpadding = self.buildpadding(_col._paddingtop, _col._paddingbottom, _col._paddingleft, _col._paddingright);
        // [622]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [623]  sb.Initialize 
        _sb.isinitialized = true;
        // [625]  sb.Append(strMargins) 
        _sb.append(_strmargins);
        // [627]  sb.Append(strPadding) 
        _sb.append(_strpadding);
        // [628]  Return sb.tostring.trim 
        return _sb.toString().trim();
        // End Sub
    };

    // [632] private Sub BuildRowClass() As String 
    this.buildrowclass = function () {
        if (self == null) self = this;
        var _sb;
        // [633]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [634]  sb.Initialize 
        _sb.isinitialized = true;
        // [635]  sb.Append( {23} ) 
        _sb.append("" + self._rowclass + " ");
        // [636]  Return sb.tostring.trim 
        return _sb.toString().trim();
        // End Sub
    };

    // [640] Private Sub BuildSpans(SS As Int, SM As Int, SL As Int) As String 
    this.buildspans = function (_ss, _sm, _sl) {
        if (self == null) self = this;
        var _sb;
        var _ktot;
        var _kcnt;
        var _colkey;
        var _colc;
        // [641]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [642]  sb.Initialize 
        _sb.isinitialized = true;
        // [644]  Dim kTot As Int = colClass.Size - 1 
        _ktot = Object.keys(self._colclass).length - 1;
        // [645]  Dim kCnt As Int 
        _kcnt = 0;
        // [646]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [647]  Dim colKey As String = colClass.GetKeyAt(kCnt) 
            _colkey = banano_getB4JKeyAt(self._colclass, _kcnt);
            // [649]  Dim colC As String = colClass.Get(colKey) 
            _colc = self._colclass[_colkey];
            // [650]  sb.Append(colC) 
            _sb.append(_colc);
            // [652]  Select Case colKey 
            switch ("" + _colkey) {
                // [653]  Case {139} 
                case "" + "s":
                    // [654]  sb.Append(SS) 
                    _sb.append(_ss);
                    // [655]  Case {140} 
                    break;
                case "" + "m":
                    // [656]  sb.Append(SM) 
                    _sb.append(_sm);
                    // [657]  Case {141} 
                    break;
                case "" + "l":
                    // [658]  sb.Append(SL) 
                    _sb.append(_sl);
                    // [659]  End Select 
                    break;
            }
            // [660]  sb.Append( {142} ) 
            _sb.append(" ");
            // [661]  Next 
        }
        // [662]  Return sb.ToString 
        return _sb.toString();
        // End Sub
    };

    // [666] Private Sub BuildOffsets(OS As Int, OM As Int, OL As Int) As String 
    this.buildoffsets = function (_os, _om, _ol) {
        if (self == null) self = this;
        var _pvalue;
        var _sb;
        var _ktot;
        var _kcnt;
        var _colkey;
        var _colc;
        // [667]  Dim pvalue As String = {143} 
        _pvalue = "0";
        // [668]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [669]  sb.Initialize 
        _sb.isinitialized = true;
        // [670]  Dim kTot As Int = offClass.Size - 1 
        _ktot = Object.keys(self._offclass).length - 1;
        // [671]  Dim kCnt As Int = 0 
        _kcnt = 0;
        // [672]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [673]  Dim colKey As String = offClass.GetKeyAt(kCnt) 
            _colkey = banano_getB4JKeyAt(self._offclass, _kcnt);
            // [675]  Dim colC As String = offClass.Get(colKey) 
            _colc = self._offclass[_colkey];
            // [677]  Select Case colKey 
            switch ("" + _colkey) {
                // [678]  Case {144} 
                case "" + "s":
                    // [679]  pvalue = CStr(OS) 
                    _pvalue = self.cstr(_os);
                    // [680]  Case {145} 
                    break;
                case "" + "m":
                    // [681]  pvalue = CStr(OM) 
                    _pvalue = self.cstr(_om);
                    // [682]  Case {146} 
                    break;
                case "" + "l":
                    // [683]  pvalue = CStr(OL) 
                    _pvalue = self.cstr(_ol);
                    // [684]  End Select 
                    break;
            }
            // [685]  sb.Append(colC) 
            _sb.append(_colc);
            // [686]  sb.Append(pvalue) 
            _sb.append(_pvalue);
            // [687]  sb.Append( {147} ) 
            _sb.append(" ");
            // [688]  Next 
        }
        // [689]  Return sb.ToString 
        return _sb.toString();
        // End Sub
    };

    // [693] Private Sub BuildPadding(PT As Int, PB As Int, PL As Int, PR As Int) As String 
    this.buildpadding = function (_pt, _pb, _pl, _pr) {
        if (self == null) self = this;
        var _pvalue;
        var _sb;
        var _ktot;
        var _kcnt;
        var _colkey;
        var _colc;
        // [694]  Dim pvalue As String = {148} 
        _pvalue = "0";
        // [695]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [696]  sb.Initialize 
        _sb.isinitialized = true;
        // [698]  Dim kTot As Int = padClass.Size - 1 
        _ktot = Object.keys(self._padclass).length - 1;
        // [699]  Dim kCnt As Int 
        _kcnt = 0;
        // [700]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [701]  Dim colKey As String = padClass.GetKeyAt(kCnt) 
            _colkey = banano_getB4JKeyAt(self._padclass, _kcnt);
            // [702]  Dim colC As String = padClass.Get(colKey) 
            _colc = self._padclass[_colkey];
            // [703]  Select Case colKey 
            switch ("" + _colkey) {
                // [704]  Case {149} 
                case "" + "pt":
                    // [705]  pvalue = CStr(PT) 
                    _pvalue = self.cstr(_pt);
                    // [706]  Case {150} 
                    break;
                case "" + "pb":
                    // [707]  pvalue = CStr(PB) 
                    _pvalue = self.cstr(_pb);
                    // [708]  Case {151} 
                    break;
                case "" + "pl":
                    // [709]  pvalue = CStr(PL) 
                    _pvalue = self.cstr(_pl);
                    // [710]  Case {152} 
                    break;
                case "" + "pr":
                    // [711]  pvalue = CStr(PR) 
                    _pvalue = self.cstr(_pr);
                    // [712]  End Select 
                    break;
            }
            // [713]  sb.Append(colC) 
            _sb.append(_colc);
            // [714]  sb.Append(pvalue) 
            _sb.append(_pvalue);
            // [715]  sb.Append( {153} ) 
            _sb.append("px !important; ");
            // [716]  Next 
        }
        // [717]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [721] Private Sub BuildMargins(MT As Int, MB As Int, ML As Int, MR As Int) As String 
    this.buildmargins = function (_mt, _mb, _ml, _mr) {
        if (self == null) self = this;
        var _pvalue;
        var _sb;
        var _ktot;
        var _kcnt;
        var _colkey;
        var _colc;
        // [722]  Dim pvalue As String = {154} 
        _pvalue = "0";
        // [723]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [724]  sb.Initialize 
        _sb.isinitialized = true;
        // [726]  Dim kTot As Int = marClass.Size - 1 
        _ktot = Object.keys(self._marclass).length - 1;
        // [727]  Dim kCnt As Int 
        _kcnt = 0;
        // [728]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [729]  Dim colKey As String = marClass.GetKeyAt(kCnt) 
            _colkey = banano_getB4JKeyAt(self._marclass, _kcnt);
            // [730]  Dim colC As String = marClass.Get(colKey) 
            _colc = self._marclass[_colkey];
            // [731]  Select Case colKey 
            switch ("" + _colkey) {
                // [732]  Case {155} 
                case "" + "mt":
                    // [733]  pvalue = CStr(MT) 
                    _pvalue = self.cstr(_mt);
                    // [734]  Case {156} 
                    break;
                case "" + "mb":
                    // [735]  pvalue = CStr(MB) 
                    _pvalue = self.cstr(_mb);
                    // [736]  Case {157} 
                    break;
                case "" + "ml":
                    // [737]  pvalue = CStr(ML) 
                    _pvalue = self.cstr(_ml);
                    // [738]  Case {158} 
                    break;
                case "" + "mr":
                    // [739]  pvalue = CStr(MR) 
                    _pvalue = self.cstr(_mr);
                    // [740]  End Select 
                    break;
            }
            // [741]  sb.Append(colC) 
            _sb.append(_colc);
            // [742]  sb.Append(pvalue) 
            _sb.append(_pvalue);
            // [743]  sb.Append( {159} ) 
            _sb.append("px !important; ");
            // [744]  Next 
        }
        // [745]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [749] Sub RowExists(rowPos As Int) As Boolean 
    this.rowexists = function (_rowpos) {
        if (self == null) self = this;
        var _rowcol;
        // [750]  Dim rowcol As String = {24} 
        _rowcol = "r" + _rowpos + "";
        // [751]  Return Rows.ContainsKey(rowcol) 
        return (_rowcol in self._rows);
        // End Sub
    };

    // [755] Sub ColumnExists(rowPos As Int, colPos As Int) As Boolean 
    this.columnexists = function (_rowpos, _colpos) {
        if (self == null) self = this;
        var _rowcol;
        // [756]  Dim rowcol As String = {25} 
        _rowcol = "r" + _rowpos + "c" + _colpos + "";
        // [757]  Return RC.ContainsKey(rowcol) 
        return (_rowcol in self._rc);
        // End Sub
    };

    // [761] Sub HowManyRows() As Int 
    this.howmanyrows = function () {
        if (self == null) self = this;
        // [762]  Return LastRow 
        return self._lastrow;
        // End Sub
    };

}
// =========================== UOEHTML  ===========================
function banano_uoebanano_uoehtml() {
    var self;
    this._id = '';

    this._tag = '';

    this._properties = {};

    this._contents = [];

    this._classes = {};

    this._styles = {};

    this._looseattributes = [];

    this._dontbreak = [];

    this._prefix = '';

    this._doaproperclose = false;

    this._required = false;

    this._enabled = false;

    this._inline = false;

    this._readonly = false;

    this._cssrule = {};

    this._singlequote = [];

    this._parentid = '';

    this._text = '';

    this._textafter = false;

    this._divider = '';

    // [27] Sub GetStyleAttribute(attr As String) As String 
    this.getstyleattribute = function (_attr) {
        if (self == null) self = this;
        var _hasitem;
        // [28]  attr = attr.ToLowerCase 
        _attr = _attr.toLowerCase();
        // [29]  attr = RemDelim(attr, {5} ).Trim 
        _attr = self.remdelim(_attr, ":").trim();
        // [30]  Dim hasItem As Boolean = styles.ContainsKey(attr) 
        _hasitem = (_attr in self._styles);
        // [31]  If hasItem Then 
        if (_hasitem) {
            // [32]  Return styles.Get(attr) 
            return self._styles[_attr];
            // [33]  Else 
        } else {
            // [34]  Return {6} 
            return "";
            // [35]  End If 
        }
        // End Sub
    };

    // [39] public Sub SetContents(value As String) As UOEHTML 
    this.setcontents = function (_value) {
        if (self == null) self = this;
        // [40]  Contents.Initialize 
        self._contents.length = 0;
        // [41]  Contents.clear 
        self._contents.length = 0;
        // [42]  If value.Length > 0 Then 
        if (_value.length > 0) {
            // [43]  value = FormatText(value) 
            _value = self.formattext(_value);
            // [44]  Contents.Add(value) 
            self._contents.push(_value);
            // [45]  End If 
        }
        // [46]  Return Me 
        return self;
        // End Sub
    };

    // [50] public Sub AddElementLine(el As UOEHTML) As UOEHTML 
    this.addelementline = function (_el) {
        if (self == null) self = this;
        var _scode;
        // [51]  If el <> Null Then 
        if (_el != null) {
            // [52]  Dim scode As String = el.html 
            _scode = _el.html();
            // [53]  AddContent(scode) 
            self.addcontent(_scode);
            // [54]  End If 
        }
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub SetROLE(sValue As String) As UOEHTML 
    this.setrole = function (_svalue) {
        if (self == null) self = this;
        // [60]  AddAttribute( {7} ,sValue) 
        self.addattribute("role", _svalue);
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [66] public Sub AddContentLine(value As String) As UOEHTML 
    this.addcontentline = function (_value) {
        if (self == null) self = this;
        // [67]  If value <> {8} Then 
        if (_value != "") {
            // [68]  value = value.Replace(CRLF, {9} ) 
            _value = _value.split("\n").join("");
            // [69]  value = FormatText(value) 
            _value = self.formattext(_value);
            // [70]  Contents.Add(value) 
            self._contents.push(_value);
            // [71]  End If 
        }
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub MaterialAddDivider(sVisibility As String, themeName As String) As UOEHTML 
    this.materialadddivider = function (_svisibility, _themename) {
        if (self == null) self = this;
        var _li;
        // [77]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [78]  li.Initialize( {10} , {11} ) 
        _li.initialize("", "li");
        // [79]  li.AddClass( {12} ) 
        _li.addclass("divider");
        // [80]  li.MaterialVisibility(sVisibility) 
        _li.materialvisibility(_svisibility);
        // [81]  divider = li.html 
        self._divider = _li.html();
        // [82]  Return Me 
        return self;
        // End Sub
    };

    // [86] Sub MaterialAddDividerOnCondition(bStatus As Boolean, sVisibility As String, themeName As String) As UOEHTML 
    this.materialadddivideroncondition = function (_bstatus, _svisibility, _themename) {
        if (self == null) self = this;
        // [87]  If bStatus = True Then 
        if (_bstatus == true) {
            // [88]  MaterialAddDivider(sVisibility,themeName) 
            self.materialadddivider(_svisibility, _themename);
            // [89]  End If 
        }
        // [90]  Return Me 
        return self;
        // End Sub
    };

    // [94] Sub MaterialButton(bStatus As Boolean) As UOEHTML 
    this.materialbutton = function (_bstatus) {
        if (self == null) self = this;
        // [95]  AddClassOnCondition(bStatus, {13} ) 
        self.addclassoncondition(_bstatus, "btn");
        // [96]  Return Me 
        return self;
        // End Sub
    };

    // [99] Sub SetTypeNumbers() As UOEHTML 
    this.settypenumbers = function () {
        if (self == null) self = this;
        // [100]  AddAttribute( {14} , {15} ) 
        self.addattribute("type", "1");
        // [101]  Return Me 
        return self;
        // End Sub
    };

    // [104] Sub SetTypeUpperCase() As UOEHTML 
    this.settypeuppercase = function () {
        if (self == null) self = this;
        // [105]  AddAttribute( {16} , {17} ) 
        self.addattribute("type", "A");
        // [106]  Return Me 
        return self;
        // End Sub
    };

    // [109] Sub SetTypeLowerCase() As UOEHTML 
    this.settypelowercase = function () {
        if (self == null) self = this;
        // [110]  AddAttribute( {18} , {19} ) 
        self.addattribute("type", "a");
        // [111]  Return Me 
        return self;
        // End Sub
    };

    // [114] Sub SetTypeUpperCaseRoman() As UOEHTML 
    this.settypeuppercaseroman = function () {
        if (self == null) self = this;
        // [115]  AddAttribute( {20} , {21} ) 
        self.addattribute("type", "I");
        // [116]  Return Me 
        return self;
        // End Sub
    };

    // [119] Sub SetTypeLowerCaseRoman() As UOEHTML 
    this.settypelowercaseroman = function () {
        if (self == null) self = this;
        // [120]  AddAttribute( {22} , {23} ) 
        self.addattribute("type", "i");
        // [121]  Return Me 
        return self;
        // End Sub
    };

    // [125] Sub SetListStyleCircle() As UOEHTML 
    this.setliststylecircle = function () {
        if (self == null) self = this;
        // [126]  AddStyleAttribute( {24} , {25} ) 
        self.addstyleattribute("list-style-type", "circle");
        // [127]  Return Me 
        return self;
        // End Sub
    };

    // [130] Sub SetListStyleDisk() As UOEHTML 
    this.setliststyledisk = function () {
        if (self == null) self = this;
        // [131]  AddStyleAttribute( {26} , {27} ) 
        self.addstyleattribute("list-style-type", "disk");
        // [132]  Return Me 
        return self;
        // End Sub
    };

    // [135] Sub SetListStyleNone() As UOEHTML 
    this.setliststylenone = function () {
        if (self == null) self = this;
        // [136]  AddStyleAttribute( {28} , {29} ) 
        self.addstyleattribute("list-style-type", "none");
        // [137]  Return Me 
        return self;
        // End Sub
    };

    // [140] Sub SetListStyleSquare() As UOEHTML 
    this.setliststylesquare = function () {
        if (self == null) self = this;
        // [141]  AddStyleAttribute( {30} , {31} ) 
        self.addstyleattribute("list-style-type", "square");
        // [142]  Return Me 
        return self;
        // End Sub
    };

    // [145] Sub AddHeading(sSize As Int, sContent As String) As UOEHTML 
    this.addheading = function (_ssize, _scontent) {
        if (self == null) self = this;
        var _hdr;
        var _hkey;
        // [146]  Dim hdr As UOEHTML 
        _hdr = new banano_uoebanano_uoehtml();
        // [147]  Dim hKey As String = {32} & sSize 
        _hkey = "h" + _ssize;
        // [148]  hdr.Initialize( {33} ,hKey) 
        _hdr.initialize("", _hkey);
        // [149]  hdr.AddContent(sContent) 
        _hdr.addcontent(_scontent);
        // [150]  AddContent(hdr.HTML) 
        self.addcontent(_hdr.html());
        // [151]  Return Me 
        return self;
        // End Sub
    };

    // [154] Sub AddParagraph(sContent As String) As UOEHTML 
    this.addparagraph = function (_scontent) {
        if (self == null) self = this;
        var _p;
        // [155]  Dim p As UOEHTML 
        _p = new banano_uoebanano_uoehtml();
        // [156]  p.Initialize( {34} , {35} ) 
        _p.initialize("", "p");
        // [157]  p.AddContent(sContent) 
        _p.addcontent(_scontent);
        // [158]  AddContent(p.HTML) 
        self.addcontent(_p.html());
        // [159]  Return Me 
        return self;
        // End Sub
    };

    // [164] Sub AddLooseAttributeOnFalseCondition(bStatus As Boolean, value As String) As UOEHTML 
    this.addlooseattributeonfalsecondition = function (_bstatus, _value) {
        if (self == null) self = this;
        // [165]  removeAttr(value) 
        self.removeattr(_value);
        // [166]  If bStatus = False Then 
        if (_bstatus == false) {
            // [167]  AddLooseAttribute(value) 
            self.addlooseattribute(_value);
            // [168]  End If 
        }
        // [169]  Return Me 
        return self;
        // End Sub
    };

    // [173] Sub SetElementTypeOnCondition(bStatus As Boolean,sElementType As String) As UOEHTML 
    this.setelementtypeoncondition = function (_bstatus, _selementtype) {
        if (self == null) self = this;
        // [174]  If bStatus Then 
        if (_bstatus) {
            // [175]  Tag = sElementType 
            self._tag = _selementtype;
            // [176]  End If 
        }
        // [177]  Return Me 
        return self;
        // End Sub
    };

    // [181] Sub MaterialCollectionItem(bStatus As Boolean) As UOEHTML 
    this.materialcollectionitem = function (_bstatus) {
        if (self == null) self = this;
        // [182]  AddClassOnCondition(bStatus, {36} ) 
        self.addclassoncondition(_bstatus, "collection-item");
        // [183]  Return Me 
        return self;
        // End Sub
    };

    // [186] Sub MaterialModalClose() As UOEHTML 
    this.materialmodalclose = function () {
        if (self == null) self = this;
        // [187]  addClass( {37} ) 
        self.addclass("modal-action");
        // [188]  addClass( {38} ) 
        self.addclass("modal-close");
        // [189]  Return Me 
        return self;
        // End Sub
    };

    // [192] Sub MaterialAvatar(bStatus As Boolean) As UOEHTML 
    this.materialavatar = function (_bstatus) {
        if (self == null) self = this;
        // [193]  AddClassOnCondition(bStatus, {39} ) 
        self.addclassoncondition(_bstatus, "avatar");
        // [194]  Return Me 
        return self;
        // End Sub
    };

    // [197] Sub MaterialSecondaryContent(bStatus As Boolean) As UOEHTML 
    this.materialsecondarycontent = function (_bstatus) {
        if (self == null) self = this;
        // [198]  AddClassOnCondition(bStatus, {40} ) 
        self.addclassoncondition(_bstatus, "secondary-content");
        // [199]  Return Me 
        return self;
        // End Sub
    };

    // [202] Sub MaterialCollectionHeader(bStatus As Boolean) As UOEHTML 
    this.materialcollectionheader = function (_bstatus) {
        if (self == null) self = this;
        // [203]  AddClassOnCondition(bStatus, {41} ) 
        self.addclassoncondition(_bstatus, "collection-header");
        // [204]  Return Me 
        return self;
        // End Sub
    };

    // [208] Sub MaterialCollapsibleHeader(bStatus As Boolean) As UOEHTML 
    this.materialcollapsibleheader = function (_bstatus) {
        if (self == null) self = this;
        // [209]  AddClassOnCondition(bStatus, {42} ) 
        self.addclassoncondition(_bstatus, "collapsible-header");
        // [210]  Return Me 
        return self;
        // End Sub
    };

    // [214] Sub SetZIndex(zindex As String) As UOEHTML 
    this.setzindex = function (_zindex) {
        if (self == null) self = this;
        // [215]  AddStyleAttribute( {43} ,zindex) 
        self.addstyleattribute("z-index", _zindex);
        // [216]  Return Me 
        return self;
        // End Sub
    };

    // [219] Sub AddContentListReverse(lst As List) As UOEHTML 
    this.addcontentlistreverse = function (_lst) {
        if (self == null) self = this;
        var _ltot;
        var _lcnt;
        var _strcontent;
        // [220]  Dim lTot As Int = lst.Size - 1 
        _ltot = _lst.length - 1;
        // [221]  Dim lCnt As Int 
        _lcnt = 0;
        // [222]  For lCnt = lTot To 0 Step -1 
        for (_lcnt = _ltot; _lcnt >= 0; _lcnt -= 1) {
            // [223]  Dim strContent As String = lst.Get(lCnt) 
            _strcontent = _lst[_lcnt];
            // [224]  AddContent(strContent) 
            self.addcontent(_strcontent);
            // [225]  Next 
        }
        // [226]  Return Me 
        return self;
        // End Sub
    };

    // [230] Sub SetFOR(sFor As String) As UOEHTML 
    this.setfor = function (_sfor) {
        if (self == null) self = this;
        // [231]  AddAttribute( {44} ,sFor) 
        self.addattribute("for", _sfor);
        // [232]  Return Me 
        return self;
        // End Sub
    };

    // [236] Sub SetVALUE(sValue As String) As UOEHTML 
    this.setvalue = function (_svalue) {
        if (self == null) self = this;
        // [237]  AddAttribute( {45} ,sValue) 
        self.addattribute("value", _svalue);
        // [238]  Return Me 
        return self;
        // End Sub
    };

    // [242] Sub SetNAME(sName As String) As UOEHTML 
    this.setname = function (_sname) {
        if (self == null) self = this;
        // [243]  AddAttribute( {46} ,sName) 
        self.addattribute("name", _sname);
        // [244]  Return Me 
        return self;
        // End Sub
    };

    // [247] Sub SetTYPE(sValue As String) As UOEHTML 
    this.settype = function (_svalue) {
        if (self == null) self = this;
        // [248]  AddAttribute( {47} ,sValue) 
        self.addattribute("type", _svalue);
        // [249]  Return Me 
        return self;
        // End Sub
    };

    // [253] Sub UpdateAttribute(name As String, propValue As String) As UOEHTML 
    this.updateattribute = function (_name, _propvalue) {
        if (self == null) self = this;
        var _svalue;
        // [254]  If properties.ContainsKey(name) Then 
        if ((_name in self._properties)) {
            // [255]  Dim svalue As String = properties.Get(name) 
            _svalue = self._properties[_name];
            // [256]  svalue = svalue & {48} & propValue 
            _svalue = _svalue + ";" + _propvalue;
            // [257]  properties.Put(name,svalue) 
            self._properties[_name] = _svalue;
            // [258]  Else 
        } else {
            // [259]  properties.Put(name,propValue) 
            self._properties[_name] = _propvalue;
            // [260]  End If 
        }
        // [261]  Return Me 
        return self;
        // End Sub
    };

    // [265] Sub AddLooseAttributeOnCondition(bStatus As Boolean, value As String) As UOEHTML 
    this.addlooseattributeoncondition = function (_bstatus, _value) {
        if (self == null) self = this;
        // [266]  removeAttr(value) 
        self.removeattr(_value);
        // [267]  If bStatus = True Then 
        if (_bstatus == true) {
            // [268]  AddAttribute(value, {49} ) 
            self.addattribute(_value, "true");
            // [269]  End If 
        }
        // [270]  Return Me 
        return self;
        // End Sub
    };

    // [274] Sub AddLooseAttribute(value As String) As UOEHTML 
    this.addlooseattribute = function (_value) {
        if (self == null) self = this;
        // [275]  removeAttr(value) 
        self.removeattr(_value);
        // [276]  AddAttribute(value, {50} ) 
        self.addattribute(_value, "true");
        // [277]  Return Me 
        return self;
        // End Sub
    };

    // [281] Sub MakePx(sValue As String) As String 
    this.makepx = function (_svalue) {
        if (self == null) self = this;
        var _endp;
        var _endpx;
        // [282]  Dim endp As Boolean = sValue.EndsWith( {51} ) 
        _endp = _svalue.endsWith("%");
        // [283]  If endp Then 
        if (_endp) {
            // [284]  Return sValue 
            return _svalue;
            // [285]  Else 
        } else {
            // [286]  Dim endpx As Boolean = sValue.EndsWith( {52} ) 
            _endpx = _svalue.endsWith("px");
            // [287]  If endpx Then 
            if (_endpx) {
                // [288]  Return sValue 
                return _svalue;
                // [289]  Else 
            } else {
                // [290]  sValue = sValue.Trim 
                _svalue = _svalue.trim();
                // [291]  sValue = sValue.Replace( {53} , {54} ) 
                _svalue = _svalue.split("px").join("");
                // [292]  sValue = {0} 
                _svalue = "" + _svalue + "px";
                // [293]  If sValue = {55} Then 
                if (_svalue == "px") {
                    // [294]  sValue = {56} 
                    _svalue = "";
                    // [295]  End If 
                }
                // [296]  Return sValue 
                return _svalue;
                // [297]  End If 
            }
            // [298]  End If 
        }
        // End Sub
    };

    // [303] Sub MaterialTextColor(sColor As String) As UOEHTML 
    this.materialtextcolor = function (_scolor) {
        if (self == null) self = this;
        var _ew;
        // [304]  sColor = sColor.trim 
        _scolor = _scolor.trim();
        // [305]  If sColor = {57} Then Return Me 
        if (_scolor == "") {
            return self;
        }
        // [306]  Dim ew As Boolean = sColor.EndsWith( {58} ) 
        _ew = _scolor.endsWith("-text");
        // [307]  If ew = False Then 
        if (_ew == false) {
            // [308]  sColor = sColor & {59} 
            _scolor = _scolor + "-text";
            // [309]  End If 
        }
        // [310]  addClass(sColor) 
        self.addclass(_scolor);
        // [311]  Return Me 
        return self;
        // End Sub
    };

    // [314] Sub AddDataAttribute(attribute As String, value As String) As UOEHTML 
    this.adddataattribute = function (_attribute, _value) {
        if (self == null) self = this;
        var _sw;
        // [315]  Dim sw As Boolean = attribute.StartsWith( {60} ) 
        _sw = _attribute.startsWith("data-");
        // [316]  If sw Then 
        if (_sw) {
            // [317]  AddAttribute(attribute,value) 
            self.addattribute(_attribute, _value);
            // [318]  Else 
        } else {
            // [319]  AddAttribute( {61} & attribute,value) 
            self.addattribute("data-" + _attribute, _value);
            // [320]  End If 
        }
        // [321]  Return Me 
        return self;
        // End Sub
    };

    // [324] Sub AddDataAttributeOnCondition(bCondition As Boolean,attribute As String, value As String) As UOEHTML 
    this.adddataattributeoncondition = function (_bcondition, _attribute, _value) {
        if (self == null) self = this;
        // [325]  removeAttrData(attribute) 
        self.removeattrdata(_attribute);
        // [326]  If bCondition = False Then 
        if (_bcondition == false) {
            // [327]  Return Me 
            return self;
            // [328]  End If 
        }
        // [329]  AddDataAttribute(attribute,value) 
        self.adddataattribute(_attribute, _value);
        // [330]  Return Me 
        return self;
        // End Sub
    };

    // [334] Sub MaterialBoxed(bStatus As String) As UOEHTML 
    this.materialboxed = function (_bstatus) {
        if (self == null) self = this;
        // [335]  AddClassOnCondition(bStatus, {62} ) 
        self.addclassoncondition(_bstatus, "materialboxed");
        // [336]  Return Me 
        return self;
        // End Sub
    };

    // [340] Sub MaterialResponsive(bStatus As Boolean) As UOEHTML 
    this.materialresponsive = function (_bstatus) {
        if (self == null) self = this;
        // [341]  AddClassOnCondition(bStatus, {63} ) 
        self.addclassoncondition(_bstatus, "responsive-img");
        // [342]  If bStatus = True Then 
        if (_bstatus == true) {
            // [343]  AddCursor 
            self.addcursor();
            // [344]  End If 
        }
        // [345]  Return Me 
        return self;
        // End Sub
    };

    // [349] Sub SetSRC(sValue As String, Static As Boolean) As UOEHTML 
    this.setsrc = function (_svalue, _static) {
        if (self == null) self = this;
        var _tmpfile;
        // [350]  Dim tmpFile As String = MvField(sValue,1, {64} ) 
        _tmpfile = self.mvfield(_svalue, 1, "?");
        // [351]  If Static Then 
        if (_static) {
            // [352]  sValue = tmpFile 
            _svalue = _tmpfile;
            // [353]  Else 
        } else {
            // [354]  sValue = tmpFile & {65} & DateTime.now 
            _svalue = _tmpfile + "?" + DateTime.Now();
            // [355]  End If 
        }
        // [356]  AddAttribute( {66} ,sValue) 
        self.addattribute("src", _svalue);
        // [357]  Return Me 
        return self;
        // End Sub
    };

    // [361] Sub SetALT(sValue As String) As UOEHTML 
    this.setalt = function (_svalue) {
        if (self == null) self = this;
        // [362]  AddAttribute( {67} ,sValue) 
        self.addattribute("alt", _svalue);
        // [363]  Return Me 
        return self;
        // End Sub
    };

    // [367] Sub MaterialCircle(bStatus As Boolean) As UOEHTML 
    this.materialcircle = function (_bstatus) {
        if (self == null) self = this;
        // [368]  AddClassOnCondition(bStatus, {68} ) 
        self.addclassoncondition(_bstatus, "circle");
        // [369]  Return Me 
        return self;
        // End Sub
    };

    // [373] Sub SetWidthPX(Width As String) As UOEHTML 
    this.setwidthpx = function (_width) {
        if (self == null) self = this;
        // [374]  If Width <> {69} Then 
        if (_width != "") {
            // [375]  AddStyleAttribute( {70} , MakePx(Width)) 
            self.addstyleattribute("width", self.makepx(_width));
            // [376]  End If 
        }
        // [377]  Return Me 
        return self;
        // End Sub
    };

    // [381] Sub SetHeightPX(Height As String) As UOEHTML 
    this.setheightpx = function (_height) {
        if (self == null) self = this;
        // [382]  If Height <> {71} Then 
        if (_height != "") {
            // [383]  AddStyleAttribute( {72} , MakePx(Height)) 
            self.addstyleattribute("height", self.makepx(_height));
            // [384]  End If 
        }
        // [385]  Return Me 
        return self;
        // End Sub
    };

    // [389] Sub MaterialToolBar(bStatus As Boolean) As UOEHTML 
    this.materialtoolbar = function (_bstatus) {
        if (self == null) self = this;
        // [390]  AddClassOnCondition(bStatus, {73} ) 
        self.addclassoncondition(_bstatus, "toolbar");
        // [391]  Return Me 
        return self;
        // End Sub
    };

    // [395] Sub MaterialHorizontal(bStatus As Boolean) As UOEHTML 
    this.materialhorizontal = function (_bstatus) {
        if (self == null) self = this;
        // [396]  AddClassOnCondition(bStatus, {74} ) 
        self.addclassoncondition(_bstatus, "horizontal");
        // [397]  Return Me 
        return self;
        // End Sub
    };

    // [400] Sub MaterialClick2Toggle(bStatus As Boolean) As UOEHTML 
    this.materialclick2toggle = function (_bstatus) {
        if (self == null) self = this;
        // [401]  AddClassOnCondition(bStatus, {75} ) 
        self.addclassoncondition(_bstatus, "click-to-toggle");
        // [402]  Return Me 
        return self;
        // End Sub
    };

    // [405] Sub AddStyleAttributeOnCondition(bCondition As Boolean, attr As String, value As String) As UOEHTML 
    this.addstyleattributeoncondition = function (_bcondition, _attr, _value) {
        if (self == null) self = this;
        // [406]  removeStyle(attr) 
        self.removestyle(_attr);
        // [407]  If bCondition = True Then 
        if (_bcondition == true) {
            // [408]  AddStyleAttribute(attr,value) 
            self.addstyleattribute(_attr, _value);
            // [409]  End If 
        }
        // [410]  Return Me 
        return self;
        // End Sub
    };

    // [413] Sub AddAttributeOnCondition(bCondition As Boolean, attr As String, value As String) As UOEHTML 
    this.addattributeoncondition = function (_bcondition, _attr, _value) {
        if (self == null) self = this;
        // [414]  removeAttr(attr) 
        self.removeattr(_attr);
        // [415]  If bCondition = True Then 
        if (_bcondition == true) {
            // [416]  AddAttribute(attr,value) 
            self.addattribute(_attr, _value);
            // [417]  End If 
        }
        // [418]  Return Me 
        return self;
        // End Sub
    };

    // [422] Sub MaterialButtonSize(sSize As String) As UOEHTML 
    this.materialbuttonsize = function (_ssize) {
        if (self == null) self = this;
        // [423]  If sSize.Length > 0 Then 
        if (_ssize.length > 0) {
            // [424]  removeClass( {76} ) 
            self.removeclass("btn-small");
            // [425]  removeClass( {77} ) 
            self.removeclass("btn-large");
            // [426]  removeClass( {78} ) 
            self.removeclass("btn-medium");
            // [427]  addClass(sSize) 
            self.addclass(_ssize);
            // [428]  addClass( {79} ) 
            self.addclass("btn");
            // [429]  End If 
        }
        // [430]  Return Me 
        return self;
        // End Sub
    };

    // [434] Sub MaterialButtonFloating(bStatus As Boolean) As UOEHTML 
    this.materialbuttonfloating = function (_bstatus) {
        if (self == null) self = this;
        // [435]  If bStatus Then 
        if (_bstatus) {
            // [436]  removeClass( {80} ) 
            self.removeclass("fixed-action-btn");
            // [437]  removeClass( {81} ) 
            self.removeclass("btn-flat");
            // [438]  removeClass( {82} ) 
            self.removeclass("btn-raised");
            // [439]  removeClass( {83} ) 
            self.removeclass("halfway-fab");
            // [440]  AddClassOnCondition(bStatus, {84} ) 
            self.addclassoncondition(_bstatus, "btn-floating");
            // [441]  End If 
        }
        // [442]  Return Me 
        return self;
        // End Sub
    };

    // [446] Sub MaterialPulse(bStatus As Boolean) As UOEHTML 
    this.materialpulse = function (_bstatus) {
        if (self == null) self = this;
        // [447]  AddClassOnCondition(bStatus, {85} ) 
        self.addclassoncondition(_bstatus, "pulse");
        // [448]  Return Me 
        return self;
        // End Sub
    };

    // [452] Sub MaterialButtonType(btnType As String) As UOEHTML 
    this.materialbuttontype = function (_btntype) {
        if (self == null) self = this;
        // [453]  If btnType.Length > 0 Then 
        if (_btntype.length > 0) {
            // [454]  removeClass( {86} ) 
            self.removeclass("fixed-action-btn");
            // [455]  removeClass( {87} ) 
            self.removeclass("btn-flat");
            // [456]  removeClass( {88} ) 
            self.removeclass("btn-raised");
            // [457]  removeClass( {89} ) 
            self.removeclass("halfway-fab");
            // [458]  removeClass( {90} ) 
            self.removeclass("btn-floating");
            // [459]  addClass(btnType) 
            self.addclass(_btntype);
            // [460]  End If 
        }
        // [461]  Return Me 
        return self;
        // End Sub
    };

    // [464] Sub GetAttribute(attr As String) As String 
    this.getattribute = function (_attr) {
        if (self == null) self = this;
        // [465]  attr = attr.tolowercase 
        _attr = _attr.toLowerCase();
        // [466]  If properties.ContainsKey(attr) Then 
        if ((_attr in self._properties)) {
            // [467]  Return properties.Get(attr) 
            return self._properties[_attr];
            // [468]  Else 
        } else {
            // [469]  Return {91} 
            return "";
            // [470]  End If 
        }
        // End Sub
    };

    // [474] Sub ClassExists(value As String) As Boolean 
    this.classexists = function (_value) {
        if (self == null) self = this;
        // [475]  value = value.trim 
        _value = _value.trim();
        // [476]  If value.Length > 0 Then 
        if (_value.length > 0) {
            // [477]  Return classes.ContainsKey(value) 
            return (_value in self._classes);
            // [478]  End If 
        }
        // [479]  Return False 
        return false;
        // End Sub
    };

    // [484] public Sub HTML As String 
    this.html = function () {
        if (self == null) self = this;
        var _sout;
        // [485]  Dim sOut As String = ToString 
        _sout = self.tostring();
        // [486]  Return sOut 
        return _sout;
        // End Sub
    };

    // [489] Sub MaterialWavesEffect(bStatus As Boolean) As UOEHTML 
    this.materialwaveseffect = function (_bstatus) {
        if (self == null) self = this;
        // [490]  AddClassOnCondition(bStatus, {92} ) 
        self.addclassoncondition(_bstatus, "waves-effect");
        // [491]  Return Me 
        return self;
        // End Sub
    };

    // [494] Sub MaterialWavesType(sType As String) As UOEHTML 
    this.materialwavestype = function (_stype) {
        if (self == null) self = this;
        // [495]  If sType.Length > 0 Then 
        if (_stype.length > 0) {
            // [496]  removeClass( {93} ) 
            self.removeclass("waves-green");
            // [497]  removeClass( {94} ) 
            self.removeclass("waves-light");
            // [498]  removeClass( {95} ) 
            self.removeclass("waves-orange");
            // [499]  removeClass( {96} ) 
            self.removeclass("waves-purple");
            // [500]  removeClass( {97} ) 
            self.removeclass("waves-red");
            // [501]  removeClass( {98} ) 
            self.removeclass("waves-teal");
            // [502]  removeClass( {99} ) 
            self.removeclass("waves-yellow");
            // [503]  addClass(sType) 
            self.addclass(_stype);
            // [504]  End If 
        }
        // [505]  Return Me 
        return self;
        // End Sub
    };

    // [508] Sub MaterialWavesCircle(bStatus As Boolean) As UOEHTML 
    this.materialwavescircle = function (_bstatus) {
        if (self == null) self = this;
        // [509]  If bStatus = True Then 
        if (_bstatus == true) {
            // [510]  removeClass( {100} ) 
            self.removeclass("waves-circle");
            // [511]  removeClass( {101} ) 
            self.removeclass("waves-block");
            // [512]  addClass( {102} ) 
            self.addclass("waves-circle");
            // [513]  End If 
        }
        // [514]  Return Me 
        return self;
        // End Sub
    };

    // [517] Sub MaterialWavesBlock(bStatus As Boolean) As UOEHTML 
    this.materialwavesblock = function (_bstatus) {
        if (self == null) self = this;
        // [518]  If bStatus = True Then 
        if (_bstatus == true) {
            // [519]  removeClass( {103} ) 
            self.removeclass("waves-circle");
            // [520]  removeClass( {104} ) 
            self.removeclass("waves-block");
            // [521]  addClass( {105} ) 
            self.addclass("waves-block");
            // [522]  End If 
        }
        // [523]  Return Me 
        return self;
        // End Sub
    };

    // [528] Sub MaterialWavesLight(bStatus As Boolean) As UOEHTML 
    this.materialwaveslight = function (_bstatus) {
        if (self == null) self = this;
        // [529]  AddClassOnCondition(bStatus, {106} ) 
        self.addclassoncondition(_bstatus, "waves-light");
        // [530]  Return Me 
        return self;
        // End Sub
    };

    // [534] Sub MaterialSetToolTip(position As String, delay As String, tooltip As String) As UOEHTML 
    this.materialsettooltip = function (_position, _delay, _tooltip) {
        if (self == null) self = this;
        // [535]  delay = CStr(delay) 
        _delay = self.cstr(_delay);
        // [536]  position = CStr(position) 
        _position = self.cstr(_position);
        // [537]  tooltip = CStr(tooltip) 
        _tooltip = self.cstr(_tooltip);
        // [538]  If tooltip.Length > 0 Then 
        if (_tooltip.length > 0) {
            // [539]  addClass( {107} ) 
            self.addclass("tooltipped");
            // [540]  AddAttribute( {108} ,position) 
            self.addattribute("data-position", _position);
            // [541]  AddAttribute( {109} ,delay) 
            self.addattribute("data-delay", _delay);
            // [542]  AddAttribute( {110} ,tooltip) 
            self.addattribute("data-tooltip", _tooltip);
            // [543]  Else 
        } else {
            // [544]  removeClass( {111} ) 
            self.removeclass("tooltipped");
            // [545]  removeClass( {112} ) 
            self.removeclass("data-position");
            // [546]  removeClass( {113} ) 
            self.removeclass("data-delay");
            // [547]  removeClass( {114} ) 
            self.removeclass("data-tooltip");
            // [548]  End If 
        }
        // [549]  Return Me 
        return self;
        // End Sub
    };

    // [552] Sub Pointer As String 
    this.pointer = function () {
        if (self == null) self = this;
        // [553]  Return {115} 
        return "cursor:pointer";
        // End Sub
    };

    // [556] Sub AddCursor As UOEHTML 
    this.addcursor = function () {
        if (self == null) self = this;
        // [557]  AddStyleAttribute( {116} , {117} ) 
        self.addstyleattribute("cursor", "pointer");
        // [558]  Return Me 
        return self;
        // End Sub
    };

    // [561] Sub setHREF(value As String) As UOEHTML 
    this.sethref = function (_value) {
        if (self == null) self = this;
        // [562]  AddAttribute( {118} ,value) 
        self.addattribute("href", _value);
        // [563]  Return Me 
        return self;
        // End Sub
    };

    // [566] Sub AddClassOnValue(iValue As Int, sClass As String) As UOEHTML 
    this.addclassonvalue = function (_ivalue, _sclass) {
        if (self == null) self = this;
        // [567]  If iValue > 0 Then 
        if (_ivalue > 0) {
            // [568]  addClass(sClass) 
            self.addclass(_sclass);
            // [569]  End If 
        }
        // [570]  Return Me 
        return self;
        // End Sub
    };

    // [573] Sub AddClassOnCondition(bCondition As Boolean, sClass As String) As UOEHTML 
    this.addclassoncondition = function (_bcondition, _sclass) {
        if (self == null) self = this;
        // [574]  removeClass(sClass) 
        self.removeclass(_sclass);
        // [575]  If bCondition = True Then 
        if (_bcondition == true) {
            // [576]  addClass(sClass) 
            self.addclass(_sclass);
            // [577]  End If 
        }
        // [578]  Return Me 
        return self;
        // End Sub
    };

    // [581] Sub AddClassOnFalseCondition(bCondition As Boolean, sClass As String) As UOEHTML 
    this.addclassonfalsecondition = function (_bcondition, _sclass) {
        if (self == null) self = this;
        // [582]  removeClass(sClass) 
        self.removeclass(_sclass);
        // [583]  If bCondition = False Then 
        if (_bcondition == false) {
            // [584]  addClass(sClass) 
            self.addclass(_sclass);
            // [585]  End If 
        }
        // [586]  Return Me 
        return self;
        // End Sub
    };

    // [589] Sub RemoveClassOnCondition(bCondition As Boolean, sClass As String) As UOEHTML 
    this.removeclassoncondition = function (_bcondition, _sclass) {
        if (self == null) self = this;
        // [590]  If bCondition = True Then 
        if (_bcondition == true) {
            // [591]  removeClass(sClass) 
            self.removeclass(_sclass);
            // [592]  End If 
        }
        // [593]  Return Me 
        return self;
        // End Sub
    };

    // [597] Sub RemoveClassOnFalseCondition(bCondition As Boolean, sClass As String) As UOEHTML 
    this.removeclassonfalsecondition = function (_bcondition, _sclass) {
        if (self == null) self = this;
        // [598]  If bCondition = False Then 
        if (_bcondition == false) {
            // [599]  removeClass(sClass) 
            self.removeclass(_sclass);
            // [600]  End If 
        }
        // [601]  Return Me 
        return self;
        // End Sub
    };

    // [606] Sub AddContentList(lst As List) As UOEHTML 
    this.addcontentlist = function (_lst) {
        if (self == null) self = this;
        var _strcontent;
        // [607]  For Each strContent As String In lst 
        for (var _strcontentindex = 0; _strcontentindex < _lst.length; _strcontentindex++) {
            _strcontent = _lst[_strcontentindex];
            // [608]  AddContent(strContent) 
            self.addcontent(_strcontent);
            // [609]  Next 
        }
        // [610]  Return Me 
        return self;
        // End Sub
    };

    // [615] Sub setText(sText As String,bAfter As Boolean) As UOEHTML 
    this.settext = function (_stext, _bafter) {
        if (self == null) self = this;
        // [616]  Text = sText 
        self._text = _stext;
        // [617]  TextAfter = bAfter 
        self._textafter = _bafter;
        // [618]  Return Me 
        return self;
        // End Sub
    };

    // [622] Sub setPrefix(sPrefix As String) As UOEHTML 
    this.setprefix = function (_sprefix) {
        if (self == null) self = this;
        // [623]  Prefix = sPrefix 
        self._prefix = _sprefix;
        // [624]  Return Me 
        return self;
        // End Sub
    };

    // [628] Sub setID(sID As String) As UOEHTML 
    this.setid = function (_sid) {
        if (self == null) self = this;
        // [629]  sID = sID.tolowercase 
        _sid = _sid.toLowerCase();
        // [630]  ID = sID 
        self._id = _sid;
        // [631]  Return Me 
        return self;
        // End Sub
    };

    // [635] Sub setTag(sTag As String) As UOEHTML 
    this.settag = function (_stag) {
        if (self == null) self = this;
        // [636]  Tag = sTag 
        self._tag = _stag;
        // [637]  Return Me 
        return self;
        // End Sub
    };

    // [641] Sub setParentID(sParentID As String) As UOEHTML 
    this.setparentid = function (_sparentid) {
        if (self == null) self = this;
        // [642]  ParentID = sParentID 
        self._parentid = _sparentid;
        // [643]  Return Me 
        return self;
        // End Sub
    };

    // [647] Sub setReadOnly(bReadOnly As Boolean) As UOEHTML 
    this.setreadonly = function (_breadonly) {
        if (self == null) self = this;
        // [648]  ReadOnly = bReadOnly 
        self._readonly = _breadonly;
        // [649]  Return Me 
        return self;
        // End Sub
    };

    // [653] Sub setInline(bInline As Boolean) As UOEHTML 
    this.setinline = function (_binline) {
        if (self == null) self = this;
        // [654]  Inline = bInline 
        self._inline = _binline;
        // [655]  Return Me 
        return self;
        // End Sub
    };

    // [659] Sub setEnabled(bEnabled As Boolean) As UOEHTML 
    this.setenabled = function (_benabled) {
        if (self == null) self = this;
        // [660]  Enabled = bEnabled 
        self._enabled = _benabled;
        // [661]  Return Me 
        return self;
        // End Sub
    };

    // [665] Sub setRequired(bRequired As Boolean) As UOEHTML 
    this.setrequired = function (_brequired) {
        if (self == null) self = this;
        // [666]  Required = bRequired 
        self._required = _brequired;
        // [667]  Return Me 
        return self;
        // End Sub
    };

    // [671] Public Sub Initialize(elID As String, eltag As String) 
    this.initialize = function (_elid, _eltag) {
        if (self == null) self = this;
        // [672]  ID = elID.ToLowerCase 
        self._id = _elid.toLowerCase();
        // [673]  properties.Initialize 
        self._properties = {};
        // [674]  properties.clear 
        self._properties = {};
        // [675]  Contents.Initialize 
        self._contents.length = 0;
        // [676]  Contents.clear 
        self._contents.length = 0;
        // [677]  styles.Initialize 
        self._styles = {};
        // [678]  styles.clear 
        self._styles = {};
        // [679]  classes.Initialize 
        self._classes = {};
        // [680]  classes.clear 
        self._classes = {};
        // [681]  LooseAttributes.Initialize 
        self._looseattributes.length = 0;
        // [682]  LooseAttributes.clear 
        self._looseattributes.length = 0;
        // [683]  ParentID = {119} 
        self._parentid = "";
        // [684]  DontBreak.Initialize 
        self._dontbreak.length = 0;
        // [685]  DontBreak.clear 
        self._dontbreak.length = 0;
        // [686]  DontBreak.Add( {120} ) 
        self._dontbreak.push("li");
        // [687]  DontBreak.Add( {121} ) 
        self._dontbreak.push("a");
        // [688]  DontBreak.Add( {122} ) 
        self._dontbreak.push("i");
        // [689]  DontBreak.Add( {123} ) 
        self._dontbreak.push("span");
        // [690]  DontBreak.Add( {124} ) 
        self._dontbreak.push("img");
        // [691]  Tag = eltag 
        self._tag = _eltag;
        // [692]  Prefix = {125} 
        self._prefix = "";
        // [693]  DoAProperClose = True 
        self._doaproperclose = true;
        // [694]  Required = False 
        self._required = false;
        // [695]  Enabled = True 
        self._enabled = true;
        // [696]  Inline = False 
        self._inline = false;
        // [697]  ReadOnly = False 
        self._readonly = false;
        // [698]  CSSRule.Initialize 
        self._cssrule = {};
        // [699]  CSSRule.clear 
        self._cssrule = {};
        // [700]  SingleQuote.Initialize 
        self._singlequote.length = 0;
        // [701]  SingleQuote.clear 
        self._singlequote.length = 0;
        // [702]  Text = {126} 
        self._text = "";
        // [703]  TextAfter = False 
        self._textafter = false;
        // End Sub
    };

    // [707] public Sub removeAttrData(sData As String) As UOEHTML 
    this.removeattrdata = function (_sdata) {
        if (self == null) self = this;
        // [708]  sData = {1} 
        _sdata = "data-" + _sdata + "";
        // [709]  removeAttr(sData) 
        self.removeattr(_sdata);
        // [710]  Return Me 
        return self;
        // End Sub
    };

    // [713] Sub MaterialEnable(bEnabled As Boolean) As UOEHTML 
    this.materialenable = function (_benabled) {
        if (self == null) self = this;
        // [714]  Enabled = bEnabled 
        self._enabled = _benabled;
        // [715]  Return Me 
        return self;
        // End Sub
    };

    // [718] Sub MaterialRequired(bRequired As Boolean) As UOEHTML 
    this.materialrequired = function (_brequired) {
        if (self == null) self = this;
        // [719]  Required = bRequired 
        self._required = _brequired;
        // [720]  Return Me 
        return self;
        // End Sub
    };

    // [723] Sub MaterialInline(bInline As Boolean) As UOEHTML 
    this.materialinline = function (_binline) {
        if (self == null) self = this;
        // [724]  Inline = bInline 
        self._inline = _binline;
        // [725]  Return Me 
        return self;
        // End Sub
    };

    // [730] Sub removeAttribute(prop As String) As UOEHTML 
    this.removeattribute = function (_prop) {
        if (self == null) self = this;
        // [731]  removeAttr(prop) 
        self.removeattr(_prop);
        // [732]  Return Me 
        return self;
        // End Sub
    };

    // [736] public Sub removeAttr(sName As String) As UOEHTML 
    this.removeattr = function (_sname) {
        if (self == null) self = this;
        var _sitems;
        var _strstyle;
        // [737]  sName = sName.ToLowerCase 
        _sname = _sname.toLowerCase();
        // [738]  sName = sName.Replace( {127} , {128} ) 
        _sname = _sname.split(" ").join(";");
        // [739]  Dim sItems As List = StrParse( {129} ,sName) 
        _sitems = self.strparse(";", _sname);
        // [740]  For Each strStyle As String In sItems 
        for (var _strstyleindex = 0; _strstyleindex < _sitems.length; _strstyleindex++) {
            _strstyle = _sitems[_strstyleindex];
            // [741]  strStyle = strStyle.trim 
            _strstyle = _strstyle.trim();
            // [742]  If properties.ContainsKey(strStyle) Then 
            if ((_strstyle in self._properties)) {
                // [743]  properties.Remove(strStyle) 
                delete self._properties[_strstyle];
                // [744]  End If 
            }
            // [745]  Next 
        }
        // [746]  Return Me 
        return self;
        // End Sub
    };

    // [750] public Sub removeStyle(styleName As String) As UOEHTML 
    this.removestyle = function (_stylename) {
        if (self == null) self = this;
        var _sitems;
        var _strstyle;
        // [751]  styleName = styleName.Trim 
        _stylename = _stylename.trim();
        // [752]  styleName = styleName.tolowercase 
        _stylename = _stylename.toLowerCase();
        // [753]  styleName = styleName.Replace( {130} , {131} ) 
        _stylename = _stylename.split(" ").join(";");
        // [754]  Dim sItems As List = StrParse( {132} ,styleName) 
        _sitems = self.strparse(";", _stylename);
        // [755]  For Each strStyle As String In sItems 
        for (var _strstyleindex = 0; _strstyleindex < _sitems.length; _strstyleindex++) {
            _strstyle = _sitems[_strstyleindex];
            // [756]  strStyle = strStyle.trim 
            _strstyle = _strstyle.trim();
            // [757]  If styles.ContainsKey(strStyle) Then 
            if ((_strstyle in self._styles)) {
                // [758]  styles.Remove(strStyle) 
                delete self._styles[_strstyle];
                // [759]  End If 
            }
            // [760]  Next 
        }
        // [761]  Return Me 
        return self;
        // End Sub
    };

    // [765] Sub setAttrLoose(value As String) As UOEHTML 
    this.setattrloose = function (_value) {
        if (self == null) self = this;
        // [766]  AddAttribute(value, {133} ) 
        self.addattribute(_value, "true");
        // [767]  Return Me 
        return self;
        // End Sub
    };

    // [771] private Sub GetComponentBuilder() As String 
    this.getcomponentbuilder = function () {
        if (self == null) self = this;
        var _sb;
        var _sout;
        // [772]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [773]  sb.Initialize 
        _sb.isinitialized = true;
        // [774]  If Prefix.Length > 0 Then 
        if (self._prefix.length > 0) {
            // [775]  sb.Append(Prefix) 
            _sb.append(self._prefix);
            // [776]  sb.Append(CRLF) 
            _sb.append("\n");
            // [777]  End If 
        }
        // [778]  sb.Append( {134} ) 
        _sb.append("<");
        // [779]  sb.Append(Tag) 
        _sb.append(self._tag);
        // [780]  sb.Append( {135} ) 
        _sb.append(" ");
        // [781]  If ID.Length > 0 Then 
        if (self._id.length > 0) {
            // [782]  sb.Append(ToProperty( {136} ,ID)) 
            _sb.append(self.toproperty("id", self._id));
            // [783]  End If 
        }
        // [784]  sb.Append( {137} ) 
        _sb.append(">");
        // [785]  Select Case Tag.ToLowerCase 
        switch ("" + self._tag.toLowerCase()) {
            // [786]  Case {138} , {139} , {140} , {141} , {142} 
            case "" + "img":
            case "" + "link":
            case "" + "meta":
            case "" + "input":
            case "" + "source":
                // [787]  DoAProperClose = False 
                self._doaproperclose = false;
                // [788]  End Select 
                break;
        }
        // [789]  If DoAProperClose = True Then 
        if (self._doaproperclose == true) {
            // [790]  sb.Append( {143} ) 
            _sb.append("</");
            // [791]  sb.Append(Tag) 
            _sb.append(self._tag);
            // [792]  sb.Append( {144} ) 
            _sb.append(">");
            // [793]  End If 
        }
        // [794]  sb.Append(CRLF) 
        _sb.append("\n");
        // [795]  Dim sout As String = sb.tostring 
        _sout = _sb.toString();
        // [796]  sout = sout.Trim 
        _sout = _sout.trim();
        // [797]  Return sout 
        return _sout;
        // End Sub
    };

    // [801] private Sub ToProperty(sName As String, svalue As String) As String 
    this.toproperty = function (_sname, _svalue) {
        if (self == null) self = this;
        var _script;
        // [802]  sName = CStr(sName) 
        _sname = self.cstr(_sname);
        // [803]  svalue = CStr(svalue) 
        _svalue = self.cstr(_svalue);
        // [804]  sName = sName.Replace( {145} , {146} ) 
        _sname = _sname.split("null").join("");
        // [805]  sName = sName.Replace( {147} , {148} ) 
        _sname = _sname.split("undefined").join("");
        // [806]  svalue = svalue.Replace( {149} , {150} ) 
        _svalue = _svalue.split("null").join("");
        // [807]  svalue = svalue.Replace( {151} , {152} ) 
        _svalue = _svalue.split("undefined").join("");
        // [808]  sName = sName.Trim 
        _sname = _sname.trim();
        // [809]  svalue = svalue.trim 
        _svalue = _svalue.trim();
        // [810]  If sName.Length > 0 Then 
        if (_sname.length > 0) {
            // [811]  Dim script As String = {2} 
            _script = "" + _sname + "=\"" + _svalue + "\"";
            // [812]  script = script.trim 
            _script = _script.trim();
            // [813]  Return script 
            return _script;
            // [814]  Else 
        } else {
            // [815]  Return {153} 
            return "";
            // [816]  End If 
        }
        // End Sub
    };

    // [820] Sub setAttrData(prop As String, value As String) As UOEHTML 
    this.setattrdata = function (_prop, _value) {
        if (self == null) self = this;
        var _sw;
        // [821]  Dim sw As Boolean = prop.StartsWith( {154} ) 
        _sw = _prop.startsWith("data-");
        // [822]  If sw Then 
        if (_sw) {
            // [823]  AddAttribute(prop,value) 
            self.addattribute(_prop, _value);
            // [824]  Else 
        } else {
            // [825]  AddAttribute( {155} & prop,value) 
            self.addattribute("data-" + _prop, _value);
            // [826]  End If 
        }
        // [827]  Return Me 
        return self;
        // End Sub
    };

    // [830] private Sub CStr(o As Object) As String 
    this.cstr = function (_o) {
        if (self == null) self = this;
        // [831]  Return {156} & o 
        return "" + _o;
        // End Sub
    };

    // [836] public Sub AddContent(value As String) As UOEHTML 
    this.addcontent = function (_value) {
        if (self == null) self = this;
        // [837]  value = CStr(value) 
        _value = self.cstr(_value);
        // [838]  If value.Length > 0 Then 
        if (_value.length > 0) {
            // [839]  value = FormatText(value) 
            _value = self.formattext(_value);
            // [840]  Contents.Add(value) 
            self._contents.push(_value);
            // [841]  End If 
        }
        // [842]  Return Me 
        return self;
        // End Sub
    };

    // [846] public Sub removeClass(className As String) As UOEHTML 
    this.removeclass = function (_classname) {
        if (self == null) self = this;
        var _sitems;
        var _strstyle;
        // [847]  className = className.Trim 
        _classname = _classname.trim();
        // [848]  className = className.replace( {157} , {158} ) 
        _classname = _classname.split(" ").join(";");
        // [849]  Dim sItems As List = StrParse( {159} ,className) 
        _sitems = self.strparse(";", _classname);
        // [850]  For Each strStyle As String In sItems 
        for (var _strstyleindex = 0; _strstyleindex < _sitems.length; _strstyleindex++) {
            _strstyle = _sitems[_strstyleindex];
            // [851]  strStyle = strStyle.Trim 
            _strstyle = _strstyle.trim();
            // [852]  If classes.ContainsKey(strStyle) Then 
            if ((_strstyle in self._classes)) {
                // [853]  classes.Remove(strStyle) 
                delete self._classes[_strstyle];
                // [854]  End If 
            }
            // [855]  Next 
        }
        // [856]  Return Me 
        return self;
        // End Sub
    };

    // [860] public Sub AddElement(el As UOEHTML) As UOEHTML 
    this.addelement = function (_el) {
        if (self == null) self = this;
        var _scode;
        // [861]  If el <> Null Then 
        if (_el != null) {
            // [862]  Dim scode As String = el.tostring 
            _scode = _el.tostring();
            // [863]  AddContent(scode) 
            self.addcontent(_scode);
            // [864]  End If 
        }
        // [865]  Return Me 
        return self;
        // End Sub
    };

    // [869] private Sub BuildClass() As String 
    this.buildclass = function () {
        if (self == null) self = this;
        var _sb;
        var _ktot;
        var _kcnt;
        var _strclass;
        // [870]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [871]  sb.Initialize 
        _sb.isinitialized = true;
        // [872]  Dim kTot As Int = classes.Size - 1 
        _ktot = Object.keys(self._classes).length - 1;
        // [873]  Dim kCnt As Int 
        _kcnt = 0;
        // [874]  Dim strClass As String = classes.GetKeyAt(0) 
        _strclass = banano_getB4JKeyAt(self._classes, 0);
        // [875]  sb.Append(strClass) 
        _sb.append(_strclass);
        // [876]  For kCnt = 1 To kTot 
        for (_kcnt = 1; _kcnt <= _ktot; _kcnt++) {
            // [877]  Dim strClass As String = classes.GetKeyAt(kCnt) 
            _strclass = banano_getB4JKeyAt(self._classes, _kcnt);
            // [878]  sb.Append( {160} ) 
            _sb.append(" ");
            // [879]  sb.Append(strClass) 
            _sb.append(_strclass);
            // [880]  Next 
        }
        // [881]  Return sb.ToString 
        return _sb.toString();
        // End Sub
    };

    // [901] private Sub BuildStyle() As String 
    this.buildstyle = function () {
        if (self == null) self = this;
        var _sb;
        var _kcnt;
        var _ktot;
        var _strkey;
        var _strvalue;
        var _strline;
        // [902]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [903]  sb.Initialize 
        _sb.isinitialized = true;
        // [904]  Dim kCnt As Int 
        _kcnt = 0;
        // [905]  Dim kTot As Int = styles.Size - 1 
        _ktot = Object.keys(self._styles).length - 1;
        // [907]  Dim strKey As String = styles.GetKeyAt(0) 
        _strkey = banano_getB4JKeyAt(self._styles, 0);
        // [908]  Dim strValue As String = styles.Get(strKey) 
        _strvalue = self._styles[_strkey];
        // [909]  Dim strLine As String = ToStyle(strKey,strValue) 
        _strline = self.tostyle(_strkey, _strvalue);
        // [910]  sb.Append(strLine) 
        _sb.append(_strline);
        // [911]  For kCnt = 1 To kTot 
        for (_kcnt = 1; _kcnt <= _ktot; _kcnt++) {
            // [912]  Dim strKey As String = styles.GetKeyAt(kCnt) 
            _strkey = banano_getB4JKeyAt(self._styles, _kcnt);
            // [913]  Dim strValue As String = styles.Get(strKey) 
            _strvalue = self._styles[_strkey];
            // [914]  Dim strLine As String = ToStyle(strKey,strValue) 
            _strline = self.tostyle(_strkey, _strvalue);
            // [915]  sb.Append( {165} ) 
            _sb.append(" ");
            // [916]  sb.Append(strLine) 
            _sb.append(_strline);
            // [917]  Next 
        }
        // [918]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [922] private Sub ToStyle(sName As String, value As String) As String 
    this.tostyle = function (_sname, _value) {
        if (self == null) self = this;
        var _ew;
        var _sout;
        // [923]  If sName.Length > 0 And value.Length > 0 Then 
        if (_sname.length > 0 && _value.length > 0) {
            // [924]  Dim ew As Boolean = sName.EndsWith( {166} ) 
            _ew = _sname.endsWith(":");
            // [925]  If ew Then 
            if (_ew) {
                // [926]  sName = MvField(sName,1, {167} ) 
                _sname = self.mvfield(_sname, 1, ":");
                // [927]  End If 
            }
            // [928]  Dim sout As String = {3} 
            _sout = "" + _sname + ":" + _value + ";";
            // [929]  If sout = {168} Then sout = {169} 
            if (_sout == ":;") {
                _sout = "";
            }
            // [930]  Return sout 
            return _sout;
            // [931]  Else 
        } else {
            // [932]  Return {170} 
            return "";
            // [933]  End If 
        }
        // End Sub
    };

    // [936] public Sub MvFieldFrom(sValue As String, iPosition As Int, Delimiter As String) As String 
    this.mvfieldfrom = function (_svalue, _iposition, _delimiter) {
        if (self == null) self = this;
        var _mvalues;
        var _tvalues;
        var _ew;
        var _sb;
        var _startcnt;
        // [937]  If sValue.Length = 0 Then Return {171} 
        if (_svalue.length == 0) {
            return "";
        }
        // [938]  Dim mValues As List 
        _mvalues = [];
        // [939]  Dim tValues As Int 
        _tvalues = 0;
        // [940]  Dim ew As Boolean = sValue.EndsWith(Delimiter) 
        _ew = _svalue.endsWith(_delimiter);
        // [941]  If ew Then 
        if (_ew) {
            // [942]  sValue = sValue & {172} 
            _svalue = _svalue + " ";
            // [943]  End If 
        }
        // [944]  mValues = StrParse(Delimiter, sValue) 
        _mvalues = self.strparse(_delimiter, _svalue);
        // [945]  tValues = mValues.size -1 
        _tvalues = _mvalues.length - 1;
        // [946]  If tValues < iPosition Then 
        if (_tvalues < _iposition) {
            // [947]  Return mValues.get(tValues) 
            return _mvalues[_tvalues];
            // [948]  End If 
        }
        // [949]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [950]  sb.Initialize 
        _sb.isinitialized = true;
        // [951]  Dim startcnt As Int 
        _startcnt = 0;
        // [952]  sb.Append(mValues.get(iPosition)) 
        _sb.append(_mvalues[_iposition]);
        // [953]  For startcnt = iPosition + 1 To tValues 
        for (_startcnt = _iposition + 1; _startcnt <= _tvalues; _startcnt++) {
            // [954]  sb.Append(Delimiter) 
            _sb.append(_delimiter);
            // [955]  sb.Append(mValues.get(startcnt)) 
            _sb.append(_mvalues[_startcnt]);
            // [956]  Next 
        }
        // [957]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [961] public Sub MaterialBuildIcon(iconName As String, iconPos As String) As UOEHTML 
    this.materialbuildicon = function (_iconname, _iconpos) {
        if (self == null) self = this;
        var _sw;
        // [962]  iconName = iconName.tolowercase 
        _iconname = _iconname.toLowerCase();
        // [963]  Dim sw As Boolean 
        _sw = false;
        // [964]  sw = iconName.StartsWith( {173} ) 
        _sw = _iconname.startsWith("mdi-");
        // [965]  If sw Then 
        if (_sw) {
            // [966]  addClass( {174} ) 
            self.addclass("material-icons");
            // [967]  iconName = MvFieldFrom(iconName,2, {175} ) 
            _iconname = self.mvfieldfrom(_iconname, 2, "-");
            // [968]  iconName = iconName.Replace( {176} , {177} ) 
            _iconname = _iconname.split("-").join("_");
            // [969]  AddContent(iconName) 
            self.addcontent(_iconname);
            // [970]  If iconPos.Length > 0 Then addClass(iconPos) 
            if (_iconpos.length > 0) {
                self.addclass(_iconpos);
            }
            // [971]  Return Me 
            return self;
            // [972]  End If 
        }
        // [973]  sw = iconName.startswith( {178} ) 
        _sw = _iconname.startsWith("ggle-");
        // [974]  If sw Then 
        if (_sw) {
            // [975]  iconName = MvFieldFrom(iconName,2, {179} ) 
            _iconname = self.mvfieldfrom(_iconname, 2, "-");
            // [976]  AddContent(iconName) 
            self.addcontent(_iconname);
            // [977]  If iconPos.Length > 0 Then addClass(iconPos) 
            if (_iconpos.length > 0) {
                self.addclass(_iconpos);
            }
            // [978]  Return Me 
            return self;
            // [979]  End If 
        }
        // [980]  sw = iconName.StartsWith( {180} ) 
        _sw = _iconname.startsWith("fa-");
        // [981]  If sw Then 
        if (_sw) {
            // [982]  addClass( {181} & iconName) 
            self.addclass("fa " + _iconname);
            // [983]  If iconPos.Length > 0 Then addClass(iconPos) 
            if (_iconpos.length > 0) {
                self.addclass(_iconpos);
            }
            // [984]  Return Me 
            return self;
            // [985]  End If 
        }
        // [986]  sw = iconName.StartsWith( {182} ) 
        _sw = _iconname.startsWith("fa fa-");
        // [987]  If sw Then 
        if (_sw) {
            // [988]  addClass(iconName) 
            self.addclass(_iconname);
            // [989]  If iconPos.Length > 0 Then addClass(iconPos) 
            if (_iconpos.length > 0) {
                self.addclass(_iconpos);
            }
            // [990]  Return Me 
            return self;
            // [991]  End If 
        }
        // [992]  sw = iconName.StartsWith( {183} ) 
        _sw = _iconname.startsWith("fa ");
        // [993]  If sw Then 
        if (_sw) {
            // [994]  addClass(iconName) 
            self.addclass(_iconname);
            // [995]  If iconPos.Length > 0 Then addClass(iconPos) 
            if (_iconpos.length > 0) {
                self.addclass(_iconpos);
            }
            // [996]  Return Me 
            return self;
            // [997]  End If 
        }
        // [998]  addClass(iconName) 
        self.addclass(_iconname);
        // [999]  If iconPos.Length > 0 Then addClass(iconPos) 
        if (_iconpos.length > 0) {
            self.addclass(_iconpos);
        }
        // [1000]  Return Me 
        return self;
        // End Sub
    };

    // [1003] Sub MaterialClose(bStatus As String) As UOEHTML 
    this.materialclose = function (_bstatus) {
        if (self == null) self = this;
        // [1004]  AddClassOnCondition(bStatus, {184} ) 
        self.addclassoncondition(_bstatus, "close");
        // [1005]  Return Me 
        return self;
        // End Sub
    };

    // [1008] Sub MaterialIconSize(sSize As String) As UOEHTML 
    this.materialiconsize = function (_ssize) {
        if (self == null) self = this;
        // [1009]  If sSize.Length > 0 Then 
        if (_ssize.length > 0) {
            // [1010]  removeClass( {185} ) 
            self.removeclass("large");
            // [1011]  removeClass( {186} ) 
            self.removeclass("tiny");
            // [1012]  removeClass( {187} ) 
            self.removeclass("small");
            // [1013]  removeClass( {188} ) 
            self.removeclass("medium");
            // [1014]  addClass(sSize) 
            self.addclass(_ssize);
            // [1015]  End If 
        }
        // [1016]  Return Me 
        return self;
        // End Sub
    };

    // [1020] private Sub Open() As String 
    this.open = function () {
        if (self == null) self = this;
        var _thisclass;
        var _thisstyle;
        var _strvalue;
        var _sb;
        var _thisattr;
        // [1022]  If Required = True Then setAttrLoose( {189} ) 
        if (self._required == true) {
            self.setattrloose("required");
        }
        // [1023]  If Enabled = False Then setAttrLoose( {190} ) 
        if (self._enabled == false) {
            self.setattrloose("disabled");
        }
        // [1024]  If Inline = True Then setAttrLoose( {191} ) 
        if (self._inline == true) {
            self.setattrloose("inline");
        }
        // [1025]  If ReadOnly = True Then setAttrLoose( {192} ) 
        if (self._readonly == true) {
            self.setattrloose("readonly");
        }
        // [1027]  Dim thisClass As String = BuildClass 
        _thisclass = self.buildclass();
        // [1028]  thisClass = thisClass.trim 
        _thisclass = _thisclass.trim();
        // [1029]  If thisClass.Length > 0 Then 
        if (_thisclass.length > 0) {
            // [1030]  AddAttribute( {193} , thisClass) 
            self.addattribute("class", _thisclass);
            // [1031]  End If 
        }
        // [1033]  Dim thisStyle As String = BuildStyle 
        _thisstyle = self.buildstyle();
        // [1034]  thisStyle = thisStyle.trim 
        _thisstyle = _thisstyle.trim();
        // [1035]  If thisStyle.Length > 0 Then 
        if (_thisstyle.length > 0) {
            // [1036]  AddAttribute( {194} , thisStyle) 
            self.addattribute("style", _thisstyle);
            // [1037]  End If 
        }
        // [1038]  Dim strValue As String 
        _strvalue = '';
        // [1039]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [1040]  sb.Initialize 
        _sb.isinitialized = true;
        // [1041]  If Prefix.Length > 0 Then 
        if (self._prefix.length > 0) {
            // [1042]  sb.Append(Prefix) 
            _sb.append(self._prefix);
            // [1043]  sb.Append(CRLF) 
            _sb.append("\n");
            // [1044]  End If 
        }
        // [1045]  sb.Append( {195} ) 
        _sb.append("<");
        // [1046]  sb.Append(Tag) 
        _sb.append(self._tag);
        // [1047]  sb.Append( {196} ) 
        _sb.append(" ");
        // [1048]  If ID.Length > 0 Then 
        if (self._id.length > 0) {
            // [1049]  sb.Append(ToProperty( {197} ,ID)) 
            _sb.append(self.toproperty("id", self._id));
            // [1050]  sb.Append( {198} ) 
            _sb.append(" ");
            // [1051]  End If 
        }
        // [1053]  Dim thisAttr As String = BuildAttributes 
        _thisattr = self.buildattributes();
        // [1054]  thisAttr = thisAttr.Trim 
        _thisattr = _thisattr.trim();
        // [1055]  If thisAttr.Length > 0 Then 
        if (_thisattr.length > 0) {
            // [1056]  sb.Append(thisAttr) 
            _sb.append(_thisattr);
            // [1057]  End If 
        }
        // [1058]  sb.Append( {199} ) 
        _sb.append(">");
        // [1059]  sb.Append(CRLF) 
        _sb.append("\n");
        // [1060]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [1063] Sub BuildAttributes As String 
    this.buildattributes = function () {
        if (self == null) self = this;
        var _sb;
        var _ktot;
        var _kcnt;
        var _strkey;
        var _strvalue;
        // [1064]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [1065]  sb.Initialize 
        _sb.isinitialized = true;
        // [1066]  Dim kTot As Int = properties.Size - 1 
        _ktot = Object.keys(self._properties).length - 1;
        // [1067]  Dim kCnt As Int 
        _kcnt = 0;
        // [1068]  Dim strKey As String = properties.GetKeyAt(0) 
        _strkey = banano_getB4JKeyAt(self._properties, 0);
        // [1069]  Dim strValue As String = properties.Get(strKey) 
        _strvalue = self._properties[_strkey];
        // [1070]  If SingleQuote.IndexOf(strKey) = -1 Then 
        if (self._singlequote.indexOf(_strkey) == -1) {
            // [1071]  sb.Append(ToProperty(strKey,strValue)) 
            _sb.append(self.toproperty(_strkey, _strvalue));
            // [1072]  Else 
        } else {
            // [1073]  sb.Append(ToSingleQuoteProperty(strKey,strValue)) 
            _sb.append(self.tosinglequoteproperty(_strkey, _strvalue));
            // [1074]  End If 
        }
        // [1075]  For kCnt = 1 To kTot 
        for (_kcnt = 1; _kcnt <= _ktot; _kcnt++) {
            // [1076]  strKey = properties.GetKeyAt(kCnt) 
            _strkey = banano_getB4JKeyAt(self._properties, _kcnt);
            // [1077]  strValue = properties.Get(strKey) 
            _strvalue = self._properties[_strkey];
            // [1078]  sb.Append( {200} ) 
            _sb.append(" ");
            // [1079]  If SingleQuote.IndexOf(strKey) = -1 Then 
            if (self._singlequote.indexOf(_strkey) == -1) {
                // [1080]  sb.Append(ToProperty(strKey,strValue)) 
                _sb.append(self.toproperty(_strkey, _strvalue));
                // [1081]  Else 
            } else {
                // [1082]  sb.Append(ToSingleQuoteProperty(strKey,strValue)) 
                _sb.append(self.tosinglequoteproperty(_strkey, _strvalue));
                // [1083]  End If 
            }
            // [1084]  Next 
        }
        // [1085]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [1089] private Sub ToSingleQuoteProperty(sName As String, svalue As String) As String 
    this.tosinglequoteproperty = function (_sname, _svalue) {
        if (self == null) self = this;
        var _script;
        // [1090]  Dim script As String = {4} 
        _script = "" + _sname + "='" + _svalue + "'";
        // [1091]  script = script.Trim 
        _script = _script.trim();
        // [1092]  If script = {201} Then 
        if (_script == "=''") {
            // [1093]  script = {202} 
            _script = "";
            // [1094]  End If 
        }
        // [1095]  Return script 
        return _script;
        // End Sub
    };

    // [1099] private Sub FormatText(sText As String) As String 
    this.formattext = function (_stext) {
        if (self == null) self = this;
        var _rm;
        var _ktot;
        var _kcnt;
        var _strvalue;
        var _strrep;
        // [1100]  Dim RM As Map 
        _rm = {};
        // [1101]  RM.Initialize 
        _rm = {};
        // [1102]  RM.clear 
        _rm = {};
        // [1103]  RM.Put( {203} , {204} ) 
        _rm["{U}"] = "<ins>";
        // [1104]  RM.Put( {205} , {206} ) 
        _rm["{/U}"] = "</ins>";
        // [1105]  RM.Put( {207} , {208} ) 
        _rm["¢"] = "&cent;";
        // [1106]  RM.put( {209} , {210} ) 
        _rm["£"] = "&pound;";
        // [1107]  RM.Put( {211} , {212} ) 
        _rm["{SUP}"] = "<sup>";
        // [1108]  RM.Put( {213} , {214} ) 
        _rm["{/SUP}"] = "</sup>";
        // [1109]  RM.Put( {215} , {216} ) 
        _rm["¥"] = "&yen;";
        // [1110]  RM.Put( {217} , {218} ) 
        _rm["€"] = "&euro;";
        // [1111]  RM.put( {219} , {220} ) 
        _rm["©"] = "&copy;";
        // [1112]  RM.Put( {221} , {222} ) 
        _rm["®"] = "&reg;";
        // [1113]  RM.Put( {223} , {224} ) 
        _rm["{POUND}"] = "&pound;";
        // [1114]  RM.Put( {225} , {226} ) 
        _rm["{/B}"] = "</b>";
        // [1115]  RM.Put( {227} , {228} ) 
        _rm["{I}"] = "<i>";
        // [1116]  RM.Put( {229} , {230} ) 
        _rm["{YEN}"] = "&yen;";
        // [1117]  RM.Put( {231} , {232} ) 
        _rm["{EURO}"] = "&euro;";
        // [1118]  RM.Put( {233} , {234} ) 
        _rm["{CODE}"] = "<code>";
        // [1119]  RM.Put( {235} , {236} ) 
        _rm["{/CODE}"] = "</code>";
        // [1120]  RM.put( {237} , {238} ) 
        _rm["{COPYRIGHT}"] = "&copy;";
        // [1121]  RM.Put( {239} , {240} ) 
        _rm["{REGISTERED}"] = "&reg;";
        // [1122]  RM.Put( {241} , {242} ) 
        _rm["®"] = "&reg;";
        // [1123]  RM.Put( {243} , {244} ) 
        _rm["{B}"] = "<b>";
        // [1124]  RM.Put( {245} , {246} ) 
        _rm["{SMALL}"] = "<small>";
        // [1125]  RM.Put( {247} , {248} ) 
        _rm["{/SMALL}"] = "</small>";
        // [1126]  RM.Put( {249} , {250} ) 
        _rm["{EM}"] = "<em>";
        // [1127]  RM.Put( {251} , {252} ) 
        _rm["{/EM}"] = "</em>";
        // [1128]  RM.Put( {253} , {254} ) 
        _rm["{MARK}"] = "<mark>";
        // [1129]  RM.Put( {255} , {256} ) 
        _rm["{/MARK}"] = "</mark>";
        // [1130]  RM.Put( {257} , {258} ) 
        _rm["{/I}"] = "</i>";
        // [1131]  RM.Put( {259} , {260} ) 
        _rm["{SUB}"] = "<sub>";
        // [1132]  RM.Put( {261} , {262} ) 
        _rm["{/SUB}"] = "</sub>";
        // [1133]  RM.Put( {263} , {264} ) 
        _rm["{BR}"] = "<br/>";
        // [1134]  RM.Put( {265} , {266} ) 
        _rm["{WBR}"] = "<wbr>";
        // [1135]  RM.Put( {267} , {268} ) 
        _rm["{STRONG}"] = "<strong>";
        // [1136]  RM.Put( {269} , {270} ) 
        _rm["{/STRONG}"] = "</strong>";
        // [1137]  RM.Put( {271} , {272} ) 
        _rm["{NBSP}"] = "&nbsp;";
        // [1138]  RM.Put( {273} , {274} ) 
        _rm["“"] = "";
        // [1139]  RM.Put( {275} , {276} ) 
        _rm["”"] = "";
        // [1140]  RM.Put( {277} , {278} ) 
        _rm["’"] = "'";
        // [1141]  Dim kTot As Int = RM.Size - 1 
        _ktot = Object.keys(_rm).length - 1;
        // [1142]  Dim kCnt As Int 
        _kcnt = 0;
        // [1143]  For kCnt = 0 To kTot 
        for (_kcnt = 0; _kcnt <= _ktot; _kcnt++) {
            // [1144]  Dim strValue As String = RM.GetKeyAt(kCnt) 
            _strvalue = banano_getB4JKeyAt(_rm, _kcnt);
            // [1145]  Dim strRep As String = RM.Get(strValue) 
            _strrep = _rm[_strvalue];
            // [1146]  sText = sText.Replace(strValue, strRep) 
            _stext = _stext.split(_strvalue).join(_strrep);
            // [1147]  Next 
        }
        // [1148]  Return sText 
        return _stext;
        // End Sub
    };

    // [1152] private Sub RemDelim(sValue As String, Delim As String) As String 
    this.remdelim = function (_svalue, _delim) {
        if (self == null) self = this;
        var _sw;
        var _ldelim;
        var _nvalue;
        // [1153]  Dim sw As Boolean = sValue.EndsWith(Delim) 
        _sw = _svalue.endsWith(_delim);
        // [1154]  If sw Then 
        if (_sw) {
            // [1155]  Dim lDelim As Int = Delim.Length 
            _ldelim = _delim.length;
            // [1156]  Dim nValue As String = sValue 
            _nvalue = _svalue;
            // [1157]  sw = nValue.EndsWith(Delim) 
            _sw = _nvalue.endsWith(_delim);
            // [1158]  If sw Then 
            if (_sw) {
                // [1159]  nValue = nValue.SubString2(0, nValue.Length-lDelim) 
                _nvalue = _nvalue.substring(0, _nvalue.length - _ldelim);
                // [1160]  End If 
            }
            // [1161]  Return nValue 
            return _nvalue;
            // [1162]  Else 
        } else {
            // [1163]  Return sValue 
            return _svalue;
            // [1164]  End If 
        }
        // End Sub
    };

    // [1168] Sub AddStyleAttribute(sprop As String, svalue As String) As UOEHTML 
    this.addstyleattribute = function (_sprop, _svalue) {
        if (self == null) self = this;
        // [1169]  sprop = sprop.ToLowerCase 
        _sprop = _sprop.toLowerCase();
        // [1170]  sprop = sprop.Trim 
        _sprop = _sprop.trim();
        // [1171]  svalue = svalue.Trim 
        _svalue = _svalue.trim();
        // [1173]  sprop = RemDelim(sprop, {279} ) 
        _sprop = self.remdelim(_sprop, ":");
        // [1175]  svalue = RemDelim(svalue, {280} ) 
        _svalue = self.remdelim(_svalue, ";");
        // [1176]  sprop = sprop.Trim 
        _sprop = _sprop.trim();
        // [1177]  svalue = svalue.Trim 
        _svalue = _svalue.trim();
        // [1178]  If svalue.Length > 0 And sprop.Length > 0 Then 
        if (_svalue.length > 0 && _sprop.length > 0) {
            // [1180]  If svalue.EndsWith( {281} ) = False Then 
            if (_svalue.endsWith("!important") == false) {
                // [1181]  svalue = svalue & {282} 
                _svalue = _svalue + " !important";
                // [1182]  End If 
            }
            // [1184]  styles.Put(sprop, svalue) 
            self._styles[_sprop] = _svalue;
            // [1185]  End If 
        }
        // [1186]  Return Me 
        return self;
        // End Sub
    };

    // [1190] private Sub MvField(sValue As String, iPosition As Int, Delimiter As String) As String 
    this.mvfield = function (_svalue, _iposition, _delimiter) {
        if (self == null) self = this;
        var _xpos;
        var _mvalues;
        var _tvalues;
        var _sb;
        var _startcnt;
        // [1191]  If sValue.Length = 0 Then Return {283} 
        if (_svalue.length == 0) {
            return "";
        }
        // [1192]  Dim xPos As Int = sValue.IndexOf(Delimiter) 
        _xpos = _svalue.indexOf(_delimiter);
        // [1193]  If xPos = -1 Then Return sValue 
        if (_xpos == -1) {
            return _svalue;
        }
        // [1194]  Dim mValues As List = StrParse(Delimiter,sValue) 
        _mvalues = self.strparse(_delimiter, _svalue);
        // [1195]  Dim tValues As Int 
        _tvalues = 0;
        // [1196]  tValues = mValues.size -1 
        _tvalues = _mvalues.length - 1;
        // [1197]  Select Case iPosition 
        switch ("" + _iposition) {
            // [1198]  Case -1 
            case "" + -1:
                // [1199]  Return mValues.get(tValues) 
                return _mvalues[_tvalues];
                // [1200]  Case -2 
            case "" + -2:
                // [1201]  Return mValues.get(tValues - 1) 
                return _mvalues[_tvalues - 1];
                // [1202]  Case -3 
            case "" + -3:
                // [1203]  Dim sb As StringBuilder 
                _sb = new StringBuilder();
                // [1204]  sb.Initialize 
                _sb.isinitialized = true;
                // [1205]  Dim startcnt As Int 
                _startcnt = 0;
                // [1206]  sb.Append(mValues.Get(1)) 
                _sb.append(_mvalues[1]);
                // [1207]  For startcnt = 2 To tValues 
                for (_startcnt = 2; _startcnt <= _tvalues; _startcnt++) {
                    // [1208]  sb.Append(Delimiter) 
                    _sb.append(_delimiter);
                    // [1209]  sb.Append(mValues.get(startcnt)) 
                    _sb.append(_mvalues[_startcnt]);
                    // [1210]  Next 
                }
                // [1211]  Return sb.tostring 
                return _sb.toString();
                // [1212]  Case Else 
            default:
                // [1213]  iPosition = iPosition - 1 
                _iposition = _iposition - 1;
                // [1214]  If iPosition <= -1 Then 
                if (_iposition <= -1) {
                    // [1215]  Return mValues.get(tValues) 
                    return _mvalues[_tvalues];
                    // [1216]  End If 
                }
                // [1217]  If iPosition > tValues Then 
                if (_iposition > _tvalues) {
                    // [1218]  Return {284} 
                    return "";
                    // [1219]  End If 
                }
                // [1220]  Return mValues.get(iPosition) 
                return _mvalues[_iposition];
                // [1221]  End Select 
        }
        // End Sub
    };

    // [1225] Sub addClass(value As String) As UOEHTML 
    this.addclass = function (_value) {
        if (self == null) self = this;
        var _spclasses;
        var _strclass;
        // [1227]  value = value.Replace( {285} , {286} ) 
        _value = _value.split(" ").join(";");
        // [1228]  Dim spClasses As List = StrParse( {287} ,value) 
        _spclasses = self.strparse(";", _value);
        // [1229]  For Each strClass As String In spClasses 
        for (var _strclassindex = 0; _strclassindex < _spclasses.length; _strclassindex++) {
            _strclass = _spclasses[_strclassindex];
            // [1230]  strClass = strClass.Trim 
            _strclass = _strclass.trim();
            // [1231]  If strClass.Length > 0 Then 
            if (_strclass.length > 0) {
                // [1232]  classes.Put(strClass,strClass) 
                self._classes[_strclass] = _strclass;
                // [1233]  End If 
            }
            // [1234]  Next 
        }
        // [1235]  Return Me 
        return self;
        // End Sub
    };

    // [1239] public Sub AddAttribute(skey As String, svalue As String) As UOEHTML 
    this.addattribute = function (_skey, _svalue) {
        if (self == null) self = this;
        // [1240]  skey = CStr(skey) 
        _skey = self.cstr(_skey);
        // [1241]  svalue = CStr(svalue) 
        _svalue = self.cstr(_svalue);
        // [1242]  skey = skey.Replace( {288} , {289} ) 
        _skey = _skey.split("undefined").join("");
        // [1243]  skey = skey.Replace( {290} , {291} ) 
        _skey = _skey.split("null").join("");
        // [1244]  svalue = svalue.Replace( {292} , {293} ) 
        _svalue = _svalue.split("undefined").join("");
        // [1245]  svalue = svalue.Replace( {294} , {295} ) 
        _svalue = _svalue.split("null").join("");
        // [1246]  skey = skey.trim 
        _skey = _skey.trim();
        // [1247]  svalue = svalue.trim 
        _svalue = _svalue.trim();
        // [1248]  If skey.Length > 0 And svalue.Length > 0 Then 
        if (_skey.length > 0 && _svalue.length > 0) {
            // [1249]  properties.Put(skey,svalue) 
            self._properties[_skey] = _svalue;
            // [1250]  Else 
        } else {
            // [1251]  properties.Remove(skey) 
            delete self._properties[_skey];
            // [1252]  End If 
        }
        // [1253]  Return Me 
        return self;
        // End Sub
    };

    // [1258] private Sub StrParse(Delim As String, InputString As String) As List 
    this.strparse = function (_delim, _inputstring) {
        if (self == null) self = this;
        var _outlist;
        var _commaloc;
        var _leftside;
        var _rightside;
        // [1259]  Dim OutList As List 
        _outlist = [];
        // [1260]  Dim CommaLoc As Int 
        _commaloc = 0;
        // [1261]  OutList.Initialize 
        _outlist.length = 0;
        // [1262]  OutList.clear 
        _outlist.length = 0;
        // [1263]  CommaLoc=InputString.IndexOf(Delim) 
        _commaloc = _inputstring.indexOf(_delim);
        // [1264]  Do While CommaLoc >-1 
        while (_commaloc > -1) {
            // [1265]  Dim LeftSide As String 
            _leftside = '';
            // [1266]  LeftSide= InputString.SubString2(0,CommaLoc) 
            _leftside = _inputstring.substring(0, _commaloc);
            // [1267]  Dim RightSide As String 
            _rightside = '';
            // [1268]  RightSide= InputString.SubString(CommaLoc+1) 
            _rightside = _inputstring.substring(_commaloc + 1);
            // [1269]  OutList.Add(LeftSide) 
            _outlist.push(_leftside);
            // [1270]  InputString=RightSide 
            _inputstring = _rightside;
            // [1271]  CommaLoc=InputString.IndexOf(Delim) 
            _commaloc = _inputstring.indexOf(_delim);
            // [1272]  Loop 
        }
        // [1273]  OutList.Add(InputString) 
        _outlist.push(_inputstring);
        // [1274]  Return OutList 
        return _outlist;
        // End Sub
    };

    // [1290] private Sub Close() As String 
    this.close = function () {
        if (self == null) self = this;
        var _sb;
        // [1291]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [1292]  sb.Initialize 
        _sb.isinitialized = true;
        // [1293]  Select Case Tag.ToLowerCase 
        switch ("" + self._tag.toLowerCase()) {
            // [1294]  Case {296} , {297} , {298} , {299} , {300} , {301} , {302} 
            case "" + "img":
            case "" + "link":
            case "" + "meta":
            case "" + "input":
            case "" + "source":
            case "" + "hr":
            case "" + "br":
                // [1295]  DoAProperClose = False 
                self._doaproperclose = false;
                // [1296]  End Select 
                break;
        }
        // [1297]  If DoAProperClose = True Then 
        if (self._doaproperclose == true) {
            // [1298]  sb.Append( {303} ) 
            _sb.append("</");
            // [1299]  sb.Append(Tag) 
            _sb.append(self._tag);
            // [1300]  sb.Append( {304} ) 
            _sb.append(">");
            // [1301]  End If 
        }
        // [1302]  sb.Append(CRLF) 
        _sb.append("\n");
        // [1303]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

    // [1307] Sub getAttr(attr As String) As String 
    this.getattr = function (_attr) {
        if (self == null) self = this;
        // [1308]  attr = attr.tolowercase 
        _attr = _attr.toLowerCase();
        // [1309]  If properties.ContainsKey(attr) Then 
        if ((_attr in self._properties)) {
            // [1310]  Return properties.Get(attr) 
            return self._properties[_attr];
            // [1311]  Else 
        } else {
            // [1312]  Return {305} 
            return "";
            // [1313]  End If 
        }
        // End Sub
    };

    // [1318] public Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _imgurl;
        var _lnk;
        var _sb;
        var _strcontent;
        var _sout;
        // [1319]  If ParentID <> {306} Then 
        if (self._parentid != "") {
            // [1320]  ID = ParentID & ID 
            self._id = self._parentid + self._id;
            // [1321]  End If 
        }
        // [1322]  Select Case Tag 
        switch ("" + self._tag) {
            // [1323]  Case {307} , {308} 
            case "" + "img":
            case "" + "script":
                // [1325]  Dim imgURL As String = getAttr( {309} ) 
                _imgurl = self.getattr("src");
                // [1326]  If imgURL.Length > 0 Then 
                if (_imgurl.length > 0) {
                    // [1327]  imgURL = imgURL.tolowercase 
                    _imgurl = _imgurl.toLowerCase();
                    // [1328]  End If 
                }
                // [1329]  Case {310} 
                break;
            case "" + "link":
                // [1330]  Dim lnk As String = getAttr( {311} ) 
                _lnk = self.getattr("href");
                // [1331]  If lnk.Length > 0 Then 
                if (_lnk.length > 0) {
                    // [1332]  lnk = lnk.tolowercase 
                    _lnk = _lnk.toLowerCase();
                    // [1333]  End If 
                }
                // [1334]  End Select 
                break;
        }
        // [1335]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [1336]  sb.Initialize 
        _sb.isinitialized = true;
        // [1337]  sb.Append(Open) 
        _sb.append(self.open());
        // [1338]  If TextAfter = True Then 
        if (self._textafter == true) {
            // [1339]  Contents.Add(Text) 
            self._contents.push(self._text);
            // [1340]  Else 
        } else {
            // [1341]  Contents.InsertAt(0,Text) 
            self._contents.splice.apply(self._contents, [0, 0].concat(self._text));
            // [1342]  End If 
        }
        // [1343]  For Each strContent As String In Contents 
        for (var _strcontentindex = 0; _strcontentindex < self._contents.length; _strcontentindex++) {
            _strcontent = self._contents[_strcontentindex];
            // [1344]  If strContent.Length > 0 Then 
            if (_strcontent.length > 0) {
                // [1345]  sb.Append(strContent) 
                _sb.append(_strcontent);
                // [1346]  End If 
            }
            // [1347]  Next 
        }
        // [1348]  sb.Append(Close) 
        _sb.append(self.close());
        // [1349]  Dim sout As String = sb.ToString 
        _sout = _sb.toString();
        // [1350]  If DontBreak.IndexOf(Tag) <> -1 Then 
        if (self._dontbreak.indexOf(self._tag) != -1) {
            // [1351]  sout = sout.Replace(CRLF, {312} ) 
            _sout = _sout.split("\n").join("");
            // [1352]  End If 
        }
        // [1354]  sout = sout.Replace(CRLF, {313} ) 
        _sout = _sout.split("\n").join("");
        // [1355]  Return sout 
        return _sout;
        // End Sub
    };

    // [1358] Sub MaterialHoverable(bStatus As Boolean) As UOEHTML 
    this.materialhoverable = function (_bstatus) {
        if (self == null) self = this;
        // [1359]  AddClassOnCondition(bStatus, {314} ) 
        self.addclassoncondition(_bstatus, "hoverable");
        // [1360]  Return Me 
        return self;
        // End Sub
    };

    // [1363] Sub MaterialTruncate(bStatus As Boolean) As UOEHTML 
    this.materialtruncate = function (_bstatus) {
        if (self == null) self = this;
        // [1364]  AddClassOnCondition(bStatus, {315} ) 
        self.addclassoncondition(_bstatus, "truncate");
        // [1365]  Return Me 
        return self;
        // End Sub
    };

    // [1368] Sub MaterialFloatLeft(bStatus As Boolean) As UOEHTML 
    this.materialfloatleft = function (_bstatus) {
        if (self == null) self = this;
        // [1369]  If bStatus = True Then 
        if (_bstatus == true) {
            // [1370]  removeClass( {316} ) 
            self.removeclass("right");
            // [1371]  removeClass( {317} ) 
            self.removeclass("left");
            // [1372]  addClass( {318} ) 
            self.addclass("left");
            // [1373]  End If 
        }
        // [1374]  Return Me 
        return self;
        // End Sub
    };

    // [1377] Sub MaterialFlowText(bStatus As Boolean) As UOEHTML 
    this.materialflowtext = function (_bstatus) {
        if (self == null) self = this;
        // [1378]  AddClassOnCondition(bStatus, {319} ) 
        self.addclassoncondition(_bstatus, "flow-text");
        // [1379]  Return Me 
        return self;
        // End Sub
    };

    // [1383] Sub MaterialFloatRight(bStatus As Boolean) As UOEHTML 
    this.materialfloatright = function (_bstatus) {
        if (self == null) self = this;
        // [1384]  If bStatus = True Then 
        if (_bstatus == true) {
            // [1385]  removeClass( {320} ) 
            self.removeclass("left");
            // [1386]  removeClass( {321} ) 
            self.removeclass("right");
            // [1387]  addClass( {322} ) 
            self.addclass("right");
            // [1388]  End If 
        }
        // [1389]  Return Me 
        return self;
        // End Sub
    };

    // [1392] Sub MaterialTextAlign(textalign As String) As UOEHTML 
    this.materialtextalign = function (_textalign) {
        if (self == null) self = this;
        // [1393]  If textalign.Length > 0 Then 
        if (_textalign.length > 0) {
            // [1394]  removeClass( {323} ) 
            self.removeclass("center-align");
            // [1395]  removeClass( {324} ) 
            self.removeclass("right-align");
            // [1396]  removeClass( {325} ) 
            self.removeclass("left-align");
            // [1397]  addClass(textalign) 
            self.addclass(_textalign);
            // [1398]  End If 
        }
        // [1399]  Return Me 
        return self;
        // End Sub
    };

    // [1402] Sub MaterialLeftAlignText(bStatus As Boolean) As UOEHTML 
    this.materialleftaligntext = function (_bstatus) {
        if (self == null) self = this;
        // [1403]  If bStatus = True Then 
        if (_bstatus == true) {
            // [1404]  removeClass( {326} ) 
            self.removeclass("center-align");
            // [1405]  removeClass( {327} ) 
            self.removeclass("right-align");
            // [1406]  removeClass( {328} ) 
            self.removeclass("left-align");
            // [1407]  addClass( {329} ) 
            self.addclass("left-align");
            // [1408]  End If 
        }
        // [1409]  Return Me 
        return self;
        // End Sub
    };

    // [1412] Sub MaterialCenterAlignText(bStatus As Boolean) As UOEHTML 
    this.materialcenteraligntext = function (_bstatus) {
        if (self == null) self = this;
        // [1413]  If bStatus = True Then 
        if (_bstatus == true) {
            // [1414]  removeClass( {330} ) 
            self.removeclass("center-align");
            // [1415]  removeClass( {331} ) 
            self.removeclass("right-align");
            // [1416]  removeClass( {332} ) 
            self.removeclass("left-align");
            // [1417]  addClass( {333} ) 
            self.addclass("center-align");
            // [1418]  End If 
        }
        // [1419]  Return Me 
        return self;
        // End Sub
    };

    // [1422] Sub MaterialRightAlignText(bStatus As Boolean) As UOEHTML 
    this.materialrightaligntext = function (_bstatus) {
        if (self == null) self = this;
        // [1423]  If bStatus = True Then 
        if (_bstatus == true) {
            // [1424]  removeClass( {334} ) 
            self.removeclass("center-align");
            // [1425]  removeClass( {335} ) 
            self.removeclass("right-align");
            // [1426]  removeClass( {336} ) 
            self.removeclass("left-align");
            // [1427]  addClass( {337} ) 
            self.addclass("right-align");
            // [1428]  End If 
        }
        // [1429]  Return Me 
        return self;
        // End Sub
    };

    // [1432] Sub MaterialAlignText(sAlignment As String) As UOEHTML 
    this.materialaligntext = function (_salignment) {
        if (self == null) self = this;
        // [1433]  If sAlignment.Length > 0 Then 
        if (_salignment.length > 0) {
            // [1434]  removeClass( {338} ) 
            self.removeclass("center-align");
            // [1435]  removeClass( {339} ) 
            self.removeclass("right-align");
            // [1436]  removeClass( {340} ) 
            self.removeclass("left-align");
            // [1437]  addClass(sAlignment) 
            self.addclass(_salignment);
            // [1438]  End If 
        }
        // [1439]  Return Me 
        return self;
        // End Sub
    };

    // [1442] Sub MaterialZDepth(szdepth As String) As UOEHTML 
    this.materialzdepth = function (_szdepth) {
        if (self == null) self = this;
        // [1444]  If szdepth.Length > 0 Then 
        if (_szdepth.length > 0) {
            // [1445]  removeClass( {341} ) 
            self.removeclass("z-depth-1");
            // [1446]  removeClass( {342} ) 
            self.removeclass("z-depth-2");
            // [1447]  removeClass( {343} ) 
            self.removeclass("z-depth-3");
            // [1448]  removeClass( {344} ) 
            self.removeclass("z-depth-4");
            // [1449]  removeClass( {345} ) 
            self.removeclass("z-depth-5");
            // [1450]  addClass(szdepth) 
            self.addclass(_szdepth);
            // [1451]  End If 
        }
        // [1452]  Return Me 
        return self;
        // End Sub
    };

    // [1456] Sub MaterialVerticalAlign(bStatus As Boolean) As UOEHTML 
    this.materialverticalalign = function (_bstatus) {
        if (self == null) self = this;
        // [1457]  AddClassOnCondition(bStatus, {346} ) 
        self.addclassoncondition(_bstatus, "valign-wrapper");
        // [1458]  Return Me 
        return self;
        // End Sub
    };

    // [1462] Sub MaterialVisibility(sVisibility As String) As UOEHTML 
    this.materialvisibility = function (_svisibility) {
        if (self == null) self = this;
        // [1463]  If sVisibility.Length > 0 Then 
        if (_svisibility.length > 0) {
            // [1464]  removeClass( {347} ) 
            self.removeclass("hide-on-small-only");
            // [1465]  removeClass( {348} ) 
            self.removeclass("hide-on-med-only");
            // [1466]  removeClass( {349} ) 
            self.removeclass("hide-on-med-and-down");
            // [1467]  removeClass( {350} ) 
            self.removeclass("hide-on-med-and-up");
            // [1468]  removeClass( {351} ) 
            self.removeclass("hide-on-large-only");
            // [1469]  removeClass( {352} ) 
            self.removeclass("show-on-large");
            // [1470]  removeClass( {353} ) 
            self.removeclass("show-on-small");
            // [1471]  removeClass( {354} ) 
            self.removeclass("show-on-medium");
            // [1472]  removeClass( {355} ) 
            self.removeclass("show-on-medium-and-up");
            // [1473]  removeClass( {356} ) 
            self.removeclass("show-on-medium-and-down");
            // [1474]  removeClass( {357} ) 
            self.removeclass("hide");
            // [1475]  addClass(sVisibility) 
            self.addclass(_svisibility);
            // [1476]  End If 
        }
        // [1477]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEHTML5Video  ===========================
function banano_uoebanano_uoehtml5video() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._url = '';

    this._visibility = '';

    this._zdepth = '';

    this._element = new banano_uoebanano_uoehtml();

    this._enabled = false;

    this._source = new banano_uoebanano_uoehtml();

    this._responsive = false;

    this._showcontrols = false;

    this._videotype = '';

    this._height = '';

    this._width = '';

    this._hoverable = false;

    this._loopit = false;

    this._autoplay = false;

    this._allowfullscreen = false;

    // [25] Sub AddStyleAttribute(attribute As String, value As String) As UOEHTML5Video 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [26]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [27]  Return Me 
        return self;
        // End Sub
    };

    // [32] Public Sub Initialize(thisApp As UOEApp, sID As String, sURL As String) 
    this.initialize = function (_thisapp, _sid, _surl) {
        if (self == null) self = this;
        // [34]  App = thisApp 
        self._app = _thisapp;
        // [35]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [36]  Responsive = True 
        self._responsive = true;
        // [37]  ShowControls = True 
        self._showcontrols = true;
        // [38]  Width = {0} 
        self._width = "100%";
        // [39]  Height = {1} 
        self._height = "100%";
        // [40]  VideoType = {2} 
        self._videotype = "video/mp4";
        // [41]  Element.Initialize(ID, {3} ) 
        self._element.initialize(self._id, "video");
        // [42]  AutoPlay = False 
        self._autoplay = false;
        // [43]  LoopIT = False 
        self._loopit = false;
        // [44]  Enabled = True 
        self._enabled = true;
        // [45]  ZDepth= {4} 
        self._zdepth = "";
        // [46]  Visibility= {5} 
        self._visibility = "";
        // [47]  AllowFullScreen = False 
        self._allowfullscreen = false;
        // [48]  URL = sURL 
        self._url = _surl;
        // [49]  source.Initialize( {6} , {7} ) 
        self._source.initialize("", "source");
        // End Sub
    };

    // [53] Sub AddClass(sClass As String) As UOEHTML5Video 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [54]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub RemoveClass(sClass As String) As UOEHTML5Video 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [60]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [65] Sub AddAttribute(attr As String, value As String) As UOEHTML5Video 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [66]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [67]  Return Me 
        return self;
        // End Sub
    };

    // [71] Sub RemoveAttribute(attr As String) As UOEHTML5Video 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [72]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [73]  Return Me 
        return self;
        // End Sub
    };

    // [77] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [80]  Element.ID = ID 
        self._element._id = self._id;
        // [81]  source.AddAttribute( {21} ,VideoType) 
        self._source.addattribute("type", self._videotype);
        // [82]  source.AddAttribute( {22} , URL) 
        self._source.addattribute("src", self._url);
        // [83]  Element.AddStyleAttribute( {23} ,Element.MakePx(Width)) 
        self._element.addstyleattribute("width", self._element.makepx(self._width));
        // [84]  Element.AddStyleAttribute( {24} ,Element.MakePx(Height)) 
        self._element.addstyleattribute("height", self._element.makepx(self._height));
        // [85]  Element.AddLooseAttribute( {25} ) 
        self._element.addlooseattribute("playsinline");
        // [86]  Element.AddLooseAttributeOnCondition(ShowControls, {26} ) 
        self._element.addlooseattributeoncondition(self._showcontrols, "controls");
        // [87]  Element.AddLooseAttributeOnCondition(LoopIT, {27} ) 
        self._element.addlooseattributeoncondition(self._loopit, "loop");
        // [88]  Element.AddLooseAttributeOnCondition(AutoPlay, {28} ) 
        self._element.addlooseattributeoncondition(self._autoplay, "autoplay");
        // [89]  Element.AddClassOnCondition(Responsive, {29} ) 
        self._element.addclassoncondition(self._responsive, "responsive-video");
        // [90]  Element.AddLooseAttributeOnCondition(AllowFullScreen, {30} ) 
        self._element.addlooseattributeoncondition(self._allowfullscreen, "allowfullscreen");
        // [91]  Element.AddContent(source.HTML) 
        self._element.addcontent(self._source.html());
        // [92]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [93]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [94]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [95]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [96]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [101]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEImage  ===========================
function banano_uoebanano_uoeimage() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._responsive = false;

    this._circle = false;

    this._url = '';

    this._alt = '';

    this._element = new banano_uoebanano_uoehtml();

    this._zdepth = '';

    this._visibility = '';

    this._hoverable = false;

    this._materialboxed = false;

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._enabled = false;

    this._activator = false;

    this._static = false;

    // [24] Sub SetMARGINTOP(sTop As String) As UOEImage 
    this.setmargintop = function (_stop) {
        if (self == null) self = this;
        // [25]  AddStyleAttribute( {0} ,sTop) 
        self.addstyleattribute("margin-top", _stop);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [31] Sub AddStyleAttribute(attribute As String, value As String) As UOEImage 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [32]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [33]  Return Me 
        return self;
        // End Sub
    };

    // [37] Sub AddClass(sClass As String) As UOEImage 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [38]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [39]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub RemoveClass(sClass As String) As UOEImage 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [44]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [49] Sub AddAttribute(attr As String, value As String) As UOEImage 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [50]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveAttribute(attr As String) As UOEImage 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [56]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Public Sub Initialize(thisApp As UOEApp, sid As String,ImgURL As String,ImgAlt As String,bStatic As Boolean) 
    this.initialize = function (_thisapp, _sid, _imgurl, _imgalt, _bstatic) {
        if (self == null) self = this;
        // [63]  App = thisApp 
        self._app = _thisapp;
        // [64]  Responsive = False 
        self._responsive = false;
        // [65]  Activator = False 
        self._activator = false;
        // [66]  Circle = False 
        self._circle = false;
        // [67]  URL = ImgURL 
        self._url = _imgurl;
        // [68]  Alt = ImgAlt 
        self._alt = _imgalt;
        // [69]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [70]  Enabled = True 
        self._enabled = true;
        // [71]  ZDepth = {1} 
        self._zdepth = "";
        // [72]  Visibility = {2} 
        self._visibility = "";
        // [73]  Hoverable = False 
        self._hoverable = false;
        // [74]  MaterialBoxed = False 
        self._materialboxed = false;
        // [75]  Element.Initialize(ID, {3} ) 
        self._element.initialize(self._id, "img");
        // [76]  WavesEffect = True 
        self._waveseffect = true;
        // [77]  WavesType =App.EnumWavesType.light 
        self._wavestype = self._app._enumwavestype._light;
        // [78]  WavesCircle = False 
        self._wavescircle = false;
        // [79]  Static = bStatic 
        self._static = _bstatic;
        // End Sub
    };

    // [83] Sub SetSize(imgHeight As String, imgWidth As String) As UOEImage 
    this.setsize = function (_imgheight, _imgwidth) {
        if (self == null) self = this;
        // [84]  Element.setheightpx(imgHeight) 
        self._element.setheightpx(_imgheight);
        // [85]  Element.setwidthpx(imgWidth) 
        self._element.setwidthpx(_imgwidth);
        // [86]  Return Me 
        return self;
        // End Sub
    };

    // [90] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [91]  WavesEffect = Responsive 
        self._waveseffect = self._responsive;
        // [92]  Element.ID = ID 
        self._element._id = self._id;
        // [93]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [94]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [95]  Element.MaterialZdepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [96]  Element.MaterialCircle(Circle) 
        self._element.materialcircle(self._circle);
        // [97]  Element.SetAlt(Alt) 
        self._element.setalt(self._alt);
        // [98]  Element.SetSrc(URL,Static) 
        self._element.setsrc(self._url, self._static);
        // [99]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [100]  Element.MaterialResponsive(Responsive) 
        self._element.materialresponsive(self._responsive);
        // [101]  Element.MaterialBoxed(MaterialBoxed) 
        self._element.materialboxed(self._materialboxed);
        // [102]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [103]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [104]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [105]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [106]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [107]  Element.AddDataAttribute( {4} ,Alt) 
        self._element.adddataattribute("caption", self._alt);
        // [108]  Element.AddClassOnCondition(Activator, {5} ) 
        self._element.addclassoncondition(self._activator, "activator");
        // [116]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOESliderOrientation  ===========================
function banano_uoebanano_uoesliderorientation() {
    var self;
    this._horizontal = "horizontal";

    this._vertical = "vertical";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEInput  ===========================
function banano_uoebanano_uoeinput() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._title = '';

    this._validate = false;

    this._theme = '';

    this._placeholder = '';

    this._div = new banano_uoebanano_uoehtml();

    this._inp = new banano_uoebanano_uoehtml();

    this._lbl = new banano_uoebanano_uoehtml();

    this._help = new banano_uoebanano_uoehtml();

    this._inptype = '';

    this._enabled = false;

    this._errormsg = '';

    this._successmsg = '';

    this._iconname = '';

    this._maxlength = 0;

    this._required = false;

    this._hoverable = false;

    this._zdepth = '';

    this._visibility = '';

    this._helpertext = '';

    this._inline = false;

    this._text = '';

    this._autofocus = false;

    this._hasautocomplete = false;

    this._items = [];

    this._instance = '';

    // [63] Sub AddStyleAttribute(attribute As String, value As String) As UOEInput 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [64]  inp.AddStyleAttribute(attribute,value) 
        self._inp.addstyleattribute(_attribute, _value);
        // [65]  Return Me 
        return self;
        // End Sub
    };

    // [71] Public Sub Initialize(thisApp As UOEApp, sID As String, sTitle As String, sPlaceholder As String, sInputType As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _splaceholder, _sinputtype, _themename) {
        if (self == null) self = this;
        // [72]  App = thisApp 
        self._app = _thisapp;
        // [73]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [74]  Title = sTitle 
        self._title = _stitle;
        // [75]  Validate = False 
        self._validate = false;
        // [76]  Theme = themeName 
        self._theme = _themename;
        // [77]  Placeholder = sPlaceholder 
        self._placeholder = _splaceholder;
        // [78]  inpType = sInputType 
        self._inptype = _sinputtype;
        // [79]  Enabled = True 
        self._enabled = true;
        // [80]  Required = False 
        self._required = false;
        // [81]  ErrorMsg = {21} 
        self._errormsg = "Error";
        // [82]  SuccessMsg = {22} 
        self._successmsg = "Success";
        // [83]  Text = {23} 
        self._text = "";
        // [84]  div.Initialize(ID & {24} , {25} ) 
        self._div.initialize(self._id + "p", "div");
        // [85]  div.AddClass( {26} ) 
        self._div.addclass("input-field");
        // [86]  div.AddClass( {27} ) 
        self._div.addclass("col");
        // [87]  div.AddClass( {28} ) 
        self._div.addclass("s12");
        // [88]  div.AddClass( {29} ) 
        self._div.addclass("m12");
        // [89]  div.AddClass( {30} ) 
        self._div.addclass("l12");
        // [90]  inp.Initialize(ID, {31} ) 
        self._inp.initialize(self._id, "input");
        // [91]  inp.AddAttribute( {32} ,Placeholder) 
        self._inp.addattribute("placeholder", self._placeholder);
        // [92]  inp.AddAttribute( {33} ,inpType) 
        self._inp.addattribute("type", self._inptype);
        // [93]  lbl.Initialize( {34} , {35} ) 
        self._lbl.initialize("", "label");
        // [94]  lbl.AddAttribute( {36} ,ID) 
        self._lbl.addattribute("for", self._id);
        // [95]  lbl.AddContent(Title) 
        self._lbl.addcontent(self._title);
        // [96]  lbl.AddClass( {37} ) 
        self._lbl.addclass("active");
        // [97]  help.Initialize( {38} , {39} ) 
        self._help.initialize("", "span");
        // [98]  help.AddClass( {40} ) 
        self._help.addclass("helper-text");
        // [99]  HelperText = {41} 
        self._helpertext = "";
        // [100]  Inline = False 
        self._inline = false;
        // [101]  hasAutoComplete = False 
        self._hasautocomplete = false;
        // [102]  MaxLength = 0 
        self._maxlength = 0;
        // [103]  AutoFocus = False 
        self._autofocus = false;
        // [104]  Items.Initialize 
        self._items.length = 0;
        // [105]  Items.clear 
        self._items.length = 0;
        // [106]  Instance = {4} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [110] Sub AddItem(itemText As String,itemURL As String) As UOEInput 
    this.additem = function (_itemtext, _itemurl) {
        if (self == null) self = this;
        var _im;
        // [111]  hasAutoComplete = True 
        self._hasautocomplete = true;
        // [112]  Dim im As Map = CreateMap( {42} :itemURL, {43} : itemText) 
        _im = {
            "id": _itemurl,
            "text": _itemtext
        };
        // [113]  Items.Add(im) 
        self._items.push(_im);
        // [114]  Return Me 
        return self;
        // End Sub
    };

    // [118] Sub AddClass(sClass As String) As UOEInput 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [119]  div.AddClass(sClass) 
        self._div.addclass(_sclass);
        // [120]  Return Me 
        return self;
        // End Sub
    };

    // [124] Sub RemoveClass(sClass As String) As UOEInput 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [125]  div.RemoveClass(sClass) 
        self._div.removeclass(_sclass);
        // [126]  Return Me 
        return self;
        // End Sub
    };

    // [130] Sub AddAttribute(attr As String, value As String) As UOEInput 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [131]  div.AddAttribute(attr,value) 
        self._div.addattribute(_attr, _value);
        // [132]  Return Me 
        return self;
        // End Sub
    };

    // [136] Sub RemoveAttribute(attr As String) As UOEInput 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [137]  div.RemoveAttribute(attr) 
        self._div.removeattribute(_attr);
        // [138]  Return Me 
        return self;
        // End Sub
    };

    // [142] Sub SetMessages(onError As String, onSuccess As String) As UOEInput 
    this.setmessages = function (_onerror, _onsuccess) {
        if (self == null) self = this;
        // [143]  ErrorMsg = onError 
        self._errormsg = _onerror;
        // [144]  SuccessMsg = onSuccess 
        self._successmsg = _onsuccess;
        // [145]  Return Me 
        return self;
        // End Sub
    };

    // [149] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [150]  div.MaterialVisibility(Visibility) 
        self._div.materialvisibility(self._visibility);
        // [151]  div.MaterialHoverable(Hoverable) 
        self._div.materialhoverable(self._hoverable);
        // [152]  div.MaterialZdepth(ZDepth) 
        self._div.materialzdepth(self._zdepth);
        // [153]  App.ApplyToolTip(ID,div) 
        self._app.applytooltip(self._id, self._div);
        // [154]  div.AddClassOnCondition(Inline, {44} ) 
        self._div.addclassoncondition(self._inline, "inline");
        // [155]  div.AddStyleAttributeOnCondition(Inline, {45} , {46} ) 
        self._div.addstyleattributeoncondition(self._inline, "display", "inline-block");
        // [156]  div.AddAttributeOnCondition(AutoFocus, {47} , {48} ) 
        self._div.addattributeoncondition(self._autofocus, "autofocus", "true");
        // [157]  inp.AddClassOnCondition(Validate, {49} ) 
        self._inp.addclassoncondition(self._validate, "validate");
        // [158]  inp.MaterialRequired(Required) 
        self._inp.materialrequired(self._required);
        // [159]  inp.AddClassOnCondition(hasAutoComplete, {50} ) 
        self._inp.addclassoncondition(self._hasautocomplete, "autocomplete");
        // [160]  inp.AddLooseAttributeOnFalseCondition(Enabled, {51} ) 
        self._inp.addlooseattributeonfalsecondition(self._enabled, "disabled");
        // [161]  inp.AddAttribute( {52} ,ID) 
        self._inp.addattribute("name", self._id);
        // [162]  AddRedStar(Required,lbl) 
        self.addredstar(self._required, self._lbl);
        // [163]  help.AddAttribute( {53} ,ErrorMsg) 
        self._help.addattribute("data-error", self._errormsg);
        // [164]  help.AddAttribute( {54} ,SuccessMsg) 
        self._help.addattribute("data-success", self._successmsg);
        // [165]  help.AddContent(HelperText) 
        self._help.addcontent(self._helpertext);
        // [166]  modUOE.MaterialAddIcon(App,div,IconName, {55} ,Theme,False,False,False,True,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._div, self._iconname, "", self._theme, false, false, false, true, false);
        // [167]  Select Case inpType 
        switch ("" + self._inptype) {
            // [168]  Case App.EnumInputType.textarea 
            case "" + self._app._enuminputtype._textarea:
                // [169]  inp.RemoveAttribute( {56} ) 
                self._inp.removeattribute("type");
                // [170]  inp.settag( {57} ) 
                self._inp.settag("textarea");
                // [171]  inp.AddClass( {58} ) 
                self._inp.addclass("materialize-textarea");
                // [172]  inp.RemoveClass( {59} ) 
                self._inp.removeclass("validate");
                // [173]  End Select 
                break;
        }
        // [174]  inp.AddAttribute( {60} , MaxLength) 
        self._inp.addattribute("data-length", self._maxlength);
        // [175]  inp.AddAttribute( {61} , inp.tag) 
        self._inp.addattribute("data-instance", self._inp._tag);
        // [176]  inp.AddAttribute( {62} ,Text) 
        self._inp.addattribute("value", self._text);
        // [177]  div.AddContent(inp.HTML) 
        self._div.addcontent(self._inp.html());
        // [178]  div.AddContent(lbl.HTML) 
        self._div.addcontent(self._lbl.html());
        // [179]  div.AddElement(help) 
        self._div.addelement(self._help);
        // [184]  Return div.html 
        return self._div.html();
        // End Sub
    };

    // [189] private Sub AddRedStar(bRequired As Boolean, Element As UOEHTML) As UOEHTML 
    this.addredstar = function (_brequired, _element) {
        if (self == null) self = this;
        var _span;
        // [190]  If bRequired = True Then 
        if (_brequired == true) {
            // [191]  Dim span As UOEHTML 
            _span = new banano_uoebanano_uoehtml();
            // [192]  span.Initialize( {65} , {66} ) 
            _span.initialize("", "span");
            // [193]  span.AddContent( {67} ).AddContent( {68} ) 
            _span.addcontent("{NBSP}").addcontent("*");
            // [194]  App.MaterialUseTheme( {69} ,span) 
            self._app.materialusetheme("redtransparent", _span);
            // [195]  Element.AddContent(span.HTML) 
            _element.addcontent(_span.html());
            // [196]  End If 
        }
        // [197]  Return Element 
        return _element;
        // End Sub
    };

    // [228] Sub SelectOption(varName As String) As String 
    this.selectoption = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [229]  Dim script As String = {10} 
        _script = "" + self._instance + ".selectOption(" + _varname + ");";
        // [230]  Return script 
        return _script;
        // End Sub
    };

    // [234] Sub UpdateData(varName As String) As String 
    this.updatedata = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [235]  Dim script As String = {11} 
        _script = "" + self._instance + ".updateData(" + _varname + ");";
        // [236]  Return script 
        return _script;
        // End Sub
    };

    // [240] Sub getActiveIndex(varName As String) As String 
    this.getactiveindex = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [241]  Dim script As String = {12} 
        _script = "" + _varname + " = " + self._instance + ".activeIndex;";
        // [242]  Return script 
        return _script;
        // End Sub
    };

    // [245] private Sub BuildAutoComplete() As String 
    this.buildautocomplete = function () {
        if (self == null) self = this;
        var _sb;
        var _kcnt;
        var _ktot;
        var _ac;
        var _mk;
        var _mv;
        var _script;
        // [246]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [247]  sb.Initialize 
        _sb.isinitialized = true;
        // [248]  sb.Append( {71} ) 
        _sb.append("data: {");
        // [249]  sb.Append(CRLF) 
        _sb.append("\n");
        // [250]  Dim kcnt As Int 
        _kcnt = 0;
        // [251]  Dim ktot As Int = Items.Size - 1 
        _ktot = self._items.length - 1;
        // [253]  Dim ac As Map = Items.Get(0) 
        _ac = self._items[0];
        // [254]  Dim mk As String = ac.Get( {72} ) 
        _mk = _ac["id"];
        // [255]  Dim mv As String = ac.Get( {73} ) 
        _mv = _ac["text"];
        // [256]  Dim script As String = {13} 
        _script = "\"" + _mv + "\":" + _mk + "";
        // [257]  sb.Append(script) 
        _sb.append(_script);
        // [258]  For kcnt = 1 To ktot 
        for (_kcnt = 1; _kcnt <= _ktot; _kcnt++) {
            // [259]  Dim ac As Map = Items.Get(kcnt) 
            _ac = self._items[_kcnt];
            // [260]  Dim mk As String = ac.Get( {74} ) 
            _mk = _ac["id"];
            // [261]  Dim mv As String = ac.Get( {75} ) 
            _mv = _ac["text"];
            // [262]  Dim script As String = {14} 
            _script = "\"" + _mv + "\":" + _mk + "";
            // [263]  sb.Append( {76} ) 
            _sb.append(",");
            // [264]  sb.Append(script) 
            _sb.append(_script);
            // [265]  Next 
        }
        // [266]  sb.Append( {77} ) 
        _sb.append("}");
        // [267]  Return sb.tostring 
        return _sb.toString();
        // End Sub
    };

}
// =========================== UOELabel  ===========================
function banano_uoebanano_uoelabel() {
    var self;
    this._id = '';

    this._zdepth = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._truncate = false;

    this._verticalalign = false;

    this._visibility = '';

    this._hoverable = false;

    this._text = '';

    this._flowtext = false;

    this._alignment = '';

    this._blockquote = false;

    this._verticallyalign = false;

    this._blockquotewidth = 0;

    this._app = new banano_uoebanano_uoeapp();

    // [22] Public Sub Initialize(thisApp As UOEApp, pID As String, pSize As String, pText As String, pTheme As String, pClass As String) 
    this.initialize = function (_thisapp, _pid, _psize, _ptext, _ptheme, _pclass) {
        if (self == null) self = this;
        // [24]  App = thisApp 
        self._app = _thisapp;
        // [25]  ID = pID.tolowercase 
        self._id = _pid.toLowerCase();
        // [26]  Theme = pTheme 
        self._theme = _ptheme;
        // [27]  Element.Initialize(ID,pSize) 
        self._element.initialize(self._id, _psize);
        // [28]  Element.addClass(pClass) 
        self._element.addclass(_pclass);
        // [29]  Hoverable = False 
        self._hoverable = false;
        // [30]  Text = pText 
        self._text = _ptext;
        // [31]  Alignment = {2} 
        self._alignment = "";
        // [32]  BlockQuote = False 
        self._blockquote = false;
        // [33]  Element.AddContent(pText) 
        self._element.addcontent(_ptext);
        // [34]  VerticallyAlign = False 
        self._verticallyalign = false;
        // [35]  BlockQuoteWidth = 5 
        self._blockquotewidth = 5;
        // End Sub
    };

    // [39] Sub AddColor(value As String, color As String) As UOELabel 
    this.addcolor = function (_value, _color) {
        if (self == null) self = this;
        var _span;
        // [40]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [41]  span.Initialize( {3} , {4} ) 
        _span.initialize("", "span");
        // [42]  span.AddContent(value) 
        _span.addcontent(_value);
        // [43]  span.MaterialTextColor(color) 
        _span.materialtextcolor(_color);
        // [44]  Element.AddContent(span.HTML) 
        self._element.addcontent(_span.html());
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [50] Sub AddSpan(pID As String,pText As String, pTheme As String, pClass As String) As UOELabel 
    this.addspan = function (_pid, _ptext, _ptheme, _pclass) {
        if (self == null) self = this;
        var _ml;
        // [51]  pID = pID.tolowercase 
        _pid = _pid.toLowerCase();
        // [52]  Dim ml As UOELabel 
        _ml = new banano_uoebanano_uoelabel();
        // [53]  ml.Initialize(App,pID, {5} ,pText,pTheme,pClass) 
        _ml.initialize(self._app, _pid, "span", _ptext, _ptheme, _pclass);
        // [54]  Element.AddContent(ml.tostring) 
        self._element.addcontent(_ml.tostring());
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub AddMailTo(emailaddress As String,subject As String,caption As String) As UOELabel 
    this.addmailto = function (_emailaddress, _subject, _caption) {
        if (self == null) self = this;
        var _a;
        // [60]  subject = subject.Replace( {6} , {7} ) 
        _subject = _subject.split(" ").join("%20");
        // [61]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [62]  a.Initialize( {8} , {9} ) 
        _a.initialize("", "a");
        // [63]  a.setHREF( {0} ).AddContent(caption) 
        _a.sethref("mailto:" + _emailaddress + "?subject=" + _subject + "").addcontent(_caption);
        // [64]  Element.AddContent(a.ToString) 
        self._element.addcontent(_a.tostring());
        // [65]  Return Me 
        return self;
        // End Sub
    };

    // [69] Sub AddText(sText As String) As UOELabel 
    this.addtext = function (_stext) {
        if (self == null) self = this;
        // [70]  Element.AddContent(sText) 
        self._element.addcontent(_stext);
        // [71]  Return Me 
        return self;
        // End Sub
    };

    // [75] Sub AddBold(value As String) As UOELabel 
    this.addbold = function (_value) {
        if (self == null) self = this;
        var _sb;
        // [76]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [77]  sb.Initialize 
        _sb.isinitialized = true;
        // [78]  sb.Append( {10} ).Append(value).Append( {11} ) 
        _sb.append("{B}").append(_value).append("{/B}");
        // [79]  Element.AddContent(sb.ToString) 
        self._element.addcontent(_sb.toString());
        // [80]  Return Me 
        return self;
        // End Sub
    };

    // [84] Sub AddItalic(value As String) As UOELabel 
    this.additalic = function (_value) {
        if (self == null) self = this;
        var _sb;
        // [85]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [86]  sb.Initialize 
        _sb.isinitialized = true;
        // [87]  sb.Append( {12} ).Append(value).Append( {13} ) 
        _sb.append("{I}").append(_value).append("{/I}");
        // [88]  Element.AddContent(sb.ToString) 
        self._element.addcontent(_sb.toString());
        // [89]  Return Me 
        return self;
        // End Sub
    };

    // [93] Sub AddUnderline(value As String) As UOELabel 
    this.addunderline = function (_value) {
        if (self == null) self = this;
        var _sb;
        // [94]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [95]  sb.Initialize 
        _sb.isinitialized = true;
        // [96]  sb.Append( {14} ).Append(value).Append( {15} ) 
        _sb.append("{U}").append(_value).append("{/U}");
        // [97]  Element.AddContent(sb.ToString) 
        self._element.addcontent(_sb.toString());
        // [98]  Return Me 
        return self;
        // End Sub
    };

    // [102] Sub AddSubScript(value As String) As UOELabel 
    this.addsubscript = function (_value) {
        if (self == null) self = this;
        var _sb;
        // [103]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [104]  sb.Initialize 
        _sb.isinitialized = true;
        // [105]  sb.Append( {16} ).Append(value).Append( {17} ) 
        _sb.append("{SUB}").append(_value).append("{/SUB}");
        // [106]  Element.AddContent(sb.ToString) 
        self._element.addcontent(_sb.toString());
        // [107]  Return Me 
        return self;
        // End Sub
    };

    // [111] Sub AddSuperScript(value As String) As UOELabel 
    this.addsuperscript = function (_value) {
        if (self == null) self = this;
        var _sb;
        // [112]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [113]  sb.Initialize 
        _sb.isinitialized = true;
        // [114]  sb.Append( {18} ).Append(value).Append( {19} ) 
        _sb.append("{SUP}").append(_value).append("{/SUP}");
        // [115]  Element.AddContent(sb.ToString) 
        self._element.addcontent(_sb.toString());
        // [116]  Return Me 
        return self;
        // End Sub
    };

    // [120] Sub AddBreak As UOELabel 
    this.addbreak = function () {
        if (self == null) self = this;
        // [121]  Element.AddContent( {20} ) 
        self._element.addcontent("{BR}");
        // [122]  Return Me 
        return self;
        // End Sub
    };

    // [126] Sub AddLink(href As String,caption As String) As UOELabel 
    this.addlink = function (_href, _caption) {
        if (self == null) self = this;
        var _a;
        // [127]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [128]  a.Initialize( {21} , {22} ) 
        _a.initialize("", "a");
        // [129]  a.SetHREF(href).AddContent(caption) 
        _a.sethref(_href).addcontent(_caption);
        // [130]  Element.AddElement(a) 
        self._element.addelement(_a);
        // [131]  Return Me 
        return self;
        // End Sub
    };

    // [135] Sub AddClass(sClass As String) As UOELabel 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [136]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [137]  Return Me 
        return self;
        // End Sub
    };

    // [141] Sub RemoveClass(sClass As String) As UOELabel 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [142]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [143]  Return Me 
        return self;
        // End Sub
    };

    // [147] Sub AddAttribute(attr As String, value As String) As UOELabel 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [148]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [149]  Return Me 
        return self;
        // End Sub
    };

    // [153] Sub RemoveAttr(attr As String) As UOELabel 
    this.removeattr = function (_attr) {
        if (self == null) self = this;
        // [154]  Element.RemoveAttr(attr) 
        self._element.removeattr(_attr);
        // [155]  Return Me 
        return self;
        // End Sub
    };

    // [159] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _fcolor;
        // [160]  Element.MaterialTruncate(Truncate) 
        self._element.materialtruncate(self._truncate);
        // [161]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [162]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [163]  Element.materialflowtext(FlowText) 
        self._element.materialflowtext(self._flowtext);
        // [164]  Element.MaterialVerticalAlign(VerticalAlign) 
        self._element.materialverticalalign(self._verticalalign);
        // [165]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [166]  Element.MaterialVerticalAlign(VerticallyAlign) 
        self._element.materialverticalalign(self._verticallyalign);
        // [167]  Element.MaterialTextAlign(Alignment) 
        self._element.materialtextalign(self._alignment);
        // [168]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [169]  If BlockQuote = True Then 
        if (self._blockquote == true) {
            // [170]  Element.SetTag( {23} ) 
            self._element.settag("blockquote");
            // [173]  Dim fColor As String = App.GetForeColorHex(Theme) 
            _fcolor = self._app.getforecolorhex(self._theme);
            // [174]  Element.AddStyleAttribute( {24} , {1} ) 
            self._element.addstyleattribute("border-left", "" + self._blockquotewidth + "px solid " + _fcolor + "");
            // [175]  End If 
        }
        // [176]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [177]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

}
// =========================== UOEList  ===========================
function banano_uoebanano_uoelist() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._visibility = '';

    this._element = new banano_uoebanano_uoehtml();

    this._order = false;

    this._items = [];

    // [14] Sub AddStyleAttribute(attribute As String, value As String) As UOEList 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [15]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [16]  Return Me 
        return self;
        // End Sub
    };

    // [20] Sub AsCircles As UOEList 
    this.ascircles = function () {
        if (self == null) self = this;
        // [21]  Element.SetListStyleCircle 
        self._element.setliststylecircle();
        // [22]  Return Me 
        return self;
        // End Sub
    };

    // [26] Sub AsDisk As UOEList 
    this.asdisk = function () {
        if (self == null) self = this;
        // [27]  Element.SetListStyleDisk 
        self._element.setliststyledisk();
        // [28]  Return Me 
        return self;
        // End Sub
    };

    // [32] Sub AsNone As UOEList 
    this.asnone = function () {
        if (self == null) self = this;
        // [33]  Element.SetListStyleNone 
        self._element.setliststylenone();
        // [34]  Return Me 
        return self;
        // End Sub
    };

    // [38] Sub AsSquare As UOEList 
    this.assquare = function () {
        if (self == null) self = this;
        // [39]  Element.SetListStyleSquare 
        self._element.setliststylesquare();
        // [40]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub ShowNumbers As UOEList 
    this.shownumbers = function () {
        if (self == null) self = this;
        // [44]  Element.SetTypeNumbers 
        self._element.settypenumbers();
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [48] Sub ShowUpperCase As UOEList 
    this.showuppercase = function () {
        if (self == null) self = this;
        // [49]  Element.SetTypeUpperCase 
        self._element.settypeuppercase();
        // [50]  Return Me 
        return self;
        // End Sub
    };

    // [53] Sub ShowLowerCase As UOEList 
    this.showlowercase = function () {
        if (self == null) self = this;
        // [54]  Element.SetTypeLowerCase 
        self._element.settypelowercase();
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub ShowUpperCaseRoman As UOEList 
    this.showuppercaseroman = function () {
        if (self == null) self = this;
        // [59]  Element.SetTypeUpperCaseRoman 
        self._element.settypeuppercaseroman();
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [63] Sub ShowLowerCaseRoman As UOEList 
    this.showlowercaseroman = function () {
        if (self == null) self = this;
        // [64]  Element.SetTypeLowerCaseRoman 
        self._element.settypelowercaseroman();
        // [65]  Return Me 
        return self;
        // End Sub
    };

    // [69] Public Sub Initialize(thisApp As UOEApp,sid As String, bOrder As Boolean, bInline As Boolean) 
    this.initialize = function (_thisapp, _sid, _border, _binline) {
        if (self == null) self = this;
        // [71]  App = thisApp 
        self._app = _thisapp;
        // [72]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [73]  Visibility= {2} 
        self._visibility = "";
        // [74]  Order = bOrder 
        self._order = _border;
        // [75]  Element.Initialize(sid, {3} ) 
        self._element.initialize(_sid, "ul");
        // [76]  If Order Then 
        if (self._order) {
            // [77]  Element.settag( {4} ) 
            self._element.settag("ol");
            // [78]  End If 
        }
        // [79]  Items.Initialize 
        self._items.length = 0;
        // [80]  items.clear 
        self._items.length = 0;
        // End Sub
    };

    // [89] Sub AddLink(lnkID As String,lnkText As String,lnkHREF As String, lnkTheme As String) 
    this.addlink = function (_lnkid, _lnktext, _lnkhref, _lnktheme) {
        if (self == null) self = this;
        var _li;
        var _a;
        // [90]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [91]  li.Initialize(ID & lnkID, {5} ) 
        _li.initialize(self._id + _lnkid, "li");
        // [92]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [93]  a.Initialize(lnkID, {6} ) 
        _a.initialize(_lnkid, "a");
        // [94]  a.SetHREF(lnkHREF) 
        _a.sethref(_lnkhref);
        // [95]  a.AddContent(lnkText) 
        _a.addcontent(_lnktext);
        // [96]  App.MaterialUseTheme(lnkTheme,a) 
        self._app.materialusetheme(_lnktheme, _a);
        // [97]  li.AddElement(a) 
        _li.addelement(_a);
        // [98]  Items.Add(li.HTML) 
        self._items.push(_li.html());
        // End Sub
    };

    // [102] Sub AddItem(txtID As String,txtText As String, txtTheme As String) 
    this.additem = function (_txtid, _txttext, _txttheme) {
        if (self == null) self = this;
        var _li;
        var _p;
        // [103]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [104]  li.Initialize(ID & txtID, {7} ) 
        _li.initialize(self._id + _txtid, "li");
        // [105]  Dim p As UOEHTML 
        _p = new banano_uoebanano_uoehtml();
        // [106]  p.Initialize(txtID & {8} , {9} ) 
        _p.initialize(_txtid + "-span", "span");
        // [107]  p.AddContent(txtText) 
        _p.addcontent(_txttext);
        // [108]  App.MaterialUseTheme(txtTheme,p) 
        self._app.materialusetheme(_txttheme, _p);
        // [109]  li.AddElement(p) 
        _li.addelement(_p);
        // [110]  Items.Add(li.HTML) 
        self._items.push(_li.html());
        // End Sub
    };

    // [114] Sub AddImage(itemID As String, imgURL As String, imgCircle As Boolean,imgHeight As String,imgWidth As String,topMargin As String) 
    this.addimage = function (_itemid, _imgurl, _imgcircle, _imgheight, _imgwidth, _topmargin) {
        if (self == null) self = this;
        var _skey;
        var _md;
        // [115]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [116]  Dim sKey As String = {1} 
        _skey = "" + self._id + "" + _itemid + "";
        // [117]  Dim md As UOEHTML 
        _md = new banano_uoebanano_uoehtml();
        // [118]  md.Initialize(sKey, {10} ) 
        _md.initialize(_skey, "li");
        // [119]  modUOE.MaterialAddImage(App,md,imgURL, {11} ,imgHeight,imgWidth,imgCircle,True,True,topMargin) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _md, _imgurl, "", _imgheight, _imgwidth, _imgcircle, true, true, _topmargin);
        // [120]  Items.Add(md.HTML) 
        self._items.push(_md.html());
        // End Sub
    };

    // [124] Sub AddDivider(themeName As String) As UOEList 
    this.adddivider = function (_themename) {
        if (self == null) self = this;
        var _div;
        // [125]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [126]  div.Initialize( {12} , {13} ) 
        _div.initialize("", "li");
        // [127]  div.AddClass( {14} ) 
        _div.addclass("divider");
        // [128]  App.MaterialUseTheme(themeName,div) 
        self._app.materialusetheme(_themename, _div);
        // [129]  Items.Add(div.HTML) 
        self._items.push(_div.html());
        // [130]  Return Me 
        return self;
        // End Sub
    };

    // [134] Sub AddClass(sClass As String) As UOEList 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [135]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [136]  Return Me 
        return self;
        // End Sub
    };

    // [140] Sub RemoveClass(sClass As String) As UOEList 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [141]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [142]  Return Me 
        return self;
        // End Sub
    };

    // [146] Sub AddAttribute(attr As String, value As String) As UOEList 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [147]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [148]  Return Me 
        return self;
        // End Sub
    };

    // [152] Sub RemoveAttribute(attr As String) As UOEList 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [153]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [154]  Return Me 
        return self;
        // End Sub
    };

    // [158] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [159]  Element.AddContentList(Items) 
        self._element.addcontentlist(self._items);
        // [160]  Element.ID = ID 
        self._element._id = self._id;
        // [161]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [162]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [168]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEListView  ===========================
function banano_uoebanano_uoelistview() {
    var self;
    this._id = '';

    this._theme = '';

    this._element = new banano_uoebanano_uoehtml();

    this._app = new banano_uoebanano_uoeapp();

    this._visibility = '';

    this._zdepth = '';

    this._enabled = false;

    this._hoverable = false;

    // [15] Sub AddStyleAttribute(attribute As String, value As String) As UOEListView 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [16]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [17]  Return Me 
        return self;
        // End Sub
    };

    // [21] Sub AddClass(sClass As String) As UOEListView 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [22]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [23]  Return Me 
        return self;
        // End Sub
    };

    // [27] Sub RemoveClass(sClass As String) As UOEListView 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [28]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [29]  Return Me 
        return self;
        // End Sub
    };

    // [33] Sub AddAttribute(attr As String, value As String) As UOEListView 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [34]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [35]  Return Me 
        return self;
        // End Sub
    };

    // [39] Sub RemoveAttribute(attr As String) As UOEListView 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [40]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [41]  Return Me 
        return self;
        // End Sub
    };

    // [45] Public Sub Initialize(thisApp As UOEApp, itemID As String, itemTheme As String) 
    this.initialize = function (_thisapp, _itemid, _itemtheme) {
        if (self == null) self = this;
        // [46]  App = thisApp 
        self._app = _thisapp;
        // [47]  ID = itemID.tolowercase 
        self._id = _itemid.toLowerCase();
        // [48]  Theme = itemTheme 
        self._theme = _itemtheme;
        // [49]  Enabled = True 
        self._enabled = true;
        // [50]  Element.Initialize(ID, {0} ) 
        self._element.initialize(self._id, "ul");
        // [51]  Element.AddClass( {1} ) 
        self._element.addclass("collapsible");
        // [52]  Element.AddAttribute( {2} ,App.EnumCollapsibleType.accordion) 
        self._element.addattribute("data-collapsible", self._app._enumcollapsibletype._accordion);
        // [53]  Visibility = {3} 
        self._visibility = "";
        // [54]  ZDepth = {4} 
        self._zdepth = "";
        // End Sub
    };

    // [58] Sub AddItem(itemID As String, itemIcon As String, itemText As String, itemBadge As String, badgeNew As Boolean, itemNavigateTo As String, itemTheme As String, iconTheme As String) 
    this.additem = function (_itemid, _itemicon, _itemtext, _itembadge, _badgenew, _itemnavigateto, _itemtheme, _icontheme) {
        if (self == null) self = this;
        var _div;
        var _li;
        // [60]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [62]  Dim div As UOEAnchor 
        _div = new banano_uoebanano_uoeanchor();
        // [63]  div.Initialize(App,itemID & {5} ) 
        _div.initialize(self._app, _itemid + "a");
        // [64]  div.element.MaterialCollapsibleHeader(True) 
        _div._element.materialcollapsibleheader(true);
        // [65]  modUOE.materialAddIcon(App,div.Element,itemIcon, {6} ,iconTheme,False,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, _div._element, _itemicon, "", _icontheme, false, false, false, false, false);
        // [66]  div.Element.AddContent(itemText) 
        _div._element.addcontent(_itemtext);
        // [67]  modUOE.MaterialAddBadge(App,div.Element,itemBadge,badgeNew,App.EnumVisibility.visible,True, {7} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _div._element, _itembadge, _badgenew, self._app._enumvisibility._visible, true, "", false);
        // [69]  div.WavesEffect = True 
        _div._waveseffect = true;
        // [70]  div.WavesType = App.EnumWavesType.Light 
        _div._wavestype = self._app._enumwavestype._light;
        // [71]  div.TextVisible = True 
        _div._textvisible = true;
        // [72]  div.Theme = itemTheme 
        _div._theme = _itemtheme;
        // [73]  div.href = itemNavigateTo 
        _div._href = _itemnavigateto;
        // [75]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [76]  li.Initialize(itemID, {11} ) 
        _li.initialize(_itemid, "li");
        // [77]  li.addcontent(div.tostring) 
        _li.addcontent(_div.tostring());
        // [78]  Element.AddElement(li) 
        self._element.addelement(_li);
        // End Sub
    };

    // [82] Sub AddContainer(itemID As String, cont As UOEContainer) 
    this.addcontainer = function (_itemid, _cont) {
        if (self == null) self = this;
        var _li;
        // [84]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [85]  li.Initialize(itemID, {12} ) 
        _li.initialize(_itemid, "li");
        // [86]  li.addcontent(cont.tostring) 
        _li.addcontent(_cont.tostring());
        // [87]  Element.AddElement(li) 
        self._element.addelement(_li);
        // End Sub
    };

    // [91] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [92]  Element.ID = ID 
        self._element._id = self._id;
        // [93]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [94]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [95]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [96]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [97]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [102]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEModal  ===========================
function banano_uoebanano_uoemodal() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._id = '';

    this._enabled = false;

    this._visibility = '';

    this._content = new banano_uoebanano_uoecontainer();

    this._dismissible = false;

    this._preventscrolling = false;

    this._fixedfooter = false;

    this._footer = new banano_uoebanano_uoecontainer();

    this._header = new banano_uoebanano_uoecontainer();

    this._isbottomsheet = false;

    this._startingtop = '';

    this._endingtop = '';

    this._theme = '';

    this._instance = '';

    this._fields = [];

    this._hidescrollbar = false;

    // [26] Public Sub Initialize(thisApp As UOEApp, mvarID As String, mTheme As String) 
    this.initialize = function (_thisapp, _mvarid, _mtheme) {
        if (self == null) self = this;
        // [27]  App = thisApp 
        self._app = _thisapp;
        // [28]  ID = mvarID.tolowercase 
        self._id = _mvarid.toLowerCase();
        // [29]  Element.Initialize(ID, {6} ) 
        self._element.initialize(self._id, "div");
        // [30]  Enabled = True 
        self._enabled = true;
        // [31]  Theme = mTheme 
        self._theme = _mtheme;
        // [32]  Header.Initialize(App,ID & {7} ,False, {8} ) 
        self._header.initialize(self._app, self._id + "header", false, "");
        // [33]  Content.Initialize(App,ID & {9} ,False, {10} ) 
        self._content.initialize(self._app, self._id + "content", false, "");
        // [34]  Content.addclass( {11} ) 
        self._content.addclass("modal-content");
        // [35]  Footer.Initialize(App,ID & {12} ,False, {13} ) 
        self._footer.initialize(self._app, self._id + "footer", false, "");
        // [36]  Footer.AddClass( {14} ) 
        self._footer.addclass("modal-footer");
        // [37]  preventScrolling = True 
        self._preventscrolling = true;
        // [38]  dismissible = False 
        self._dismissible = false;
        // [39]  fixedFooter = False 
        self._fixedfooter = false;
        // [40]  IsBottomSheet = False 
        self._isbottomsheet = false;
        // [41]  startingTop = {15} 
        self._startingtop = "4%";
        // [42]  endingTop = {16} 
        self._endingtop = "10%";
        // [43]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // [44]  Fields.Initialize 
        self._fields.length = 0;
        // [45]  Fields.clear 
        self._fields.length = 0;
        // [46]  HideScrollBar = True 
        self._hidescrollbar = true;
        // End Sub
    };

    // [50] Sub getCSS As String 
    this.getcss = function () {
        if (self == null) self = this;
        var _sel;
        var _cssmap;
        var _strcss;
        // [51]  Dim sel As String = {1} 
        _sel = "#" + self._id + "";
        // [52]  Dim cssmap As Map 
        _cssmap = {};
        // [53]  cssmap.Initialize 
        _cssmap = {};
        // [54]  cssmap.clear 
        _cssmap = {};
        // [55]  cssmap.Put( {17} , {18} ) 
        _cssmap["overflow"] = "hidden";
        // [56]  cssmap.Put( {19} , sel) 
        _cssmap["id"] = _sel;
        // [57]  Dim strcss As String = App.Map2Json(cssmap) 
        _strcss = self._app.map2json(_cssmap);
        // [58]  Return strcss 
        return _strcss;
        // End Sub
    };

    // [62] Sub AddClass(sClass As String) As UOEModal 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [63]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [64]  Return Me 
        return self;
        // End Sub
    };

    // [68] Sub RemoveClass(sClass As String) As UOEModal 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [69]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [70]  Return Me 
        return self;
        // End Sub
    };

    // [74] Sub AddAttribute(attr As String, value As String) As UOEModal 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [75]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [76]  Return Me 
        return self;
        // End Sub
    };

    // [80] Sub RemoveAttribute(attr As String) As UOEModal 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [81]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [82]  Return Me 
        return self;
        // End Sub
    };

    // [86] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [87]  Element.ID = ID 
        self._element._id = self._id;
        // [88]  Element.AddClass( {20} ) 
        self._element.addclass("modal");
        // [89]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [90]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [91]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [92]  Element.AddContent(Header.ToString) 
        self._element.addcontent(self._header.tostring());
        // [93]  Element.AddContent(Content.tostring) 
        self._element.addcontent(self._content.tostring());
        // [94]  Element.AddContent(Footer.tostring) 
        self._element.addcontent(self._footer.tostring());
        // [95]  If fixedFooter Then 
        if (self._fixedfooter) {
            // [96]  Element.AddClass( {21} ) 
            self._element.addclass("modal-fixed-footer");
            // [97]  End If 
        }
        // [98]  If IsBottomSheet Then 
        if (self._isbottomsheet) {
            // [99]  Element.AddClass( {22} ) 
            self._element.addclass("bottom-sheet");
            // [100]  End If 
        }
        // [101]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

    // [110] Sub getSettings() As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _ms;
        var _str;
        // [111]  Dim ms As Map 
        _ms = {};
        // [112]  ms.Initialize 
        _ms = {};
        // [113]  ms.clear 
        _ms = {};
        // [114]  ms.Put( {27} , ID) 
        _ms["id"] = self._id;
        // [115]  ms.Put( {28} , {29} ) 
        _ms["instance"] = "modal";
        // [116]  ms.Put( {30} , startingTop) 
        _ms["startingTop"] = self._startingtop;
        // [117]  ms.Put( {31} , endingTop) 
        _ms["endingTop"] = self._endingtop;
        // [118]  ms.Put( {32} , dismissible) 
        _ms["dismissible"] = self._dismissible;
        // [119]  ms.Put( {33} , preventScrolling) 
        _ms["preventScrolling"] = self._preventscrolling;
        // [120]  Dim str As String = App.Map2Json(ms) 
        _str = self._app.map2json(_ms);
        // [121]  Return str 
        return _str;
        // End Sub
    };

    // [125] Sub Open 
    this.open = function () {
        if (self == null) self = this;
        var _script;
        // [126]  Dim script As String = {3} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".open();";
        // [127]  BANano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [131] Sub Destroy 
    this.destroy = function () {
        if (self == null) self = this;
        var _script;
        // [132]  Dim script As String = {4} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".destroy();";
        // [133]  BANano.Eval(script) 
        eval(_script);
        // End Sub
    };

    // [137] Sub Close 
    this.close = function () {
        if (self == null) self = this;
        var _script;
        // [138]  Dim script As String = {5} 
        _script = "var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".close();";
        // [139]  BANano.Eval(script) 
        eval(_script);
        // End Sub
    };

}
// =========================== UOENavBar  ===========================
function banano_uoebanano_uoenavbar() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._visibility = '';

    this._nw = new banano_uoebanano_uoehtml();

    this._logo = new banano_uoebanano_uoehtml();

    this._leftmenu = new banano_uoebanano_uoehtml();

    this._rightmenu = new banano_uoebanano_uoehtml();

    this._leftmenuvisibility = '';

    this._rightmenuvisibility = '';

    this._logoposition = '';

    this._pcol = new banano_uoebanano_uoehtml();

    this._fixed = false;

    this._dropdowns = {};

    this._content = new banano_uoebanano_uoecontainer();

    this._hascontents = false;

    this._drawer = new banano_uoebanano_uoesidebar();

    this._showmenuonlarge = false;

    this._hastabs = false;

    this._tabs = new banano_uoebanano_uoehtml();

    // [29] Sub AddTab(tabID As String, tabText As String, tabDisabled As Boolean, tabCont As UOEContainer) 
    this.addtab = function (_tabid, _tabtext, _tabdisabled, _tabcont) {
        if (self == null) self = this;
        var _li;
        var _a;
        var _dv;
        // [30]  hasTabs = True 
        self._hastabs = true;
        // [31]  hasContents = True 
        self._hascontents = true;
        // [32]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [33]  li.Initialize(tabID & {21} , {22} ) 
        _li.initialize(_tabid + "li", "li");
        // [34]  li.AddClass( {23} ) 
        _li.addclass("tab");
        // [35]  li.AddClassOnCondition(tabDisabled, {24} ) 
        _li.addclassoncondition(_tabdisabled, "disabled");
        // [36]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [37]  a.Initialize(tabID, {25} ) 
        _a.initialize(_tabid, "a");
        // [38]  a.sethref( {26} & tabID & {27} ) 
        _a.sethref("#" + _tabid + "dv");
        // [39]  a.AddContent(tabText) 
        _a.addcontent(_tabtext);
        // [40]  li.AddElement(a) 
        _li.addelement(_a);
        // [42]  tabs.AddElement(li) 
        self._tabs.addelement(_li);
        // [45]  Dim dv As UOEHTML 
        _dv = new banano_uoebanano_uoehtml();
        // [46]  dv.Initialize(tabID & {28} , {29} ) 
        _dv.initialize(_tabid + "dv", "div");
        // [47]  If tabCont <> Null Then 
        if (_tabcont != null) {
            // [48]  dv.AddContent(tabCont.tostring) 
            _dv.addcontent(_tabcont.tostring());
            // [49]  End If 
        }
        // [51]  Content.AddContent(dv.html) 
        self._content.addcontent(_dv.html());
        // End Sub
    };

    // [55] Public Sub Initialize(thisApp As UOEApp,sID As String,sTitle As String, sTitlePosition As String, bFixed As Boolean, bFixDrawer As Boolean, sTheme As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _stitleposition, _bfixed, _bfixdrawer, _stheme) {
        if (self == null) self = this;
        // [56]  App = thisApp 
        self._app = _thisapp;
        // [57]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [58]  Theme = sTheme 
        self._theme = _stheme;
        // [59]  Element.Initialize(ID, {30} ) 
        self._element.initialize(self._id, "nav");
        // [60]  Element.SetROLE( {31} ) 
        self._element.setrole("navigation");
        // [61]  nw.Initialize( {32} , {33} ) 
        self._nw.initialize("navwrapper", "div");
        // [62]  nw.AddClass( {34} ) 
        self._nw.addclass("nav-wrapper");
        // [63]  logo.Initialize( {35} , {36} ) 
        self._logo.initialize("brandlogo", "a");
        // [64]  logo.AddClass( {37} ) 
        self._logo.addclass("brand-logo");
        // [65]  logo.AddContent(sTitle) 
        self._logo.addcontent(_stitle);
        // [66]  logo.MaterialVisibility(App.EnumVisibility.showonmediumandup) 
        self._logo.materialvisibility(self._app._enumvisibility._showonmediumandup);
        // [67]  LeftMenu.Initialize(ID & {38} , {39} ) 
        self._leftmenu.initialize(self._id + "leftmenu", "ul");
        // [68]  RightMenu.Initialize(ID & {40} , {41} ) 
        self._rightmenu.initialize(self._id + "rightmenu", "ul");
        // [69]  RightMenu.AddClass( {42} ) 
        self._rightmenu.addclass("right");
        // [70]  pcol.Initialize( {43} & ID, {44} ) 
        self._pcol.initialize("pcol" + self._id, "div");
        // [71]  pcol.AddClass( {45} ) 
        self._pcol.addclass("col");
        // [72]  pcol.AddClass( {46} ) 
        self._pcol.addclass("s12");
        // [73]  LogoPosition = sTitlePosition 
        self._logoposition = _stitleposition;
        // [74]  LeftMenuVisibility = App.EnumVisibility.hideonmedanddown 
        self._leftmenuvisibility = self._app._enumvisibility._hideonmedanddown;
        // [75]  RightMenuVisibility = App.EnumVisibility.hideonmedanddown 
        self._rightmenuvisibility = self._app._enumvisibility._hideonmedanddown;
        // [76]  Fixed = bFixed 
        self._fixed = _bfixed;
        // [77]  dropdowns.Initialize 
        self._dropdowns = {};
        // [78]  dropdowns.clear 
        self._dropdowns = {};
        // [79]  Content.Initialize(App, {47} & ID,False, {48} ) 
        self._content.initialize(self._app, "navcontent" + self._id, false, "");
        // [80]  Content.AddClass( {49} ) 
        self._content.addclass("nav-content");
        // [81]  hasContents = False 
        self._hascontents = false;
        // [82]  hasTabs = False 
        self._hastabs = false;
        // [83]  Drawer.Initialize(App,ID & {50} ,bFixDrawer,False, {51} ) 
        self._drawer.initialize(self._app, self._id + "drawer", _bfixdrawer, false, "");
        // [84]  ShowMenuOnLarge = Not(bFixDrawer) 
        self._showmenuonlarge = !(_bfixdrawer);
        // [85]  tabs.Initialize( {52} & ID, {53} ) 
        self._tabs.initialize("navtabs" + self._id, "ul");
        // [86]  tabs.AddClass( {54} ) 
        self._tabs.addclass("tabs");
        // [87]  tabs.AddClass( {55} ) 
        self._tabs.addclass("tabs-transparent");
        // End Sub
    };

    // [91] Sub AddSubTitle(sTitle As String) 
    this.addsubtitle = function (_stitle) {
        if (self == null) self = this;
        var _el;
        // [92]  Dim el As UOEHTML 
        _el = new banano_uoebanano_uoehtml();
        // [93]  el.Initialize( {56} , {57} ) 
        _el.initialize("", "span");
        // [94]  el.AddContent(sTitle) 
        _el.addcontent(_stitle);
        // [95]  el.AddClass( {58} ) 
        _el.addclass("nav-title");
        // [96]  Content.AddContent(el.HTML) 
        self._content.addcontent(_el.html());
        // End Sub
    };

    // [100] Sub AddFAB(sid As String,iconName As String, bSize As String, href As String, bPulse As Boolean, bVisibility As String, btheme As String) 
    this.addfab = function (_sid, _iconname, _bsize, _href, _bpulse, _bvisibility, _btheme) {
        if (self == null) self = this;
        var _btn;
        // [101]  sid = sid.tolowercase 
        _sid = _sid.toLowerCase();
        // [102]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [103]  btn.Initialize(App, sid, {59} ,btheme) 
        _btn.initialize(self._app, _sid, "", _btheme);
        // [104]  btn.setbuttontype(App.EnumButtonType.halfwayfab) 
        _btn.setbuttontype(self._app._enumbuttontype._halfwayfab);
        // [105]  btn.AddIcon(iconName, {60} , {61} ,False,False) 
        _btn.addicon(_iconname, "", "", false, false);
        // [106]  btn.Size = bSize 
        _btn._size = _bsize;
        // [107]  btn.HREF = href 
        _btn._href = _href;
        // [108]  btn.Visibility = bVisibility 
        _btn._visibility = _bvisibility;
        // [109]  btn.Pulsing = bPulse 
        _btn._pulsing = _bpulse;
        // [111]  Content.AddContent(btn.tostring) 
        self._content.addcontent(_btn.tostring());
        // [112]  hasContents = True 
        self._hascontents = true;
        // [113]  App.AddEvent(sid, {62} ) 
        self._app.addevent(_sid, "click");
        // End Sub
    };

    // [117] Sub AddDividerR(themeName As String) 
    this.adddividerr = function (_themename) {
        if (self == null) self = this;
        var _div;
        // [118]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [119]  div.Initialize( {63} , {64} ) 
        _div.initialize("", "li");
        // [120]  div.AddClass( {65} ) 
        _div.addclass("divider");
        // [121]  App.MaterialUseTheme(themeName,div) 
        self._app.materialusetheme(_themename, _div);
        // [122]  RightMenu.addcontentline(div.HTML) 
        self._rightmenu.addcontentline(_div.html());
        // End Sub
    };

    // [126] Sub AddDividerL(themeName As String) 
    this.adddividerl = function (_themename) {
        if (self == null) self = this;
        var _div;
        // [127]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [128]  div.Initialize( {66} , {67} ) 
        _div.initialize("", "li");
        // [129]  div.AddClass( {68} ) 
        _div.addclass("divider");
        // [130]  App.MaterialUseTheme(themeName,div) 
        self._app.materialusetheme(_themename, _div);
        // [131]  LeftMenu.addcontentline(div.HTML) 
        self._leftmenu.addcontentline(_div.html());
        // End Sub
    };

    // [151] private Sub BuildDropDownStructures 
    this.builddropdownstructures = function () {
        if (self == null) self = this;
        var _strkey;
        var _ditems;
        var _li;
        var _items;
        // [152]  For Each strKey As String In dropdowns.Keys 
        var _strkeyKeys = Object.keys(self._dropdowns);
        for (var _strkeyindex = 0; _strkeyindex < _strkeyKeys.length; _strkeyindex++) {
            _strkey = _strkeyKeys[_strkeyindex];
            // [153]  Dim ditems As String = strKey & {69} 
            _ditems = _strkey + "items";
            // [154]  Dim li As UOEHTML 
            _li = new banano_uoebanano_uoehtml();
            // [155]  li.Initialize(ditems, {70} ) 
            _li.initialize(_ditems, "ul");
            // [156]  li.AddClass( {71} ) 
            _li.addclass("dropdown-content");
            // [157]  Dim items As List = dropdowns.Get(strKey) 
            _items = self._dropdowns[_strkey];
            // [158]  li.AddContentList(items) 
            _li.addcontentlist(_items);
            // [159]  Element.addcontent(li.HTML) 
            self._element.addcontent(_li.html());
            // [160]  Next 
        }
        // End Sub
    };

    // [164] Sub AddItemLeft(iID As String, href As String,iText As String,iTheme As String) 
    this.additemleft = function (_iid, _href, _itext, _itheme) {
        if (self == null) self = this;
        // [165]  AddItem(iID,href,iText, {72} ,App.EnumMenuPos.Left,False,iTheme) 
        self.additem(_iid, _href, _itext, "", self._app._enummenupos._left, false, _itheme);
        // End Sub
    };

    // [169] Sub AddItemRight(iID As String, href As String,iText As String,iTheme As String) 
    this.additemright = function (_iid, _href, _itext, _itheme) {
        if (self == null) self = this;
        // [170]  AddItem(iID,href,iText, {73} ,App.EnumMenuPos.Right,False,iTheme) 
        self.additem(_iid, _href, _itext, "", self._app._enummenupos._right, false, _itheme);
        // End Sub
    };

    // [174] Sub AddItem(iID As String,ihref As String,iText As String,iVisibility As String,iLeftOrRight As String, bActive As Boolean, iTheme As String) 
    this.additem = function (_iid, _ihref, _itext, _ivisibility, _ileftorright, _bactive, _itheme) {
        if (self == null) self = this;
        var _skey;
        var _item;
        var _a;
        // [175]  Dim sKey As String = {4} 
        _skey = "" + self._id + "" + _iid + "";
        // [176]  Dim item As UOEHTML 
        _item = new banano_uoebanano_uoehtml();
        // [177]  item.Initialize(sKey & {74} , {75} ) 
        _item.initialize(_skey + "li", "li");
        // [178]  item.AddClassOnCondition(bActive, {76} ) 
        _item.addclassoncondition(_bactive, "active");
        // [180]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [181]  a.Initialize(iID, {77} ) 
        _a.initialize(_iid, "a");
        // [182]  a.SetHREF(ihref) 
        _a.sethref(_ihref);
        // [183]  a.AddContent(iText) 
        _a.addcontent(_itext);
        // [184]  a.MaterialVisibility(iVisibility) 
        _a.materialvisibility(_ivisibility);
        // [185]  item.AddElement(a) 
        _item.addelement(_a);
        // [186]  Select Case iLeftOrRight 
        switch ("" + _ileftorright) {
            // [187]  Case {78} 
            case "" + "left":
                // [188]  LeftMenu.AddElementLine(item) 
                self._leftmenu.addelementline(_item);
                // [189]  Case {79} 
                break;
            case "" + "right":
                // [190]  RightMenu.AddElementLine(item) 
                self._rightmenu.addelementline(_item);
                // [191]  End Select 
                break;
        }
        // [192]  App.AddEvent(iID, {80} ) 
        self._app.addevent(_iid, "click");
        // End Sub
    };

    // [196] Sub AddDropDownItem(pID As String,iID As String,ihref As String,iText As String,iVisibility As String, iTheme As String) 
    this.adddropdownitem = function (_pid, _iid, _ihref, _itext, _ivisibility, _itheme) {
        if (self == null) self = this;
        var _pkey;
        var _skey;
        var _item;
        var _a;
        var _items;
        var _scode;
        // [197]  If ihref = {81} Then ihref = {82} 
        if (_ihref == "") {
            _ihref = "#!";
        }
        // [198]  Dim pKey As String = {5} 
        _pkey = "" + self._id + "" + _pid + "";
        // [199]  If dropdowns.ContainsKey(pKey) = False Then Return 
        if ((_pkey in self._dropdowns) == false) {
            return;
        }
        // [200]  Dim sKey As String = {6} 
        _skey = "" + _pkey + "" + _iid + "";
        // [201]  Dim item As UOEHTML 
        _item = new banano_uoebanano_uoehtml();
        // [202]  item.Initialize(sKey & {83} , {84} ) 
        _item.initialize(_skey + "li", "li");
        // [204]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [205]  a.Initialize(iID, {85} ) 
        _a.initialize(_iid, "a");
        // [206]  a.SetHREF(ihref) 
        _a.sethref(_ihref);
        // [207]  a.AddContent(iText) 
        _a.addcontent(_itext);
        // [208]  a.MaterialVisibility(iVisibility) 
        _a.materialvisibility(_ivisibility);
        // [209]  item.AddElement(a) 
        _item.addelement(_a);
        // [210]  Dim items As List = dropdowns.Get(pKey) 
        _items = self._dropdowns[_pkey];
        // [211]  Dim scode As String = item.tostring 
        _scode = _item.tostring();
        // [212]  scode = scode.Replace(CRLF, {86} ) 
        _scode = _scode.split("\n").join("");
        // [213]  items.Add(scode) 
        _items.push(_scode);
        // [214]  dropdowns.Put(pKey,items) 
        self._dropdowns[_pkey] = _items;
        // [215]  App.AddEvent(iID, {87} ) 
        self._app.addevent(_iid, "click");
        // End Sub
    };

    // [219] Sub AddDropDownItem1(parentID As String, itemID As String, itemIcon As String, itemText As String, itemNavigateTo As String, itemActive As Boolean, bhasDivider As Boolean, itemTheme As String) 
    this.adddropdownitem1 = function (_parentid, _itemid, _itemicon, _itemtext, _itemnavigateto, _itemactive, _bhasdivider, _itemtheme) {
        if (self == null) self = this;
        var _pkey;
        var _dpi;
        var _items;
        var _scode;
        // [220]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [221]  parentID = parentID.tolowercase 
        _parentid = _parentid.toLowerCase();
        // [222]  If itemNavigateTo = {88} Then itemNavigateTo = {89} 
        if (_itemnavigateto == "") {
            _itemnavigateto = "#!";
        }
        // [223]  Dim pKey As String = {7} 
        _pkey = "" + self._id + "" + _parentid + "";
        // [224]  If dropdowns.ContainsKey(pKey) = False Then Return 
        if ((_pkey in self._dropdowns) == false) {
            return;
        }
        // [225]  itemIcon= {90} 
        _itemicon = "";
        // [226]  Dim dpi As UOEDropDownItem 
        _dpi = new banano_uoebanano_uoedropdownitem();
        // [227]  dpi.Initialize(App,pKey,itemID,itemIcon,itemText,itemNavigateTo,itemActive,itemTheme) 
        _dpi.initialize(self._app, _pkey, _itemid, _itemicon, _itemtext, _itemnavigateto, _itemactive, _itemtheme);
        // [228]  dpi.li.MaterialAddDividerOnCondition(bhasDivider,App.EnumVisibility.visible,itemTheme) 
        _dpi._li.materialadddivideroncondition(_bhasdivider, self._app._enumvisibility._visible, _itemtheme);
        // [230]  Dim items As List = dropdowns.Get(pKey) 
        _items = self._dropdowns[_pkey];
        // [231]  Dim scode As String = dpi.tostring 
        _scode = _dpi.tostring();
        // [232]  scode = scode.Replace(CRLF, {91} ) 
        _scode = _scode.split("\n").join("");
        // [233]  items.Add(scode) 
        _items.push(_scode);
        // [234]  dropdowns.Put(pKey,items) 
        self._dropdowns[_pkey] = _items;
        // [235]  App.AddEvent(itemID, {92} ) 
        self._app.addevent(_itemid, "click");
        // [236]  App.AddEvent(pkey, {93} ) 
        self._app.addevent(_pkey, "click");
        // End Sub
    };

    // [240] public Sub AddDropDownDivider(pID As String) 
    this.adddropdowndivider = function (_pid) {
        if (self == null) self = this;
        var _pkey;
        var _md;
        var _items;
        var _scode;
        // [241]  Dim pKey As String = {8} 
        _pkey = "" + self._id + "" + _pid + "";
        // [242]  If dropdowns.ContainsKey(pKey) = False Then Return 
        if ((_pkey in self._dropdowns) == false) {
            return;
        }
        // [243]  Dim md As UOEHTML 
        _md = new banano_uoebanano_uoehtml();
        // [244]  md.Initialize( {94} , {95} ) 
        _md.initialize("", "li");
        // [245]  md.AddClass( {96} ) 
        _md.addclass("divider");
        // [246]  Dim items As List = dropdowns.Get(pKey) 
        _items = self._dropdowns[_pkey];
        // [247]  Dim scode As String = md.tostring 
        _scode = _md.tostring();
        // [248]  scode = scode.Replace(CRLF, {97} ) 
        _scode = _scode.split("\n").join("");
        // [249]  items.Add(scode) 
        _items.push(_scode);
        // [250]  dropdowns.Put(pKey,items) 
        self._dropdowns[_pkey] = _items;
        // End Sub
    };

    // [254] Sub AddImageL(itemID As String, imgURL As String, imgCircle As Boolean,imgHeight As String,imgWidth As String, topMargin As String) 
    this.addimagel = function (_itemid, _imgurl, _imgcircle, _imgheight, _imgwidth, _topmargin) {
        if (self == null) self = this;
        var _skey;
        var _md;
        // [255]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [256]  Dim sKey As String = {9} 
        _skey = "" + self._id + "" + _itemid + "";
        // [257]  Dim md As UOEHTML 
        _md = new banano_uoebanano_uoehtml();
        // [258]  md.Initialize(sKey, {98} ) 
        _md.initialize(_skey, "li");
        // [259]  modUOE.MaterialAddImage(App,md,imgURL, {99} ,imgHeight,imgWidth,imgCircle,True,True,topMargin) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _md, _imgurl, "", _imgheight, _imgwidth, _imgcircle, true, true, _topmargin);
        // [260]  LeftMenu.addcontentline(md.HTML) 
        self._leftmenu.addcontentline(_md.html());
        // [261]  App.AddEvent(sKey, {100} ) 
        self._app.addevent(_skey, "click");
        // [262]  App.AddEvent(itemID, {101} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [266] Sub AddDropDownAvatar(itemID As String, imgURL As String, imgCircle As Boolean, itemText As String, itemPos As String, itemVisibility As String, bConstrainWidth As Boolean, itemTheme As String) 
    this.adddropdownavatar = function (_itemid, _imgurl, _imgcircle, _itemtext, _itempos, _itemvisibility, _bconstrainwidth, _itemtheme) {
        if (self == null) self = this;
        var _skey;
        var _dp;
        var _drpitems;
        // [267]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [268]  Dim sKey As String = {10} 
        _skey = "" + self._id + "" + _itemid + "";
        // [270]  Dim dp As UOEDropDown 
        _dp = new banano_uoebanano_uoedropdown();
        // [271]  dp.Initialize(App,sKey,itemText,itemVisibility,False,bConstrainWidth,itemTheme) 
        _dp.initialize(self._app, _skey, _itemtext, _itemvisibility, false, _bconstrainwidth, _itemtheme);
        // [272]  modUOE.MaterialAddImage(App,dp.a,imgURL, {102} ,App.ItemHeight,App.ItemHeight,imgCircle,True,True, {103} ) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _dp._a, _imgurl, "", self._app._itemheight, self._app._itemheight, _imgcircle, true, true, "5px");
        // [273]  If itemPos.tolowercase = {104} Then 
        if (_itempos.toLowerCase() == "right") {
            // [274]  RightMenu.addcontentline(dp.tostring) 
            self._rightmenu.addcontentline(_dp.tostring());
            // [275]  Else 
        } else {
            // [276]  LeftMenu.addcontentline(dp.tostring) 
            self._leftmenu.addcontentline(_dp.tostring());
            // [277]  End If 
        }
        // [279]  Dim drpItems As List 
        _drpitems = [];
        // [280]  drpItems.Initialize 
        _drpitems.length = 0;
        // [281]  drpItems.clear 
        _drpitems.length = 0;
        // [282]  dropdowns.Put(sKey,drpItems) 
        self._dropdowns[_skey] = _drpitems;
        // [283]  App.AddEvent(sKey, {105} ) 
        self._app.addevent(_skey, "click");
        // [284]  App.AddEvent(itemID, {106} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [288] Sub AddItemBadge(itemID As String, iconName As String, iconAlign As String, itemText As String, href As String, textVisible As Boolean, itemActive As Boolean, badgeText As String, badgeNew As Boolean, itemVisibility As String, itemPos As String, itemTheme As String, badgeTheme As String) 
    this.additembadge = function (_itemid, _iconname, _iconalign, _itemtext, _href, _textvisible, _itemactive, _badgetext, _badgenew, _itemvisibility, _itempos, _itemtheme, _badgetheme) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _ai;
        // [289]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [290]  Dim sKey As String = {11} 
        _skey = "" + self._id + "" + _itemid + "";
        // [291]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [292]  li.Initialize(sKey & {107} , {108} ) 
        _li.initialize(_skey + "li", "li");
        // [293]  li.MaterialVisibility(itemVisibility) 
        _li.materialvisibility(_itemvisibility);
        // [294]  If itemActive = True Then li.AddClass( {109} ) 
        if (_itemactive == true) {
            _li.addclass("active");
        }
        // [296]  Dim ai As UOEAnchorIcon 
        _ai = new banano_uoebanano_uoeanchoricon();
        // [297]  ai.Initialize(App,itemID,iconName,iconAlign,False,itemText,href,textVisible,itemTheme, {110} ) 
        _ai.initialize(self._app, _itemid, _iconname, _iconalign, false, _itemtext, _href, _textvisible, _itemtheme, "");
        // [298]  modUOE.MaterialAddBadge(App,ai.a,badgeText,badgeNew,App.EnumVisibility.visible,True,badgeTheme,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _ai._a, _badgetext, _badgenew, self._app._enumvisibility._visible, true, _badgetheme, false);
        // [299]  li.AddContent(ai.tostring) 
        _li.addcontent(_ai.tostring());
        // [300]  If itemPos.tolowercase = {111} Then 
        if (_itempos.toLowerCase() == "right") {
            // [301]  RightMenu.addcontentline(li.HTML) 
            self._rightmenu.addcontentline(_li.html());
            // [302]  Else 
        } else {
            // [303]  LeftMenu.addcontentline(li.HTML) 
            self._leftmenu.addcontentline(_li.html());
            // [304]  End If 
        }
        // [305]  App.AddEvent(sKey, {112} ) 
        self._app.addevent(_skey, "click");
        // [306]  App.AddEvent(itemID, {113} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [310] Sub AddIcon(itemID As String, iconName As String, itemNavigateTo As String, itemActive As Boolean, itemPos As String, itemVisibility As String, itemTheme As String) 
    this.addicon = function (_itemid, _iconname, _itemnavigateto, _itemactive, _itempos, _itemvisibility, _itemtheme) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _ai;
        // [312]  Dim sKey As String = {12} 
        _skey = "" + self._id + "" + _itemid + "";
        // [313]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [314]  li.Initialize(sKey & {114} , {115} ) 
        _li.initialize(_skey + "li", "li");
        // [315]  li.MaterialVisibility(itemVisibility) 
        _li.materialvisibility(_itemvisibility);
        // [316]  If itemActive = True Then li.AddClass( {116} ) 
        if (_itemactive == true) {
            _li.addclass("active");
        }
        // [318]  Dim ai As UOEAnchorIcon 
        _ai = new banano_uoebanano_uoeanchoricon();
        // [319]  ai.Initialize(App,itemID,iconName, {117} ,False, {118} ,itemNavigateTo,False,itemTheme, {119} ) 
        _ai.initialize(self._app, _itemid, _iconname, "", false, "", _itemnavigateto, false, _itemtheme, "");
        // [320]  li.AddContent(ai.tostring) 
        _li.addcontent(_ai.tostring());
        // [321]  If itemPos.tolowercase = {120} Then 
        if (_itempos.toLowerCase() == "right") {
            // [322]  RightMenu.addcontentline(li.HTML) 
            self._rightmenu.addcontentline(_li.html());
            // [323]  Else 
        } else {
            // [324]  LeftMenu.addcontentline(li.HTML) 
            self._leftmenu.addcontentline(_li.html());
            // [325]  End If 
        }
        // [326]  App.AddEvent(itemID, {121} ) 
        self._app.addevent(_itemid, "click");
        // End Sub
    };

    // [330] Sub AddIconBadge(itemID As String, iconName As String, itemNavigateTo As String, itemActive As Boolean, itemPos As String, itemVisibility As String, itemTheme As String, sBadge As String) 
    this.addiconbadge = function (_itemid, _iconname, _itemnavigateto, _itemactive, _itempos, _itemvisibility, _itemtheme, _sbadge) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _ai;
        // [332]  Dim sKey As String = {13} 
        _skey = "" + self._id + "" + _itemid + "";
        // [333]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [334]  li.Initialize(sKey & {122} , {123} ) 
        _li.initialize(_skey + "li", "li");
        // [335]  li.MaterialVisibility(itemVisibility) 
        _li.materialvisibility(_itemvisibility);
        // [336]  If itemActive = True Then 
        if (_itemactive == true) {
            // [337]  li.AddClass( {124} ) 
            _li.addclass("active");
            // [338]  End If 
        }
        // [340]  Dim ai As UOEAnchorIcon 
        _ai = new banano_uoebanano_uoeanchoricon();
        // [341]  ai.Initialize(App,itemID,iconName, {125} ,False, {126} ,itemNavigateTo,False,itemTheme, {127} ) 
        _ai.initialize(self._app, _itemid, _iconname, "", false, "", _itemnavigateto, false, _itemtheme, "");
        // [342]  modUOE.MaterialAddBadge(App,ai.a,sBadge,False,App.EnumVisibility.visible,False, {128} ,True) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _ai._a, _sbadge, false, self._app._enumvisibility._visible, false, "", true);
        // [343]  li.AddContent(ai.tostring) 
        _li.addcontent(_ai.tostring());
        // [344]  If itemPos.tolowercase = {129} Then 
        if (_itempos.toLowerCase() == "right") {
            // [345]  RightMenu.addcontentline(li.HTML) 
            self._rightmenu.addcontentline(_li.html());
            // [346]  Else 
        } else {
            // [347]  LeftMenu.addcontentline(li.HTML) 
            self._leftmenu.addcontentline(_li.html());
            // [348]  End If 
        }
        // [349]  App.AddEvent(itemID, {130} ) 
        self._app.addevent(_itemid, "click");
        // [350]  App.AddEvent(sKey, {131} ) 
        self._app.addevent(_skey, "click");
        // End Sub
    };

    // [355] Sub AddAvatar(itemID As String, itemImageURL As String, bCircle As Boolean, itemText As String, itemNavigateTo As String, textVisible As Boolean, itemPos As String, itemVisibility As String, itemTheme As String) 
    this.addavatar = function (_itemid, _itemimageurl, _bcircle, _itemtext, _itemnavigateto, _textvisible, _itempos, _itemvisibility, _itemtheme) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _a;
        var _st;
        // [356]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [358]  Dim sKey As String = {14} 
        _skey = "" + self._id + "" + _itemid + "";
        // [359]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [360]  li.Initialize(sKey & {132} , {133} ) 
        _li.initialize(_skey + "li", "li");
        // [365]  Dim a As UOEAnchorIcon 
        _a = new banano_uoebanano_uoeanchoricon();
        // [366]  a.Initialize(App,itemID, {135} , {136} ,False, {137} ,itemNavigateTo,textVisible,itemTheme, {138} ) 
        _a.initialize(self._app, _itemid, "", "", false, "", _itemnavigateto, _textvisible, _itemtheme, "");
        // [367]  modUOE.Materialaddimage(App,a.a,itemImageURL, {139} ,App.itemheight,App.itemheight,bCircle,True,True,App.ImageTopMargin) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _a._a, _itemimageurl, "", self._app._itemheight, self._app._itemheight, _bcircle, true, true, self._app._imagetopmargin);
        // [369]  Dim st As UOESpan 
        _st = new banano_uoebanano_uoespan();
        // [370]  st.Initialize(App,itemID & {140} ,itemText,True,App.EnumVisibility.visible,itemTheme) 
        _st.initialize(self._app, _itemid + "st", _itemtext, true, self._app._enumvisibility._visible, _itemtheme);
        // [371]  a.Text = st.tostring 
        _a._text = _st.tostring();
        // [372]  modUOE.MaterialaddBadge(App,a.a, {141} ,False,App.EnumVisibility.hide,True, {142} ,False) 
        _banano_uoebanano_moduoe.materialaddbadge(self._app, _a._a, "", false, self._app._enumvisibility._hide, true, "", false);
        // [373]  li.MaterialVisibility(itemVisibility) 
        _li.materialvisibility(_itemvisibility);
        // [376]  li.AddContent(a.tostring) 
        _li.addcontent(_a.tostring());
        // [377]  If itemPos.tolowercase = {143} Then 
        if (_itempos.toLowerCase() == "right") {
            // [378]  RightMenu.addcontentline(li.HTML) 
            self._rightmenu.addcontentline(_li.html());
            // [379]  Else 
        } else {
            // [380]  LeftMenu.addcontentline(li.HTML) 
            self._leftmenu.addcontentline(_li.html());
            // [381]  End If 
        }
        // [382]  App.AddEvent(itemID, {144} ) 
        self._app.addevent(_itemid, "click");
        // [383]  App.AddEvent(sKey, {145} ) 
        self._app.addevent(_skey, "click");
        // End Sub
    };

    // [387] Sub AddButton(btnID As String, btnText As String, btnIconName As String, btnIconAlign As String, btnNavigateTo As String, btnSize As String, btnVisibility As String, btnTheme As String, iconTheme As String, btnPos As String) 
    this.addbutton = function (_btnid, _btntext, _btniconname, _btniconalign, _btnnavigateto, _btnsize, _btnvisibility, _btntheme, _icontheme, _btnpos) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _btn;
        // [388]  btnID = btnID.tolowercase 
        _btnid = _btnid.toLowerCase();
        // [389]  Dim sKey As String = {16} 
        _skey = "" + self._id + "" + _btnid + "";
        // [391]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [392]  li.Initialize(sKey & {146} , {147} ) 
        _li.initialize(_skey + "li", "li");
        // [396]  Dim btn As UOEButton 
        _btn = new banano_uoebanano_uoebutton();
        // [397]  btn.Initialize(App,btnID,btnText,btnTheme) 
        _btn.initialize(self._app, _btnid, _btntext, _btntheme);
        // [398]  btn.Visibility = btnVisibility 
        _btn._visibility = _btnvisibility;
        // [399]  btn.HREF = btnNavigateTo 
        _btn._href = _btnnavigateto;
        // [400]  btn.SetButtonType(App.EnumButtonType.raised) 
        _btn.setbuttontype(self._app._enumbuttontype._raised);
        // [401]  btn.AddIcon(btnIconName,btnIconAlign,iconTheme,False,False) 
        _btn.addicon(_btniconname, _btniconalign, _icontheme, false, false);
        // [402]  btn.Size = btnSize 
        _btn._size = _btnsize;
        // [404]  li.AddContent(btn.tostring) 
        _li.addcontent(_btn.tostring());
        // [405]  If btnPos.tolowercase = {149} Then 
        if (_btnpos.toLowerCase() == "right") {
            // [406]  RightMenu.addcontentline(li.HTML) 
            self._rightmenu.addcontentline(_li.html());
            // [407]  Else 
        } else {
            // [408]  LeftMenu.addcontentline(li.HTML) 
            self._leftmenu.addcontentline(_li.html());
            // [409]  End If 
        }
        // [410]  App.AddEvent(btnID, {150} ) 
        self._app.addevent(_btnid, "click");
        // [411]  App.AddEvent(sKey, {151} ) 
        self._app.addevent(_skey, "click");
        // End Sub
    };

    // [416] Sub AddDropDown(iID As String,iText As String,iVisibility As String,iLeftOrRight As String, bHover As Boolean, bCoverTrigger As Boolean, closeOnClick As Boolean,constrainWidth As Boolean,iTheme As String) 
    this.adddropdown = function (_iid, _itext, _ivisibility, _ileftorright, _bhover, _bcovertrigger, _closeonclick, _constrainwidth, _itheme) {
        if (self == null) self = this;
        var _skey;
        var _li;
        var _a;
        var _i;
        var _items;
        // [417]  Dim sKey As String = {18} 
        _skey = "" + self._id + "" + _iid + "";
        // [418]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [419]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [420]  Dim i As UOEHTML 
        _i = new banano_uoebanano_uoehtml();
        // [422]  li.Initialize(sKey & {152} , {153} ) 
        _li.initialize(_skey + "li", "li");
        // [424]  a.Initialize(iID, {154} ) 
        _a.initialize(_iid, "a");
        // [425]  a.addattribute( {155} ,sKey & {156} ) 
        _a.addattribute("data-target", _skey + "items");
        // [426]  a.AddContent(iText) 
        _a.addcontent(_itext);
        // [427]  a.AddClass( {157} ) 
        _a.addclass("dropdown-trigger");
        // [429]  i.Initialize( {158} , {159} ) 
        _i.initialize("", "i");
        // [430]  i.AddClass( {160} ) 
        _i.addclass("material-icons");
        // [431]  i.AddClass( {161} ) 
        _i.addclass("right");
        // [432]  i.AddContent( {162} ) 
        _i.addcontent("keyboard_arrow_right");
        // [433]  a.AddElement(i) 
        _a.addelement(_i);
        // [434]  li.AddElement(a) 
        _li.addelement(_a);
        // [435]  Dim items As List 
        _items = [];
        // [436]  items.Initialize 
        _items.length = 0;
        // [437]  items.clear 
        _items.length = 0;
        // [438]  dropdowns.Put(sKey,items) 
        self._dropdowns[_skey] = _items;
        // [439]  Select Case iLeftOrRight 
        switch ("" + _ileftorright) {
            // [440]  Case {163} 
            case "" + "left":
                // [441]  LeftMenu.AddElementline(li) 
                self._leftmenu.addelementline(_li);
                // [442]  Case {164} 
                break;
            case "" + "right":
                // [443]  RightMenu.AddElementline(li) 
                self._rightmenu.addelementline(_li);
                // [444]  End Select 
                break;
        }
        // End Sub
    };

    // [464] Sub AddClass(sClass As String) 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [465]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // End Sub
    };

    // [469] Sub RemoveClass(sClass As String) 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [470]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // End Sub
    };

    // [474] Sub AddAttribute(attr As String, value As String) 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [475]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // End Sub
    };

    // [479] Sub RemoveAttribute(attr As String) 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [480]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // End Sub
    };

    // [484] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _menu;
        var _i;
        var _df;
        // [485]  If Theme = {174} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [486]  BuildDropDownStructures 
        self.builddropdownstructures();
        // [487]  Element.ID = ID 
        self._element._id = self._id;
        // [488]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [489]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [491]  logo.AddClass(LogoPosition) 
        self._logo.addclass(self._logoposition);
        // [493]  nw.AddElement(logo) 
        self._nw.addelement(self._logo);
        // [495]  Dim menu As UOEHTML 
        _menu = new banano_uoebanano_uoehtml();
        // [496]  menu.Initialize( {175} , {176} ) 
        _menu.initialize("navmenu", "a");
        // [497]  menu.SetHREF( {177} ) 
        _menu.sethref("#");
        // [498]  menu.addattribute( {178} ,ID & {179} ) 
        _menu.addattribute("data-target", self._id + "drawer");
        // [499]  menu.AddClassOnCondition(ShowMenuOnLarge, {180} ) 
        _menu.addclassoncondition(self._showmenuonlarge, "show-on-large");
        // [500]  menu.AddClass( {181} ) 
        _menu.addclass("sidenav-trigger");
        // [502]  Dim i As UOEHTML 
        _i = new banano_uoebanano_uoehtml();
        // [503]  i.Initialize( {182} , {183} ) 
        _i.initialize("", "i");
        // [504]  i.AddClass( {184} ) 
        _i.addclass("material-icons");
        // [505]  i.AddContent( {185} ) 
        _i.addcontent("menu");
        // [506]  menu.AddElement(i) 
        _menu.addelement(_i);
        // [508]  nw.AddElement(menu) 
        self._nw.addelement(_menu);
        // [509]  LeftMenu.MaterialVisibility(LeftMenuVisibility) 
        self._leftmenu.materialvisibility(self._leftmenuvisibility);
        // [510]  RightMenu.MaterialVisibility(RightMenuVisibility) 
        self._rightmenu.materialvisibility(self._rightmenuvisibility);
        // [512]  nw.AddElement(LeftMenu) 
        self._nw.addelement(self._leftmenu);
        // [513]  nw.AddElement(RightMenu) 
        self._nw.addelement(self._rightmenu);
        // [516]  Element.AddClassOnCondition(hasContents, {186} ) 
        self._element.addclassoncondition(self._hascontents, "nav-extended");
        // [517]  pcol.AddElement(nw) 
        self._pcol.addelement(self._nw);
        // [518]  If hasContents Then 
        if (self._hascontents) {
            // [519]  pcol.AddContent(Content.tostring) 
            self._pcol.addcontent(self._content.tostring());
            // [520]  End If 
        }
        // [521]  Element.AddElement(pcol) 
        self._element.addelement(self._pcol);
        // [522]  If Fixed Then 
        if (self._fixed) {
            // [523]  Dim df As UOEHTML 
            _df = new banano_uoebanano_uoehtml();
            // [524]  df.Initialize(ID & {187} , {188} ) 
            _df.initialize(self._id + "fixed", "div");
            // [525]  df.AddClass( {189} ) 
            _df.addclass("navbar-fixed");
            // [526]  df.AddElement(Element) 
            _df.addelement(self._element);
            // [533]  Return df.html 
            return _df.html();
            // [534]  Else 
        } else {
            // [541]  Return Element.html 
            return self._element.html();
            // [542]  End If 
        }
        // End Sub
    };

}
// =========================== UOEPagination  ===========================
function banano_uoebanano_uoepagination() {
    var self;
    this._id = '';

    this._theme = '';

    this._app = new banano_uoebanano_uoeapp();

    this._visibility = '';

    this._enabled = false;

    this._el = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._ptot = 0;

    this._activepagenumber = 0;

    this._links = {};

    this._showarrows = false;

    this._texts = {};

    // [21] Sub AddStyleAttribute(attribute As String, value As String) As UOEPagination 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [22]  el.AddStyleAttribute(attribute,value) 
        self._el.addstyleattribute(_attribute, _value);
        // [23]  Return Me 
        return self;
        // End Sub
    };

    // [27] Public Sub Initialize(thisApp As UOEApp, sID As String, totPages As Int, themeName As String, className As String) 
    this.initialize = function (_thisapp, _sid, _totpages, _themename, _classname) {
        if (self == null) self = this;
        // [29]  App = thisApp 
        self._app = _thisapp;
        // [30]  ID = sID.ToLowerCase 
        self._id = _sid.toLowerCase();
        // [31]  el.Initialize(ID, {6} ) 
        self._el.initialize(self._id, "ul");
        // [32]  el.AddClass( {7} ) 
        self._el.addclass("pagination");
        // [33]  el.addClass(className) 
        self._el.addclass(_classname);
        // [34]  Enabled = True 
        self._enabled = true;
        // [35]  ActivePageNumber = 0 
        self._activepagenumber = 0;
        // [36]  pTot = totPages 
        self._ptot = _totpages;
        // [37]  links.Initialize 
        self._links = {};
        // [38]  links.clear 
        self._links = {};
        // [39]  texts.Initialize 
        self._texts = {};
        // [40]  texts.clear 
        self._texts = {};
        // [41]  ShowArrows = True 
        self._showarrows = true;
        // [42]  Theme = themeName 
        self._theme = _themename;
        // [43]  App.MaterialUseTheme(Theme,el) 
        self._app.materialusetheme(self._theme, self._el);
        // End Sub
    };

    // [47] Sub AddLink(pgLink As String) As UOEPagination 
    this.addlink = function (_pglink) {
        if (self == null) self = this;
        var _pgnumber;
        var _pkey;
        // [48]  Dim pgNumber As Int = links.size + 1 
        _pgnumber = Object.keys(self._links).length + 1;
        // [49]  Dim pKey As String = {0} 
        _pkey = "" + self._id + "page" + _pgnumber + "";
        // [50]  links.Put(pKey,pgLink) 
        self._links[_pkey] = _pglink;
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [56] private Sub AddLink2(pgText As String) 
    this.addlink2 = function (_pgtext) {
        if (self == null) self = this;
        var _pgnumber;
        var _pkey;
        // [57]  Dim pgNumber As Int = texts.size + 1 
        _pgnumber = Object.keys(self._texts).length + 1;
        // [58]  Dim pKey As String = {1} 
        _pkey = "" + self._id + "page" + _pgnumber + "";
        // [59]  texts.Put(pKey,pgText) 
        self._texts[_pkey] = _pgtext;
        // End Sub
    };

    // [63] Sub AddLinks(lst As List) As UOEPagination 
    this.addlinks = function (_lst) {
        if (self == null) self = this;
        var _strlink;
        // [64]  If lst <> Null Then 
        if (_lst != null) {
            // [65]  For Each strLink As String In lst 
            for (var _strlinkindex = 0; _strlinkindex < _lst.length; _strlinkindex++) {
                _strlink = _lst[_strlinkindex];
                // [66]  AddLink(strLink) 
                self.addlink(_strlink);
                // [67]  Next 
            }
            // [68]  End If 
        }
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [72] Sub AddTexts(lst As List) As UOEPagination 
    this.addtexts = function (_lst) {
        if (self == null) self = this;
        var _strlink;
        // [73]  If lst <> Null Then 
        if (_lst != null) {
            // [74]  For Each strLink As String In lst 
            for (var _strlinkindex = 0; _strlinkindex < _lst.length; _strlinkindex++) {
                _strlink = _lst[_strlinkindex];
                // [75]  AddLink2(strLink) 
                self.addlink2(_strlink);
                // [76]  Next 
            }
            // [77]  End If 
        }
        // [78]  Return Me 
        return self;
        // End Sub
    };

    // [82] Sub AddLink1(pgNumber As Int, pgLink As String) As UOEPagination 
    this.addlink1 = function (_pgnumber, _pglink) {
        if (self == null) self = this;
        var _pkey;
        // [83]  Dim pKey As String = {2} 
        _pkey = "" + self._id + "page" + _pgnumber + "";
        // [84]  links.Put(pKey,pgLink) 
        self._links[_pkey] = _pglink;
        // [87]  Return Me 
        return self;
        // End Sub
    };

    // [91] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _la;
        var _pkey;
        var _i;
        var _a;
        var _pcnt;
        var _ep;
        var _href;
        var _haspkey;
        var _hastext;
        var _txt;
        var _ra;
        // [92]  el.ID = ID 
        self._el._id = self._id;
        // [93]  el.MaterialEnable(Enabled) 
        self._el.materialenable(self._enabled);
        // [94]  el.MaterialVisibility(Visibility) 
        self._el.materialvisibility(self._visibility);
        // [96]  Dim la As UOEHTML 
        _la = new banano_uoebanano_uoehtml();
        // [97]  Dim pKey As String = {3} 
        _pkey = "" + self._id + "pagefirst";
        // [98]  la.Initialize(ID & {8} , {9} ) 
        _la.initialize(self._id + "first", "li");
        // [100]  Dim i As UOEHTML 
        _i = new banano_uoebanano_uoehtml();
        // [101]  i.Initialize( {10} , {11} ) 
        _i.initialize("", "i");
        // [102]  i.AddClass( {12} ) 
        _i.addclass("waves-effect");
        // [103]  i.addclass( {13} ) 
        _i.addclass("material-icons");
        // [104]  i.AddClass( {14} ) 
        _i.addclass("disabled");
        // [105]  i.AddContent( {15} ) 
        _i.addcontent("chevron_left");
        // [107]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [108]  a.Initialize(pKey, {16} ) 
        _a.initialize(_pkey, "a");
        // [109]  a.SetHREF( {17} ) 
        _a.sethref("#!");
        // [110]  a.AddElement(i) 
        _a.addelement(_i);
        // [111]  la.AddElement(a) 
        _la.addelement(_a);
        // [113]  If ShowArrows Then el.AddElement(la) 
        if (self._showarrows) {
            self._el.addelement(_la);
        }
        // [115]  Dim pCnt As Int 
        _pcnt = 0;
        // [116]  pTot = links.Size 
        self._ptot = Object.keys(self._links).length;
        // [117]  For pCnt = 1 To pTot 
        for (_pcnt = 1; _pcnt <= self._ptot; _pcnt++) {
            // [118]  pKey = {4} 
            _pkey = "" + self._id + "page" + _pcnt + "";
            // [119]  Dim ep As UOEHTML 
            _ep = new banano_uoebanano_uoehtml();
            // [120]  ep.Initialize( {18} , {19} ) 
            _ep.initialize("", "li");
            // [121]  ep.AddClass( {20} ) 
            _ep.addclass("waves-effect");
            // [122]  Dim a As UOEHTML 
            _a = new banano_uoebanano_uoehtml();
            // [123]  Dim href As String = {21} 
            _href = "#!";
            // [124]  a.Initialize(pKey, {22} ) 
            _a.initialize(_pkey, "a");
            // [125]  a.AddContent(pCnt) 
            _a.addcontent(_pcnt);
            // [126]  Dim haspKey As Boolean = links.ContainsKey(pKey) 
            _haspkey = (_pkey in self._links);
            // [127]  If haspKey Then 
            if (_haspkey) {
                // [128]  href = links.GetDefault(pKey, {23} ) 
                _href = (self._links[_pkey] || "#!");
                // [129]  a.SetHREF(href) 
                _a.sethref(_href);
                // [130]  Else 
            } else {
                // [131]  a.SetHREF(href) 
                _a.sethref(_href);
                // [132]  End If 
            }
            // [134]  Dim hasText As Boolean = texts.ContainsKey(pKey) 
            _hastext = (_pkey in self._texts);
            // [135]  If hasText Then 
            if (_hastext) {
                // [136]  Dim txt As String = texts.Get(pKey) 
                _txt = self._texts[_pkey];
                // [137]  a.MaterialSetToolTip( {24} , {25} ,txt) 
                _a.materialsettooltip("bottom", "300", _txt);
                // [138]  End If 
            }
            // [139]  ep.AddElement(a) 
            _ep.addelement(_a);
            // [140]  If ActivePageNumber = pCnt Then 
            if (self._activepagenumber == _pcnt) {
                // [141]  ep.AddClass( {26} ) 
                _ep.addclass("active");
                // [142]  End If 
            }
            // [143]  el.AddElement(ep) 
            self._el.addelement(_ep);
            // [144]  Next 
        }
        // [147]  Dim ra As UOEHTML 
        _ra = new banano_uoebanano_uoehtml();
        // [148]  pKey = {5} 
        _pkey = "" + self._id + "pagelast";
        // [149]  ra.Initialize(ID & {27} , {28} ) 
        _ra.initialize(self._id + "last", "li");
        // [151]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [152]  a.Initialize(pKey, {29} ) 
        _a.initialize(_pkey, "a");
        // [153]  a.SetHREF( {30} ) 
        _a.sethref("#!");
        // [155]  Dim i As UOEHTML 
        _i = new banano_uoebanano_uoehtml();
        // [156]  i.Initialize( {31} , {32} ) 
        _i.initialize("", "i");
        // [157]  i.AddClass( {33} ) 
        _i.addclass("waves-effect");
        // [158]  i.addclass( {34} ) 
        _i.addclass("material-icons");
        // [159]  i.AddContent( {35} ) 
        _i.addcontent("chevron_right");
        // [161]  a.AddElement(i) 
        _a.addelement(_i);
        // [162]  ra.AddElement(a) 
        _ra.addelement(_a);
        // [164]  If ShowArrows Then 
        if (self._showarrows) {
            // [165]  el.AddElement(ra) 
            self._el.addelement(_ra);
            // [166]  End If 
        }
        // [171]  Return el.html 
        return self._el.html();
        // End Sub
    };

    // [175] Sub AddClass(sClass As String) As UOEPagination 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [176]  el.AddClass(sClass) 
        self._el.addclass(_sclass);
        // [177]  Return Me 
        return self;
        // End Sub
    };

    // [181] Sub RemoveClass(sClass As String) As UOEPagination 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [182]  el.RemoveClass(sClass) 
        self._el.removeclass(_sclass);
        // [183]  Return Me 
        return self;
        // End Sub
    };

    // [187] Sub AddAttribute(attr As String, value As String) As UOEPagination 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [188]  el.AddAttribute(attr,value) 
        self._el.addattribute(_attr, _value);
        // [189]  Return Me 
        return self;
        // End Sub
    };

    // [193] Sub RemoveAttribute(attr As String) As UOEPagination 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [194]  el.RemoveAttribute(attr) 
        self._el.removeattribute(_attr);
        // [195]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEParallax  ===========================
function banano_uoebanano_uoeparallax() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._image = '';

    this._enabled = false;

    this._element = new banano_uoebanano_uoehtml();

    this._visibility = '';

    this._instance = '';

    this._height = 0;

    // [16] Sub AddStyleAttribute(attribute As String, value As String) As UOEParallax 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [17]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [18]  Return Me 
        return self;
        // End Sub
    };

    // [23] Public Sub Initialize(thisApp As UOEApp, sID As String, sImage As String) 
    this.initialize = function (_thisapp, _sid, _simage) {
        if (self == null) self = this;
        var _div;
        var _img;
        // [25]  App = thisApp 
        self._app = _thisapp;
        // [26]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [27]  Enabled = True 
        self._enabled = true;
        // [28]  Image = sImage 
        self._image = _simage;
        // [29]  Element.Initialize(ID, {4} ) 
        self._element.initialize(self._id, "div");
        // [30]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [31]  div.Initialize( {5} , {6} ) 
        _div.initialize("", "div");
        // [32]  div.AddClass( {7} ) 
        _div.addclass("parallax");
        // [33]  Dim img As UOEHTML 
        _img = new banano_uoebanano_uoehtml();
        // [34]  img.Initialize( {8} , {9} ) 
        _img.initialize("", "img");
        // [35]  img.SetSRC(Image,True) 
        _img.setsrc(self._image, true);
        // [36]  div.AddElement(img) 
        _div.addelement(_img);
        // [37]  Element.AddElement(div) 
        self._element.addelement(_div);
        // [38]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // [39]  Height = 500 
        self._height = 500;
        // End Sub
    };

    // [43] Sub AddContainer(cont As UOEContainer) As UOEParallax 
    this.addcontainer = function (_cont) {
        if (self == null) self = this;
        // [44]  Element.AddContent(cont.ToString) 
        self._element.addcontent(_cont.tostring());
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [49] Sub AddClass(sClass As String) As UOEParallax 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [50]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveClass(sClass As String) As UOEParallax 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [56]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub AddAttribute(attr As String, value As String) As UOEParallax 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [62]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [63]  Return Me 
        return self;
        // End Sub
    };

    // [67] Sub RemoveAttribute(attr As String) As UOEParallax 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [68]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [73] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [74]  Element.ID = ID 
        self._element._id = self._id;
        // [75]  Element.MaterialEnable(Enabled).AddClass( {10} ) 
        self._element.materialenable(self._enabled).addclass("parallax-container");
        // [76]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [78]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [85]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEPreloader  ===========================
function banano_uoebanano_uoepreloader() {
    var self;
    this._id = '';

    this._app = new banano_uoebanano_uoeapp();

    this._el = new banano_uoebanano_uoehtml();

    // [11] Sub AddStyleAttribute(attribute As String, value As String) As UOEPreloader 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [12]  el.AddStyleAttribute(attribute,value) 
        self._el.addstyleattribute(_attribute, _value);
        // [13]  Return Me 
        return self;
        // End Sub
    };

    // [17] Public Sub Initialize(thisApp As UOEApp, sID As String) 
    this.initialize = function (_thisapp, _sid) {
        if (self == null) self = this;
        // [19]  App = thisApp 
        self._app = _thisapp;
        // [20]  ID = sID.ToLowerCase 
        self._id = _sid.toLowerCase();
        // [21]  el.Initialize(ID, {1} ) 
        self._el.initialize(self._id, "div");
        // [22]  el.AddClass( {2} ).AddClass( {3} ).AddClass( {4} ) 
        self._el.addclass("preloader-wrapper").addclass("big").addclass("active");
        // End Sub
    };

    // [26] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _script;
        // [27]  el.ID = ID 
        self._el._id = self._id;
        // [28]  Dim script As String = {0} 
        _script = "<div class=\"spinner-layer spinner-blue\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-red\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-yellow\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-green\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div>";
        // [29]  el.AddContent(script) 
        self._el.addcontent(_script);
        // [34]  Return el.html 
        return self._el.html();
        // End Sub
    };

    // [38] Sub AddClass(sClass As String) As UOEPreloader 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [39]  el.AddClass(sClass) 
        self._el.addclass(_sclass);
        // [40]  Return Me 
        return self;
        // End Sub
    };

    // [44] Sub RemoveClass(sClass As String) As UOEPreloader 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [45]  el.RemoveClass(sClass) 
        self._el.removeclass(_sclass);
        // [46]  Return Me 
        return self;
        // End Sub
    };

    // [50] Sub AddAttribute(attr As String, value As String) As UOEPreloader 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [51]  el.AddAttribute(attr,value) 
        self._el.addattribute(_attr, _value);
        // [52]  Return Me 
        return self;
        // End Sub
    };

    // [56] Sub RemoveAttribute(attr As String) As UOEPreloader 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [57]  el.RemoveAttribute(attr) 
        self._el.removeattribute(_attr);
        // [58]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEProgress  ===========================
function banano_uoebanano_uoeprogress() {
    var self;
    this._id = '';

    this._theme = '';

    this._app = new banano_uoebanano_uoeapp();

    this._visibility = '';

    this._el = new banano_uoebanano_uoehtml();

    this._percentage = 0;

    this._perc = new banano_uoebanano_uoehtml();

    this._mdeterminate = false;

    // [16] Sub AddStyleAttribute(attribute As String, value As String) As UOEProgress 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [17]  el.AddStyleAttribute(attribute,value) 
        self._el.addstyleattribute(_attribute, _value);
        // [18]  Return Me 
        return self;
        // End Sub
    };

    // [22] Public Sub Initialize(thisApp As UOEApp, sID As String, Determinate As Boolean, themeName As String) As UOEProgress 
    this.initialize = function (_thisapp, _sid, _determinate, _themename) {
        if (self == null) self = this;
        // [24]  App = thisApp 
        self._app = _thisapp;
        // [25]  ID = sID.ToLowerCase 
        self._id = _sid.toLowerCase();
        // [26]  el.Initialize(ID, {1} ) 
        self._el.initialize(self._id, "div");
        // [27]  el.AddClass( {2} ) 
        self._el.addclass("progress");
        // [28]  mDeterminate = Determinate 
        self._mdeterminate = _determinate;
        // [29]  Percentage = 0 
        self._percentage = 0;
        // [30]  Theme = themeName 
        self._theme = _themename;
        // [31]  Return Me 
        return self;
        // End Sub
    };

    // [35] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [36]  el.MaterialVisibility(Visibility) 
        self._el.materialvisibility(self._visibility);
        // [37]  perc.Initialize( {3} , {4} ) 
        self._perc.initialize("", "div");
        // [38]  perc.AddClassOnCondition(mDeterminate, {5} ) 
        self._perc.addclassoncondition(self._mdeterminate, "determinate");
        // [39]  perc.AddStyleAttribute( {6} , {0} ) 
        self._perc.addstyleattribute("width", "" + self._percentage + "%");
        // [40]  If mDeterminate = False Then 
        if (self._mdeterminate == false) {
            // [41]  perc.AddClassOnFalseCondition(False, {7} ) 
            self._perc.addclassonfalsecondition(false, "indeterminate");
            // [42]  End If 
        }
        // [43]  el.AddElement(perc) 
        self._el.addelement(self._perc);
        // [48]  App.ApplyToolTip(ID,perc) 
        self._app.applytooltip(self._id, self._perc);
        // [49]  Return el.html 
        return self._el.html();
        // End Sub
    };

    // [53] Sub AddClass(sClass As String) As UOEProgress 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [54]  el.AddClass(sClass) 
        self._el.addclass(_sclass);
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub RemoveClass(sClass As String) As UOEProgress 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [60]  el.RemoveClass(sClass) 
        self._el.removeclass(_sclass);
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [65] Sub AddAttribute(attr As String, value As String) As UOEProgress 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [66]  el.AddAttribute(attr,value) 
        self._el.addattribute(_attr, _value);
        // [67]  Return Me 
        return self;
        // End Sub
    };

    // [71] Sub RemoveAttribute(attr As String) As UOEProgress 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [72]  el.RemoveAttribute(attr) 
        self._el.removeattribute(_attr);
        // [73]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== modUOE  ===========================
function banano_uoebanano_moduoe() {
    var self;
    this._resources = {};

    // [7] Sub PrepareResources 
    this.prepareresources = function () {
        if (self == null) self = this;
        // [8]  Resources.Initialize 
        self._resources = {};
        // [9]  Resources.clear 
        self._resources = {};
        // [10]  AddResource( {0} ) 
        self.addresource("materialfont.css");
        // [11]  AddResource( {1} ) 
        self.addresource("materialize.min.css");
        // [12]  AddResource( {2} ) 
        self.addresource("preloader.css");
        // [13]  AddResource( {3} ) 
        self.addresource("jquery-3.3.1.min.js");
        // [14]  AddResource( {4} ) 
        self.addresource("jquery.timeago.min.js");
        // [15]  AddResource( {5} ) 
        self.addresource("materialize.min.js");
        // [17]  AddResource( {6} ) 
        self.addresource("all.min.css");
        // [18]  AddResource( {7} ) 
        self.addresource("all.min.js");
        // [19]  AddResource( {8} ) 
        self.addresource("nouislider.css");
        // [20]  AddResource( {9} ) 
        self.addresource("nouislider.min.js");
        // [21]  AddResource( {10} ) 
        self.addresource("jquery.sweet-modal.min.css");
        // [22]  AddResource( {11} ) 
        self.addresource("jquery.sweet-modal.min.js");
        // [24]  AddResource( {12} ) 
        self.addresource("Blob.min.js");
        // [25]  AddResource( {13} ) 
        self.addresource("canvas-toBlob.js");
        // [26]  AddResource( {14} ) 
        self.addresource("dom-to-image.min.js");
        // [27]  AddResource( {15} ) 
        self.addresource("FileSaver.min.js");
        // [28]  AddResource( {16} ) 
        self.addresource("printThis.js");
        // [30]  AddResource( {17} ) 
        self.addresource("jquery.toolbar.css");
        // [31]  AddResource( {18} ) 
        self.addresource("jquery.toolbar.min.js");
        // [33]  AddResource( {19} ) 
        self.addresource("billboard.min.css");
        // [34]  AddResource( {20} ) 
        self.addresource("billboard.pkgd.min.js");
        // [36]  AddResource( {21} ) 
        self.addresource("tableHTMLExport.js");
        // End Sub
    };

    // [39] Sub AddResource(sFile As String) 
    this.addresource = function (_sfile) {
        if (self == null) self = this;
        // [40]  Resources.Put(sFile,sFile) 
        self._resources[_sfile] = _sfile;
        // End Sub
    };

    // [44] public Sub MaterialAddIcon(thisApp As UOEApp, Element As UOEHTML,IconName As String, iconPos As String, IconTheme As String, IconCircle As Boolean, bWave As Boolean, bCursor As Boolean, bPrefix As Boolean, bClose As Boolean) As UOEHTML 
    this.materialaddicon = function (_thisapp, _element, _iconname, _iconpos, _icontheme, _iconcircle, _bwave, _bcursor, _bprefix, _bclose) {
        if (self == null) self = this;
        var _iconid;
        var _icn;
        // [46]  Dim iconID As String = Element.ID & {22} 
        _iconid = _element._id + "-icon";
        // [47]  If Element.ClassExists( {23} ) = True Then 
        if (_element.classexists("fixed-action-btn") == true) {
            // [48]  IconCircle = True 
            _iconcircle = true;
            // [49]  else if Element.ClassExists( {24} ) = True Then 
        } else if (_element.classexists("halfway-fab") == true) {
            // [50]  IconCircle = True 
            _iconcircle = true;
            // [51]  else if Element.ClassExists( {25} ) = True Then 
        } else if (_element.classexists("btn-floating") == true) {
            // [52]  IconCircle = True 
            _iconcircle = true;
            // [53]  End If 
        }
        // [54]  If IconName.Length > 0 Then 
        if (_iconname.length > 0) {
            // [55]  Dim icn As UOEIcon 
            _icn = new banano_uoebanano_uoeicon();
            // [56]  icn.Initialize(thisApp,iconID,IconName,IconTheme) 
            _icn.initialize(_thisapp, _iconid, _iconname, _icontheme);
            // [57]  icn.IconName = IconName 
            _icn._iconname = _iconname;
            // [58]  icn.Alignment = iconPos 
            _icn._alignment = _iconpos;
            // [59]  icn.AddCursor = bCursor 
            _icn._addcursor = _bcursor;
            // [60]  icn.Circle = IconCircle 
            _icn._circle = _iconcircle;
            // [61]  icn.WavesEffect = bWave 
            _icn._waveseffect = _bwave;
            // [62]  icn.Prefix = bPrefix 
            _icn._prefix = _bprefix;
            // [63]  icn.Theme = IconTheme 
            _icn._theme = _icontheme;
            // [64]  icn.Close = bClose 
            _icn._close = _bclose;
            // [65]  Element.AddContent(icn.tostring) 
            _element.addcontent(_icn.tostring());
            // [66]  End If 
        }
        // [67]  Return Element 
        return _element;
        // End Sub
    };

    // [72] public Sub MaterialAddImage(thisApp As UOEApp, Element As UOEHTML,imgURL As String, imgAlt As String, imgHeight As String, imgWidth As String, imgCircle As Boolean, imgResponsive As Boolean, imgStatic As Boolean, topMargin As String) As UOEHTML 
    this.materialaddimage = function (_thisapp, _element, _imgurl, _imgalt, _imgheight, _imgwidth, _imgcircle, _imgresponsive, _imgstatic, _topmargin) {
        if (self == null) self = this;
        var _img;
        // [73]  If imgURL.Length > 0 Then 
        if (_imgurl.length > 0) {
            // [74]  Dim img As UOEImage 
            _img = new banano_uoebanano_uoeimage();
            // [75]  img.Initialize(thisApp,Element.ID & {26} ,imgURL,imgAlt,imgStatic) 
            _img.initialize(_thisapp, _element._id + "-img", _imgurl, _imgalt, _imgstatic);
            // [76]  img.SetSize(imgHeight,imgWidth) 
            _img.setsize(_imgheight, _imgwidth);
            // [77]  img.Circle = imgCircle 
            _img._circle = _imgcircle;
            // [78]  img.SetMarginTop(topMargin) 
            _img.setmargintop(_topmargin);
            // [79]  img.Responsive = imgResponsive 
            _img._responsive = _imgresponsive;
            // [80]  img.Static = imgStatic 
            _img._static = _imgstatic;
            // [81]  Element.AddContent(img.tostring) 
            _element.addcontent(_img.tostring());
            // [82]  End If 
        }
        // [83]  Return Element 
        return _element;
        // End Sub
    };

    // [88] Sub MaterialAddBadge(thisApp As UOEApp, Element As UOEHTML,sText As String, bNew As Boolean, sVisibility As String, bCircle As Boolean, sTheme As String, bAddClass1 As Boolean) As UOEHTML 
    this.materialaddbadge = function (_thisapp, _element, _stext, _bnew, _svisibility, _bcircle, _stheme, _baddclass1) {
        if (self == null) self = this;
        var _badge;
        // [90]  Dim badge As UOEBadge 
        _badge = new banano_uoebanano_uoebadge();
        // [91]  badge.Initialize(thisApp,Element.id & {27} ,sText,bNew,sTheme) 
        _badge.initialize(_thisapp, _element._id + "-badge", _stext, _bnew, _stheme);
        // [92]  badge.Circle = bCircle 
        _badge._circle = _bcircle;
        // [93]  badge.element.MaterialVisibility(sVisibility) 
        _badge._element.materialvisibility(_svisibility);
        // [94]  If bAddClass1 = True Then 
        if (_baddclass1 == true) {
            // [95]  badge.Element.AddClass( {28} ) 
            _badge._element.addclass("badge1");
            // [96]  badge.Element.RemoveClass( {29} ) 
            _badge._element.removeclass("badge");
            // [97]  End If 
        }
        // [98]  Element.AddContent(badge.tostring) 
        _element.addcontent(_badge.tostring());
        // [100]  Return Element 
        return _element;
        // End Sub
    };

}
// =========================== UOERadio  ===========================
function banano_uoebanano_uoeradio() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._theme = '';

    this._enabled = false;

    this._hoverable = false;

    this._withgap = false;

    this._checked = false;

    this._visibility = '';

    this._element = new banano_uoebanano_uoehtml();

    this._zdepth = '';

    this._lbl = new banano_uoebanano_uoehtml();

    this._inp = new banano_uoebanano_uoehtml();

    this._spn = new banano_uoebanano_uoehtml();

    this._inline = false;

    // [24] Sub AddStyleAttribute(attribute As String, value As String) As UOERadio 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [25]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Public Sub Initialize(thisApp As UOEApp, sID As String, sName As String, sValue As String, sTitle As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _sname, _svalue, _stitle, _themename) {
        if (self == null) self = this;
        // [32]  App = thisApp 
        self._app = _thisapp;
        // [33]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [34]  Theme = themeName 
        self._theme = _themename;
        // [35]  Checked = False 
        self._checked = false;
        // [36]  Enabled = True 
        self._enabled = true;
        // [37]  Visibility = {0} 
        self._visibility = "";
        // [38]  WithGap = False 
        self._withgap = false;
        // [39]  Element.Initialize(ID, {1} ) 
        self._element.initialize(self._id, "p");
        // [40]  lbl.Initialize(ID & {2} , {3} ) 
        self._lbl.initialize(self._id + "lbl", "label");
        // [41]  inp.Initialize(ID & {4} , {5} ) 
        self._inp.initialize(self._id + "inp", "input");
        // [42]  inp.SetTYPE( {6} ) 
        self._inp.settype("radio");
        // [43]  inp.SetNAME(sName) 
        self._inp.setname(_sname);
        // [44]  inp.SetVALUE(sValue) 
        self._inp.setvalue(_svalue);
        // [45]  spn.Initialize(ID & {7} , {8} ) 
        self._spn.initialize(self._id + "-span", "span");
        // [46]  spn.AddContent(sTitle & {9} ) 
        self._spn.addcontent(_stitle + "{NBSP}{NBSP}");
        // [47]  Inline = False 
        self._inline = false;
        // End Sub
    };

    // [51] Sub AddClass(sClass As String) As UOERadio 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [52]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [57] Sub RemoveClass(sClass As String) As UOERadio 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [58]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [59]  Return Me 
        return self;
        // End Sub
    };

    // [63] Sub AddAttribute(attr As String, value As String) As UOERadio 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [64]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [65]  Return Me 
        return self;
        // End Sub
    };

    // [69] Sub RemoveAttribute(attr As String) As UOERadio 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [70]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [71]  Return Me 
        return self;
        // End Sub
    };

    // [75] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [76]  Element.ID = ID 
        self._element._id = self._id;
        // [77]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [78]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [79]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [80]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [81]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [83]  inp.AddAttributeOnCondition(Not(Enabled), {10} , {11} ) 
        self._inp.addattributeoncondition(!(self._enabled), "disabled", "disabled");
        // [84]  inp.AddAttributeOnCondition(Checked, {12} , {13} ) 
        self._inp.addattributeoncondition(self._checked, "checked", "checked");
        // [85]  inp.AddClassOnCondition(WithGap, {14} ) 
        self._inp.addclassoncondition(self._withgap, "with-gap");
        // [86]  lbl.AddElement(inp) 
        self._lbl.addelement(self._inp);
        // [87]  lbl.AddElement(spn) 
        self._lbl.addelement(self._spn);
        // [88]  Element.AddElement(lbl) 
        self._element.addelement(self._lbl);
        // [89]  Element.AddClassOnCondition(Inline, {15} ) 
        self._element.addclassoncondition(self._inline, "inline");
        // [90]  Element.AddStyleAttributeOnCondition(Inline, {16} , {17} ) 
        self._element.addstyleattributeoncondition(self._inline, "display", "inline-block");
        // [91]  Element.AddStyleAttributeOnCondition(Inline, {18} , {19} ) 
        self._element.addstyleattributeoncondition(self._inline, "padding", "0 12px");
        // [97]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOERadioGroup  ===========================
function banano_uoebanano_uoeradiogroup() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._title = '';

    this._theme = '';

    this._enabled = false;

    this._container = new banano_uoebanano_uoehtml();

    this._visibility = '';

    this._zdepth = '';

    // [16] Sub AddStyleAttribute(attribute As String, value As String) As UOERadioGroup 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [17]  Container.AddStyleAttribute(attribute,value) 
        self._container.addstyleattribute(_attribute, _value);
        // [18]  Return Me 
        return self;
        // End Sub
    };

    // [23] Public Sub Initialize(thisApp As UOEApp, sID As String, sTitle As String, bTitleVisible As Boolean, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _btitlevisible, _themename) {
        if (self == null) self = this;
        var _lbl;
        // [24]  App = thisApp 
        self._app = _thisapp;
        // [25]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [26]  Theme = themeName 
        self._theme = _themename;
        // [27]  Enabled = True 
        self._enabled = true;
        // [28]  Container.Initialize(ID, {0} ) 
        self._container.initialize(self._id, "div");
        // [29]  If bTitleVisible Then 
        if (_btitlevisible) {
            // [30]  Dim lbl As UOEHTML 
            _lbl = new banano_uoebanano_uoehtml();
            // [31]  lbl.Initialize(ID & {1} , {2} ) 
            _lbl.initialize(self._id + "lbl", "label");
            // [32]  lbl.SetFOR(ID).AddContent(sTitle) 
            _lbl.setfor(self._id).addcontent(_stitle);
            // [33]  App.MaterialUseTheme(themeName,lbl) 
            self._app.materialusetheme(_themename, _lbl);
            // [34]  Container.AddElement(lbl) 
            self._container.addelement(_lbl);
            // [35]  End If 
        }
        // End Sub
    };

    // [40] Sub AddClass(sClass As String) As UOERadioGroup 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [41]  Container.AddClass(sClass) 
        self._container.addclass(_sclass);
        // [42]  Return Me 
        return self;
        // End Sub
    };

    // [46] Sub RemoveClass(sClass As String) As UOERadioGroup 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [47]  Container.RemoveClass(sClass) 
        self._container.removeclass(_sclass);
        // [48]  Return Me 
        return self;
        // End Sub
    };

    // [52] Sub AddAttribute(attr As String, value As String) As UOERadioGroup 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [53]  Container.AddAttribute(attr,value) 
        self._container.addattribute(_attr, _value);
        // [54]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub RemoveAttribute(attr As String) As UOERadioGroup 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [59]  Container.RemoveAttribute(attr) 
        self._container.removeattribute(_attr);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub AddItem(itemID As String, itemValue As String, itemText As String, withGap As Boolean, bInline As Boolean, bEnabled As Boolean, bSelected As Boolean) 
    this.additem = function (_itemid, _itemvalue, _itemtext, _withgap, _binline, _benabled, _bselected) {
        if (self == null) self = this;
        var _rad;
        // [65]  Dim rad As UOERadio 
        _rad = new banano_uoebanano_uoeradio();
        // [66]  rad.Initialize(App,itemID,ID,itemValue,itemText, {3} ) 
        _rad.initialize(self._app, _itemid, self._id, _itemvalue, _itemtext, "");
        // [67]  rad.Checked = bSelected 
        _rad._checked = _bselected;
        // [68]  rad.Enabled = bEnabled 
        _rad._enabled = _benabled;
        // [69]  rad.Inline = bInline 
        _rad._inline = _binline;
        // [70]  rad.WithGap = withGap 
        _rad._withgap = _withgap;
        // [71]  Container.AddContent(rad.tostring) 
        self._container.addcontent(_rad.tostring());
        // End Sub
    };

    // [75] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [76]  Container.MaterialVisibility(Visibility).MaterialEnable(Enabled) 
        self._container.materialvisibility(self._visibility).materialenable(self._enabled);
        // [77]  App.MaterialUseTheme(Theme,Container) 
        self._app.materialusetheme(self._theme, self._container);
        // [78]  Container.MaterialZDepth(ZDepth).MaterialVisibility(Visibility) 
        self._container.materialzdepth(self._zdepth).materialvisibility(self._visibility);
        // [83]  App.ApplyToolTip(ID,Container) 
        self._app.applytooltip(self._id, self._container);
        // [84]  Return Container.html 
        return self._container.html();
        // End Sub
    };

}
// =========================== UOERange  ===========================
function banano_uoebanano_uoerange() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._minvalue = 0;

    this._maxvalue = 0;

    this._value = 0;

    this._stepwith = 0;

    this._range = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._title = '';

    this._enabled = false;

    this._visibility = '';

    this._zdepth = '';

    this._theme = '';

    this._showtitle = false;

    this._container = new banano_uoebanano_uoehtml();

    // [23] Sub AddStyleAttribute(attribute As String, sValue As String) As UOERange 
    this.addstyleattribute = function (_attribute, _svalue) {
        if (self == null) self = this;
        // [24]  range.AddStyleAttribute(attribute,sValue) 
        self._range.addstyleattribute(_attribute, _svalue);
        // [25]  Return Me 
        return self;
        // End Sub
    };

    // [29] Public Sub Initialize(thisApp As UOEApp,sid As String, sTitle As String, sMinValue As Float, sMaxValue As Float, sValue As Float, sStep As Float, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _sminvalue, _smaxvalue, _svalue, _sstep, _themename) {
        if (self == null) self = this;
        // [31]  App = thisApp 
        self._app = _thisapp;
        // [32]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [33]  MaxValue = sMaxValue 
        self._maxvalue = _smaxvalue;
        // [34]  MinValue = sMinValue 
        self._minvalue = _sminvalue;
        // [35]  Value = sValue 
        self._value = _svalue;
        // [36]  Title = sTitle 
        self._title = _stitle;
        // [37]  StepWith = sStep 
        self._stepwith = _sstep;
        // [38]  range.Initialize(ID & {0} , {1} ) 
        self._range.initialize(self._id + "inp", "input");
        // [39]  range.AddAttribute( {2} ,MinValue) 
        self._range.addattribute("min", self._minvalue);
        // [40]  range.AddAttribute( {3} ,MaxValue) 
        self._range.addattribute("max", self._maxvalue);
        // [41]  range.AddAttribute( {4} , {5} ) 
        self._range.addattribute("type", "range");
        // [42]  range.AddAttribute( {6} ,StepWith) 
        self._range.addattribute("step", self._stepwith);
        // [43]  range.SetNAME(ID).setvalue(sValue) 
        self._range.setname(self._id).setvalue(_svalue);
        // [44]  Enabled = True 
        self._enabled = true;
        // [45]  Visibility = {7} 
        self._visibility = "";
        // [46]  Theme = themeName 
        self._theme = _themename;
        // [47]  ShowTitle = True 
        self._showtitle = true;
        // [48]  Container.Initialize(ID, {8} ) 
        self._container.initialize(self._id, "p");
        // [49]  Container.AddClass( {9} ) 
        self._container.addclass("range-field");
        // End Sub
    };

    // [53] Sub AddClass(sClass As String) As UOERange 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [54]  range.AddClass(sClass) 
        self._range.addclass(_sclass);
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub RemoveClass(sClass As String) As UOERange 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [60]  range.RemoveClass(sClass) 
        self._range.removeclass(_sclass);
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [65] Sub AddAttribute(attr As String, sValue As String) As UOERange 
    this.addattribute = function (_attr, _svalue) {
        if (self == null) self = this;
        // [66]  range.AddAttribute(attr,sValue) 
        self._range.addattribute(_attr, _svalue);
        // [67]  Return Me 
        return self;
        // End Sub
    };

    // [71] Sub RemoveAttribute(attr As String) As UOERange 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [72]  range.RemoveAttribute(attr) 
        self._range.removeattribute(_attr);
        // [73]  Return Me 
        return self;
        // End Sub
    };

    // [77] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _lbl;
        // [78]  range.MaterialEnable(Enabled) 
        self._range.materialenable(self._enabled);
        // [79]  range.MaterialZDepth(ZDepth) 
        self._range.materialzdepth(self._zdepth);
        // [80]  range.MaterialVisibility(Visibility) 
        self._range.materialvisibility(self._visibility);
        // [81]  App.ApplyToolTip(ID,range) 
        self._app.applytooltip(self._id, self._range);
        // [82]  If ShowTitle = True Then 
        if (self._showtitle == true) {
            // [83]  Dim lbl As UOEHTML 
            _lbl = new banano_uoebanano_uoehtml();
            // [84]  lbl.Initialize(ID & {10} , {11} ) 
            _lbl.initialize(self._id + "lbl", "label");
            // [85]  lbl.SetFOR(ID) 
            _lbl.setfor(self._id);
            // [86]  lbl.AddContent(Title) 
            _lbl.addcontent(self._title);
            // [87]  App.MaterialUseTheme(Theme,lbl) 
            self._app.materialusetheme(self._theme, _lbl);
            // [88]  Container.AddElement(lbl) 
            self._container.addelement(_lbl);
            // [89]  End If 
        }
        // [90]  Container.AddContent(range.HTML) 
        self._container.addcontent(self._range.html());
        // [95]  Return Container.html 
        return self._container.html();
        // End Sub
    };

}
// =========================== UOERangeSlider  ===========================
function banano_uoebanano_uoerangeslider() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._minvalue = 0;

    this._maxvalue = 0;

    this._range = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._title = '';

    this._enabled = false;

    this._visibility = '';

    this._zdepth = '';

    this._theme = '';

    this._connect = false;

    this._startat = 0;

    this._stopat = 0;

    this._stepa = 0;

    this._orientation = '';

    this._decimals = 0;

    this._showtitle = false;

    // [25] Sub AddStyleAttribute(attribute As String, value As String) As UOERangeSlider 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [26]  range.AddStyleAttribute(attribute,value) 
        self._range.addstyleattribute(_attribute, _value);
        // [27]  Return Me 
        return self;
        // End Sub
    };

    // [31] Public Sub Initialize(thisApp As UOEApp,sid As String, sTitle As String, lStart As Float, lStop As Float, sMinValue As Float, sMaxValue As Float, lStep As Float, bConnect As Boolean, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _lstart, _lstop, _sminvalue, _smaxvalue, _lstep, _bconnect, _themename) {
        if (self == null) self = this;
        // [33]  App = thisApp 
        self._app = _thisapp;
        // [34]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [35]  MaxValue = sMaxValue 
        self._maxvalue = _smaxvalue;
        // [36]  MinValue = sMinValue 
        self._minvalue = _sminvalue;
        // [37]  Connect = bConnect 
        self._connect = _bconnect;
        // [38]  StartAt = lStart 
        self._startat = _lstart;
        // [39]  StopAt = lStop 
        self._stopat = _lstop;
        // [40]  StepA = lStep 
        self._stepa = _lstep;
        // [41]  Title = sTitle 
        self._title = _stitle;
        // [42]  range.Initialize(ID, {1} ) 
        self._range.initialize(self._id, "div");
        // [43]  Enabled = True 
        self._enabled = true;
        // [44]  Visibility = {2} 
        self._visibility = "";
        // [45]  Theme = themeName 
        self._theme = _themename;
        // [46]  Orientation = App.EnumSliderOrientation.horizontal 
        self._orientation = self._app._enumsliderorientation._horizontal;
        // [47]  Decimals = 0 
        self._decimals = 0;
        // [48]  ShowTitle = True 
        self._showtitle = true;
        // End Sub
    };

    // [52] Sub AddClass(sClass As String) As UOERangeSlider 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [53]  range.AddClass(sClass) 
        self._range.addclass(_sclass);
        // [54]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub RemoveClass(sClass As String) As UOERangeSlider 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [59]  range.RemoveClass(sClass) 
        self._range.removeclass(_sclass);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub AddAttribute(attr As String, sValue As String) As UOERangeSlider 
    this.addattribute = function (_attr, _svalue) {
        if (self == null) self = this;
        // [65]  range.AddAttribute(attr,sValue) 
        self._range.addattribute(_attr, _svalue);
        // [66]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub RemoveAttribute(attr As String) As UOERangeSlider 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [71]  range.RemoveAttribute(attr) 
        self._range.removeattribute(_attr);
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [77] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _p;
        var _lbl;
        // [78]  range.MaterialEnable(Enabled) 
        self._range.materialenable(self._enabled);
        // [79]  range.MaterialZDepth(ZDepth) 
        self._range.materialzdepth(self._zdepth);
        // [80]  range.MaterialVisibility(Visibility) 
        self._range.materialvisibility(self._visibility);
        // [81]  App.ApplyToolTip(ID,range) 
        self._app.applytooltip(self._id, self._range);
        // [82]  If ShowTitle Then 
        if (self._showtitle) {
            // [83]  Dim p As UOEHTML 
            _p = new banano_uoebanano_uoehtml();
            // [84]  p.Initialize(ID & {3} , {4} ) 
            _p.initialize(self._id + "parent", "p");
            // [85]  Dim lbl As UOEHTML 
            _lbl = new banano_uoebanano_uoehtml();
            // [86]  lbl.Initialize(ID & {5} , {6} ) 
            _lbl.initialize(self._id + "lbl", "label");
            // [87]  lbl.SetFOR(ID) 
            _lbl.setfor(self._id);
            // [88]  lbl.AddContent(Title) 
            _lbl.addcontent(self._title);
            // [89]  App.MaterialUseTheme(Theme,lbl) 
            self._app.materialusetheme(self._theme, _lbl);
            // [90]  p.AddElement(lbl) 
            _p.addelement(_lbl);
            // [91]  p.AddContent(range.HTML) 
            _p.addcontent(self._range.html());
            // [98]  Return p.html 
            return _p.html();
            // [99]  Else 
        } else {
            // [104]  Return range.html 
            return self._range.html();
            // [105]  End If 
        }
        // End Sub
    };

    // [109] Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _bconnect;
        var _script;
        // [110]  Dim bConnect As String = App.iif(Connect, {11} , {12} ) 
        _bconnect = self._app.iif(self._connect, "true", "false");
        // [111]  Dim script As String = {0} 
        _script = "var slider" + self._id + " = document.getElementById('" + self._id + "'); \n  noUiSlider.create(slider" + self._id + ", { \n   start: [" + self._startat + ", " + self._stopat + "], \n   connect: " + _bconnect + ", \n   step: " + self._stepa + ", \n   orientation: '" + self._orientation + "', \n   range: { \n	'min': " + self._minvalue + ", \n	'max': " + self._maxvalue + " \n   }, \n   format: wNumb({ \n     decimals: " + self._decimals + " \n   }) \n  });";
        // [112]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOESelect  ===========================
function banano_uoebanano_uoeselect() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._title = '';

    this._theme = '';

    this._prompt = '';

    this._div = new banano_uoebanano_uoehtml();

    this._sel = new banano_uoebanano_uoehtml();

    this._lbl = new banano_uoebanano_uoehtml();

    this._enabled = false;

    this._inline = false;

    this._iconname = '';

    this._multiple = false;

    this._items = [];

    this._isicons = false;

    this._hoverable = false;

    this._visibility = '';

    this._zdepth = '';

    this._autofocus = false;

    this._instance = '';

    // [27] Sub AddStyleAttribute(attribute As String, value As String) As UOESelect 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [28]  div.AddStyleAttribute(attribute,value) 
        self._div.addstyleattribute(_attribute, _value);
        // [29]  Return Me 
        return self;
        // End Sub
    };

    // [33] Public Sub Initialize(thisApp As UOEApp, sID As String, sIcon As String, sTitle As String, sPrompt As String, bMultiple As Boolean, themeName As String) As UOESelect 
    this.initialize = function (_thisapp, _sid, _sicon, _stitle, _sprompt, _bmultiple, _themename) {
        if (self == null) self = this;
        // [35]  App = thisApp 
        self._app = _thisapp;
        // [36]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [37]  Title = sTitle 
        self._title = _stitle;
        // [38]  Theme = themeName 
        self._theme = _themename;
        // [39]  Prompt = sPrompt 
        self._prompt = _sprompt;
        // [40]  Inline = False 
        self._inline = false;
        // [41]  Enabled = True 
        self._enabled = true;
        // [42]  Multiple = bMultiple 
        self._multiple = _bmultiple;
        // [43]  IconName = sIcon 
        self._iconname = _sicon;
        // [44]  items.Initialize 
        self._items.length = 0;
        // [45]  items.clear 
        self._items.length = 0;
        // [46]  isicons=False 
        self._isicons = false;
        // [47]  AutoFocus = False 
        self._autofocus = false;
        // [48]  div.Initialize(ID & {3} , {4} ) 
        self._div.initialize(self._id + "p", "div");
        // [49]  div.AddClass( {5} ).AddClass( {6} ).AddClass( {7} ).AddClass( {8} ).AddClass( {9} ) 
        self._div.addclass("input-field").addclass("col").addclass("s12").addclass("m12").addclass("l12");
        // [50]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub AddClass(sClass As String) As UOESelect 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [56]  div.AddClass(sClass) 
        self._div.addclass(_sclass);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub RemoveClass(sClass As String) As UOESelect 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [62]  div.RemoveClass(sClass) 
        self._div.removeclass(_sclass);
        // [63]  Return Me 
        return self;
        // End Sub
    };

    // [67] Sub AddAttribute(attr As String, value As String) As UOESelect 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [68]  div.AddAttribute(attr,value) 
        self._div.addattribute(_attr, _value);
        // [69]  Return Me 
        return self;
        // End Sub
    };

    // [73] Sub RemoveAttribute(attr As String) As UOESelect 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [74]  div.RemoveAttribute(attr) 
        self._div.removeattribute(_attr);
        // [75]  Return Me 
        return self;
        // End Sub
    };

    // [79] Sub AddItem(itemID As String, itemValue As String, itemText As String) As UOESelect 
    this.additem = function (_itemid, _itemvalue, _itemtext) {
        if (self == null) self = this;
        var _opt;
        // [80]  Dim opt As UOEHTML 
        _opt = new banano_uoebanano_uoehtml();
        // [81]  opt.Initialize(itemID, {10} ) 
        _opt.initialize(_itemid, "option");
        // [82]  opt.AddAttribute( {11} ,itemValue) 
        _opt.addattribute("value", _itemvalue);
        // [83]  opt.AddContent(itemText) 
        _opt.addcontent(_itemtext);
        // [84]  items.Add(opt.HTML) 
        self._items.push(_opt.html());
        // [85]  Return Me 
        return self;
        // End Sub
    };

    // [89] Sub AddImage(itemID As String, itemValue As String, itemText As String, itemImageURL As String, itemAlignment As String, itemCircle As Boolean) As UOESelect 
    this.addimage = function (_itemid, _itemvalue, _itemtext, _itemimageurl, _itemalignment, _itemcircle) {
        if (self == null) self = this;
        var _opt;
        // [90]  isicons = True 
        self._isicons = true;
        // [91]  Dim opt As UOEHTML 
        _opt = new banano_uoebanano_uoehtml();
        // [92]  opt.Initialize(itemID, {12} ) 
        _opt.initialize(_itemid, "option");
        // [93]  opt.AddAttribute( {13} ,itemValue) 
        _opt.addattribute("value", _itemvalue);
        // [94]  opt.AddAttribute( {14} , itemImageURL) 
        _opt.addattribute("data-icon", _itemimageurl);
        // [95]  opt.AddClassOnCondition(itemCircle, {15} ) 
        _opt.addclassoncondition(_itemcircle, "circle");
        // [96]  opt.AddClass(itemAlignment) 
        _opt.addclass(_itemalignment);
        // [97]  opt.AddContent(itemText) 
        _opt.addcontent(_itemtext);
        // [98]  items.Add(opt.HTML) 
        self._items.push(_opt.html());
        // [99]  Return Me 
        return self;
        // End Sub
    };

    // [104] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _opt;
        // [105]  div.MaterialEnable(Enabled) 
        self._div.materialenable(self._enabled);
        // [106]  div.MaterialZDepth(ZDepth) 
        self._div.materialzdepth(self._zdepth);
        // [107]  div.MaterialVisibility(Visibility) 
        self._div.materialvisibility(self._visibility);
        // [108]  App.ApplyToolTip(ID,div) 
        self._app.applytooltip(self._id, self._div);
        // [109]  div.AddClassOnCondition(Inline, {16} ) 
        self._div.addclassoncondition(self._inline, "inline");
        // [110]  sel.Initialize(ID, {17} ) 
        self._sel.initialize(self._id, "select");
        // [111]  sel.AddAttributeOnCondition(AutoFocus, {18} , {19} ) 
        self._sel.addattributeoncondition(self._autofocus, "autofocus", "true");
        // [112]  If Multiple = True Then sel.AddLooseAttribute( {20} ) 
        if (self._multiple == true) {
            self._sel.addlooseattribute("multiple");
        }
        // [113]  sel.AddClassOnCondition(isicons, {21} ).MaterialEnable(Enabled) 
        self._sel.addclassoncondition(self._isicons, "icons").materialenable(self._enabled);
        // [115]  If Prompt.Length > 0 Then 
        if (self._prompt.length > 0) {
            // [116]  Dim opt As UOEHTML 
            _opt = new banano_uoebanano_uoehtml();
            // [117]  opt.Initialize( {22} , {23} ) 
            _opt.initialize("", "option");
            // [118]  opt.AddLooseAttribute( {24} ).AddLooseAttribute( {25} ) 
            _opt.addlooseattribute("disabled").addlooseattribute("selected");
            // [119]  opt.AddContent(Prompt).AddAttribute( {26} , {27} ) 
            _opt.addcontent(self._prompt).addattribute("value", "");
            // [120]  sel.AddContent(opt.HTML) 
            self._sel.addcontent(_opt.html());
            // [121]  End If 
        }
        // [122]  sel.AddContentList(items) 
        self._sel.addcontentlist(self._items);
        // [123]  lbl.Initialize( {28} , {29} ) 
        self._lbl.initialize("", "label");
        // [124]  lbl.AddContent(Title) 
        self._lbl.addcontent(self._title);
        // [125]  modUOE.MaterialAddIcon(App,div,IconName, {30} ,Theme,False,False,False,True,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._div, self._iconname, "", self._theme, false, false, false, true, false);
        // [126]  div.AddContent(sel.HTML) 
        self._div.addcontent(self._sel.html());
        // [127]  div.AddContent(lbl.HTML) 
        self._div.addcontent(self._lbl.html());
        // [134]  Return div.html 
        return self._div.html();
        // End Sub
    };

    // [138] Sub getSelectedValues(varName As String) As String 
    this.getselectedvalues = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [139]  Dim script As String = {2} 
        _script = "" + _varname + " = " + self._instance + ".getSelectedValues();";
        // [140]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOESideBar  ===========================
function banano_uoebanano_uoesidebar() {
    var self;
    this._id = '';

    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._items = [];

    this._drawerwidth = 0;

    this._edge = '';

    this._activesideid = '';

    this._enabled = false;

    this._theme = '';

    this._visibility = '';

    this._isopen = false;

    this._isfixed = false;

    this._draggable = false;

    this._preventscrolling = false;

    this._hascollapse = false;

    this._mc = new banano_uoebanano_uoecollapsible();

    // [24] Sub AddHeader1(itemID As String, itemIcon As String, itemText As String,itemTheme As String, iconTheme As String, hasDivider As Boolean) As UOESideBar 
    this.addheader1 = function (_itemid, _itemicon, _itemtext, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [25]  mc.AddHeader(itemID,itemIcon,itemText, {14} ,False, {15} ,itemTheme,iconTheme,hasDivider) 
        self._mc.addheader(_itemid, _itemicon, _itemtext, "", false, "", _itemtheme, _icontheme, _hasdivider);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Sub AddHeaderItem1(parentID As String,itemID As String,itemIcon As String,itemText As String,itemGoto As String,itemTheme As String,iconTheme As String,hasDivider As Boolean) As UOESideBar 
    this.addheaderitem1 = function (_parentid, _itemid, _itemicon, _itemtext, _itemgoto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [31]  mc.AddHeaderItem(parentID,itemID,itemIcon,itemText,itemGoto, {16} ,False,hasDivider,itemTheme,iconTheme) 
        self._mc.addheaderitem(_parentid, _itemid, _itemicon, _itemtext, _itemgoto, "", false, _hasdivider, _itemtheme, _icontheme);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Sub AddStyleAttribute(attribute As String, value As String) 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [37]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // End Sub
    };

    // [42] Sub AddClass(sClass As String) 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [43]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // End Sub
    };

    // [47] Sub RemoveClass(sClass As String) 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [48]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // End Sub
    };

    // [52] Sub AddAttribute(attr As String, value As String) 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [53]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // End Sub
    };

    // [57] Sub RemoveAttribute(attr As String) 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [58]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // End Sub
    };

    // [63] Public Sub Initialize(thisApp As UOEApp, sID As String, bFixed As Boolean, bOpen As Boolean, sTheme As String) 
    this.initialize = function (_thisapp, _sid, _bfixed, _bopen, _stheme) {
        if (self == null) self = this;
        // [64]  App = thisApp 
        self._app = _thisapp;
        // [65]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [66]  Enabled = True 
        self._enabled = true;
        // [67]  Visibility = {17} 
        self._visibility = "";
        // [68]  Theme = sTheme 
        self._theme = _stheme;
        // [69]  isOpen = bOpen 
        self._isopen = _bopen;
        // [70]  ActiveSideID = {18} 
        self._activesideid = "";
        // [71]  edge = {19} 
        self._edge = "left";
        // [72]  draggable = True 
        self._draggable = true;
        // [73]  isFixed = bFixed 
        self._isfixed = _bfixed;
        // [74]  preventScrolling = True 
        self._preventscrolling = true;
        // [75]  hascollapse = False 
        self._hascollapse = false;
        // [76]  DrawerWidth = 300 
        self._drawerwidth = 300;
        // [77]  Items.Initialize 
        self._items.length = 0;
        // [78]  Items.clear 
        self._items.length = 0;
        // [79]  mc.Initialize(App,ID & {20} ,App.EnumCollapsibleType.accordion,True, {21} ) 
        self._mc.initialize(self._app, self._id + "collapse", self._app._enumcollapsibletype._accordion, true, "");
        // [80]  Element.Initialize(ID, {22} ) 
        self._element.initialize(self._id, "ul");
        // [81]  Element.AddClass( {23} ) 
        self._element.addclass("sidenav");
        // End Sub
    };

    // [85] Sub Open(idx As Int) 
    this.open = function (_idx) {
        if (self == null) self = this;
        // End Sub
    };

    // [90] Sub Close(idx As Int) 
    this.close = function (_idx) {
        if (self == null) self = this;
        // End Sub
    };

    // [102] Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _ms;
        var _str;
        // [103]  Dim ms As Map 
        _ms = {};
        // [104]  ms.Initialize 
        _ms = {};
        // [105]  ms.clear 
        _ms = {};
        // [106]  ms.Put( {28} , ID) 
        _ms["id"] = self._id;
        // [107]  ms.Put( {29} , {30} ) 
        _ms["instance"] = "sidenav";
        // [108]  ms.Put( {31} , draggable) 
        _ms["draggable"] = self._draggable;
        // [109]  ms.Put( {32} , preventScrolling) 
        _ms["preventScrolling"] = self._preventscrolling;
        // [110]  ms.Put( {33} , edge) 
        _ms["edge"] = self._edge;
        // [111]  Dim str As String = App.Map2Json(ms) 
        _str = self._app.map2json(_ms);
        // [112]  Return str 
        return _str;
        // End Sub
    };

    // [116] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _strsideitem;
        // [117]  Element.ID = ID 
        self._element._id = self._id;
        // [118]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [119]  Element.AddClassOnCondition(isFixed, {34} ) 
        self._element.addclassoncondition(self._isfixed, "sidenav-fixed");
        // [120]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [121]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [122]  Element.AddStyleAttribute( {35} ,DrawerWidth & {36} ) 
        self._element.addstyleattribute("width", self._drawerwidth + "px");
        // [124]  For Each strSideItem As String In Items 
        for (var _strsideitemindex = 0; _strsideitemindex < self._items.length; _strsideitemindex++) {
            _strsideitem = self._items[_strsideitemindex];
            // [126]  If strSideItem = ID & {37} Then 
            if (_strsideitem == self._id + "collapse") {
                // [127]  Element.AddContent(mc.tostring) 
                self._element.addcontent(self._mc.tostring());
                // [128]  Else 
            } else {
                // [129]  Element.AddContent(strSideItem) 
                self._element.addcontent(_strsideitem);
                // [130]  End If 
            }
            // [131]  Next 
        }
        // [138]  Return Element.html 
        return self._element.html();
        // End Sub
    };

    // [141] Sub getCSS 
    this.getcss = function () {
        if (self == null) self = this;
        var _strsize;
        var _css;
        var _str;
        // [142]  If isFixed Then 
        if (self._isfixed) {
            // [143]  Dim strSize As String = {4} 
            _strsize = "" + self._drawerwidth + "px";
            // [144]  Dim css As Map 
            _css = {};
            // [145]  css.Initialize 
            _css = {};
            // [146]  css.clear 
            _css = {};
            // [147]  css.Put( {38} , {39} ) 
            _css["id"] = "header";
            // [148]  css.Put( {40} , strSize) 
            _css["padding-left"] = _strsize;
            // [149]  css.Put( {41} , {42} ) 
            _css["width"] = "100%";
            // [150]  Dim str As String = App.Map2Json(css) 
            _str = self._app.map2json(_css);
            // [151]  App.CSS.Add(str) 
            self._app._css.push(_str);
            // [152]  css.Put( {43} , {44} ) 
            _css["id"] = "main";
            // [153]  Dim str As String = App.Map2Json(css) 
            _str = self._app.map2json(_css);
            // [154]  App.CSS.Add(str) 
            self._app._css.push(_str);
            // [155]  css.Put( {45} , {46} ) 
            _css["id"] = "footer";
            // [156]  Dim str As String = App.Map2Json(css) 
            _str = self._app.map2json(_css);
            // [157]  App.CSS.Add(str) 
            self._app._css.push(_str);
            // [158]  End If 
        }
        // End Sub
    };

    // [162] Sub GetLinks(Header As String) As List 
    this.getlinks = function (_header) {
        if (self == null) self = this;
        var _lst;
        var _hdrlinks;
        // [163]  Dim lst As List 
        _lst = [];
        // [164]  lst.Initialize 
        _lst.length = 0;
        // [165]  lst.clear 
        _lst.length = 0;
        // [166]  Header = Header.ToLowerCase 
        _header = _header.toLowerCase();
        // [167]  Dim hdrLinks As Map = mc.links 
        _hdrlinks = self._mc._links;
        // [168]  If hdrLinks.ContainsKey(Header) Then 
        if ((_header in _hdrlinks)) {
            // [169]  lst = hdrLinks.Get(Header) 
            _lst = _hdrlinks[_header];
            // [170]  End If 
        }
        // [171]  Return lst 
        return _lst;
        // End Sub
    };

    // [175] Sub GetTexts(Header As String) As List 
    this.gettexts = function (_header) {
        if (self == null) self = this;
        var _lst;
        var _hdrnames;
        // [176]  Dim lst As List 
        _lst = [];
        // [177]  lst.Initialize 
        _lst.length = 0;
        // [178]  lst.clear 
        _lst.length = 0;
        // [179]  Header = Header.ToLowerCase 
        _header = _header.toLowerCase();
        // [180]  Dim hdrNames As Map = mc.ItemNames 
        _hdrnames = self._mc._itemnames;
        // [181]  If hdrNames.ContainsKey(Header) Then 
        if ((_header in _hdrnames)) {
            // [182]  lst = hdrNames.Get(Header) 
            _lst = _hdrnames[_header];
            // [183]  End If 
        }
        // [184]  Return lst 
        return _lst;
        // End Sub
    };

    // [187] Sub AddHeader(itemID As String, itemIcon As String, itemText As String, itemBadge As String, badgeNew As Boolean, itemNavigateTo As String, itemTheme As String, iconTheme As String,hasDivider As Boolean) 
    this.addheader = function (_itemid, _itemicon, _itemtext, _itembadge, _badgenew, _itemnavigateto, _itemtheme, _icontheme, _hasdivider) {
        if (self == null) self = this;
        // [188]  If hascollapse = False Then AddCollapsible 
        if (self._hascollapse == false) {
            self.addcollapsible();
        }
        // [189]  mc.AddHeader(itemID,itemIcon,itemText, itemBadge,badgeNew,itemNavigateTo,itemTheme,iconTheme,hasDivider) 
        self._mc.addheader(_itemid, _itemicon, _itemtext, _itembadge, _badgenew, _itemnavigateto, _itemtheme, _icontheme, _hasdivider);
        // End Sub
    };

    // [192] Sub AddHeaderItem(parentID As String, itemID As String, iconName As String, itemText As String, itemNavigateTo As String, itemBadge As String, badgeNew As Boolean, bHasDivider As Boolean, itemTheme As String, iconTheme As String) 
    this.addheaderitem = function (_parentid, _itemid, _iconname, _itemtext, _itemnavigateto, _itembadge, _badgenew, _bhasdivider, _itemtheme, _icontheme) {
        if (self == null) self = this;
        // [193]  mc.AddHeaderItem(parentID, itemID, iconName, itemText, itemNavigateTo, itemBadge, badgeNew, bHasDivider, itemTheme, iconTheme) 
        self._mc.addheaderitem(_parentid, _itemid, _iconname, _itemtext, _itemnavigateto, _itembadge, _badgenew, _bhasdivider, _itemtheme, _icontheme);
        // End Sub
    };

    // [197] Sub AddUserView(UserName As String, UserEmail As String, UserImageURL As String, BackgroundImageURL As String) 
    this.adduserview = function (_username, _useremail, _userimageurl, _backgroundimageurl) {
        if (self == null) self = this;
        var _uli;
        var _udiv;
        var _bdiv;
        var _ui;
        var _ui1;
        var _span;
        var _ui2;
        var _span1;
        // [199]  Dim uli As UOEHTML 
        _uli = new banano_uoebanano_uoehtml();
        // [200]  uli.Initialize(ID & {47} , {48} ) 
        _uli.initialize(self._id + "user", "li");
        // [202]  Dim udiv As UOEHTML 
        _udiv = new banano_uoebanano_uoehtml();
        // [203]  udiv.Initialize( {49} , {50} ) 
        _udiv.initialize("", "div");
        // [204]  udiv.AddClass( {51} ) 
        _udiv.addclass("user-view");
        // [207]  Dim bdiv As UOEHTML 
        _bdiv = new banano_uoebanano_uoehtml();
        // [208]  bdiv.Initialize( {52} , {53} ) 
        _bdiv.initialize("", "div");
        // [209]  bdiv.AddClass( {54} ) 
        _bdiv.addclass("background");
        // [210]  modUOE.MaterialAddImage(App,bdiv,BackgroundImageURL, {55} , {56} , {57} ,False,False,True, {58} ) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _bdiv, _backgroundimageurl, "", "", "", false, false, true, "0px");
        // [212]  udiv.AddContent(bdiv.html) 
        _udiv.addcontent(_bdiv.html());
        // [214]  Dim ui As UOEAnchor 
        _ui = new banano_uoebanano_uoeanchor();
        // [215]  ui.Initialize(App, {59} ) 
        _ui.initialize(self._app, "");
        // [216]  ui.HREF = {60} 
        _ui._href = "#!user";
        // [217]  modUOE.MaterialAddImage(App,ui.element,UserImageURL, {61} , {62} , {63} ,True,True,True, {64} ) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _ui._element, _userimageurl, "", "", "", true, true, true, "0px");
        // [218]  udiv.AddContent(ui.tostring) 
        _udiv.addcontent(_ui.tostring());
        // [220]  Dim ui1 As UOEHTML 
        _ui1 = new banano_uoebanano_uoehtml();
        // [221]  ui1.initialize( {65} , {66} ) 
        _ui1.initialize("", "a");
        // [222]  ui1.AddAttribute( {67} , {68} ) 
        _ui1.addattribute("href", "#!name");
        // [223]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [224]  span.Initialize( {69} , {70} ) 
        _span.initialize("", "span");
        // [225]  span.AddClass( {71} ) 
        _span.addclass("white-text name");
        // [226]  span.AddContent(UserName) 
        _span.addcontent(_username);
        // [227]  ui1.addcontent(span.html) 
        _ui1.addcontent(_span.html());
        // [228]  udiv.addcontent(ui1.html) 
        _udiv.addcontent(_ui1.html());
        // [231]  Dim ui2 As UOEHTML 
        _ui2 = new banano_uoebanano_uoehtml();
        // [232]  ui2.initialize( {72} , {73} ) 
        _ui2.initialize("", "a");
        // [233]  ui2.AddAttribute( {74} , {5} ) 
        _ui2.addattribute("href", "mailto:" + _useremail + "");
        // [234]  Dim span1 As UOEHTML 
        _span1 = new banano_uoebanano_uoehtml();
        // [235]  span1.Initialize( {75} , {76} ) 
        _span1.initialize("", "span");
        // [236]  span1.AddClass( {77} ) 
        _span1.addclass("white-text email");
        // [237]  span1.AddContent(UserEmail) 
        _span1.addcontent(_useremail);
        // [238]  ui2.addcontent(span1.html) 
        _ui2.addcontent(_span1.html());
        // [239]  udiv.addcontent(ui2.html) 
        _udiv.addcontent(_ui2.html());
        // [240]  uli.addcontent(udiv.html) 
        _uli.addcontent(_udiv.html());
        // [241]  Items.Add(uli.HTML) 
        self._items.push(_uli.html());
        // End Sub
    };

    // [245] Sub AddDivider 
    this.adddivider = function () {
        if (self == null) self = this;
        var _md;
        // [246]  Dim md As UOEDivider 
        _md = new banano_uoebanano_uoedivider();
        // [247]  md.Initialize(App, {78} , {79} ) 
        _md.initialize(self._app, "", "");
        // [248]  Items.Add(md.tostring) 
        self._items.push(_md.tostring());
        // End Sub
    };

    // [265] Sub AddItem(itemID As String, iconName As String, itemText As String, itemNavigateTo As String, bHasDivider As Boolean, itemTheme As String,iconTheme As String) 
    this.additem = function (_itemid, _iconname, _itemtext, _itemnavigateto, _bhasdivider, _itemtheme, _icontheme) {
        if (self == null) self = this;
        // [266]  If hascollapse = False Then AddCollapsible 
        if (self._hascollapse == false) {
            self.addcollapsible();
        }
        // [267]  mc.AddItem(itemID,iconName,itemText, {89} ,False,itemNavigateTo,itemTheme,iconTheme,bHasDivider) 
        self._mc.additem(_itemid, _iconname, _itemtext, "", false, _itemnavigateto, _itemtheme, _icontheme, _bhasdivider);
        // End Sub
    };

    // [271] Sub AddItemImage(itemID As String, imgURL As String, imgCircle As Boolean, itemText As String, href As String, bHasDivider As Boolean, itemTheme As String) 
    this.additemimage = function (_itemid, _imgurl, _imgcircle, _itemtext, _href, _bhasdivider, _itemtheme) {
        if (self == null) self = this;
        var _li;
        var _span;
        // [272]  itemID = itemID.tolowercase 
        _itemid = _itemid.toLowerCase();
        // [274]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [275]  li.Initialize(itemID, {90} ) 
        _li.initialize(_itemid, "li");
        // [276]  li.AddClass( {91} ) 
        _li.addclass("avatar");
        // [277]  li.AddClass( {92} ) 
        _li.addclass("no-padding");
        // [278]  li.MaterialWavesEffect(True) 
        _li.materialwaveseffect(true);
        // [280]  modUOE.MaterialAddImage(App,li,imgURL, {93} ,App.ImageHW,App.ImageHW,imgCircle,True,True,App.ImageTopMargin) 
        _banano_uoebanano_moduoe.materialaddimage(self._app, _li, _imgurl, "", self._app._imagehw, self._app._imagehw, _imgcircle, true, true, self._app._imagetopmargin);
        // [281]  li.AddClass( {94} ) 
        _li.addclass("waves-effect");
        // [282]  App.MaterialUseTheme(itemTheme,li) 
        self._app.materialusetheme(_itemtheme, _li);
        // [283]  li.AddAttribute( {95} ,href) 
        _li.addattribute("href", _href);
        // [285]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [286]  span.Initialize(itemID & {96} , {97} ) 
        _span.initialize(_itemid + "-title", "span");
        // [287]  span.AddClass( {98} ) 
        _span.addclass("title");
        // [288]  span.AddContent(itemText) 
        _span.addcontent(_itemtext);
        // [289]  App.MaterialUseTheme(itemTheme,span) 
        self._app.materialusetheme(_itemtheme, _span);
        // [290]  span.AddStyleAttribute( {99} , {100} ) 
        _span.addstyleattribute("vertical-align", "top");
        // [291]  li.AddContent(span.HTML) 
        _li.addcontent(_span.html());
        // [292]  li.MaterialAddDividerOnCondition(bHasDivider,App.EnumVisibility.visible,itemTheme) 
        _li.materialadddivideroncondition(_bhasdivider, self._app._enumvisibility._visible, _itemtheme);
        // [293]  Items.Add(li.HTML) 
        self._items.push(_li.html());
        // End Sub
    };

    // [297] private Sub AddCollapsible() 
    this.addcollapsible = function () {
        if (self == null) self = this;
        var _skey;
        var _kpos;
        // [298]  Dim skey As String = {6} 
        _skey = "" + self._id + "collapse";
        // [299]  Dim kPos As Int = Items.IndexOf(skey) 
        _kpos = self._items.indexOf(_skey);
        // [300]  If kPos = -1 Then 
        if (_kpos == -1) {
            // [301]  Items.Add(ID & {101} ) 
            self._items.push(self._id + "collapse");
            // [302]  End If 
        }
        // End Sub
    };

}
// =========================== UOESlider  ===========================
function banano_uoebanano_uoeslider() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._element = new banano_uoebanano_uoehtml();

    this._items = [];

    this._enabled = false;

    this._id = '';

    this._theme = '';

    this._visibility = '';

    this._zdepth = '';

    this._slides = new banano_uoebanano_uoehtml();

    this._indicators = false;

    this._height = '';

    this._transition = '';

    this._interval = '';

    this._hoverable = false;

    this._fullscreen = false;

    this._instance = '';

    // [24] Sub AddStyleAttribute(attribute As String, value As String) As UOESlider 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [25]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [30] Sub AddClass(sClass As String) As UOESlider 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [31]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [32]  Return Me 
        return self;
        // End Sub
    };

    // [36] Sub RemoveClass(sClass As String) As UOESlider 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [37]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [38]  Return Me 
        return self;
        // End Sub
    };

    // [42] Sub AddAttribute(attr As String, value As String) As UOESlider 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [43]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [44]  Return Me 
        return self;
        // End Sub
    };

    // [48] Sub RemoveAttribute(attr As String) As UOESlider 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [49]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [50]  Return Me 
        return self;
        // End Sub
    };

    // [54] Public Sub Initialize(thisApp As UOEApp, mvarID As String) 
    this.initialize = function (_thisapp, _mvarid) {
        if (self == null) self = this;
        // [56]  App = thisApp 
        self._app = _thisapp;
        // [57]  ID = mvarID.tolowercase 
        self._id = _mvarid.toLowerCase();
        // [58]  Element.Initialize(ID, {7} ) 
        self._element.initialize(self._id, "div");
        // [59]  Items.Initialize 
        self._items.length = 0;
        // [60]  Items.clear 
        self._items.length = 0;
        // [61]  Enabled = True 
        self._enabled = true;
        // [62]  Indicators = True 
        self._indicators = true;
        // [63]  Transition = {8} 
        self._transition = "500";
        // [64]  Height = {9} 
        self._height = "400";
        // [65]  Interval = {10} 
        self._interval = "6000";
        // [66]  Theme = {11} 
        self._theme = "";
        // [67]  Visibility = {12} 
        self._visibility = "";
        // [68]  ZDepth = {13} 
        self._zdepth = "";
        // [69]  Slides.Initialize(ID & {14} , {15} ) 
        self._slides.initialize(self._id + "slides", "ul");
        // [70]  Slides.addclass( {16} ) 
        self._slides.addclass("slides");
        // [71]  FullScreen = False 
        self._fullscreen = false;
        // [72]  Instance = {0} 
        self._instance = "" + self._id + "inst";
        // End Sub
    };

    // [76] Sub AddSlide(slideID As String, imgURL As String, Title As String, Alignment As String, Description As String, titleTheme As String, descriptionTheme As String) 
    this.addslide = function (_slideid, _imgurl, _title, _alignment, _description, _titletheme, _descriptiontheme) {
        if (self == null) self = this;
        var _li;
        var _img;
        var _content;
        var _h3;
        var _h5;
        // [78]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [79]  li.Initialize(slideID, {17} ) 
        _li.initialize(_slideid, "li");
        // [81]  Dim img As UOEImage 
        _img = new banano_uoebanano_uoeimage();
        // [82]  img.Initialize(App,slideID & {18} ,imgURL, {19} ,True) 
        _img.initialize(self._app, _slideid + "img", _imgurl, "", true);
        // [85]  img.Element.AddStyleAttribute( {22} , {23} ) 
        _img._element.addstyleattribute("object-fit", "contain");
        // [86]  li.AddContent(img.tostring) 
        _li.addcontent(_img.tostring());
        // [88]  Dim content As UOEHTML 
        _content = new banano_uoebanano_uoehtml();
        // [89]  content.Initialize(slideID & {24} , {25} ) 
        _content.initialize(_slideid + "content", "div");
        // [90]  content.addclass( {26} ) 
        _content.addclass("caption");
        // [91]  content.MaterialAlignText(Alignment) 
        _content.materialaligntext(_alignment);
        // [93]  Dim h3 As UOEHTML 
        _h3 = new banano_uoebanano_uoehtml();
        // [94]  h3.Initialize( {27} , {28} ) 
        _h3.initialize("", "h3");
        // [95]  h3.AddContent(Title) 
        _h3.addcontent(_title);
        // [96]  App.MaterialUseTheme(titleTheme,h3) 
        self._app.materialusetheme(_titletheme, _h3);
        // [98]  Dim h5 As UOEHTML 
        _h5 = new banano_uoebanano_uoehtml();
        // [99]  h5.Initialize( {29} , {30} ) 
        _h5.initialize("", "h5");
        // [100]  h5.AddContent(Description) 
        _h5.addcontent(_description);
        // [101]  App.MaterialUseTheme(descriptionTheme,h5) 
        self._app.materialusetheme(_descriptiontheme, _h5);
        // [103]  content.AddContent(h3.HTML) 
        _content.addcontent(_h3.html());
        // [104]  content.AddContent(h5.HTML) 
        _content.addcontent(_h5.html());
        // [107]  li.AddContent(content.HTML) 
        _li.addcontent(_content.html());
        // [108]  Slides.addcontent(li.HTML) 
        self._slides.addcontent(_li.html());
        // End Sub
    };

    // [112] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [113]  Element.ID = ID 
        self._element._id = self._id;
        // [114]  Slides.ID = ID & {31} 
        self._slides._id = self._id + "slides";
        // [115]  Element.AddClass( {32} ) 
        self._element.addclass("slider");
        // [116]  Element.AddClassOnCondition(FullScreen, {33} ) 
        self._element.addclassoncondition(self._fullscreen, "fullscreen");
        // [117]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [118]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [119]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [120]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [121]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [122]  Element.AddContent(Slides.HTML) 
        self._element.addcontent(self._slides.html());
        // [127]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

    // [138] Sub getSettings As String 
    this.getsettings = function () {
        if (self == null) self = this;
        var _ms;
        var _str;
        // [139]  Dim ms As Map 
        _ms = {};
        // [140]  ms.Initialize 
        _ms = {};
        // [141]  ms.clear 
        _ms = {};
        // [142]  ms.Put( {36} , ID) 
        _ms["id"] = self._id;
        // [143]  ms.Put( {37} , {38} ) 
        _ms["instance"] = "slider";
        // [144]  ms.put( {39} , Indicators) 
        _ms["indicators"] = self._indicators;
        // [145]  ms.Put( {40} , Height) 
        _ms["height"] = self._height;
        // [146]  ms.Put( {41} , Transition) 
        _ms["transition"] = self._transition;
        // [147]  ms.Put( {42} , Interval) 
        _ms["interval"] = self._interval;
        // [148]  Dim str As String = App.Map2Json(ms) 
        _str = self._app.map2json(_ms);
        // [149]  Return str 
        return _str;
        // End Sub
    };

    // [153] Sub NextSlide() As String 
    this.nextslide = function () {
        if (self == null) self = this;
        var _script;
        // [154]  Dim script As String = {3} 
        _script = "" + self._instance + ".next();";
        // [155]  Return script 
        return _script;
        // End Sub
    };

    // [159] Sub PreviousSlide() As String 
    this.previousslide = function () {
        if (self == null) self = this;
        var _script;
        // [160]  Dim script As String = {4} 
        _script = "" + self._instance + ".prev();";
        // [161]  Return script 
        return _script;
        // End Sub
    };

    // [165] Sub Start() As String 
    this.start = function () {
        if (self == null) self = this;
        var _script;
        // [166]  Dim script As String = {5} 
        _script = "" + self._instance + ".start();";
        // [167]  Return script 
        return _script;
        // End Sub
    };

    // [171] Sub Pause() As String 
    this.pause = function () {
        if (self == null) self = this;
        var _script;
        // [172]  Dim script As String = {6} 
        _script = "" + self._instance + ".pause();";
        // [173]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOESpan  ===========================
function banano_uoebanano_uoespan() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._span = new banano_uoebanano_uoehtml();

    this._verticalalign = false;

    this._visibility = '';

    this._text = '';

    this._theme = '';

    this._hoverable = false;

    // [15] Public Sub Initialize(thisApp As UOEApp, sid As String, sText As String, bVerticalAlign As Boolean, sVisibility As String, themeName As String) As UOESpan 
    this.initialize = function (_thisapp, _sid, _stext, _bverticalalign, _svisibility, _themename) {
        if (self == null) self = this;
        // [17]  App = thisApp 
        self._app = _thisapp;
        // [18]  span.Initialize(sid, {0} ) 
        self._span.initialize(_sid, "span");
        // [19]  VerticalAlign = bVerticalAlign 
        self._verticalalign = _bverticalalign;
        // [20]  Text = sText 
        self._text = _stext;
        // [21]  Theme = themeName 
        self._theme = _themename;
        // [22]  Visibility = sVisibility 
        self._visibility = _svisibility;
        // [23]  Return Me 
        return self;
        // End Sub
    };

    // [27] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [28]  span.ID = ID 
        self._span._id = self._id;
        // [29]  span.AddStyleAttributeOnCondition(VerticalAlign, {1} , {2} ) 
        self._span.addstyleattributeoncondition(self._verticalalign, "vertical-align", "top");
        // [30]  span.MaterialVisibility(Visibility) 
        self._span.materialvisibility(self._visibility);
        // [31]  span.AddContent(Text) 
        self._span.addcontent(self._text);
        // [32]  App.MaterialUseTheme(Theme,span) 
        self._app.materialusetheme(self._theme, self._span);
        // [33]  Return span.html 
        return self._span.html();
        // End Sub
    };

    // [38] Sub RemoveClass(sClass As String) As UOESpan 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [39]  span.RemoveClass(sClass) 
        self._span.removeclass(_sclass);
        // [40]  Return Me 
        return self;
        // End Sub
    };

    // [44] Sub AddAttribute(attr As String, value As String) As UOESpan 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [45]  span.AddAttribute(attr,value) 
        self._span.addattribute(_attr, _value);
        // [46]  Return Me 
        return self;
        // End Sub
    };

    // [50] Sub RemoveAttribute(attr As String) As UOESpan 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [51]  span.RemoveAttribute(attr) 
        self._span.removeattribute(_attr);
        // [52]  Return Me 
        return self;
        // End Sub
    };

    // [56] Sub AddClass(sClass As String) As UOESpan 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [57]  span.AddClass(sClass) 
        self._span.addclass(_sclass);
        // [58]  Return Me 
        return self;
        // End Sub
    };

    // [62] Sub AddStyleAttribute(attribute As String, value As String) As UOESpan 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [63]  span.AddStyleAttribute(attribute,value) 
        self._span.addstyleattribute(_attribute, _value);
        // [64]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOESwitch  ===========================
function banano_uoebanano_uoeswitch() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._ontext = '';

    this._offtext = '';

    this._enabled = false;

    this._switch = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._title = '';

    this._visibility = '';

    this._zdepth = '';

    this._theme = '';

    this._showtitle = false;

    this._checked = false;

    // [22] Sub AddStyleAttribute(attribute As String, value As String) As UOESwitch 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [23]  switch.AddStyleAttribute(attribute,value) 
        self._switch.addstyleattribute(_attribute, _value);
        // [24]  Return Me 
        return self;
        // End Sub
    };

    // [29] Public Sub Initialize(thisApp As UOEApp,sid As String, sTitle As String, sOnText As String, sOffText As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _stitle, _sontext, _sofftext, _themename) {
        if (self == null) self = this;
        // [31]  App = thisApp 
        self._app = _thisapp;
        // [32]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [33]  OnText = sOnText 
        self._ontext = _sontext;
        // [34]  OffText = sOffText 
        self._offtext = _sofftext;
        // [35]  switch.Initialize(ID, {1} ) 
        self._switch.initialize(self._id, "div");
        // [36]  switch.AddClass( {2} ) 
        self._switch.addclass("switch");
        // [37]  Title = sTitle 
        self._title = _stitle;
        // [38]  theme = themeName 
        self._theme = _themename;
        // [39]  Enabled = True 
        self._enabled = true;
        // [40]  ShowTitle = True 
        self._showtitle = true;
        // [41]  Checked = False 
        self._checked = false;
        // End Sub
    };

    // [46] Sub RemoveClass(sClass As String) As UOESwitch 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [47]  switch.RemoveClass(sClass) 
        self._switch.removeclass(_sclass);
        // [48]  Return Me 
        return self;
        // End Sub
    };

    // [52] Sub AddAttribute(attr As String, value As String) As UOESwitch 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [53]  switch.AddAttribute(attr,value) 
        self._switch.addattribute(_attr, _value);
        // [54]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub RemoveAttribute(attr As String) As UOESwitch 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [59]  switch.RemoveAttribute(attr) 
        self._switch.removeattribute(_attr);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub AddClass(sClass As String) As UOESwitch 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [65]  switch.AddClass(sClass) 
        self._switch.addclass(_sclass);
        // [66]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _lbl;
        var _inp;
        var _span;
        var _p;
        // [71]  switch.MaterialEnable(Enabled) 
        self._switch.materialenable(self._enabled);
        // [72]  switch.MaterialZDepth(ZDepth) 
        self._switch.materialzdepth(self._zdepth);
        // [73]  switch.MaterialVisibility(Visibility) 
        self._switch.materialvisibility(self._visibility);
        // [74]  App.ApplyToolTip(ID,switch) 
        self._app.applytooltip(self._id, self._switch);
        // [75]  switch.ID = ID 
        self._switch._id = self._id;
        // [76]  Dim lbl As UOEHTML 
        _lbl = new banano_uoebanano_uoehtml();
        // [77]  lbl.Initialize( {3} , {4} ) 
        _lbl.initialize("", "label");
        // [78]  lbl.AddContent(OffText) 
        _lbl.addcontent(self._offtext);
        // [79]  Dim inp As UOEHTML 
        _inp = new banano_uoebanano_uoehtml();
        // [80]  inp.Initialize( {0} , {5} ) 
        _inp.initialize("" + self._id + "inp", "input");
        // [81]  inp.AddAttribute( {6} , {7} ) 
        _inp.addattribute("type", "checkbox");
        // [82]  inp.AddAttributeOnCondition(Not(Enabled), {8} , {9} ) 
        _inp.addattributeoncondition(!(self._enabled), "disabled", "true");
        // [83]  inp.AddAttributeOnCondition(Checked, {10} , {11} ) 
        _inp.addattributeoncondition(self._checked, "checked", "checked");
        // [84]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [85]  span.Initialize(ID & {12} , {13} ) 
        _span.initialize(self._id + "-span", "span");
        // [86]  span.AddClass( {14} ) 
        _span.addclass("lever");
        // [87]  lbl.AddContent(inp.HTML) 
        _lbl.addcontent(_inp.html());
        // [88]  lbl.AddContent(span.HTML) 
        _lbl.addcontent(_span.html());
        // [89]  lbl.AddContent(OnText) 
        _lbl.addcontent(self._ontext);
        // [90]  switch.AddContent(lbl.HTML) 
        self._switch.addcontent(_lbl.html());
        // [91]  If ShowTitle = False Then Return switch.HTML 
        if (self._showtitle == false) {
            return self._switch.html();
        }
        // [92]  Dim p As UOEHTML 
        _p = new banano_uoebanano_uoehtml();
        // [93]  p.Initialize( {15} , {16} ) 
        _p.initialize("", "p");
        // [94]  Dim lbl As UOEHTML 
        _lbl = new banano_uoebanano_uoehtml();
        // [95]  lbl.Initialize(ID & {17} , {18} ) 
        _lbl.initialize(self._id + "lbl", "label");
        // [96]  lbl.SetFOR(ID).AddContent(Title) 
        _lbl.setfor(self._id).addcontent(self._title);
        // [97]  App.MaterialUseTheme(theme,lbl) 
        self._app.materialusetheme(self._theme, _lbl);
        // [98]  p.AddElement(lbl) 
        _p.addelement(_lbl);
        // [99]  p.AddContent(switch.HTML) 
        _p.addcontent(self._switch.html());
        // [104]  Return p.html 
        return _p.html();
        // End Sub
    };

}
// =========================== UOETable  ===========================
function banano_uoebanano_uoetable() {
    var self;
    this._id = '';

    this._app = new banano_uoebanano_uoeapp();

    this._zdepth = '';

    this._visibility = '';

    this._enabled = false;

    this._el = new banano_uoebanano_uoehtml();

    this._hoverable = false;

    this._thead = new banano_uoebanano_uoehtml();

    this._tbody = new banano_uoebanano_uoehtml();

    this._rows = [];

    this._striped = false;

    this._highlight = false;

    this._centered = false;

    this._responsive = false;

    this._tfoot = new banano_uoebanano_uoehtml();

    this._ptable = new banano_uoebanano_uoecontainer();

    this._headers = {};

    this._hasborder = false;

    this._overflow = false;

    this._onrowclick = '';

    this._activerow = '';

    this._caption = '';

    this._headerrows = [];

    this._footerrows = [];

    this._canexport = false;

    this._j = "$";

    this._fields = [];

    this._columns = {};

    // [37] Sub getTableHeading(colName As String) As UOETableHeading 
    this.gettableheading = function (_colname) {
        if (self == null) self = this;
        var _hdr;
        var _hdrcnt;
        var _hdrstr;
        // [38]  Dim hdr As UOETableHeading 
        _hdr = new banano_uoebanano_uoetableheading();
        // [39]  Dim hdrCnt As Int = Fields.IndexOf(colName) 
        _hdrcnt = self._fields.indexOf(_colname);
        // [40]  If hdrCnt >= 0 Then 
        if (_hdrcnt >= 0) {
            // [41]  Dim hdrStr As String = {0} 
            _hdrstr = "head" + _hdrcnt + "";
            // [42]  hdr = Columns.Get(hdrStr) 
            _hdr = self._columns[_hdrstr];
            // [43]  End If 
        }
        // [44]  Return hdr 
        return _hdr;
        // End Sub
    };

    // [53] Sub Export2Json() As String 
    this.export2json = function () {
        if (self == null) self = this;
        var _script;
        // [54]  CanExport = True 
        self._canexport = true;
        // [55]  Dim script As String = {1} 
        _script = "" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'json',filename:'" + self._id + ".json'});";
        // [56]  Return script 
        return _script;
        // End Sub
    };

    // [60] Sub Export2CSV() As String 
    this.export2csv = function () {
        if (self == null) self = this;
        var _script;
        // [61]  CanExport = True 
        self._canexport = true;
        // [62]  Dim script As String = {2} 
        _script = "" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'csv',filename:'" + self._id + ".csv'});";
        // [63]  Return script 
        return _script;
        // End Sub
    };

    // [67] Sub Export2Txt() As String 
    this.export2txt = function () {
        if (self == null) self = this;
        var _script;
        // [68]  CanExport = True 
        self._canexport = true;
        // [69]  Dim script As String = {3} 
        _script = "" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'txt',filename:'" + self._id + ".txt'});";
        // [70]  Return script 
        return _script;
        // End Sub
    };

    // [74] Sub Export2PDF() As String 
    this.export2pdf = function () {
        if (self == null) self = this;
        var _script;
        // [75]  CanExport = True 
        self._canexport = true;
        // [76]  Dim script As String = {4} 
        _script = "" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'pdf',filename:'" + self._id + ".pdf'});";
        // [77]  Return script 
        return _script;
        // End Sub
    };

    // [81] Sub TableExport() As String 
    this.tableexport = function () {
        if (self == null) self = this;
        var _script;
        // [82]  Dim script As String = {5} 
        _script = "" + self._j + "(\"" + self._id + "\").tableExport();";
        // [83]  Return script 
        return _script;
        // End Sub
    };

    // [87] Sub GetRows(varName As String) As String 
    this.getrows = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [88]  Dim script As String = {6} 
        _script = "" + _varname + " = getRows" + self._id + "();";
        // [89]  Return script 
        return _script;
        // End Sub
    };

    // [93] Sub AddStyleAttribute(attribute As String, value As String) As UOETable 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [94]  el.AddStyleAttribute(attribute,value) 
        self._el.addstyleattribute(_attribute, _value);
        // [95]  Return Me 
        return self;
        // End Sub
    };

    // [99] Public Sub Initialize(thisApp As UOEApp, sID As String, cClass As String) 
    this.initialize = function (_thisapp, _sid, _cclass) {
        if (self == null) self = this;
        // [100]  App = thisApp 
        self._app = _thisapp;
        // [101]  ID = sID.ToLowerCase 
        self._id = _sid.toLowerCase();
        // [102]  pTable.Initialize(App,ID & {39} ,False, {40} ) 
        self._ptable.initialize(self._app, self._id + "p", false, "");
        // [103]  pTable.AddRowsM(1,0,0, {41} , {42} ).AddColumnsOSMP(1,0,0,0,12,12,12,0,0,0,0, {43} , {44} ) 
        self._ptable.addrowsm(1, 0, 0, "", "").addcolumnsosmp(1, 0, 0, 0, 12, 12, 12, 0, 0, 0, 0, "", "");
        // [104]  el.Initialize(ID, {45} ) 
        self._el.initialize(self._id, "table");
        // [105]  el.AddClass(cClass).SetNAME(ID) 
        self._el.addclass(_cclass).setname(self._id);
        // [106]  el.AddStyleAttribute( {46} , {47} ) 
        self._el.addstyleattribute("border-collapse", "collapse");
        // [107]  thead.Initialize( {7} , {48} ) 
        self._thead.initialize("" + self._id + "thead", "thead");
        // [108]  tbody.Initialize( {8} , {49} ) 
        self._tbody.initialize("" + self._id + "body", "tbody");
        // [109]  tfoot.Initialize( {9} , {50} ) 
        self._tfoot.initialize("" + self._id + "foot", "tfoot");
        // [110]  Fields.Initialize 
        self._fields.length = 0;
        // [111]  Fields.clear 
        self._fields.length = 0;
        // [112]  Rows.Initialize 
        self._rows.length = 0;
        // [113]  Rows.clear 
        self._rows.length = 0;
        // [114]  Columns.Initialize 
        self._columns = {};
        // [115]  Columns.clear 
        self._columns = {};
        // [116]  Enabled = True 
        self._enabled = true;
        // [117]  Striped = False 
        self._striped = false;
        // [118]  Highlight = False 
        self._highlight = false;
        // [119]  Headers.Initialize 
        self._headers = {};
        // [120]  Headers.clear 
        self._headers = {};
        // [121]  HasBorder = True 
        self._hasborder = true;
        // [122]  OverFlow = False 
        self._overflow = false;
        // [123]  OnRowClick = {51} 
        self._onrowclick = "";
        // [124]  ActiveRow = {52} 
        self._activerow = "activerow";
        // [125]  Caption = {53} 
        self._caption = "";
        // [126]  HeaderRows.Initialize 
        self._headerrows.length = 0;
        // [127]  HeaderRows.clear 
        self._headerrows.length = 0;
        // [128]  FooterRows.Initialize 
        self._footerrows.length = 0;
        // [129]  FooterRows.clear 
        self._footerrows.length = 0;
        // [130]  CanExport = False 
        self._canexport = false;
        // End Sub
    };

    // [134] Sub AddHeading(rowField As List,rowTitle As List, rowAlignment As List, rowTheme As List, rowClass As List, colSpan As List,colTag As List) 
    this.addheading = function (_rowfield, _rowtitle, _rowalignment, _rowtheme, _rowclass, _colspan, _coltag) {
        if (self == null) self = this;
        var _rtot;
        var _rkey;
        var _hr;
        var _hdrtot;
        var _hdrcnt;
        var _fldname;
        var _td;
        var _strcolspan;
        var _scode;
        // [135]  Dim rTot As Int = HeaderRows.Size + 1 
        _rtot = self._headerrows.length + 1;
        // [136]  Dim rKey As String = {10} 
        _rkey = "rh" + _rtot + "";
        // [137]  Dim hr As UOEHTML 
        _hr = new banano_uoebanano_uoehtml();
        // [138]  hr.Initialize(rKey, {54} ) 
        _hr.initialize(_rkey, "tr");
        // [140]  Dim hdrTot As Int = rowField.Size - 1 
        _hdrtot = _rowfield.length - 1;
        // [141]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [142]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [143]  Dim fldName As String = rowField.Get(hdrCnt) 
            _fldname = _rowfield[_hdrcnt];
            // [144]  Dim td As UOEHTML 
            _td = new banano_uoebanano_uoehtml();
            // [145]  td.Initialize( {55} , {56} ) 
            _td.initialize("", "td");
            // [146]  td.setname(fldName) 
            _td.setname(_fldname);
            // [147]  td.AddClass(fldName) 
            _td.addclass(_fldname);
            // [148]  If colTag <> Null And hdrCnt <= colTag.Size Then 
            if (_coltag != null && _hdrcnt <= _coltag.length) {
                // [149]  td.SetTag(colTag.Get(hdrCnt)) 
                _td.settag(_coltag[_hdrcnt]);
                // [150]  End If 
            }
            // [151]  If rowTitle <> Null And hdrCnt <= rowTitle.Size Then 
            if (_rowtitle != null && _hdrcnt <= _rowtitle.length) {
                // [152]  td.AddContent(rowTitle.Get(hdrCnt)) 
                _td.addcontent(_rowtitle[_hdrcnt]);
                // [153]  End If 
            }
            // [154]  If rowTheme <> Null And hdrCnt <= rowTheme.Size Then 
            if (_rowtheme != null && _hdrcnt <= _rowtheme.length) {
                // [155]  App.materialusetheme(rowTheme.Get(hdrCnt),td) 
                self._app.materialusetheme(_rowtheme[_hdrcnt], _td);
                // [156]  End If 
            }
            // [157]  If rowAlignment <> Null And hdrCnt <= rowAlignment.Size Then 
            if (_rowalignment != null && _hdrcnt <= _rowalignment.length) {
                // [158]  td.AddStyleAttribute( {57} , rowAlignment.Get(hdrCnt)) 
                _td.addstyleattribute("text-align", _rowalignment[_hdrcnt]);
                // [159]  End If 
            }
            // [160]  If rowClass <> Null And hdrCnt <= rowClass.Size Then 
            if (_rowclass != null && _hdrcnt <= _rowclass.length) {
                // [161]  td.AddClass(rowClass.Get(hdrCnt)) 
                _td.addclass(_rowclass[_hdrcnt]);
                // [162]  End If 
            }
            // [163]  If colSpan <> Null And hdrCnt <= colSpan.Size Then 
            if (_colspan != null && _hdrcnt <= _colspan.length) {
                // [164]  Dim strColSpan As String = colSpan.Get(hdrCnt) 
                _strcolspan = _colspan[_hdrcnt];
                // [165]  If strColSpan.Length > 0 Then 
                if (_strcolspan.length > 0) {
                    // [166]  td.AddAttribute( {58} ,strColSpan) 
                    _td.addattribute("colspan", _strcolspan);
                    // [167]  End If 
                }
                // [168]  End If 
            }
            // [170]  hr.AddElement(td) 
            _hr.addelement(_td);
            // [171]  Next 
        }
        // [172]  Dim scode As String = hr.tostring 
        _scode = _hr.tostring();
        // [173]  scode = scode.Replace(CRLF, {59} ) 
        _scode = _scode.split("\n").join("");
        // [174]  HeaderRows.Add(scode) 
        self._headerrows.push(_scode);
        // End Sub
    };

    // [178] Sub AddBody(rowField As List,rowTitle As List, rowAlignment As List, rowTheme As List, rowClass As List, colSpan As List,colTag As List) 
    this.addbody = function (_rowfield, _rowtitle, _rowalignment, _rowtheme, _rowclass, _colspan, _coltag) {
        if (self == null) self = this;
        var _rtot;
        var _rkey;
        var _hr;
        var _hdrtot;
        var _hdrcnt;
        var _fldname;
        var _td;
        var _strcolspan;
        var _scode;
        // [179]  Dim rTot As Int = Rows.Size + 1 
        _rtot = self._rows.length + 1;
        // [180]  Dim rKey As String = {11} 
        _rkey = "rb" + _rtot + "";
        // [181]  Dim hr As UOEHTML 
        _hr = new banano_uoebanano_uoehtml();
        // [182]  hr.Initialize(rKey, {60} ) 
        _hr.initialize(_rkey, "tr");
        // [184]  Dim hdrTot As Int = rowField.Size - 1 
        _hdrtot = _rowfield.length - 1;
        // [185]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [186]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [187]  Dim fldName As String = rowField.Get(hdrCnt) 
            _fldname = _rowfield[_hdrcnt];
            // [188]  Dim td As UOEHTML 
            _td = new banano_uoebanano_uoehtml();
            // [189]  td.Initialize( {61} , {62} ) 
            _td.initialize("", "td");
            // [190]  td.setname(fldName) 
            _td.setname(_fldname);
            // [191]  td.AddClass(fldName) 
            _td.addclass(_fldname);
            // [192]  If colTag <> Null And hdrCnt <= colTag.Size Then 
            if (_coltag != null && _hdrcnt <= _coltag.length) {
                // [193]  td.SetTag(colTag.Get(hdrCnt)) 
                _td.settag(_coltag[_hdrcnt]);
                // [194]  End If 
            }
            // [195]  If rowTitle <> Null And hdrCnt <= rowTitle.Size Then 
            if (_rowtitle != null && _hdrcnt <= _rowtitle.length) {
                // [196]  td.AddContent(rowTitle.Get(hdrCnt)) 
                _td.addcontent(_rowtitle[_hdrcnt]);
                // [197]  End If 
            }
            // [198]  If rowTheme <> Null And hdrCnt <= rowTheme.Size Then 
            if (_rowtheme != null && _hdrcnt <= _rowtheme.length) {
                // [199]  App.materialusetheme(rowTheme.Get(hdrCnt),td) 
                self._app.materialusetheme(_rowtheme[_hdrcnt], _td);
                // [200]  End If 
            }
            // [201]  If rowAlignment <> Null And hdrCnt <= rowAlignment.Size Then 
            if (_rowalignment != null && _hdrcnt <= _rowalignment.length) {
                // [202]  td.AddStyleAttribute( {63} , rowAlignment.Get(hdrCnt)) 
                _td.addstyleattribute("text-align", _rowalignment[_hdrcnt]);
                // [203]  End If 
            }
            // [204]  If rowClass <> Null And hdrCnt <= rowClass.Size Then 
            if (_rowclass != null && _hdrcnt <= _rowclass.length) {
                // [205]  td.AddClass(rowClass.Get(hdrCnt)) 
                _td.addclass(_rowclass[_hdrcnt]);
                // [206]  End If 
            }
            // [207]  If colSpan <> Null And hdrCnt <= colSpan.Size Then 
            if (_colspan != null && _hdrcnt <= _colspan.length) {
                // [208]  Dim strColSpan As String = colSpan.Get(hdrCnt) 
                _strcolspan = _colspan[_hdrcnt];
                // [209]  If strColSpan.Length > 0 Then 
                if (_strcolspan.length > 0) {
                    // [210]  td.AddAttribute( {64} ,strColSpan) 
                    _td.addattribute("colspan", _strcolspan);
                    // [211]  End If 
                }
                // [212]  End If 
            }
            // [214]  hr.AddElement(td) 
            _hr.addelement(_td);
            // [215]  Next 
        }
        // [216]  Dim scode As String = hr.tostring 
        _scode = _hr.tostring();
        // [217]  scode = scode.Replace(CRLF, {65} ) 
        _scode = _scode.split("\n").join("");
        // [218]  Rows.Add(scode) 
        self._rows.push(_scode);
        // End Sub
    };

    // [222] Sub AddFooter(rowField As List,rowTitle As List, rowAlignment As List, rowTheme As List, rowClass As List, colSpan As List,colTag As List) 
    this.addfooter = function (_rowfield, _rowtitle, _rowalignment, _rowtheme, _rowclass, _colspan, _coltag) {
        if (self == null) self = this;
        var _rtot;
        var _rkey;
        var _hr;
        var _hdrtot;
        var _hdrcnt;
        var _fldname;
        var _td;
        var _strcolspan;
        var _scode;
        // [223]  Dim rTot As Int = FooterRows.Size + 1 
        _rtot = self._footerrows.length + 1;
        // [224]  Dim rKey As String = {12} 
        _rkey = "rb" + _rtot + "";
        // [225]  Dim hr As UOEHTML 
        _hr = new banano_uoebanano_uoehtml();
        // [226]  hr.Initialize(rKey, {66} ) 
        _hr.initialize(_rkey, "tr");
        // [228]  Dim hdrTot As Int = rowField.Size - 1 
        _hdrtot = _rowfield.length - 1;
        // [229]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [230]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [231]  Dim fldName As String = rowField.Get(hdrCnt) 
            _fldname = _rowfield[_hdrcnt];
            // [232]  Dim td As UOEHTML 
            _td = new banano_uoebanano_uoehtml();
            // [233]  td.Initialize( {67} , {68} ) 
            _td.initialize("", "td");
            // [234]  td.setname(fldName) 
            _td.setname(_fldname);
            // [235]  td.AddClass(fldName) 
            _td.addclass(_fldname);
            // [236]  If colTag <> Null And hdrCnt <= colTag.Size Then 
            if (_coltag != null && _hdrcnt <= _coltag.length) {
                // [237]  td.SetTag(colTag.Get(hdrCnt)) 
                _td.settag(_coltag[_hdrcnt]);
                // [238]  End If 
            }
            // [239]  If rowTitle <> Null And hdrCnt <= rowTitle.Size Then 
            if (_rowtitle != null && _hdrcnt <= _rowtitle.length) {
                // [240]  td.AddContent(rowTitle.Get(hdrCnt)) 
                _td.addcontent(_rowtitle[_hdrcnt]);
                // [241]  End If 
            }
            // [242]  If rowTheme <> Null And hdrCnt <= rowTheme.Size Then 
            if (_rowtheme != null && _hdrcnt <= _rowtheme.length) {
                // [243]  App.materialusetheme(rowTheme.Get(hdrCnt),td) 
                self._app.materialusetheme(_rowtheme[_hdrcnt], _td);
                // [244]  End If 
            }
            // [245]  If rowAlignment <> Null And hdrCnt <= rowAlignment.Size Then 
            if (_rowalignment != null && _hdrcnt <= _rowalignment.length) {
                // [246]  td.AddStyleAttribute( {69} , rowAlignment.Get(hdrCnt)) 
                _td.addstyleattribute("text-align", _rowalignment[_hdrcnt]);
                // [247]  End If 
            }
            // [248]  If rowClass <> Null And hdrCnt <= rowClass.Size Then 
            if (_rowclass != null && _hdrcnt <= _rowclass.length) {
                // [249]  td.AddClass(rowClass.Get(hdrCnt)) 
                _td.addclass(_rowclass[_hdrcnt]);
                // [250]  End If 
            }
            // [251]  If colSpan <> Null And hdrCnt <= colSpan.Size Then 
            if (_colspan != null && _hdrcnt <= _colspan.length) {
                // [252]  Dim strColSpan As String = colSpan.Get(hdrCnt) 
                _strcolspan = _colspan[_hdrcnt];
                // [253]  If strColSpan.Length > 0 Then 
                if (_strcolspan.length > 0) {
                    // [254]  td.AddAttribute( {70} ,strColSpan) 
                    _td.addattribute("colspan", _strcolspan);
                    // [255]  End If 
                }
                // [256]  End If 
            }
            // [258]  hr.AddElement(td) 
            _hr.addelement(_td);
            // [259]  Next 
        }
        // [260]  Dim scode As String = hr.tostring 
        _scode = _hr.tostring();
        // [261]  scode = scode.Replace(CRLF, {71} ) 
        _scode = _scode.split("\n").join("");
        // [262]  FooterRows.Add(scode) 
        self._footerrows.push(_scode);
        // End Sub
    };

    // [267] Sub AddFooterContainer(cont As UOEContainer) As UOETable 
    this.addfootercontainer = function (_cont) {
        if (self == null) self = this;
        // [268]  tfoot.AddContent(cont.ToString) 
        self._tfoot.addcontent(_cont.tostring());
        // [269]  Return Me 
        return self;
        // End Sub
    };

    // [273] Sub AddHeaderContainer(cont As UOEContainer) As UOETable 
    this.addheadercontainer = function (_cont) {
        if (self == null) self = this;
        // [274]  pTable.AddContainer(1,1,cont) 
        self._ptable.addcontainer(1, 1, _cont);
        // [275]  Return Me 
        return self;
        // End Sub
    };

    // [279] Sub AddHeadingsThemes(colThemes As List) As UOETable 
    this.addheadingsthemes = function (_colthemes) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th1;
        var _th;
        var _hasheader;
        // [280]  Dim hdrTot As Int = colThemes.Size - 1 
        _hdrtot = _colthemes.length - 1;
        // [281]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [282]  Dim hdrStr As String 
        _hdrstr = '';
        // [283]  Dim hdrName As String 
        _hdrname = '';
        // [284]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [285]  hdrStr = {13} 
            _hdrstr = "head" + _hdrcnt + "";
            // [286]  hdrName = colThemes.Get(hdrCnt) 
            _hdrname = _colthemes[_hdrcnt];
            // [287]  If hdrName = {72} Then 
            if (_hdrname == "") {
                // [288]  hdrName = App.theme 
                _hdrname = self._app._theme;
                // [289]  End If 
            }
            // [290]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [291]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [292]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [293]  If hasHeader Then 
            if (_hasheader) {
                // [294]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [295]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [296]  Else 
            } else {
                // [297]  th.Initialize(hdrStr, {73} ) 
                _th.initialize(_hdrstr, "th");
                // [298]  th1.Initialize 
                _th1.initialize();
                // [299]  End If 
            }
            // [301]  App.MaterialUseTheme(hdrName,th) 
            self._app.materialusetheme(_hdrname, _th);
            // [302]  th1.Theme = hdrName 
            _th1._theme = _hdrname;
            // [303]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [304]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [305]  Next 
        }
        // [306]  Return Me 
        return self;
        // End Sub
    };

    // [310] Sub AddHeadings(colTitles As List) As UOETable 
    this.addheadings = function (_coltitles) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th1;
        var _th;
        var _hasheader;
        // [311]  Dim hdrTot As Int = colTitles.Size - 1 
        _hdrtot = _coltitles.length - 1;
        // [312]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [313]  Dim hdrStr As String 
        _hdrstr = '';
        // [314]  Dim hdrName As String 
        _hdrname = '';
        // [315]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [316]  hdrStr = {14} 
            _hdrstr = "head" + _hdrcnt + "";
            // [317]  hdrName = colTitles.Get(hdrCnt) 
            _hdrname = _coltitles[_hdrcnt];
            // [318]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [319]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [320]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [321]  If hasHeader Then 
            if (_hasheader) {
                // [322]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [323]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [324]  Else 
            } else {
                // [325]  th.Initialize(hdrStr, {74} ) 
                _th.initialize(_hdrstr, "th");
                // [326]  th1.Initialize 
                _th1.initialize();
                // [327]  End If 
            }
            // [329]  th.AddContent(hdrName) 
            _th.addcontent(_hdrname);
            // [330]  th1.title = hdrName 
            _th1._title = _hdrname;
            // [331]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [332]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [333]  Next 
        }
        // [334]  Return Me 
        return self;
        // End Sub
    };

    // [338] Sub AddHeadingsFields(colFields As List) As UOETable 
    this.addheadingsfields = function (_colfields) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [339]  Dim hdrTot As Int = colFields.Size - 1 
        _hdrtot = _colfields.length - 1;
        // [340]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [341]  Dim hdrStr As String 
        _hdrstr = '';
        // [342]  Dim hdrName As String 
        _hdrname = '';
        // [343]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [344]  hdrStr = {15} 
            _hdrstr = "head" + _hdrcnt + "";
            // [345]  hdrName = colFields.Get(hdrCnt) 
            _hdrname = _colfields[_hdrcnt];
            // [346]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [347]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [348]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [349]  If hasHeader Then 
            if (_hasheader) {
                // [350]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [351]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [352]  Else 
            } else {
                // [353]  th.Initialize(hdrStr, {75} ) 
                _th.initialize(_hdrstr, "th");
                // [354]  th1.Initialize 
                _th1.initialize();
                // [355]  End If 
            }
            // [356]  th.setname(hdrName) 
            _th.setname(_hdrname);
            // [357]  th.AddClass(hdrName) 
            _th.addclass(_hdrname);
            // [358]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [359]  Fields.Add(hdrName) 
            self._fields.push(_hdrname);
            // [360]  th1.FieldName = hdrName 
            _th1._fieldname = _hdrname;
            // [361]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [362]  Next 
        }
        // [363]  Return Me 
        return self;
        // End Sub
    };

    // [368] Sub AddHeadingsHeights(colHeights As List) As UOETable 
    this.addheadingsheights = function (_colheights) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [369]  Dim hdrTot As Int = colHeights.Size - 1 
        _hdrtot = _colheights.length - 1;
        // [370]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [371]  Dim hdrStr As String 
        _hdrstr = '';
        // [372]  Dim hdrName As String 
        _hdrname = '';
        // [373]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [374]  hdrStr = {16} 
            _hdrstr = "head" + _hdrcnt + "";
            // [375]  hdrName = colHeights.Get(hdrCnt) 
            _hdrname = _colheights[_hdrcnt];
            // [376]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [377]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [378]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [379]  If hasHeader Then 
            if (_hasheader) {
                // [380]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [381]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [382]  Else 
            } else {
                // [383]  th.Initialize(hdrStr, {76} ) 
                _th.initialize(_hdrstr, "th");
                // [384]  th1.Initialize 
                _th1.initialize();
                // [385]  End If 
            }
            // [387]  th.AddStyleAttribute( {77} ,hdrName & {78} ) 
            _th.addstyleattribute("height", _hdrname + "px");
            // [388]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [389]  th1.Height = hdrName 
            _th1._height = _hdrname;
            // [390]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [391]  Next 
        }
        // [392]  Return Me 
        return self;
        // End Sub
    };

    // [396] Sub AddHeadingsAlignment(colAlign As List) As UOETable 
    this.addheadingsalignment = function (_colalign) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [397]  Dim hdrTot As Int = colAlign.Size - 1 
        _hdrtot = _colalign.length - 1;
        // [398]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [399]  Dim hdrStr As String 
        _hdrstr = '';
        // [400]  Dim hdrName As String 
        _hdrname = '';
        // [401]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [402]  hdrStr = {17} 
            _hdrstr = "head" + _hdrcnt + "";
            // [403]  hdrName = colAlign.Get(hdrCnt) 
            _hdrname = _colalign[_hdrcnt];
            // [404]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [405]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [406]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [407]  If hasHeader Then 
            if (_hasheader) {
                // [408]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [409]  th1 = Columns.get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [410]  Else 
            } else {
                // [411]  th.Initialize(hdrStr, {79} ) 
                _th.initialize(_hdrstr, "th");
                // [412]  th1.Initialize 
                _th1.initialize();
                // [413]  End If 
            }
            // [415]  th.AddStyleAttribute( {80} , hdrName) 
            _th.addstyleattribute("text-align", _hdrname);
            // [416]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [417]  th1.alignment = hdrName 
            _th1._alignment = _hdrname;
            // [418]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [419]  Next 
        }
        // [420]  Return Me 
        return self;
        // End Sub
    };

    // [424] Sub AddHeadingsClasses(colClass As List) As UOETable 
    this.addheadingsclasses = function (_colclass) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [425]  Dim hdrTot As Int = colClass.Size - 1 
        _hdrtot = _colclass.length - 1;
        // [426]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [427]  Dim hdrStr As String 
        _hdrstr = '';
        // [428]  Dim hdrName As String 
        _hdrname = '';
        // [429]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [430]  hdrStr = {18} 
            _hdrstr = "head" + _hdrcnt + "";
            // [431]  hdrName = colClass.Get(hdrCnt) 
            _hdrname = _colclass[_hdrcnt];
            // [432]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [433]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [434]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [435]  If hasHeader Then 
            if (_hasheader) {
                // [436]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [437]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [438]  Else 
            } else {
                // [439]  th.Initialize(hdrStr, {81} ) 
                _th.initialize(_hdrstr, "th");
                // [440]  th1.Initialize 
                _th1.initialize();
                // [441]  End If 
            }
            // [443]  th.addclass(hdrName) 
            _th.addclass(_hdrname);
            // [444]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [445]  th1.ClassName = hdrName 
            _th1._classname = _hdrname;
            // [446]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [447]  Next 
        }
        // [448]  Return Me 
        return self;
        // End Sub
    };

    // [453] Sub AddHeadingsWidths(colWidths As List) As UOETable 
    this.addheadingswidths = function (_colwidths) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [454]  Dim hdrTot As Int = colWidths.Size - 1 
        _hdrtot = _colwidths.length - 1;
        // [455]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [456]  Dim hdrStr As String 
        _hdrstr = '';
        // [457]  Dim hdrName As String 
        _hdrname = '';
        // [458]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [459]  hdrStr = {19} 
            _hdrstr = "head" + _hdrcnt + "";
            // [460]  hdrName = colWidths.Get(hdrCnt) 
            _hdrname = _colwidths[_hdrcnt];
            // [461]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [462]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [463]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [464]  If hasHeader Then 
            if (_hasheader) {
                // [465]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [466]  th1 = Columns.get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [467]  Else 
            } else {
                // [468]  th.Initialize(hdrStr, {82} ) 
                _th.initialize(_hdrstr, "th");
                // [469]  th1.Initialize 
                _th1.initialize();
                // [470]  End If 
            }
            // [472]  th.AddStyleAttribute( {83} ,hdrName & {84} ) 
            _th.addstyleattribute("width", _hdrname + "px");
            // [473]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [474]  th1.Width = hdrName 
            _th1._width = _hdrname;
            // [475]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [476]  Next 
        }
        // [477]  Return Me 
        return self;
        // End Sub
    };

    // [481] Sub AddHeadingsVisibility(colVisibility As List) As UOETable 
    this.addheadingsvisibility = function (_colvisibility) {
        if (self == null) self = this;
        var _hdrtot;
        var _hdrcnt;
        var _hdrstr;
        var _hdrname;
        var _th;
        var _th1;
        var _hasheader;
        // [482]  Dim hdrTot As Int = colVisibility.Size - 1 
        _hdrtot = _colvisibility.length - 1;
        // [483]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [484]  Dim hdrStr As String 
        _hdrstr = '';
        // [485]  Dim hdrName As String 
        _hdrname = '';
        // [486]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [487]  hdrStr = {20} 
            _hdrstr = "head" + _hdrcnt + "";
            // [488]  hdrName = colVisibility.Get(hdrCnt) 
            _hdrname = _colvisibility[_hdrcnt];
            // [489]  Dim th As UOEHTML 
            _th = new banano_uoebanano_uoehtml();
            // [490]  Dim th1 As UOETableHeading 
            _th1 = new banano_uoebanano_uoetableheading();
            // [491]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [492]  If hasHeader Then 
            if (_hasheader) {
                // [493]  th = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [494]  th1 = Columns.Get(hdrStr) 
                _th1 = self._columns[_hdrstr];
                // [495]  Else 
            } else {
                // [496]  th.Initialize(hdrStr, {85} ) 
                _th.initialize(_hdrstr, "th");
                // [497]  th1.Initialize 
                _th1.initialize();
                // [498]  End If 
            }
            // [499]  th.MaterialVisibility(hdrName) 
            _th.materialvisibility(_hdrname);
            // [500]  Headers.Put(hdrStr,th) 
            self._headers[_hdrstr] = _th;
            // [501]  th1.Visibility = hdrName 
            _th1._visibility = _hdrname;
            // [502]  Columns.Put(hdrStr,th1) 
            self._columns[_hdrstr] = _th1;
            // [503]  Next 
        }
        // [504]  Return Me 
        return self;
        // End Sub
    };

    // [508] Sub DeleteRow(rowPos As String) As String 
    this.deleterow = function (_rowpos) {
        if (self == null) self = this;
        var _script;
        // [509]  Dim script As String = {21} 
        _script = "document.getElementById(\"" + self._id + "\").deleteRow(" + _rowpos + ");";
        // [510]  Return script 
        return _script;
        // End Sub
    };

    // [514] Sub AddRow(data As List,dataTheme As List,dataClass As List) As UOETable 
    this.addrow = function (_data, _datatheme, _dataclass) {
        if (self == null) self = this;
        var _rtot;
        var _rkey;
        var _tr1;
        var _scode;
        // [516]  Dim rTot As Int = Rows.size + 1 
        _rtot = self._rows.length + 1;
        // [517]  Dim rKey As String = {22} 
        _rkey = "" + self._id + "_r" + _rtot + "";
        // [519]  Dim tr1 As UOEHTML = NewRow(rKey,data,dataTheme,dataClass) 
        _tr1 = self.newrow(_rkey, _data, _datatheme, _dataclass);
        // [520]  Dim scode As String = tr1.tostring 
        _scode = _tr1.tostring();
        // [521]  scode = scode.Replace(CRLF, {86} ) 
        _scode = _scode.split("\n").join("");
        // [522]  Rows.Add(scode) 
        self._rows.push(_scode);
        // [523]  Return Me 
        return self;
        // End Sub
    };

    // [527] Sub getRowsCount(varName As String) As String 
    this.getrowscount = function (_varname) {
        if (self == null) self = this;
        var _script;
        // [528]  Dim script As String = {23} 
        _script = "var tbl = " + self._j + "('#" + self._id + " tbody tr'); \n" + _varname + " = tbl.length;";
        // [529]  Return script 
        return _script;
        // End Sub
    };

    // [533] private Sub NewRow(rKey As String,data As List,dataTheme As List, dataClass As List) As UOEHTML 
    this.newrow = function (_rkey, _data, _datatheme, _dataclass) {
        if (self == null) self = this;
        var _tr1;
        var _hdrtot;
        var _hdrcnt;
        var _cell;
        var _dkey;
        var _hdrstr;
        var _td;
        var _hasheader;
        var _th;
        var _colalignment;
        var _colfield;
        var _tdtheme;
        var _tdclass;
        // [535]  Dim tr1 As UOEHTML 
        _tr1 = new banano_uoebanano_uoehtml();
        // [536]  tr1.Initialize(rKey, {87} ) 
        _tr1.initialize(_rkey, "tr");
        // [538]  Dim hdrTot As Int = data.Size - 1 
        _hdrtot = _data.length - 1;
        // [539]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [541]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [543]  Dim cell As String = data.Get(hdrCnt) 
            _cell = _data[_hdrcnt];
            // [545]  Dim dKey As String = {24} 
            _dkey = "" + _rkey + "_c" + _hdrcnt + "";
            // [547]  Dim hdrStr As String = {25} 
            _hdrstr = "head" + _hdrcnt + "";
            // [548]  Dim td As UOEHTML 
            _td = new banano_uoebanano_uoehtml();
            // [549]  td.Initialize(dKey, {88} ) 
            _td.initialize(_dkey, "td");
            // [550]  td.AddContent(cell) 
            _td.addcontent(_cell);
            // [552]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
            _hasheader = (_hdrstr in self._headers);
            // [553]  If hasHeader Then 
            if (_hasheader) {
                // [554]  Dim th As UOEHTML = Headers.Get(hdrStr) 
                _th = self._headers[_hdrstr];
                // [555]  Dim colAlignment As String = th.GetStyleAttribute( {89} ) 
                _colalignment = _th.getstyleattribute("text-align");
                // [556]  Dim colField As String = th.GetAttribute( {90} ) 
                _colfield = _th.getattribute("name");
                // [558]  td.AddStyleAttribute( {91} , colAlignment) 
                _td.addstyleattribute("text-align", _colalignment);
                // [559]  td.setname(colField) 
                _td.setname(_colfield);
                // [560]  td.AddClass(colField) 
                _td.addclass(_colfield);
                // [561]  End If 
            }
            // [563]  If dataTheme <> Null And hdrCnt <= dataTheme.Size Then 
            if (_datatheme != null && _hdrcnt <= _datatheme.length) {
                // [564]  Dim tdTheme As String = dataTheme.Get(hdrCnt) 
                _tdtheme = _datatheme[_hdrcnt];
                // [565]  App.MaterialUseTheme(tdTheme,td) 
                self._app.materialusetheme(_tdtheme, _td);
                // [566]  End If 
            }
            // [568]  If dataClass <> Null And hdrCnt <= dataClass.Size Then 
            if (_dataclass != null && _hdrcnt <= _dataclass.length) {
                // [569]  Dim tdClass As String = dataClass.Get(hdrCnt) 
                _tdclass = _dataclass[_hdrcnt];
                // [570]  td.AddClass(tdClass) 
                _td.addclass(_tdclass);
                // [571]  End If 
            }
            // [572]  tr1.AddElement(td) 
            _tr1.addelement(_td);
            // [573]  Next 
        }
        // [574]  Return tr1 
        return _tr1;
        // End Sub
    };

    // [578] Sub AddRow1(pos As Int, data As List,dataTheme As List, dataClass As List) As String 
    this.addrow1 = function (_pos, _data, _datatheme, _dataclass) {
        if (self == null) self = this;
        var _rkey;
        var _tr1;
        var _srow;
        var _script;
        // [580]  Dim rKey As String = {26} 
        _rkey = "" + self._id + "_r" + DateTime.Now() + "";
        // [582]  Dim tr1 As UOEHTML = NewRow(rKey,data,dataTheme,dataClass) 
        _tr1 = self.newrow(_rkey, _data, _datatheme, _dataclass);
        // [583]  Select Case pos 
        switch ("" + _pos) {
            // [584]  Case -1 
            case "" + -1:
                // [586]  Dim sRow As String = tr1.tostring 
                _srow = _tr1.tostring();
                // [587]  sRow = sRow.Replace(CRLF, {92} ) 
                _srow = _srow.split("\n").join("");
                // [588]  Dim script As String = {27} 
                _script = "var newRow = '" + _srow + "'; \n		var tbl = " + self._j + "('#" + self._id + "'); \n		tbl.append(newRow);";
                // [589]  Return script 
                return _script;
                // [590]  Case Else 
            default:
                // [591]  Dim script As String = {28} 
                _script = "var newRow = '" + _srow + "'; \n		$('#" + self._id + " > tbody > tr').eq(" + _pos + "-1).before(newRow);";
                // [592]  Return script 
                return _script;
                // [593]  End Select 
        }
        // End Sub
    };

    // [597] Sub Clear() As String 
    this.clear = function () {
        if (self == null) self = this;
        var _script;
        // [598]  Dim script As String = {29} 
        _script = "" + self._j + "('#" + self._id + " tbody tr').remove();";
        // [599]  Return script 
        return _script;
        // End Sub
    };

    // [603] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _mtot;
        var _tr;
        var _mcnt;
        var _hdrstr;
        var _hasheader;
        var _hdr;
        var _cap;
        // [607]  pTable.ZDepth = ZDepth 
        self._ptable._zdepth = self._zdepth;
        // [608]  el.MaterialEnable(Enabled) 
        self._el.materialenable(self._enabled);
        // [609]  el.MaterialVisibility(Visibility) 
        self._el.materialvisibility(self._visibility);
        // [610]  el.AddClassOnCondition(Striped, {94} ) 
        self._el.addclassoncondition(self._striped, "striped");
        // [611]  el.AddClassOnCondition(Highlight, {95} ) 
        self._el.addclassoncondition(self._highlight, "highlight");
        // [612]  el.AddClassOnCondition(Centered, {96} ) 
        self._el.addclassoncondition(self._centered, "centered");
        // [613]  el.AddClassOnCondition(Responsive, {97} ) 
        self._el.addclassoncondition(self._responsive, "responsive-table");
        // [615]  Dim mTot As Int = Headers.Size - 1 
        _mtot = Object.keys(self._headers).length - 1;
        // [616]  If Headers.Size >= 0 Then 
        if (Object.keys(self._headers).length >= 0) {
            // [617]  Dim tr As UOEHTML 
            _tr = new banano_uoebanano_uoehtml();
            // [618]  tr.Initialize( {98} , {99} ) 
            _tr.initialize("", "tr");
            // [619]  Dim mCnt As Int 
            _mcnt = 0;
            // [620]  For mCnt = 0 To mTot 
            for (_mcnt = 0; _mcnt <= _mtot; _mcnt++) {
                // [621]  Dim hdrStr As String = {31} 
                _hdrstr = "head" + _mcnt + "";
                // [622]  Dim hasHeader As Boolean = Headers.ContainsKey(hdrStr) 
                _hasheader = (_hdrstr in self._headers);
                // [623]  If hasHeader Then 
                if (_hasheader) {
                    // [624]  Dim hdr As UOEHTML = Headers.Get(hdrStr) 
                    _hdr = self._headers[_hdrstr];
                    // [625]  tr.AddElement(hdr) 
                    _tr.addelement(_hdr);
                    // [626]  End If 
                }
                // [627]  Next 
            }
            // [628]  thead.AddElement(tr) 
            self._thead.addelement(_tr);
            // [629]  End If 
        }
        // [631]  thead.AddContentList(HeaderRows) 
        self._thead.addcontentlist(self._headerrows);
        // [632]  If Caption.Length > 0 Then 
        if (self._caption.length > 0) {
            // [633]  Dim cap As UOEHTML 
            _cap = new banano_uoebanano_uoehtml();
            // [634]  cap.Initialize( {100} , {101} ) 
            _cap.initialize("", "caption");
            // [635]  cap.AddContent(Caption) 
            _cap.addcontent(self._caption);
            // [636]  el.AddElement(cap) 
            self._el.addelement(_cap);
            // [637]  End If 
        }
        // [638]  el.AddElement(thead) 
        self._el.addelement(self._thead);
        // [639]  tfoot.AddContentList(FooterRows) 
        self._tfoot.addcontentlist(self._footerrows);
        // [640]  el.AddElement(tfoot) 
        self._el.addelement(self._tfoot);
        // [641]  tbody.AddContentList(Rows) 
        self._tbody.addcontentlist(self._rows);
        // [642]  el.AddElement(tbody) 
        self._el.addelement(self._tbody);
        // [648]  pTable.AddComponent(1,1,el.html) 
        self._ptable.addcomponent(1, 1, self._el.html());
        // [649]  pTable.AddStyleAttributeOnCondition(OverFlow, {104} , {105} ) 
        self._ptable.addstyleattributeoncondition(self._overflow, "overflow-x", "auto");
        // [662]  Return pTable.tostring 
        return self._ptable.tostring();
        // End Sub
    };

    // [666] Sub HideColumn(colFieldName As String) As String 
    this.hidecolumn = function (_colfieldname) {
        if (self == null) self = this;
        var _script;
        // [667]  Dim script As String = {33} 
        _script = "var tbl" + self._id + " = " + self._j + "(\"#" + self._id + "\"); \n    var tblhead" + self._id + " = " + self._j + "(\"#" + self._id + " th\"); \n	var colToHide" + self._id + " = tblhead" + self._id + ".filter(\"." + _colfieldname + "\"); \n    var index" + self._id + " = colToHide" + self._id + ".index(); \n    tbl" + self._id + ".find('tr :nth-child(' + (index" + self._id + " + 1) + ')').toggle();";
        // [668]  Return script 
        return _script;
        // End Sub
    };

    // [672] private Sub GetRowsInternal() 
    this.getrowsinternal = function () {
        if (self == null) self = this;
        var _hdrcnt;
        var _hdrtot;
        var _sb;
        var _hdrstr;
        var _hdr;
        var _colfield;
        var _script;
        // [673]  Dim hdrCnt As Int 
        _hdrcnt = 0;
        // [674]  Dim hdrTot As Int = Headers.Size - 1 
        _hdrtot = Object.keys(self._headers).length - 1;
        // [675]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [676]  sb.Initialize 
        _sb.isinitialized = true;
        // [677]  For hdrCnt = 0 To hdrTot 
        for (_hdrcnt = 0; _hdrcnt <= _hdrtot; _hdrcnt++) {
            // [678]  Dim hdrStr As String = {34} 
            _hdrstr = "head" + _hdrcnt + "";
            // [679]  Dim hdr As UOEHTML = Headers.Get(hdrStr) 
            _hdr = self._headers[_hdrstr];
            // [680]  Dim colField As String = hdr.GetAttribute( {109} ) 
            _colfield = _hdr.getattribute("name");
            // [681]  If colField.Length > 0 Then 
            if (_colfield.length > 0) {
                // [682]  Dim script As String = {35} 
                _script = "var v" + _colfield + " = " + self._id + "row.find(\"[name=" + _colfield + "]\").text(); \n			" + self._id + "obj['" + _colfield + "'] = v" + _colfield + "; \n			" + self._id + "obj['index'] = index;";
                // [683]  sb.append(script).Append(CRLF) 
                _sb.append(_script).append("\n");
                // [684]  End If 
            }
            // [685]  Next 
        }
        // [686]  Dim script As String = {36} 
        _script = "var " + self._id + "data = []; \n	" + self._id + "rows = " + self._j + "(\"#" + self._id + " tbody tr\"); \n" + self._id + "rows.each(function (index) { \n    var " + self._id + "row = " + self._j + "(this); \n 	var " + self._id + "obj = {}; \n	" + _sb.toString() + " \n	" + self._id + "data.push(" + self._id + "obj); \n}); \nreturn " + self._id + "data;";
        // End Sub
    };

    // [694] Sub AddClass(sClass As String) As UOETable 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [695]  el.AddClass(sClass) 
        self._el.addclass(_sclass);
        // [696]  Return Me 
        return self;
        // End Sub
    };

    // [700] Sub RemoveClass(sClass As String) As UOETable 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [701]  el.RemoveClass(sClass) 
        self._el.removeclass(_sclass);
        // [702]  Return Me 
        return self;
        // End Sub
    };

    // [706] Sub AddAttribute(attr As String, value As String) As UOETable 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [707]  el.AddAttribute(attr,value) 
        self._el.addattribute(_attr, _value);
        // [708]  Return Me 
        return self;
        // End Sub
    };

    // [712] Sub RemoveAttribute(attr As String) As UOETable 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [713]  el.RemoveAttribute(attr) 
        self._el.removeattribute(_attr);
        // [714]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEAnchor  ===========================
function banano_uoebanano_uoeanchor() {
    var self;
    this._id = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._enabled = false;

    this._textvisible = false;

    this._text = '';

    this._href = '';

    this._visibility = '';

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._zdepth = '';

    this._hoverable = false;

    this._isdiv = false;

    this._app = new banano_uoebanano_uoeapp();

    // [22] Sub AddStyleAttribute(attribute As String, value As String) As UOEAnchor 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [23]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [24]  Return Me 
        return self;
        // End Sub
    };

    // [28] Public Sub Initialize(thisApp As UOEApp, sID As String) As UOEAnchor 
    this.initialize = function (_thisapp, _sid) {
        if (self == null) self = this;
        // [30]  App = thisApp 
        self._app = _thisapp;
        // [31]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [32]  HREF = {0} 
        self._href = "#!";
        // [33]  Text = {1} 
        self._text = "";
        // [34]  Visibility = {2} 
        self._visibility = "";
        // [35]  Enabled = True 
        self._enabled = true;
        // [36]  TextVisible = True 
        self._textvisible = true;
        // [37]  Theme = {3} 
        self._theme = "";
        // [38]  ZDepth = {4} 
        self._zdepth = "";
        // [39]  IsDiv = False 
        self._isdiv = false;
        // [40]  Element.Initialize(ID, {5} ) 
        self._element.initialize(self._id, "a");
        // [41]  WavesType = App.EnumWavesType.light 
        self._wavestype = self._app._enumwavestype._light;
        // [42]  WavesCircle = False 
        self._wavescircle = false;
        // [43]  WavesEffect = True 
        self._waveseffect = true;
        // [44]  Return Me 
        return self;
        // End Sub
    };

    // [48] Sub AddClass(sClass As String) As UOEAnchor 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [49]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [50]  Return Me 
        return self;
        // End Sub
    };

    // [54] Sub RemoveClass(sClass As String) As UOEAnchor 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [55]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [56]  Return Me 
        return self;
        // End Sub
    };

    // [60] Sub AddAttribute(attr As String, value As String) As UOEAnchor 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [61]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [62]  Return Me 
        return self;
        // End Sub
    };

    // [66] Sub RemoveAttribute(attr As String) As UOEAnchor 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [67]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [68]  Return Me 
        return self;
        // End Sub
    };

    // [72] Sub AddContent(sText As String) As UOEAnchor 
    this.addcontent = function (_stext) {
        if (self == null) self = this;
        // [73]  Element.AddContent(sText) 
        self._element.addcontent(_stext);
        // [74]  Return Me 
        return self;
        // End Sub
    };

    // [78] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [80]  Element.ID = ID 
        self._element._id = self._id;
        // [81]  Element.SetHRef(HREF) 
        self._element.sethref(self._href);
        // [82]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [83]  If IsDiv = True Then Element.settag( {6} ) 
        if (self._isdiv == true) {
            self._element.settag("div");
        }
        // [84]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [85]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [86]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [87]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [88]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [89]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [90]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [91]  If TextVisible = True Then Element.AddContent(Text) 
        if (self._textvisible == true) {
            self._element.addcontent(self._text);
        }
        // [92]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

}
// =========================== UOEToast  ===========================
function banano_uoebanano_uoetoast() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._text = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._callbackfunction = '';

    this._buttontext = '';

    this._isround = false;

    this._duration = 0;

    // [16] Public Sub Initialize(thisApp As UOEApp, tID As String,tText As String, tButtonText As String, tCallBack As String, tRound As Boolean, tDuration As Int, tTheme As String) 
    this.initialize = function (_thisapp, _tid, _ttext, _tbuttontext, _tcallback, _tround, _tduration, _ttheme) {
        if (self == null) self = this;
        // [18]  App = thisApp 
        self._app = _thisapp;
        // [19]  Text = tText 
        self._text = _ttext;
        // [20]  ID = tID.tolowercase 
        self._id = _tid.toLowerCase();
        // [21]  Theme = tTheme 
        self._theme = _ttheme;
        // [22]  Element.Initialize(ID, {2} ) 
        self._element.initialize(self._id, "span");
        // [23]  CallBackFunction = tCallBack 
        self._callbackfunction = _tcallback;
        // [24]  ButtonText = tButtonText 
        self._buttontext = _tbuttontext;
        // [25]  IsRound = tRound 
        self._isround = _tround;
        // [26]  Duration = tDuration 
        self._duration = _tduration;
        // End Sub
    };

    // [31] Sub AddStyleAttribute(attribute As String, value As String) As UOEToast 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [32]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [33]  Return Me 
        return self;
        // End Sub
    };

    // [37] Sub AddClass(sClass As String) As UOEToast 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [38]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [39]  Return Me 
        return self;
        // End Sub
    };

    // [43] Sub RemoveClass(sClass As String) As UOEToast 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [44]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [45]  Return Me 
        return self;
        // End Sub
    };

    // [49] Sub AddAttribute(attr As String, value As String) As UOEToast 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [50]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [51]  Return Me 
        return self;
        // End Sub
    };

    // [55] Sub RemoveAttribute(attr As String) As UOEToast 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [56]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [57]  Return Me 
        return self;
        // End Sub
    };

    // [61] Sub ToSTring As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _sb;
        var _btn;
        var _tclass;
        var _srounded;
        var _js;
        var _scontent;
        // [62]  If Theme = {3} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [63]  Dim sb As StringBuilder 
        _sb = new StringBuilder();
        // [64]  sb.Initialize 
        _sb.isinitialized = true;
        // [65]  Element.ID = ID 
        self._element._id = self._id;
        // [66]  Element.addcontent(Text) 
        self._element.addcontent(self._text);
        // [67]  sb.Append(Element.HTML) 
        _sb.append(self._element.html());
        // [68]  If ButtonText.Length > 0 Then 
        if (self._buttontext.length > 0) {
            // [69]  Dim btn As UOEHTML 
            _btn = new banano_uoebanano_uoehtml();
            // [70]  btn.Initialize(ID & {4} , {5} ) 
            _btn.initialize(self._id + "btn", "button");
            // [71]  btn.AddClass( {6} ) 
            _btn.addclass("btn-flat");
            // [72]  btn.AddClass( {7} ) 
            _btn.addclass("toast-action");
            // [73]  sb.Append(btn.HTML) 
            _sb.append(_btn.html());
            // [74]  End If 
        }
        // [75]  Dim tClass As String = App.MaterialGetTheme(Theme) 
        _tclass = self._app.materialgettheme(self._theme);
        // [76]  Dim srounded As String = {8} 
        _srounded = "";
        // [77]  srounded = App.iif(IsRound, {9} , {10} ) 
        _srounded = self._app.iif(self._isround, "rounded", "");
        // [78]  Dim js As String 
        _js = '';
        // [79]  Dim scontent As String = sb.tostring 
        _scontent = _sb.toString();
        // [80]  scontent = scontent.Replace(CRLF, {11} ) 
        _scontent = _scontent.split("\n").join("");
        // [81]  If CallBackFunction = {12} Then 
        if (self._callbackfunction == "") {
            // [82]  js = {0} 
            _js = "M.toast({ \n		html:'" + _scontent + "',  \n		displayLength:" + self._duration + ",  \n		classes:'" + _srounded + " " + _tclass + "' \n		});";
            // [83]  Else 
        } else {
            // [84]  js = {1} 
            _js = "M.toast({ \n		html:'" + _scontent + "',  \n		completeCallback:" + self._callbackfunction + ",  \n		displayLength:" + self._duration + ",  \n		classes:'" + _srounded + " " + _tclass + "' \n		});";
            // [85]  End If 
        }
        // [86]  Return js 
        return _js;
        // End Sub
    };

}
// =========================== UOETOC  ===========================
function banano_uoebanano_uoetoc() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._visibility = '';

    this._element = new banano_uoebanano_uoehtml();

    this._items = [];

    this._theme = '';

    this._events = {};

    // [15] Public Sub Initialize(thisApp As UOEApp,sid As String,sTheme As String) 
    this.initialize = function (_thisapp, _sid, _stheme) {
        if (self == null) self = this;
        // [16]  App = thisApp 
        self._app = _thisapp;
        // [17]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [18]  Visibility= {9} 
        self._visibility = "";
        // [19]  Theme = sTheme 
        self._theme = _stheme;
        // [20]  Element.Initialize(sid, {10} ) 
        self._element.initialize(_sid, "ul");
        // [21]  Element.AddClass( {11} ).AddClass( {12} ) 
        self._element.addclass("section").addclass("table-of-contents");
        // [22]  Items.Initialize 
        self._items.length = 0;
        // [23]  Items.clear 
        self._items.length = 0;
        // [24]  Events.Initialize 
        self._events = {};
        // [25]  Events.clear 
        self._events = {};
        // End Sub
    };

    // [29] Sub AddStyleAttribute(attribute As String, value As String) As UOETOC 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [30]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [31]  Return Me 
        return self;
        // End Sub
    };

    // [35] Sub AddLink(lnkID As String,lnkText As String,lnkHREF As String, lnkTheme As String) 
    this.addlink = function (_lnkid, _lnktext, _lnkhref, _lnktheme) {
        if (self == null) self = this;
        var _li;
        var _a;
        // [36]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [37]  li.Initialize(lnkID & {13} , {14} ) 
        _li.initialize(_lnkid + "li", "li");
        // [38]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [39]  a.Initialize(lnkID, {15} ) 
        _a.initialize(_lnkid, "a");
        // [40]  a.SetHREF(lnkHREF).AddContent(lnkText) 
        _a.sethref(_lnkhref).addcontent(_lnktext);
        // [41]  App.MaterialUseTheme(lnkTheme,a) 
        self._app.materialusetheme(_lnktheme, _a);
        // [42]  li.AddElement(a) 
        _li.addelement(_a);
        // [43]  Items.Add(li.tostring) 
        self._items.push(_li.tostring());
        // [44]  AddEvent(lnkID, {16} ) 
        self.addevent(_lnkid, "click");
        // End Sub
    };

    // [48] Sub RemoveEvent(elID As String) 
    this.removeevent = function (_elid) {
        if (self == null) self = this;
        var _strevent;
        var _strkey;
        var _elm;
        var _em;
        var _strsuffix;
        // [49]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [50]  If Events.ContainsKey(elID) Then 
        if ((_elid in self._events)) {
            // [51]  Dim strEvent As String = Events.Get(elID) 
            _strevent = self._events[_elid];
            // [52]  Dim strKey As String = {0} 
            _strkey = "#" + _elid + "";
            // [53]  Events.Remove(elID) 
            delete self._events[_elid];
            // [54]  Dim elm As BANanoElement = BANano.GetElement(strKey) 
            _elm = u(_strkey);
            // [55]  elm.Off(strEvent) 
            _elm.off(_strevent);
            // [56]  Dim em As List 
            _em = [];
            // [57]  em.Initialize 
            _em.length = 0;
            // [58]  em.AddAll(Array As String( {17} , {18} , {19} , {20} , {21} )) 
            _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
            // [59]  For Each strsuffix As String In em 
            for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
                _strsuffix = _em[_strsuffixindex];
                // [60]  Dim strKey As String = {1} 
                _strkey = "" + _elid + "-" + _strsuffix + "";
                // [61]  Events.remove(strKey) 
                delete self._events[_strkey];
                // [62]  strKey = {2} 
                _strkey = "#" + _strkey + "";
                // [63]  Dim elm As BANanoElement = BANano.GetElement(strKey) 
                _elm = u(_strkey);
                // [64]  elm.Off(strEvent) 
                _elm.off(_strevent);
                // [65]  Next 
            }
            // [66]  End If 
        }
        // End Sub
    };

    // [70] Sub AddEvent(elID As String, elEvent As String) 
    this.addevent = function (_elid, _elevent) {
        if (self == null) self = this;
        var _em;
        var _strsuffix;
        var _strkey;
        // [71]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [72]  elID = elID.Trim 
        _elid = _elid.trim();
        // [73]  elEvent = elEvent.trim 
        _elevent = _elevent.trim();
        // [74]  If elID.Length > 0 And elEvent.Length > 0 Then 
        if (_elid.length > 0 && _elevent.length > 0) {
            // [75]  Events.Put(elID,elEvent) 
            self._events[_elid] = _elevent;
            // [76]  Dim em As List 
            _em = [];
            // [77]  em.Initialize 
            _em.length = 0;
            // [78]  em.AddAll(Array As String( {22} , {23} , {24} , {25} , {26} )) 
            _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
            // [79]  For Each strsuffix As String In em 
            for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
                _strsuffix = _em[_strsuffixindex];
                // [80]  Dim strkey As String = {3} 
                _strkey = "" + _elid + "-" + _strsuffix + "";
                // [81]  Events.Put(strkey,elEvent) 
                self._events[_strkey] = _elevent;
                // [82]  Next 
            }
            // [83]  End If 
        }
        // End Sub
    };

    // [87] Sub BindEvents(elMethod As String, EventHandler As Object) 
    this.bindevents = function (_elmethod, _eventhandler) {
        if (self == null) self = this;
        var _mtot;
        var _mcnt;
        var _elid;
        var _elevent;
        var _btnevent;
        var _elkey;
        var _elm;
        // [88]  Dim mTot As Int = Events.Size - 1 
        _mtot = Object.keys(self._events).length - 1;
        // [89]  Dim mCnt As Int 
        _mcnt = 0;
        // [90]  For mCnt = 0 To mTot 
        for (_mcnt = 0; _mcnt <= _mtot; _mcnt++) {
            // [91]  Dim elID As String = Events.GetKeyAt(mCnt) 
            _elid = banano_getB4JKeyAt(self._events, _mcnt);
            // [92]  Dim elEvent As String = Events.Get(elID) 
            _elevent = self._events[_elid];
            // [93]  elID = elID.Trim 
            _elid = _elid.trim();
            // [94]  elEvent = elEvent.trim 
            _elevent = _elevent.trim();
            // [95]  If elID.Length > 0 And elEvent.Length > 0 Then 
            if (_elid.length > 0 && _elevent.length > 0) {
                // [96]  Dim btnEvent As String = {4} 
                _btnevent = "" + _elid + "_" + _elevent + "";
                // [97]  Dim elKey As String = {5} 
                _elkey = "#" + _elid + "";
                // [99]  If elMethod.Length > 0 Then 
                if (_elmethod.length > 0) {
                    // [100]  btnEvent = elMethod.tolowercase 
                    _btnevent = _elmethod.toLowerCase();
                    // [101]  End If 
                }
                // [102]  If EventHandler <> Null Then 
                if (_eventhandler != null) {
                    // [103]  Dim elm As BANanoElement = BANano.GetElement(elKey) 
                    _elm = u(_elkey);
                    // [104]  elm.Off(elEvent) 
                    _elm.off(_elevent);
                    // [105]  elm.HandleEvents(elEvent, EventHandler, btnEvent) 
                    _elm.handle(_elevent, function (event) {
                        if (typeof _eventhandler[_btnevent] === "function") {
                            return _eventhandler[_btnevent](event)
                        }
                    });
                    // [106]  End If 
                }
                // [107]  End If 
            }
            // [108]  Next 
        }
        // End Sub
    };

    // [111] Sub BindEvent(elID As String, elEvent As String, elMethod As String, EventHandler As Object) 
    this.bindevent = function (_elid, _elevent, _elmethod, _eventhandler) {
        if (self == null) self = this;
        var _evem;
        var _em;
        var _strsuffix;
        var _strkey;
        var _mtot;
        var _mcnt;
        var _btnevent;
        var _skey;
        var _elm;
        // [112]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [113]  elID = elID.Trim 
        _elid = _elid.trim();
        // [114]  elEvent = elEvent.trim 
        _elevent = _elevent.trim();
        // [115]  Dim evem As Map 
        _evem = {};
        // [116]  evem.Initialize 
        _evem = {};
        // [117]  evem.Put(elID,elEvent) 
        _evem[_elid] = _elevent;
        // [118]  Dim em As List 
        _em = [];
        // [119]  em.Initialize 
        _em.length = 0;
        // [120]  em.AddAll(Array As String( {27} , {28} , {29} , {30} , {31} )) 
        _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
        // [121]  For Each strsuffix As String In em 
        for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
            _strsuffix = _em[_strsuffixindex];
            // [122]  Dim strkey As String = {6} 
            _strkey = "" + _elid + "-" + _strsuffix + "";
            // [123]  evem.Put(strkey,elEvent) 
            _evem[_strkey] = _elevent;
            // [124]  Next 
        }
        // [126]  Dim mTot As Int = evem.Size - 1 
        _mtot = Object.keys(_evem).length - 1;
        // [127]  Dim mCnt As Int = 0 
        _mcnt = 0;
        // [128]  For mCnt = 0 To mTot 
        for (_mcnt = 0; _mcnt <= _mtot; _mcnt++) {
            // [129]  elID = evem.GetKeyAt(mCnt) 
            _elid = banano_getB4JKeyAt(_evem, _mcnt);
            // [130]  elEvent = evem.Get(elID) 
            _elevent = _evem[_elid];
            // [131]  Dim btnEvent As String = {7} 
            _btnevent = "" + _elid + "_" + _elevent + "";
            // [132]  Dim sKey As String = {8} 
            _skey = "#" + _elid + "";
            // [133]  If elID.Length > 0 And elEvent.Length > 0 Then 
            if (_elid.length > 0 && _elevent.length > 0) {
                // [134]  If elMethod.Length > 0 Then 
                if (_elmethod.length > 0) {
                    // [135]  btnEvent = elMethod.tolowercase 
                    _btnevent = _elmethod.toLowerCase();
                    // [136]  End If 
                }
                // [137]  If EventHandler <> Null Then 
                if (_eventhandler != null) {
                    // [138]  Dim elm As BANanoElement = BANano.GetElement(sKey) 
                    _elm = u(_skey);
                    // [139]  elm.Off(elEvent) 
                    _elm.off(_elevent);
                    // [140]  elm.HandleEvents(elEvent, EventHandler, btnEvent) 
                    _elm.handle(_elevent, function (event) {
                        if (typeof _eventhandler[_btnevent] === "function") {
                            return _eventhandler[_btnevent](event)
                        }
                    });
                    // [141]  End If 
                }
                // [142]  End If 
            }
            // [143]  Next 
        }
        // End Sub
    };

    // [147] Sub AddClass(sClass As String) As UOETOC 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [148]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [149]  Return Me 
        return self;
        // End Sub
    };

    // [153] Sub RemoveClass(sClass As String) As UOETOC 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [154]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [155]  Return Me 
        return self;
        // End Sub
    };

    // [159] Sub AddAttribute(attr As String, value As String) As UOETOC 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [160]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [161]  Return Me 
        return self;
        // End Sub
    };

    // [165] Sub RemoveAttribute(attr As String) As UOETOC 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [166]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [167]  Return Me 
        return self;
        // End Sub
    };

    // [171] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [172]  If Theme = {32} Then Theme = App.Theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [173]  Element.AddContentList(Items) 
        self._element.addcontentlist(self._items);
        // [174]  Element.ID = ID 
        self._element._id = self._id;
        // [175]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [181]  Return Element.tostring 
        return self._element.tostring();
        // End Sub
    };

}
// =========================== UOEVideo  ===========================
function banano_uoebanano_uoevideo() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._url = '';

    this._visibility = '';

    this._zdepth = '';

    this._element = new banano_uoebanano_uoehtml();

    this._enabled = false;

    this._frameborder = '';

    this._width = 0;

    this._height = 0;

    this._iframe = new banano_uoebanano_uoehtml();

    this._allowfullscreen = false;

    this._hoverable = false;

    this._autoplay = false;

    this._loopit = false;

    this._showcontrols = false;

    // [24] Sub AddStyleAttribute(attribute As String, value As String) As UOEVideo 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [25]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [26]  Return Me 
        return self;
        // End Sub
    };

    // [31] Public Sub Initialize(thisApp As UOEApp, sID As String, sURL As String) 
    this.initialize = function (_thisapp, _sid, _surl) {
        if (self == null) self = this;
        // [33]  App = thisApp 
        self._app = _thisapp;
        // [34]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [35]  Element.Initialize(ID, {0} ) 
        self._element.initialize(self._id, "div");
        // [36]  Element.AddClass( {1} ) 
        self._element.addclass("video-container");
        // [37]  Enabled = True 
        self._enabled = true;
        // [38]  ZDepth= {2} 
        self._zdepth = "";
        // [39]  Visibility= {3} 
        self._visibility = "";
        // [40]  FrameBorder = {4} 
        self._frameborder = "0";
        // [41]  Width = {5} 
        self._width = "853";
        // [42]  Height = {6} 
        self._height = "480";
        // [43]  URL = sURL 
        self._url = _surl;
        // [44]  iframe.Initialize( {7} , {8} ) 
        self._iframe.initialize("", "iframe");
        // [45]  AllowFullScreen = True 
        self._allowfullscreen = true;
        // [46]  AutoPlay = False 
        self._autoplay = false;
        // [47]  LoopIt = False 
        self._loopit = false;
        // [48]  ShowControls = True 
        self._showcontrols = true;
        // End Sub
    };

    // [52] Sub AddClass(sClass As String) As UOEVideo 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [53]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [54]  Return Me 
        return self;
        // End Sub
    };

    // [58] Sub RemoveClass(sClass As String) As UOEVideo 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [59]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [60]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub AddAttribute(attr As String, value As String) As UOEVideo 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [65]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [66]  Return Me 
        return self;
        // End Sub
    };

    // [70] Sub RemoveAttribute(attr As String) As UOEVideo 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [71]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [79]  Element.ID = ID 
        self._element._id = self._id;
        // [80]  iframe.AddStyleAttribute( {21} ,iframe.MakePx(Width)) 
        self._iframe.addstyleattribute("width", self._iframe.makepx(self._width));
        // [81]  iframe.AddStyleAttribute( {22} ,iframe.MakePx(Height)) 
        self._iframe.addstyleattribute("height", self._iframe.makepx(self._height));
        // [82]  iframe.AddAttribute( {23} ,URL) 
        self._iframe.addattribute("src", self._url);
        // [83]  iframe.AddAttribute( {24} ,FrameBorder) 
        self._iframe.addattribute("frameborder", self._frameborder);
        // [84]  iframe.AddLooseAttributeOnCondition(AllowFullScreen, {25} ) 
        self._iframe.addlooseattributeoncondition(self._allowfullscreen, "allowfullscreen");
        // [85]  iframe.AddLooseAttribute( {26} ) 
        self._iframe.addlooseattribute("playsinline");
        // [86]  iframe.AddAttribute( {27} , {28} ) 
        self._iframe.addattribute("allow", "accelerometer");
        // [87]  If AutoPlay Then 
        if (self._autoplay) {
            // [88]  iframe.UpdateAttribute( {29} , {30} ) 
            self._iframe.updateattribute("allow", "autoplay");
            // [89]  End If 
        }
        // [90]  iframe.UpdateAttribute( {31} , {32} ) 
        self._iframe.updateattribute("allow", "encrypted-media; gyroscope; picture-in-picture");
        // [91]  iframe.AddLooseAttributeOnCondition(ShowControls, {33} ) 
        self._iframe.addlooseattributeoncondition(self._showcontrols, "controls");
        // [92]  iframe.AddLooseAttributeOnCondition(LoopIt, {34} ) 
        self._iframe.addlooseattributeoncondition(self._loopit, "loop");
        // [93]  iframe.AddLooseAttributeOnCondition(AutoPlay, {35} ) 
        self._iframe.addlooseattributeoncondition(self._autoplay, "autoplay");
        // [94]  Element.AddContent(iframe.HTML) 
        self._element.addcontent(self._iframe.html());
        // [95]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [96]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [97]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [98]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [99]  Element.MaterialHoverable(Hoverable) 
        self._element.materialhoverable(self._hoverable);
        // [104]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEColumn  ===========================
function banano_uoebanano_uoecolumn() {
    var self;
    this._columns = 0;

    this._offsetsmall = 0;

    this._offsetmedium = 0;

    this._offsetlarge = 0;

    this._spansmall = 0;

    this._spanmedium = 0;

    this._spanlarge = 0;

    this._margintop = 0;

    this._marginbottom = 0;

    this._marginleft = 0;

    this._marginright = 0;

    this._paddingtop = 0;

    this._paddingbottom = 0;

    this._paddingleft = 0;

    this._paddingright = 0;

    this._theme = '';

    this._visibility = '';

    this._classname = '';

    this._row = 0;

    this._col = 0;

    // [26] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // [27]  Columns = 1 
        self._columns = 1;
        // [28]  OffsetSmall = 0 
        self._offsetsmall = 0;
        // [29]  OffsetMedium = 0 
        self._offsetmedium = 0;
        // [30]  OffsetLarge = 0 
        self._offsetlarge = 0;
        // [31]  SpanSmall = 12 
        self._spansmall = 12;
        // [32]  SpanMedium = 12 
        self._spanmedium = 12;
        // [33]  SpanLarge = 12 
        self._spanlarge = 12;
        // [34]  MarginTop = 0 
        self._margintop = 0;
        // [35]  MarginBottom = 0 
        self._marginbottom = 0;
        // [36]  MarginLeft = 0 
        self._marginleft = 0;
        // [37]  MarginRight = 0 
        self._marginright = 0;
        // [38]  PaddingTop = 0 
        self._paddingtop = 0;
        // [39]  PaddingBottom = 0 
        self._paddingbottom = 0;
        // [40]  PaddingRight = 0 
        self._paddingright = 0;
        // [41]  PaddingLeft = 0 
        self._paddingleft = 0;
        // [42]  Theme = {0} 
        self._theme = "";
        // [43]  Visibility = {1} 
        self._visibility = "";
        // [44]  ClassName = {2} 
        self._classname = "";
        // [45]  Row = 0 
        self._row = 0;
        // [46]  Col = 0 
        self._col = 0;
        // End Sub
    };

}
// =========================== UOERow  ===========================
function banano_uoebanano_uoerow() {
    var self;
    this._rows = 0;

    this._margintop = 0;

    this._marginbottom = 0;

    this._marginleft = 0;

    this._marginright = 0;

    this._paddingtop = 0;

    this._paddingbottom = 0;

    this._paddingleft = 0;

    this._paddingright = 0;

    this._columns = [];

    this._visibility = '';

    this._themename = '';

    this._classname = '';

    this._row = 0;

    // [20] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // [21]  Columns.Initialize 
        self._columns.length = 0;
        // [22]  Columns.clear 
        self._columns.length = 0;
        // [23]  Rows = 1 
        self._rows = 1;
        // [24]  MarginTop = 0 
        self._margintop = 0;
        // [25]  MarginBottom = 20 
        self._marginbottom = 20;
        // [26]  MarginLeft = 0 
        self._marginleft = 0;
        // [27]  MarginRight = 0 
        self._marginright = 0;
        // [28]  PaddingTop = 0 
        self._paddingtop = 0;
        // [29]  PaddingBottom = 0 
        self._paddingbottom = 0;
        // [30]  PaddingLeft = 0 
        self._paddingleft = 0;
        // [31]  PaddingRight = 0 
        self._paddingright = 0;
        // [32]  Visibility = {0} 
        self._visibility = "";
        // [33]  ThemeName = {1} 
        self._themename = "";
        // [34]  ClassName = {2} 
        self._classname = "";
        // [35]  Row = 0 
        self._row = 0;
        // End Sub
    };

}
// =========================== UOESection  ===========================
function banano_uoebanano_uoesection() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._content = new banano_uoebanano_uoecontainer();

    // [10] Public Sub Initialize(thisApp As UOEApp, sid As String, themeName As String) 
    this.initialize = function (_thisapp, _sid, _themename) {
        if (self == null) self = this;
        // [12]  App = thisApp 
        self._app = _thisapp;
        // [13]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [14]  Content.Initialize(App,ID,False,themeName) 
        self._content.initialize(self._app, self._id, false, _themename);
        // [15]  Content.Section = True 
        self._content._section = true;
        // [16]  Content.Theme = themeName 
        self._content._theme = _themename;
        // End Sub
    };

    // [20] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [21]  Return Content.tostring 
        return self._content.tostring();
        // End Sub
    };

}
// =========================== UOESweetModal  ===========================
function banano_uoebanano_uoesweetmodal() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._tabs = new StringBuilder();

    this._tabcontent = new StringBuilder();

    this._showclosebutton = false;

    this._title = '';

    this._content = '';

    this._blocking = false;

    this._width = '';

    this._icon = '';

    this._timeout = '';

    this._j = "$";

    this._icon_success = "" + self._j + ".sweetModal.ICON_SUCCESS";

    this._icon_warning = "" + self._j + ".sweetModal.ICON_WARNING";

    this._icon_error = "" + self._j + ".sweetModal.ICON_ERROR";

    this._hastabs = false;

    this._tabcount = 0;

    this._buttons = new StringBuilder();

    this._hasbuttons = false;

    this._buttontheme_secondaryb = "secondaryB";

    this._buttontheme_redb = "redB";

    this._buttontheme_blueb = "blueB";

    this._buttontheme_greenb = "greenB";

    this._buttontheme_darkgreyb = "darkGreyB";

    this._buttontheme_lightgreyb = "lightGreyB";

    this._buttontheme_yellowb = "yellowB";

    this._buttontheme_purpleb = "purpleB";

    this._buttontheme_tealb = "tealB";

    this._buttontheme_brownb = "brownB";

    this._buttontheme_orangeb = "orangeB";

    this._buttontheme_pinkb = "pinkB";

    // [38] Public Sub Initialize(thisApp As UOEApp, sid As String) 
    this.initialize = function (_thisapp, _sid) {
        if (self == null) self = this;
        // [40]  App = thisApp 
        self._app = _thisapp;
        // [41]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [42]  tabs.Initialize 
        self._tabs.isinitialized = true;
        // [43]  tabContent.Initialize 
        self._tabcontent.isinitialized = true;
        // [44]  Width = {25} 
        self._width = "auto";
        // [45]  Blocking = False 
        self._blocking = false;
        // [46]  hasTabs = False 
        self._hastabs = false;
        // [47]  Icon = {26} 
        self._icon = "''";
        // [48]  Timeout = {27} 
        self._timeout = "null";
        // [49]  tabCount = 0 
        self._tabcount = 0;
        // [50]  buttons.Initialize 
        self._buttons.isinitialized = true;
        // [51]  hasButtons = False 
        self._hasbuttons = false;
        // [52]  showCloseButton = True 
        self._showclosebutton = true;
        // End Sub
    };

    // [56] Sub AddContainer(sContent As UOEContainer) 
    this.addcontainer = function (_scontent) {
        if (self == null) self = this;
        var _scode;
        // [57]  Content = {28} 
        self._content = "";
        // [58]  If sContent <> Null Then 
        if (_scontent != null) {
            // [59]  Dim sCode As String = sContent.ToString 
            _scode = _scontent.tostring();
            // [60]  sCode = sCode.Replace(CRLF, {29} ) 
            _scode = _scode.split("\n").join("");
            // [61]  Content = sCode 
            self._content = _scode;
            // [62]  End If 
        }
        // End Sub
    };

    // [66] Sub AddTab(sTitle As String, sIcon As String, sContent As UOEContainer) 
    this.addtab = function (_stitle, _sicon, _scontent) {
        if (self == null) self = this;
        var _scode;
        var _script;
        // [67]  Dim sCode As String = {30} 
        _scode = "";
        // [68]  If sContent <> Null Then 
        if (_scontent != null) {
            // [69]  sCode = sContent.ToString 
            _scode = _scontent.tostring();
            // [70]  sCode = sCode.Replace(CRLF, {31} ) 
            _scode = _scode.split("\n").join("");
            // [71]  End If 
        }
        // [72]  tabCount = tabCount + 1 
        self._tabcount = self._tabcount + 1;
        // [74]  Dim script As String = {3} 
        _script = "tab" + self._tabcount + ": {label: '" + _stitle + "', icon: '" + _sicon + "'},";
        // [75]  tabs.Append(script).Append(CRLF) 
        self._tabs.append(_script).append("\n");
        // [77]  script = {4} 
        _script = "tab" + self._tabcount + ": '" + _scode + "',";
        // [78]  tabContent.Append(script).Append(CRLF) 
        self._tabcontent.append(_script).append("\n");
        // [79]  hasTabs = True 
        self._hastabs = true;
        // End Sub
    };

    // [82] private Sub BuildContent() As String 
    this.buildcontent = function () {
        if (self == null) self = this;
        var _script;
        var _delim;
        var _sout;
        // [83]  Dim script As String 
        _script = '';
        // [84]  If hasTabs Then 
        if (self._hastabs) {
            // [85]  Dim delim As String = {32} & CRLF 
            _delim = "," + "\n";
            // [86]  Dim sout As String = tabContent.ToString 
            _sout = self._tabcontent.toString();
            // [87]  delim = App.RemDelim(sout,delim) 
            _delim = self._app.remdelim(_sout, _delim);
            // [88]  script = {5} 
            _script = "{" + _delim + "}";
            // [89]  Else 
        } else {
            // [90]  script = {6} 
            _script = "'" + self._content + "'";
            // [91]  End If 
        }
        // [92]  Return script 
        return _script;
        // End Sub
    };

    // [95] private Sub BuildTitle() As String 
    this.buildtitle = function () {
        if (self == null) self = this;
        var _script;
        var _delim;
        var _sout;
        // [96]  Dim script As String 
        _script = '';
        // [97]  If hasTabs Then 
        if (self._hastabs) {
            // [98]  Dim delim As String = {33} & CRLF 
            _delim = "," + "\n";
            // [99]  Dim sout As String = tabs.ToString 
            _sout = self._tabs.toString();
            // [100]  delim = App.RemDelim(sout,delim) 
            _delim = self._app.remdelim(_sout, _delim);
            // [101]  script = {7} 
            _script = "{" + _delim + "}";
            // [102]  Else 
        } else {
            // [103]  script = {8} 
            _script = "'" + self._title + "'";
            // [104]  End If 
        }
        // [105]  Return script 
        return _script;
        // End Sub
    };

    // [108] private Sub BuildButtons() As String 
    this.buildbuttons = function () {
        if (self == null) self = this;
        var _script;
        var _delim;
        var _sout;
        // [109]  Dim script As String 
        _script = '';
        // [110]  If hasButtons Then 
        if (self._hasbuttons) {
            // [111]  Dim delim As String = {34} & CRLF 
            _delim = "," + "\n";
            // [112]  Dim sout As String = buttons.ToString 
            _sout = self._buttons.toString();
            // [113]  delim = App.RemDelim(sout,delim) 
            _delim = self._app.remdelim(_sout, _delim);
            // [114]  script = {9} 
            _script = "{" + _delim + "}";
            // [115]  Else 
        } else {
            // [116]  script = {35} 
            _script = "{}";
            // [117]  End If 
        }
        // [118]  Return script 
        return _script;
        // End Sub
    };

    // [122] Sub AddButton(btnID As String,btnTitle As String,btnClasses As List,btnOnClick As String) 
    this.addbutton = function (_btnid, _btntitle, _btnclasses, _btnonclick) {
        if (self == null) self = this;
        var _vars;
        var _sw;
        var _script;
        // [123]  hasButtons = True 
        self._hasbuttons = true;
        // [124]  Dim vars As String = {36} 
        _vars = "";
        // [125]  If btnClasses <> Null Then 
        if (_btnclasses != null) {
            // [126]  vars = App.Join( {37} ,btnClasses) 
            _vars = self._app.join(",", _btnclasses);
            // [127]  End If 
        }
        // [128]  Dim sw As Boolean = btnOnClick.EndsWith( {38} ) 
        _sw = _btnonclick.endsWith(";");
        // [129]  If sw Then 
        if (_sw) {
            // [130]  Else 
        } else {
            // [131]  btnOnClick = btnOnClick & {39} 
            _btnonclick = _btnonclick + ";";
            // [132]  End If 
        }
        // [133]  Dim script As String = {10} 
        _script = "" + _btnid + ": { \n			label: '" + _btntitle + "', \n			classes: '" + _vars + "', \n			action: function() { \n				return " + _btnonclick + " \n			} \n		},";
        // [134]  buttons.Append(script) 
        self._buttons.append(_script);
        // [135]  buttons.Append(CRLF) 
        self._buttons.append("\n");
        // End Sub
    };

    // [140] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _sshowclosebutton;
        var _sblocking;
        var _script;
        // [141]  Dim sshowCloseButton As String = App.iif(showCloseButton, {40} , {41} ) 
        _sshowclosebutton = self._app.iif(self._showclosebutton, "true", "false");
        // [142]  Dim sBlocking As String = App.iif(Blocking, {42} , {43} ) 
        _sblocking = self._app.iif(self._blocking, "true", "false");
        // [143]  Dim script As String = {11} 
        _script = "" + self._j + ".sweetModal({ \n	title: " + self.buildtitle() + ", \n	content: " + self.buildcontent() + " , \n	icon: " + self._icon + ", \n	showCloseButton: " + _sshowclosebutton + ", \n	blocking: " + _sblocking + ",	 \n	timeout: " + self._timeout + ", \n	width: '" + self._width + "', \n	buttons: " + self.buildbuttons() + " \n});";
        // [144]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOEAlignment  ===========================
function banano_uoebanano_uoealignment() {
    var self;
    this._center = "center";

    this._left = "left";

    this._right = "right";

    this._top = "top";

    this._bottom = "bottom";

    this._valign = "valign-wrapper";

    this._centerdiv = "centerdiv";

    // [14] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEButtonSize  ===========================
function banano_uoebanano_uoebuttonsize() {
    var self;
    this._small = "btn-small";

    this._medium = "btn-medium";

    this._large = "btn-large";

    // [10] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEButtonType  ===========================
function banano_uoebanano_uoebuttontype() {
    var self;
    this._flat = "btn-flat";

    this._raised = "btn-raised";

    this._floating = "btn-floating";

    this._fab = "btn-fab";

    this._halfwayfab = "halfwayfab";

    // [12] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEBadge  ===========================
function banano_uoebanano_uoebadge() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._theme = '';

    this._text = '';

    this._isnew = false;

    this._visibility = '';

    this._zdepth = '';

    this._circle = false;

    this._element = new banano_uoebanano_uoehtml();

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._enabled = false;

    this._hoverable = false;

    // [22] Sub AddStyleAttribute(attribute As String, value As String) As UOEBadge 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [23]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [24]  Return Me 
        return self;
        // End Sub
    };

    // [28] Public Sub Initialize(thisApp As UOEApp,sid As String,bText As String,bIsNew As Boolean,bTheme As String) 
    this.initialize = function (_thisapp, _sid, _btext, _bisnew, _btheme) {
        if (self == null) self = this;
        // [30]  App = thisApp 
        self._app = _thisapp;
        // [31]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [32]  Text = bText 
        self._text = _btext;
        // [33]  IsNew = bIsNew 
        self._isnew = _bisnew;
        // [34]  Circle = False 
        self._circle = false;
        // [35]  Element.Initialize(ID, {0} ) 
        self._element.initialize(self._id, "span");
        // [36]  Element.addClass( {1} ) 
        self._element.addclass("badge");
        // [37]  Enabled = True 
        self._enabled = true;
        // [38]  Theme = bTheme 
        self._theme = _btheme;
        // [39]  Visibility= App.EnumVisibility.hide 
        self._visibility = self._app._enumvisibility._hide;
        // [40]  ZDepth = {2} 
        self._zdepth = "";
        // [41]  WavesType= {3} 
        self._wavestype = "";
        // [42]  WavesEffect = False 
        self._waveseffect = false;
        // [43]  WavesCircle = False 
        self._wavescircle = false;
        // End Sub
    };

    // [47] Sub AddClass(sClass As String) As UOEBadge 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [48]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [49]  Return Me 
        return self;
        // End Sub
    };

    // [53] Sub RemoveClass(sClass As String) As UOEBadge 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [54]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [55]  Return Me 
        return self;
        // End Sub
    };

    // [59] Sub AddAttribute(attr As String, value As String) As UOEBadge 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [60]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [61]  Return Me 
        return self;
        // End Sub
    };

    // [65] Sub RemoveAttribute(attr As String) As UOEBadge 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [66]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [67]  Return Me 
        return self;
        // End Sub
    };

    // [71] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [72]  If Text.Length > 0 Then Visibility = App.EnumVisibility.visible 
        if (self._text.length > 0) {
            self._visibility = self._app._enumvisibility._visible;
        }
        // [73]  Element.ID = ID 
        self._element._id = self._id;
        // [74]  App.MaterialUseThemeOnCondition(Not(IsNew),Theme,Element) 
        self._app.materialusethemeoncondition(!(self._isnew), self._theme, self._element);
        // [75]  Element.MaterialVisibility(Visibility).MaterialWavesType(WavesType) 
        self._element.materialvisibility(self._visibility).materialwavestype(self._wavestype);
        // [76]  Element.MaterialWavesCircle(WavesCircle).MaterialWaveseffect(WavesEffect).MaterialZDepth(ZDepth) 
        self._element.materialwavescircle(self._wavescircle).materialwaveseffect(self._waveseffect).materialzdepth(self._zdepth);
        // [77]  Element.AddContent(Text).AddClassOnCondition(Circle, {4} ) 
        self._element.addcontent(self._text).addclassoncondition(self._circle, "circle");
        // [78]  Element.AddClassOnCondition(IsNew, {5} ) 
        self._element.addclassoncondition(self._isnew, "new");
        // [79]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [80]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [81]  Return Element.HTML 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOECardSize  ===========================
function banano_uoebanano_uoecardsize() {
    var self;
    this._small = "small";

    this._medium = "medium";

    this._large = "large";

    this._normal = "";

    // [11] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOECardType  ===========================
function banano_uoebanano_uoecardtype() {
    var self;
    this._basic = "basic";

    this._image = "image";

    this._reveal = "reveal";

    // [10] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOECollapsibleType  ===========================
function banano_uoebanano_uoecollapsibletype() {
    var self;
    this._accordion = "accordion";

    this._expandable = "expandable";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEColor  ===========================
function banano_uoebanano_uoecolor() {
    var self;
    this._amber = "amber";

    this._black = "black";

    this._blue = "blue";

    this._bluegrey = "blue-grey";

    this._brown = "brown";

    this._cyan = "cyan";

    this._deeporange = "deep-orange";

    this._deeppurple = "deep-purple";

    this._green = "green";

    this._grey = "grey";

    this._indigo = "indigo";

    this._lightblue = "light-blue";

    this._lightgreen = "light-green";

    this._lime = "lime";

    this._orange = "orange";

    this._pink = "pink";

    this._purple = "purple";

    this._red = "red";

    this._teal = "teal";

    this._transparent = "transparent";

    this._white = "white";

    this._normal = "";

    this._yellow = "yellow";

    // [30] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEDateTimeType  ===========================
function banano_uoebanano_uoedatetimetype() {
    var self;
    this._datepicker = "datepicker";

    this._timepicker = "timepicker";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEEvents  ===========================
function banano_uoebanano_uoeevents() {
    var self;
    this._click = "click";

    this._input = "input";

    this._blur = "blur";

    this._change = "change";

    this._keypress = "keypress";

    this._keydown = "keydown";

    this._keyup = "keyup";

    this._dblclick = "dblclick";

    this._mouseover = "mouseover";

    this._mousemove = "mousemove";

    this._mousedown = "mousedown";

    this._load = "load";

    this._unload = "unload";

    this._error = "error";

    this._resize = "resize";

    // [22] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEFABDirection  ===========================
function banano_uoebanano_uoefabdirection() {
    var self;
    this._top = "top";

    this._right = "right";

    this._bottom = "bottom";

    this._left = "left";

    // [11] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEFloatType  ===========================
function banano_uoebanano_uoefloattype() {
    var self;
    this._left = "left";

    this._right = "right";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEIconSize  ===========================
function banano_uoebanano_uoeiconsize() {
    var self;
    this._large = "large";

    this._medium = "medium";

    this._small = "small";

    this._tiny = "tiny";

    // [11] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEInputType  ===========================
function banano_uoebanano_uoeinputtype() {
    var self;
    this._password = "password";

    this._text = "text";

    this._email = "email";

    this._textarea = "textarea";

    this._color = "color";

    this._date = "date";

    this._datetimelocal = "datetime-local";

    this._month = "month";

    this._number = "number";

    this._range = "range";

    this._search = "search";

    this._tel = "tel";

    this._time = "time";

    this._url = "url";

    this._week = "week";

    // [22] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEBreadCrumbs  ===========================
function banano_uoebanano_uoebreadcrumbs() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._theme = '';

    this._element = new banano_uoebanano_uoehtml();

    this._buttons = [];

    this._enabled = false;

    this._visibility = '';

    this._zdepth = '';

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._hoverable = false;

    // [19] Sub AddStyleAttribute(attribute As String, value As String) As UOEBreadCrumbs 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [20]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [21]  Return Me 
        return self;
        // End Sub
    };

    // [25] Public Sub Initialize(thisApp As UOEApp,sid As String,sTheme As String) 
    this.initialize = function (_thisapp, _sid, _stheme) {
        if (self == null) self = this;
        // [27]  App = thisApp 
        self._app = _thisapp;
        // [28]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [29]  Theme = sTheme 
        self._theme = _stheme;
        // [30]  Element.Initialize(ID, {0} ) 
        self._element.initialize(self._id, "nav");
        // [31]  Buttons.Initialize 
        self._buttons.length = 0;
        // [32]  Buttons.clear 
        self._buttons.length = 0;
        // [33]  Enabled = True 
        self._enabled = true;
        // [34]  Visibility= {1} 
        self._visibility = "";
        // [35]  ZDepth = {2} 
        self._zdepth = "";
        // [36]  WavesType= {3} 
        self._wavestype = "";
        // [37]  WavesEffect = False 
        self._waveseffect = false;
        // [38]  WavesCircle = False 
        self._wavescircle = false;
        // End Sub
    };

    // [42] Sub AddClass(sClass As String) As UOEBreadCrumbs 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [43]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [44]  Return Me 
        return self;
        // End Sub
    };

    // [48] Sub RemoveClass(sClass As String) As UOEBreadCrumbs 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [49]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [50]  Return Me 
        return self;
        // End Sub
    };

    // [54] Sub AddAttribute(attr As String, value As String) As UOEBreadCrumbs 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [55]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [56]  Return Me 
        return self;
        // End Sub
    };

    // [60] Sub RemoveAttribute(attr As String) As UOEBreadCrumbs 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [61]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [62]  Return Me 
        return self;
        // End Sub
    };

    // [66] Sub AddButton(btnID As String, btnText As String, btnNav2 As String) As UOEBreadCrumbs 
    this.addbutton = function (_btnid, _btntext, _btnnav2) {
        if (self == null) self = this;
        var _a;
        // [67]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [68]  a.Initialize(btnID, {4} ) 
        _a.initialize(_btnid, "a");
        // [69]  a.AddAttribute( {5} ,btnNav2) 
        _a.addattribute("href", _btnnav2);
        // [70]  a.AddClass( {6} ).AddContent(btnText) 
        _a.addclass("breadcrumb").addcontent(_btntext);
        // [71]  Buttons.Add(a.HTML) 
        self._buttons.push(_a.html());
        // [72]  Return Me 
        return self;
        // End Sub
    };

    // [76] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _wrapper;
        var _div;
        // [77]  If Theme = {7} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [78]  Element.ID = ID 
        self._element._id = self._id;
        // [79]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [80]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [81]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [82]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [83]  Element.MaterialWaveseffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [84]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [85]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [86]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [88]  Dim wrapper As UOEHTML 
        _wrapper = new banano_uoebanano_uoehtml();
        // [89]  wrapper.Initialize( {8} , {9} ) 
        _wrapper.initialize("", "div");
        // [90]  wrapper.AddClass( {10} ) 
        _wrapper.addclass("nav-wrapper");
        // [92]  Dim div As UOEHTML 
        _div = new banano_uoebanano_uoehtml();
        // [93]  div.Initialize( {11} , {12} ) 
        _div.initialize("", "div");
        // [94]  div.AddClass( {13} ) 
        _div.addclass("col s12");
        // [95]  div.AddContentList(Buttons) 
        _div.addcontentlist(self._buttons);
        // [97]  wrapper.AddContent(div.HTML) 
        _wrapper.addcontent(_div.html());
        // [98]  Element.AddContent(wrapper.HTML) 
        self._element.addcontent(_wrapper.html());
        // [103]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOEIntensity  ===========================
function banano_uoebanano_uoeintensity() {
    var self;
    this._normal = "";

    this._lighten5 = "lighten-5";

    this._lighten4 = "lighten-4";

    this._lighten3 = "lighten-3";

    this._lighten2 = "lighten-2";

    this._lighten1 = "lighten-1";

    this._darken1 = "darken-1";

    this._darken2 = "darken-2";

    this._darken3 = "darken-3";

    this._darken4 = "darken-4";

    this._accent1 = "accent-1";

    this._accent2 = "accent-2";

    this._accent3 = "accent-3";

    this._accent4 = "accent-4";

    // [21] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOELabelSize  ===========================
function banano_uoebanano_uoelabelsize() {
    var self;
    this._h1 = "h1";

    this._h2 = "h2";

    this._h3 = "h3";

    this._h4 = "h4";

    this._h5 = "h5";

    this._h6 = "h6";

    this._span = "span";

    this._paragraph = "p";

    this._blockquote = "blockquote";

    // [16] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOELogoPosition  ===========================
function banano_uoebanano_uoelogoposition() {
    var self;
    this._center = "center";

    this._right = "right";

    this._left = "left";

    // [10] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEMenuPosition  ===========================
function banano_uoebanano_uoemenuposition() {
    var self;
    this._left = "left";

    this._right = "right";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEScaleType  ===========================
function banano_uoebanano_uoescaletype() {
    var self;
    this._scalein = "in";

    this._scaleout = "out";

    // [9] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOETableHeading  ===========================
function banano_uoebanano_uoetableheading() {
    var self;
    this._theme = '';

    this._classname = '';

    this._fieldname = '';

    this._height = '';

    this._width = '';

    this._visibility = '';

    this._alignment = '';

    this._title = '';

    // [13] Public Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOETarget  ===========================
function banano_uoebanano_uoetarget() {
    var self;
    this._self = "_self";

    this._blank = "_blank";

    this._parent = "_parent";

    this._top = "_top";

    // [11] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOETextAlignment  ===========================
function banano_uoebanano_uoetextalignment() {
    var self;
    this._center = "center-align";

    this._left = "left-align";

    this._right = "right-align";

    // [10] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOETheme  ===========================
function banano_uoebanano_uoetheme() {
    var self;
    this._fc = '';

    this._fci = '';

    this._bc = '';

    this._bci = '';

    this._fcname = '';

    this._fciname = '';

    this._id = '';

    this._classdef = '';

    // [15] Public Sub Initialize(sID As String,sForeColor As String,sForeColorIntensity As String, sBackColor As String, sBackColorIntensity As String) 
    this.initialize = function (_sid, _sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity) {
        if (self == null) self = this;
        // [16]  sID = sID.tolowercase 
        _sid = _sid.toLowerCase();
        // [17]  ID = sID 
        self._id = _sid;
        // [18]  FCName = sForeColor 
        self._fcname = _sforecolor;
        // [19]  FCIName = sForeColorIntensity 
        self._fciname = _sforecolorintensity;
        // [20]  BC = sBackColor 
        self._bc = _sbackcolor;
        // [21]  BCI = sBackColorIntensity 
        self._bci = _sbackcolorintensity;
        // [22]  FC = {0} 
        self._fc = "" + _sforecolor + "-text";
        // [23]  FCI = {1} 
        self._fci = "text-" + _sforecolorintensity + "";
        // [24]  If sForeColor = {5} Then FC = {6} 
        if (_sforecolor == "") {
            self._fc = "";
        }
        // [25]  If sForeColorIntensity = {7} Then FCI = {8} 
        if (_sforecolorintensity == "") {
            self._fci = "";
        }
        // [26]  ClassDef = getThemeClass(sForeColor,sForeColorIntensity,sBackColor,sBackColorIntensity) 
        self._classdef = self.getthemeclass(_sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity);
        // End Sub
    };

    // [30] private Sub getThemeClass(sForeColor As String,sForeColorIntensity As String, sBackColor As String, sBackColorIntensity As String) As String 
    this.getthemeclass = function (_sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity) {
        if (self == null) self = this;
        var _sbc;
        var _sbci;
        var _sfc;
        var _sfci;
        var _script;
        // [31]  Dim sBC As String = sBackColor 
        _sbc = _sbackcolor;
        // [32]  Dim sBCI As String = sBackColorIntensity 
        _sbci = _sbackcolorintensity;
        // [33]  Dim sFC As String = {2} 
        _sfc = "" + _sforecolor + "-text";
        // [34]  Dim sFCI As String = {3} 
        _sfci = "text-" + _sforecolorintensity + "";
        // [35]  If sForeColor = {9} Then sFC = {10} 
        if (_sforecolor == "") {
            _sfc = "";
        }
        // [36]  If sForeColorIntensity = {11} Then sFCI = {12} 
        if (_sforecolorintensity == "") {
            _sfci = "";
        }
        // [37]  Dim script As String = {4} 
        _script = "" + _sfc + " " + _sfci + " " + _sbc + " " + _sbci + "";
        // [38]  script = script.trim 
        _script = _script.trim();
        // [39]  Return script 
        return _script;
        // End Sub
    };

}
// =========================== UOEThemes  ===========================
function banano_uoebanano_uoethemes() {
    var self;
    this._primary = "primary";

    this._danger = "danger";

    this._warn = "warn";

    this._success = "success";

    this._info = "info";

    this._muted = "muted";

    this._default = "default";

    this._primarytext = "primarytext";

    this._dangertext = "dangertext";

    this._warntext = "warntext";

    this._successtext = "successtext";

    this._infotext = "infotext";

    this._mutedtext = "mutedtext";

    this._defaulttext = "defaulttext";

    // [22] Public Sub Initialize() 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEButton  ===========================
function banano_uoebanano_uoebutton() {
    var self;
    this._id = '';

    this._text = '';

    this._enabled = false;

    this._size = '';

    this._buttontype = '';

    this._pulsing = false;

    this._app = new banano_uoebanano_uoeapp();

    this._href = '';

    this._element = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._zdepth = '';

    this._visibility = '';

    this._isfab = false;

    this._click2toggle = false;

    this._horizontal = false;

    this._istoolbar = false;

    this._buttons = [];

    this._waveseffect = false;

    this._wavestype = '';

    this._wavescircle = false;

    this._hoverable = false;

    this._modaltrigger = false;

    this._modalclose = false;

    this._modalname = '';

    this._autofocus = false;

    this._fitwidth = false;

    // [33] Sub AddStyleAttribute(attribute As String, value As String) As UOEButton 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [34]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [35]  Return Me 
        return self;
        // End Sub
    };

    // [39] Sub AddClass(sClass As String) As UOEButton 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [40]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [41]  Return Me 
        return self;
        // End Sub
    };

    // [45] Sub RemoveClass(sClass As String) As UOEButton 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [46]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [47]  Return Me 
        return self;
        // End Sub
    };

    // [51] Sub AddAttribute(attr As String, value As String) As UOEButton 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [52]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [57] Sub RemoveAttribute(attr As String) As UOEButton 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [58]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [59]  Return Me 
        return self;
        // End Sub
    };

    // [64] Sub Initialize(thisApp As UOEApp, sID As String,bText As String, bTheme As String) As UOEButton 
    this.initialize = function (_thisapp, _sid, _btext, _btheme) {
        if (self == null) self = this;
        // [65]  App = thisApp 
        self._app = _thisapp;
        // [66]  ID = sID.tolowercase 
        self._id = _sid.toLowerCase();
        // [67]  Text = bText 
        self._text = _btext;
        // [68]  ButtonType = App.EnumButtonType.raised 
        self._buttontype = self._app._enumbuttontype._raised;
        // [69]  Pulsing = False 
        self._pulsing = false;
        // [70]  Enabled = True 
        self._enabled = true;
        // [71]  HREF= {2} 
        self._href = "#";
        // [72]  ZDepth = {3} 
        self._zdepth = "";
        // [73]  Size = App.EnumButtonSize.medium 
        self._size = self._app._enumbuttonsize._medium;
        // [74]  IsFAB = False 
        self._isfab = false;
        // [75]  Click2Toggle = False 
        self._click2toggle = false;
        // [76]  Horizontal = False 
        self._horizontal = false;
        // [77]  IsToolBar = False 
        self._istoolbar = false;
        // [78]  Visibility = {4} 
        self._visibility = "";
        // [79]  WavesEffect = True 
        self._waveseffect = true;
        // [80]  Buttons.Initialize 
        self._buttons.length = 0;
        // [81]  Buttons.clear 
        self._buttons.length = 0;
        // [82]  WavesType = App.EnumWavesType.light 
        self._wavestype = self._app._enumwavestype._light;
        // [83]  WavesCircle = False 
        self._wavescircle = false;
        // [84]  Theme = bTheme 
        self._theme = _btheme;
        // [85]  Element.Initialize(ID, {5} ) 
        self._element.initialize(self._id, "a");
        // [86]  ModalClose = False 
        self._modalclose = false;
        // [87]  ModalTrigger = False 
        self._modaltrigger = false;
        // [88]  AutoFocus = False 
        self._autofocus = false;
        // [89]  FitWidth = False 
        self._fitwidth = false;
        // [90]  Return Me 
        return self;
        // End Sub
    };

    // [94] Sub SetButtonType(btnType As String) As UOEButton 
    this.setbuttontype = function (_btntype) {
        if (self == null) self = this;
        // [95]  ButtonType = btnType 
        self._buttontype = _btntype;
        // [96]  Element.MaterialButtonType(ButtonType) 
        self._element.materialbuttontype(self._buttontype);
        // [97]  Return Me 
        return self;
        // End Sub
    };

    // [101] Sub AddJustIcon(IconName As String) As UOEButton 
    this.addjusticon = function (_iconname) {
        if (self == null) self = this;
        // [102]  If IconName = {6} Then Return Me 
        if (_iconname == "") {
            return self;
        }
        // [103]  AddIcon(IconName, {7} ,Theme,False,False) 
        self.addicon(_iconname, "", self._theme, false, false);
        // [104]  Return Me 
        return self;
        // End Sub
    };

    // [108] Sub AddIconWithColors(IconName As String, ForeColor As String, BackColor As String) As UOEButton 
    this.addiconwithcolors = function (_iconname, _forecolor, _backcolor) {
        if (self == null) self = this;
        // [110]  AddIcon(IconName, {11} ,ID & {12} ,False,False) 
        self.addicon(_iconname, "", self._id + "theme", false, false);
        // [111]  Return Me 
        return self;
        // End Sub
    };

    // [115] public Sub AddIcon(sIconName As String, siconAlign As String, sIconTheme As String, bIconCircle As Boolean, bWave As Boolean) As UOEButton 
    this.addicon = function (_siconname, _siconalign, _sicontheme, _biconcircle, _bwave) {
        if (self == null) self = this;
        // [116]  Select Case ButtonType 
        switch ("" + self._buttontype) {
            // [117]  Case App.EnumButtonType.fab 
            case "" + self._app._enumbuttontype._fab:
                // [118]  siconAlign= {13} 
                _siconalign = "";
                // [119]  bIconCircle = True 
                _biconcircle = true;
                // [120]  Case App.EnumButtonType.floating 
                break;
            case "" + self._app._enumbuttontype._floating:
                // [121]  siconAlign= {14} 
                _siconalign = "";
                // [122]  bIconCircle = True 
                _biconcircle = true;
                // [123]  Case App.EnumButtonType.halfwayfab 
                break;
            case "" + self._app._enumbuttontype._halfwayfab:
                // [124]  siconAlign= {15} 
                _siconalign = "";
                // [125]  bIconCircle = True 
                _biconcircle = true;
                // [126]  End Select 
                break;
        }
        // [127]  modUOE.MaterialAddIcon(App,Element,sIconName,siconAlign,sIconTheme,bIconCircle,bWave,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._element, _siconname, _siconalign, _sicontheme, _biconcircle, _bwave, false, false, false);
        // [128]  Return Me 
        return self;
        // End Sub
    };

    // [132] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _themeexist;
        var _fab;
        var _li;
        var _strbutton;
        // [133]  If Theme = {16} Then Theme = App.theme 
        if (self._theme == "") {
            self._theme = self._app._theme;
        }
        // [134]  Dim themeExist As Boolean = App.ThemeExist(Theme) 
        _themeexist = self._app.themeexist(self._theme);
        // [135]  If themeExist = False Then 
        if (_themeexist == false) {
            // [136]  If Theme.Length > 0 Then 
            if (self._theme.length > 0) {
                // [137]  Log( {0} ) 
                console.log("UOEButton: theme '" + self._theme + "' DOES NOT exist!");
                // [138]  End If 
            }
            // [139]  End If 
        }
        // [142]  Element.AddClass( {17} ) 
        self._element.addclass("btn");
        // [143]  If ButtonType = {18} Then ButtonType = App.EnumButtonType.raised 
        if (self._buttontype == "") {
            self._buttontype = self._app._enumbuttontype._raised;
        }
        // [144]  Element.MaterialButtonType(ButtonType) 
        self._element.materialbuttontype(self._buttontype);
        // [145]  Select Case ButtonType 
        switch ("" + self._buttontype) {
            // [146]  Case App.EnumButtonType.fab 
            case "" + self._app._enumbuttontype._fab:
                // [147]  Text= {19} 
                self._text = "";
                // [148]  Element.RemoveClass( {20} ) 
                self._element.removeclass("btn");
                // [149]  Case App.EnumButtonType.floating 
                break;
            case "" + self._app._enumbuttontype._floating:
                // [150]  Text= {21} 
                self._text = "";
                // [151]  Element.RemoveClass( {22} ) 
                self._element.removeclass("btn");
                // [152]  Case App.EnumButtonType.halfwayfab 
                break;
            case "" + self._app._enumbuttontype._halfwayfab:
                // [153]  Text= {23} 
                self._text = "";
                // [154]  Element.AddClass( {24} ).AddClass( {25} ) 
                self._element.addclass("btn-floating").addclass("halfway-fab");
                // [155]  End Select 
                break;
        }
        // [156]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [157]  Element.SetHRef(HREF) 
        self._element.sethref(self._href);
        // [158]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [159]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [160]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [161]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [162]  App.ApplyToolTip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [163]  Element.AddClass(ButtonType) 
        self._element.addclass(self._buttontype);
        // [164]  Element.MaterialPulse(Pulsing) 
        self._element.materialpulse(self._pulsing);
        // [165]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [166]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [167]  Element.MaterialButtonSize(Size) 
        self._element.materialbuttonsize(self._size);
        // [168]  Element.AddContent(Text) 
        self._element.addcontent(self._text);
        // [169]  Element.AddClassOnCondition(ModalTrigger, {26} ) 
        self._element.addclassoncondition(self._modaltrigger, "modal-trigger");
        // [170]  Element.AddAttributeOnCondition(AutoFocus, {27} , {28} ) 
        self._element.addattributeoncondition(self._autofocus, "autofocus", "true");
        // [171]  If ModalName <> {29} Then 
        if (self._modalname != "") {
            // [172]  Element.SetHREF( {1} ) 
            self._element.sethref("#" + self._modalname + "");
            // [173]  Element.addattribute( {30} , ModalName) 
            self._element.addattribute("data-target", self._modalname);
            // [174]  End If 
        }
        // [175]  Element.AddClassOnCondition(ModalClose, {31} ) 
        self._element.addclassoncondition(self._modalclose, "modal-close");
        // [177]  If IsFAB = True Then 
        if (self._isfab == true) {
            // [178]  Dim fab As UOEHTML 
            _fab = new banano_uoebanano_uoehtml();
            // [179]  fab.Initialize(ID & {34} , {35} ) 
            _fab.initialize(self._id + "div", "div");
            // [180]  fab.AddClass( {36} ) 
            _fab.addclass("fixed-action-btn");
            // [181]  fab.AddContent(Element.HTML) 
            _fab.addcontent(self._element.html());
            // [182]  fab.MaterialClick2Toggle(Click2Toggle) 
            _fab.materialclick2toggle(self._click2toggle);
            // [183]  fab.MaterialHorizontal(Horizontal) 
            _fab.materialhorizontal(self._horizontal);
            // [184]  fab.MaterialToolBar(IsToolBar) 
            _fab.materialtoolbar(self._istoolbar);
            // [191]  Dim li As UOEHTML 
            _li = new banano_uoebanano_uoehtml();
            // [192]  li.Initialize( {43} , {44} ) 
            _li.initialize("", "ul");
            // [193]  For Each strButton As String In Buttons 
            for (var _strbuttonindex = 0; _strbuttonindex < self._buttons.length; _strbuttonindex++) {
                _strbutton = self._buttons[_strbuttonindex];
                // [194]  li.AddContent(strButton) 
                _li.addcontent(_strbutton);
                // [195]  Next 
            }
            // [196]  fab.AddContent(li.HTML) 
            _fab.addcontent(_li.html());
            // [201]  Return fab.html 
            return _fab.html();
            // [202]  Else 
        } else {
            // [207]  Return Element.html 
            return self._element.html();
            // [208]  End If 
        }
        // End Sub
    };

}
// =========================== UOEToolTip  ===========================
function banano_uoebanano_uoetooltip() {
    var self;
    this._position = "";

    this._text = "";

    this._delay = 50;

    this._id = "";

    this._theme = "";

    // [12] Public Sub Initialize(sid As String,sText As String,sPosition As String,iDelay As Int,sTheme As String) 
    this.initialize = function (_sid, _stext, _sposition, _idelay, _stheme) {
        if (self == null) self = this;
        // [13]  ID = sid 
        self._id = _sid;
        // [14]  Position = sPosition 
        self._position = _sposition;
        // [15]  Text = sText 
        self._text = _stext;
        // [16]  Delay = iDelay 
        self._delay = _idelay;
        // [17]  Theme = sTheme 
        self._theme = _stheme;
        // End Sub
    };

}
// =========================== UOETooltipPos  ===========================
function banano_uoebanano_uoetooltippos() {
    var self;
    this._bottom = "bottom";

    this._left = "left";

    this._right = "right";

    this._top = "top";

    // [11] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEVideoType  ===========================
function banano_uoebanano_uoevideotype() {
    var self;
    this._mp4 = "video/mp4";

    this._webm = "video/webm";

    this._ogg = "video/ogg";

    // [10] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEVisibility  ===========================
function banano_uoebanano_uoevisibility() {
    var self;
    this._visible = "";

    this._hide = "hide";

    this._hideonsmallonly = "hide-on-small-only";

    this._hideonmedonly = "hide-on-med-only";

    this._hideonmedanddown = "hide-on-med-and-down";

    this._hideonmedandup = "hide-on-med-and-up";

    this._hideonlargeonly = "hide-on-large-only";

    this._showonlargeonly = "show-on-large";

    this._showonsmallonly = "show-on-small";

    this._showonmediumonly = "show-on-medium";

    this._showonmediumandup = "show-on-medium-and-up";

    this._showonmediumanddown = "show-on-medium-and-down";

    // [19] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEWavesType  ===========================
function banano_uoebanano_uoewavestype() {
    var self;
    this._green = "waves-green";

    this._light = "waves-light";

    this._normal = "";

    this._orange = "waves-orange";

    this._purple = "waves-purple";

    this._red = "waves-red";

    this._teal = "waves-teal";

    this._yellow = "waves-yellow";

    // [15] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEZDepth  ===========================
function banano_uoebanano_uoezdepth() {
    var self;
    this._zdepth_1 = "z-depth-1";

    this._zdepth_2 = "z-depth-2";

    this._zdepth_3 = "z-depth-3";

    this._zdepth_4 = "z-depth-4";

    this._zdepth_5 = "z-depth-5";

    this._zdepth_none = "";

    // [13] Sub Initialize 
    this.initialize = function () {
        if (self == null) self = this;
        // End Sub
    };

}
// =========================== UOEApp  ===========================
function banano_uoebanano_uoeapp() {
    var self;
    this._theme = '';

    this._appname = '';

    this._enumcardtype = new banano_uoebanano_uoecardtype();

    this._enumtarget = new banano_uoebanano_uoetarget();

    this._enumlogoposition = new banano_uoebanano_uoelogoposition();

    this._enumintensity = new banano_uoebanano_uoeintensity();

    this._enumlabelsize = new banano_uoebanano_uoelabelsize();

    this._enummenupos = new banano_uoebanano_uoemenuposition();

    this._enumsliderorientation = new banano_uoebanano_uoesliderorientation();

    this._enumfabdirection = new banano_uoebanano_uoefabdirection();

    this._enumtextalignment = new banano_uoebanano_uoetextalignment();

    this._enumtooltippos = new banano_uoebanano_uoetooltippos();

    this._enumalignment = new banano_uoebanano_uoealignment();

    this._enumbuttonsize = new banano_uoebanano_uoebuttonsize();

    this._enumbuttontype = new banano_uoebanano_uoebuttontype();

    this._enumcardsize = new banano_uoebanano_uoecardsize();

    this._enumiconsize = new banano_uoebanano_uoeiconsize();

    this._enuminputtype = new banano_uoebanano_uoeinputtype();

    this._enumvisibility = new banano_uoebanano_uoevisibility();

    this._enumzdepth = new banano_uoebanano_uoezdepth();

    this._enumcolor = new banano_uoebanano_uoecolor();

    this._enumvideotype = new banano_uoebanano_uoevideotype();

    this._enumdatetimetype = new banano_uoebanano_uoedatetimetype();

    this._enumfloattype = new banano_uoebanano_uoefloattype();

    this._enumscaletype = new banano_uoebanano_uoescaletype();

    this._enumcollapsibletype = new banano_uoebanano_uoecollapsibletype();

    this._enumwavestype = new banano_uoebanano_uoewavestype();

    this._enumthemes = new banano_uoebanano_uoethemes();

    this._tooltipdelay = 50;

    this._tooltipposition = "top";

    this._themesmap = {};

    this._colormap = {};

    this._copyrights = '';

    this._termsandconditionsurl = '';

    this._disclaimerurl = '';

    this._privacypolicyurl = '';

    this._imagehw = '';

    this._imagetopmargin = '';

    this._itemheight = '';

    this._css = [];

    this._js = [];

    this._tooltips = {};

    this._components = [];

    this._m = null;

    this._jq = null;

    this._events = {};

    // [53] Sub FunctionDoThis(funcName As String, varList As List,DoThis As String) As String 
    this.functiondothis = function (_funcname, _varlist, _dothis) {
        if (self == null) self = this;
        var _vars;
        var _script;
        // [54]  Dim vars As String = {25} 
        _vars = "";
        // [55]  If varList <> Null Then 
        if (_varlist != null) {
            // [56]  vars = Join( {26} ,varList) 
            _vars = self.join(",", _varlist);
            // [57]  End If 
        }
        // [58]  Dim script As String 
        _script = '';
        // [59]  script = {0} 
        _script = "function " + _funcname + "(" + _vars + "){ \n	" + _dothis + " \n}";
        // [60]  Return script 
        return _script;
        // End Sub
    };

    // [63] Sub CStr(o As Object) As String 
    this.cstr = function (_o) {
        if (self == null) self = this;
        // [64]  Return {27} & o 
        return "" + _o;
        // End Sub
    };

    // [68] Sub RemoveEvent(elID As String) 
    this.removeevent = function (_elid) {
        if (self == null) self = this;
        var _strkey;
        var _strevent;
        var _elm;
        var _em;
        var _strsuffix;
        // [69]  Dim strKey As String 
        _strkey = '';
        // [70]  Dim strEvent As String 
        _strevent = '';
        // [71]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [72]  If Events.ContainsKey(elID) Then 
        if ((_elid in self._events)) {
            // [73]  strEvent = Events.Get(elID) 
            _strevent = self._events[_elid];
            // [74]  Events.Remove(elID) 
            delete self._events[_elid];
            // [75]  strKey = {1} 
            _strkey = "#" + _elid + "";
            // [76]  Dim elm As BANanoElement = BANano.GetElement(strKey) 
            _elm = u(_strkey);
            // [77]  elm.Off(strEvent) 
            _elm.off(_strevent);
            // [78]  Dim em As List 
            _em = [];
            // [79]  em.Initialize 
            _em.length = 0;
            // [80]  em.AddAll(Array As String( {28} , {29} , {30} , {31} , {32} )) 
            _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
            // [81]  For Each strsuffix As String In em 
            for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
                _strsuffix = _em[_strsuffixindex];
                // [82]  Dim strKey As String = {2} 
                _strkey = "" + _elid + "-" + _strsuffix + "";
                // [83]  Events.remove(strKey) 
                delete self._events[_strkey];
                // [84]  strKey = {3} 
                _strkey = "#" + _strkey + "";
                // [85]  Dim elm As BANanoElement = BANano.GetElement(strKey) 
                _elm = u(_strkey);
                // [86]  elm.Off(strEvent) 
                _elm.off(_strevent);
                // [87]  Next 
            }
            // [88]  End If 
        }
        // End Sub
    };

    // [92] Sub AddEvent(elID As String, elEvent As String) 
    this.addevent = function (_elid, _elevent) {
        if (self == null) self = this;
        var _em;
        var _strsuffix;
        var _strkey;
        // [93]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [94]  elID = elID.Trim 
        _elid = _elid.trim();
        // [95]  elEvent = elEvent.trim 
        _elevent = _elevent.trim();
        // [96]  If elID.Length > 0 And elEvent.Length > 0 Then 
        if (_elid.length > 0 && _elevent.length > 0) {
            // [97]  Events.Put(elID,elEvent) 
            self._events[_elid] = _elevent;
            // [98]  Dim em As List 
            _em = [];
            // [99]  em.Initialize 
            _em.length = 0;
            // [100]  em.AddAll(Array As String( {33} , {34} , {35} , {36} , {37} )) 
            _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
            // [101]  For Each strsuffix As String In em 
            for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
                _strsuffix = _em[_strsuffixindex];
                // [102]  Dim strkey As String = {4} 
                _strkey = "" + _elid + "-" + _strsuffix + "";
                // [103]  Events.Put(strkey,elEvent) 
                self._events[_strkey] = _elevent;
                // [104]  Next 
            }
            // [105]  End If 
        }
        // End Sub
    };

    // [109] Sub BindEvents(elMethod As String, EventHandler As Object) 
    this.bindevents = function (_elmethod, _eventhandler) {
        if (self == null) self = this;
        var _mtot;
        var _mcnt;
        var _elid;
        var _elevent;
        var _btnevent;
        var _elkey;
        var _elm;
        // [110]  Dim mTot As Int = Events.Size - 1 
        _mtot = Object.keys(self._events).length - 1;
        // [111]  Dim mCnt As Int 
        _mcnt = 0;
        // [112]  For mCnt = 0 To mTot 
        for (_mcnt = 0; _mcnt <= _mtot; _mcnt++) {
            // [113]  Dim elID As String = Events.GetKeyAt(mCnt) 
            _elid = banano_getB4JKeyAt(self._events, _mcnt);
            // [114]  Dim elEvent As String = Events.Get(elID) 
            _elevent = self._events[_elid];
            // [115]  elID = elID.Trim 
            _elid = _elid.trim();
            // [116]  elEvent = elEvent.trim 
            _elevent = _elevent.trim();
            // [117]  If elID.Length > 0 And elEvent.Length > 0 Then 
            if (_elid.length > 0 && _elevent.length > 0) {
                // [118]  Dim btnEvent As String = {5} 
                _btnevent = "" + _elid + "_" + _elevent + "";
                // [119]  Dim elKey As String = {6} 
                _elkey = "#" + _elid + "";
                // [121]  If elMethod.Length > 0 Then 
                if (_elmethod.length > 0) {
                    // [122]  btnEvent = elMethod.tolowercase 
                    _btnevent = _elmethod.toLowerCase();
                    // [123]  End If 
                }
                // [124]  If EventHandler <> Null Then 
                if (_eventhandler != null) {
                    // [125]  Dim elm As BANanoElement = BANano.GetElement(elKey) 
                    _elm = u(_elkey);
                    // [126]  elm.Off(elEvent) 
                    _elm.off(_elevent);
                    // [127]  elm.HandleEvents(elEvent, EventHandler, btnEvent) 
                    _elm.handle(_elevent, function (event) {
                        if (typeof _eventhandler[_btnevent] === "function") {
                            return _eventhandler[_btnevent](event)
                        }
                    });
                    // [128]  End If 
                }
                // [129]  End If 
            }
            // [130]  Next 
        }
        // End Sub
    };

    // [133] Sub BindEvent(elID As String, elEvent As String, elMethod As String, EventHandler As Object) 
    this.bindevent = function (_elid, _elevent, _elmethod, _eventhandler) {
        if (self == null) self = this;
        var _evem;
        var _em;
        var _strsuffix;
        var _strkey;
        var _mtot;
        var _mcnt;
        var _btnevent;
        var _skey;
        var _elm;
        // [134]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [135]  elID = elID.Trim 
        _elid = _elid.trim();
        // [136]  elEvent = elEvent.trim 
        _elevent = _elevent.trim();
        // [137]  Dim evem As Map 
        _evem = {};
        // [138]  evem.Initialize 
        _evem = {};
        // [139]  evem.Put(elID,elEvent) 
        _evem[_elid] = _elevent;
        // [140]  Dim em As List 
        _em = [];
        // [141]  em.Initialize 
        _em.length = 0;
        // [142]  em.AddAll(Array As String( {38} , {39} , {40} , {41} , {42} )) 
        _em.splice(_em.length, 0, ["icon", "img", "badge", "title", "badge"]);
        // [143]  For Each strsuffix As String In em 
        for (var _strsuffixindex = 0; _strsuffixindex < _em.length; _strsuffixindex++) {
            _strsuffix = _em[_strsuffixindex];
            // [144]  Dim strkey As String = {7} 
            _strkey = "" + _elid + "-" + _strsuffix + "";
            // [145]  evem.Put(strkey,elEvent) 
            _evem[_strkey] = _elevent;
            // [146]  Next 
        }
        // [148]  Dim mTot As Int = evem.Size - 1 
        _mtot = Object.keys(_evem).length - 1;
        // [149]  Dim mCnt As Int = 0 
        _mcnt = 0;
        // [150]  For mCnt = 0 To mTot 
        for (_mcnt = 0; _mcnt <= _mtot; _mcnt++) {
            // [151]  elID = evem.GetKeyAt(mCnt) 
            _elid = banano_getB4JKeyAt(_evem, _mcnt);
            // [152]  elEvent = evem.Get(elID) 
            _elevent = _evem[_elid];
            // [153]  Dim btnEvent As String = {8} 
            _btnevent = "" + _elid + "_" + _elevent + "";
            // [154]  Dim sKey As String = {9} 
            _skey = "#" + _elid + "";
            // [155]  If elID.Length > 0 And elEvent.Length > 0 Then 
            if (_elid.length > 0 && _elevent.length > 0) {
                // [156]  If elMethod.Length > 0 Then 
                if (_elmethod.length > 0) {
                    // [157]  btnEvent = elMethod.tolowercase 
                    _btnevent = _elmethod.toLowerCase();
                    // [158]  End If 
                }
                // [159]  If EventHandler <> Null Then 
                if (_eventhandler != null) {
                    // [160]  Dim elm As BANanoElement = BANano.GetElement(sKey) 
                    _elm = u(_skey);
                    // [161]  elm.Off(elEvent) 
                    _elm.off(_elevent);
                    // [162]  elm.HandleEvents(elEvent, EventHandler, btnEvent) 
                    _elm.handle(_elevent, function (event) {
                        if (typeof _eventhandler[_btnevent] === "function") {
                            return _eventhandler[_btnevent](event)
                        }
                    });
                    // [163]  End If 
                }
                // [164]  End If 
            }
            // [165]  Next 
        }
        // End Sub
    };

    // [169] Sub NewPage 
    this.newpage = function () {
        if (self == null) self = this;
        // [170]  CSS.Initialize 
        self._css.length = 0;
        // [171]  CSS.clear 
        self._css.length = 0;
        // [172]  JS.Initialize 
        self._js.length = 0;
        // [173]  JS.clear 
        self._js.length = 0;
        // [174]  ToolTips.Initialize 
        self._tooltips = {};
        // [175]  ToolTips.clear 
        self._tooltips = {};
        // [176]  Components.Initialize 
        self._components.length = 0;
        // [177]  Components.clear 
        self._components.length = 0;
        // [178]  Events.Initialize 
        self._events = {};
        // [179]  Events.clear 
        self._events = {};
        // End Sub
    };

    // [183] Sub Join(Delim As String, lst As List) As String 
    this.join = function (_delim, _lst) {
        if (self == null) self = this;
        var _ltot;
        var _lcnt;
        var _lstr;
        // [184]  Dim lTot As Int 
        _ltot = 0;
        // [185]  Dim lCnt As Int 
        _lcnt = 0;
        // [186]  Dim lStr As StringBuilder 
        _lstr = new StringBuilder();
        // [187]  lStr.Initialize 
        _lstr.isinitialized = true;
        // [188]  lTot = lst.Size - 1 
        _ltot = _lst.length - 1;
        // [189]  For lCnt = 0 To lTot 
        for (_lcnt = 0; _lcnt <= _ltot; _lcnt++) {
            // [190]  lStr.Append(lst.Get(lCnt)) 
            _lstr.append(_lst[_lcnt]);
            // [191]  If lCnt <> lTot Then 
            if (_lcnt != _ltot) {
                // [192]  lStr.Append(Delim) 
                _lstr.append(_delim);
                // [193]  End If 
            }
            // [194]  Next 
        }
        // [195]  Return lStr.tostring 
        return _lstr.toString();
        // End Sub
    };

    // [199] Sub RemDelim(sValue As String, Delim As String) As String 
    this.remdelim = function (_svalue, _delim) {
        if (self == null) self = this;
        var _ew;
        var _ldelim;
        var _nvalue;
        // [200]  Dim ew As Boolean = sValue.EndsWith(Delim) 
        _ew = _svalue.endsWith(_delim);
        // [201]  If ew Then 
        if (_ew) {
            // [202]  Dim lDelim As Int = Delim.Length 
            _ldelim = _delim.length;
            // [203]  Dim nValue As String = sValue 
            _nvalue = _svalue;
            // [204]  Dim ew As Boolean = nValue.EndsWith(Delim) 
            _ew = _nvalue.endsWith(_delim);
            // [205]  If ew Then 
            if (_ew) {
                // [206]  nValue = nValue.SubString2(0, nValue.Length-lDelim) 
                _nvalue = _nvalue.substring(0, _nvalue.length - _ldelim);
                // [207]  End If 
            }
            // [208]  Return nValue 
            return _nvalue;
            // [209]  Else 
        } else {
            // [210]  Return sValue 
            return _svalue;
            // [211]  End If 
        }
        // End Sub
    };

    // [216] Sub RemDelimSB(delimiter As String, value As StringBuilder) As StringBuilder 
    this.remdelimsb = function (_delimiter, _value) {
        if (self == null) self = this;
        var _delimlen;
        // [217]  If value.tostring.EndsWith(delimiter) = True Then 
        if (_value.toString().endsWith(_delimiter) == true) {
            // [218]  Dim delimLen As Int = delimiter.length 
            _delimlen = _delimiter.length;
            // [219]  value.Remove(value.Length-delimLen,value.Length) 
            _value.remove(_value.length() - _delimlen, _value.length());
            // [220]  End If 
        }
        // [221]  Return value 
        return;
        // End Sub
    };

    // [225] Sub iif(Expression2Evaluate As String, ReturnIfTrue As Object, ReturnIfFalse As Object) As Object 
    this.iif = function (_expression2evaluate, _returniftrue, _returniffalse) {
        if (self == null) self = this;
        // [226]  If Expression2Evaluate = True Then Return ReturnIfTrue Else Return ReturnIfFalse 
        if (_expression2evaluate == true) {
            return _returniftrue;
        } else {
            _returniffalse;
        }
        // End Sub
    };

    // [230] Sub getTheme(themeName As String) As UOETheme 
    this.gettheme = function (_themename) {
        if (self == null) self = this;
        var _tt;
        // [231]  themeName = themeName.tolowercase 
        _themename = _themename.toLowerCase();
        // [232]  Dim tt As UOETheme = ThemesMap.Get(themeName) 
        _tt = self._themesmap[_themename];
        // [233]  Return tt 
        return _tt;
        // End Sub
    };

    // [238] Sub AddTheme(themeName As String, sForeColor As String, sForeColorIntensity As String, sBackColor As String, sBackColorIntensity As String) 
    this.addtheme = function (_themename, _sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity) {
        if (self == null) self = this;
        var _tt;
        // [239]  themeName = themeName.tolowercase 
        _themename = _themename.toLowerCase();
        // [240]  Dim tt As UOETheme 
        _tt = new banano_uoebanano_uoetheme();
        // [241]  tt.Initialize(themeName,sForeColor,sForeColorIntensity,sBackColor,sBackColorIntensity) 
        _tt.initialize(_themename, _sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity);
        // [242]  ThemesMap.Put(themeName,tt) 
        self._themesmap[_themename] = _tt;
        // End Sub
    };

    // [246] Sub ThemeExist(themeName As String) As Boolean 
    this.themeexist = function (_themename) {
        if (self == null) self = this;
        var _bexist;
        // [247]  themeName = themeName.ToLowerCase 
        _themename = _themename.toLowerCase();
        // [248]  Dim bExist As Boolean = ThemesMap.ContainsKey(themeName) 
        _bexist = (_themename in self._themesmap);
        // [249]  Return bExist 
        return _bexist;
        // End Sub
    };

    // [253] Sub MaterialUseTheme(sThemeName As String, el As UOEHTML) As UOEHTML 
    this.materialusetheme = function (_sthemename, _el) {
        if (self == null) self = this;
        var _tt;
        var _script;
        // [254]  If sThemeName = {43} Then Return el 
        if (_sthemename == "") {
            return _el;
        }
        // [255]  If ThemeExist(sThemeName) Then 
        if (self.themeexist(_sthemename)) {
            // [256]  Dim tt As UOETheme 
            _tt = new banano_uoebanano_uoetheme();
            // [257]  tt = getTheme(sThemeName) 
            _tt = self.gettheme(_sthemename);
            // [258]  Dim script As String = tt.ClassDef 
            _script = _tt._classdef;
            // [259]  el.AddClass(script) 
            _el.addclass(_script);
            // [260]  End If 
        }
        // [261]  Return el 
        return _el;
        // End Sub
    };

    // [265] Sub MaterialGetTheme(sTheme As String) As String 
    this.materialgettheme = function (_stheme) {
        if (self == null) self = this;
        var _thist;
        var _script;
        // [266]  sTheme = sTheme.trim 
        _stheme = _stheme.trim();
        // [267]  If ThemeExist(sTheme) Then 
        if (self.themeexist(_stheme)) {
            // [268]  Dim thisT As UOETheme 
            _thist = new banano_uoebanano_uoetheme();
            // [269]  thisT = getTheme(sTheme) 
            _thist = self.gettheme(_stheme);
            // [270]  Dim script As String = thisT.ClassDef 
            _script = _thist._classdef;
            // [271]  Return script 
            return _script;
            // [272]  Else 
        } else {
            // [273]  Return {44} 
            return "";
            // [274]  End If 
        }
        // End Sub
    };

    // [279] private Sub StrParse(Delim As String, InputString As String) As List 
    this.strparse = function (_delim, _inputstring) {
        if (self == null) self = this;
        var _outlist;
        var _commaloc;
        var _leftside;
        var _rightside;
        // [280]  Dim OutList As List 
        _outlist = [];
        // [281]  Dim CommaLoc As Int 
        _commaloc = 0;
        // [282]  OutList.Initialize 
        _outlist.length = 0;
        // [283]  OutList.clear 
        _outlist.length = 0;
        // [284]  CommaLoc=InputString.IndexOf(Delim) 
        _commaloc = _inputstring.indexOf(_delim);
        // [285]  Do While CommaLoc >-1 
        while (_commaloc > -1) {
            // [286]  Dim LeftSide As String 
            _leftside = '';
            // [287]  LeftSide= InputString.SubString2(0,CommaLoc) 
            _leftside = _inputstring.substring(0, _commaloc);
            // [288]  Dim RightSide As String 
            _rightside = '';
            // [289]  RightSide= InputString.SubString(CommaLoc+1) 
            _rightside = _inputstring.substring(_commaloc + 1);
            // [290]  OutList.Add(LeftSide) 
            _outlist.push(_leftside);
            // [291]  InputString=RightSide 
            _inputstring = _rightside;
            // [292]  CommaLoc=InputString.IndexOf(Delim) 
            _commaloc = _inputstring.indexOf(_delim);
            // [293]  Loop 
        }
        // [294]  OutList.Add(InputString) 
        _outlist.push(_inputstring);
        // [295]  Return OutList 
        return _outlist;
        // End Sub
    };

    // [300] Sub MvField(sValue As String, iPosition As Int, Delimiter As String) As String 
    this.mvfield = function (_svalue, _iposition, _delimiter) {
        if (self == null) self = this;
        var _xpos;
        var _mvalues;
        var _tvalues;
        var _sb;
        var _startcnt;
        // [301]  If sValue.Length = 0 Then Return {45} 
        if (_svalue.length == 0) {
            return "";
        }
        // [302]  Dim xPos As Int = sValue.IndexOf(Delimiter) 
        _xpos = _svalue.indexOf(_delimiter);
        // [303]  If xPos = -1 Then Return sValue 
        if (_xpos == -1) {
            return _svalue;
        }
        // [304]  Dim mValues As List = StrParse(Delimiter,sValue) 
        _mvalues = self.strparse(_delimiter, _svalue);
        // [305]  Dim tValues As Int 
        _tvalues = 0;
        // [306]  tValues = mValues.size -1 
        _tvalues = _mvalues.length - 1;
        // [307]  Select Case iPosition 
        switch ("" + _iposition) {
            // [308]  Case -1 
            case "" + -1:
                // [309]  Return mValues.get(tValues) 
                return _mvalues[_tvalues];
                // [310]  Case -2 
            case "" + -2:
                // [311]  Return mValues.get(tValues - 1) 
                return _mvalues[_tvalues - 1];
                // [312]  Case -3 
            case "" + -3:
                // [313]  Dim sb As StringBuilder 
                _sb = new StringBuilder();
                // [314]  sb.Initialize 
                _sb.isinitialized = true;
                // [315]  Dim startcnt As Int 
                _startcnt = 0;
                // [316]  sb.Append(mValues.Get(1)) 
                _sb.append(_mvalues[1]);
                // [317]  For startcnt = 2 To tValues 
                for (_startcnt = 2; _startcnt <= _tvalues; _startcnt++) {
                    // [318]  sb.Append(Delimiter) 
                    _sb.append(_delimiter);
                    // [319]  sb.Append(mValues.get(startcnt)) 
                    _sb.append(_mvalues[_startcnt]);
                    // [320]  Next 
                }
                // [321]  Return sb.tostring 
                return _sb.toString();
                // [322]  Case Else 
            default:
                // [323]  iPosition = iPosition - 1 
                _iposition = _iposition - 1;
                // [324]  If iPosition <= -1 Then 
                if (_iposition <= -1) {
                    // [325]  Return mValues.get(tValues) 
                    return _mvalues[_tvalues];
                    // [326]  End If 
                }
                // [327]  If iPosition > tValues Then 
                if (_iposition > _tvalues) {
                    // [328]  Return {46} 
                    return "";
                    // [329]  End If 
                }
                // [330]  Return mValues.get(iPosition) 
                return _mvalues[_iposition];
                // [331]  End Select 
        }
        // End Sub
    };

    // [336] Sub getThemeClass(sForeColor As String,sForeColorIntensity As String, sBackColor As String, sBackColorIntensity As String) As String 
    this.getthemeclass = function (_sforecolor, _sforecolorintensity, _sbackcolor, _sbackcolorintensity) {
        if (self == null) self = this;
        var _bc;
        var _bci;
        var _fc;
        var _fci;
        var _script;
        // [337]  Dim BC As String = sBackColor 
        _bc = _sbackcolor;
        // [338]  Dim BCI As String = sBackColorIntensity 
        _bci = _sbackcolorintensity;
        // [339]  Dim FC As String = {10} 
        _fc = "" + _sforecolor + "-text";
        // [340]  Dim FCI As String = {11} 
        _fci = "text-" + _sforecolorintensity + "";
        // [341]  If sForeColor = {47} Then FC = {48} 
        if (_sforecolor == "") {
            _fc = "";
        }
        // [342]  If sForeColorIntensity = {49} Then FCI = {50} 
        if (_sforecolorintensity == "") {
            _fci = "";
        }
        // [343]  Dim script As String = {12} 
        _script = "" + _fc + " " + _fci + " " + _bc + " " + _bci + "";
        // [344]  script = script.trim 
        _script = _script.trim();
        // [345]  Return script 
        return _script;
        // End Sub
    };

    // [349] Sub Map2Json(mp As Map) As String 
    this.map2json = function (_mp) {
        if (self == null) self = this;
        var _json;
        // [350]  Dim JSON As BANanoJSONGenerator 
        _json = {};
        // [351]  JSON.Initialize(mp) 
        _json = _mp;
        // [352]  Return JSON.ToString 
        return JSON.stringify(_json);
        // End Sub
    };

    // [356] Sub Object2Json(mp As Object) As String 
    this.object2json = function (_mp) {
        if (self == null) self = this;
        var _json;
        // [357]  Dim JSON As BANanoJSONGenerator 
        _json = {};
        // [358]  JSON.Initialize(mp) 
        _json = _mp;
        // [359]  Return JSON.ToString 
        return JSON.stringify(_json);
        // End Sub
    };

    // [364] Sub List2Json(mp As List) As String 
    this.list2json = function (_mp) {
        if (self == null) self = this;
        var _json;
        // [365]  Dim JSON As BANanoJSONGenerator 
        _json = {};
        // [366]  JSON.Initialize2(mp) 
        _json = _mp;
        // [367]  Return JSON.ToString 
        return JSON.stringify(_json);
        // End Sub
    };

    // [371] Sub Json2Map(strJSON As String) As Map 
    this.json2map = function (_strjson) {
        if (self == null) self = this;
        var _json;
        var _map1;
        // [372]  Dim json As BANanoJSONParser 
        _json = {};
        // [373]  Dim Map1 As Map 
        _map1 = {};
        // [374]  Map1.Initialize 
        _map1 = {};
        // [375]  Map1.clear 
        _map1 = {};
        // [376]  Try 
        try {
            // [377]  If strJSON.length > 0 Then 
            if (_strjson.length > 0) {
                // [378]  json.Initialize(strJSON) 
                _json = JSON.parse(_strjson);
                // [379]  Map1 = json.NextObject 
                _map1 = _json;
                // [380]  End If 
            }
            // [381]  Return Map1 
            return _map1;
            // [382]  Catch 
        } catch (err) {
            // [383]  Return Map1 
            return _map1;
            // [384]  End Try 
        }
        // End Sub
    };

    // [388] Sub Json2List(strValue As String) As List 
    this.json2list = function (_strvalue) {
        if (self == null) self = this;
        var _lst;
        var _parser;
        // [389]  Dim lst As List 
        _lst = [];
        // [390]  lst.Initialize 
        _lst.length = 0;
        // [391]  lst.clear 
        _lst.length = 0;
        // [392]  If strValue.Length = 0 Then 
        if (_strvalue.length == 0) {
            // [393]  Return lst 
            return _lst;
            // [394]  End If 
        }
        // [395]  Try 
        try {
            // [396]  Dim parser As BANanoJSONParser 
            _parser = {};
            // [397]  parser.Initialize(strValue) 
            _parser = JSON.parse(_strvalue);
            // [398]  Return parser.NextArray 
            return _parser;
            // [399]  Catch 
        } catch (err) {
            // [400]  Return lst 
            return _lst;
            // [401]  End Try 
        }
        // End Sub
    };

    // [406] Sub GetColorHex(color As String, intensity As String) As String 
    this.getcolorhex = function (_color, _intensity) {
        if (self == null) self = this;
        var _skey;
        var _scolor;
        // [407]  Dim sKey As String = color & {51} & intensity 
        _skey = _color + " " + _intensity;
        // [408]  sKey = sKey.trim 
        _skey = _skey.trim();
        // [409]  If sKey = {52} Then Return {53} 
        if (_skey == "") {
            return "";
        }
        // [410]  If ColorMap.ContainsKey(sKey) Then 
        if ((_skey in self._colormap)) {
            // [411]  Dim sColor As String = ColorMap.GetDefault(sKey, {54} ) 
            _scolor = (self._colormap[_skey] || "");
            // [412]  Return sColor 
            return _scolor;
            // [413]  Else 
        } else {
            // [414]  Return {55} 
            return "";
            // [415]  End If 
        }
        // End Sub
    };

    // [419] Sub GetForeColorHex(sTheme As String) As String 
    this.getforecolorhex = function (_stheme) {
        if (self == null) self = this;
        var _thist;
        // [420]  sTheme = sTheme.trim 
        _stheme = _stheme.trim();
        // [421]  If ThemeExist(sTheme) Then 
        if (self.themeexist(_stheme)) {
            // [422]  Dim thisT As UOETheme 
            _thist = new banano_uoebanano_uoetheme();
            // [423]  thisT = getTheme(sTheme) 
            _thist = self.gettheme(_stheme);
            // [424]  Return GetColorHex(thisT.FCName,thisT.FCIName) 
            return self.getcolorhex(_thist._fcname, _thist._fciname);
            // [425]  Else 
        } else {
            // [426]  Return {56} 
            return "";
            // [427]  End If 
        }
        // End Sub
    };

    // [431] Sub GetBackGroundColorHex(sTheme As String) As String 
    this.getbackgroundcolorhex = function (_stheme) {
        if (self == null) self = this;
        var _thist;
        // [432]  sTheme = sTheme.trim 
        _stheme = _stheme.trim();
        // [433]  If ThemeExist(sTheme) Then 
        if (self.themeexist(_stheme)) {
            // [434]  Dim thisT As UOETheme 
            _thist = new banano_uoebanano_uoetheme();
            // [435]  thisT = getTheme(sTheme) 
            _thist = self.gettheme(_stheme);
            // [436]  Return GetColorHex(thisT.BC,thisT.BCI) 
            return self.getcolorhex(_thist._bc, _thist._bci);
            // [437]  Else 
        } else {
            // [438]  Return {57} 
            return "";
            // [439]  End If 
        }
        // End Sub
    };

    // [444] Public Sub Initialize(sAppName As String, sTheme As String) 
    this.initialize = function (_sappname, _stheme) {
        if (self == null) self = this;
        // [445]  M.Initialize( {58} ) 
        self._m = M;
        // [446]  jQ.Initialize( {59} ) 
        self._jq = $;
        // [447]  NewPage 
        self.newpage();
        // [448]  ColorMap.Initialize 
        self._colormap = {};
        // [449]  ColorMap.clear 
        self._colormap = {};
        // [450]  Theme = sTheme 
        self._theme = _stheme;
        // [451]  EnumThemes.Initialize 
        self._enumthemes.initialize();
        // [452]  AppName = sAppName 
        self._appname = _sappname;
        // [453]  ThemesMap.Initialize 
        self._themesmap = {};
        // [454]  ThemesMap.clear 
        self._themesmap = {};
        // [456]  InitColorMap 
        self.initcolormap();
        // [457]  EnumColor.Initialize 
        self._enumcolor.initialize();
        // [458]  EnumCardType.Initialize 
        self._enumcardtype.initialize();
        // [459]  EnumTarget.Initialize 
        self._enumtarget.initialize();
        // [460]  EnumLogoPosition.Initialize 
        self._enumlogoposition.initialize();
        // [461]  EnumIntensity.Initialize 
        self._enumintensity.initialize();
        // [462]  EnumLabelSize.Initialize 
        self._enumlabelsize.initialize();
        // [463]  EnumMenuPos.Initialize 
        self._enummenupos.initialize();
        // [464]  EnumSliderOrientation.Initialize 
        self._enumsliderorientation.initialize();
        // [465]  EnumFABDirection.Initialize 
        self._enumfabdirection.initialize();
        // [466]  EnumTextAlignment.Initialize 
        self._enumtextalignment.initialize();
        // [467]  EnumTooltipPos.Initialize 
        self._enumtooltippos.initialize();
        // [468]  EnumAlignment.Initialize 
        self._enumalignment.initialize();
        // [469]  EnumButtonSize.Initialize 
        self._enumbuttonsize.initialize();
        // [470]  EnumButtonType.Initialize 
        self._enumbuttontype.initialize();
        // [471]  EnumCardSize.Initialize 
        self._enumcardsize.initialize();
        // [472]  EnumIconSize.Initialize 
        self._enumiconsize.initialize();
        // [473]  EnumInputType.Initialize 
        self._enuminputtype.initialize();
        // [474]  EnumVisibility.Initialize 
        self._enumvisibility.initialize();
        // [475]  EnumZDepth.Initialize 
        self._enumzdepth.initialize();
        // [476]  EnumVideoType.Initialize 
        self._enumvideotype.initialize();
        // [477]  EnumDateTimeType.Initialize 
        self._enumdatetimetype.initialize();
        // [478]  EnumFloatType.Initialize 
        self._enumfloattype.initialize();
        // [479]  EnumScaleType.Initialize 
        self._enumscaletype.initialize();
        // [480]  EnumCollapsibleType.Initialize 
        self._enumcollapsibletype.initialize();
        // [481]  EnumWavesType.Initialize 
        self._enumwavestype.initialize();
        // [482]  AddTheme( {60} , {61} , {62} , {63} , {64} ) 
        self.addtheme("primary", "white", "", "blue", "");
        // [483]  AddTheme( {65} , {66} , {67} , {68} , {69} ) 
        self.addtheme("danger", "white", "", "red", "");
        // [484]  AddTheme( {70} , {71} , {72} , {73} , {74} ) 
        self.addtheme("warn", "white", "", "orange", "");
        // [485]  AddTheme( {75} , {76} , {77} , {78} , {79} ) 
        self.addtheme("success", "white", "", "green", "");
        // [486]  AddTheme( {80} , {81} , {82} , {83} , {84} ) 
        self.addtheme("info", "white", "", "light-blue", "");
        // [487]  AddTheme( {85} , {86} , {87} , {88} , {89} ) 
        self.addtheme("muted", "white", "", "black", "");
        // [488]  AddTheme( {90} , {91} , {92} , {93} , {94} ) 
        self.addtheme("default", "white", "", "light-blue", "");
        // [490]  AddTheme( {95} , {96} , {97} , {98} , {99} ) 
        self.addtheme("primarytext", "blue", "", "transparent", "");
        // [491]  AddTheme( {100} , {101} , {102} , {103} , {104} ) 
        self.addtheme("dangertext", "red", "", "transparent", "");
        // [492]  AddTheme( {105} , {106} , {107} , {108} , {109} ) 
        self.addtheme("warntext", "orange", "", "transparent", "");
        // [493]  AddTheme( {110} , {111} , {112} , {113} , {114} ) 
        self.addtheme("successtext", "green", "", "transparent", "");
        // [494]  AddTheme( {115} , {116} , {117} , {118} , {119} ) 
        self.addtheme("infotext", "light-blue", "", "transparent", "");
        // [495]  AddTheme( {120} , {121} , {122} , {123} , {124} ) 
        self.addtheme("mutedtext", "black", "", "transparent", "");
        // [496]  AddTheme( {125} , {126} , {127} , {128} , {129} ) 
        self.addtheme("defaulttext", "light-blue", "", "transparent", "");
        // [498]  AddTheme( {130} , {131} , {132} , {133} , {134} ) 
        self.addtheme("white.amber", "white", "", "amber", "");
        // [499]  AddTheme( {135} , {136} , {137} , {138} , {139} ) 
        self.addtheme("white.black", "white", "", "black", "");
        // [500]  AddTheme( {140} , {141} , {142} , {143} , {144} ) 
        self.addtheme("white.blue", "white", "", "blue", "");
        // [501]  AddTheme( {145} , {146} , {147} ,EnumColor.BLUEGREY, {148} ) 
        self.addtheme("white.bluegrey", "white", "", self._enumcolor._bluegrey, "");
        // [502]  AddTheme( {149} , {150} , {151} , {152} , {153} ) 
        self.addtheme("white.brown", "white", "", "brown", "");
        // [503]  AddTheme( {154} , {155} , {156} , {157} , {158} ) 
        self.addtheme("white.cyan", "white", "", "cyan", "");
        // [504]  AddTheme( {159} , {160} , {161} ,EnumColor.DEEPORANGE, {162} ) 
        self.addtheme("black.deeporange", "black", "", self._enumcolor._deeporange, "");
        // [505]  AddTheme( {163} , {164} , {165} ,EnumColor.DEEPPURPLE, {166} ) 
        self.addtheme("white.deeppurple", "while", "", self._enumcolor._deeppurple, "");
        // [506]  AddTheme( {167} , {168} , {169} , {170} , {171} ) 
        self.addtheme("white.green", "while", "", "green", "");
        // [507]  AddTheme( {172} , {173} , {174} , {175} , {176} ) 
        self.addtheme("black.grey", "black", "", "green", "");
        // [508]  AddTheme( {177} , {178} , {179} , {180} , {181} ) 
        self.addtheme("white.indigo", "white", "", "indigo", "");
        // [509]  AddTheme( {182} , {183} , {184} ,EnumColor.LIGHTBLUE, {185} ) 
        self.addtheme("white.lightblue", "white", "", self._enumcolor._lightblue, "");
        // [510]  AddTheme( {186} , {187} , {188} ,EnumColor.LIGHTGREEN, {189} ) 
        self.addtheme("black.lightgreen", "white", "", self._enumcolor._lightgreen, "");
        // [511]  AddTheme( {190} , {191} , {192} ,EnumColor.lime, {193} ) 
        self.addtheme("black.lime", "white", "", self._enumcolor._lime, "");
        // [512]  AddTheme( {194} , {195} , {196} ,EnumColor.pink, {197} ) 
        self.addtheme("white.pink", "white", "", self._enumcolor._pink, "");
        // [513]  AddTheme( {198} ,EnumColor.white,EnumIntensity.NORMAL,EnumColor.orange,EnumIntensity.NORMAL) 
        self.addtheme("white.orange", self._enumcolor._white, self._enumintensity._normal, self._enumcolor._orange, self._enumintensity._normal);
        // [514]  AddTheme( {199} , {200} , {201} ,EnumColor.orange, {202} ) 
        self.addtheme("black.orange", "black", "", self._enumcolor._orange, "");
        // [515]  AddTheme( {203} , {204} , {205} ,EnumColor.purple, {206} ) 
        self.addtheme("white.purple", "white", "", self._enumcolor._purple, "");
        // [516]  AddTheme( {207} , {208} , {209} ,EnumColor.red, {210} ) 
        self.addtheme("white.red", "white", "", self._enumcolor._red, "");
        // [517]  AddTheme( {211} , {212} , {213} ,EnumColor.teal, {214} ) 
        self.addtheme("white.teal", "white", "", self._enumcolor._teal, "");
        // [518]  AddTheme( {215} , {216} , {217} ,EnumColor.black, {218} ) 
        self.addtheme("white.black", "white", "", self._enumcolor._black, "");
        // [519]  AddTheme( {219} , {220} , {221} ,EnumColor.white, {222} ) 
        self.addtheme("black.white", "black", "", self._enumcolor._white, "");
        // [520]  AddTheme( {223} , {224} , {225} ,EnumColor.yellow, {226} ) 
        self.addtheme("white.yellow", "white", "", self._enumcolor._yellow, "");
        // [521]  AddTheme( {227} , {228} , {229} ,EnumColor.yellow, {230} ) 
        self.addtheme("black.yellow", "black", "", self._enumcolor._yellow, "");
        // [522]  ImageTopMargin = {231} 
        self._imagetopmargin = "8px";
        // [523]  ImageHW = {232} 
        self._imagehw = "32px";
        // [524]  ItemHeight = {233} 
        self._itemheight = "43px";
        // End Sub
    };

    // [561] Sub TooltipExist(ttName As String) As Boolean 
    this.tooltipexist = function (_ttname) {
        if (self == null) self = this;
        // [562]  ttName = ttName.ToLowerCase 
        _ttname = _ttname.toLowerCase();
        // [563]  Return ToolTips.ContainsKey(ttName) 
        return (_ttname in self._tooltips);
        // End Sub
    };

    // [567] Sub getTooltip(ttName As String) As UOEToolTip 
    this.gettooltip = function (_ttname) {
        if (self == null) self = this;
        var _tt;
        // [568]  ttName = ttName.ToLowerCase 
        _ttname = _ttname.toLowerCase();
        // [569]  Dim tt As UOEToolTip = ToolTips.Get(ttName) 
        _tt = self._tooltips[_ttname];
        // [570]  Return tt 
        return _tt;
        // End Sub
    };

    // [573] Sub ElementExists(elID As String) As Boolean 
    this.elementexists = function (_elid) {
        if (self == null) self = this;
        // [574]  Return BANano.GetElement(elID).Length > 0 
        return u(_elid).length > 0;
        // End Sub
    };

    // [577] Sub ApplyToolTip(elID As String, el As UOEHTML) 
    this.applytooltip = function (_elid, _el) {
        if (self == null) self = this;
        var _texist;
        var _tt;
        // [578]  Dim tExist As Boolean = TooltipExist(elID) 
        _texist = self.tooltipexist(_elid);
        // [579]  If tExist Then 
        if (_texist) {
            // [580]  Dim tt As UOEToolTip = getTooltip(elID) 
            _tt = self.gettooltip(_elid);
            // [581]  el.MaterialSetToolTip(tt.Position,tt.Delay,tt.text) 
            _el.materialsettooltip(_tt._position, _tt._delay, _tt._text);
            // [582]  End If 
        }
        // End Sub
    };

    // [587] Sub MaterialUseThemeOnCondition(bStatus As Boolean, themeName As String, element As UOEHTML) 
    this.materialusethemeoncondition = function (_bstatus, _themename, _element) {
        if (self == null) self = this;
        // [588]  If bStatus = True Then 
        if (_bstatus == true) {
            // [589]  MaterialUseTheme(themeName, element) 
            self.materialusetheme(_themename, _element);
            // [590]  End If 
        }
        // End Sub
    };

    // [595] Sub GetElement(elID As String) As BANanoElement 
    this.getelement = function (_elid) {
        if (self == null) self = this;
        var _skey;
        // [596]  elID = elID.ToLowerCase 
        _elid = _elid.toLowerCase();
        // [597]  Dim sKey As String = {14} 
        _skey = "#" + _elid + "";
        // [598]  Return BANano.GetElement(sKey) 
        return u(_skey);
        // End Sub
    };

    // [603] private Sub InitColorMap 
    this.initcolormap = function () {
        if (self == null) self = this;
        // [604]  ColorMap.Initialize 
        self._colormap = {};
        // [605]  ColorMap.clear 
        self._colormap = {};
        // [606]  ColorMap.Put( {240} , {241} ) 
        self._colormap["maroon"] = "#800000";
        // [607]  ColorMap.put( {242} , {243} ) 
        self._colormap["red"] = "#f44336";
        // [608]  ColorMap.put( {244} , {245} ) 
        self._colormap["orange"] = "#ff9800";
        // [609]  ColorMap.put( {246} , {247} ) 
        self._colormap["yellow"] = "#ffeb3b";
        // [610]  ColorMap.put( {248} , {249} ) 
        self._colormap["olive"] = "#808000";
        // [611]  ColorMap.put( {250} , {251} ) 
        self._colormap["green"] = "#4caf50";
        // [612]  ColorMap.put( {252} , {253} ) 
        self._colormap["purple"] = "#9c27b0";
        // [613]  ColorMap.Put( {254} , {255} ) 
        self._colormap["fuchsia"] = "#ff00ff";
        // [614]  ColorMap.put( {256} , {257} ) 
        self._colormap["lime"] = "#cddc39";
        // [615]  ColorMap.put( {258} , {259} ) 
        self._colormap["teal"] = "#009688";
        // [616]  ColorMap.Put( {260} , {261} ) 
        self._colormap["aqua"] = "#00ffff";
        // [617]  ColorMap.put( {262} , {263} ) 
        self._colormap["grey"] = "#9e9e9e";
        // [618]  ColorMap.put( {264} , {265} ) 
        self._colormap["pink"] = "#e91e63";
        // [619]  ColorMap.put( {266} , {267} ) 
        self._colormap["blue"] = "#2196f3";
        // [620]  ColorMap.put( {268} , {269} ) 
        self._colormap["brown"] = "#795548";
        // [621]  ColorMap.put( {270} , {271} ) 
        self._colormap["deep-purple"] = "#673ab7";
        // [622]  ColorMap.put( {272} , {273} ) 
        self._colormap["indigo"] = "#3f51b5";
        // [623]  ColorMap.put( {274} , {275} ) 
        self._colormap["light-blue"] = "#03a9f4";
        // [624]  ColorMap.put( {276} , {277} ) 
        self._colormap["cyan"] = "#00bcd4";
        // [625]  ColorMap.put( {278} , {279} ) 
        self._colormap["light-green"] = "#8bc34a";
        // [626]  ColorMap.put( {280} , {281} ) 
        self._colormap["amber"] = "#ffc107";
        // [627]  ColorMap.put( {282} , {283} ) 
        self._colormap["deep-orange"] = "#ff5722";
        // [628]  ColorMap.put( {284} , {285} ) 
        self._colormap["blue-grey"] = "#607d8b";
        // [629]  ColorMap.put( {286} , {287} ) 
        self._colormap["black"] = "#000000";
        // [630]  ColorMap.put( {288} , {289} ) 
        self._colormap["navy"] = "#000080";
        // [631]  ColorMap.Put( {290} , {291} ) 
        self._colormap["silver"] = "#c0c0c0";
        // [632]  ColorMap.Put( {292} , {293} ) 
        self._colormap["aquamarine"] = "#7fffd4";
        // [633]  ColorMap.put( {294} , {295} ) 
        self._colormap["white"] = "#ffffff";
        // [634]  ColorMap.Put( {296} , {297} ) 
        self._colormap["blueviolet"] = "#8a2be2";
        // [635]  ColorMap.Put( {298} , {299} ) 
        self._colormap["burlywood"] = "#deb887";
        // [636]  ColorMap.Put( {300} , {301} ) 
        self._colormap["cadetblue"] = "#5f9ea0";
        // [637]  ColorMap.Put( {302} , {303} ) 
        self._colormap["chartreuse"] = "#7fff00";
        // [638]  ColorMap.Put( {304} , {305} ) 
        self._colormap["chocolate"] = "#d2691e";
        // [639]  ColorMap.Put( {306} , {307} ) 
        self._colormap["coral"] = "#ff7f50";
        // [640]  ColorMap.Put( {308} , {309} ) 
        self._colormap["cornflowerblue"] = "#6495ed";
        // [641]  ColorMap.Put( {310} , {311} ) 
        self._colormap["forestgreen"] = "#228b22";
        // [642]  ColorMap.put( {312} , {313} ) 
        self._colormap["gold"] = "#ffd700";
        // [643]  ColorMap.Put( {314} , {315} ) 
        self._colormap["goldenrod"] = "#daa520";
        // [644]  ColorMap.Put( {316} , {317} ) 
        self._colormap["khaki"] = "#f0e68c";
        // [645]  ColorMap.Put( {318} , {319} ) 
        self._colormap["lavendar"] = "#e6e6fa";
        // [646]  ColorMap.Put( {320} , {321} ) 
        self._colormap["lightcoral"] = "#f08080";
        // [647]  ColorMap.put( {322} , {323} ) 
        self._colormap["lightseagreen"] = "#20b2aa";
        // [648]  ColorMap.put( {324} , {325} ) 
        self._colormap["rosybrown"] = "#bc8f8f";
        // [649]  ColorMap.Put( {326} , {327} ) 
        self._colormap["steelblue"] = "#4682b4";
        // [650]  ColorMap.Put( {328} , {329} ) 
        self._colormap["yellowgreen"] = "#9acd32";
        // [651]  ColorMap.put( {330} , {331} ) 
        self._colormap["red lighten-5"] = "#ffebee";
        // [652]  ColorMap.put( {332} , {333} ) 
        self._colormap["red lighten-4"] = "#ffcdd2";
        // [653]  ColorMap.put( {334} , {335} ) 
        self._colormap["red lighten-3"] = "#ef9a9a";
        // [654]  ColorMap.put( {336} , {337} ) 
        self._colormap["red lighten-2"] = "#e57373";
        // [655]  ColorMap.put( {338} , {339} ) 
        self._colormap["red lighten-1"] = "#ef5350";
        // [656]  ColorMap.put( {340} , {341} ) 
        self._colormap["red"] = "#f44336";
        // [657]  ColorMap.put( {342} , {343} ) 
        self._colormap["red darken-1"] = "#e53935";
        // [658]  ColorMap.put( {344} , {345} ) 
        self._colormap["red darken-2"] = "#d32f2f";
        // [659]  ColorMap.put( {346} , {347} ) 
        self._colormap["red darken-3"] = "#c62828";
        // [660]  ColorMap.put( {348} , {349} ) 
        self._colormap["red darken-4"] = "#b71c1c";
        // [661]  ColorMap.put( {350} , {351} ) 
        self._colormap["red accent-1"] = "#ff8a80";
        // [662]  ColorMap.put( {352} , {353} ) 
        self._colormap["red accent-2"] = "#ff5252";
        // [663]  ColorMap.put( {354} , {355} ) 
        self._colormap["red accent-3"] = "#ff1744";
        // [664]  ColorMap.put( {356} , {357} ) 
        self._colormap["red accent-4"] = "#d50000";
        // [665]  ColorMap.put( {358} , {359} ) 
        self._colormap["pink lighten-5"] = "#fce4ec";
        // [666]  ColorMap.put( {360} , {361} ) 
        self._colormap["pink lighten-4"] = "#f8bbd0";
        // [667]  ColorMap.put( {362} , {363} ) 
        self._colormap["pink lighten-3"] = "#f48fb1";
        // [668]  ColorMap.put( {364} , {365} ) 
        self._colormap["pink lighten-2"] = "#f06292";
        // [669]  ColorMap.put( {366} , {367} ) 
        self._colormap["pink lighten-1"] = "#ec407a";
        // [670]  ColorMap.put( {368} , {369} ) 
        self._colormap["pink"] = "#e91e63";
        // [671]  ColorMap.put( {370} , {371} ) 
        self._colormap["pink darken-1"] = "#d81b60";
        // [672]  ColorMap.put( {372} , {373} ) 
        self._colormap["pink darken-2"] = "#c2185b";
        // [673]  ColorMap.put( {374} , {375} ) 
        self._colormap["pink darken-3"] = "#ad1457";
        // [674]  ColorMap.put( {376} , {377} ) 
        self._colormap["pink darken-4"] = "#880e4f";
        // [675]  ColorMap.put( {378} , {379} ) 
        self._colormap["pink accent-1"] = "#ff80ab";
        // [676]  ColorMap.put( {380} , {381} ) 
        self._colormap["pink accent-2"] = "#ff4081";
        // [677]  ColorMap.put( {382} , {383} ) 
        self._colormap["pink accent-3"] = "#f50057";
        // [678]  ColorMap.put( {384} , {385} ) 
        self._colormap["pink accent-4"] = "#c51162";
        // [679]  ColorMap.put( {386} , {387} ) 
        self._colormap["purple lighten-5"] = "#f3e5f5";
        // [680]  ColorMap.put( {388} , {389} ) 
        self._colormap["purple lighten-4"] = "#e1bee7";
        // [681]  ColorMap.put( {390} , {391} ) 
        self._colormap["purple lighten-3"] = "#ce93d8";
        // [682]  ColorMap.put( {392} , {393} ) 
        self._colormap["purple lighten-2"] = "#ba68c8";
        // [683]  ColorMap.put( {394} , {395} ) 
        self._colormap["purple lighten-1"] = "#ab47bc";
        // [684]  ColorMap.put( {396} , {397} ) 
        self._colormap["purple"] = "#9c27b0";
        // [685]  ColorMap.put( {398} , {399} ) 
        self._colormap["purple darken-1"] = "#8e24aa";
        // [686]  ColorMap.put( {400} , {401} ) 
        self._colormap["purple darken-2"] = "#7b1fa2";
        // [687]  ColorMap.put( {402} , {403} ) 
        self._colormap["purple darken-3"] = "#6a1b9a";
        // [688]  ColorMap.put( {404} , {405} ) 
        self._colormap["purple darken-4"] = "#4a148c";
        // [689]  ColorMap.put( {406} , {407} ) 
        self._colormap["purple accent-1"] = "#ea80fc";
        // [690]  ColorMap.put( {408} , {409} ) 
        self._colormap["purple accent-2"] = "#e040fb";
        // [691]  ColorMap.put( {410} , {411} ) 
        self._colormap["purple accent-3"] = "#d500f9";
        // [692]  ColorMap.put( {412} , {413} ) 
        self._colormap["purple accent-4"] = "#aa00ff";
        // [693]  ColorMap.put( {414} , {415} ) 
        self._colormap["deep-purple lighten-5"] = "#ede7f6";
        // [694]  ColorMap.put( {416} , {417} ) 
        self._colormap["deep-purple lighten-4"] = "#d1c4e9";
        // [695]  ColorMap.put( {418} , {419} ) 
        self._colormap["deep-purple lighten-3"] = "#b39ddb";
        // [696]  ColorMap.put( {420} , {421} ) 
        self._colormap["deep-purple lighten-2"] = "#9575cd";
        // [697]  ColorMap.put( {422} , {423} ) 
        self._colormap["deep-purple lighten-1"] = "#7e57c2";
        // [698]  ColorMap.put( {424} , {425} ) 
        self._colormap["deep-purple"] = "#673ab7";
        // [699]  ColorMap.put( {426} , {427} ) 
        self._colormap["deep-purple darken-1"] = "#5e35b1";
        // [700]  ColorMap.put( {428} , {429} ) 
        self._colormap["deep-purple darken-2"] = "#512da8";
        // [701]  ColorMap.put( {430} , {431} ) 
        self._colormap["deep-purple darken-3"] = "#4527a0";
        // [702]  ColorMap.put( {432} , {433} ) 
        self._colormap["deep-purple darken-4"] = "#311b92";
        // [703]  ColorMap.put( {434} , {435} ) 
        self._colormap["deep-purple accent-1"] = "#b388ff";
        // [704]  ColorMap.put( {436} , {437} ) 
        self._colormap["deep-purple accent-2"] = "#7c4dff";
        // [705]  ColorMap.put( {438} , {439} ) 
        self._colormap["deep-purple accent-3"] = "#651fff";
        // [706]  ColorMap.put( {440} , {441} ) 
        self._colormap["deep-purple accent-4"] = "#6200ea";
        // [707]  ColorMap.put( {442} , {443} ) 
        self._colormap["indigo lighten-5"] = "#e8eaf6";
        // [708]  ColorMap.put( {444} , {445} ) 
        self._colormap["indigo lighten-4"] = "#c5cae9";
        // [709]  ColorMap.put( {446} , {447} ) 
        self._colormap["indigo lighten-3"] = "#9fa8da";
        // [710]  ColorMap.put( {448} , {449} ) 
        self._colormap["indigo lighten-2"] = "#7986cb";
        // [711]  ColorMap.put( {450} , {451} ) 
        self._colormap["indigo lighten-1"] = "#5c6bc0";
        // [712]  ColorMap.put( {452} , {453} ) 
        self._colormap["indigo"] = "#3f51b5";
        // [713]  ColorMap.put( {454} , {455} ) 
        self._colormap["indigo darken-1"] = "#3949ab";
        // [714]  ColorMap.put( {456} , {457} ) 
        self._colormap["indigo darken-2"] = "#303f9f";
        // [715]  ColorMap.put( {458} , {459} ) 
        self._colormap["indigo darken-3"] = "#283593";
        // [716]  ColorMap.put( {460} , {461} ) 
        self._colormap["indigo darken-4"] = "#1a237e";
        // [717]  ColorMap.put( {462} , {463} ) 
        self._colormap["indigo accent-1"] = "#8c9eff";
        // [718]  ColorMap.put( {464} , {465} ) 
        self._colormap["indigo accent-2"] = "#536dfe";
        // [719]  ColorMap.put( {466} , {467} ) 
        self._colormap["indigo accent-3"] = "#3d5afe";
        // [720]  ColorMap.put( {468} , {469} ) 
        self._colormap["indigo accent-4"] = "#304ffe";
        // [721]  ColorMap.put( {470} , {471} ) 
        self._colormap["blue lighten-5"] = "#e3f2fd";
        // [722]  ColorMap.put( {472} , {473} ) 
        self._colormap["blue lighten-4"] = "#bbdefb";
        // [723]  ColorMap.put( {474} , {475} ) 
        self._colormap["blue lighten-3"] = "#90caf9";
        // [724]  ColorMap.put( {476} , {477} ) 
        self._colormap["blue lighten-2"] = "#64b5f6";
        // [725]  ColorMap.put( {478} , {479} ) 
        self._colormap["blue lighten-1"] = "#42a5f5";
        // [726]  ColorMap.put( {480} , {481} ) 
        self._colormap["blue"] = "#2196f3";
        // [727]  ColorMap.put( {482} , {483} ) 
        self._colormap["blue darken-1"] = "#1e88e5";
        // [728]  ColorMap.put( {484} , {485} ) 
        self._colormap["blue darken-2"] = "#1976d2";
        // [729]  ColorMap.put( {486} , {487} ) 
        self._colormap["blue darken-3"] = "#1565c0";
        // [730]  ColorMap.put( {488} , {489} ) 
        self._colormap["blue darken-4"] = "#0d47a1";
        // [731]  ColorMap.put( {490} , {491} ) 
        self._colormap["blue accent-1"] = "#82b1ff";
        // [732]  ColorMap.put( {492} , {493} ) 
        self._colormap["blue accent-2"] = "#448aff";
        // [733]  ColorMap.put( {494} , {495} ) 
        self._colormap["blue accent-3"] = "#2979ff";
        // [734]  ColorMap.put( {496} , {497} ) 
        self._colormap["blue accent-4"] = "#2962ff";
        // [735]  ColorMap.put( {498} , {499} ) 
        self._colormap["light-blue lighten-5"] = "#e1f5fe";
        // [736]  ColorMap.put( {500} , {501} ) 
        self._colormap["light-blue lighten-4"] = "#b3e5fc";
        // [737]  ColorMap.put( {502} , {503} ) 
        self._colormap["light-blue lighten-3"] = "#81d4fa";
        // [738]  ColorMap.put( {504} , {505} ) 
        self._colormap["light-blue lighten-2"] = "#4fc3f7";
        // [739]  ColorMap.put( {506} , {507} ) 
        self._colormap["light-blue lighten-1"] = "#29b6f6";
        // [740]  ColorMap.put( {508} , {509} ) 
        self._colormap["light-blue"] = "#03a9f4";
        // [741]  ColorMap.put( {510} , {511} ) 
        self._colormap["light-blue darken-1"] = "#039be5";
        // [742]  ColorMap.put( {512} , {513} ) 
        self._colormap["light-blue darken-2"] = "#0288d1";
        // [743]  ColorMap.put( {514} , {515} ) 
        self._colormap["light-blue darken-3"] = "#0277bd";
        // [744]  ColorMap.put( {516} , {517} ) 
        self._colormap["light-blue darken-4"] = "#01579b";
        // [745]  ColorMap.put( {518} , {519} ) 
        self._colormap["light-blue accent-1"] = "#80d8ff";
        // [746]  ColorMap.put( {520} , {521} ) 
        self._colormap["light-blue accent-2"] = "#40c4ff";
        // [747]  ColorMap.put( {522} , {523} ) 
        self._colormap["light-blue accent-3"] = "#00b0ff";
        // [748]  ColorMap.put( {524} , {525} ) 
        self._colormap["light-blue accent-4"] = "#0091ea";
        // [749]  ColorMap.put( {526} , {527} ) 
        self._colormap["cyan lighten-5"] = "#e0f7fa";
        // [750]  ColorMap.put( {528} , {529} ) 
        self._colormap["cyan lighten-4"] = "#b2ebf2";
        // [751]  ColorMap.put( {530} , {531} ) 
        self._colormap["cyan lighten-3"] = "#80deea";
        // [752]  ColorMap.put( {532} , {533} ) 
        self._colormap["cyan lighten-2"] = "#4dd0e1";
        // [753]  ColorMap.put( {534} , {535} ) 
        self._colormap["cyan lighten-1"] = "#26c6da";
        // [754]  ColorMap.put( {536} , {537} ) 
        self._colormap["cyan"] = "#00bcd4";
        // [755]  ColorMap.put( {538} , {539} ) 
        self._colormap["cyan darken-1"] = "#00acc1";
        // [756]  ColorMap.put( {540} , {541} ) 
        self._colormap["cyan darken-2"] = "#0097a7";
        // [757]  ColorMap.put( {542} , {543} ) 
        self._colormap["cyan darken-3"] = "#00838f";
        // [758]  ColorMap.put( {544} , {545} ) 
        self._colormap["cyan darken-4"] = "#006064";
        // [759]  ColorMap.put( {546} , {547} ) 
        self._colormap["cyan accent-1"] = "#84ffff";
        // [760]  ColorMap.put( {548} , {549} ) 
        self._colormap["cyan accent-2"] = "#18ffff";
        // [761]  ColorMap.put( {550} , {551} ) 
        self._colormap["cyan accent-3"] = "#00e5ff";
        // [762]  ColorMap.put( {552} , {553} ) 
        self._colormap["cyan accent-4"] = "#00b8d4";
        // [763]  ColorMap.put( {554} , {555} ) 
        self._colormap["teal lighten-5"] = "#e0f2f1";
        // [764]  ColorMap.put( {556} , {557} ) 
        self._colormap["teal lighten-4"] = "#b2dfdb";
        // [765]  ColorMap.put( {558} , {559} ) 
        self._colormap["teal lighten-3"] = "#80cbc4";
        // [766]  ColorMap.put( {560} , {561} ) 
        self._colormap["teal lighten-2"] = "#4db6ac";
        // [767]  ColorMap.put( {562} , {563} ) 
        self._colormap["teal lighten-1"] = "#26a69a";
        // [768]  ColorMap.put( {564} , {565} ) 
        self._colormap["teal"] = "#009688";
        // [769]  ColorMap.put( {566} , {567} ) 
        self._colormap["teal darken-1"] = "#00897b";
        // [770]  ColorMap.put( {568} , {569} ) 
        self._colormap["teal darken-2"] = "#00796b";
        // [771]  ColorMap.put( {570} , {571} ) 
        self._colormap["teal darken-3"] = "#00695c";
        // [772]  ColorMap.put( {572} , {573} ) 
        self._colormap["teal darken-4"] = "#004d40";
        // [773]  ColorMap.put( {574} , {575} ) 
        self._colormap["teal accent-1"] = "#a7ffeb";
        // [774]  ColorMap.put( {576} , {577} ) 
        self._colormap["teal accent-2"] = "#64ffda";
        // [775]  ColorMap.put( {578} , {579} ) 
        self._colormap["teal accent-3"] = "#1de9b6";
        // [776]  ColorMap.put( {580} , {581} ) 
        self._colormap["teal accent-4"] = "#00bfa5";
        // [777]  ColorMap.put( {582} , {583} ) 
        self._colormap["green lighten-5"] = "#e8f5e9";
        // [778]  ColorMap.put( {584} , {585} ) 
        self._colormap["green lighten-4"] = "#c8e6c9";
        // [779]  ColorMap.put( {586} , {587} ) 
        self._colormap["green lighten-3"] = "#a5d6a7";
        // [780]  ColorMap.put( {588} , {589} ) 
        self._colormap["green lighten-2"] = "#81c784";
        // [781]  ColorMap.put( {590} , {591} ) 
        self._colormap["green lighten-1"] = "#66bb6a";
        // [782]  ColorMap.put( {592} , {593} ) 
        self._colormap["green"] = "#4caf50";
        // [783]  ColorMap.put( {594} , {595} ) 
        self._colormap["green darken-1"] = "#43a047";
        // [784]  ColorMap.put( {596} , {597} ) 
        self._colormap["green darken-2"] = "#388e3c";
        // [785]  ColorMap.put( {598} , {599} ) 
        self._colormap["green darken-3"] = "#2e7d32";
        // [786]  ColorMap.put( {600} , {601} ) 
        self._colormap["green darken-4"] = "#1b5e20";
        // [787]  ColorMap.put( {602} , {603} ) 
        self._colormap["green accent-1"] = "#b9f6ca";
        // [788]  ColorMap.put( {604} , {605} ) 
        self._colormap["green accent-2"] = "#69f0ae";
        // [789]  ColorMap.put( {606} , {607} ) 
        self._colormap["green accent-3"] = "#00e676";
        // [790]  ColorMap.put( {608} , {609} ) 
        self._colormap["green accent-4"] = "#00c853";
        // [791]  ColorMap.put( {610} , {611} ) 
        self._colormap["light-green lighten-5"] = "#f1f8e9";
        // [792]  ColorMap.put( {612} , {613} ) 
        self._colormap["light-green lighten-4"] = "#dcedc8";
        // [793]  ColorMap.put( {614} , {615} ) 
        self._colormap["light-green lighten-3"] = "#c5e1a5";
        // [794]  ColorMap.put( {616} , {617} ) 
        self._colormap["light-green lighten-2"] = "#aed581";
        // [795]  ColorMap.put( {618} , {619} ) 
        self._colormap["light-green lighten-1"] = "#9ccc65";
        // [796]  ColorMap.put( {620} , {621} ) 
        self._colormap["light-green"] = "#8bc34a";
        // [797]  ColorMap.put( {622} , {623} ) 
        self._colormap["light-green darken-1"] = "#7cb342";
        // [798]  ColorMap.put( {624} , {625} ) 
        self._colormap["light-green darken-2"] = "#689f38";
        // [799]  ColorMap.put( {626} , {627} ) 
        self._colormap["light-green darken-3"] = "#558b2f";
        // [800]  ColorMap.put( {628} , {629} ) 
        self._colormap["light-green darken-4"] = "#33691e";
        // [801]  ColorMap.put( {630} , {631} ) 
        self._colormap["light-green accent-1"] = "#ccff90";
        // [802]  ColorMap.put( {632} , {633} ) 
        self._colormap["light-green accent-2"] = "#b2ff59";
        // [803]  ColorMap.put( {634} , {635} ) 
        self._colormap["light-green accent-3"] = "#76ff03";
        // [804]  ColorMap.put( {636} , {637} ) 
        self._colormap["light-green accent-4"] = "#64dd17";
        // [805]  ColorMap.put( {638} , {639} ) 
        self._colormap["lime lighten-5"] = "#f9fbe7";
        // [806]  ColorMap.put( {640} , {641} ) 
        self._colormap["lime lighten-4"] = "#f0f4c3";
        // [807]  ColorMap.put( {642} , {643} ) 
        self._colormap["lime lighten-3"] = "#e6ee9c";
        // [808]  ColorMap.put( {644} , {645} ) 
        self._colormap["lime lighten-2"] = "#dce775";
        // [809]  ColorMap.put( {646} , {647} ) 
        self._colormap["lime lighten-1"] = "#d4e157";
        // [810]  ColorMap.put( {648} , {649} ) 
        self._colormap["lime"] = "#cddc39";
        // [811]  ColorMap.put( {650} , {651} ) 
        self._colormap["lime darken-1"] = "#c0ca33";
        // [812]  ColorMap.put( {652} , {653} ) 
        self._colormap["lime darken-2"] = "#afb42b";
        // [813]  ColorMap.put( {654} , {655} ) 
        self._colormap["lime darken-3"] = "#9e9d24";
        // [814]  ColorMap.put( {656} , {657} ) 
        self._colormap["lime darken-4"] = "#827717";
        // [815]  ColorMap.put( {658} , {659} ) 
        self._colormap["lime accent-1"] = "#f4ff81";
        // [816]  ColorMap.put( {660} , {661} ) 
        self._colormap["lime accent-2"] = "#eeff41";
        // [817]  ColorMap.put( {662} , {663} ) 
        self._colormap["lime accent-3"] = "#c6ff00";
        // [818]  ColorMap.put( {664} , {665} ) 
        self._colormap["lime accent-4"] = "#aeea00";
        // [819]  ColorMap.put( {666} , {667} ) 
        self._colormap["yellow lighten-5"] = "#fffde7";
        // [820]  ColorMap.put( {668} , {669} ) 
        self._colormap["yellow lighten-4"] = "#fff9c4";
        // [821]  ColorMap.put( {670} , {671} ) 
        self._colormap["yellow lighten-3"] = "#fff59d";
        // [822]  ColorMap.put( {672} , {673} ) 
        self._colormap["yellow lighten-2"] = "#fff176";
        // [823]  ColorMap.put( {674} , {675} ) 
        self._colormap["yellow lighten-1"] = "#ffee58";
        // [824]  ColorMap.put( {676} , {677} ) 
        self._colormap["yellow"] = "#ffeb3b";
        // [825]  ColorMap.put( {678} , {679} ) 
        self._colormap["yellow darken-1"] = "#fdd835";
        // [826]  ColorMap.put( {680} , {681} ) 
        self._colormap["yellow darken-2"] = "#fbc02d";
        // [827]  ColorMap.put( {682} , {683} ) 
        self._colormap["yellow darken-3"] = "#f9a825";
        // [828]  ColorMap.put( {684} , {685} ) 
        self._colormap["yellow darken-4"] = "#f57f17";
        // [829]  ColorMap.put( {686} , {687} ) 
        self._colormap["yellow accent-1"] = "#ffff8d";
        // [830]  ColorMap.put( {688} , {689} ) 
        self._colormap["yellow accent-2"] = "#ffff00";
        // [831]  ColorMap.put( {690} , {691} ) 
        self._colormap["yellow accent-3"] = "#ffea00";
        // [832]  ColorMap.put( {692} , {693} ) 
        self._colormap["yellow accent-4"] = "#ffd600";
        // [833]  ColorMap.put( {694} , {695} ) 
        self._colormap["amber lighten-5"] = "#fff8e1";
        // [834]  ColorMap.put( {696} , {697} ) 
        self._colormap["amber lighten-4"] = "#ffecb3";
        // [835]  ColorMap.put( {698} , {699} ) 
        self._colormap["amber lighten-3"] = "#ffe082";
        // [836]  ColorMap.put( {700} , {701} ) 
        self._colormap["amber lighten-2"] = "#ffd54f";
        // [837]  ColorMap.put( {702} , {703} ) 
        self._colormap["amber lighten-1"] = "#ffca28";
        // [838]  ColorMap.put( {704} , {705} ) 
        self._colormap["amber"] = "#ffc107";
        // [839]  ColorMap.put( {706} , {707} ) 
        self._colormap["amber darken-1"] = "#ffb300";
        // [840]  ColorMap.put( {708} , {709} ) 
        self._colormap["amber darken-2"] = "#ffa000";
        // [841]  ColorMap.put( {710} , {711} ) 
        self._colormap["amber darken-3"] = "#ff8f00";
        // [842]  ColorMap.put( {712} , {713} ) 
        self._colormap["amber darken-4"] = "#ff6f00";
        // [843]  ColorMap.put( {714} , {715} ) 
        self._colormap["amber accent-1"] = "#ffe57f";
        // [844]  ColorMap.put( {716} , {717} ) 
        self._colormap["amber accent-2"] = "#ffd740";
        // [845]  ColorMap.put( {718} , {719} ) 
        self._colormap["amber accent-3"] = "#ffc400";
        // [846]  ColorMap.put( {720} , {721} ) 
        self._colormap["amber accent-4"] = "#ffab00";
        // [847]  ColorMap.put( {722} , {723} ) 
        self._colormap["orange lighten-5"] = "#fff3e0";
        // [848]  ColorMap.put( {724} , {725} ) 
        self._colormap["orange lighten-4"] = "#ffe0b2";
        // [849]  ColorMap.put( {726} , {727} ) 
        self._colormap["orange lighten-3"] = "#ffcc80";
        // [850]  ColorMap.put( {728} , {729} ) 
        self._colormap["orange lighten-2"] = "#ffb74d";
        // [851]  ColorMap.put( {730} , {731} ) 
        self._colormap["orange lighten-1"] = "#ffa726";
        // [852]  ColorMap.put( {732} , {733} ) 
        self._colormap["orange"] = "#ff9800";
        // [853]  ColorMap.put( {734} , {735} ) 
        self._colormap["orange darken-1"] = "#fb8c00";
        // [854]  ColorMap.put( {736} , {737} ) 
        self._colormap["orange darken-2"] = "#f57c00";
        // [855]  ColorMap.put( {738} , {739} ) 
        self._colormap["orange darken-3"] = "#ef6c00";
        // [856]  ColorMap.put( {740} , {741} ) 
        self._colormap["orange darken-4"] = "#e65100";
        // [857]  ColorMap.put( {742} , {743} ) 
        self._colormap["orange accent-1"] = "#ffd180";
        // [858]  ColorMap.put( {744} , {745} ) 
        self._colormap["orange accent-2"] = "#ffab40";
        // [859]  ColorMap.put( {746} , {747} ) 
        self._colormap["orange accent-3"] = "#ff9100";
        // [860]  ColorMap.put( {748} , {749} ) 
        self._colormap["orange accent-4"] = "#ff6d00";
        // [861]  ColorMap.put( {750} , {751} ) 
        self._colormap["deep-orange lighten-5"] = "#fbe9e7";
        // [862]  ColorMap.put( {752} , {753} ) 
        self._colormap["deep-orange lighten-4"] = "#ffccbc";
        // [863]  ColorMap.put( {754} , {755} ) 
        self._colormap["deep-orange lighten-3"] = "#ffab91";
        // [864]  ColorMap.put( {756} , {757} ) 
        self._colormap["deep-orange lighten-2"] = "#ff8a65";
        // [865]  ColorMap.put( {758} , {759} ) 
        self._colormap["deep-orange lighten-1"] = "#ff7043";
        // [866]  ColorMap.put( {760} , {761} ) 
        self._colormap["deep-orange"] = "#ff5722";
        // [867]  ColorMap.put( {762} , {763} ) 
        self._colormap["deep-orange darken-1"] = "#f4511e";
        // [868]  ColorMap.put( {764} , {765} ) 
        self._colormap["deep-orange darken-2"] = "#e64a19";
        // [869]  ColorMap.put( {766} , {767} ) 
        self._colormap["deep-orange darken-3"] = "#d84315";
        // [870]  ColorMap.put( {768} , {769} ) 
        self._colormap["deep-orange darken-4"] = "#bf360c";
        // [871]  ColorMap.put( {770} , {771} ) 
        self._colormap["deep-orange accent-1"] = "#ff9e80";
        // [872]  ColorMap.put( {772} , {773} ) 
        self._colormap["deep-orange accent-2"] = "#ff6e40";
        // [873]  ColorMap.put( {774} , {775} ) 
        self._colormap["deep-orange accent-3"] = "#ff3d00";
        // [874]  ColorMap.put( {776} , {777} ) 
        self._colormap["deep-orange accent-4"] = "#dd2c00";
        // [875]  ColorMap.put( {778} , {779} ) 
        self._colormap["brown lighten-5"] = "#efebe9";
        // [876]  ColorMap.put( {780} , {781} ) 
        self._colormap["brown lighten-4"] = "#d7ccc8";
        // [877]  ColorMap.put( {782} , {783} ) 
        self._colormap["brown lighten-3"] = "#bcaaa4";
        // [878]  ColorMap.put( {784} , {785} ) 
        self._colormap["brown lighten-2"] = "#a1887f";
        // [879]  ColorMap.put( {786} , {787} ) 
        self._colormap["brown lighten-1"] = "#8d6e63";
        // [880]  ColorMap.put( {788} , {789} ) 
        self._colormap["brown"] = "#795548";
        // [881]  ColorMap.put( {790} , {791} ) 
        self._colormap["brown darken-1"] = "#6d4c41";
        // [882]  ColorMap.put( {792} , {793} ) 
        self._colormap["brown darken-2"] = "#5d4037";
        // [883]  ColorMap.put( {794} , {795} ) 
        self._colormap["brown darken-3"] = "#4e342e";
        // [884]  ColorMap.put( {796} , {797} ) 
        self._colormap["brown darken-4"] = "#3e2723";
        // [885]  ColorMap.put( {798} , {799} ) 
        self._colormap["grey lighten-5"] = "#fafafa";
        // [886]  ColorMap.put( {800} , {801} ) 
        self._colormap["grey lighten-4"] = "#f5f5f5";
        // [887]  ColorMap.put( {802} , {803} ) 
        self._colormap["grey lighten-3"] = "#eeeeee";
        // [888]  ColorMap.put( {804} , {805} ) 
        self._colormap["grey lighten-2"] = "#e0e0e0";
        // [889]  ColorMap.put( {806} , {807} ) 
        self._colormap["grey lighten-1"] = "#bdbdbd";
        // [890]  ColorMap.put( {808} , {809} ) 
        self._colormap["grey"] = "#9e9e9e";
        // [891]  ColorMap.put( {810} , {811} ) 
        self._colormap["grey darken-1"] = "#757575";
        // [892]  ColorMap.put( {812} , {813} ) 
        self._colormap["grey darken-2"] = "#616161";
        // [893]  ColorMap.put( {814} , {815} ) 
        self._colormap["grey darken-3"] = "#424242";
        // [894]  ColorMap.put( {816} , {817} ) 
        self._colormap["grey darken-4"] = "#212121";
        // [895]  ColorMap.put( {818} , {819} ) 
        self._colormap["blue-grey lighten-5"] = "#eceff1";
        // [896]  ColorMap.put( {820} , {821} ) 
        self._colormap["blue-grey lighten-4"] = "#cfd8dc";
        // [897]  ColorMap.put( {822} , {823} ) 
        self._colormap["blue-grey lighten-3"] = "#b0bec5";
        // [898]  ColorMap.put( {824} , {825} ) 
        self._colormap["blue-grey lighten-2"] = "#90a4ae";
        // [899]  ColorMap.put( {826} , {827} ) 
        self._colormap["blue-grey lighten-1"] = "#78909c";
        // [900]  ColorMap.put( {828} , {829} ) 
        self._colormap["blue-grey"] = "#607d8b";
        // [901]  ColorMap.put( {830} , {831} ) 
        self._colormap["blue-grey darken-1"] = "#546e7a";
        // [902]  ColorMap.put( {832} , {833} ) 
        self._colormap["blue-grey darken-2"] = "#455a64";
        // [903]  ColorMap.put( {834} , {835} ) 
        self._colormap["blue-grey darken-3"] = "#37474f";
        // [904]  ColorMap.put( {836} , {837} ) 
        self._colormap["blue-grey darken-4"] = "#263238";
        // [905]  ColorMap.put( {838} , {839} ) 
        self._colormap["black"] = "#000000";
        // [906]  ColorMap.put( {840} , {841} ) 
        self._colormap["white"] = "#ffffff";
        // [907]  ColorMap.put( {842} , {843} ) 
        self._colormap["transparent"] = "transparent";
        // [908]  ColorMap.put( {844} , {845} ) 
        self._colormap["lightslategrey"] = "#778899";
        // [909]  ColorMap.put( {846} , {847} ) 
        self._colormap["darkviolet"] = "#9400D3";
        // [910]  ColorMap.put( {848} , {849} ) 
        self._colormap["cyan"] = "#00FFFF";
        // [911]  ColorMap.put( {850} , {851} ) 
        self._colormap["darkslateblue"] = "#483D8B";
        // [912]  ColorMap.put( {852} , {853} ) 
        self._colormap["bisque"] = "#FFE4C4";
        // [913]  ColorMap.put( {854} , {855} ) 
        self._colormap["lightgrey"] = "#D3D3D3";
        // [914]  ColorMap.put( {856} , {857} ) 
        self._colormap["khaki"] = "#F0E68C";
        // [915]  ColorMap.put( {858} , {859} ) 
        self._colormap["darkgray"] = "#A9A9A9";
        // [916]  ColorMap.put( {860} , {861} ) 
        self._colormap["saddlebrown"] = "#8B4513";
        // [917]  ColorMap.put( {862} , {863} ) 
        self._colormap["blanchedalmond"] = "#FFEBCD";
        // [918]  ColorMap.put( {864} , {865} ) 
        self._colormap["darkblue"] = "#00008B";
        // [919]  ColorMap.put( {866} , {867} ) 
        self._colormap["lightcoral"] = "#F08080";
        // [920]  ColorMap.put( {868} , {869} ) 
        self._colormap["orangered"] = "#FF4500";
        // [921]  ColorMap.put( {870} , {871} ) 
        self._colormap["moccasin"] = "#FFE4B5";
        // [922]  ColorMap.put( {872} , {873} ) 
        self._colormap["azure"] = "#F0FFFF";
        // [923]  ColorMap.put( {874} , {875} ) 
        self._colormap["lightgoldenrodyellow"] = "#FAFAD2";
        // [924]  ColorMap.put( {876} , {877} ) 
        self._colormap["skyblue"] = "#87CEEB";
        // [925]  ColorMap.put( {878} , {879} ) 
        self._colormap["deepskyblue"] = "#00BFFF";
        // [926]  ColorMap.put( {880} , {881} ) 
        self._colormap["chartreuse"] = "#7FFF00";
        // [927]  ColorMap.put( {882} , {883} ) 
        self._colormap["mediumpurple"] = "#9370DB";
        // [928]  ColorMap.put( {884} , {885} ) 
        self._colormap["lightyellow"] = "#FFFFE0";
        // [929]  ColorMap.put( {886} , {887} ) 
        self._colormap["violet"] = "#EE82EE";
        // [930]  ColorMap.put( {888} , {889} ) 
        self._colormap["palevioletred"] = "#DB7093";
        // [931]  ColorMap.put( {890} , {891} ) 
        self._colormap["dimgrey"] = "#696969";
        // [932]  ColorMap.put( {892} , {893} ) 
        self._colormap["rosybrown"] = "#BC8F8F";
        // [933]  ColorMap.put( {894} , {895} ) 
        self._colormap["honeydew"] = "#F0FFF0";
        // [934]  ColorMap.put( {896} , {897} ) 
        self._colormap["mediumblue"] = "#0000CD";
        // [935]  ColorMap.put( {898} , {899} ) 
        self._colormap["darkseagreen"] = "#8FBC8F";
        // [936]  ColorMap.put( {900} , {901} ) 
        self._colormap["limegreen"] = "#32CD32";
        // [937]  ColorMap.put( {902} , {903} ) 
        self._colormap["paleturquoise"] = "#AFEEEE";
        // [938]  ColorMap.put( {904} , {905} ) 
        self._colormap["mediumorchid"] = "#BA55D3";
        // [939]  ColorMap.put( {906} , {907} ) 
        self._colormap["burlywood"] = "#DEB887";
        // [940]  ColorMap.put( {908} , {909} ) 
        self._colormap["silver"] = "#C0C0C0";
        // [941]  ColorMap.put( {910} , {911} ) 
        self._colormap["papayawhip"] = "#FFEFD5";
        // [942]  ColorMap.put( {912} , {913} ) 
        self._colormap["chocolate"] = "#D2691E";
        // [943]  ColorMap.put( {914} , {915} ) 
        self._colormap["lightsteelblue"] = "#B0C4DE";
        // [944]  ColorMap.put( {916} , {917} ) 
        self._colormap["pink"] = "#FFC0CB";
        // [945]  ColorMap.put( {918} , {919} ) 
        self._colormap["darkgreen"] = "#006400";
        // [946]  ColorMap.put( {920} , {921} ) 
        self._colormap["sienna"] = "#A0522D";
        // [947]  ColorMap.put( {922} , {923} ) 
        self._colormap["seashell"] = "#FFF5EE";
        // [948]  ColorMap.put( {924} , {925} ) 
        self._colormap["thistle"] = "#D8BFD8";
        // [949]  ColorMap.put( {926} , {927} ) 
        self._colormap["yellow"] = "#FFFF00";
        // [950]  ColorMap.put( {928} , {929} ) 
        self._colormap["lightseagreen"] = "#20B2AA";
        // [951]  ColorMap.put( {930} , {931} ) 
        self._colormap["cornsilk"] = "#FFF8DC";
        // [952]  ColorMap.put( {932} , {933} ) 
        self._colormap["blueviolet"] = "#8A2BE2";
        // [953]  ColorMap.put( {934} , {935} ) 
        self._colormap["tomato"] = "#FF6347";
        // [954]  ColorMap.put( {936} , {937} ) 
        self._colormap["cornflowerblue"] = "#6495ED";
        // [955]  ColorMap.put( {938} , {939} ) 
        self._colormap["sandybrown"] = "#F4A460";
        // [956]  ColorMap.put( {940} , {941} ) 
        self._colormap["gold"] = "#FFD700";
        // [957]  ColorMap.put( {942} , {943} ) 
        self._colormap["springgreen"] = "#00FF7F";
        // [958]  ColorMap.put( {944} , {945} ) 
        self._colormap["gray"] = "#808080";
        // [959]  ColorMap.put( {946} , {947} ) 
        self._colormap["slategrey"] = "#708090";
        // [960]  ColorMap.put( {948} , {949} ) 
        self._colormap["mediumvioletred"] = "#C71585";
        // [961]  ColorMap.put( {950} , {951} ) 
        self._colormap["crimson"] = "#DC143C";
        // [962]  ColorMap.put( {952} , {953} ) 
        self._colormap["darkcyan"] = "#008B8B";
        // [963]  ColorMap.put( {954} , {955} ) 
        self._colormap["ivory"] = "#FFFFF0";
        // [964]  ColorMap.put( {956} , {957} ) 
        self._colormap["darkmagenta"] = "#8B008B";
        // [965]  ColorMap.put( {958} , {959} ) 
        self._colormap["wheat"] = "#F5DEB3";
        // [966]  ColorMap.put( {960} , {961} ) 
        self._colormap["indianred"] = "#CD5C5C";
        // [967]  ColorMap.put( {962} , {963} ) 
        self._colormap["darkorchid"] = "#9932CC";
        // [968]  ColorMap.put( {964} , {965} ) 
        self._colormap["whitesmoke"] = "#F5F5F5";
        // [969]  ColorMap.put( {966} , {967} ) 
        self._colormap["mintcream"] = "#F5FFFA";
        // [970]  ColorMap.put( {968} , {969} ) 
        self._colormap["lightpink"] = "#FFB6C1";
        // [971]  ColorMap.put( {970} , {971} ) 
        self._colormap["black"] = "#000000";
        // [972]  ColorMap.put( {972} , {973} ) 
        self._colormap["teal"] = "#008080";
        // [973]  ColorMap.put( {974} , {975} ) 
        self._colormap["cadetblue"] = "#5F9EA0";
        // [974]  ColorMap.put( {976} , {977} ) 
        self._colormap["beige"] = "#F5F5DC";
        // [975]  ColorMap.put( {978} , {979} ) 
        self._colormap["darkkhaki"] = "#BDB76B";
        // [976]  ColorMap.put( {980} , {981} ) 
        self._colormap["blue"] = "#0000FF";
        // [977]  ColorMap.put( {982} , {983} ) 
        self._colormap["darkslategray"] = "#2F4F4F";
        // [978]  ColorMap.put( {984} , {985} ) 
        self._colormap["royalblue"] = "#4169E1";
        // [979]  ColorMap.put( {986} , {987} ) 
        self._colormap["seagreen"] = "#2E8B57";
        // [980]  ColorMap.put( {988} , {989} ) 
        self._colormap["purple"] = "#800080";
        // [981]  ColorMap.put( {990} , {991} ) 
        self._colormap["orchid"] = "#DA70D6";
        // [982]  ColorMap.put( {992} , {993} ) 
        self._colormap["forestgreen"] = "#228B22";
        // [983]  ColorMap.put( {994} , {995} ) 
        self._colormap["darksalmon"] = "#E9967A";
        // [984]  ColorMap.put( {996} , {997} ) 
        self._colormap["palegreen"] = "#98FB98";
        // [985]  ColorMap.put( {998} , {999} ) 
        self._colormap["navy"] = "#000080";
        // [986]  ColorMap.put( {1000} , {1001} ) 
        self._colormap["lightslategray"] = "#778899";
        // [987]  ColorMap.put( {1002} , {1003} ) 
        self._colormap["rebeccapurple"] = "#663399";
        // [988]  ColorMap.put( {1004} , {1005} ) 
        self._colormap["greenyellow"] = "#ADFF2F";
        // [989]  ColorMap.put( {1006} , {1007} ) 
        self._colormap["red"] = "#FF0000";
        // [990]  ColorMap.put( {1008} , {1009} ) 
        self._colormap["aqua"] = "#00FFFF";
        // [991]  ColorMap.put( {1010} , {1011} ) 
        self._colormap["white"] = "#FFFFFF";
        // [992]  ColorMap.put( {1012} , {1013} ) 
        self._colormap["dodgerblue"] = "#1E90FF";
        // [993]  ColorMap.put( {1014} , {1015} ) 
        self._colormap["lightblue"] = "#ADD8E6";
        // [994]  ColorMap.put( {1016} , {1017} ) 
        self._colormap["olive"] = "#808000";
        // [995]  ColorMap.put( {1018} , {1019} ) 
        self._colormap["coral"] = "#FF7F50";
        // [996]  ColorMap.put( {1020} , {1021} ) 
        self._colormap["peachpuff"] = "#FFDAB9";
        // [997]  ColorMap.put( {1022} , {1023} ) 
        self._colormap["darkolivegreen"] = "#556B2F";
        // [998]  ColorMap.put( {1024} , {1025} ) 
        self._colormap["darkturquoise"] = "#00CED1";
        // [999]  ColorMap.put( {1026} , {1027} ) 
        self._colormap["darkgrey"] = "#A9A9A9";
        // [1000]  ColorMap.put( {1028} , {1029} ) 
        self._colormap["lavender"] = "#E6E6FA";
        // [1001]  ColorMap.put( {1030} , {1031} ) 
        self._colormap["lightgray"] = "#D3D3D3";
        // [1002]  ColorMap.put( {1032} , {1033} ) 
        self._colormap["gainsboro"] = "#DCDCDC";
        // [1003]  ColorMap.put( {1034} , {1035} ) 
        self._colormap["tan"] = "#D2B48C";
        // [1004]  ColorMap.put( {1036} , {1037} ) 
        self._colormap["plum"] = "#DDA0DD";
        // [1005]  ColorMap.put( {1038} , {1039} ) 
        self._colormap["midnightblue"] = "#191970";
        // [1006]  ColorMap.put( {1040} , {1041} ) 
        self._colormap["powderblue"] = "#B0E0E6";
        // [1007]  ColorMap.put( {1042} , {1043} ) 
        self._colormap["dimgray"] = "#696969";
        // [1008]  ColorMap.put( {1044} , {1045} ) 
        self._colormap["lemonchiffon"] = "#FFFACD";
        // [1009]  ColorMap.put( {1046} , {1047} ) 
        self._colormap["salmon"] = "#FA8072";
        // [1010]  ColorMap.put( {1048} , {1049} ) 
        self._colormap["lightgreen"] = "#90EE90";
        // [1011]  ColorMap.put( {1050} , {1051} ) 
        self._colormap["brown"] = "#A52A2A";
        // [1012]  ColorMap.put( {1052} , {1053} ) 
        self._colormap["goldenrod"] = "#DAA520";
        // [1013]  ColorMap.put( {1054} , {1055} ) 
        self._colormap["steelblue"] = "#4682B4";
        // [1014]  ColorMap.put( {1056} , {1057} ) 
        self._colormap["lightsalmon"] = "#FFA07A";
        // [1015]  ColorMap.put( {1058} , {1059} ) 
        self._colormap["darkred"] = "#8B0000";
        // [1016]  ColorMap.put( {1060} , {1061} ) 
        self._colormap["snow"] = "#FFFAFA";
        // [1017]  ColorMap.put( {1062} , {1063} ) 
        self._colormap["olivedrab"] = "#6B8E23";
        // [1018]  ColorMap.put( {1064} , {1065} ) 
        self._colormap["yellowgreen"] = "#9ACD32";
        // [1019]  ColorMap.put( {1066} , {1067} ) 
        self._colormap["indigo"] = "#4B0082";
        // [1020]  ColorMap.put( {1068} , {1069} ) 
        self._colormap["lawngreen"] = "#7CFC00";
        // [1021]  ColorMap.put( {1070} , {1071} ) 
        self._colormap["magenta"] = "#FF00FF";
        // [1022]  ColorMap.put( {1072} , {1073} ) 
        self._colormap["aquamarine"] = "#7FFFD4";
        // [1023]  ColorMap.put( {1074} , {1075} ) 
        self._colormap["floralwhite"] = "#FFFAF0";
        // [1024]  ColorMap.put( {1076} , {1077} ) 
        self._colormap["antiquewhite"] = "#FAEBD7";
        // [1025]  ColorMap.put( {1078} , {1079} ) 
        self._colormap["hotpink"] = "#FF69B4";
        // [1026]  ColorMap.put( {1080} , {1081} ) 
        self._colormap["turquoise"] = "#40E0D0";
        // [1027]  ColorMap.put( {1082} , {1083} ) 
        self._colormap["peru"] = "#CD853F";
        // [1028]  ColorMap.put( {1084} , {1085} ) 
        self._colormap["fuchsia"] = "#FF00FF";
        // [1029]  ColorMap.put( {1086} , {1087} ) 
        self._colormap["firebrick"] = "#B22222";
        // [1030]  ColorMap.put( {1088} , {1089} ) 
        self._colormap["aliceblue"] = "#F0F8FF";
        // [1031]  ColorMap.put( {1090} , {1091} ) 
        self._colormap["darkgoldenrod"] = "#B8860B";
        // [1032]  ColorMap.put( {1092} , {1093} ) 
        self._colormap["navajowhite"] = "#FFDEAD";
        // [1033]  ColorMap.put( {1094} , {1095} ) 
        self._colormap["lavenderblush"] = "#FFF0F5";
        // [1034]  ColorMap.put( {1096} , {1097} ) 
        self._colormap["mediumspringgreen"] = "#00FA9A";
        // [1035]  ColorMap.put( {1098} , {1099} ) 
        self._colormap["slategray"] = "#708090";
        // [1036]  ColorMap.put( {1100} , {1101} ) 
        self._colormap["mistyrose"] = "#FFE4E1";
        // [1037]  ColorMap.put( {1102} , {1103} ) 
        self._colormap["linen"] = "#FAF0E6";
        // [1038]  ColorMap.put( {1104} , {1105} ) 
        self._colormap["darkorange"] = "#FF8C00";
        // [1039]  ColorMap.put( {1106} , {1107} ) 
        self._colormap["slateblue"] = "#6A5ACD";
        // [1040]  ColorMap.put( {1108} , {1109} ) 
        self._colormap["lightcyan"] = "#E0FFFF";
        // [1041]  ColorMap.put( {1110} , {1111} ) 
        self._colormap["lightskyblue"] = "#87CEFA";
        // [1042]  ColorMap.put( {1112} , {1113} ) 
        self._colormap["mediumseagreen"] = "#3CB371";
        // [1043]  ColorMap.put( {1114} , {1115} ) 
        self._colormap["mediumturquoise"] = "#48D1CC";
        // [1044]  ColorMap.put( {1116} , {1117} ) 
        self._colormap["deeppink"] = "#FF1493";
        // [1045]  ColorMap.put( {1118} , {1119} ) 
        self._colormap["ghostwhite"] = "#F8F8FF";
        // [1046]  ColorMap.put( {1120} , {1121} ) 
        self._colormap["green"] = "#008000";
        // [1047]  ColorMap.put( {1122} , {1123} ) 
        self._colormap["lime"] = "#00FF00";
        // [1048]  ColorMap.put( {1124} , {1125} ) 
        self._colormap["mediumaquamarine"] = "#66CDAA";
        // [1049]  ColorMap.put( {1126} , {1127} ) 
        self._colormap["oldlace"] = "#FDF5E6";
        // [1050]  ColorMap.put( {1128} , {1129} ) 
        self._colormap["grey"] = "#808080";
        // [1051]  ColorMap.put( {1130} , {1131} ) 
        self._colormap["orange"] = "#FFA500";
        // [1052]  ColorMap.put( {1132} , {1133} ) 
        self._colormap["darkslategrey"] = "#2F4F4F";
        // [1053]  ColorMap.put( {1134} , {1135} ) 
        self._colormap["mediumslateblue"] = "#7B68EE";
        // [1054]  ColorMap.put( {1136} , {1137} ) 
        self._colormap["maroon"] = "#800000";
        // [1055]  ColorMap.put( {1138} , {1139} ) 
        self._colormap["palegoldenrod"] = "#EEE8AA";
        // [1056]  ColorMap.Put( {1140} , {1141} ) 
        self._colormap["indigo"] = "#6610f2";
        // [1057]  ColorMap.Put( {1142} , {1143} ) 
        self._colormap["primary"] = "#007bff";
        // [1058]  ColorMap.Put( {1144} , {1145} ) 
        self._colormap["secondary"] = "#6c757d";
        // [1059]  ColorMap.Put( {1146} , {1147} ) 
        self._colormap["success"] = "#28a745";
        // [1060]  ColorMap.Put( {1148} , {1149} ) 
        self._colormap["info"] = "#17a2b8";
        // [1061]  ColorMap.Put( {1150} , {1151} ) 
        self._colormap["warning"] = "#ffc107";
        // [1062]  ColorMap.Put( {1152} , {1153} ) 
        self._colormap["danger"] = "#dc3545";
        // [1063]  ColorMap.Put( {1154} , {1155} ) 
        self._colormap["light"] = "#f8f9fa";
        // [1064]  ColorMap.Put( {1156} , {1157} ) 
        self._colormap["dark"] = "#343a40";
        // End Sub
    };

    // [1069] Sub SetHTML(elID As String, elContent As String) 
    this.sethtml = function (_elid, _elcontent) {
        if (self == null) self = this;
        var _el;
        // [1070]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1071]  Dim el As BANanoElement 
        _el = null;
        // [1072]  el = BANano.getelement( {15} ) 
        _el = u("#" + _elid + "");
        // [1073]  el.Empty 
        _el.empty();
        // [1074]  el.SetHTML(elContent) 
        _el.html(_elcontent);
        // End Sub
    };

    // [1078] Sub SetValue(elID As String, elContent As String) 
    this.setvalue = function (_elid, _elcontent) {
        if (self == null) self = this;
        // [1079]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1080]  BANano.GetElement( {16} ).SetValue(elContent) 
        u("#" + _elid + "").value(_elcontent);
        // End Sub
    };

    // [1084] Sub GetValue(elID As String) As String 
    this.getvalue = function (_elid) {
        if (self == null) self = this;
        var _svalue;
        // [1085]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1086]  Dim sValue As String = BANano.GetElement( {17} ).GetValue 
        _svalue = u("#" + _elid + "").value();
        // [1087]  Return sValue 
        return _svalue;
        // End Sub
    };

    // [1090] Sub SetStyle(elID As String, elContent As String) 
    this.setstyle = function (_elid, _elcontent) {
        if (self == null) self = this;
        // [1091]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1092]  BANano.GetElement( {18} ).SetStyle(elContent) 
        u("#" + _elid + "").css(JSON.parse(_elcontent));
        // End Sub
    };

    // [1095] Sub AddClass(elID As String, elContent As String) 
    this.addclass = function (_elid, _elcontent) {
        if (self == null) self = this;
        // [1096]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1097]  BANano.GetElement( {19} ).AddClass(elContent) 
        u("#" + _elid + "").addClass(_elcontent);
        // End Sub
    };

    // [1100] Sub SetAttr(elID As String, elProp As String, elContent As String) 
    this.setattr = function (_elid, _elprop, _elcontent) {
        if (self == null) self = this;
        // [1101]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1102]  BANano.GetElement( {20} ).SetAttr(elContent,elContent) 
        u("#" + _elid + "").attr(_elcontent, _elcontent);
        // End Sub
    };

    // [1107] Sub Empty(elID As String) 
    this.empty = function (_elid) {
        if (self == null) self = this;
        // [1108]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1109]  BANano.GetElement( {21} ).Empty 
        u("#" + _elid + "").empty();
        // End Sub
    };

    // [1113] Sub Append(elID As String, elContent As String) 
    this.append = function (_elid, _elcontent) {
        if (self == null) self = this;
        // [1114]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1115]  BANano.GetElement( {22} ).Append(elContent) 
        u("#" + _elid + "").append(_elcontent);
        // End Sub
    };

    // [1119] Sub SetText(elID As String, elContent As String) 
    this.settext = function (_elid, _elcontent) {
        if (self == null) self = this;
        // [1120]  elID = elID.tolowercase 
        _elid = _elid.toLowerCase();
        // [1121]  BANano.GetElement( {23} ).SetText(elContent) 
        u("#" + _elid + "").text(_elcontent);
        // End Sub
    };

    // [1124] Sub Eval(elContent As String) 
    this.eval = function (_elcontent) {
        if (self == null) self = this;
        // [1125]  BANano.Eval(elContent) 
        eval(_elcontent);
        // End Sub
    };

    // [1128] Sub EvalWithResult(elContent As String) As String 
    this.evalwithresult = function (_elcontent) {
        if (self == null) self = this;
        // [1129]  Return BANano.Eval(elContent) 
        return eval(_elcontent);
        // End Sub
    };

}
// =========================== UOEAnchorIcon  ===========================
function banano_uoebanano_uoeanchoricon() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._a = new banano_uoebanano_uoehtml();

    this._theme = '';

    this._enabled = false;

    this._textvisible = false;

    this._text = '';

    this._href = '';

    this._isfab = false;

    this._click2toggle = false;

    this._horizontal = false;

    this._istoolbar = false;

    this._buttons = [];

    this._iconname = '';

    this._iconalignment = '';

    this._iconcircle = false;

    this._icontheme = '';

    this._waveseffect = false;

    this._visibility = '';

    this._wavestype = '';

    this._wavescircle = false;

    this._zdepth = '';

    this._activator = false;

    this._floating = false;

    this._alignment = '';

    this._inlist = false;

    this._inline = false;

    this._hoverable = false;

    // [37] Sub AddStyleAttribute(attribute As String, value As String) As UOEAnchorIcon 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [38]  a.AddStyleAttribute(attribute,value) 
        self._a.addstyleattribute(_attribute, _value);
        // [39]  Return Me 
        return self;
        // End Sub
    };

    // [43] Public Sub Initialize(thisApp As UOEApp, itemID As String, itemIcon As String, itemIconAlign As String, itemIconCircle As Boolean, itemText As String, itemNavigateTo As String, bTextVisible As Boolean, itemTheme As String, itemIconTheme As String) 
    this.initialize = function (_thisapp, _itemid, _itemicon, _itemiconalign, _itemiconcircle, _itemtext, _itemnavigateto, _btextvisible, _itemtheme, _itemicontheme) {
        if (self == null) self = this;
        // [45]  App = thisApp 
        self._app = _thisapp;
        // [46]  Alignment= {0} 
        self._alignment = "";
        // [47]  InList = False 
        self._inlist = false;
        // [48]  InLine = False 
        self._inline = false;
        // [49]  Activator = False 
        self._activator = false;
        // [50]  Floating = False 
        self._floating = false;
        // [51]  ID = itemID.tolowercase 
        self._id = _itemid.toLowerCase();
        // [52]  HREF = itemNavigateTo 
        self._href = _itemnavigateto;
        // [53]  TextVisible = bTextVisible 
        self._textvisible = _btextvisible;
        // [54]  Text = itemText 
        self._text = _itemtext;
        // [55]  Theme = itemTheme 
        self._theme = _itemtheme;
        // [56]  IsFAB = False 
        self._isfab = false;
        // [57]  Click2Toggle = False 
        self._click2toggle = false;
        // [58]  Horizontal = False 
        self._horizontal = false;
        // [59]  IsToolBar = False 
        self._istoolbar = false;
        // [60]  Enabled = True 
        self._enabled = true;
        // [61]  Visibility = {1} 
        self._visibility = "";
        // [62]  ZDepth = {2} 
        self._zdepth = "";
        // [63]  IconName = itemIcon 
        self._iconname = _itemicon;
        // [64]  IconAlignment = itemIconAlign 
        self._iconalignment = _itemiconalign;
        // [65]  IconTheme = itemIconTheme 
        self._icontheme = _itemicontheme;
        // [66]  IconCircle = itemIconCircle 
        self._iconcircle = _itemiconcircle;
        // [67]  Buttons.Initialize 
        self._buttons.length = 0;
        // [68]  Buttons.clear 
        self._buttons.length = 0;
        // [69]  a.Initialize(ID, {3} ) 
        self._a.initialize(self._id, "a");
        // [70]  WavesType = App.EnumWavesType.Light 
        self._wavestype = self._app._enumwavestype._light;
        // [71]  WavesCircle = False 
        self._wavescircle = false;
        // [72]  WavesEffect = True 
        self._waveseffect = true;
        // End Sub
    };

    // [77] Sub AddClass(sClass As String) As UOEAnchorIcon 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [78]  a.AddClass(sClass) 
        self._a.addclass(_sclass);
        // [79]  Return Me 
        return self;
        // End Sub
    };

    // [83] Sub RemoveClass(sClass As String) As UOEAnchorIcon 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [84]  a.RemoveClass(sClass) 
        self._a.removeclass(_sclass);
        // [85]  Return Me 
        return self;
        // End Sub
    };

    // [89] Sub AddAttribute(attr As String, value As String) As UOEAnchorIcon 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [90]  a.AddAttribute(attr,value) 
        self._a.addattribute(_attr, _value);
        // [91]  Return Me 
        return self;
        // End Sub
    };

    // [95] Sub RemoveAttribute(attr As String) As UOEAnchorIcon 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [96]  a.RemoveAttribute(attr) 
        self._a.removeattribute(_attr);
        // [97]  Return Me 
        return self;
        // End Sub
    };

    // [101] Sub ToString As String 
    this.tostring = function () {
        if (self == null) self = this;
        var _fab;
        var _li;
        var _strbutton;
        // [103]  a.ID = ID 
        self._a._id = self._id;
        // [104]  a.MaterialWavesEffect(WavesEffect) 
        self._a.materialwaveseffect(self._waveseffect);
        // [105]  a.SetHRef(HREF) 
        self._a.sethref(self._href);
        // [106]  App.MaterialUseTheme(Theme,a) 
        self._app.materialusetheme(self._theme, self._a);
        // [107]  a.MaterialEnable(Enabled) 
        self._a.materialenable(self._enabled);
        // [108]  a.MaterialZDepth(ZDepth) 
        self._a.materialzdepth(self._zdepth);
        // [109]  a.MaterialVisibility(Visibility) 
        self._a.materialvisibility(self._visibility);
        // [111]  If a.ClassExists( {4} ) = True Then IconCircle = True 
        if (self._a.classexists("fixed-action-btn") == true) {
            self._iconcircle = true;
        }
        // [112]  If a.ClassExists( {5} ) = True Then IconCircle = True 
        if (self._a.classexists("halfway-fab") == true) {
            self._iconcircle = true;
        }
        // [113]  If a.ClassExists( {6} ) = True Then IconCircle = True 
        if (self._a.classexists("btn-floating") == true) {
            self._iconcircle = true;
        }
        // [114]  modUOE.MaterialAddIcon(App,a,IconName,IconAlignment,IconTheme,IconCircle,False,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, self._a, self._iconname, self._iconalignment, self._icontheme, self._iconcircle, false, false, false, false);
        // [115]  a.MaterialWavesType(WavesType) 
        self._a.materialwavestype(self._wavestype);
        // [116]  a.MaterialWavesCircle(WavesCircle) 
        self._a.materialwavescircle(self._wavescircle);
        // [117]  a.AddClassOnCondition(Activator, {7} ) 
        self._a.addclassoncondition(self._activator, "activator");
        // [118]  a.AddClassOnCondition(Floating, {8} ) 
        self._a.addclassoncondition(self._floating, "btn-floating");
        // [119]  a.AddClass(Alignment) 
        self._a.addclass(self._alignment);
        // [120]  If TextVisible = True Then a.AddContent(Text) 
        if (self._textvisible == true) {
            self._a.addcontent(self._text);
        }
        // [121]  If IsFAB = True Then 
        if (self._isfab == true) {
            // [122]  Dim fab As UOEHTML 
            _fab = new banano_uoebanano_uoehtml();
            // [123]  fab.Initialize(ID & {9} , {10} ) 
            _fab.initialize(self._id + "div", "div");
            // [124]  fab.AddClass( {11} ) 
            _fab.addclass("fixed-action-btn");
            // [125]  fab.AddContent(a.HTML) 
            _fab.addcontent(self._a.html());
            // [126]  fab.MaterialClick2Toggle(Click2Toggle) 
            _fab.materialclick2toggle(self._click2toggle);
            // [127]  fab.MaterialHorizontal(Horizontal) 
            _fab.materialhorizontal(self._horizontal);
            // [128]  fab.MaterialToolBar(IsToolBar) 
            _fab.materialtoolbar(self._istoolbar);
            // [135]  Dim li As UOEHTML 
            _li = new banano_uoebanano_uoehtml();
            // [136]  li.Initialize( {18} , {19} ) 
            _li.initialize("", "ul");
            // [137]  For Each strButton As String In Buttons 
            for (var _strbuttonindex = 0; _strbuttonindex < self._buttons.length; _strbuttonindex++) {
                _strbutton = self._buttons[_strbuttonindex];
                // [138]  li.AddContent(strButton) 
                _li.addcontent(_strbutton);
                // [139]  Next 
            }
            // [140]  fab.AddContent(li.HTML) 
            _fab.addcontent(_li.html());
            // [141]  Return fab.html 
            return _fab.html();
            // [142]  Else 
        } else {
            // [143]  If InList = True Then 
            if (self._inlist == true) {
                // [144]  Dim li As UOEHTML 
                _li = new banano_uoebanano_uoehtml();
                // [145]  li.Initialize( {20} , {21} ) 
                _li.initialize("", "li");
                // [146]  If InLine = True Then 
                if (self._inline == true) {
                    // [147]  li.AddStyleAttribute( {22} , {23} ) 
                    _li.addstyleattribute("display", "inline");
                    // [148]  End If 
                }
                // [149]  li.AddContent(a.HTML) 
                _li.addcontent(self._a.html());
                // [150]  Return li.html 
                return _li.html();
                // [151]  Else 
            } else {
                // [152]  Return a.html 
                return self._a.html();
                // [153]  End If 
            }
            // [154]  End If 
        }
        // End Sub
    };

}
// =========================== UOEIcon  ===========================
function banano_uoebanano_uoeicon() {
    var self;
    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._iconname = '';

    this._theme = '';

    this._element = new banano_uoebanano_uoehtml();

    this._alignment = '';

    this._addcursor = false;

    this._circle = false;

    this._waveeffects = false;

    this._prefix = false;

    this._waveseffect = false;

    this._visibility = '';

    this._wavestype = '';

    this._wavescircle = false;

    this._zdepth = '';

    this._enabled = false;

    this._iconsize = '';

    this._close = false;

    this._hoverable = false;

    // [27] Sub AddStyleAttribute(attribute As String, value As String) As UOEIcon 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [28]  Element.AddStyleAttribute(attribute,value) 
        self._element.addstyleattribute(_attribute, _value);
        // [29]  Return Me 
        return self;
        // End Sub
    };

    // [33] Sub AddClass(sClass As String) As UOEIcon 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [34]  Element.AddClass(sClass) 
        self._element.addclass(_sclass);
        // [35]  Return Me 
        return self;
        // End Sub
    };

    // [39] Sub RemoveClass(sClass As String) As UOEIcon 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [40]  Element.RemoveClass(sClass) 
        self._element.removeclass(_sclass);
        // [41]  Return Me 
        return self;
        // End Sub
    };

    // [45] Sub AddAttribute(attr As String, value As String) As UOEIcon 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [46]  Element.AddAttribute(attr,value) 
        self._element.addattribute(_attr, _value);
        // [47]  Return Me 
        return self;
        // End Sub
    };

    // [51] Sub RemoveAttribute(attr As String) As UOEIcon 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [52]  Element.RemoveAttribute(attr) 
        self._element.removeattribute(_attr);
        // [53]  Return Me 
        return self;
        // End Sub
    };

    // [57] Public Sub Initialize(thisApp As UOEApp, sid As String, sIconName As String, sThemeName As String) As UOEIcon 
    this.initialize = function (_thisapp, _sid, _siconname, _sthemename) {
        if (self == null) self = this;
        // [58]  App = thisApp 
        self._app = _thisapp;
        // [59]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [60]  Close = False 
        self._close = false;
        // [61]  IconName = sIconName 
        self._iconname = _siconname;
        // [62]  Prefix = False 
        self._prefix = false;
        // [63]  Circle = False 
        self._circle = false;
        // [64]  AddCursor = False 
        self._addcursor = false;
        // [65]  Theme = sThemeName 
        self._theme = _sthemename;
        // [66]  WaveEffects = True 
        self._waveeffects = true;
        // [67]  Alignment = {0} 
        self._alignment = "";
        // [68]  Element.Initialize(ID, {1} ) 
        self._element.initialize(self._id, "i");
        // [69]  Enabled = True 
        self._enabled = true;
        // [70]  Visibility= {2} 
        self._visibility = "";
        // [71]  ZDepth = {3} 
        self._zdepth = "";
        // [72]  WavesType = App.EnumWavesType.Light 
        self._wavestype = self._app._enumwavestype._light;
        // [73]  IconSize = {4} 
        self._iconsize = "";
        // [74]  WavesEffect = True 
        self._waveseffect = true;
        // [75]  WavesCircle = False 
        self._wavescircle = false;
        // [76]  Return Me 
        return self;
        // End Sub
    };

    // [80] Sub RemoveWave 
    this.removewave = function () {
        if (self == null) self = this;
        // [81]  WaveEffects = False 
        self._waveeffects = false;
        // [82]  WavesType = {5} 
        self._wavestype = "";
        // [83]  WavesCircle = False 
        self._wavescircle = false;
        // End Sub
    };

    // [87] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [88]  Element.ID = ID 
        self._element._id = self._id;
        // [89]  App.MaterialUseTheme(Theme,Element) 
        self._app.materialusetheme(self._theme, self._element);
        // [90]  Element.MaterialBuildIcon(IconName, Alignment) 
        self._element.materialbuildicon(self._iconname, self._alignment);
        // [91]  Element.MaterialCircle(Circle) 
        self._element.materialcircle(self._circle);
        // [93]  Element.MaterialWavesEffect(WaveEffects) 
        self._element.materialwaveseffect(self._waveeffects);
        // [94]  Element.AddClassOnCondition(Prefix, {6} ) 
        self._element.addclassoncondition(self._prefix, "prefix");
        // [95]  Element.MaterialVisibility(Visibility) 
        self._element.materialvisibility(self._visibility);
        // [96]  Element.MaterialWavesType(WavesType) 
        self._element.materialwavestype(self._wavestype);
        // [97]  Element.MaterialWavesCircle(WavesCircle) 
        self._element.materialwavescircle(self._wavescircle);
        // [98]  Element.MaterialWavesEffect(WavesEffect) 
        self._element.materialwaveseffect(self._waveseffect);
        // [99]  Element.MaterialZDepth(ZDepth) 
        self._element.materialzdepth(self._zdepth);
        // [100]  Element.MaterialEnable(Enabled) 
        self._element.materialenable(self._enabled);
        // [101]  App.ApplyTooltip(ID,Element) 
        self._app.applytooltip(self._id, self._element);
        // [102]  Element.MaterialIconSize(IconSize) 
        self._element.materialiconsize(self._iconsize);
        // [103]  Element.MaterialClose(Close) 
        self._element.materialclose(self._close);
        // [104]  If AddCursor = True Then Element.addcursor 
        if (self._addcursor == true) {
            self._element.addcursor();
        }
        // [109]  Return Element.html 
        return self._element.html();
        // End Sub
    };

}
// =========================== UOECard  ===========================
function banano_uoebanano_uoecard() {
    var self;
    this._card = new banano_uoebanano_uoehtml();

    this._actions = new banano_uoebanano_uoehtml();

    this._content = new banano_uoebanano_uoehtml();

    this._imageurl = '';

    this._app = new banano_uoebanano_uoeapp();

    this._id = '';

    this._cardtype = '';

    this._cardsize = '';

    this._visibility = '';

    this._zdepth = '';

    this._hoverable = false;

    this._image = new banano_uoebanano_uoehtml();

    this._horizontal = false;

    this._stacked = new banano_uoebanano_uoehtml();

    this._reveal = new banano_uoebanano_uoehtml();

    this._breveal = false;

    this._hasactions = false;

    this._stickyaction = false;

    this._hastabs = false;

    this._tabs = new banano_uoebanano_uoehtml();

    this._ul = new banano_uoebanano_uoehtml();

    this._uldata = new banano_uoebanano_uoehtml();

    this._panel = false;

    this._small = 0;

    this._medium = 0;

    this._large = 0;

    // [35] Public Sub Initialize(thisApp As UOEApp,sid As String, sImageURL As String, sCardType As String, sCardTheme As String, sContentTheme As String) 
    this.initialize = function (_thisapp, _sid, _simageurl, _scardtype, _scardtheme, _scontenttheme) {
        if (self == null) self = this;
        // [37]  App = thisApp 
        self._app = _thisapp;
        // [38]  ID = sid.tolowercase 
        self._id = _sid.toLowerCase();
        // [39]  ImageURL = sImageURL 
        self._imageurl = _simageurl;
        // [40]  CardType = sCardType 
        self._cardtype = _scardtype;
        // [41]  CardSize = App.EnumCardSize.normal 
        self._cardsize = self._app._enumcardsize._normal;
        // [42]  card.Initialize(ID, {3} ) 
        self._card.initialize(self._id, "div");
        // [43]  card.AddClass( {4} ) 
        self._card.addclass("card");
        // [44]  App.MaterialUseTheme(sCardTheme,card) 
        self._app.materialusetheme(_scardtheme, self._card);
        // [45]  content.Initialize( {5} , {6} ) 
        self._content.initialize("", "div");
        // [46]  content.AddClass( {7} ) 
        self._content.addclass("card-content");
        // [47]  App.MaterialUseTheme(sContentTheme,content) 
        self._app.materialusetheme(_scontenttheme, self._content);
        // [48]  actions.Initialize( {8} , {9} ) 
        self._actions.initialize("", "div");
        // [49]  actions.AddClass( {10} ) 
        self._actions.addclass("card-action");
        // [50]  image.Initialize( {11} , {12} ) 
        self._image.initialize("", "div");
        // [51]  image.addclass( {13} ) 
        self._image.addclass("card-image");
        // [52]  stacked.Initialize( {14} , {15} ) 
        self._stacked.initialize("", "div");
        // [53]  stacked.AddClass( {16} ) 
        self._stacked.addclass("card-stacked");
        // [54]  reveal.Initialize( {17} , {18} ) 
        self._reveal.initialize("", "div");
        // [55]  reveal.AddClass( {19} ) 
        self._reveal.addclass("card-reveal");
        // [56]  tabs.Initialize( {20} , {21} ) 
        self._tabs.initialize("", "div");
        // [57]  tabs.addclass( {22} ) 
        self._tabs.addclass("card-tabs");
        // [58]  ul.Initialize( {23} , {24} ) 
        self._ul.initialize("", "ul");
        // [59]  ul.AddClass( {25} ) 
        self._ul.addclass("tabs tabs-fixed-width");
        // [60]  uldata.Initialize( {26} , {27} ) 
        self._uldata.initialize("", "div");
        // [61]  uldata.AddClass( {28} ) 
        self._uldata.addclass("card-content");
        // [62]  Horizontal = False 
        self._horizontal = false;
        // [63]  bReveal = False 
        self._breveal = false;
        // [64]  If CardType = App.EnumCardType.Reveal Then 
        if (self._cardtype == self._app._enumcardtype._reveal) {
            // [65]  Horizontal = False 
            self._horizontal = false;
            // [66]  bReveal = True 
            self._breveal = true;
            // [67]  End If 
        }
        // [68]  hasActions = False 
        self._hasactions = false;
        // [69]  StickyAction = False 
        self._stickyaction = false;
        // [70]  hasTabs = False 
        self._hastabs = false;
        // [71]  Panel = False 
        self._panel = false;
        // [72]  Small = 12 
        self._small = 12;
        // [73]  Medium = 12 
        self._medium = 12;
        // [74]  Large = 12 
        self._large = 12;
        // End Sub
    };

    // [78] Sub SetSizes(iSmall As Int, iMedium As Int, iLarge As Int) As UOECard 
    this.setsizes = function (_ismall, _imedium, _ilarge) {
        if (self == null) self = this;
        // [79]  Small = iSmall 
        self._small = _ismall;
        // [80]  Medium = iMedium 
        self._medium = _imedium;
        // [81]  Large = iLarge 
        self._large = _ilarge;
        // [82]  card.AddClass( {29} ) 
        self._card.addclass("col");
        // [83]  card.AddClass( {0} ) 
        self._card.addclass("s" + self._small + "");
        // [84]  card.AddClass( {1} ) 
        self._card.addclass("m" + self._medium + "");
        // [85]  card.AddClass( {2} ) 
        self._card.addclass("l" + self._large + "");
        // [86]  Return Me 
        return self;
        // End Sub
    };

    // [90] Sub AddTab(tabID As String, tabText As String, tabDisabled As Boolean, tabCont As UOEContainer) As UOECard 
    this.addtab = function (_tabid, _tabtext, _tabdisabled, _tabcont) {
        if (self == null) self = this;
        var _li;
        var _a;
        var _dv;
        // [91]  hasTabs = True 
        self._hastabs = true;
        // [92]  Dim li As UOEHTML 
        _li = new banano_uoebanano_uoehtml();
        // [93]  li.Initialize(tabID & {30} , {31} ) 
        _li.initialize(_tabid + "li", "li");
        // [94]  li.AddClass( {32} ) 
        _li.addclass("tab");
        // [95]  li.AddClassOnCondition(tabDisabled, {33} ) 
        _li.addclassoncondition(_tabdisabled, "disabled");
        // [96]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [97]  a.Initialize(tabID, {34} ) 
        _a.initialize(_tabid, "a");
        // [98]  a.sethref( {35} & tabID & {36} ).AddContent(tabText) 
        _a.sethref("#" + _tabid + "dv").addcontent(_tabtext);
        // [99]  li.AddElement(a) 
        _li.addelement(_a);
        // [101]  ul.AddElement(li) 
        self._ul.addelement(_li);
        // [104]  Dim dv As UOEHTML 
        _dv = new banano_uoebanano_uoehtml();
        // [105]  dv.Initialize(tabID & {37} , {38} ) 
        _dv.initialize(_tabid + "dv", "div");
        // [106]  If tabCont <> Null Then 
        if (_tabcont != null) {
            // [107]  dv.AddContent(tabCont.tostring) 
            _dv.addcontent(_tabcont.tostring());
            // [108]  End If 
        }
        // [110]  uldata.AddContent(dv.HTML) 
        self._uldata.addcontent(_dv.html());
        // [111]  Return Me 
        return self;
        // End Sub
    };

    // [115] Sub AddFAB(btnID As String, btnIcon As String, btnURL As String, btnSize As String, btnTheme As String) As UOECard 
    this.addfab = function (_btnid, _btnicon, _btnurl, _btnsize, _btntheme) {
        if (self == null) self = this;
        var _a;
        // [116]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [117]  a.Initialize(btnID, {39} ) 
        _a.initialize(_btnid, "a");
        // [118]  a.AddClass( {40} ) 
        _a.addclass("btn-floating");
        // [119]  a.AddClass( {41} ) 
        _a.addclass("halfway-fab");
        // [120]  a.MaterialWavesEffect(True) 
        _a.materialwaveseffect(true);
        // [121]  a.MaterialWavesLight(True) 
        _a.materialwaveslight(true);
        // [122]  a.SetZIndex( {42} ) 
        _a.setzindex("999");
        // [123]  App.MaterialUseTheme(btnTheme,a) 
        self._app.materialusetheme(_btntheme, _a);
        // [124]  modUOE.MaterialAddIcon(App,a,btnIcon, {43} ,btnTheme,False,True,False,False,False) 
        _banano_uoebanano_moduoe.materialaddicon(self._app, _a, _btnicon, "", _btntheme, false, true, false, false, false);
        // [125]  a.MaterialButtonSize(btnSize) 
        _a.materialbuttonsize(_btnsize);
        // [126]  Select Case CardType 
        switch ("" + self._cardtype) {
            // [127]  Case App.EnumCardType.Basic 
            case "" + self._app._enumcardtype._basic:
                // [128]  Case Else 
                break;
            default:
                // [129]  image.AddElement(a) 
                self._image.addelement(_a);
                // [130]  End Select 
                break;
        }
        // [131]  App.AddEvent(btnID, {44} ) 
        self._app.addevent(_btnid, "click");
        // [132]  Return Me 
        return self;
        // End Sub
    };

    // [136] Sub AddTitle(sTitle As String, themeName As String, className As String) As UOECard 
    this.addtitle = function (_stitle, _themename, _classname) {
        if (self == null) self = this;
        var _span;
        var _img;
        var _spanc;
        // [137]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [138]  span.Initialize( {45} , {46} ) 
        _span.initialize("", "span");
        // [139]  span.AddClass( {47} ).AddContent(sTitle).AddClass(className) 
        _span.addclass("card-title").addcontent(_stitle).addclass(_classname);
        // [140]  App.MaterialUseTheme(themeName,span) 
        self._app.materialusetheme(_themename, _span);
        // [141]  Select Case CardType 
        switch ("" + self._cardtype) {
            // [142]  Case App.EnumCardType.Basic 
            case "" + self._app._enumcardtype._basic:
                // [143]  content.AddContent(span.HTML) 
                self._content.addcontent(_span.html());
                // [144]  Case App.EnumCardType.Image 
                break;
            case "" + self._app._enumcardtype._image:
                // [145]  Dim img As UOEHTML 
                _img = new banano_uoebanano_uoehtml();
                // [146]  img.Initialize( {48} , {49} ) 
                _img.initialize("", "img");
                // [147]  img.SetSRC(ImageURL,True) 
                _img.setsrc(self._imageurl, true);
                // [148]  image.AddElement(img) 
                self._image.addelement(_img);
                // [149]  image.AddElement(span) 
                self._image.addelement(_span);
                // [150]  Case App.EnumCardType.Reveal 
                break;
            case "" + self._app._enumcardtype._reveal:
                // [151]  Dim img As UOEHTML 
                _img = new banano_uoebanano_uoehtml();
                // [152]  img.Initialize( {50} , {51} ) 
                _img.initialize("", "img");
                // [153]  img.SetSRC(ImageURL,True) 
                _img.setsrc(self._imageurl, true);
                // [154]  img.AddClassOnCondition(bReveal, {52} ) 
                _img.addclassoncondition(self._breveal, "activator");
                // [155]  image.AddElement(img) 
                self._image.addelement(_img);
                // [157]  span.AddClass( {53} ) 
                _span.addclass("activator");
                // [158]  modUOE.MaterialAddIcon(App,span, {54} , {55} , {56} ,False,False,False,False,False) 
                _banano_uoebanano_moduoe.materialaddicon(self._app, _span, "mdi-more_vert", "right", "", false, false, false, false, false);
                // [159]  content.AddElement(span) 
                self._content.addelement(_span);
                // [161]  Dim spanc As UOEHTML 
                _spanc = new banano_uoebanano_uoehtml();
                // [162]  spanc.Initialize( {57} , {58} ) 
                _spanc.initialize("", "span");
                // [163]  spanc.AddClass( {59} ).AddContent(sTitle).AddClass(className) 
                _spanc.addclass("card-title").addcontent(_stitle).addclass(_classname);
                // [164]  modUOE.MaterialAddIcon(App,spanc, {60} , {61} , {62} ,False,False,False,False,False) 
                _banano_uoebanano_moduoe.materialaddicon(self._app, _spanc, "mdi-close", "right", "", false, false, false, false, false);
                // [165]  App.MaterialUseTheme(themeName,spanc) 
                self._app.materialusetheme(_themename, _spanc);
                // [166]  reveal.AddElement(spanc) 
                self._reveal.addelement(_spanc);
                // [167]  End Select 
                break;
        }
        // [168]  Return Me 
        return self;
        // End Sub
    };

    // [172] Sub AddParagraph(pText As String, pTheme As String, pClass As String) As UOECard 
    this.addparagraph = function (_ptext, _ptheme, _pclass) {
        if (self == null) self = this;
        var _span;
        // [173]  Dim span As UOEHTML 
        _span = new banano_uoebanano_uoehtml();
        // [174]  span.Initialize( {63} , {64} ) 
        _span.initialize("", "p");
        // [175]  span.AddClass(pClass).AddContent(pText) 
        _span.addclass(_pclass).addcontent(_ptext);
        // [176]  App.MaterialUseTheme(pTheme,span) 
        self._app.materialusetheme(_ptheme, _span);
        // [177]  Select Case CardType 
        switch ("" + self._cardtype) {
            // [178]  Case App.EnumCardType.reveal 
            case "" + self._app._enumcardtype._reveal:
                // [179]  reveal.AddContent(span.HTML) 
                self._reveal.addcontent(_span.html());
                // [180]  Case Else 
                break;
            default:
                // [181]  content.AddContent(span.HTML) 
                self._content.addcontent(_span.html());
                // [182]  End Select 
                break;
        }
        // [183]  Return Me 
        return self;
        // End Sub
    };

    // [187] Sub AddLink(aid As String, atitle As String, ahref As String) As UOECard 
    this.addlink = function (_aid, _atitle, _ahref) {
        if (self == null) self = this;
        var _a;
        var _p;
        // [188]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [189]  a.Initialize(aid, {65} ) 
        _a.initialize(_aid, "a");
        // [190]  a.SetHREF(ahref).AddContent(atitle) 
        _a.sethref(_ahref).addcontent(_atitle);
        // [191]  Dim p As UOEHTML 
        _p = new banano_uoebanano_uoehtml();
        // [192]  p.Initialize( {66} , {67} ) 
        _p.initialize("", "p");
        // [193]  p.AddElement(a) 
        _p.addelement(_a);
        // [194]  content.AddElement(p) 
        self._content.addelement(_p);
        // [195]  App.AddEvent(aid, {68} ) 
        self._app.addevent(_aid, "click");
        // [196]  Return Me 
        return self;
        // End Sub
    };

    // [200] Sub AddAction(aid As String, atitle As String, ahref As String) As UOECard 
    this.addaction = function (_aid, _atitle, _ahref) {
        if (self == null) self = this;
        var _a;
        // [201]  Dim a As UOEHTML 
        _a = new banano_uoebanano_uoehtml();
        // [202]  a.Initialize(aid, {69} ) 
        _a.initialize(_aid, "a");
        // [203]  a.SetHREF(ahref).AddContent(atitle) 
        _a.sethref(_ahref).addcontent(_atitle);
        // [204]  actions.AddContent(a.HTML) 
        self._actions.addcontent(_a.html());
        // [205]  hasActions = True 
        self._hasactions = true;
        // [206]  App.AddEvent(aid, {70} ) 
        self._app.addevent(_aid, "click");
        // [207]  Return Me 
        return self;
        // End Sub
    };

    // [211] Sub ToString() As String 
    this.tostring = function () {
        if (self == null) self = this;
        // [212]  If Panel Then 
        if (self._panel) {
            // [213]  card.RemoveClass( {71} ).AddClass( {72} ) 
            self._card.removeclass("card").addclass("card-panel");
            // [214]  End If 
        }
        // [215]  card.MaterialZDepth(ZDepth) 
        self._card.materialzdepth(self._zdepth);
        // [216]  card.MaterialVisibility(Visibility) 
        self._card.materialvisibility(self._visibility);
        // [217]  card.MaterialHoverable(Hoverable) 
        self._card.materialhoverable(self._hoverable);
        // [218]  card.AddClassOnCondition(Horizontal, {73} ) 
        self._card.addclassoncondition(self._horizontal, "horizontal");
        // [219]  card.AddClassOnCondition(StickyAction, {74} ) 
        self._card.addclassoncondition(self._stickyaction, "sticky-action");
        // [220]  image.AddClassOnCondition(bReveal, {75} ) 
        self._image.addclassoncondition(self._breveal, "waves-effect waves-block waves-light");
        // [226]  tabs.AddElement(ul) 
        self._tabs.addelement(self._ul);
        // [227]  Select Case CardType 
        switch ("" + self._cardtype) {
            // [228]  Case App.EnumCardType.basic 
            case "" + self._app._enumcardtype._basic:
                // [229]  If Horizontal Then 
                if (self._horizontal) {
                    // [230]  stacked.AddElement(content) 
                    self._stacked.addelement(self._content);
                    // [231]  If hasTabs Then 
                    if (self._hastabs) {
                        // [232]  card.AddElement(tabs) 
                        self._card.addelement(self._tabs);
                        // [233]  card.AddElement(uldata) 
                        self._card.addelement(self._uldata);
                        // [234]  End If 
                    }
                    // [235]  stacked.AddElement(actions) 
                    self._stacked.addelement(self._actions);
                    // [236]  card.AddElement(stacked) 
                    self._card.addelement(self._stacked);
                    // [237]  Else 
                } else {
                    // [238]  card.AddElement(content) 
                    self._card.addelement(self._content);
                    // [239]  If hasTabs Then 
                    if (self._hastabs) {
                        // [240]  card.AddElement(tabs) 
                        self._card.addelement(self._tabs);
                        // [241]  card.AddElement(uldata) 
                        self._card.addelement(self._uldata);
                        // [242]  End If 
                    }
                    // [243]  If hasActions Then card.AddElement(actions) 
                    if (self._hasactions) {
                        self._card.addelement(self._actions);
                    }
                    // [244]  End If 
                }
                // [245]  Case App.EnumCardType.image 
                break;
            case "" + self._app._enumcardtype._image:
                // [246]  card.AddElement(image) 
                self._card.addelement(self._image);
                // [247]  If Horizontal Then 
                if (self._horizontal) {
                    // [248]  stacked.AddElement(content) 
                    self._stacked.addelement(self._content);
                    // [249]  If hasTabs Then 
                    if (self._hastabs) {
                        // [250]  card.AddElement(tabs) 
                        self._card.addelement(self._tabs);
                        // [251]  card.AddElement(uldata) 
                        self._card.addelement(self._uldata);
                        // [252]  End If 
                    }
                    // [253]  If hasActions Then stacked.AddElement(actions) 
                    if (self._hasactions) {
                        self._stacked.addelement(self._actions);
                    }
                    // [254]  card.AddElement(stacked) 
                    self._card.addelement(self._stacked);
                    // [255]  Else 
                } else {
                    // [256]  card.AddElement(content) 
                    self._card.addelement(self._content);
                    // [257]  If hasTabs Then 
                    if (self._hastabs) {
                        // [258]  card.AddElement(tabs) 
                        self._card.addelement(self._tabs);
                        // [259]  card.AddElement(uldata) 
                        self._card.addelement(self._uldata);
                        // [260]  End If 
                    }
                    // [261]  If hasActions Then card.AddElement(actions) 
                    if (self._hasactions) {
                        self._card.addelement(self._actions);
                    }
                    // [262]  End If 
                }
                // [263]  Case App.EnumCardType.reveal 
                break;
            case "" + self._app._enumcardtype._reveal:
                // [264]  card.AddElement(image) 
                self._card.addelement(self._image);
                // [265]  card.AddElement(content) 
                self._card.addelement(self._content);
                // [266]  If hasTabs Then 
                if (self._hastabs) {
                    // [267]  card.AddElement(tabs) 
                    self._card.addelement(self._tabs);
                    // [268]  card.AddElement(uldata) 
                    self._card.addelement(self._uldata);
                    // [269]  End If 
                }
                // [270]  If hasActions Then card.AddElement(actions) 
                if (self._hasactions) {
                    self._card.addelement(self._actions);
                }
                // [271]  card.AddElement(reveal) 
                self._card.addelement(self._reveal);
                // [272]  End Select 
                break;
        }
        // [273]  App.ApplyToolTip(ID,card) 
        self._app.applytooltip(self._id, self._card);
        // [274]  Return card.HTML 
        return self._card.html();
        // End Sub
    };

    // [278] Sub AddStyleAttribute(attribute As String, value As String) As UOECard 
    this.addstyleattribute = function (_attribute, _value) {
        if (self == null) self = this;
        // [279]  card.AddStyleAttribute(attribute,value) 
        self._card.addstyleattribute(_attribute, _value);
        // [280]  Return Me 
        return self;
        // End Sub
    };

    // [284] Sub AddClass(sClass As String) As UOECard 
    this.addclass = function (_sclass) {
        if (self == null) self = this;
        // [285]  card.AddClass(sClass) 
        self._card.addclass(_sclass);
        // [286]  Return Me 
        return self;
        // End Sub
    };

    // [290] Sub RemoveClass(sClass As String) As UOECard 
    this.removeclass = function (_sclass) {
        if (self == null) self = this;
        // [291]  card.RemoveClass(sClass) 
        self._card.removeclass(_sclass);
        // [292]  Return Me 
        return self;
        // End Sub
    };

    // [296] Sub AddAttribute(attr As String, value As String) As UOECard 
    this.addattribute = function (_attr, _value) {
        if (self == null) self = this;
        // [297]  card.AddAttribute(attr,value) 
        self._card.addattribute(_attr, _value);
        // [298]  Return Me 
        return self;
        // End Sub
    };

    // [302] Sub RemoveAttribute(attr As String) As UOECard 
    this.removeattribute = function (_attr) {
        if (self == null) self = this;
        // [303]  card.RemoveAttribute(attr) 
        self._card.removeattribute(_attr);
        // [304]  Return Me 
        return self;
        // End Sub
    };

}
// =========================== UOEBANano  ===========================
function banano_uoebanano() {
    var self;
    this._appname = "UOEBANano";

}
_banano_uoebanano.uoebanano_ready();