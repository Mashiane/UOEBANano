package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoespan extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoespan", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoespan.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _span = null;
public boolean _verticalalign = false;
public String _visibility = "";
public String _text = "";
public String _theme = "";
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoespan  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 45;BA.debugLine="span.AddAttribute(attr,value)";
_span._addattribute(_attr,_value);
 //BA.debugLineNum = 46;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoespan  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 56;BA.debugLine="Sub AddClass(sClass As String) As UOESpan";
 //BA.debugLineNum = 57;BA.debugLine="span.AddClass(sClass)";
_span._addclass(_sclass);
 //BA.debugLineNum = 58;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoespan  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 63;BA.debugLine="span.AddStyleAttribute(attribute,value)";
_span._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 64;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Public VerticalAlign As Boolean";
_verticalalign = false;
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoespan  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stext,boolean _bverticalalign,String _svisibility,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sid As St";
 //BA.debugLineNum = 17;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 18;BA.debugLine="span.Initialize(sid,\"span\")";
_span._initialize(ba,_sid,"span");
 //BA.debugLineNum = 19;BA.debugLine="VerticalAlign = bVerticalAlign";
_verticalalign = _bverticalalign;
 //BA.debugLineNum = 20;BA.debugLine="Text = sText";
_text = _stext;
 //BA.debugLineNum = 21;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 22;BA.debugLine="Visibility = sVisibility";
_visibility = _svisibility;
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoespan  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Sub RemoveAttribute(attr As String) As UOESpan";
 //BA.debugLineNum = 51;BA.debugLine="span.RemoveAttribute(attr)";
_span._removeattribute(_attr);
 //BA.debugLineNum = 52;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoespan  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Sub RemoveClass(sClass As String) As UOESpan";
 //BA.debugLineNum = 39;BA.debugLine="span.RemoveClass(sClass)";
_span._removeclass(_sclass);
 //BA.debugLineNum = 40;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoespan)(this);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 28;BA.debugLine="span.ID = ID";
_span._id = _id;
 //BA.debugLineNum = 29;BA.debugLine="span.AddStyleAttributeOnCondition(VerticalAlign,\"";
_span._addstyleattributeoncondition(_verticalalign,"vertical-align","top");
 //BA.debugLineNum = 30;BA.debugLine="span.MaterialVisibility(Visibility)";
_span._materialvisibility(_visibility);
 //BA.debugLineNum = 31;BA.debugLine="span.AddContent(Text)";
_span._addcontent(_text);
 //BA.debugLineNum = 32;BA.debugLine="App.MaterialUseTheme(Theme,span)";
_app._materialusetheme(_theme,_span);
 //BA.debugLineNum = 33;BA.debugLine="Return span.html";
if (true) return _span._html();
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
