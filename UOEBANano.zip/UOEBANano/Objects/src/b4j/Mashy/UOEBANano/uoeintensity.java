package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeintensity extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeintensity", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeintensity.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _normal = "";
public String _lighten5 = "";
public String _lighten4 = "";
public String _lighten3 = "";
public String _lighten2 = "";
public String _lighten1 = "";
public String _darken1 = "";
public String _darken2 = "";
public String _darken3 = "";
public String _darken4 = "";
public String _accent1 = "";
public String _accent2 = "";
public String _accent3 = "";
public String _accent4 = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public NORMAL As String= \"\"";
_normal = "";
 //BA.debugLineNum = 6;BA.debugLine="Public LIGHTEN5 As String= \"lighten-5\"";
_lighten5 = "lighten-5";
 //BA.debugLineNum = 7;BA.debugLine="Public LIGHTEN4 As String= \"lighten-4\"";
_lighten4 = "lighten-4";
 //BA.debugLineNum = 8;BA.debugLine="Public LIGHTEN3 As String= \"lighten-3\"";
_lighten3 = "lighten-3";
 //BA.debugLineNum = 9;BA.debugLine="Public LIGHTEN2 As String= \"lighten-2\"";
_lighten2 = "lighten-2";
 //BA.debugLineNum = 10;BA.debugLine="Public LIGHTEN1 As String= \"lighten-1\"";
_lighten1 = "lighten-1";
 //BA.debugLineNum = 11;BA.debugLine="Public DARKEN1 As String= \"darken-1\"";
_darken1 = "darken-1";
 //BA.debugLineNum = 12;BA.debugLine="Public DARKEN2 As String= \"darken-2\"";
_darken2 = "darken-2";
 //BA.debugLineNum = 13;BA.debugLine="Public DARKEN3 As String= \"darken-3\"";
_darken3 = "darken-3";
 //BA.debugLineNum = 14;BA.debugLine="Public DARKEN4 As String= \"darken-4\"";
_darken4 = "darken-4";
 //BA.debugLineNum = 15;BA.debugLine="Public ACCENT1 As String= \"accent-1\"";
_accent1 = "accent-1";
 //BA.debugLineNum = 16;BA.debugLine="Public ACCENT2 As String= \"accent-2\"";
_accent2 = "accent-2";
 //BA.debugLineNum = 17;BA.debugLine="Public ACCENT3 As String= \"accent-3\"";
_accent3 = "accent-3";
 //BA.debugLineNum = 18;BA.debugLine="Public ACCENT4 As String= \"accent-4\"";
_accent4 = "accent-4";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 21;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
