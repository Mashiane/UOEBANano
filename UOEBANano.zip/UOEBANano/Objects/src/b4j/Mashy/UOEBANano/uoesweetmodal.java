package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoesweetmodal extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoesweetmodal", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoesweetmodal.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public anywheresoftware.b4a.keywords.StringBuilderWrapper _tabs = null;
public anywheresoftware.b4a.keywords.StringBuilderWrapper _tabcontent = null;
public boolean _showclosebutton = false;
public String _title = "";
public String _content = "";
public boolean _blocking = false;
public String _width = "";
public String _icon = "";
public String _timeout = "";
public String _j = "";
public String _icon_success = "";
public String _icon_warning = "";
public String _icon_error = "";
public boolean _hastabs = false;
public int _tabcount = 0;
public anywheresoftware.b4a.keywords.StringBuilderWrapper _buttons = null;
public boolean _hasbuttons = false;
public String _buttontheme_secondaryb = "";
public String _buttontheme_redb = "";
public String _buttontheme_blueb = "";
public String _buttontheme_greenb = "";
public String _buttontheme_darkgreyb = "";
public String _buttontheme_lightgreyb = "";
public String _buttontheme_yellowb = "";
public String _buttontheme_purpleb = "";
public String _buttontheme_tealb = "";
public String _buttontheme_brownb = "";
public String _buttontheme_orangeb = "";
public String _buttontheme_pinkb = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _addbutton(String _btnid,String _btntitle,anywheresoftware.b4a.objects.collections.List _btnclasses,String _btnonclick) throws Exception{
String _vars = "";
boolean _sw = false;
String _script = "";
 //BA.debugLineNum = 122;BA.debugLine="Sub AddButton(btnID As String,btnTitle As String,b";
 //BA.debugLineNum = 123;BA.debugLine="hasButtons = True";
_hasbuttons = __c.True;
 //BA.debugLineNum = 124;BA.debugLine="Dim vars As String = \"\"";
_vars = "";
 //BA.debugLineNum = 125;BA.debugLine="If btnClasses <> Null Then";
if (_btnclasses!= null) { 
 //BA.debugLineNum = 126;BA.debugLine="vars = App.Join(\",\",btnClasses)";
_vars = _app._join(",",_btnclasses);
 };
 //BA.debugLineNum = 128;BA.debugLine="Dim sw As Boolean = btnOnClick.EndsWith(\";\")";
_sw = _btnonclick.endsWith(";");
 //BA.debugLineNum = 129;BA.debugLine="If sw Then";
if (_sw) { 
 }else {
 //BA.debugLineNum = 131;BA.debugLine="btnOnClick = btnOnClick & \";\"";
_btnonclick = _btnonclick+";";
 };
 //BA.debugLineNum = 133;BA.debugLine="Dim script As String = $\"${btnID}: { 			label: '$";
_script = (""+__c.SmartStringFormatter("",(Object)(_btnid))+": {\n"+"			label: '"+__c.SmartStringFormatter("",(Object)(_btntitle))+"',\n"+"			classes: '"+__c.SmartStringFormatter("",(Object)(_vars))+"',\n"+"			action: function() {\n"+"				return "+__c.SmartStringFormatter("",(Object)(_btnonclick))+"\n"+"			}\n"+"		},");
 //BA.debugLineNum = 140;BA.debugLine="buttons.Append(script)";
_buttons.Append(_script);
 //BA.debugLineNum = 141;BA.debugLine="buttons.Append(CRLF)";
_buttons.Append(__c.CRLF);
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return "";
}
public String  _addcontainer(b4j.Mashy.UOEBANano.uoecontainer _scontent) throws Exception{
String _scode = "";
 //BA.debugLineNum = 56;BA.debugLine="Sub AddContainer(sContent As UOEContainer)";
 //BA.debugLineNum = 57;BA.debugLine="Content = \"\"";
_content = "";
 //BA.debugLineNum = 58;BA.debugLine="If sContent <> Null Then";
if (_scontent!= null) { 
 //BA.debugLineNum = 59;BA.debugLine="Dim sCode As String = sContent.ToString";
_scode = _scontent._tostring();
 //BA.debugLineNum = 60;BA.debugLine="sCode = sCode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 61;BA.debugLine="Content = sCode";
_content = _scode;
 };
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _addtab(String _stitle,String _sicon,b4j.Mashy.UOEBANano.uoecontainer _scontent) throws Exception{
String _scode = "";
String _script = "";
 //BA.debugLineNum = 66;BA.debugLine="Sub AddTab(sTitle As String, sIcon As String, sCon";
 //BA.debugLineNum = 67;BA.debugLine="Dim sCode As String = \"\"";
_scode = "";
 //BA.debugLineNum = 68;BA.debugLine="If sContent <> Null Then";
if (_scontent!= null) { 
 //BA.debugLineNum = 69;BA.debugLine="sCode = sContent.ToString";
_scode = _scontent._tostring();
 //BA.debugLineNum = 70;BA.debugLine="sCode = sCode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 };
 //BA.debugLineNum = 72;BA.debugLine="tabCount = tabCount + 1";
_tabcount = (int) (_tabcount+1);
 //BA.debugLineNum = 74;BA.debugLine="Dim script As String = $\"tab${tabCount}: {label:";
_script = ("tab"+__c.SmartStringFormatter("",(Object)(_tabcount))+": {label: '"+__c.SmartStringFormatter("",(Object)(_stitle))+"', icon: '"+__c.SmartStringFormatter("",(Object)(_sicon))+"'},");
 //BA.debugLineNum = 75;BA.debugLine="tabs.Append(script).Append(CRLF)";
_tabs.Append(_script).Append(__c.CRLF);
 //BA.debugLineNum = 77;BA.debugLine="script = $\"tab${tabCount}: '${sCode}',\"$";
_script = ("tab"+__c.SmartStringFormatter("",(Object)(_tabcount))+": '"+__c.SmartStringFormatter("",(Object)(_scode))+"',");
 //BA.debugLineNum = 78;BA.debugLine="tabContent.Append(script).Append(CRLF)";
_tabcontent.Append(_script).Append(__c.CRLF);
 //BA.debugLineNum = 79;BA.debugLine="hasTabs = True";
_hastabs = __c.True;
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public String  _buildbuttons() throws Exception{
String _script = "";
String _delim = "";
String _sout = "";
 //BA.debugLineNum = 108;BA.debugLine="private Sub BuildButtons() As String";
 //BA.debugLineNum = 109;BA.debugLine="Dim script As String";
_script = "";
 //BA.debugLineNum = 110;BA.debugLine="If hasButtons Then";
if (_hasbuttons) { 
 //BA.debugLineNum = 111;BA.debugLine="Dim delim As String = \",\" & CRLF";
_delim = ","+__c.CRLF;
 //BA.debugLineNum = 112;BA.debugLine="Dim sout As String = buttons.ToString";
_sout = _buttons.ToString();
 //BA.debugLineNum = 113;BA.debugLine="delim = App.RemDelim(sout,delim)";
_delim = _app._remdelim(_sout,_delim);
 //BA.debugLineNum = 114;BA.debugLine="script = $\"{${delim}}\"$";
_script = ("{"+__c.SmartStringFormatter("",(Object)(_delim))+"}");
 }else {
 //BA.debugLineNum = 116;BA.debugLine="script = \"{}\"";
_script = "{}";
 };
 //BA.debugLineNum = 118;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _buildcontent() throws Exception{
String _script = "";
String _delim = "";
String _sout = "";
 //BA.debugLineNum = 82;BA.debugLine="private Sub BuildContent() As String";
 //BA.debugLineNum = 83;BA.debugLine="Dim script As String";
_script = "";
 //BA.debugLineNum = 84;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 85;BA.debugLine="Dim delim As String = \",\" & CRLF";
_delim = ","+__c.CRLF;
 //BA.debugLineNum = 86;BA.debugLine="Dim sout As String = tabContent.ToString";
_sout = _tabcontent.ToString();
 //BA.debugLineNum = 87;BA.debugLine="delim = App.RemDelim(sout,delim)";
_delim = _app._remdelim(_sout,_delim);
 //BA.debugLineNum = 88;BA.debugLine="script = $\"{${delim}}\"$";
_script = ("{"+__c.SmartStringFormatter("",(Object)(_delim))+"}");
 }else {
 //BA.debugLineNum = 90;BA.debugLine="script = $\"'${Content}'\"$";
_script = ("'"+__c.SmartStringFormatter("",(Object)(_content))+"'");
 };
 //BA.debugLineNum = 92;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 93;BA.debugLine="End Sub";
return "";
}
public String  _buildtitle() throws Exception{
String _script = "";
String _delim = "";
String _sout = "";
 //BA.debugLineNum = 95;BA.debugLine="private Sub BuildTitle() As String";
 //BA.debugLineNum = 96;BA.debugLine="Dim script As String";
_script = "";
 //BA.debugLineNum = 97;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 98;BA.debugLine="Dim delim As String = \",\" & CRLF";
_delim = ","+__c.CRLF;
 //BA.debugLineNum = 99;BA.debugLine="Dim sout As String = tabs.ToString";
_sout = _tabs.ToString();
 //BA.debugLineNum = 100;BA.debugLine="delim = App.RemDelim(sout,delim)";
_delim = _app._remdelim(_sout,_delim);
 //BA.debugLineNum = 101;BA.debugLine="script = $\"{${delim}}\"$";
_script = ("{"+__c.SmartStringFormatter("",(Object)(_delim))+"}");
 }else {
 //BA.debugLineNum = 103;BA.debugLine="script = $\"'${Title}'\"$";
_script = ("'"+__c.SmartStringFormatter("",(Object)(_title))+"'");
 };
 //BA.debugLineNum = 105;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private tabs As StringBuilder";
_tabs = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Private tabContent As StringBuilder";
_tabcontent = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Public showCloseButton	As Boolean";
_showclosebutton = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Content As String";
_content = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Blocking As Boolean = False";
_blocking = __c.False;
 //BA.debugLineNum = 12;BA.debugLine="Public Width As String";
_width = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Icon As String";
_icon = "";
 //BA.debugLineNum = 14;BA.debugLine="Public Timeout As String";
_timeout = "";
 //BA.debugLineNum = 15;BA.debugLine="Private j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 16;BA.debugLine="Public Icon_Success As String = $\"${j}.sweetModal";
_icon_success = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_SUCCESS");
 //BA.debugLineNum = 17;BA.debugLine="Public Icon_Warning As String = $\"${j}.sweetModal";
_icon_warning = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_WARNING");
 //BA.debugLineNum = 18;BA.debugLine="Public Icon_Error As String = $\"${j}.sweetModal.I";
_icon_error = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_ERROR");
 //BA.debugLineNum = 19;BA.debugLine="Private hasTabs As Boolean";
_hastabs = false;
 //BA.debugLineNum = 20;BA.debugLine="Private tabCount As Int";
_tabcount = 0;
 //BA.debugLineNum = 21;BA.debugLine="Private buttons As StringBuilder";
_buttons = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Private hasButtons As Boolean";
_hasbuttons = false;
 //BA.debugLineNum = 23;BA.debugLine="Public ButtonTheme_secondaryB As String = \"second";
_buttontheme_secondaryb = "secondaryB";
 //BA.debugLineNum = 24;BA.debugLine="Public ButtonTheme_redB As String = \"redB\"";
_buttontheme_redb = "redB";
 //BA.debugLineNum = 25;BA.debugLine="Public ButtonTheme_blueB As String = \"blueB\"";
_buttontheme_blueb = "blueB";
 //BA.debugLineNum = 26;BA.debugLine="Public ButtonTheme_greenB As String = \"greenB\"";
_buttontheme_greenb = "greenB";
 //BA.debugLineNum = 27;BA.debugLine="Public ButtonTheme_darkGreyB As String = \"darkGre";
_buttontheme_darkgreyb = "darkGreyB";
 //BA.debugLineNum = 28;BA.debugLine="Public ButtonTheme_lightGreyB As String = \"lightG";
_buttontheme_lightgreyb = "lightGreyB";
 //BA.debugLineNum = 29;BA.debugLine="Public ButtonTheme_yellowB As String = \"yellowB\"";
_buttontheme_yellowb = "yellowB";
 //BA.debugLineNum = 30;BA.debugLine="Public ButtonTheme_purpleB As String = \"purpleB\"";
_buttontheme_purpleb = "purpleB";
 //BA.debugLineNum = 31;BA.debugLine="Public ButtonTheme_tealB As String = \"tealB\"";
_buttontheme_tealb = "tealB";
 //BA.debugLineNum = 32;BA.debugLine="Public ButtonTheme_brownB As String = \"brownB\"";
_buttontheme_brownb = "brownB";
 //BA.debugLineNum = 33;BA.debugLine="Public ButtonTheme_orangeB As String = \"orangeB\"";
_buttontheme_orangeb = "orangeB";
 //BA.debugLineNum = 34;BA.debugLine="Public ButtonTheme_pinkB As String = \"pinkB\"";
_buttontheme_pinkb = "pinkB";
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 38;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sid As St";
 //BA.debugLineNum = 40;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 41;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 42;BA.debugLine="tabs.Initialize";
_tabs.Initialize();
 //BA.debugLineNum = 43;BA.debugLine="tabContent.Initialize";
_tabcontent.Initialize();
 //BA.debugLineNum = 44;BA.debugLine="Width = \"auto\"";
_width = "auto";
 //BA.debugLineNum = 45;BA.debugLine="Blocking = False";
_blocking = __c.False;
 //BA.debugLineNum = 46;BA.debugLine="hasTabs = False";
_hastabs = __c.False;
 //BA.debugLineNum = 47;BA.debugLine="Icon = \"''\"";
_icon = "''";
 //BA.debugLineNum = 48;BA.debugLine="Timeout = \"null\"";
_timeout = "null";
 //BA.debugLineNum = 49;BA.debugLine="tabCount = 0";
_tabcount = (int) (0);
 //BA.debugLineNum = 50;BA.debugLine="buttons.Initialize";
_buttons.Initialize();
 //BA.debugLineNum = 51;BA.debugLine="hasButtons = False";
_hasbuttons = __c.False;
 //BA.debugLineNum = 52;BA.debugLine="showCloseButton = True";
_showclosebutton = __c.True;
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
String _sshowclosebutton = "";
String _sblocking = "";
String _script = "";
 //BA.debugLineNum = 146;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 147;BA.debugLine="Dim sshowCloseButton As String = App.iif(showClos";
_sshowclosebutton = BA.ObjectToString(_app._iif(BA.ObjectToString(_showclosebutton),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 148;BA.debugLine="Dim sBlocking As String = App.iif(Blocking,\"true\"";
_sblocking = BA.ObjectToString(_app._iif(BA.ObjectToString(_blocking),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 149;BA.debugLine="Dim script As String = $\"${j}.sweetModal({ 	title";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal({\n"+"	title: "+__c.SmartStringFormatter("",(Object)(_buildtitle()))+",\n"+"	content: "+__c.SmartStringFormatter("",(Object)(_buildcontent()))+" ,\n"+"	icon: "+__c.SmartStringFormatter("",(Object)(_icon))+",\n"+"	showCloseButton: "+__c.SmartStringFormatter("",(Object)(_sshowclosebutton))+",\n"+"	blocking: "+__c.SmartStringFormatter("",(Object)(_sblocking))+",	\n"+"	timeout: "+__c.SmartStringFormatter("",(Object)(_timeout))+",\n"+"	width: '"+__c.SmartStringFormatter("",(Object)(_width))+"',\n"+"	buttons: "+__c.SmartStringFormatter("",(Object)(_buildbuttons()))+"\n"+"});");
 //BA.debugLineNum = 159;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
