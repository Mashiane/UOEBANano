package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetoast extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetoast", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetoast.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _text = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _theme = "";
public String _callbackfunction = "";
public String _buttontext = "";
public boolean _isround = false;
public int _duration = 0;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoetoast  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 50;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 51;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoast)(this);
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetoast  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Sub AddClass(sClass As String) As UOEToast";
 //BA.debugLineNum = 38;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 39;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoast)(this);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetoast  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 32;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 33;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoast)(this);
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Text As String";
_text = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Private CallBackFunction As String";
_callbackfunction = "";
 //BA.debugLineNum = 10;BA.debugLine="Private ButtonText As String";
_buttontext = "";
 //BA.debugLineNum = 11;BA.debugLine="Private IsRound As Boolean";
_isround = false;
 //BA.debugLineNum = 12;BA.debugLine="Private Duration As Int";
_duration = 0;
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _tid,String _ttext,String _tbuttontext,String _tcallback,boolean _tround,int _tduration,String _ttheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 16;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, tID As St";
 //BA.debugLineNum = 18;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 19;BA.debugLine="Text = tText";
_text = _ttext;
 //BA.debugLineNum = 20;BA.debugLine="ID = tID.tolowercase";
_id = _tid.toLowerCase();
 //BA.debugLineNum = 21;BA.debugLine="Theme = tTheme";
_theme = _ttheme;
 //BA.debugLineNum = 22;BA.debugLine="Element.Initialize(ID,\"span\")";
_element._initialize(ba,_id,"span");
 //BA.debugLineNum = 23;BA.debugLine="CallBackFunction = tCallBack";
_callbackfunction = _tcallback;
 //BA.debugLineNum = 24;BA.debugLine="ButtonText = tButtonText";
_buttontext = _tbuttontext;
 //BA.debugLineNum = 25;BA.debugLine="IsRound = tRound";
_isround = _tround;
 //BA.debugLineNum = 26;BA.debugLine="Duration = tDuration";
_duration = _tduration;
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetoast  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEToast";
 //BA.debugLineNum = 56;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoast)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetoast  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub RemoveClass(sClass As String) As UOEToast";
 //BA.debugLineNum = 44;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 45;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoast)(this);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
b4j.Mashy.UOEBANano.uoehtml _btn = null;
String _tclass = "";
String _srounded = "";
String _js = "";
String _scontent = "";
 //BA.debugLineNum = 61;BA.debugLine="Sub ToSTring As String";
 //BA.debugLineNum = 62;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 63;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 64;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 65;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 66;BA.debugLine="Element.addcontent(Text)";
_element._addcontent(_text);
 //BA.debugLineNum = 67;BA.debugLine="sb.Append(Element.HTML)";
_sb.Append(_element._html());
 //BA.debugLineNum = 68;BA.debugLine="If ButtonText.Length > 0 Then";
if (_buttontext.length()>0) { 
 //BA.debugLineNum = 69;BA.debugLine="Dim btn As UOEHTML";
_btn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 70;BA.debugLine="btn.Initialize(ID & \"-button\",\"button\")";
_btn._initialize(ba,_id+"-button","button");
 //BA.debugLineNum = 71;BA.debugLine="btn.AddClass(\"btn-flat\")";
_btn._addclass("btn-flat");
 //BA.debugLineNum = 72;BA.debugLine="btn.AddClass(\"toast-action\")";
_btn._addclass("toast-action");
 //BA.debugLineNum = 73;BA.debugLine="sb.Append(btn.HTML)";
_sb.Append(_btn._html());
 };
 //BA.debugLineNum = 75;BA.debugLine="Dim tClass As String = App.MaterialGetTheme(Theme";
_tclass = _app._materialgettheme(_theme);
 //BA.debugLineNum = 76;BA.debugLine="Dim srounded As String = \"\"";
_srounded = "";
 //BA.debugLineNum = 77;BA.debugLine="srounded = App.iif(IsRound,\"rounded\",\"\")";
_srounded = BA.ObjectToString(_app._iif(BA.ObjectToString(_isround),(Object)("rounded"),(Object)("")));
 //BA.debugLineNum = 78;BA.debugLine="Dim js As String";
_js = "";
 //BA.debugLineNum = 79;BA.debugLine="Dim scontent As String = sb.tostring";
_scontent = _sb.ToString();
 //BA.debugLineNum = 80;BA.debugLine="scontent = scontent.Replace(CRLF,\"\")";
_scontent = _scontent.replace(__c.CRLF,"");
 //BA.debugLineNum = 81;BA.debugLine="If CallBackFunction = \"\" Then";
if ((_callbackfunction).equals("")) { 
 //BA.debugLineNum = 82;BA.debugLine="js = $\"M.toast({ 		html:'${scontent}',  		displa";
_js = ("M.toast({\n"+"		html:'"+__c.SmartStringFormatter("",(Object)(_scontent))+"', \n"+"		displayLength:"+__c.SmartStringFormatter("",(Object)(_duration))+", \n"+"		classes:'"+__c.SmartStringFormatter("",(Object)(_srounded))+" "+__c.SmartStringFormatter("",(Object)(_tclass))+"'\n"+"		});");
 }else {
 //BA.debugLineNum = 88;BA.debugLine="js = $\"M.toast({ 		html:'${scontent}',  		comple";
_js = ("M.toast({\n"+"		html:'"+__c.SmartStringFormatter("",(Object)(_scontent))+"', \n"+"		completeCallback:"+__c.SmartStringFormatter("",(Object)(_callbackfunction))+", \n"+"		displayLength:"+__c.SmartStringFormatter("",(Object)(_duration))+", \n"+"		classes:'"+__c.SmartStringFormatter("",(Object)(_srounded))+" "+__c.SmartStringFormatter("",(Object)(_tclass))+"'\n"+"		});");
 };
 //BA.debugLineNum = 95;BA.debugLine="Return js";
if (true) return _js;
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
