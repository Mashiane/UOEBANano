package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoehtml extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoehtml", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoehtml.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _tag = "";
public anywheresoftware.b4a.objects.collections.Map _properties = null;
public anywheresoftware.b4a.objects.collections.List _contents = null;
public anywheresoftware.b4a.objects.collections.Map _classes = null;
public anywheresoftware.b4a.objects.collections.Map _styles = null;
public anywheresoftware.b4a.objects.collections.List _looseattributes = null;
public anywheresoftware.b4a.objects.collections.List _dontbreak = null;
public String _prefix = "";
public boolean _doaproperclose = false;
public boolean _required = false;
public boolean _enabled = false;
public boolean _inline = false;
public boolean _readonly = false;
public anywheresoftware.b4a.objects.collections.Map _cssrule = null;
public anywheresoftware.b4a.objects.collections.List _singlequote = null;
public String _parentid = "";
public String _text = "";
public boolean _textafter = false;
public String _divider = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoehtml  _addattribute(String _skey,String _svalue) throws Exception{
 //BA.debugLineNum = 1239;BA.debugLine="public Sub AddAttribute(skey As String, svalue As";
 //BA.debugLineNum = 1240;BA.debugLine="skey = CStr(skey)";
_skey = _cstr((Object)(_skey));
 //BA.debugLineNum = 1241;BA.debugLine="svalue = CStr(svalue)";
_svalue = _cstr((Object)(_svalue));
 //BA.debugLineNum = 1242;BA.debugLine="skey = skey.Replace(\"undefined\",\"\")";
_skey = _skey.replace("undefined","");
 //BA.debugLineNum = 1243;BA.debugLine="skey = skey.Replace(\"null\",\"\")";
_skey = _skey.replace("null","");
 //BA.debugLineNum = 1244;BA.debugLine="svalue = svalue.Replace(\"undefined\",\"\")";
_svalue = _svalue.replace("undefined","");
 //BA.debugLineNum = 1245;BA.debugLine="svalue = svalue.Replace(\"null\",\"\")";
_svalue = _svalue.replace("null","");
 //BA.debugLineNum = 1246;BA.debugLine="skey = skey.trim";
_skey = _skey.trim();
 //BA.debugLineNum = 1247;BA.debugLine="svalue = svalue.trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 1248;BA.debugLine="If skey.Length > 0 And svalue.Length > 0 Then";
if (_skey.length()>0 && _svalue.length()>0) { 
 //BA.debugLineNum = 1249;BA.debugLine="properties.Put(skey,svalue)";
_properties.Put((Object)(_skey),(Object)(_svalue));
 }else {
 //BA.debugLineNum = 1251;BA.debugLine="properties.Remove(skey)";
_properties.Remove((Object)(_skey));
 };
 //BA.debugLineNum = 1253;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1254;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addattributeoncondition(boolean _bcondition,String _attr,String _value) throws Exception{
 //BA.debugLineNum = 414;BA.debugLine="Sub AddAttributeOnCondition(bCondition As Boolean,";
 //BA.debugLineNum = 415;BA.debugLine="removeAttr(attr)";
_removeattr(_attr);
 //BA.debugLineNum = 416;BA.debugLine="If bCondition = True Then";
if (_bcondition==__c.True) { 
 //BA.debugLineNum = 417;BA.debugLine="AddAttribute(attr,value)";
_addattribute(_attr,_value);
 };
 //BA.debugLineNum = 419;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 420;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addclass(String _value) throws Exception{
anywheresoftware.b4a.objects.collections.List _spclasses = null;
String _strclass = "";
 //BA.debugLineNum = 1225;BA.debugLine="Sub addClass(value As String) As UOEHTML";
 //BA.debugLineNum = 1227;BA.debugLine="value = value.Replace(\" \",\";\")";
_value = _value.replace(" ",";");
 //BA.debugLineNum = 1228;BA.debugLine="Dim spClasses As List = StrParse(\";\",value)";
_spclasses = new anywheresoftware.b4a.objects.collections.List();
_spclasses = _strparse(";",_value);
 //BA.debugLineNum = 1229;BA.debugLine="For Each strClass As String In spClasses";
{
final anywheresoftware.b4a.BA.IterableList group3 = _spclasses;
final int groupLen3 = group3.getSize()
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_strclass = BA.ObjectToString(group3.Get(index3));
 //BA.debugLineNum = 1230;BA.debugLine="strClass = strClass.Trim";
_strclass = _strclass.trim();
 //BA.debugLineNum = 1231;BA.debugLine="If strClass.Length > 0 Then";
if (_strclass.length()>0) { 
 //BA.debugLineNum = 1232;BA.debugLine="classes.Put(strClass,strClass)";
_classes.Put((Object)(_strclass),(Object)(_strclass));
 };
 }
};
 //BA.debugLineNum = 1235;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1236;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addclassoncondition(boolean _bcondition,String _sclass) throws Exception{
 //BA.debugLineNum = 574;BA.debugLine="Sub AddClassOnCondition(bCondition As Boolean, sCl";
 //BA.debugLineNum = 575;BA.debugLine="removeClass(sClass)";
_removeclass(_sclass);
 //BA.debugLineNum = 576;BA.debugLine="If bCondition = True Then";
if (_bcondition==__c.True) { 
 //BA.debugLineNum = 577;BA.debugLine="addClass(sClass)";
_addclass(_sclass);
 };
 //BA.debugLineNum = 579;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 580;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addclassonfalsecondition(boolean _bcondition,String _sclass) throws Exception{
 //BA.debugLineNum = 582;BA.debugLine="Sub AddClassOnFalseCondition(bCondition As Boolean";
 //BA.debugLineNum = 583;BA.debugLine="removeClass(sClass)";
_removeclass(_sclass);
 //BA.debugLineNum = 584;BA.debugLine="If bCondition = False Then";
if (_bcondition==__c.False) { 
 //BA.debugLineNum = 585;BA.debugLine="addClass(sClass)";
_addclass(_sclass);
 };
 //BA.debugLineNum = 587;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 588;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addclassonvalue(int _ivalue,String _sclass) throws Exception{
 //BA.debugLineNum = 567;BA.debugLine="Sub AddClassOnValue(iValue As Int, sClass As Strin";
 //BA.debugLineNum = 568;BA.debugLine="If iValue > 0 Then";
if (_ivalue>0) { 
 //BA.debugLineNum = 569;BA.debugLine="addClass(sClass)";
_addclass(_sclass);
 };
 //BA.debugLineNum = 571;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 572;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addcontent(String _value) throws Exception{
 //BA.debugLineNum = 837;BA.debugLine="public Sub AddContent(value As String) As UOEHTML";
 //BA.debugLineNum = 838;BA.debugLine="value = CStr(value)";
_value = _cstr((Object)(_value));
 //BA.debugLineNum = 839;BA.debugLine="If value.Length > 0 Then";
if (_value.length()>0) { 
 //BA.debugLineNum = 840;BA.debugLine="value = FormatText(value)";
_value = _formattext(_value);
 //BA.debugLineNum = 841;BA.debugLine="Contents.Add(value)";
_contents.Add((Object)(_value));
 };
 //BA.debugLineNum = 843;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 844;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addcontentline(String _value) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="public Sub AddContentLine(value As String) As UOEH";
 //BA.debugLineNum = 68;BA.debugLine="If value <> \"\" Then";
if ((_value).equals("") == false) { 
 //BA.debugLineNum = 69;BA.debugLine="value = value.Replace(CRLF,\"\")";
_value = _value.replace(__c.CRLF,"");
 //BA.debugLineNum = 70;BA.debugLine="value = FormatText(value)";
_value = _formattext(_value);
 //BA.debugLineNum = 71;BA.debugLine="Contents.Add(value)";
_contents.Add((Object)(_value));
 };
 //BA.debugLineNum = 73;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addcontentlist(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
String _strcontent = "";
 //BA.debugLineNum = 607;BA.debugLine="Sub AddContentList(lst As List) As UOEHTML";
 //BA.debugLineNum = 608;BA.debugLine="For Each strContent As String In lst";
{
final anywheresoftware.b4a.BA.IterableList group1 = _lst;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_strcontent = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 609;BA.debugLine="AddContent(strContent)";
_addcontent(_strcontent);
 }
};
 //BA.debugLineNum = 611;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 612;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addcontentlistreverse(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
int _ltot = 0;
int _lcnt = 0;
String _strcontent = "";
 //BA.debugLineNum = 220;BA.debugLine="Sub AddContentListReverse(lst As List) As UOEHTML";
 //BA.debugLineNum = 221;BA.debugLine="Dim lTot As Int = lst.Size - 1";
_ltot = (int) (_lst.getSize()-1);
 //BA.debugLineNum = 222;BA.debugLine="Dim lCnt As Int";
_lcnt = 0;
 //BA.debugLineNum = 223;BA.debugLine="For lCnt = lTot To 0 Step -1";
{
final int step3 = -1;
final int limit3 = (int) (0);
_lcnt = _ltot ;
for (;_lcnt >= limit3 ;_lcnt = _lcnt + step3 ) {
 //BA.debugLineNum = 224;BA.debugLine="Dim strContent As String = lst.Get(lCnt)";
_strcontent = BA.ObjectToString(_lst.Get(_lcnt));
 //BA.debugLineNum = 225;BA.debugLine="AddContent(strContent)";
_addcontent(_strcontent);
 }
};
 //BA.debugLineNum = 227;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addcursor() throws Exception{
 //BA.debugLineNum = 557;BA.debugLine="Sub AddCursor As UOEHTML";
 //BA.debugLineNum = 558;BA.debugLine="AddStyleAttribute(\"cursor\", \"pointer\")";
_addstyleattribute("cursor","pointer");
 //BA.debugLineNum = 559;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 560;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _adddataattribute(String _attribute,String _value) throws Exception{
boolean _sw = false;
 //BA.debugLineNum = 315;BA.debugLine="Sub AddDataAttribute(attribute As String, value As";
 //BA.debugLineNum = 316;BA.debugLine="Dim sw As Boolean = attribute.StartsWith(\"data-\")";
_sw = _attribute.startsWith("data-");
 //BA.debugLineNum = 317;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 318;BA.debugLine="AddAttribute(attribute,value)";
_addattribute(_attribute,_value);
 }else {
 //BA.debugLineNum = 320;BA.debugLine="AddAttribute(\"data-\" & attribute,value)";
_addattribute("data-"+_attribute,_value);
 };
 //BA.debugLineNum = 322;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 323;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _adddataattributeoncondition(boolean _bcondition,String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 325;BA.debugLine="Sub AddDataAttributeOnCondition(bCondition As Bool";
 //BA.debugLineNum = 326;BA.debugLine="removeAttrData(attribute)";
_removeattrdata(_attribute);
 //BA.debugLineNum = 327;BA.debugLine="If bCondition = False Then";
if (_bcondition==__c.False) { 
 //BA.debugLineNum = 328;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 330;BA.debugLine="AddDataAttribute(attribute,value)";
_adddataattribute(_attribute,_value);
 //BA.debugLineNum = 331;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 332;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addelement(b4j.Mashy.UOEBANano.uoehtml _el) throws Exception{
String _scode = "";
 //BA.debugLineNum = 861;BA.debugLine="public Sub AddElement(el As UOEHTML) As UOEHTML";
 //BA.debugLineNum = 862;BA.debugLine="If el <> Null Then";
if (_el!= null) { 
 //BA.debugLineNum = 863;BA.debugLine="Dim scode As String = el.tostring";
_scode = _el._tostring();
 //BA.debugLineNum = 864;BA.debugLine="AddContent(scode)";
_addcontent(_scode);
 };
 //BA.debugLineNum = 866;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 867;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addelementline(b4j.Mashy.UOEBANano.uoehtml _el) throws Exception{
String _scode = "";
 //BA.debugLineNum = 51;BA.debugLine="public Sub AddElementLine(el As UOEHTML) As UOEHTM";
 //BA.debugLineNum = 52;BA.debugLine="If el <> Null Then";
if (_el!= null) { 
 //BA.debugLineNum = 53;BA.debugLine="Dim scode As String = el.html";
_scode = _el._html();
 //BA.debugLineNum = 54;BA.debugLine="AddContent(scode)";
_addcontent(_scode);
 };
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addheading(int _ssize,String _scontent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _hdr = null;
String _hkey = "";
 //BA.debugLineNum = 146;BA.debugLine="Sub AddHeading(sSize As Int, sContent As String) A";
 //BA.debugLineNum = 147;BA.debugLine="Dim hdr As UOEHTML";
_hdr = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 148;BA.debugLine="Dim hKey As String = \"h\" & sSize";
_hkey = "h"+BA.NumberToString(_ssize);
 //BA.debugLineNum = 149;BA.debugLine="hdr.Initialize(\"\",hKey)";
_hdr._initialize(ba,"",_hkey);
 //BA.debugLineNum = 150;BA.debugLine="hdr.AddContent(sContent)";
_hdr._addcontent(_scontent);
 //BA.debugLineNum = 151;BA.debugLine="AddContent(hdr.HTML)";
_addcontent(_hdr._html());
 //BA.debugLineNum = 152;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addlooseattribute(String _value) throws Exception{
 //BA.debugLineNum = 275;BA.debugLine="Sub AddLooseAttribute(value As String) As UOEHTML";
 //BA.debugLineNum = 276;BA.debugLine="removeAttr(value)";
_removeattr(_value);
 //BA.debugLineNum = 277;BA.debugLine="AddAttribute(value,\"true\")";
_addattribute(_value,"true");
 //BA.debugLineNum = 278;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 279;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addlooseattributeoncondition(boolean _bstatus,String _value) throws Exception{
 //BA.debugLineNum = 266;BA.debugLine="Sub AddLooseAttributeOnCondition(bStatus As Boolea";
 //BA.debugLineNum = 267;BA.debugLine="removeAttr(value)";
_removeattr(_value);
 //BA.debugLineNum = 268;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 269;BA.debugLine="AddAttribute(value,\"true\")";
_addattribute(_value,"true");
 };
 //BA.debugLineNum = 271;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 272;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addlooseattributeonfalsecondition(boolean _bstatus,String _value) throws Exception{
 //BA.debugLineNum = 165;BA.debugLine="Sub AddLooseAttributeOnFalseCondition(bStatus As B";
 //BA.debugLineNum = 166;BA.debugLine="removeAttr(value)";
_removeattr(_value);
 //BA.debugLineNum = 167;BA.debugLine="If bStatus = False Then";
if (_bstatus==__c.False) { 
 //BA.debugLineNum = 168;BA.debugLine="AddLooseAttribute(value)";
_addlooseattribute(_value);
 };
 //BA.debugLineNum = 170;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 171;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addparagraph(String _scontent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _p = null;
 //BA.debugLineNum = 155;BA.debugLine="Sub AddParagraph(sContent As String) As UOEHTML";
 //BA.debugLineNum = 156;BA.debugLine="Dim p As UOEHTML";
_p = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 157;BA.debugLine="p.Initialize(\"\",\"p\")";
_p._initialize(ba,"","p");
 //BA.debugLineNum = 158;BA.debugLine="p.AddContent(sContent)";
_p._addcontent(_scontent);
 //BA.debugLineNum = 159;BA.debugLine="AddContent(p.HTML)";
_addcontent(_p._html());
 //BA.debugLineNum = 160;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addstyleattribute(String _sprop,String _svalue) throws Exception{
 //BA.debugLineNum = 1168;BA.debugLine="Sub AddStyleAttribute(sprop As String, svalue As S";
 //BA.debugLineNum = 1169;BA.debugLine="sprop = sprop.ToLowerCase";
_sprop = _sprop.toLowerCase();
 //BA.debugLineNum = 1170;BA.debugLine="sprop = sprop.Trim";
_sprop = _sprop.trim();
 //BA.debugLineNum = 1171;BA.debugLine="svalue = svalue.Trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 1173;BA.debugLine="sprop = RemDelim(sprop,\":\")";
_sprop = _remdelim(_sprop,":");
 //BA.debugLineNum = 1175;BA.debugLine="svalue = RemDelim(svalue,\";\")";
_svalue = _remdelim(_svalue,";");
 //BA.debugLineNum = 1176;BA.debugLine="sprop = sprop.Trim";
_sprop = _sprop.trim();
 //BA.debugLineNum = 1177;BA.debugLine="svalue = svalue.Trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 1178;BA.debugLine="If svalue.Length > 0 And sprop.Length > 0 Then";
if (_svalue.length()>0 && _sprop.length()>0) { 
 //BA.debugLineNum = 1180;BA.debugLine="If svalue.EndsWith(\"!important\") = False Then";
if (_svalue.endsWith("!important")==__c.False) { 
 //BA.debugLineNum = 1181;BA.debugLine="svalue = svalue & \" !important\"";
_svalue = _svalue+" !important";
 };
 //BA.debugLineNum = 1184;BA.debugLine="styles.Put(sprop, svalue)";
_styles.Put((Object)(_sprop),(Object)(_svalue));
 };
 //BA.debugLineNum = 1186;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1187;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addstyleattributeoncondition(boolean _bcondition,String _attr,String _value) throws Exception{
 //BA.debugLineNum = 406;BA.debugLine="Sub AddStyleAttributeOnCondition(bCondition As Boo";
 //BA.debugLineNum = 407;BA.debugLine="removeStyle(attr)";
_removestyle(_attr);
 //BA.debugLineNum = 408;BA.debugLine="If bCondition = True Then";
if (_bcondition==__c.True) { 
 //BA.debugLineNum = 409;BA.debugLine="AddStyleAttribute(attr,value)";
_addstyleattribute(_attr,_value);
 };
 //BA.debugLineNum = 411;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 412;BA.debugLine="End Sub";
return null;
}
public String  _buildattributes() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _strkey = "";
String _strvalue = "";
 //BA.debugLineNum = 1063;BA.debugLine="Sub BuildAttributes As String";
 //BA.debugLineNum = 1064;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 1065;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 1066;BA.debugLine="Dim kTot As Int = properties.Size - 1";
_ktot = (int) (_properties.getSize()-1);
 //BA.debugLineNum = 1067;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 1068;BA.debugLine="Dim strKey As String = properties.GetKeyAt(0)";
_strkey = BA.ObjectToString(_properties.GetKeyAt((int) (0)));
 //BA.debugLineNum = 1069;BA.debugLine="Dim strValue As String = properties.Get(strKey)";
_strvalue = BA.ObjectToString(_properties.Get((Object)(_strkey)));
 //BA.debugLineNum = 1070;BA.debugLine="If SingleQuote.IndexOf(strKey) = -1 Then";
if (_singlequote.IndexOf((Object)(_strkey))==-1) { 
 //BA.debugLineNum = 1071;BA.debugLine="sb.Append(ToProperty(strKey,strValue))";
_sb.Append(_toproperty(_strkey,_strvalue));
 }else {
 //BA.debugLineNum = 1073;BA.debugLine="sb.Append(ToSingleQuoteProperty(strKey,strValue)";
_sb.Append(_tosinglequoteproperty(_strkey,_strvalue));
 };
 //BA.debugLineNum = 1075;BA.debugLine="For kCnt = 1 To kTot";
{
final int step12 = 1;
final int limit12 = _ktot;
_kcnt = (int) (1) ;
for (;_kcnt <= limit12 ;_kcnt = _kcnt + step12 ) {
 //BA.debugLineNum = 1076;BA.debugLine="strKey = properties.GetKeyAt(kCnt)";
_strkey = BA.ObjectToString(_properties.GetKeyAt(_kcnt));
 //BA.debugLineNum = 1077;BA.debugLine="strValue = properties.Get(strKey)";
_strvalue = BA.ObjectToString(_properties.Get((Object)(_strkey)));
 //BA.debugLineNum = 1078;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 //BA.debugLineNum = 1079;BA.debugLine="If SingleQuote.IndexOf(strKey) = -1 Then";
if (_singlequote.IndexOf((Object)(_strkey))==-1) { 
 //BA.debugLineNum = 1080;BA.debugLine="sb.Append(ToProperty(strKey,strValue))";
_sb.Append(_toproperty(_strkey,_strvalue));
 }else {
 //BA.debugLineNum = 1082;BA.debugLine="sb.Append(ToSingleQuoteProperty(strKey,strValue";
_sb.Append(_tosinglequoteproperty(_strkey,_strvalue));
 };
 }
};
 //BA.debugLineNum = 1085;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 1086;BA.debugLine="End Sub";
return "";
}
public String  _buildclass() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _strclass = "";
 //BA.debugLineNum = 870;BA.debugLine="private Sub BuildClass() As String";
 //BA.debugLineNum = 871;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 872;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 873;BA.debugLine="Dim kTot As Int = classes.Size - 1";
_ktot = (int) (_classes.getSize()-1);
 //BA.debugLineNum = 874;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 875;BA.debugLine="Dim strClass As String  = classes.GetKeyAt(0)";
_strclass = BA.ObjectToString(_classes.GetKeyAt((int) (0)));
 //BA.debugLineNum = 876;BA.debugLine="sb.Append(strClass)";
_sb.Append(_strclass);
 //BA.debugLineNum = 877;BA.debugLine="For kCnt = 1 To kTot";
{
final int step7 = 1;
final int limit7 = _ktot;
_kcnt = (int) (1) ;
for (;_kcnt <= limit7 ;_kcnt = _kcnt + step7 ) {
 //BA.debugLineNum = 878;BA.debugLine="Dim strClass As String  = classes.GetKeyAt(kCnt)";
_strclass = BA.ObjectToString(_classes.GetKeyAt(_kcnt));
 //BA.debugLineNum = 879;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 //BA.debugLineNum = 880;BA.debugLine="sb.Append(strClass)";
_sb.Append(_strclass);
 }
};
 //BA.debugLineNum = 882;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 883;BA.debugLine="End Sub";
return "";
}
public String  _buildstyle() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _kcnt = 0;
int _ktot = 0;
String _strkey = "";
String _strvalue = "";
String _strline = "";
 //BA.debugLineNum = 902;BA.debugLine="private Sub BuildStyle() As String";
 //BA.debugLineNum = 903;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 904;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 905;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 906;BA.debugLine="Dim kTot As Int = styles.Size - 1";
_ktot = (int) (_styles.getSize()-1);
 //BA.debugLineNum = 908;BA.debugLine="Dim strKey As String = styles.GetKeyAt(0)";
_strkey = BA.ObjectToString(_styles.GetKeyAt((int) (0)));
 //BA.debugLineNum = 909;BA.debugLine="Dim strValue As String = styles.Get(strKey)";
_strvalue = BA.ObjectToString(_styles.Get((Object)(_strkey)));
 //BA.debugLineNum = 910;BA.debugLine="Dim strLine As String = ToStyle(strKey,strValue)";
_strline = _tostyle(_strkey,_strvalue);
 //BA.debugLineNum = 911;BA.debugLine="sb.Append(strLine)";
_sb.Append(_strline);
 //BA.debugLineNum = 912;BA.debugLine="For kCnt = 1 To kTot";
{
final int step9 = 1;
final int limit9 = _ktot;
_kcnt = (int) (1) ;
for (;_kcnt <= limit9 ;_kcnt = _kcnt + step9 ) {
 //BA.debugLineNum = 913;BA.debugLine="Dim strKey As String = styles.GetKeyAt(kCnt)";
_strkey = BA.ObjectToString(_styles.GetKeyAt(_kcnt));
 //BA.debugLineNum = 914;BA.debugLine="Dim strValue As String = styles.Get(strKey)";
_strvalue = BA.ObjectToString(_styles.Get((Object)(_strkey)));
 //BA.debugLineNum = 915;BA.debugLine="Dim strLine As String = ToStyle(strKey,strValue)";
_strline = _tostyle(_strkey,_strvalue);
 //BA.debugLineNum = 916;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 //BA.debugLineNum = 917;BA.debugLine="sb.Append(strLine)";
_sb.Append(_strline);
 }
};
 //BA.debugLineNum = 919;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 920;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Public Tag As String";
_tag = "";
 //BA.debugLineNum = 6;BA.debugLine="Private properties As Map";
_properties = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 7;BA.debugLine="Private Contents As List";
_contents = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 8;BA.debugLine="Private classes As Map";
_classes = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 9;BA.debugLine="Private styles As Map";
_styles = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 10;BA.debugLine="Private LooseAttributes As List";
_looseattributes = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 11;BA.debugLine="Private DontBreak As List";
_dontbreak = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 12;BA.debugLine="Private Prefix As String";
_prefix = "";
 //BA.debugLineNum = 13;BA.debugLine="Private DoAProperClose As Boolean";
_doaproperclose = false;
 //BA.debugLineNum = 14;BA.debugLine="Private Required As Boolean";
_required = false;
 //BA.debugLineNum = 15;BA.debugLine="Private Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 16;BA.debugLine="Private Inline As Boolean";
_inline = false;
 //BA.debugLineNum = 17;BA.debugLine="Private ReadOnly As Boolean";
_readonly = false;
 //BA.debugLineNum = 18;BA.debugLine="Private CSSRule As Map";
_cssrule = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 19;BA.debugLine="Private SingleQuote As List";
_singlequote = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 20;BA.debugLine="Private ParentID As String";
_parentid = "";
 //BA.debugLineNum = 21;BA.debugLine="Private Text As String";
_text = "";
 //BA.debugLineNum = 22;BA.debugLine="Private TextAfter As Boolean";
_textafter = false;
 //BA.debugLineNum = 23;BA.debugLine="Private divider As String";
_divider = "";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public boolean  _classexists(String _value) throws Exception{
 //BA.debugLineNum = 475;BA.debugLine="Sub ClassExists(value As String) As Boolean";
 //BA.debugLineNum = 476;BA.debugLine="value = value.trim";
_value = _value.trim();
 //BA.debugLineNum = 477;BA.debugLine="If value.Length > 0 Then";
if (_value.length()>0) { 
 //BA.debugLineNum = 478;BA.debugLine="Return classes.ContainsKey(value)";
if (true) return _classes.ContainsKey((Object)(_value));
 };
 //BA.debugLineNum = 480;BA.debugLine="Return False";
if (true) return __c.False;
 //BA.debugLineNum = 481;BA.debugLine="End Sub";
return false;
}
public String  _close() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 1290;BA.debugLine="private Sub Close() As String";
 //BA.debugLineNum = 1291;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 1292;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 1293;BA.debugLine="Select Case Tag.ToLowerCase";
switch (BA.switchObjectToInt(_tag.toLowerCase(),"img","link","meta","input","source","hr","br")) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: 
case 5: 
case 6: {
 //BA.debugLineNum = 1295;BA.debugLine="DoAProperClose = False";
_doaproperclose = __c.False;
 break; }
}
;
 //BA.debugLineNum = 1297;BA.debugLine="If DoAProperClose = True Then";
if (_doaproperclose==__c.True) { 
 //BA.debugLineNum = 1298;BA.debugLine="sb.Append(\"</\")";
_sb.Append("</");
 //BA.debugLineNum = 1299;BA.debugLine="sb.Append(Tag)";
_sb.Append(_tag);
 //BA.debugLineNum = 1300;BA.debugLine="sb.Append(\">\")";
_sb.Append(">");
 };
 //BA.debugLineNum = 1302;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 //BA.debugLineNum = 1303;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 1304;BA.debugLine="End Sub";
return "";
}
public String  _cstr(Object _o) throws Exception{
 //BA.debugLineNum = 831;BA.debugLine="private Sub CStr(o As Object) As String";
 //BA.debugLineNum = 832;BA.debugLine="Return \"\" & o";
if (true) return ""+BA.ObjectToString(_o);
 //BA.debugLineNum = 833;BA.debugLine="End Sub";
return "";
}
public String  _formattext(String _stext) throws Exception{
anywheresoftware.b4a.objects.collections.Map _rm = null;
int _ktot = 0;
int _kcnt = 0;
String _strvalue = "";
String _strrep = "";
 //BA.debugLineNum = 1099;BA.debugLine="private Sub FormatText(sText As String) As String";
 //BA.debugLineNum = 1100;BA.debugLine="Dim RM As Map";
_rm = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 1101;BA.debugLine="RM.Initialize";
_rm.Initialize();
 //BA.debugLineNum = 1102;BA.debugLine="RM.clear";
_rm.Clear();
 //BA.debugLineNum = 1103;BA.debugLine="RM.Put(\"{U}\", \"<ins>\")";
_rm.Put((Object)("{U}"),(Object)("<ins>"));
 //BA.debugLineNum = 1104;BA.debugLine="RM.Put(\"{/U}\", \"</ins>\")";
_rm.Put((Object)("{/U}"),(Object)("</ins>"));
 //BA.debugLineNum = 1105;BA.debugLine="RM.Put(\"¢\",\"&cent;\")";
_rm.Put((Object)("¢"),(Object)("&cent;"));
 //BA.debugLineNum = 1106;BA.debugLine="RM.put(\"£\",\"&pound;\")";
_rm.Put((Object)("£"),(Object)("&pound;"));
 //BA.debugLineNum = 1107;BA.debugLine="RM.Put(\"{SUP}\", \"<sup>\")";
_rm.Put((Object)("{SUP}"),(Object)("<sup>"));
 //BA.debugLineNum = 1108;BA.debugLine="RM.Put(\"{/SUP}\", \"</sup>\")";
_rm.Put((Object)("{/SUP}"),(Object)("</sup>"));
 //BA.debugLineNum = 1109;BA.debugLine="RM.Put(\"¥\",\"&yen;\")";
_rm.Put((Object)("¥"),(Object)("&yen;"));
 //BA.debugLineNum = 1110;BA.debugLine="RM.Put(\"€\",\"&euro;\")";
_rm.Put((Object)("€"),(Object)("&euro;"));
 //BA.debugLineNum = 1111;BA.debugLine="RM.put(\"©\",\"&copy;\")";
_rm.Put((Object)("©"),(Object)("&copy;"));
 //BA.debugLineNum = 1112;BA.debugLine="RM.Put(\"®\",\"&reg;\")";
_rm.Put((Object)("®"),(Object)("&reg;"));
 //BA.debugLineNum = 1113;BA.debugLine="RM.Put(\"{POUND}\",\"&pound;\")";
_rm.Put((Object)("{POUND}"),(Object)("&pound;"));
 //BA.debugLineNum = 1114;BA.debugLine="RM.Put(\"{/B}\", \"</b>\")";
_rm.Put((Object)("{/B}"),(Object)("</b>"));
 //BA.debugLineNum = 1115;BA.debugLine="RM.Put(\"{I}\", \"<i>\")";
_rm.Put((Object)("{I}"),(Object)("<i>"));
 //BA.debugLineNum = 1116;BA.debugLine="RM.Put(\"{YEN}\",\"&yen;\")";
_rm.Put((Object)("{YEN}"),(Object)("&yen;"));
 //BA.debugLineNum = 1117;BA.debugLine="RM.Put(\"{EURO}\",\"&euro;\")";
_rm.Put((Object)("{EURO}"),(Object)("&euro;"));
 //BA.debugLineNum = 1118;BA.debugLine="RM.Put(\"{CODE}\",\"<code>\")";
_rm.Put((Object)("{CODE}"),(Object)("<code>"));
 //BA.debugLineNum = 1119;BA.debugLine="RM.Put(\"{/CODE}\",\"</code>\")";
_rm.Put((Object)("{/CODE}"),(Object)("</code>"));
 //BA.debugLineNum = 1120;BA.debugLine="RM.put(\"{COPYRIGHT}\",\"&copy;\")";
_rm.Put((Object)("{COPYRIGHT}"),(Object)("&copy;"));
 //BA.debugLineNum = 1121;BA.debugLine="RM.Put(\"{REGISTERED}\",\"&reg;\")";
_rm.Put((Object)("{REGISTERED}"),(Object)("&reg;"));
 //BA.debugLineNum = 1122;BA.debugLine="RM.Put(\"®\", \"&reg;\")";
_rm.Put((Object)("®"),(Object)("&reg;"));
 //BA.debugLineNum = 1123;BA.debugLine="RM.Put(\"{B}\", \"<b>\")";
_rm.Put((Object)("{B}"),(Object)("<b>"));
 //BA.debugLineNum = 1124;BA.debugLine="RM.Put(\"{SMALL}\", \"<small>\")";
_rm.Put((Object)("{SMALL}"),(Object)("<small>"));
 //BA.debugLineNum = 1125;BA.debugLine="RM.Put(\"{/SMALL}\", \"</small>\")";
_rm.Put((Object)("{/SMALL}"),(Object)("</small>"));
 //BA.debugLineNum = 1126;BA.debugLine="RM.Put(\"{EM}\", \"<em>\")";
_rm.Put((Object)("{EM}"),(Object)("<em>"));
 //BA.debugLineNum = 1127;BA.debugLine="RM.Put(\"{/EM}\", \"</em>\")";
_rm.Put((Object)("{/EM}"),(Object)("</em>"));
 //BA.debugLineNum = 1128;BA.debugLine="RM.Put(\"{MARK}\", \"<mark>\")";
_rm.Put((Object)("{MARK}"),(Object)("<mark>"));
 //BA.debugLineNum = 1129;BA.debugLine="RM.Put(\"{/MARK}\", \"</mark>\")";
_rm.Put((Object)("{/MARK}"),(Object)("</mark>"));
 //BA.debugLineNum = 1130;BA.debugLine="RM.Put(\"{/I}\", \"</i>\")";
_rm.Put((Object)("{/I}"),(Object)("</i>"));
 //BA.debugLineNum = 1131;BA.debugLine="RM.Put(\"{SUB}\", \"<sub>\")";
_rm.Put((Object)("{SUB}"),(Object)("<sub>"));
 //BA.debugLineNum = 1132;BA.debugLine="RM.Put(\"{/SUB}\", \"</sub>\")";
_rm.Put((Object)("{/SUB}"),(Object)("</sub>"));
 //BA.debugLineNum = 1133;BA.debugLine="RM.Put(\"{BR}\", \"<br/>\")";
_rm.Put((Object)("{BR}"),(Object)("<br/>"));
 //BA.debugLineNum = 1134;BA.debugLine="RM.Put(\"{WBR}\",\"<wbr>\")";
_rm.Put((Object)("{WBR}"),(Object)("<wbr>"));
 //BA.debugLineNum = 1135;BA.debugLine="RM.Put(\"{STRONG}\", \"<strong>\")";
_rm.Put((Object)("{STRONG}"),(Object)("<strong>"));
 //BA.debugLineNum = 1136;BA.debugLine="RM.Put(\"{/STRONG}\", \"</strong>\")";
_rm.Put((Object)("{/STRONG}"),(Object)("</strong>"));
 //BA.debugLineNum = 1137;BA.debugLine="RM.Put(\"{NBSP}\", \"&nbsp;\")";
_rm.Put((Object)("{NBSP}"),(Object)("&nbsp;"));
 //BA.debugLineNum = 1138;BA.debugLine="RM.Put(\"“\",\"\")";
_rm.Put((Object)("“"),(Object)(""));
 //BA.debugLineNum = 1139;BA.debugLine="RM.Put(\"”\",\"\")";
_rm.Put((Object)("”"),(Object)(""));
 //BA.debugLineNum = 1140;BA.debugLine="RM.Put(\"’\",\"'\")";
_rm.Put((Object)("’"),(Object)("'"));
 //BA.debugLineNum = 1141;BA.debugLine="Dim kTot As Int = RM.Size - 1";
_ktot = (int) (_rm.getSize()-1);
 //BA.debugLineNum = 1142;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 1143;BA.debugLine="For kCnt = 0 To kTot";
{
final int step44 = 1;
final int limit44 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit44 ;_kcnt = _kcnt + step44 ) {
 //BA.debugLineNum = 1144;BA.debugLine="Dim strValue As String = RM.GetKeyAt(kCnt)";
_strvalue = BA.ObjectToString(_rm.GetKeyAt(_kcnt));
 //BA.debugLineNum = 1145;BA.debugLine="Dim strRep As String = RM.Get(strValue)";
_strrep = BA.ObjectToString(_rm.Get((Object)(_strvalue)));
 //BA.debugLineNum = 1146;BA.debugLine="sText = sText.Replace(strValue, strRep)";
_stext = _stext.replace(_strvalue,_strrep);
 }
};
 //BA.debugLineNum = 1148;BA.debugLine="Return sText";
if (true) return _stext;
 //BA.debugLineNum = 1149;BA.debugLine="End Sub";
return "";
}
public String  _getattr(String _attr) throws Exception{
 //BA.debugLineNum = 1307;BA.debugLine="Sub GetAttr(attr As String) As String";
 //BA.debugLineNum = 1308;BA.debugLine="attr = attr.tolowercase";
_attr = _attr.toLowerCase();
 //BA.debugLineNum = 1309;BA.debugLine="If properties.ContainsKey(attr) Then";
if (_properties.ContainsKey((Object)(_attr))) { 
 //BA.debugLineNum = 1310;BA.debugLine="Return properties.Get(attr)";
if (true) return BA.ObjectToString(_properties.Get((Object)(_attr)));
 }else {
 //BA.debugLineNum = 1312;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 1314;BA.debugLine="End Sub";
return "";
}
public String  _getattribute(String _attr) throws Exception{
 //BA.debugLineNum = 465;BA.debugLine="Sub GetAttribute(attr As String) As String";
 //BA.debugLineNum = 466;BA.debugLine="attr = attr.tolowercase";
_attr = _attr.toLowerCase();
 //BA.debugLineNum = 467;BA.debugLine="If properties.ContainsKey(attr) Then";
if (_properties.ContainsKey((Object)(_attr))) { 
 //BA.debugLineNum = 468;BA.debugLine="Return properties.Get(attr)";
if (true) return BA.ObjectToString(_properties.Get((Object)(_attr)));
 }else {
 //BA.debugLineNum = 470;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 472;BA.debugLine="End Sub";
return "";
}
public String  _getcomponentbuilder() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _sout = "";
 //BA.debugLineNum = 772;BA.debugLine="private Sub GetComponentBuilder() As String";
 //BA.debugLineNum = 773;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 774;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 775;BA.debugLine="If Prefix.Length > 0 Then";
if (_prefix.length()>0) { 
 //BA.debugLineNum = 776;BA.debugLine="sb.Append(Prefix)";
_sb.Append(_prefix);
 //BA.debugLineNum = 777;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 };
 //BA.debugLineNum = 779;BA.debugLine="sb.Append(\"<\")";
_sb.Append("<");
 //BA.debugLineNum = 780;BA.debugLine="sb.Append(Tag)";
_sb.Append(_tag);
 //BA.debugLineNum = 781;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 //BA.debugLineNum = 782;BA.debugLine="If ID.Length > 0 Then";
if (_id.length()>0) { 
 //BA.debugLineNum = 783;BA.debugLine="sb.Append(ToProperty(\"id\",ID))";
_sb.Append(_toproperty("id",_id));
 };
 //BA.debugLineNum = 785;BA.debugLine="sb.Append(\">\")";
_sb.Append(">");
 //BA.debugLineNum = 786;BA.debugLine="Select Case Tag.ToLowerCase";
switch (BA.switchObjectToInt(_tag.toLowerCase(),"img","link","meta","input","source")) {
case 0: 
case 1: 
case 2: 
case 3: 
case 4: {
 //BA.debugLineNum = 788;BA.debugLine="DoAProperClose = False";
_doaproperclose = __c.False;
 break; }
}
;
 //BA.debugLineNum = 790;BA.debugLine="If DoAProperClose = True Then";
if (_doaproperclose==__c.True) { 
 //BA.debugLineNum = 791;BA.debugLine="sb.Append(\"</\")";
_sb.Append("</");
 //BA.debugLineNum = 792;BA.debugLine="sb.Append(Tag)";
_sb.Append(_tag);
 //BA.debugLineNum = 793;BA.debugLine="sb.Append(\">\")";
_sb.Append(">");
 };
 //BA.debugLineNum = 795;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 //BA.debugLineNum = 796;BA.debugLine="Dim sout As String = sb.tostring";
_sout = _sb.ToString();
 //BA.debugLineNum = 797;BA.debugLine="sout = sout.Trim";
_sout = _sout.trim();
 //BA.debugLineNum = 798;BA.debugLine="Return sout";
if (true) return _sout;
 //BA.debugLineNum = 799;BA.debugLine="End Sub";
return "";
}
public String  _getstyleattribute(String _attr) throws Exception{
boolean _hasitem = false;
 //BA.debugLineNum = 27;BA.debugLine="Sub GetStyleAttribute(attr As String) As String";
 //BA.debugLineNum = 28;BA.debugLine="attr = attr.ToLowerCase";
_attr = _attr.toLowerCase();
 //BA.debugLineNum = 29;BA.debugLine="attr = RemDelim(attr,\":\")";
_attr = _remdelim(_attr,":");
 //BA.debugLineNum = 30;BA.debugLine="attr = attr.trim";
_attr = _attr.trim();
 //BA.debugLineNum = 31;BA.debugLine="Dim hasItem As Boolean = styles.ContainsKey(attr)";
_hasitem = _styles.ContainsKey((Object)(_attr));
 //BA.debugLineNum = 32;BA.debugLine="If hasItem Then";
if (_hasitem) { 
 //BA.debugLineNum = 33;BA.debugLine="Return styles.Get(attr)";
if (true) return BA.ObjectToString(_styles.Get((Object)(_attr)));
 }else {
 //BA.debugLineNum = 35;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _html() throws Exception{
String _sout = "";
 //BA.debugLineNum = 485;BA.debugLine="public Sub HTML As String";
 //BA.debugLineNum = 486;BA.debugLine="Dim sOut As String = ToString";
_sout = _tostring();
 //BA.debugLineNum = 487;BA.debugLine="Return sOut";
if (true) return _sout;
 //BA.debugLineNum = 488;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _elid,String _eltag) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 672;BA.debugLine="Public Sub Initialize(elID As String, eltag As Str";
 //BA.debugLineNum = 673;BA.debugLine="ID = elID.ToLowerCase";
_id = _elid.toLowerCase();
 //BA.debugLineNum = 674;BA.debugLine="properties.Initialize";
_properties.Initialize();
 //BA.debugLineNum = 675;BA.debugLine="properties.clear";
_properties.Clear();
 //BA.debugLineNum = 676;BA.debugLine="Contents.Initialize";
_contents.Initialize();
 //BA.debugLineNum = 677;BA.debugLine="Contents.clear";
_contents.Clear();
 //BA.debugLineNum = 678;BA.debugLine="styles.Initialize";
_styles.Initialize();
 //BA.debugLineNum = 679;BA.debugLine="styles.clear";
_styles.Clear();
 //BA.debugLineNum = 680;BA.debugLine="classes.Initialize";
_classes.Initialize();
 //BA.debugLineNum = 681;BA.debugLine="classes.clear";
_classes.Clear();
 //BA.debugLineNum = 682;BA.debugLine="LooseAttributes.Initialize";
_looseattributes.Initialize();
 //BA.debugLineNum = 683;BA.debugLine="LooseAttributes.clear";
_looseattributes.Clear();
 //BA.debugLineNum = 684;BA.debugLine="ParentID = \"\"";
_parentid = "";
 //BA.debugLineNum = 685;BA.debugLine="DontBreak.Initialize";
_dontbreak.Initialize();
 //BA.debugLineNum = 686;BA.debugLine="DontBreak.clear";
_dontbreak.Clear();
 //BA.debugLineNum = 687;BA.debugLine="DontBreak.Add(\"li\")";
_dontbreak.Add((Object)("li"));
 //BA.debugLineNum = 688;BA.debugLine="DontBreak.Add(\"a\")";
_dontbreak.Add((Object)("a"));
 //BA.debugLineNum = 689;BA.debugLine="DontBreak.Add(\"i\")";
_dontbreak.Add((Object)("i"));
 //BA.debugLineNum = 690;BA.debugLine="DontBreak.Add(\"span\")";
_dontbreak.Add((Object)("span"));
 //BA.debugLineNum = 691;BA.debugLine="DontBreak.Add(\"img\")";
_dontbreak.Add((Object)("img"));
 //BA.debugLineNum = 692;BA.debugLine="Tag = eltag";
_tag = _eltag;
 //BA.debugLineNum = 693;BA.debugLine="Prefix = \"\"";
_prefix = "";
 //BA.debugLineNum = 694;BA.debugLine="DoAProperClose = True";
_doaproperclose = __c.True;
 //BA.debugLineNum = 695;BA.debugLine="Required = False";
_required = __c.False;
 //BA.debugLineNum = 696;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 697;BA.debugLine="Inline = False";
_inline = __c.False;
 //BA.debugLineNum = 698;BA.debugLine="ReadOnly = False";
_readonly = __c.False;
 //BA.debugLineNum = 699;BA.debugLine="CSSRule.Initialize";
_cssrule.Initialize();
 //BA.debugLineNum = 700;BA.debugLine="CSSRule.clear";
_cssrule.Clear();
 //BA.debugLineNum = 701;BA.debugLine="SingleQuote.Initialize";
_singlequote.Initialize();
 //BA.debugLineNum = 702;BA.debugLine="SingleQuote.clear";
_singlequote.Clear();
 //BA.debugLineNum = 703;BA.debugLine="Text = \"\"";
_text = "";
 //BA.debugLineNum = 704;BA.debugLine="TextAfter = False";
_textafter = __c.False;
 //BA.debugLineNum = 705;BA.debugLine="End Sub";
return "";
}
public String  _makepx(String _svalue) throws Exception{
boolean _endp = false;
boolean _endpx = false;
 //BA.debugLineNum = 282;BA.debugLine="Sub MakePx(sValue As String) As String";
 //BA.debugLineNum = 283;BA.debugLine="Dim endp As Boolean = sValue.EndsWith(\"%\")";
_endp = _svalue.endsWith("%");
 //BA.debugLineNum = 284;BA.debugLine="If endp Then";
if (_endp) { 
 //BA.debugLineNum = 285;BA.debugLine="Return sValue";
if (true) return _svalue;
 }else {
 //BA.debugLineNum = 287;BA.debugLine="Dim endpx As Boolean = sValue.EndsWith(\"px\")";
_endpx = _svalue.endsWith("px");
 //BA.debugLineNum = 288;BA.debugLine="If endpx Then";
if (_endpx) { 
 //BA.debugLineNum = 289;BA.debugLine="Return sValue";
if (true) return _svalue;
 }else {
 //BA.debugLineNum = 291;BA.debugLine="sValue = sValue.Trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 292;BA.debugLine="sValue = sValue.Replace(\"px\",\"\")";
_svalue = _svalue.replace("px","");
 //BA.debugLineNum = 293;BA.debugLine="sValue = $\"${sValue}px\"$";
_svalue = (""+__c.SmartStringFormatter("",(Object)(_svalue))+"px");
 //BA.debugLineNum = 294;BA.debugLine="If sValue = \"px\" Then";
if ((_svalue).equals("px")) { 
 //BA.debugLineNum = 295;BA.debugLine="sValue = \"\"";
_svalue = "";
 };
 //BA.debugLineNum = 297;BA.debugLine="Return sValue";
if (true) return _svalue;
 };
 };
 //BA.debugLineNum = 300;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoehtml  _materialadddivider(String _svisibility,String _themename) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
 //BA.debugLineNum = 77;BA.debugLine="Sub MaterialAddDivider(sVisibility As String, them";
 //BA.debugLineNum = 78;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 79;BA.debugLine="li.Initialize(\"\",\"li\")";
_li._initialize(ba,"","li");
 //BA.debugLineNum = 80;BA.debugLine="li.AddClass(\"divider\")";
_li._addclass("divider");
 //BA.debugLineNum = 81;BA.debugLine="li.MaterialVisibility(sVisibility)";
_li._materialvisibility(_svisibility);
 //BA.debugLineNum = 82;BA.debugLine="divider = li.html";
_divider = _li._html();
 //BA.debugLineNum = 83;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialadddivideroncondition(boolean _bstatus,String _svisibility,String _themename) throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub MaterialAddDividerOnCondition(bStatus As Boole";
 //BA.debugLineNum = 88;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 89;BA.debugLine="MaterialAddDivider(sVisibility,themeName)";
_materialadddivider(_svisibility,_themename);
 };
 //BA.debugLineNum = 91;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialaligntext(String _salignment) throws Exception{
 //BA.debugLineNum = 1432;BA.debugLine="Sub MaterialAlignText(sAlignment As String) As UOE";
 //BA.debugLineNum = 1433;BA.debugLine="If sAlignment.Length > 0 Then";
if (_salignment.length()>0) { 
 //BA.debugLineNum = 1434;BA.debugLine="removeClass(\"center-align\")";
_removeclass("center-align");
 //BA.debugLineNum = 1435;BA.debugLine="removeClass(\"right-align\")";
_removeclass("right-align");
 //BA.debugLineNum = 1436;BA.debugLine="removeClass(\"left-align\")";
_removeclass("left-align");
 //BA.debugLineNum = 1437;BA.debugLine="addClass(sAlignment)";
_addclass(_salignment);
 };
 //BA.debugLineNum = 1439;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1440;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialavatar(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 193;BA.debugLine="Sub MaterialAvatar(bStatus As Boolean) As UOEHTML";
 //BA.debugLineNum = 194;BA.debugLine="AddClassOnCondition(bStatus,\"avatar\")";
_addclassoncondition(_bstatus,"avatar");
 //BA.debugLineNum = 195;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialboxed(String _bstatus) throws Exception{
 //BA.debugLineNum = 335;BA.debugLine="Sub MaterialBoxed(bStatus As String) As UOEHTML";
 //BA.debugLineNum = 336;BA.debugLine="AddClassOnCondition(bStatus,\"materialboxed\")";
_addclassoncondition(BA.ObjectToBoolean(_bstatus),"materialboxed");
 //BA.debugLineNum = 337;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 338;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialbuildicon(String _iconname,String _iconpos) throws Exception{
boolean _sw = false;
 //BA.debugLineNum = 962;BA.debugLine="public Sub MaterialBuildIcon(iconName As String, i";
 //BA.debugLineNum = 963;BA.debugLine="iconName = iconName.tolowercase";
_iconname = _iconname.toLowerCase();
 //BA.debugLineNum = 964;BA.debugLine="Dim sw As Boolean";
_sw = false;
 //BA.debugLineNum = 965;BA.debugLine="sw = iconName.StartsWith(\"mdi-\")";
_sw = _iconname.startsWith("mdi-");
 //BA.debugLineNum = 966;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 967;BA.debugLine="addClass(\"material-icons\")";
_addclass("material-icons");
 //BA.debugLineNum = 968;BA.debugLine="iconName = MvFieldFrom(iconName,2,\"-\")";
_iconname = _mvfieldfrom(_iconname,(int) (2),"-");
 //BA.debugLineNum = 969;BA.debugLine="iconName = iconName.Replace(\"-\",\"_\")";
_iconname = _iconname.replace("-","_");
 //BA.debugLineNum = 970;BA.debugLine="AddContent(iconName)";
_addcontent(_iconname);
 //BA.debugLineNum = 971;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 972;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 974;BA.debugLine="sw = iconName.startswith(\"ggle-\")";
_sw = _iconname.startsWith("ggle-");
 //BA.debugLineNum = 975;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 976;BA.debugLine="iconName = MvFieldFrom(iconName,2,\"-\")";
_iconname = _mvfieldfrom(_iconname,(int) (2),"-");
 //BA.debugLineNum = 977;BA.debugLine="AddContent(iconName)";
_addcontent(_iconname);
 //BA.debugLineNum = 978;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 979;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 981;BA.debugLine="sw = iconName.StartsWith(\"fa-\")";
_sw = _iconname.startsWith("fa-");
 //BA.debugLineNum = 982;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 983;BA.debugLine="addClass(\"fa \" & iconName)";
_addclass("fa "+_iconname);
 //BA.debugLineNum = 984;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 985;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 987;BA.debugLine="sw = iconName.StartsWith(\"fa fa-\")";
_sw = _iconname.startsWith("fa fa-");
 //BA.debugLineNum = 988;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 989;BA.debugLine="addClass(iconName)";
_addclass(_iconname);
 //BA.debugLineNum = 990;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 991;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 993;BA.debugLine="sw = iconName.StartsWith(\"fa \")";
_sw = _iconname.startsWith("fa ");
 //BA.debugLineNum = 994;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 995;BA.debugLine="addClass(iconName)";
_addclass(_iconname);
 //BA.debugLineNum = 996;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 997;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 };
 //BA.debugLineNum = 999;BA.debugLine="addClass(iconName)";
_addclass(_iconname);
 //BA.debugLineNum = 1000;BA.debugLine="If iconPos.Length > 0 Then addClass(iconPos)";
if (_iconpos.length()>0) { 
_addclass(_iconpos);};
 //BA.debugLineNum = 1001;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1002;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialbutton(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Sub MaterialButton(bStatus As Boolean) As UOEHTML";
 //BA.debugLineNum = 96;BA.debugLine="AddClassOnCondition(bStatus,\"btn\")";
_addclassoncondition(_bstatus,"btn");
 //BA.debugLineNum = 97;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialbuttonfloating(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 435;BA.debugLine="Sub MaterialButtonFloating(bStatus As Boolean) As";
 //BA.debugLineNum = 436;BA.debugLine="If bStatus Then";
if (_bstatus) { 
 //BA.debugLineNum = 437;BA.debugLine="removeClass(\"fixed-action-btn\")";
_removeclass("fixed-action-btn");
 //BA.debugLineNum = 438;BA.debugLine="removeClass(\"btn-flat\")";
_removeclass("btn-flat");
 //BA.debugLineNum = 439;BA.debugLine="removeClass(\"btn-raised\")";
_removeclass("btn-raised");
 //BA.debugLineNum = 440;BA.debugLine="removeClass(\"halfway-fab\")";
_removeclass("halfway-fab");
 //BA.debugLineNum = 441;BA.debugLine="AddClassOnCondition(bStatus,\"btn-floating\")";
_addclassoncondition(_bstatus,"btn-floating");
 };
 //BA.debugLineNum = 443;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 444;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialbuttonsize(String _ssize) throws Exception{
 //BA.debugLineNum = 423;BA.debugLine="Sub MaterialButtonSize(sSize As String) As UOEHTML";
 //BA.debugLineNum = 424;BA.debugLine="If sSize.Length > 0 Then";
if (_ssize.length()>0) { 
 //BA.debugLineNum = 425;BA.debugLine="removeClass(\"btn-small\")";
_removeclass("btn-small");
 //BA.debugLineNum = 426;BA.debugLine="removeClass(\"btn-large\")";
_removeclass("btn-large");
 //BA.debugLineNum = 427;BA.debugLine="removeClass(\"btn-medium\")";
_removeclass("btn-medium");
 //BA.debugLineNum = 428;BA.debugLine="addClass(sSize)";
_addclass(_ssize);
 //BA.debugLineNum = 429;BA.debugLine="addClass(\"btn\")";
_addclass("btn");
 };
 //BA.debugLineNum = 431;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 432;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialbuttontype(String _btntype) throws Exception{
 //BA.debugLineNum = 453;BA.debugLine="Sub MaterialButtonType(btnType As String) As UOEHT";
 //BA.debugLineNum = 454;BA.debugLine="If btnType.Length > 0 Then";
if (_btntype.length()>0) { 
 //BA.debugLineNum = 455;BA.debugLine="removeClass(\"fixed-action-btn\")";
_removeclass("fixed-action-btn");
 //BA.debugLineNum = 456;BA.debugLine="removeClass(\"btn-flat\")";
_removeclass("btn-flat");
 //BA.debugLineNum = 457;BA.debugLine="removeClass(\"btn-raised\")";
_removeclass("btn-raised");
 //BA.debugLineNum = 458;BA.debugLine="removeClass(\"halfway-fab\")";
_removeclass("halfway-fab");
 //BA.debugLineNum = 459;BA.debugLine="removeClass(\"btn-floating\")";
_removeclass("btn-floating");
 //BA.debugLineNum = 460;BA.debugLine="addClass(btnType)";
_addclass(_btntype);
 };
 //BA.debugLineNum = 462;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 463;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialcenteraligntext(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1412;BA.debugLine="Sub MaterialCenterAlignText(bStatus As Boolean) As";
 //BA.debugLineNum = 1413;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 1414;BA.debugLine="removeClass(\"center-align\")";
_removeclass("center-align");
 //BA.debugLineNum = 1415;BA.debugLine="removeClass(\"right-align\")";
_removeclass("right-align");
 //BA.debugLineNum = 1416;BA.debugLine="removeClass(\"left-align\")";
_removeclass("left-align");
 //BA.debugLineNum = 1417;BA.debugLine="addClass(\"center-align\")";
_addclass("center-align");
 };
 //BA.debugLineNum = 1419;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1420;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialcircle(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 368;BA.debugLine="Sub MaterialCircle(bStatus As Boolean) As UOEHTML";
 //BA.debugLineNum = 369;BA.debugLine="AddClassOnCondition(bStatus,\"circle\")";
_addclassoncondition(_bstatus,"circle");
 //BA.debugLineNum = 370;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 371;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialclick2toggle(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 401;BA.debugLine="Sub MaterialClick2Toggle(bStatus As Boolean) As UO";
 //BA.debugLineNum = 402;BA.debugLine="AddClassOnCondition(bStatus,\"click-to-toggle\")";
_addclassoncondition(_bstatus,"click-to-toggle");
 //BA.debugLineNum = 403;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 404;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialclose(String _bstatus) throws Exception{
 //BA.debugLineNum = 1004;BA.debugLine="Sub MaterialClose(bStatus As String) As UOEHTML";
 //BA.debugLineNum = 1005;BA.debugLine="AddClassOnCondition(bStatus,\"close\")";
_addclassoncondition(BA.ObjectToBoolean(_bstatus),"close");
 //BA.debugLineNum = 1006;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1007;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialcollapsibleheader(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 209;BA.debugLine="Sub MaterialCollapsibleHeader(bStatus As Boolean)";
 //BA.debugLineNum = 210;BA.debugLine="AddClassOnCondition(bStatus,\"collapsible-header\")";
_addclassoncondition(_bstatus,"collapsible-header");
 //BA.debugLineNum = 211;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 212;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialcollectionheader(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 203;BA.debugLine="Sub MaterialCollectionHeader(bStatus As Boolean) A";
 //BA.debugLineNum = 204;BA.debugLine="AddClassOnCondition(bStatus,\"collection-header\")";
_addclassoncondition(_bstatus,"collection-header");
 //BA.debugLineNum = 205;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 206;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialcollectionitem(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 182;BA.debugLine="Sub MaterialCollectionItem(bStatus As Boolean) As";
 //BA.debugLineNum = 183;BA.debugLine="AddClassOnCondition(bStatus,\"collection-item\")";
_addclassoncondition(_bstatus,"collection-item");
 //BA.debugLineNum = 184;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialenable(boolean _benabled) throws Exception{
 //BA.debugLineNum = 714;BA.debugLine="Sub MaterialEnable(bEnabled As Boolean) As UOEHTML";
 //BA.debugLineNum = 715;BA.debugLine="Enabled = bEnabled";
_enabled = _benabled;
 //BA.debugLineNum = 716;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 717;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialfloatleft(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1368;BA.debugLine="Sub MaterialFloatLeft(bStatus As Boolean) As UOEHT";
 //BA.debugLineNum = 1369;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 1370;BA.debugLine="removeClass(\"right\")";
_removeclass("right");
 //BA.debugLineNum = 1371;BA.debugLine="removeClass(\"left\")";
_removeclass("left");
 //BA.debugLineNum = 1372;BA.debugLine="addClass(\"left\")";
_addclass("left");
 };
 //BA.debugLineNum = 1374;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1375;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialfloatright(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1383;BA.debugLine="Sub MaterialFloatRight(bStatus As Boolean) As UOEH";
 //BA.debugLineNum = 1384;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 1385;BA.debugLine="removeClass(\"left\")";
_removeclass("left");
 //BA.debugLineNum = 1386;BA.debugLine="removeClass(\"right\")";
_removeclass("right");
 //BA.debugLineNum = 1387;BA.debugLine="addClass(\"right\")";
_addclass("right");
 };
 //BA.debugLineNum = 1389;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1390;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialflowtext(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1377;BA.debugLine="Sub MaterialFlowText(bStatus As Boolean) As UOEHTM";
 //BA.debugLineNum = 1378;BA.debugLine="AddClassOnCondition(bStatus,\"flow-text\")";
_addclassoncondition(_bstatus,"flow-text");
 //BA.debugLineNum = 1379;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1380;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialhorizontal(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 396;BA.debugLine="Sub MaterialHorizontal(bStatus As Boolean) As UOEH";
 //BA.debugLineNum = 397;BA.debugLine="AddClassOnCondition(bStatus,\"horizontal\")";
_addclassoncondition(_bstatus,"horizontal");
 //BA.debugLineNum = 398;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 399;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialhoverable(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1358;BA.debugLine="Sub MaterialHoverable(bStatus As Boolean) As UOEHT";
 //BA.debugLineNum = 1359;BA.debugLine="AddClassOnCondition(bStatus,\"hoverable\")";
_addclassoncondition(_bstatus,"hoverable");
 //BA.debugLineNum = 1360;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1361;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialiconsize(String _ssize) throws Exception{
 //BA.debugLineNum = 1009;BA.debugLine="Sub MaterialIconSize(sSize As String) As UOEHTML";
 //BA.debugLineNum = 1010;BA.debugLine="If sSize.Length > 0 Then";
if (_ssize.length()>0) { 
 //BA.debugLineNum = 1011;BA.debugLine="removeClass(\"large\")";
_removeclass("large");
 //BA.debugLineNum = 1012;BA.debugLine="removeClass(\"tiny\")";
_removeclass("tiny");
 //BA.debugLineNum = 1013;BA.debugLine="removeClass(\"small\")";
_removeclass("small");
 //BA.debugLineNum = 1014;BA.debugLine="removeClass(\"medium\")";
_removeclass("medium");
 //BA.debugLineNum = 1015;BA.debugLine="addClass(sSize)";
_addclass(_ssize);
 };
 //BA.debugLineNum = 1017;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1018;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialinline(boolean _binline) throws Exception{
 //BA.debugLineNum = 724;BA.debugLine="Sub MaterialInline(bInline As Boolean) As UOEHTML";
 //BA.debugLineNum = 725;BA.debugLine="Inline = bInline";
_inline = _binline;
 //BA.debugLineNum = 726;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 727;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialleftaligntext(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1402;BA.debugLine="Sub MaterialLeftAlignText(bStatus As Boolean) As U";
 //BA.debugLineNum = 1403;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 1404;BA.debugLine="removeClass(\"center-align\")";
_removeclass("center-align");
 //BA.debugLineNum = 1405;BA.debugLine="removeClass(\"right-align\")";
_removeclass("right-align");
 //BA.debugLineNum = 1406;BA.debugLine="removeClass(\"left-align\")";
_removeclass("left-align");
 //BA.debugLineNum = 1407;BA.debugLine="addClass(\"left-align\")";
_addclass("left-align");
 };
 //BA.debugLineNum = 1409;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1410;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialmodalclose() throws Exception{
 //BA.debugLineNum = 187;BA.debugLine="Sub MaterialModalClose() As UOEHTML";
 //BA.debugLineNum = 188;BA.debugLine="addClass(\"modal-action\")";
_addclass("modal-action");
 //BA.debugLineNum = 189;BA.debugLine="addClass(\"modal-close\")";
_addclass("modal-close");
 //BA.debugLineNum = 190;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialpulse(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 447;BA.debugLine="Sub MaterialPulse(bStatus As Boolean) As UOEHTML";
 //BA.debugLineNum = 448;BA.debugLine="AddClassOnCondition(bStatus,\"pulse\")";
_addclassoncondition(_bstatus,"pulse");
 //BA.debugLineNum = 449;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 450;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialrequired(boolean _brequired) throws Exception{
 //BA.debugLineNum = 719;BA.debugLine="Sub MaterialRequired(bRequired As Boolean) As UOEH";
 //BA.debugLineNum = 720;BA.debugLine="Required = bRequired";
_required = _brequired;
 //BA.debugLineNum = 721;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 722;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialresponsive(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 341;BA.debugLine="Sub MaterialResponsive(bStatus As Boolean) As UOEH";
 //BA.debugLineNum = 342;BA.debugLine="AddClassOnCondition(bStatus,\"responsive-img\")";
_addclassoncondition(_bstatus,"responsive-img");
 //BA.debugLineNum = 343;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 344;BA.debugLine="AddCursor";
_addcursor();
 };
 //BA.debugLineNum = 346;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 347;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialrightaligntext(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1422;BA.debugLine="Sub MaterialRightAlignText(bStatus As Boolean) As";
 //BA.debugLineNum = 1423;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 1424;BA.debugLine="removeClass(\"center-align\")";
_removeclass("center-align");
 //BA.debugLineNum = 1425;BA.debugLine="removeClass(\"right-align\")";
_removeclass("right-align");
 //BA.debugLineNum = 1426;BA.debugLine="removeClass(\"left-align\")";
_removeclass("left-align");
 //BA.debugLineNum = 1427;BA.debugLine="addClass(\"right-align\")";
_addclass("right-align");
 };
 //BA.debugLineNum = 1429;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1430;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialsecondarycontent(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 198;BA.debugLine="Sub MaterialSecondaryContent(bStatus As Boolean) A";
 //BA.debugLineNum = 199;BA.debugLine="AddClassOnCondition(bStatus,\"secondary-content\")";
_addclassoncondition(_bstatus,"secondary-content");
 //BA.debugLineNum = 200;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 201;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialsettooltip(String _position,String _delay,String _tooltip) throws Exception{
 //BA.debugLineNum = 535;BA.debugLine="Sub MaterialSetToolTip(position As String, delay A";
 //BA.debugLineNum = 536;BA.debugLine="delay = CStr(delay)";
_delay = _cstr((Object)(_delay));
 //BA.debugLineNum = 537;BA.debugLine="position = CStr(position)";
_position = _cstr((Object)(_position));
 //BA.debugLineNum = 538;BA.debugLine="tooltip = CStr(tooltip)";
_tooltip = _cstr((Object)(_tooltip));
 //BA.debugLineNum = 539;BA.debugLine="If tooltip.Length > 0 Then";
if (_tooltip.length()>0) { 
 //BA.debugLineNum = 540;BA.debugLine="addClass(\"tooltipped\")";
_addclass("tooltipped");
 //BA.debugLineNum = 541;BA.debugLine="AddAttribute(\"data-position\",position)";
_addattribute("data-position",_position);
 //BA.debugLineNum = 542;BA.debugLine="AddAttribute(\"data-delay\",delay)";
_addattribute("data-delay",_delay);
 //BA.debugLineNum = 543;BA.debugLine="AddAttribute(\"data-tooltip\",tooltip)";
_addattribute("data-tooltip",_tooltip);
 }else {
 //BA.debugLineNum = 545;BA.debugLine="removeClass(\"tooltipped\")";
_removeclass("tooltipped");
 //BA.debugLineNum = 546;BA.debugLine="removeClass(\"data-position\")";
_removeclass("data-position");
 //BA.debugLineNum = 547;BA.debugLine="removeClass(\"data-delay\")";
_removeclass("data-delay");
 //BA.debugLineNum = 548;BA.debugLine="removeClass(\"data-tooltip\")";
_removeclass("data-tooltip");
 };
 //BA.debugLineNum = 550;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 551;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialtextalign(String _textalign) throws Exception{
 //BA.debugLineNum = 1392;BA.debugLine="Sub MaterialTextAlign(textalign As String) As UOEH";
 //BA.debugLineNum = 1393;BA.debugLine="If textalign.Length > 0 Then";
if (_textalign.length()>0) { 
 //BA.debugLineNum = 1394;BA.debugLine="removeClass(\"center-align\")";
_removeclass("center-align");
 //BA.debugLineNum = 1395;BA.debugLine="removeClass(\"right-align\")";
_removeclass("right-align");
 //BA.debugLineNum = 1396;BA.debugLine="removeClass(\"left-align\")";
_removeclass("left-align");
 //BA.debugLineNum = 1397;BA.debugLine="addClass(textalign)";
_addclass(_textalign);
 };
 //BA.debugLineNum = 1399;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1400;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialtextcolor(String _scolor) throws Exception{
boolean _ew = false;
 //BA.debugLineNum = 304;BA.debugLine="Sub MaterialTextColor(sColor As String) As UOEHTML";
 //BA.debugLineNum = 305;BA.debugLine="sColor = sColor.trim";
_scolor = _scolor.trim();
 //BA.debugLineNum = 306;BA.debugLine="If sColor = \"\" Then Return Me";
if ((_scolor).equals("")) { 
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);};
 //BA.debugLineNum = 307;BA.debugLine="Dim ew As Boolean = sColor.EndsWith(\"-text\")";
_ew = _scolor.endsWith("-text");
 //BA.debugLineNum = 308;BA.debugLine="If ew = False Then";
if (_ew==__c.False) { 
 //BA.debugLineNum = 309;BA.debugLine="sColor = sColor & \"-text\"";
_scolor = _scolor+"-text";
 };
 //BA.debugLineNum = 311;BA.debugLine="addClass(sColor)";
_addclass(_scolor);
 //BA.debugLineNum = 312;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 313;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialtoolbar(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 390;BA.debugLine="Sub MaterialToolBar(bStatus As Boolean) As UOEHTML";
 //BA.debugLineNum = 391;BA.debugLine="AddClassOnCondition(bStatus,\"toolbar\")";
_addclassoncondition(_bstatus,"toolbar");
 //BA.debugLineNum = 392;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 393;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialtruncate(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1363;BA.debugLine="Sub MaterialTruncate(bStatus As Boolean) As UOEHTM";
 //BA.debugLineNum = 1364;BA.debugLine="AddClassOnCondition(bStatus,\"truncate\")";
_addclassoncondition(_bstatus,"truncate");
 //BA.debugLineNum = 1365;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1366;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialverticalalign(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 1456;BA.debugLine="Sub MaterialVerticalAlign(bStatus As Boolean) As U";
 //BA.debugLineNum = 1457;BA.debugLine="AddClassOnCondition(bStatus,\"valign-wrapper\")";
_addclassoncondition(_bstatus,"valign-wrapper");
 //BA.debugLineNum = 1458;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1459;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialvisibility(String _svisibility) throws Exception{
 //BA.debugLineNum = 1462;BA.debugLine="Sub MaterialVisibility(sVisibility As String) As U";
 //BA.debugLineNum = 1463;BA.debugLine="If sVisibility.Length > 0 Then";
if (_svisibility.length()>0) { 
 //BA.debugLineNum = 1464;BA.debugLine="removeClass(\"hide-on-small-only\")";
_removeclass("hide-on-small-only");
 //BA.debugLineNum = 1465;BA.debugLine="removeClass(\"hide-on-med-only\")";
_removeclass("hide-on-med-only");
 //BA.debugLineNum = 1466;BA.debugLine="removeClass(\"hide-on-med-and-down\")";
_removeclass("hide-on-med-and-down");
 //BA.debugLineNum = 1467;BA.debugLine="removeClass(\"hide-on-med-and-up\")";
_removeclass("hide-on-med-and-up");
 //BA.debugLineNum = 1468;BA.debugLine="removeClass(\"hide-on-large-only\")";
_removeclass("hide-on-large-only");
 //BA.debugLineNum = 1469;BA.debugLine="removeClass(\"show-on-large\")";
_removeclass("show-on-large");
 //BA.debugLineNum = 1470;BA.debugLine="removeClass(\"show-on-small\")";
_removeclass("show-on-small");
 //BA.debugLineNum = 1471;BA.debugLine="removeClass(\"show-on-medium\")";
_removeclass("show-on-medium");
 //BA.debugLineNum = 1472;BA.debugLine="removeClass(\"show-on-medium-and-up\")";
_removeclass("show-on-medium-and-up");
 //BA.debugLineNum = 1473;BA.debugLine="removeClass(\"show-on-medium-and-down\")";
_removeclass("show-on-medium-and-down");
 //BA.debugLineNum = 1474;BA.debugLine="removeClass(\"hide\")";
_removeclass("hide");
 //BA.debugLineNum = 1475;BA.debugLine="addClass(sVisibility)";
_addclass(_svisibility);
 };
 //BA.debugLineNum = 1477;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1478;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialwavesblock(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 518;BA.debugLine="Sub MaterialWavesBlock(bStatus As Boolean) As UOEH";
 //BA.debugLineNum = 519;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 520;BA.debugLine="removeClass(\"waves-circle\")";
_removeclass("waves-circle");
 //BA.debugLineNum = 521;BA.debugLine="removeClass(\"waves-block\")";
_removeclass("waves-block");
 //BA.debugLineNum = 522;BA.debugLine="addClass(\"waves-block\")";
_addclass("waves-block");
 };
 //BA.debugLineNum = 524;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 525;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialwavescircle(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 509;BA.debugLine="Sub MaterialWavesCircle(bStatus As Boolean) As UOE";
 //BA.debugLineNum = 510;BA.debugLine="If bStatus = True Then";
if (_bstatus==__c.True) { 
 //BA.debugLineNum = 511;BA.debugLine="removeClass(\"waves-circle\")";
_removeclass("waves-circle");
 //BA.debugLineNum = 512;BA.debugLine="removeClass(\"waves-block\")";
_removeclass("waves-block");
 //BA.debugLineNum = 513;BA.debugLine="addClass(\"waves-circle\")";
_addclass("waves-circle");
 };
 //BA.debugLineNum = 515;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 516;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialwaveseffect(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 490;BA.debugLine="Sub MaterialWavesEffect(bStatus As Boolean) As UOE";
 //BA.debugLineNum = 491;BA.debugLine="AddClassOnCondition(bStatus,\"waves-effect\")";
_addclassoncondition(_bstatus,"waves-effect");
 //BA.debugLineNum = 492;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 493;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialwaveslight(boolean _bstatus) throws Exception{
 //BA.debugLineNum = 529;BA.debugLine="Sub MaterialWavesLight(bStatus As Boolean) As UOEH";
 //BA.debugLineNum = 530;BA.debugLine="AddClassOnCondition(bStatus,\"waves-light\")";
_addclassoncondition(_bstatus,"waves-light");
 //BA.debugLineNum = 531;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 532;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialwavestype(String _stype) throws Exception{
 //BA.debugLineNum = 495;BA.debugLine="Sub MaterialWavesType(sType As String) As UOEHTML";
 //BA.debugLineNum = 496;BA.debugLine="If sType.Length > 0 Then";
if (_stype.length()>0) { 
 //BA.debugLineNum = 497;BA.debugLine="removeClass(\"waves-green\")";
_removeclass("waves-green");
 //BA.debugLineNum = 498;BA.debugLine="removeClass(\"waves-light\")";
_removeclass("waves-light");
 //BA.debugLineNum = 499;BA.debugLine="removeClass(\"waves-orange\")";
_removeclass("waves-orange");
 //BA.debugLineNum = 500;BA.debugLine="removeClass(\"waves-purple\")";
_removeclass("waves-purple");
 //BA.debugLineNum = 501;BA.debugLine="removeClass(\"waves-red\")";
_removeclass("waves-red");
 //BA.debugLineNum = 502;BA.debugLine="removeClass(\"waves-teal\")";
_removeclass("waves-teal");
 //BA.debugLineNum = 503;BA.debugLine="removeClass(\"waves-yellow\")";
_removeclass("waves-yellow");
 //BA.debugLineNum = 504;BA.debugLine="addClass(sType)";
_addclass(_stype);
 };
 //BA.debugLineNum = 506;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 507;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _materialzdepth(String _szdepth) throws Exception{
 //BA.debugLineNum = 1442;BA.debugLine="Sub MaterialZDepth(szdepth As String) As UOEHTML";
 //BA.debugLineNum = 1444;BA.debugLine="If szdepth.Length > 0 Then";
if (_szdepth.length()>0) { 
 //BA.debugLineNum = 1445;BA.debugLine="removeClass(\"z-depth-1\")";
_removeclass("z-depth-1");
 //BA.debugLineNum = 1446;BA.debugLine="removeClass(\"z-depth-2\")";
_removeclass("z-depth-2");
 //BA.debugLineNum = 1447;BA.debugLine="removeClass(\"z-depth-3\")";
_removeclass("z-depth-3");
 //BA.debugLineNum = 1448;BA.debugLine="removeClass(\"z-depth-4\")";
_removeclass("z-depth-4");
 //BA.debugLineNum = 1449;BA.debugLine="removeClass(\"z-depth-5\")";
_removeclass("z-depth-5");
 //BA.debugLineNum = 1450;BA.debugLine="addClass(szdepth)";
_addclass(_szdepth);
 };
 //BA.debugLineNum = 1452;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 1453;BA.debugLine="End Sub";
return null;
}
public String  _mvfield(String _svalue,int _iposition,String _delimiter) throws Exception{
int _xpos = 0;
anywheresoftware.b4a.objects.collections.List _mvalues = null;
int _tvalues = 0;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _startcnt = 0;
 //BA.debugLineNum = 1190;BA.debugLine="private Sub MvField(sValue As String, iPosition As";
 //BA.debugLineNum = 1191;BA.debugLine="If sValue.Length = 0 Then Return \"\"";
if (_svalue.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 1192;BA.debugLine="Dim xPos As Int = sValue.IndexOf(Delimiter)";
_xpos = _svalue.indexOf(_delimiter);
 //BA.debugLineNum = 1193;BA.debugLine="If xPos = -1 Then Return sValue";
if (_xpos==-1) { 
if (true) return _svalue;};
 //BA.debugLineNum = 1194;BA.debugLine="Dim mValues As List = StrParse(Delimiter,sValue)";
_mvalues = new anywheresoftware.b4a.objects.collections.List();
_mvalues = _strparse(_delimiter,_svalue);
 //BA.debugLineNum = 1195;BA.debugLine="Dim tValues As Int";
_tvalues = 0;
 //BA.debugLineNum = 1196;BA.debugLine="tValues = mValues.size -1";
_tvalues = (int) (_mvalues.getSize()-1);
 //BA.debugLineNum = 1197;BA.debugLine="Select Case iPosition";
switch (BA.switchObjectToInt(_iposition,(int) (-1),(int) (-2),(int) (-3))) {
case 0: {
 //BA.debugLineNum = 1199;BA.debugLine="Return mValues.get(tValues)";
if (true) return BA.ObjectToString(_mvalues.Get(_tvalues));
 break; }
case 1: {
 //BA.debugLineNum = 1201;BA.debugLine="Return mValues.get(tValues - 1)";
if (true) return BA.ObjectToString(_mvalues.Get((int) (_tvalues-1)));
 break; }
case 2: {
 //BA.debugLineNum = 1203;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 1204;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 1205;BA.debugLine="Dim startcnt As Int";
_startcnt = 0;
 //BA.debugLineNum = 1206;BA.debugLine="sb.Append(mValues.Get(1))";
_sb.Append(BA.ObjectToString(_mvalues.Get((int) (1))));
 //BA.debugLineNum = 1207;BA.debugLine="For startcnt = 2 To tValues";
{
final int step17 = 1;
final int limit17 = _tvalues;
_startcnt = (int) (2) ;
for (;_startcnt <= limit17 ;_startcnt = _startcnt + step17 ) {
 //BA.debugLineNum = 1208;BA.debugLine="sb.Append(Delimiter)";
_sb.Append(_delimiter);
 //BA.debugLineNum = 1209;BA.debugLine="sb.Append(mValues.get(startcnt))";
_sb.Append(BA.ObjectToString(_mvalues.Get(_startcnt)));
 }
};
 //BA.debugLineNum = 1211;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 break; }
default: {
 //BA.debugLineNum = 1213;BA.debugLine="iPosition = iPosition - 1";
_iposition = (int) (_iposition-1);
 //BA.debugLineNum = 1214;BA.debugLine="If iPosition <= -1 Then";
if (_iposition<=-1) { 
 //BA.debugLineNum = 1215;BA.debugLine="Return mValues.get(tValues)";
if (true) return BA.ObjectToString(_mvalues.Get(_tvalues));
 };
 //BA.debugLineNum = 1217;BA.debugLine="If iPosition > tValues Then";
if (_iposition>_tvalues) { 
 //BA.debugLineNum = 1218;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 1220;BA.debugLine="Return mValues.get(iPosition)";
if (true) return BA.ObjectToString(_mvalues.Get(_iposition));
 break; }
}
;
 //BA.debugLineNum = 1222;BA.debugLine="End Sub";
return "";
}
public String  _mvfieldfrom(String _svalue,int _iposition,String _delimiter) throws Exception{
anywheresoftware.b4a.objects.collections.List _mvalues = null;
int _tvalues = 0;
boolean _ew = false;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _startcnt = 0;
 //BA.debugLineNum = 937;BA.debugLine="public Sub MvFieldFrom(sValue As String, iPosition";
 //BA.debugLineNum = 938;BA.debugLine="If sValue.Length = 0 Then Return \"\"";
if (_svalue.length()==0) { 
if (true) return "";};
 //BA.debugLineNum = 939;BA.debugLine="Dim mValues As List";
_mvalues = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 940;BA.debugLine="Dim tValues As Int";
_tvalues = 0;
 //BA.debugLineNum = 941;BA.debugLine="Dim ew As Boolean = sValue.EndsWith(Delimiter)";
_ew = _svalue.endsWith(_delimiter);
 //BA.debugLineNum = 942;BA.debugLine="If ew Then";
if (_ew) { 
 //BA.debugLineNum = 943;BA.debugLine="sValue = sValue & \" \"";
_svalue = _svalue+" ";
 };
 //BA.debugLineNum = 945;BA.debugLine="mValues = StrParse(Delimiter, sValue)";
_mvalues = _strparse(_delimiter,_svalue);
 //BA.debugLineNum = 946;BA.debugLine="tValues = mValues.size -1";
_tvalues = (int) (_mvalues.getSize()-1);
 //BA.debugLineNum = 947;BA.debugLine="If tValues < iPosition Then";
if (_tvalues<_iposition) { 
 //BA.debugLineNum = 948;BA.debugLine="Return mValues.get(tValues)";
if (true) return BA.ObjectToString(_mvalues.Get(_tvalues));
 };
 //BA.debugLineNum = 950;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 951;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 952;BA.debugLine="Dim startcnt As Int";
_startcnt = 0;
 //BA.debugLineNum = 953;BA.debugLine="sb.Append(mValues.get(iPosition))";
_sb.Append(BA.ObjectToString(_mvalues.Get(_iposition)));
 //BA.debugLineNum = 954;BA.debugLine="For startcnt = iPosition + 1 To tValues";
{
final int step17 = 1;
final int limit17 = _tvalues;
_startcnt = (int) (_iposition+1) ;
for (;_startcnt <= limit17 ;_startcnt = _startcnt + step17 ) {
 //BA.debugLineNum = 955;BA.debugLine="sb.Append(Delimiter)";
_sb.Append(_delimiter);
 //BA.debugLineNum = 956;BA.debugLine="sb.Append(mValues.get(startcnt))";
_sb.Append(BA.ObjectToString(_mvalues.Get(_startcnt)));
 }
};
 //BA.debugLineNum = 958;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 959;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
String _thisclass = "";
String _thisstyle = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _thisattr = "";
 //BA.debugLineNum = 1021;BA.debugLine="private Sub Open() As String";
 //BA.debugLineNum = 1023;BA.debugLine="If Required = True Then setAttrLoose(\"required\")";
if (_required==__c.True) { 
_setattrloose("required");};
 //BA.debugLineNum = 1024;BA.debugLine="If Enabled = False Then setAttrLoose(\"disabled\")";
if (_enabled==__c.False) { 
_setattrloose("disabled");};
 //BA.debugLineNum = 1025;BA.debugLine="If Inline = True Then setAttrLoose(\"inline\")";
if (_inline==__c.True) { 
_setattrloose("inline");};
 //BA.debugLineNum = 1026;BA.debugLine="If ReadOnly = True Then setAttrLoose(\"readonly\")";
if (_readonly==__c.True) { 
_setattrloose("readonly");};
 //BA.debugLineNum = 1028;BA.debugLine="Dim thisClass As String = BuildClass";
_thisclass = _buildclass();
 //BA.debugLineNum = 1029;BA.debugLine="thisClass = thisClass.trim";
_thisclass = _thisclass.trim();
 //BA.debugLineNum = 1030;BA.debugLine="If thisClass.Length > 0 Then";
if (_thisclass.length()>0) { 
 //BA.debugLineNum = 1031;BA.debugLine="AddAttribute(\"class\", thisClass)";
_addattribute("class",_thisclass);
 };
 //BA.debugLineNum = 1034;BA.debugLine="Dim thisStyle As String = BuildStyle";
_thisstyle = _buildstyle();
 //BA.debugLineNum = 1035;BA.debugLine="thisStyle = thisStyle.trim";
_thisstyle = _thisstyle.trim();
 //BA.debugLineNum = 1036;BA.debugLine="If thisStyle.Length > 0 Then";
if (_thisstyle.length()>0) { 
 //BA.debugLineNum = 1037;BA.debugLine="AddAttribute(\"style\", thisStyle)";
_addattribute("style",_thisstyle);
 };
 //BA.debugLineNum = 1039;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 1040;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 1041;BA.debugLine="If Prefix.Length > 0 Then";
if (_prefix.length()>0) { 
 //BA.debugLineNum = 1042;BA.debugLine="sb.Append(Prefix)";
_sb.Append(_prefix);
 //BA.debugLineNum = 1043;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 };
 //BA.debugLineNum = 1045;BA.debugLine="sb.Append(\"<\")";
_sb.Append("<");
 //BA.debugLineNum = 1046;BA.debugLine="sb.Append(Tag)";
_sb.Append(_tag);
 //BA.debugLineNum = 1047;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 //BA.debugLineNum = 1048;BA.debugLine="If ID.Length > 0 Then";
if (_id.length()>0) { 
 //BA.debugLineNum = 1049;BA.debugLine="sb.Append(ToProperty(\"id\",ID))";
_sb.Append(_toproperty("id",_id));
 //BA.debugLineNum = 1050;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 };
 //BA.debugLineNum = 1053;BA.debugLine="Dim thisAttr As String = BuildAttributes";
_thisattr = _buildattributes();
 //BA.debugLineNum = 1054;BA.debugLine="thisAttr = thisAttr.Trim";
_thisattr = _thisattr.trim();
 //BA.debugLineNum = 1055;BA.debugLine="If thisAttr.Length > 0 Then";
if (_thisattr.length()>0) { 
 //BA.debugLineNum = 1056;BA.debugLine="sb.Append(thisAttr)";
_sb.Append(_thisattr);
 };
 //BA.debugLineNum = 1058;BA.debugLine="sb.Append(\">\")";
_sb.Append(">");
 //BA.debugLineNum = 1059;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 //BA.debugLineNum = 1060;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 1061;BA.debugLine="End Sub";
return "";
}
public String  _pointer() throws Exception{
 //BA.debugLineNum = 553;BA.debugLine="Sub Pointer As String";
 //BA.debugLineNum = 554;BA.debugLine="Return \"cursor:pointer\"";
if (true) return "cursor:pointer";
 //BA.debugLineNum = 555;BA.debugLine="End Sub";
return "";
}
public String  _remdelim(String _svalue,String _delim) throws Exception{
boolean _sw = false;
int _ldelim = 0;
String _nvalue = "";
 //BA.debugLineNum = 1152;BA.debugLine="private Sub RemDelim(sValue As String, Delim As St";
 //BA.debugLineNum = 1153;BA.debugLine="Dim sw As Boolean = sValue.EndsWith(Delim)";
_sw = _svalue.endsWith(_delim);
 //BA.debugLineNum = 1154;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 1155;BA.debugLine="Dim lDelim As Int = Delim.Length";
_ldelim = _delim.length();
 //BA.debugLineNum = 1156;BA.debugLine="Dim nValue As String = sValue";
_nvalue = _svalue;
 //BA.debugLineNum = 1157;BA.debugLine="sw = nValue.EndsWith(Delim)";
_sw = _nvalue.endsWith(_delim);
 //BA.debugLineNum = 1158;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 1159;BA.debugLine="nValue = nValue.SubString2(0, nValue.Length-lDe";
_nvalue = _nvalue.substring((int) (0),(int) (_nvalue.length()-_ldelim));
 };
 //BA.debugLineNum = 1161;BA.debugLine="Return nValue";
if (true) return _nvalue;
 }else {
 //BA.debugLineNum = 1163;BA.debugLine="Return sValue";
if (true) return _svalue;
 };
 //BA.debugLineNum = 1165;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoehtml  _removeattr(String _sname) throws Exception{
anywheresoftware.b4a.objects.collections.List _sitems = null;
String _strstyle = "";
 //BA.debugLineNum = 737;BA.debugLine="public Sub removeAttr(sName As String) As UOEHTML";
 //BA.debugLineNum = 738;BA.debugLine="sName = sName.ToLowerCase";
_sname = _sname.toLowerCase();
 //BA.debugLineNum = 739;BA.debugLine="sName = sName.Replace(\" \",\";\")";
_sname = _sname.replace(" ",";");
 //BA.debugLineNum = 740;BA.debugLine="Dim sItems As List = StrParse(\";\",sName)";
_sitems = new anywheresoftware.b4a.objects.collections.List();
_sitems = _strparse(";",_sname);
 //BA.debugLineNum = 741;BA.debugLine="For Each strStyle As String In sItems";
{
final anywheresoftware.b4a.BA.IterableList group4 = _sitems;
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_strstyle = BA.ObjectToString(group4.Get(index4));
 //BA.debugLineNum = 742;BA.debugLine="strStyle = strStyle.trim";
_strstyle = _strstyle.trim();
 //BA.debugLineNum = 743;BA.debugLine="If properties.ContainsKey(strStyle) Then";
if (_properties.ContainsKey((Object)(_strstyle))) { 
 //BA.debugLineNum = 744;BA.debugLine="properties.Remove(strStyle)";
_properties.Remove((Object)(_strstyle));
 };
 }
};
 //BA.debugLineNum = 747;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 748;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removeattrdata(String _sdata) throws Exception{
 //BA.debugLineNum = 708;BA.debugLine="public Sub removeAttrData(sData As String) As UOEH";
 //BA.debugLineNum = 709;BA.debugLine="sData = $\"data-${sData}\"$";
_sdata = ("data-"+__c.SmartStringFormatter("",(Object)(_sdata))+"");
 //BA.debugLineNum = 710;BA.debugLine="removeAttr(sData)";
_removeattr(_sdata);
 //BA.debugLineNum = 711;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 712;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removeattribute(String _prop) throws Exception{
 //BA.debugLineNum = 731;BA.debugLine="Sub removeAttribute(prop As String) As UOEHTML";
 //BA.debugLineNum = 732;BA.debugLine="removeAttr(prop)";
_removeattr(_prop);
 //BA.debugLineNum = 733;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 734;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removeclass(String _classname) throws Exception{
anywheresoftware.b4a.objects.collections.List _sitems = null;
String _strstyle = "";
 //BA.debugLineNum = 847;BA.debugLine="public Sub removeClass(className As String) As UOE";
 //BA.debugLineNum = 848;BA.debugLine="className = className.Trim";
_classname = _classname.trim();
 //BA.debugLineNum = 849;BA.debugLine="className = className.replace(\" \",\";\")";
_classname = _classname.replace(" ",";");
 //BA.debugLineNum = 850;BA.debugLine="Dim sItems As List = StrParse(\";\",className)";
_sitems = new anywheresoftware.b4a.objects.collections.List();
_sitems = _strparse(";",_classname);
 //BA.debugLineNum = 851;BA.debugLine="For Each strStyle As String In sItems";
{
final anywheresoftware.b4a.BA.IterableList group4 = _sitems;
final int groupLen4 = group4.getSize()
;int index4 = 0;
;
for (; index4 < groupLen4;index4++){
_strstyle = BA.ObjectToString(group4.Get(index4));
 //BA.debugLineNum = 852;BA.debugLine="strStyle = strStyle.Trim";
_strstyle = _strstyle.trim();
 //BA.debugLineNum = 853;BA.debugLine="If classes.ContainsKey(strStyle) Then";
if (_classes.ContainsKey((Object)(_strstyle))) { 
 //BA.debugLineNum = 854;BA.debugLine="classes.Remove(strStyle)";
_classes.Remove((Object)(_strstyle));
 };
 }
};
 //BA.debugLineNum = 857;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 858;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removeclassoncondition(boolean _bcondition,String _sclass) throws Exception{
 //BA.debugLineNum = 590;BA.debugLine="Sub RemoveClassOnCondition(bCondition As Boolean,";
 //BA.debugLineNum = 591;BA.debugLine="If bCondition = True Then";
if (_bcondition==__c.True) { 
 //BA.debugLineNum = 592;BA.debugLine="removeClass(sClass)";
_removeclass(_sclass);
 };
 //BA.debugLineNum = 594;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 595;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removeclassonfalsecondition(boolean _bcondition,String _sclass) throws Exception{
 //BA.debugLineNum = 598;BA.debugLine="Sub RemoveClassOnFalseCondition(bCondition As Bool";
 //BA.debugLineNum = 599;BA.debugLine="If bCondition = False Then";
if (_bcondition==__c.False) { 
 //BA.debugLineNum = 600;BA.debugLine="removeClass(sClass)";
_removeclass(_sclass);
 };
 //BA.debugLineNum = 602;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 603;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _removestyle(String _stylename) throws Exception{
anywheresoftware.b4a.objects.collections.List _sitems = null;
String _strstyle = "";
 //BA.debugLineNum = 751;BA.debugLine="public Sub removeStyle(styleName As String) As UOE";
 //BA.debugLineNum = 752;BA.debugLine="styleName = styleName.Trim";
_stylename = _stylename.trim();
 //BA.debugLineNum = 753;BA.debugLine="styleName = styleName.tolowercase";
_stylename = _stylename.toLowerCase();
 //BA.debugLineNum = 754;BA.debugLine="styleName = styleName.Replace(\" \",\";\")";
_stylename = _stylename.replace(" ",";");
 //BA.debugLineNum = 755;BA.debugLine="Dim sItems As List = StrParse(\";\",styleName)";
_sitems = new anywheresoftware.b4a.objects.collections.List();
_sitems = _strparse(";",_stylename);
 //BA.debugLineNum = 756;BA.debugLine="For Each strStyle As String In sItems";
{
final anywheresoftware.b4a.BA.IterableList group5 = _sitems;
final int groupLen5 = group5.getSize()
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_strstyle = BA.ObjectToString(group5.Get(index5));
 //BA.debugLineNum = 757;BA.debugLine="strStyle = strStyle.trim";
_strstyle = _strstyle.trim();
 //BA.debugLineNum = 758;BA.debugLine="If styles.ContainsKey(strStyle) Then";
if (_styles.ContainsKey((Object)(_strstyle))) { 
 //BA.debugLineNum = 759;BA.debugLine="styles.Remove(strStyle)";
_styles.Remove((Object)(_strstyle));
 };
 }
};
 //BA.debugLineNum = 762;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 763;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setalt(String _svalue) throws Exception{
 //BA.debugLineNum = 362;BA.debugLine="Sub SetALT(sValue As String) As UOEHTML";
 //BA.debugLineNum = 363;BA.debugLine="AddAttribute(\"alt\",sValue)";
_addattribute("alt",_svalue);
 //BA.debugLineNum = 364;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 365;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setattrdata(String _prop,String _value) throws Exception{
boolean _sw = false;
 //BA.debugLineNum = 821;BA.debugLine="Sub setAttrData(prop As String, value As String) A";
 //BA.debugLineNum = 822;BA.debugLine="Dim sw As Boolean = prop.StartsWith(\"data-\")";
_sw = _prop.startsWith("data-");
 //BA.debugLineNum = 823;BA.debugLine="If sw Then";
if (_sw) { 
 //BA.debugLineNum = 824;BA.debugLine="AddAttribute(prop,value)";
_addattribute(_prop,_value);
 }else {
 //BA.debugLineNum = 826;BA.debugLine="AddAttribute(\"data-\" & prop,value)";
_addattribute("data-"+_prop,_value);
 };
 //BA.debugLineNum = 828;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 829;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setattrloose(String _value) throws Exception{
 //BA.debugLineNum = 766;BA.debugLine="Sub setAttrLoose(value As String) As UOEHTML";
 //BA.debugLineNum = 767;BA.debugLine="AddAttribute(value,\"true\")";
_addattribute(_value,"true");
 //BA.debugLineNum = 768;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 769;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setcontents(String _value) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="public Sub SetContents(value As String) As UOEHTML";
 //BA.debugLineNum = 41;BA.debugLine="Contents.Initialize";
_contents.Initialize();
 //BA.debugLineNum = 42;BA.debugLine="Contents.clear";
_contents.Clear();
 //BA.debugLineNum = 43;BA.debugLine="If value.Length > 0 Then";
if (_value.length()>0) { 
 //BA.debugLineNum = 44;BA.debugLine="value = FormatText(value)";
_value = _formattext(_value);
 //BA.debugLineNum = 45;BA.debugLine="Contents.Add(value)";
_contents.Add((Object)(_value));
 };
 //BA.debugLineNum = 47;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setelementtypeoncondition(boolean _bstatus,String _selementtype) throws Exception{
 //BA.debugLineNum = 174;BA.debugLine="Sub SetElementTypeOnCondition(bStatus As Boolean,s";
 //BA.debugLineNum = 175;BA.debugLine="If bStatus Then";
if (_bstatus) { 
 //BA.debugLineNum = 176;BA.debugLine="Tag = sElementType";
_tag = _selementtype;
 };
 //BA.debugLineNum = 178;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setenabled(boolean _benabled) throws Exception{
 //BA.debugLineNum = 660;BA.debugLine="Sub setEnabled(bEnabled As Boolean) As UOEHTML";
 //BA.debugLineNum = 661;BA.debugLine="Enabled = bEnabled";
_enabled = _benabled;
 //BA.debugLineNum = 662;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 663;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setfor(String _sfor) throws Exception{
 //BA.debugLineNum = 231;BA.debugLine="Sub SetFOR(sFor As String) As UOEHTML";
 //BA.debugLineNum = 232;BA.debugLine="AddAttribute(\"for\",sFor)";
_addattribute("for",_sfor);
 //BA.debugLineNum = 233;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 234;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setheightpx(String _height) throws Exception{
 //BA.debugLineNum = 382;BA.debugLine="Sub SetHeightPX(Height As String) As UOEHTML";
 //BA.debugLineNum = 383;BA.debugLine="If Height <> \"\" Then";
if ((_height).equals("") == false) { 
 //BA.debugLineNum = 384;BA.debugLine="AddStyleAttribute(\"height\", MakePx(Height))";
_addstyleattribute("height",_makepx(_height));
 };
 //BA.debugLineNum = 386;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 387;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _sethref(String _value) throws Exception{
 //BA.debugLineNum = 562;BA.debugLine="Sub setHREF(value As String) As UOEHTML";
 //BA.debugLineNum = 563;BA.debugLine="AddAttribute(\"href\",value)";
_addattribute("href",_value);
 //BA.debugLineNum = 564;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 565;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setid(String _sid) throws Exception{
 //BA.debugLineNum = 629;BA.debugLine="Sub setID(sID As String) As UOEHTML";
 //BA.debugLineNum = 630;BA.debugLine="sID = sID.tolowercase";
_sid = _sid.toLowerCase();
 //BA.debugLineNum = 631;BA.debugLine="ID = sID";
_id = _sid;
 //BA.debugLineNum = 632;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 633;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setinline(boolean _binline) throws Exception{
 //BA.debugLineNum = 654;BA.debugLine="Sub setInline(bInline As Boolean) As UOEHTML";
 //BA.debugLineNum = 655;BA.debugLine="Inline = bInline";
_inline = _binline;
 //BA.debugLineNum = 656;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 657;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setliststylecircle() throws Exception{
 //BA.debugLineNum = 126;BA.debugLine="Sub SetListStyleCircle() As UOEHTML";
 //BA.debugLineNum = 127;BA.debugLine="AddStyleAttribute(\"list-style-type\",\"circle\")";
_addstyleattribute("list-style-type","circle");
 //BA.debugLineNum = 128;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setliststyledisk() throws Exception{
 //BA.debugLineNum = 131;BA.debugLine="Sub SetListStyleDisk() As UOEHTML";
 //BA.debugLineNum = 132;BA.debugLine="AddStyleAttribute(\"list-style-type\",\"disk\")";
_addstyleattribute("list-style-type","disk");
 //BA.debugLineNum = 133;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setliststylenone() throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Sub SetListStyleNone() As UOEHTML";
 //BA.debugLineNum = 137;BA.debugLine="AddStyleAttribute(\"list-style-type\",\"none\")";
_addstyleattribute("list-style-type","none");
 //BA.debugLineNum = 138;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setliststylesquare() throws Exception{
 //BA.debugLineNum = 141;BA.debugLine="Sub SetListStyleSquare() As UOEHTML";
 //BA.debugLineNum = 142;BA.debugLine="AddStyleAttribute(\"list-style-type\",\"square\")";
_addstyleattribute("list-style-type","square");
 //BA.debugLineNum = 143;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setname(String _sname) throws Exception{
 //BA.debugLineNum = 243;BA.debugLine="Sub SetNAME(sName As String) As UOEHTML";
 //BA.debugLineNum = 244;BA.debugLine="AddAttribute(\"name\",sName)";
_addattribute("name",_sname);
 //BA.debugLineNum = 245;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 246;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setparentid(String _sparentid) throws Exception{
 //BA.debugLineNum = 642;BA.debugLine="Sub setParentID(sParentID As String) As UOEHTML";
 //BA.debugLineNum = 643;BA.debugLine="ParentID = sParentID";
_parentid = _sparentid;
 //BA.debugLineNum = 644;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 645;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setprefix(String _sprefix) throws Exception{
 //BA.debugLineNum = 623;BA.debugLine="Sub setPrefix(sPrefix As String) As UOEHTML";
 //BA.debugLineNum = 624;BA.debugLine="Prefix = sPrefix";
_prefix = _sprefix;
 //BA.debugLineNum = 625;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 626;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setreadonly(boolean _breadonly) throws Exception{
 //BA.debugLineNum = 648;BA.debugLine="Sub setReadOnly(bReadOnly As Boolean) As UOEHTML";
 //BA.debugLineNum = 649;BA.debugLine="ReadOnly = bReadOnly";
_readonly = _breadonly;
 //BA.debugLineNum = 650;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 651;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setrequired(boolean _brequired) throws Exception{
 //BA.debugLineNum = 666;BA.debugLine="Sub setRequired(bRequired As Boolean) As UOEHTML";
 //BA.debugLineNum = 667;BA.debugLine="Required = bRequired";
_required = _brequired;
 //BA.debugLineNum = 668;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 669;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setrole(String _svalue) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub SetROLE(sValue As String) As UOEHTML";
 //BA.debugLineNum = 61;BA.debugLine="AddAttribute(\"role\",sValue)";
_addattribute("role",_svalue);
 //BA.debugLineNum = 62;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setsrc(String _svalue,boolean _static) throws Exception{
String _tmpfile = "";
 //BA.debugLineNum = 350;BA.debugLine="Sub SetSRC(sValue As String, Static As Boolean) As";
 //BA.debugLineNum = 351;BA.debugLine="Dim tmpFile As String = MvField(sValue,1,\"?\")";
_tmpfile = _mvfield(_svalue,(int) (1),"?");
 //BA.debugLineNum = 352;BA.debugLine="If Static Then";
if (_static) { 
 //BA.debugLineNum = 353;BA.debugLine="sValue = tmpFile";
_svalue = _tmpfile;
 }else {
 //BA.debugLineNum = 355;BA.debugLine="sValue = tmpFile & \"?\" & DateTime.now";
_svalue = _tmpfile+"?"+BA.NumberToString(__c.DateTime.getNow());
 };
 //BA.debugLineNum = 357;BA.debugLine="AddAttribute(\"src\",sValue)";
_addattribute("src",_svalue);
 //BA.debugLineNum = 358;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 359;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settag(String _stag) throws Exception{
 //BA.debugLineNum = 636;BA.debugLine="Sub setTag(sTag As String) As UOEHTML";
 //BA.debugLineNum = 637;BA.debugLine="Tag = sTag";
_tag = _stag;
 //BA.debugLineNum = 638;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 639;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settext(String _stext,boolean _bafter) throws Exception{
 //BA.debugLineNum = 616;BA.debugLine="Sub setText(sText As String,bAfter As Boolean) As";
 //BA.debugLineNum = 617;BA.debugLine="Text = sText";
_text = _stext;
 //BA.debugLineNum = 618;BA.debugLine="TextAfter = bAfter";
_textafter = _bafter;
 //BA.debugLineNum = 619;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 620;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settype(String _svalue) throws Exception{
 //BA.debugLineNum = 248;BA.debugLine="Sub SetTYPE(sValue As String) As UOEHTML";
 //BA.debugLineNum = 249;BA.debugLine="AddAttribute(\"type\",sValue)";
_addattribute("type",_svalue);
 //BA.debugLineNum = 250;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settypelowercase() throws Exception{
 //BA.debugLineNum = 110;BA.debugLine="Sub SetTypeLowerCase() As UOEHTML";
 //BA.debugLineNum = 111;BA.debugLine="AddAttribute(\"type\",\"a\")";
_addattribute("type","a");
 //BA.debugLineNum = 112;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settypelowercaseroman() throws Exception{
 //BA.debugLineNum = 120;BA.debugLine="Sub SetTypeLowerCaseRoman() As UOEHTML";
 //BA.debugLineNum = 121;BA.debugLine="AddAttribute(\"type\",\"i\")";
_addattribute("type","i");
 //BA.debugLineNum = 122;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settypenumbers() throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Sub SetTypeNumbers() As UOEHTML";
 //BA.debugLineNum = 101;BA.debugLine="AddAttribute(\"type\",\"1\")";
_addattribute("type","1");
 //BA.debugLineNum = 102;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settypeuppercase() throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Sub SetTypeUpperCase() As UOEHTML";
 //BA.debugLineNum = 106;BA.debugLine="AddAttribute(\"type\",\"A\")";
_addattribute("type","A");
 //BA.debugLineNum = 107;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _settypeuppercaseroman() throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="Sub SetTypeUpperCaseRoman() As UOEHTML";
 //BA.debugLineNum = 116;BA.debugLine="AddAttribute(\"type\",\"I\")";
_addattribute("type","I");
 //BA.debugLineNum = 117;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setvalue(String _svalue) throws Exception{
 //BA.debugLineNum = 237;BA.debugLine="Sub SetVALUE(sValue As String) As UOEHTML";
 //BA.debugLineNum = 238;BA.debugLine="AddAttribute(\"value\",sValue)";
_addattribute("value",_svalue);
 //BA.debugLineNum = 239;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setwidthpx(String _width) throws Exception{
 //BA.debugLineNum = 374;BA.debugLine="Sub SetWidthPX(Width As String) As UOEHTML";
 //BA.debugLineNum = 375;BA.debugLine="If Width <> \"\" Then";
if ((_width).equals("") == false) { 
 //BA.debugLineNum = 376;BA.debugLine="AddStyleAttribute(\"width\", MakePx(Width))";
_addstyleattribute("width",_makepx(_width));
 };
 //BA.debugLineNum = 378;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 379;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _setzindex(String _zindex) throws Exception{
 //BA.debugLineNum = 215;BA.debugLine="Sub SetZIndex(zindex As String) As UOEHTML";
 //BA.debugLineNum = 216;BA.debugLine="AddStyleAttribute(\"z-index\",zindex)";
_addstyleattribute("z-index",_zindex);
 //BA.debugLineNum = 217;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 218;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.List  _strparse(String _delim,String _inputstring) throws Exception{
anywheresoftware.b4a.objects.collections.List _outlist = null;
int _commaloc = 0;
String _leftside = "";
String _rightside = "";
 //BA.debugLineNum = 1258;BA.debugLine="private Sub StrParse(Delim As String, InputString";
 //BA.debugLineNum = 1259;BA.debugLine="Dim OutList As List";
_outlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 1260;BA.debugLine="Dim CommaLoc As Int";
_commaloc = 0;
 //BA.debugLineNum = 1261;BA.debugLine="OutList.Initialize";
_outlist.Initialize();
 //BA.debugLineNum = 1262;BA.debugLine="OutList.clear";
_outlist.Clear();
 //BA.debugLineNum = 1263;BA.debugLine="CommaLoc=InputString.IndexOf(Delim)";
_commaloc = _inputstring.indexOf(_delim);
 //BA.debugLineNum = 1264;BA.debugLine="Do While CommaLoc >-1";
while (_commaloc>-1) {
 //BA.debugLineNum = 1265;BA.debugLine="Dim LeftSide As String";
_leftside = "";
 //BA.debugLineNum = 1266;BA.debugLine="LeftSide= InputString.SubString2(0,CommaLoc)";
_leftside = _inputstring.substring((int) (0),_commaloc);
 //BA.debugLineNum = 1267;BA.debugLine="Dim RightSide As String";
_rightside = "";
 //BA.debugLineNum = 1268;BA.debugLine="RightSide= InputString.SubString(CommaLoc+1)";
_rightside = _inputstring.substring((int) (_commaloc+1));
 //BA.debugLineNum = 1269;BA.debugLine="OutList.Add(LeftSide)";
_outlist.Add((Object)(_leftside));
 //BA.debugLineNum = 1270;BA.debugLine="InputString=RightSide";
_inputstring = _rightside;
 //BA.debugLineNum = 1271;BA.debugLine="CommaLoc=InputString.IndexOf(Delim)";
_commaloc = _inputstring.indexOf(_delim);
 }
;
 //BA.debugLineNum = 1273;BA.debugLine="OutList.Add(InputString)";
_outlist.Add((Object)(_inputstring));
 //BA.debugLineNum = 1274;BA.debugLine="Return OutList";
if (true) return _outlist;
 //BA.debugLineNum = 1275;BA.debugLine="End Sub";
return null;
}
public String  _toproperty(String _sname,String _svalue) throws Exception{
String _script = "";
 //BA.debugLineNum = 802;BA.debugLine="private Sub ToProperty(sName As String, svalue As";
 //BA.debugLineNum = 803;BA.debugLine="sName = CStr(sName)";
_sname = _cstr((Object)(_sname));
 //BA.debugLineNum = 804;BA.debugLine="svalue = CStr(svalue)";
_svalue = _cstr((Object)(_svalue));
 //BA.debugLineNum = 805;BA.debugLine="sName = sName.Replace(\"null\",\"\")";
_sname = _sname.replace("null","");
 //BA.debugLineNum = 806;BA.debugLine="sName = sName.Replace(\"undefined\",\"\")";
_sname = _sname.replace("undefined","");
 //BA.debugLineNum = 807;BA.debugLine="svalue = svalue.Replace(\"null\",\"\")";
_svalue = _svalue.replace("null","");
 //BA.debugLineNum = 808;BA.debugLine="svalue = svalue.Replace(\"undefined\",\"\")";
_svalue = _svalue.replace("undefined","");
 //BA.debugLineNum = 809;BA.debugLine="sName = sName.Trim";
_sname = _sname.trim();
 //BA.debugLineNum = 810;BA.debugLine="svalue = svalue.trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 811;BA.debugLine="If sName.Length > 0 Then";
if (_sname.length()>0) { 
 //BA.debugLineNum = 812;BA.debugLine="Dim script As String = $\"${sName}=\"${svalue}\"\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_sname))+"=\""+__c.SmartStringFormatter("",(Object)(_svalue))+"\"");
 //BA.debugLineNum = 813;BA.debugLine="script = script.trim";
_script = _script.trim();
 //BA.debugLineNum = 814;BA.debugLine="Return script";
if (true) return _script;
 }else {
 //BA.debugLineNum = 816;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 818;BA.debugLine="End Sub";
return "";
}
public String  _tosinglequoteproperty(String _sname,String _svalue) throws Exception{
String _script = "";
 //BA.debugLineNum = 1089;BA.debugLine="private Sub ToSingleQuoteProperty(sName As String,";
 //BA.debugLineNum = 1090;BA.debugLine="Dim script As String = $\"${sName}='${svalue}'\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_sname))+"='"+__c.SmartStringFormatter("",(Object)(_svalue))+"'");
 //BA.debugLineNum = 1091;BA.debugLine="script = script.Trim";
_script = _script.trim();
 //BA.debugLineNum = 1092;BA.debugLine="If script = \"=''\" Then";
if ((_script).equals("=''")) { 
 //BA.debugLineNum = 1093;BA.debugLine="script = \"\"";
_script = "";
 };
 //BA.debugLineNum = 1095;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 1096;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
String _imgurl = "";
String _lnk = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _strcontent = "";
String _sout = "";
 //BA.debugLineNum = 1318;BA.debugLine="public Sub ToString As String";
 //BA.debugLineNum = 1319;BA.debugLine="If ParentID <> \"\" Then";
if ((_parentid).equals("") == false) { 
 //BA.debugLineNum = 1320;BA.debugLine="ID = ParentID & ID";
_id = _parentid+_id;
 };
 //BA.debugLineNum = 1322;BA.debugLine="Select Case Tag";
switch (BA.switchObjectToInt(_tag,"img","script","link")) {
case 0: 
case 1: {
 //BA.debugLineNum = 1325;BA.debugLine="Dim imgURL As String = GetAttr(\"src\")";
_imgurl = _getattr("src");
 //BA.debugLineNum = 1326;BA.debugLine="If imgURL.Length > 0 Then";
if (_imgurl.length()>0) { 
 //BA.debugLineNum = 1327;BA.debugLine="imgURL = imgURL.tolowercase";
_imgurl = _imgurl.toLowerCase();
 };
 break; }
case 2: {
 //BA.debugLineNum = 1330;BA.debugLine="Dim lnk As String = GetAttr(\"href\")";
_lnk = _getattr("href");
 //BA.debugLineNum = 1331;BA.debugLine="If lnk.Length > 0 Then";
if (_lnk.length()>0) { 
 //BA.debugLineNum = 1332;BA.debugLine="lnk = lnk.tolowercase";
_lnk = _lnk.toLowerCase();
 };
 break; }
}
;
 //BA.debugLineNum = 1335;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 1336;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 1337;BA.debugLine="sb.Append(Open)";
_sb.Append(_open());
 //BA.debugLineNum = 1338;BA.debugLine="If TextAfter = True Then";
if (_textafter==__c.True) { 
 //BA.debugLineNum = 1339;BA.debugLine="Contents.Add(Text)";
_contents.Add((Object)(_text));
 }else {
 //BA.debugLineNum = 1341;BA.debugLine="Contents.InsertAt(0,Text)";
_contents.InsertAt((int) (0),(Object)(_text));
 };
 //BA.debugLineNum = 1343;BA.debugLine="For Each strContent As String In Contents";
{
final anywheresoftware.b4a.BA.IterableList group24 = _contents;
final int groupLen24 = group24.getSize()
;int index24 = 0;
;
for (; index24 < groupLen24;index24++){
_strcontent = BA.ObjectToString(group24.Get(index24));
 //BA.debugLineNum = 1344;BA.debugLine="If strContent.Length > 0 Then";
if (_strcontent.length()>0) { 
 //BA.debugLineNum = 1345;BA.debugLine="sb.Append(strContent)";
_sb.Append(_strcontent);
 };
 }
};
 //BA.debugLineNum = 1348;BA.debugLine="sb.Append(Close)";
_sb.Append(_close());
 //BA.debugLineNum = 1349;BA.debugLine="Dim sout As String = sb.ToString";
_sout = _sb.ToString();
 //BA.debugLineNum = 1350;BA.debugLine="If DontBreak.IndexOf(Tag) <> -1 Then";
if (_dontbreak.IndexOf((Object)(_tag))!=-1) { 
 //BA.debugLineNum = 1351;BA.debugLine="sout = sout.Replace(CRLF,\"\")";
_sout = _sout.replace(__c.CRLF,"");
 };
 //BA.debugLineNum = 1354;BA.debugLine="sout = sout.Replace(CRLF,\"\")";
_sout = _sout.replace(__c.CRLF,"");
 //BA.debugLineNum = 1355;BA.debugLine="Return sout";
if (true) return _sout;
 //BA.debugLineNum = 1356;BA.debugLine="End Sub";
return "";
}
public String  _tostyle(String _sname,String _value) throws Exception{
boolean _ew = false;
String _sout = "";
 //BA.debugLineNum = 923;BA.debugLine="private Sub ToStyle(sName As String, value As Stri";
 //BA.debugLineNum = 924;BA.debugLine="If sName.Length > 0 And value.Length > 0 Then";
if (_sname.length()>0 && _value.length()>0) { 
 //BA.debugLineNum = 925;BA.debugLine="Dim ew As Boolean = sName.EndsWith(\":\")";
_ew = _sname.endsWith(":");
 //BA.debugLineNum = 926;BA.debugLine="If ew Then";
if (_ew) { 
 //BA.debugLineNum = 927;BA.debugLine="sName = MvField(sName,1,\":\")";
_sname = _mvfield(_sname,(int) (1),":");
 };
 //BA.debugLineNum = 929;BA.debugLine="Dim sout As String = $\"${sName}:${value};\"$";
_sout = (""+__c.SmartStringFormatter("",(Object)(_sname))+":"+__c.SmartStringFormatter("",(Object)(_value))+";");
 //BA.debugLineNum = 930;BA.debugLine="If sout = \":;\" Then sout = \"\"";
if ((_sout).equals(":;")) { 
_sout = "";};
 //BA.debugLineNum = 931;BA.debugLine="Return sout";
if (true) return _sout;
 }else {
 //BA.debugLineNum = 933;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 935;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoehtml  _updateattribute(String _name,String _propvalue) throws Exception{
String _svalue = "";
 //BA.debugLineNum = 254;BA.debugLine="Sub UpdateAttribute(name As String, propValue As S";
 //BA.debugLineNum = 255;BA.debugLine="If properties.ContainsKey(name) Then";
if (_properties.ContainsKey((Object)(_name))) { 
 //BA.debugLineNum = 256;BA.debugLine="Dim svalue As String = properties.Get(name)";
_svalue = BA.ObjectToString(_properties.Get((Object)(_name)));
 //BA.debugLineNum = 257;BA.debugLine="svalue = svalue & \";\" & propValue";
_svalue = _svalue+";"+_propvalue;
 //BA.debugLineNum = 258;BA.debugLine="properties.Put(name,svalue)";
_properties.Put((Object)(_name),(Object)(_svalue));
 }else {
 //BA.debugLineNum = 260;BA.debugLine="properties.Put(name,propValue)";
_properties.Put((Object)(_name),(Object)(_propvalue));
 };
 //BA.debugLineNum = 262;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoehtml)(this);
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
