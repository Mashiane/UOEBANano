package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecollections extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecollections", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecollections.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public anywheresoftware.b4a.objects.collections.Map _dropdownitems = null;
public anywheresoftware.b4a.objects.collections.Map _items = null;
public boolean _hasheaders = false;
public b4j.Mashy.UOEBANano.uoehtml _maindiv = null;
public boolean _hoverable = false;
public String _theme = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecollections  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 34;BA.debugLine="maindiv.AddAttribute(attr,value)";
_maindiv._addattribute(_attr,_value);
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub AddClass(sClass As String) As UOECollections";
 //BA.debugLineNum = 22;BA.debugLine="maindiv.AddClass(sClass)";
_maindiv._addclass(_sclass);
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _addheader(String _itemid,String _itemtext,String _itemtheme) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
 //BA.debugLineNum = 57;BA.debugLine="Sub AddHeader(itemID As String, itemText As String";
 //BA.debugLineNum = 58;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 59;BA.debugLine="hasHeaders = True";
_hasheaders = __c.True;
 //BA.debugLineNum = 60;BA.debugLine="itemText = $\"<h4>${itemText}</h4>\"$";
_itemtext = ("<h4>"+__c.SmartStringFormatter("",(Object)(_itemtext))+"</h4>");
 //BA.debugLineNum = 61;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 62;BA.debugLine="li.Initialize(itemID & \"-header\",\"li\")";
_li._initialize(ba,_itemid+"-header","li");
 //BA.debugLineNum = 63;BA.debugLine="li.AddContent(itemText)";
_li._addcontent(_itemtext);
 //BA.debugLineNum = 64;BA.debugLine="li.AddClass(\"collection-header\")";
_li._addclass("collection-header");
 //BA.debugLineNum = 65;BA.debugLine="App.MaterialUseTheme(itemTheme,li)";
_app._materialusetheme(_itemtheme,_li);
 //BA.debugLineNum = 66;BA.debugLine="Items.put(itemID.ToLowerCase,li.html)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_li._html()));
 //BA.debugLineNum = 67;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additem(String _itemid,String _iconname,String _itemtext,String _href,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchoricon _a = null;
 //BA.debugLineNum = 71;BA.debugLine="Sub AddItem(itemID As String, iconName As String,";
 //BA.debugLineNum = 72;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 73;BA.debugLine="Dim a As UOEAnchorIcon";
_a = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 74;BA.debugLine="a.Initialize(App,itemID,iconName,\"\",False,itemTex";
_a._initialize(ba,_app,_itemid,_iconname,"",__c.False,_itemtext,_href,__c.True,_itemtheme,"");
 //BA.debugLineNum = 75;BA.debugLine="a.a.MaterialCollectionItem(True)";
_a._a._materialcollectionitem(__c.True);
 //BA.debugLineNum = 76;BA.debugLine="modUOE.MaterialAddBadge(App,a.a,\"\",False,App.Enum";
_moduoe._materialaddbadge(_app,_a._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 77;BA.debugLine="Items.put(itemID.ToLowerCase,a.tostring)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_a._tostring()));
 //BA.debugLineNum = 78;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 79;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 81;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additemavatar(String _itemid,String _itemimageurl,String _itemtitle,String _itemdescription,String _itemnavigateto,String _itemtheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _title = null;
b4j.Mashy.UOEBANano.uoehtml _desc = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 143;BA.debugLine="Sub AddItemAvatar(itemID As String, itemImageURL A";
 //BA.debugLineNum = 144;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 146;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 147;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 148;BA.debugLine="li.MaterialCollectionItem(True)";
_li._materialcollectionitem(__c.True);
 //BA.debugLineNum = 149;BA.debugLine="li.MaterialAvatar(True)";
_li._materialavatar(__c.True);
 //BA.debugLineNum = 150;BA.debugLine="li.AddCursor";
_li._addcursor();
 //BA.debugLineNum = 153;BA.debugLine="modUOE.MaterialAddImage(App,li,itemImageURL,\"\",\"\"";
_moduoe._materialaddimage(_app,_li,_itemimageurl,"","","",__c.True,__c.True,__c.True,_app._imagetopmargin);
 //BA.debugLineNum = 154;BA.debugLine="Dim title As UOEHTML";
_title = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 155;BA.debugLine="title.Initialize(itemID & \"-title\",\"span\")";
_title._initialize(ba,_itemid+"-title","span");
 //BA.debugLineNum = 156;BA.debugLine="title.AddClass(\"title\")";
_title._addclass("title");
 //BA.debugLineNum = 157;BA.debugLine="title.AddContent(itemTitle)";
_title._addcontent(_itemtitle);
 //BA.debugLineNum = 158;BA.debugLine="App.MaterialUseTheme(itemTheme,title)";
_app._materialusetheme(_itemtheme,_title);
 //BA.debugLineNum = 161;BA.debugLine="Dim desc As UOEHTML";
_desc = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 162;BA.debugLine="desc.Initialize(itemID & \"-description\",\"p\")";
_desc._initialize(ba,_itemid+"-description","p");
 //BA.debugLineNum = 163;BA.debugLine="desc.AddContent(itemDescription)";
_desc._addcontent(_itemdescription);
 //BA.debugLineNum = 165;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 166;BA.debugLine="ai.Initialize(App,itemID & \"-secondary\",\"mdi-send";
_ai._initialize(ba,_app,_itemid+"-secondary","mdi-send","",__c.False,"",_itemnavigateto,__c.False,_itemtheme,_itemtheme);
 //BA.debugLineNum = 167;BA.debugLine="ai.a.MaterialSecondaryContent(True)";
_ai._a._materialsecondarycontent(__c.True);
 //BA.debugLineNum = 171;BA.debugLine="li.AddContent(title.HTML)";
_li._addcontent(_title._html());
 //BA.debugLineNum = 172;BA.debugLine="li.AddContent(desc.HTML)";
_li._addcontent(_desc._html());
 //BA.debugLineNum = 173;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 175;BA.debugLine="Items.put(itemID.ToLowerCase,li.html)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_li._html()));
 //BA.debugLineNum = 176;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 177;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 179;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 180;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additembadge(String _itemid,String _itemtext,String _href,String _badgetext,boolean _badgenew,String _itemtheme,String _badgetheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 85;BA.debugLine="Sub AddItemBadge(itemID As String, itemText As Str";
 //BA.debugLineNum = 86;BA.debugLine="maindiv.settag(\"div\")";
_maindiv._settag("div");
 //BA.debugLineNum = 87;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 88;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 89;BA.debugLine="ai.Initialize(App,itemID,\"\",\"\",False,itemText,hre";
_ai._initialize(ba,_app,_itemid,"","",__c.False,_itemtext,_href,__c.True,_itemtheme,"");
 //BA.debugLineNum = 90;BA.debugLine="ai.a.MaterialCollectionItem(True)";
_ai._a._materialcollectionitem(__c.True);
 //BA.debugLineNum = 91;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,badgeText,badgeN";
_moduoe._materialaddbadge(_app,_ai._a,_badgetext,_badgenew,_app._enumvisibility._visible,__c.True,_badgetheme,__c.False);
 //BA.debugLineNum = 92;BA.debugLine="Items.put(itemID.ToLowerCase,ai.tostring)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_ai._tostring()));
 //BA.debugLineNum = 93;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 94;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 96;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additemicon(String _itemid,String _itemicon,String _itemtitle,String _itemdescription,String _itemnavigateto,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _title = null;
b4j.Mashy.UOEBANano.uoehtml _desc = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 183;BA.debugLine="Sub AddItemIcon(itemID As String, itemIcon As Stri";
 //BA.debugLineNum = 184;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 186;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 187;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 188;BA.debugLine="li.MaterialCollectionItem(True)";
_li._materialcollectionitem(__c.True);
 //BA.debugLineNum = 189;BA.debugLine="li.MaterialAvatar(True)";
_li._materialavatar(__c.True);
 //BA.debugLineNum = 190;BA.debugLine="li.addcursor";
_li._addcursor();
 //BA.debugLineNum = 191;BA.debugLine="modUOE.MaterialAddIcon(App,li,itemIcon,\"\",iconThe";
_moduoe._materialaddicon(_app,_li,_itemicon,"",_icontheme,__c.True,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 193;BA.debugLine="Dim title As UOEHTML";
_title = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 194;BA.debugLine="title.Initialize(itemID & \"-title\",\"span\")";
_title._initialize(ba,_itemid+"-title","span");
 //BA.debugLineNum = 195;BA.debugLine="title.AddClass(\"title\")";
_title._addclass("title");
 //BA.debugLineNum = 196;BA.debugLine="title.AddContent(itemTitle)";
_title._addcontent(_itemtitle);
 //BA.debugLineNum = 197;BA.debugLine="App.MaterialUseTheme(itemTheme,title)";
_app._materialusetheme(_itemtheme,_title);
 //BA.debugLineNum = 198;BA.debugLine="li.AddContent(title.HTML)";
_li._addcontent(_title._html());
 //BA.debugLineNum = 201;BA.debugLine="Dim desc As UOEHTML";
_desc = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 202;BA.debugLine="desc.Initialize(itemID & \"-description\",\"p\")";
_desc._initialize(ba,_itemid+"-description","p");
 //BA.debugLineNum = 203;BA.debugLine="desc.AddContent(itemDescription)";
_desc._addcontent(_itemdescription);
 //BA.debugLineNum = 204;BA.debugLine="li.AddContent(desc.HTML)";
_li._addcontent(_desc._html());
 //BA.debugLineNum = 206;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 207;BA.debugLine="ai.Initialize(App,itemID & \"-secondary\",\"mdi-send";
_ai._initialize(ba,_app,_itemid+"-secondary","mdi-send","",__c.False,"",_itemnavigateto,__c.False,_itemtheme,_itemtheme);
 //BA.debugLineNum = 208;BA.debugLine="ai.a.MaterialSecondaryContent(True)";
_ai._a._materialsecondarycontent(__c.True);
 //BA.debugLineNum = 209;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,\"\",False,App.Enu";
_moduoe._materialaddbadge(_app,_ai._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 210;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 211;BA.debugLine="Items.put(itemID.ToLowerCase,li.html)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_li._html()));
 //BA.debugLineNum = 212;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 213;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 215;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additemimage(String _itemid,String _imgurl,String _itemtext,String _href,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 100;BA.debugLine="Sub AddItemImage(itemID As String, imgURL As Strin";
 //BA.debugLineNum = 101;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 103;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 104;BA.debugLine="ai.Initialize(App,itemID,\"\",\"\",False,itemText,hre";
_ai._initialize(ba,_app,_itemid,"","",__c.False,_itemtext,_href,__c.True,_itemtheme,"");
 //BA.debugLineNum = 105;BA.debugLine="ai.a.MaterialCollectionItem(True)";
_ai._a._materialcollectionitem(__c.True);
 //BA.debugLineNum = 106;BA.debugLine="modUOE.MaterialAddImage(App,ai.a,imgURL,\"\",App.Im";
_moduoe._materialaddimage(_app,_ai._a,_imgurl,"",_app._imagehw,_app._imagehw,__c.False,__c.True,__c.True,_app._imagetopmargin);
 //BA.debugLineNum = 107;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,\"\",False,App.Enu";
_moduoe._materialaddbadge(_app,_ai._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 108;BA.debugLine="Items.put(itemID.ToLowerCase,ai.tostring)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_ai._tostring()));
 //BA.debugLineNum = 109;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 110;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 112;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _additemsecondary(String _itemid,String _itemtext,String _href,String _itemicon,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _div = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 116;BA.debugLine="Sub AddItemSecondary(itemID As String, itemText As";
 //BA.debugLineNum = 117;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 118;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 119;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 120;BA.debugLine="li.MaterialCollectionItem(True)";
_li._materialcollectionitem(__c.True);
 //BA.debugLineNum = 122;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 123;BA.debugLine="div.Initialize(itemID & \"-description\",\"div\")";
_div._initialize(ba,_itemid+"-description","div");
 //BA.debugLineNum = 124;BA.debugLine="App.MaterialUseTheme(itemTheme,div)";
_app._materialusetheme(_itemtheme,_div);
 //BA.debugLineNum = 125;BA.debugLine="div.AddContent(itemText)";
_div._addcontent(_itemtext);
 //BA.debugLineNum = 127;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 128;BA.debugLine="ai.Initialize(App,itemID & \"-secondary\",itemIcon,";
_ai._initialize(ba,_app,_itemid+"-secondary",_itemicon,"",__c.False,"",_href,__c.True,_itemtheme,_icontheme);
 //BA.debugLineNum = 129;BA.debugLine="ai.a.MaterialSecondaryContent(True)";
_ai._a._materialsecondarycontent(__c.True);
 //BA.debugLineNum = 130;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,\"\",False,App.Enu";
_moduoe._materialaddbadge(_app,_ai._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 132;BA.debugLine="div.AddContent(ai.tostring)";
_div._addcontent(_ai._tostring());
 //BA.debugLineNum = 133;BA.debugLine="li.AddContent(div.HTML)";
_li._addcontent(_div._html());
 //BA.debugLineNum = 134;BA.debugLine="Items.put(itemID.ToLowerCase,li.html)";
_items.Put((Object)(_itemid.toLowerCase()),(Object)(_li._html()));
 //BA.debugLineNum = 135;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 136;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 138;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 16;BA.debugLine="maindiv.AddStyleAttribute(attribute,value)";
_maindiv._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 17;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Private DropDownItems As Map";
_dropdownitems = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 6;BA.debugLine="Private Items As Map";
_items = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 7;BA.debugLine="Private hasHeaders As Boolean";
_hasheaders = false;
 //BA.debugLineNum = 8;BA.debugLine="Private maindiv As UOEHTML";
_maindiv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 10;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 11;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 45;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 46;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 47;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 48;BA.debugLine="DropDownItems.Initialize";
_dropdownitems.Initialize();
 //BA.debugLineNum = 49;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 50;BA.debugLine="hasHeaders = False";
_hasheaders = __c.False;
 //BA.debugLineNum = 51;BA.debugLine="maindiv.Initialize(ID,\"ul\")";
_maindiv._initialize(ba,_id,"ul");
 //BA.debugLineNum = 52;BA.debugLine="maindiv.AddClass(\"collection\")";
_maindiv._addclass("collection");
 //BA.debugLineNum = 53;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecollections  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub RemoveAttribute(attr As String) As UOECollecti";
 //BA.debugLineNum = 40;BA.debugLine="maindiv.RemoveAttribute(attr)";
_maindiv._removeattribute(_attr);
 //BA.debugLineNum = 41;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollections  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub RemoveClass(sClass As String) As UOECollection";
 //BA.debugLineNum = 28;BA.debugLine="maindiv.RemoveClass(sClass)";
_maindiv._removeclass(_sclass);
 //BA.debugLineNum = 29;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollections)(this);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
String _strbutton = "";
String _strvalue = "";
 //BA.debugLineNum = 219;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 220;BA.debugLine="maindiv.ID = ID";
_maindiv._id = _id;
 //BA.debugLineNum = 221;BA.debugLine="maindiv.SetTag(\"ul\")";
_maindiv._settag("ul");
 //BA.debugLineNum = 222;BA.debugLine="If hasHeaders = True Then";
if (_hasheaders==__c.True) { 
 //BA.debugLineNum = 223;BA.debugLine="maindiv.AddClass(\"with-header\")";
_maindiv._addclass("with-header");
 };
 //BA.debugLineNum = 225;BA.debugLine="For Each strButton As String In Items.keys";
{
final anywheresoftware.b4a.BA.IterableList group6 = _items.Keys();
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_strbutton = BA.ObjectToString(group6.Get(index6));
 //BA.debugLineNum = 226;BA.debugLine="Dim strValue As String = Items.Get(strButton)";
_strvalue = BA.ObjectToString(_items.Get((Object)(_strbutton)));
 //BA.debugLineNum = 227;BA.debugLine="maindiv.AddContent(strValue)";
_maindiv._addcontent(_strvalue);
 }
};
 //BA.debugLineNum = 229;BA.debugLine="App.ApplyToolTip(ID,maindiv)";
_app._applytooltip(_id,_maindiv);
 //BA.debugLineNum = 234;BA.debugLine="Return maindiv.html";
if (true) return _maindiv._html();
 //BA.debugLineNum = 235;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
