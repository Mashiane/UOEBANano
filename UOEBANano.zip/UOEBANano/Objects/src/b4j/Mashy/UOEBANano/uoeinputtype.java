package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeinputtype extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeinputtype", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeinputtype.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _password = "";
public String _text = "";
public String _email = "";
public String _textarea = "";
public String _color = "";
public String _date = "";
public String _datetimelocal = "";
public String _month = "";
public String _number = "";
public String _range = "";
public String _search = "";
public String _tel = "";
public String _time = "";
public String _url = "";
public String _week = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public Password As String= \"password\"";
_password = "password";
 //BA.debugLineNum = 6;BA.debugLine="Public Text As String= \"text\"";
_text = "text";
 //BA.debugLineNum = 7;BA.debugLine="Public Email As String= \"email\"";
_email = "email";
 //BA.debugLineNum = 8;BA.debugLine="Public TextArea As String= \"textarea\"";
_textarea = "textarea";
 //BA.debugLineNum = 9;BA.debugLine="Public Color As String= \"color\"";
_color = "color";
 //BA.debugLineNum = 10;BA.debugLine="Public Date As String= \"date\"";
_date = "date";
 //BA.debugLineNum = 11;BA.debugLine="Public DateTimeLocal As String= \"datetime-local\"";
_datetimelocal = "datetime-local";
 //BA.debugLineNum = 12;BA.debugLine="Public Month As String= \"month\"";
_month = "month";
 //BA.debugLineNum = 13;BA.debugLine="Public Number As String= \"number\"";
_number = "number";
 //BA.debugLineNum = 14;BA.debugLine="Public Range As String= \"range\"";
_range = "range";
 //BA.debugLineNum = 15;BA.debugLine="Public Search As String= \"search\"";
_search = "search";
 //BA.debugLineNum = 16;BA.debugLine="Public Tel As String= \"tel\"";
_tel = "tel";
 //BA.debugLineNum = 17;BA.debugLine="Public Time As String= \"time\"";
_time = "time";
 //BA.debugLineNum = 18;BA.debugLine="Public URL As String= \"url\"";
_url = "url";
 //BA.debugLineNum = 19;BA.debugLine="Public Week As String= \"week\"";
_week = "week";
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
