package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoebillboardchart extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoebillboardchart", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoebillboardchart.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.collections.Map _series = null;
public String _charttype = "";
public int _rcnt = 0;
public int _rtot = 0;
public anywheresoftware.b4a.objects.collections.List _records = null;
public String _compid = "";
public b4j.Mashy.UOEBANano.uoehtml _div = null;
public boolean _enabled = false;
public String _visibility = "";
public String _zdepth = "";
public String _cheight = "";
public String _xkey = "";
public int _xangle = 0;
public b4j.Mashy.UOEBANano.uoebillboardcharttype _enumcharttype = null;
public boolean _labels = false;
public String _mtitle = "";
public anywheresoftware.b4a.objects.collections.Map _thresholds = null;
public String _ylabel = "";
public String _xlabel = "";
public boolean _rotated = false;
public int _xaxisheight = 0;
public boolean _showgrid = false;
public b4j.Mashy.UOEBANano.uoebillboardpietype _billboardpie = null;
public b4j.Mashy.UOEBANano.uoebillboardlegendtype _billboardlegend = null;
public b4j.Mashy.UOEBANano.uoebillboarddonuttype _billboarddonut = null;
public b4j.Mashy.UOEBANano.uoebillboardradartype _billboardradar = null;
public boolean _zoom = false;
public b4j.Mashy.UOEBANano.uoebillboardlegendpositiontype _billboardlegendposition = null;
public b4j.Mashy.UOEBANano.uoebillboardgaugetype _billboardgauge = null;
public String _cwidth = "";
public boolean _fitwidth = false;
public boolean _consolidate = false;
public boolean _differentcolors = false;
public boolean _bbuildgroups = false;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoebillboardchart  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 278;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 279;BA.debugLine="div.AddAttribute(attr,value)";
_div._addattribute(_attr,_value);
 //BA.debugLineNum = 280;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 281;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 266;BA.debugLine="Sub AddClass(sClass As String) As UOEBillBoardChar";
 //BA.debugLineNum = 267;BA.debugLine="div.AddClass(sClass)";
_div._addclass(_sclass);
 //BA.debugLineNum = 268;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 269;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _adddata(anywheresoftware.b4a.objects.collections.Map _m) throws Exception{
 //BA.debugLineNum = 594;BA.debugLine="Sub AddData(m As Map) As UOEBillBoardChart";
 //BA.debugLineNum = 595;BA.debugLine="records.Add(m)";
_records.Add((Object)(_m.getObject()));
 //BA.debugLineNum = 596;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 597;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addseries(String _column,String _label,String _color) throws Exception{
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
 //BA.debugLineNum = 303;BA.debugLine="Sub AddSeries(Column As String, Label As String, C";
 //BA.debugLineNum = 304;BA.debugLine="Dim seriesm As Map = CreateMap(\"column\": Column,\"";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm = __c.createMap(new Object[] {(Object)("column"),(Object)(_column),(Object)("label"),(Object)(_label),(Object)("color"),(Object)(_color),(Object)("type"),(Object)(_charttype)});
 //BA.debugLineNum = 305;BA.debugLine="series.Put(Column,seriesm)";
_series.Put((Object)(_column),(Object)(_seriesm.getObject()));
 //BA.debugLineNum = 306;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 307;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 260;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 261;BA.debugLine="div.AddStyleAttribute(attribute,value)";
_div._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 262;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy(String _x,String _y) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 740;BA.debugLine="Sub AddXY(x As String,y As String) As UOEBillBoard";
 //BA.debugLineNum = 741;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 741;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 742;BA.debugLine="yv.Add(y)";
_yv.Add((Object)(_y));
 //BA.debugLineNum = 743;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 744;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 745;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 746;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy10(String _x,String _y1,String _y2,String _y3,String _y4,String _y5,String _y6,String _y7,String _y8,String _y9,String _y10) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 722;BA.debugLine="Sub AddXY10(x As String,y1 As String,y2 As String,";
 //BA.debugLineNum = 723;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 723;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 724;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 725;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 726;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 727;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 728;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 729;BA.debugLine="yv.Add(y6)";
_yv.Add((Object)(_y6));
 //BA.debugLineNum = 730;BA.debugLine="yv.Add(y7)";
_yv.Add((Object)(_y7));
 //BA.debugLineNum = 731;BA.debugLine="yv.Add(y8)";
_yv.Add((Object)(_y8));
 //BA.debugLineNum = 732;BA.debugLine="yv.Add(y9)";
_yv.Add((Object)(_y9));
 //BA.debugLineNum = 733;BA.debugLine="yv.Add(y10)";
_yv.Add((Object)(_y10));
 //BA.debugLineNum = 734;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 735;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 736;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 737;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy2(String _x,String _y1,String _y2) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 749;BA.debugLine="Sub AddXY2(x As String,y1 As String,y2 As String)";
 //BA.debugLineNum = 751;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 751;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 752;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 753;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 754;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 755;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 756;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 757;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy3(String _x,String _y1,String _y2,String _y3) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 624;BA.debugLine="Sub AddXY3(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 625;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 625;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 626;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 627;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 628;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 629;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 630;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 631;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 632;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy4(String _x,String _y1,String _y2,String _y3,String _y4) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 635;BA.debugLine="Sub AddXY4(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 636;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 636;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 637;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 638;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 639;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 640;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 641;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 642;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 643;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 644;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy5(String _x,String _y1,String _y2,String _y3,String _y4,String _y5) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 647;BA.debugLine="Sub AddXY5(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 648;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 648;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 649;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 650;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 651;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 652;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 653;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 654;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 655;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 656;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 657;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy6(String _x,String _y1,String _y2,String _y3,String _y4,String _y5,String _y6) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 660;BA.debugLine="Sub AddXY6(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 661;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 661;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 662;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 663;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 664;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 665;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 666;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 667;BA.debugLine="yv.Add(y6)";
_yv.Add((Object)(_y6));
 //BA.debugLineNum = 668;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 669;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 670;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 671;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy7(String _x,String _y1,String _y2,String _y3,String _y4,String _y5,String _y6,String _y7) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 674;BA.debugLine="Sub AddXY7(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 675;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 675;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 676;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 677;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 678;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 679;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 680;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 681;BA.debugLine="yv.Add(y6)";
_yv.Add((Object)(_y6));
 //BA.debugLineNum = 682;BA.debugLine="yv.Add(y7)";
_yv.Add((Object)(_y7));
 //BA.debugLineNum = 683;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 684;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 685;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 686;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy8(String _x,String _y1,String _y2,String _y3,String _y4,String _y5,String _y6,String _y7,String _y8) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 689;BA.debugLine="Sub AddXY8(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 690;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 690;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 691;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 692;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 693;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 694;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 695;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 696;BA.debugLine="yv.Add(y6)";
_yv.Add((Object)(_y6));
 //BA.debugLineNum = 697;BA.debugLine="yv.Add(y7)";
_yv.Add((Object)(_y7));
 //BA.debugLineNum = 698;BA.debugLine="yv.Add(y8)";
_yv.Add((Object)(_y8));
 //BA.debugLineNum = 699;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 700;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 701;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 702;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _addxy9(String _x,String _y1,String _y2,String _y3,String _y4,String _y5,String _y6,String _y7,String _y8,String _y9) throws Exception{
anywheresoftware.b4a.objects.collections.List _yv = null;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
 //BA.debugLineNum = 705;BA.debugLine="Sub AddXY9(x As String,y1 As String,y2 As String,y";
 //BA.debugLineNum = 706;BA.debugLine="Dim yv As List: yv.initialize";
_yv = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 706;BA.debugLine="Dim yv As List: yv.initialize";
_yv.Initialize();
 //BA.debugLineNum = 707;BA.debugLine="yv.Add(y1)";
_yv.Add((Object)(_y1));
 //BA.debugLineNum = 708;BA.debugLine="yv.Add(y2)";
_yv.Add((Object)(_y2));
 //BA.debugLineNum = 709;BA.debugLine="yv.Add(y3)";
_yv.Add((Object)(_y3));
 //BA.debugLineNum = 710;BA.debugLine="yv.Add(y4)";
_yv.Add((Object)(_y4));
 //BA.debugLineNum = 711;BA.debugLine="yv.Add(y5)";
_yv.Add((Object)(_y5));
 //BA.debugLineNum = 712;BA.debugLine="yv.Add(y6)";
_yv.Add((Object)(_y6));
 //BA.debugLineNum = 713;BA.debugLine="yv.Add(y7)";
_yv.Add((Object)(_y7));
 //BA.debugLineNum = 714;BA.debugLine="yv.Add(y8)";
_yv.Add((Object)(_y8));
 //BA.debugLineNum = 715;BA.debugLine="yv.Add(y9)";
_yv.Add((Object)(_y9));
 //BA.debugLineNum = 716;BA.debugLine="Dim mrec As Map = CreateRecord(x,yv)";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
_mrec = _createrecord(_x,_yv);
 //BA.debugLineNum = 717;BA.debugLine="AddData(mrec)";
_adddata(_mrec);
 //BA.debugLineNum = 718;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 719;BA.debugLine="End Sub";
return null;
}
public String  _buildcolors() throws Exception{
String _script = "";
 //BA.debugLineNum = 567;BA.debugLine="private Sub BuildColors() As String";
 //BA.debugLineNum = 568;BA.debugLine="If ChartType = EnumChartType.gauge Then";
if ((_charttype).equals(_enumcharttype._gauge)) { 
 //BA.debugLineNum = 569;BA.debugLine="Dim script As String = $\"color: {     pattern: [";
_script = ("color: {\n"+"    pattern: [\n"+"      "+__c.SmartStringFormatter("",(Object)(_buildpatterns()))+"\n"+"    ],\n"+"    threshold: {\n"+"      values: [\n"+"        "+__c.SmartStringFormatter("",(Object)(_buildvalues()))+"\n"+"      ]\n"+"    }\n"+"  },");
 //BA.debugLineNum = 579;BA.debugLine="Return script";
if (true) return _script;
 }else {
 //BA.debugLineNum = 581;BA.debugLine="Return $\"colors: { 		${BuildSeriesColors} 		},\"$";
if (true) return ("colors: {\n"+"		"+__c.SmartStringFormatter("",(Object)(_buildseriescolors()))+"\n"+"		},");
 };
 //BA.debugLineNum = 585;BA.debugLine="End Sub";
return "";
}
public String  _buildcolumndata(String _column) throws Exception{
anywheresoftware.b4a.objects.collections.List _xaxis = null;
anywheresoftware.b4a.objects.collections.Map _em = null;
String _skey = "";
 //BA.debugLineNum = 290;BA.debugLine="private Sub BuildColumnData(Column As String) As S";
 //BA.debugLineNum = 291;BA.debugLine="Dim xaxis As List";
_xaxis = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 292;BA.debugLine="xaxis.Initialize";
_xaxis.Initialize();
 //BA.debugLineNum = 293;BA.debugLine="rTot = records.Size - 1";
_rtot = (int) (_records.getSize()-1);
 //BA.debugLineNum = 294;BA.debugLine="For rCnt = 0 To rTot";
{
final int step4 = 1;
final int limit4 = _rtot;
_rcnt = (int) (0) ;
for (;_rcnt <= limit4 ;_rcnt = _rcnt + step4 ) {
 //BA.debugLineNum = 295;BA.debugLine="Dim em As Map = records.Get(rCnt)";
_em = new anywheresoftware.b4a.objects.collections.Map();
_em.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_records.Get(_rcnt)));
 //BA.debugLineNum = 296;BA.debugLine="Dim skey As String = em.GetDefault(Column,\"\")";
_skey = BA.ObjectToString(_em.GetDefault((Object)(_column),(Object)("")));
 //BA.debugLineNum = 297;BA.debugLine="xaxis.Add(skey)";
_xaxis.Add((Object)(_skey));
 }
};
 //BA.debugLineNum = 299;BA.debugLine="Return App.Join(\",\",xaxis)";
if (true) return _app._join(",",_xaxis);
 //BA.debugLineNum = 300;BA.debugLine="End Sub";
return "";
}
public String  _buildcolumns() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _stot = 0;
int _scnt = 0;
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
String _sname = "";
anywheresoftware.b4a.objects.collections.List _ydatalist = null;
String _ydata = "";
 //BA.debugLineNum = 153;BA.debugLine="private Sub BuildColumns() As String";
 //BA.debugLineNum = 154;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 155;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 156;BA.debugLine="Dim sTot As Int = series.Size - 1";
_stot = (int) (_series.getSize()-1);
 //BA.debugLineNum = 157;BA.debugLine="Dim sCnt As Int";
_scnt = 0;
 //BA.debugLineNum = 158;BA.debugLine="For sCnt = 0 To sTot";
{
final int step5 = 1;
final int limit5 = _stot;
_scnt = (int) (0) ;
for (;_scnt <= limit5 ;_scnt = _scnt + step5 ) {
 //BA.debugLineNum = 159;BA.debugLine="Dim seriesm As Map = series.GetValueAt(sCnt)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_scnt)));
 //BA.debugLineNum = 160;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 162;BA.debugLine="Dim yDataList As List = App.MapProperty2List(rec";
_ydatalist = new anywheresoftware.b4a.objects.collections.List();
_ydatalist = _app._mapproperty2list(_records,_sname,"0");
 //BA.debugLineNum = 163;BA.debugLine="Dim yData As String = App.Join(\",\",yDataList)";
_ydata = _app._join(",",_ydatalist);
 //BA.debugLineNum = 164;BA.debugLine="sb.Append($\"[\"${sname}\",${yData}],\"$)";
_sb.Append(("[\""+__c.SmartStringFormatter("",(Object)(_sname))+"\","+__c.SmartStringFormatter("",(Object)(_ydata))+"],"));
 }
};
 //BA.debugLineNum = 166;BA.debugLine="Return App.RemDelim(sb.ToString,\",\")";
if (true) return _app._remdelim(_sb.ToString(),",");
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return "";
}
public String  _builddifferentcolors() throws Exception{
String _script = "";
 //BA.debugLineNum = 124;BA.debugLine="private Sub BuildDifferentColors() As String";
 //BA.debugLineNum = 125;BA.debugLine="If DifferentColors = False Then Return \"\"";
if (_differentcolors==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 126;BA.debugLine="Dim script As String = $\"color: function(color, d";
_script = ("color: function(color, d) {\n"+"	return colors[d.index];\n"+"   },");
 //BA.debugLineNum = 129;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
return "";
}
public String  _buildgroups() throws Exception{
String _script = "";
 //BA.debugLineNum = 399;BA.debugLine="private Sub BuildGroups() As String";
 //BA.debugLineNum = 400;BA.debugLine="If bBuildGroups = False Then Return \"\"";
if (_bbuildgroups==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 401;BA.debugLine="Dim script As String = $\"groups: [       [";
_script = ("groups: [\n"+"      [\n"+"        "+__c.SmartStringFormatter("",(Object)(_buildseriesnames()))+"\n"+"      ]\n"+"    ],");
 //BA.debugLineNum = 406;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 407;BA.debugLine="End Sub";
return "";
}
public String  _buildlabels() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _stot = 0;
int _scnt = 0;
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
String _sname = "";
String _stype = "";
String _xout = "";
 //BA.debugLineNum = 213;BA.debugLine="private Sub BuildLabels() As String";
 //BA.debugLineNum = 214;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 215;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 216;BA.debugLine="sb.Append(\"names: {\")";
_sb.Append("names: {");
 //BA.debugLineNum = 217;BA.debugLine="Dim sTot As Int = series.Size - 1";
_stot = (int) (_series.getSize()-1);
 //BA.debugLineNum = 218;BA.debugLine="Dim sCnt As Int";
_scnt = 0;
 //BA.debugLineNum = 219;BA.debugLine="For sCnt = 0 To sTot";
{
final int step6 = 1;
final int limit6 = _stot;
_scnt = (int) (0) ;
for (;_scnt <= limit6 ;_scnt = _scnt + step6 ) {
 //BA.debugLineNum = 220;BA.debugLine="Dim seriesm As Map = series.GetValueAt(sCnt)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_scnt)));
 //BA.debugLineNum = 221;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 222;BA.debugLine="Dim stype As String = seriesm.Get(\"label\")";
_stype = BA.ObjectToString(_seriesm.Get((Object)("label")));
 //BA.debugLineNum = 223;BA.debugLine="sb.Append($\"${sname}:\"${stype}\",\"$)";
_sb.Append((""+__c.SmartStringFormatter("",(Object)(_sname))+":\""+__c.SmartStringFormatter("",(Object)(_stype))+"\","));
 }
};
 //BA.debugLineNum = 225;BA.debugLine="Dim xout As String = App.RemDelim(sb.ToString,\",\"";
_xout = _app._remdelim(_sb.ToString(),",");
 //BA.debugLineNum = 226;BA.debugLine="xout = xout & \"},\"";
_xout = _xout+"},";
 //BA.debugLineNum = 227;BA.debugLine="Return xout";
if (true) return _xout;
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return "";
}
public String  _buildpatterns() throws Exception{
anywheresoftware.b4a.objects.collections.List _lcolors = null;
int _ttot = 0;
int _tcnt = 0;
String _scolor = "";
 //BA.debugLineNum = 331;BA.debugLine="private Sub BuildPatterns() As String";
 //BA.debugLineNum = 332;BA.debugLine="Dim lColors As List";
_lcolors = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 333;BA.debugLine="lColors.Initialize";
_lcolors.Initialize();
 //BA.debugLineNum = 334;BA.debugLine="Dim tTot As Int = thresholds.Size - 1";
_ttot = (int) (_thresholds.getSize()-1);
 //BA.debugLineNum = 335;BA.debugLine="Dim tCnt As Int";
_tcnt = 0;
 //BA.debugLineNum = 336;BA.debugLine="For tCnt = 0 To tTot";
{
final int step5 = 1;
final int limit5 = _ttot;
_tcnt = (int) (0) ;
for (;_tcnt <= limit5 ;_tcnt = _tcnt + step5 ) {
 //BA.debugLineNum = 337;BA.debugLine="Dim sColor As String = thresholds.GetValueAt(tCn";
_scolor = BA.ObjectToString(_thresholds.GetValueAt(_tcnt));
 //BA.debugLineNum = 338;BA.debugLine="sColor = QUOTE & sColor & QUOTE";
_scolor = __c.QUOTE+_scolor+__c.QUOTE;
 //BA.debugLineNum = 339;BA.debugLine="lColors.Add(sColor)";
_lcolors.Add((Object)(_scolor));
 }
};
 //BA.debugLineNum = 341;BA.debugLine="Return App.Join(\",\", lColors)";
if (true) return _app._join(",",_lcolors);
 //BA.debugLineNum = 342;BA.debugLine="End Sub";
return "";
}
public String  _buildseriescolors() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _stot = 0;
int _scnt = 0;
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
String _sname = "";
String _stype = "";
 //BA.debugLineNum = 230;BA.debugLine="private Sub BuildSeriesColors() As String";
 //BA.debugLineNum = 231;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 232;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 233;BA.debugLine="Dim sTot As Int = series.Size - 1";
_stot = (int) (_series.getSize()-1);
 //BA.debugLineNum = 234;BA.debugLine="Dim sCnt As Int";
_scnt = 0;
 //BA.debugLineNum = 235;BA.debugLine="For sCnt = 0 To sTot";
{
final int step5 = 1;
final int limit5 = _stot;
_scnt = (int) (0) ;
for (;_scnt <= limit5 ;_scnt = _scnt + step5 ) {
 //BA.debugLineNum = 236;BA.debugLine="Dim seriesm As Map = series.GetValueAt(sCnt)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_scnt)));
 //BA.debugLineNum = 237;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 238;BA.debugLine="Dim stype As String = seriesm.Get(\"color\")";
_stype = BA.ObjectToString(_seriesm.Get((Object)("color")));
 //BA.debugLineNum = 239;BA.debugLine="sb.Append($\"${sname}:\"${stype}\",\"$)";
_sb.Append((""+__c.SmartStringFormatter("",(Object)(_sname))+":\""+__c.SmartStringFormatter("",(Object)(_stype))+"\","));
 }
};
 //BA.debugLineNum = 241;BA.debugLine="Return App.RemDelim(sb.ToString,\",\")";
if (true) return _app._remdelim(_sb.ToString(),",");
 //BA.debugLineNum = 242;BA.debugLine="End Sub";
return "";
}
public String  _buildseriesnames() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _stot = 0;
int _scnt = 0;
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
String _sname = "";
 //BA.debugLineNum = 245;BA.debugLine="private Sub BuildSeriesNames() As String";
 //BA.debugLineNum = 246;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 247;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 248;BA.debugLine="Dim sTot As Int = series.Size - 1";
_stot = (int) (_series.getSize()-1);
 //BA.debugLineNum = 249;BA.debugLine="Dim sCnt As Int";
_scnt = 0;
 //BA.debugLineNum = 250;BA.debugLine="For sCnt = 0 To sTot";
{
final int step5 = 1;
final int limit5 = _stot;
_scnt = (int) (0) ;
for (;_scnt <= limit5 ;_scnt = _scnt + step5 ) {
 //BA.debugLineNum = 251;BA.debugLine="Dim seriesm As Map = series.GetValueAt(sCnt)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_scnt)));
 //BA.debugLineNum = 252;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 253;BA.debugLine="sb.Append($\"\"${sname}\",\"$)";
_sb.Append(("\""+__c.SmartStringFormatter("",(Object)(_sname))+"\","));
 }
};
 //BA.debugLineNum = 255;BA.debugLine="Return App.RemDelim(sb.ToString,\",\")";
if (true) return _app._remdelim(_sb.ToString(),",");
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _buildsize() throws Exception{
String _script = "";
 //BA.debugLineNum = 409;BA.debugLine="private Sub BuildSize() As String";
 //BA.debugLineNum = 410;BA.debugLine="Dim script As String = $\"size: {     height: ${cH";
_script = ("size: {\n"+"    height: "+__c.SmartStringFormatter("",(Object)(_cheight))+",\n"+"	width: "+__c.SmartStringFormatter("",(Object)(_cwidth))+"\n"+"  },");
 //BA.debugLineNum = 414;BA.debugLine="If FitWidth Then";
if (_fitwidth) { 
 //BA.debugLineNum = 415;BA.debugLine="script = $\"size: {     height: ${cHeight}   },\"$";
_script = ("size: {\n"+"    height: "+__c.SmartStringFormatter("",(Object)(_cheight))+"\n"+"  },");
 };
 //BA.debugLineNum = 419;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 420;BA.debugLine="End Sub";
return "";
}
public String  _buildtypes() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sbx = null;
int _stot = 0;
int _scnt = 0;
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
String _sname = "";
String _stype = "";
 //BA.debugLineNum = 170;BA.debugLine="private Sub BuildTypes() As String";
 //BA.debugLineNum = 171;BA.debugLine="Dim sbx As StringBuilder";
_sbx = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 172;BA.debugLine="sbx.Initialize";
_sbx.Initialize();
 //BA.debugLineNum = 173;BA.debugLine="sbx.Append(\"types: {\")";
_sbx.Append("types: {");
 //BA.debugLineNum = 174;BA.debugLine="sbx.Append(CRLF)";
_sbx.Append(__c.CRLF);
 //BA.debugLineNum = 175;BA.debugLine="Dim sTot As Int = series.Size - 1";
_stot = (int) (_series.getSize()-1);
 //BA.debugLineNum = 176;BA.debugLine="Dim sCnt As Int";
_scnt = 0;
 //BA.debugLineNum = 177;BA.debugLine="If sTot >= 0 Then";
if (_stot>=0) { 
 //BA.debugLineNum = 179;BA.debugLine="Dim seriesm As Map = series.GetValueAt(0)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt((int) (0))));
 //BA.debugLineNum = 180;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 181;BA.debugLine="Dim stype As String = seriesm.Get(\"type\")";
_stype = BA.ObjectToString(_seriesm.Get((Object)("type")));
 //BA.debugLineNum = 182;BA.debugLine="stype = stype.Replace(\"horizontalbar\",\"bar\")";
_stype = _stype.replace("horizontalbar","bar");
 //BA.debugLineNum = 183;BA.debugLine="stype = stype.Replace(\"stackedbar\",\"bar\")";
_stype = _stype.replace("stackedbar","bar");
 //BA.debugLineNum = 184;BA.debugLine="stype = stype.Replace(\"grouped-bar\",\"bar\")";
_stype = _stype.replace("grouped-bar","bar");
 //BA.debugLineNum = 185;BA.debugLine="If stype.Length > 0 Then";
if (_stype.length()>0) { 
 //BA.debugLineNum = 186;BA.debugLine="sbx.Append($\"${sname}:\"${stype}\"$)";
_sbx.Append((""+__c.SmartStringFormatter("",(Object)(_sname))+":\""+__c.SmartStringFormatter("",(Object)(_stype))+""));
 };
 //BA.debugLineNum = 188;BA.debugLine="For sCnt = 1 To sTot";
{
final int step17 = 1;
final int limit17 = _stot;
_scnt = (int) (1) ;
for (;_scnt <= limit17 ;_scnt = _scnt + step17 ) {
 //BA.debugLineNum = 189;BA.debugLine="Dim seriesm As Map = series.GetValueAt(sCnt)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_scnt)));
 //BA.debugLineNum = 190;BA.debugLine="Dim sname As String = seriesm.Get(\"column\")";
_sname = BA.ObjectToString(_seriesm.Get((Object)("column")));
 //BA.debugLineNum = 191;BA.debugLine="Dim stype As String = seriesm.Get(\"type\")";
_stype = BA.ObjectToString(_seriesm.Get((Object)("type")));
 //BA.debugLineNum = 192;BA.debugLine="stype = stype.Replace(\"horizontalbar\",\"bar\")";
_stype = _stype.replace("horizontalbar","bar");
 //BA.debugLineNum = 193;BA.debugLine="stype = stype.Replace(\"stackedbar\",\"bar\")";
_stype = _stype.replace("stackedbar","bar");
 //BA.debugLineNum = 194;BA.debugLine="stype = stype.Replace(\"grouped-bar\",\"bar\")";
_stype = _stype.replace("grouped-bar","bar");
 //BA.debugLineNum = 195;BA.debugLine="If stype.Length > 0 Then";
if (_stype.length()>0) { 
 //BA.debugLineNum = 196;BA.debugLine="sbx.Append(\",\")";
_sbx.Append(",");
 //BA.debugLineNum = 197;BA.debugLine="sbx.Append($\"${sname}:\"${stype}\"$)";
_sbx.Append((""+__c.SmartStringFormatter("",(Object)(_sname))+":\""+__c.SmartStringFormatter("",(Object)(_stype))+""));
 };
 }
};
 };
 //BA.debugLineNum = 201;BA.debugLine="sbx.Append(\"},\")";
_sbx.Append("},");
 //BA.debugLineNum = 202;BA.debugLine="Return sbx.tostring";
if (true) return _sbx.ToString();
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
return "";
}
public String  _buildvalues() throws Exception{
anywheresoftware.b4a.objects.collections.List _lcolors = null;
int _ttot = 0;
int _tcnt = 0;
String _scolor = "";
 //BA.debugLineNum = 345;BA.debugLine="private Sub BuildValues() As String";
 //BA.debugLineNum = 346;BA.debugLine="Dim lColors As List";
_lcolors = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 347;BA.debugLine="lColors.Initialize";
_lcolors.Initialize();
 //BA.debugLineNum = 348;BA.debugLine="Dim tTot As Int = thresholds.Size - 1";
_ttot = (int) (_thresholds.getSize()-1);
 //BA.debugLineNum = 349;BA.debugLine="Dim tCnt As Int";
_tcnt = 0;
 //BA.debugLineNum = 350;BA.debugLine="For tCnt = 0 To tTot";
{
final int step5 = 1;
final int limit5 = _ttot;
_tcnt = (int) (0) ;
for (;_tcnt <= limit5 ;_tcnt = _tcnt + step5 ) {
 //BA.debugLineNum = 351;BA.debugLine="Dim sColor As String = thresholds.GetKeyAt(tCnt)";
_scolor = BA.ObjectToString(_thresholds.GetKeyAt(_tcnt));
 //BA.debugLineNum = 352;BA.debugLine="lColors.Add(sColor)";
_lcolors.Add((Object)(_scolor));
 }
};
 //BA.debugLineNum = 354;BA.debugLine="Return App.Join(\",\", lColors)";
if (true) return _app._join(",",_lcolors);
 //BA.debugLineNum = 355;BA.debugLine="End Sub";
return "";
}
public String  _buildxaxis() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
anywheresoftware.b4a.objects.collections.List _ydatalist = null;
String _ydata = "";
 //BA.debugLineNum = 142;BA.debugLine="private Sub BuildXAxis() As String";
 //BA.debugLineNum = 143;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 144;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 145;BA.debugLine="sb.Append($\"[\"x\", \"$)";
_sb.Append(("[\"x\", "));
 //BA.debugLineNum = 146;BA.debugLine="Dim yDataList As List = App.MapProperty2ListQuote";
_ydatalist = new anywheresoftware.b4a.objects.collections.List();
_ydatalist = _app._mapproperty2listquote(_records,_xkey,"");
 //BA.debugLineNum = 147;BA.debugLine="Dim yData As String = App.Join(\",\",yDataList)";
_ydata = _app._join(",",_ydatalist);
 //BA.debugLineNum = 148;BA.debugLine="sb.append(yData).Append(\"]\")";
_sb.Append(_ydata).Append("]");
 //BA.debugLineNum = 149;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private series As Map";
_series = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 5;BA.debugLine="Public ChartType As String";
_charttype = "";
 //BA.debugLineNum = 6;BA.debugLine="Private rCnt As Int";
_rcnt = 0;
 //BA.debugLineNum = 7;BA.debugLine="Private rTot As Int";
_rtot = 0;
 //BA.debugLineNum = 8;BA.debugLine="Private records As List";
_records = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 9;BA.debugLine="Private CompID As String";
_compid = "";
 //BA.debugLineNum = 10;BA.debugLine="Private div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Private cHeight As String";
_cheight = "";
 //BA.debugLineNum = 15;BA.debugLine="Private xkey As String";
_xkey = "";
 //BA.debugLineNum = 16;BA.debugLine="Private xangle As Int";
_xangle = 0;
 //BA.debugLineNum = 17;BA.debugLine="Public EnumChartType As UOEBillboardChartType";
_enumcharttype = new b4j.Mashy.UOEBANano.uoebillboardcharttype();
 //BA.debugLineNum = 18;BA.debugLine="Private Labels As Boolean";
_labels = false;
 //BA.debugLineNum = 19;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 20;BA.debugLine="Private thresholds As Map";
_thresholds = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 21;BA.debugLine="Public YLabel As String";
_ylabel = "";
 //BA.debugLineNum = 22;BA.debugLine="Public XLabel As String";
_xlabel = "";
 //BA.debugLineNum = 23;BA.debugLine="Private rotated As Boolean";
_rotated = false;
 //BA.debugLineNum = 24;BA.debugLine="Private XAxisHeight As Int";
_xaxisheight = 0;
 //BA.debugLineNum = 25;BA.debugLine="Public ShowGrid As Boolean";
_showgrid = false;
 //BA.debugLineNum = 26;BA.debugLine="Public BillBoardPie As UOEBillBoardPieType";
_billboardpie = new b4j.Mashy.UOEBANano.uoebillboardpietype();
 //BA.debugLineNum = 27;BA.debugLine="Public BillBoardLegend As UOEBillBoardLegendType";
_billboardlegend = new b4j.Mashy.UOEBANano.uoebillboardlegendtype();
 //BA.debugLineNum = 28;BA.debugLine="Public BillBoardDonut As UOEBillBoardDonutType";
_billboarddonut = new b4j.Mashy.UOEBANano.uoebillboarddonuttype();
 //BA.debugLineNum = 29;BA.debugLine="Public BillBoardRadar As UOEBillBoardRadarType";
_billboardradar = new b4j.Mashy.UOEBANano.uoebillboardradartype();
 //BA.debugLineNum = 30;BA.debugLine="Public Zoom As Boolean";
_zoom = false;
 //BA.debugLineNum = 31;BA.debugLine="Public BillboardLegendPosition As UOEBillboardLeg";
_billboardlegendposition = new b4j.Mashy.UOEBANano.uoebillboardlegendpositiontype();
 //BA.debugLineNum = 32;BA.debugLine="Public BillBoardGauge As UOEBillBoardGaugeType";
_billboardgauge = new b4j.Mashy.UOEBANano.uoebillboardgaugetype();
 //BA.debugLineNum = 33;BA.debugLine="Private mTitle As String";
_mtitle = "";
 //BA.debugLineNum = 34;BA.debugLine="Private cWidth As String";
_cwidth = "";
 //BA.debugLineNum = 35;BA.debugLine="Public FitWidth As Boolean";
_fitwidth = false;
 //BA.debugLineNum = 36;BA.debugLine="Public Consolidate As Boolean";
_consolidate = false;
 //BA.debugLineNum = 37;BA.debugLine="Public DifferentColors As Boolean";
_differentcolors = false;
 //BA.debugLineNum = 38;BA.debugLine="Private bBuildGroups As Boolean";
_bbuildgroups = false;
 //BA.debugLineNum = 39;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _clear() throws Exception{
 //BA.debugLineNum = 133;BA.debugLine="Sub Clear As UOEBillBoardChart";
 //BA.debugLineNum = 134;BA.debugLine="series.Initialize";
_series.Initialize();
 //BA.debugLineNum = 135;BA.debugLine="series.clear";
_series.Clear();
 //BA.debugLineNum = 136;BA.debugLine="records.Initialize";
_records.Initialize();
 //BA.debugLineNum = 137;BA.debugLine="records.clear";
_records.Clear();
 //BA.debugLineNum = 138;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 139;BA.debugLine="End Sub";
return null;
}
public anywheresoftware.b4a.objects.collections.Map  _createrecord(String _x,anywheresoftware.b4a.objects.collections.List _yv) throws Exception{
int _mtot = 0;
int _mcnt = 0;
anywheresoftware.b4a.objects.collections.Map _mrec = null;
anywheresoftware.b4a.objects.collections.Map _ym = null;
String _cl = "";
String _vy = "";
 //BA.debugLineNum = 608;BA.debugLine="private Sub CreateRecord(x As String, yv As List)";
 //BA.debugLineNum = 609;BA.debugLine="Dim mtot As Int = yv.Size - 1";
_mtot = (int) (_yv.getSize()-1);
 //BA.debugLineNum = 610;BA.debugLine="Dim mcnt As Int";
_mcnt = 0;
 //BA.debugLineNum = 611;BA.debugLine="Dim mrec As Map: mrec.initialize";
_mrec = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 611;BA.debugLine="Dim mrec As Map: mrec.initialize";
_mrec.Initialize();
 //BA.debugLineNum = 612;BA.debugLine="mrec.Put(xkey,x)";
_mrec.Put((Object)(_xkey),(Object)(_x));
 //BA.debugLineNum = 614;BA.debugLine="For mcnt = 0 To mtot";
{
final int step6 = 1;
final int limit6 = _mtot;
_mcnt = (int) (0) ;
for (;_mcnt <= limit6 ;_mcnt = _mcnt + step6 ) {
 //BA.debugLineNum = 615;BA.debugLine="Dim ym As Map = series.GetValueAt(mcnt)";
_ym = new anywheresoftware.b4a.objects.collections.Map();
_ym.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.GetValueAt(_mcnt)));
 //BA.debugLineNum = 616;BA.debugLine="Dim cl As String = ym.GetDefault(\"column\",\"\")";
_cl = BA.ObjectToString(_ym.GetDefault((Object)("column"),(Object)("")));
 //BA.debugLineNum = 617;BA.debugLine="Dim vy As String = yv.Get(mcnt)";
_vy = BA.ObjectToString(_yv.Get(_mcnt));
 //BA.debugLineNum = 618;BA.debugLine="mrec.Put(cl,vy)";
_mrec.Put((Object)(_cl),(Object)(_vy));
 }
};
 //BA.debugLineNum = 620;BA.debugLine="Return mrec";
if (true) return _mrec;
 //BA.debugLineNum = 621;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _gaugeaddthreshold(int _ivalue,String _scolor) throws Exception{
 //BA.debugLineNum = 110;BA.debugLine="Sub GaugeAddThreshold(iValue As Int, sColor As Str";
 //BA.debugLineNum = 111;BA.debugLine="thresholds.Put(iValue,sColor)";
_thresholds.Put((Object)(_ivalue),(Object)(_scolor));
 //BA.debugLineNum = 112;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return null;
}
public String  _getcharttype() throws Exception{
String _stype = "";
 //BA.debugLineNum = 205;BA.debugLine="private Sub GetChartType() As String";
 //BA.debugLineNum = 206;BA.debugLine="Dim stype As String = ChartType";
_stype = _charttype;
 //BA.debugLineNum = 207;BA.debugLine="stype = stype.Replace(\"horizontalbar\",\"bar\")";
_stype = _stype.replace("horizontalbar","bar");
 //BA.debugLineNum = 208;BA.debugLine="stype = stype.Replace(\"stackedbar\",\"bar\")";
_stype = _stype.replace("stackedbar","bar");
 //BA.debugLineNum = 209;BA.debugLine="stype = stype.Replace(\"grouped-bar\",\"bar\")";
_stype = _stype.replace("grouped-bar","bar");
 //BA.debugLineNum = 210;BA.debugLine="Return stype";
if (true) return _stype;
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _slbl = "";
String _sfc = "";
String _psl = "";
String _art = "";
String _gxs = "";
String _gys = "";
String _zoe = "";
String _lgs = "";
String _leq = "";
String _lep = "";
String _leup = "";
String _rsl = "";
String _rst = "";
String _rslt = "";
String _dsl = "";
String _script = "";
 //BA.debugLineNum = 422;BA.debugLine="Sub GetJavaScript As String";
 //BA.debugLineNum = 423;BA.debugLine="If series.Size -1 = -1 Then";
if (_series.getSize()-1==-1) { 
 //BA.debugLineNum = 424;BA.debugLine="Log($\"UOEBillBoardChart: '${CompID}' please add";
__c.Log(("UOEBillBoardChart: '"+__c.SmartStringFormatter("",(Object)(_compid))+"' please add at least 1 single series to the chart"));
 //BA.debugLineNum = 425;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 427;BA.debugLine="If xkey.Length = 0 Then";
if (_xkey.length()==0) { 
 //BA.debugLineNum = 428;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._gauge,_enumcharttype._donut,_enumcharttype._pie)) {
case 0: 
case 1: 
case 2: {
 break; }
default: {
 //BA.debugLineNum = 431;BA.debugLine="Log($\"UOEBillBoardChart: '${CompID}' please spe";
__c.Log(("UOEBillBoardChart: '"+__c.SmartStringFormatter("",(Object)(_compid))+"' please specify the X Axis with SetXAxis Method"));
 //BA.debugLineNum = 432;BA.debugLine="Return \"\"";
if (true) return "";
 break; }
}
;
 };
 //BA.debugLineNum = 435;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._horizontalbar,_enumcharttype._groupedbar,_enumcharttype._stackedbar,_enumcharttype._donut,_enumcharttype._gauge)) {
case 0: {
 //BA.debugLineNum = 437;BA.debugLine="rotated = True";
_rotated = __c.True;
 break; }
case 1: {
 //BA.debugLineNum = 439;BA.debugLine="bBuildGroups = True";
_bbuildgroups = __c.True;
 break; }
case 2: {
 //BA.debugLineNum = 441;BA.debugLine="bBuildGroups = True";
_bbuildgroups = __c.True;
 break; }
case 3: {
 //BA.debugLineNum = 444;BA.debugLine="BillBoardGauge.Width = BillBoardDonut.Width";
_billboardgauge._width = _billboarddonut._width;
 break; }
case 4: {
 //BA.debugLineNum = 447;BA.debugLine="BillBoardDonut.Width = BillBoardGauge.Width";
_billboarddonut._width = _billboardgauge._width;
 break; }
}
;
 //BA.debugLineNum = 449;BA.debugLine="Dim slbl As String = App.iif(Labels=True,\"true\",F";
_slbl = BA.ObjectToString(_app._iif(BA.ObjectToString(_labels==__c.True),(Object)("true"),(Object)(__c.False)));
 //BA.debugLineNum = 450;BA.debugLine="Dim sfc As String = App.iif(BillBoardGauge.FullCi";
_sfc = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardgauge._fullcircle==__c.True),(Object)("true"),(Object)(__c.False)));
 //BA.debugLineNum = 451;BA.debugLine="Dim psl As String = App.iif(BillBoardPie.ShowLabe";
_psl = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardpie._showlabel==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 452;BA.debugLine="Dim art As String = App.iif(rotated=True,\"true\",\"";
_art = BA.ObjectToString(_app._iif(BA.ObjectToString(_rotated==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 453;BA.debugLine="Dim gxs As String = App.iif(ShowGrid=True,\"true\",";
_gxs = BA.ObjectToString(_app._iif(BA.ObjectToString(_showgrid==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 454;BA.debugLine="Dim gys As String = App.iif(ShowGrid=True,\"true\",";
_gys = BA.ObjectToString(_app._iif(BA.ObjectToString(_showgrid==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 455;BA.debugLine="Dim zoe As String = App.iif(Zoom=True,\"true\",\"fal";
_zoe = BA.ObjectToString(_app._iif(BA.ObjectToString(_zoom==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 456;BA.debugLine="Dim lgs As String = App.iif(BillBoardLegend.Show=";
_lgs = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardlegend._show==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 457;BA.debugLine="Dim leq As String = App.iif(BillBoardLegend.equal";
_leq = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardlegend._equally==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 458;BA.debugLine="Dim lep As String = App.iif(BillBoardLegend.paddi";
_lep = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardlegend._padding==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 459;BA.debugLine="Dim leup As String = App.iif(BillBoardLegend.UseP";
_leup = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardlegend._usepoint==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 460;BA.debugLine="Dim rsl As String = App.iif(BillBoardRadar.ShowLi";
_rsl = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardradar._showline==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 461;BA.debugLine="Dim rst As String = App.iif(BillBoardRadar.ShowTe";
_rst = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardradar._showtext==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 462;BA.debugLine="Dim rslt As String = App.iif(BillBoardRadar.ShowL";
_rslt = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboardradar._showleveltext==__c.True),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 463;BA.debugLine="Dim dsl As String = App.iif(BillBoardDonut.ShowLa";
_dsl = BA.ObjectToString(_app._iif(BA.ObjectToString(_billboarddonut._showlabel==__c.True),(Object)("true"),(Object)(__c.False)));
 //BA.debugLineNum = 464;BA.debugLine="Dim script As String = $\"var colors = HTMLColors(";
_script = ("var colors = HTMLColors();\n"+"	var chart = bb.generate({\n"+"	data: {"+__c.SmartStringFormatter("",(Object)(_hasxaxis()))+"\n"+"  	columns: ["+__c.SmartStringFormatter("",(Object)(_hasxaxis1()))+"\n"+"	"+__c.SmartStringFormatter("",(Object)(_buildcolumns()))+"\n"+"	],\n"+"	"+__c.SmartStringFormatter("",(Object)(_buildlabels()))+"\n"+"    "+__c.SmartStringFormatter("",(Object)(_buildcolors()))+"\n"+"	"+__c.SmartStringFormatter("",(Object)(_builddifferentcolors()))+"\n"+"	type: \""+__c.SmartStringFormatter("",(Object)(_getcharttype()))+"\",\n"+"    "+__c.SmartStringFormatter("",(Object)(_buildtypes()))+"\n"+"    "+__c.SmartStringFormatter("",(Object)(_buildgroups()))+"\n"+"	labels: "+__c.SmartStringFormatter("",(Object)(_slbl))+",\n"+"	onclick: function(d, i) {\n"+"    },\n"+"    onover: function(d, i) {\n"+"	},\n"+"    onout: function(d, i) {\n"+"	}\n"+"  },\n"+"title: {\n"+"text: \""+__c.SmartStringFormatter("",(Object)(_mtitle))+"\"\n"+"},\n"+"  gauge: {\n"+"   	min: "+__c.SmartStringFormatter("",(Object)(_billboardgauge._minvalue))+",\n"+"    max: "+__c.SmartStringFormatter("",(Object)(_billboardgauge._maxvalue))+",\n"+"    width: "+__c.SmartStringFormatter("",(Object)(_billboardgauge._width))+",\n"+"    fullCircle: "+__c.SmartStringFormatter("",(Object)(_sfc))+",\n"+"	startingAngle: "+__c.SmartStringFormatter("",(Object)(_billboardgauge._startingangle))+"\n"+"  },\n"+"  "+__c.SmartStringFormatter("",(Object)(_buildsize()))+"\n"+"  pie: {\n"+"  	innerRadius: "+__c.SmartStringFormatter("",(Object)(_billboardpie._innerradius))+",\n"+"	padAngle: "+__c.SmartStringFormatter("",(Object)(_billboardpie._padangle))+",\n"+"	padding: "+__c.SmartStringFormatter("",(Object)(_billboardpie._padding))+",\n"+"	label: {\n"+"     	\"show\": "+__c.SmartStringFormatter("",(Object)(_psl))+"\n"+"    }\n"+"  },\n"+"  axis: {\n"+"  	rotated: "+__c.SmartStringFormatter("",(Object)(_art))+",\n"+"    x: {\n"+"	  "+__c.SmartStringFormatter("",(Object)(_hasxaxis2()))+"\n"+"      label: {\n"+"	  	text: \""+__c.SmartStringFormatter("",(Object)(_xlabel))+"\",\n"+"	  	position: \"outer-center\"\n"+"	  },\n"+"	  "+__c.SmartStringFormatter("",(Object)(_hasxaxis3()))+"\n"+"    },\n"+"    y: {\n"+"      label: {\n"+"	  	text: \""+__c.SmartStringFormatter("",(Object)(_ylabel))+"\",\n"+"		position: \"outer-middle\"\n"+"	  }\n"+"    }\n"+"  },\n"+"  grid: {\n"+"    x: {\n"+"      show: "+__c.SmartStringFormatter("",(Object)(_gxs))+"\n"+"    },\n"+"    y: {\n"+"      show: "+__c.SmartStringFormatter("",(Object)(_gys))+"\n"+"    }\n"+"  },\n"+"  zoom: {\n"+"    enabled: "+__c.SmartStringFormatter("",(Object)(_zoe))+"\n"+"  },\n"+"  legend: {\n"+"  	show: "+__c.SmartStringFormatter("",(Object)(_lgs))+",\n"+"	position: \""+__c.SmartStringFormatter("",(Object)(_billboardlegend._position))+"\",\n"+"	equally: "+__c.SmartStringFormatter("",(Object)(_leq))+",\n"+"	padding: "+__c.SmartStringFormatter("",(Object)(_lep))+",\n"+"	usePoint: "+__c.SmartStringFormatter("",(Object)(_leup))+"\n"+"  },\n"+"  radar: {\n"+"    axis: {\n"+"      line: {\n"+"        show: "+__c.SmartStringFormatter("",(Object)(_rsl))+"\n"+"      },\n"+"      text: {\n"+"        show: "+__c.SmartStringFormatter("",(Object)(_rst))+"\n"+"      }\n"+"    },\n"+"    level: {\n"+"      text: {\n"+"        show: "+__c.SmartStringFormatter("",(Object)(_rslt))+"\n"+"      }\n"+"    }\n"+"  },\n"+"  donut: {\n"+"width: "+__c.SmartStringFormatter("",(Object)(_billboarddonut._width))+",\n"+"title: \""+__c.SmartStringFormatter("",(Object)(_billboarddonut._title))+"\",\n"+"padAngle: "+__c.SmartStringFormatter("",(Object)(_billboarddonut._padangle))+",\n"+"label: {\n"+"show: "+__c.SmartStringFormatter("",(Object)(_dsl))+",\n"+"}\n"+"},\n"+"  bindto: \"#"+__c.SmartStringFormatter("",(Object)(_compid))+"\"\n"+"});");
 //BA.debugLineNum = 563;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 564;BA.debugLine="End Sub";
return "";
}
public String  _hasxaxis() throws Exception{
 //BA.debugLineNum = 358;BA.debugLine="private Sub HasXAxis() As String";
 //BA.debugLineNum = 359;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._gauge,_enumcharttype._donut,_enumcharttype._pie,_enumcharttype._groupedbar)) {
case 0: 
case 1: 
case 2: 
case 3: {
 //BA.debugLineNum = 361;BA.debugLine="Return \"\"";
if (true) return "";
 break; }
default: {
 //BA.debugLineNum = 363;BA.debugLine="Return $\"x: \"x\",\"$";
if (true) return ("x: \"x\",");
 break; }
}
;
 //BA.debugLineNum = 365;BA.debugLine="End Sub";
return "";
}
public String  _hasxaxis1() throws Exception{
 //BA.debugLineNum = 367;BA.debugLine="private Sub HasXAxis1() As String";
 //BA.debugLineNum = 368;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._gauge,_enumcharttype._donut,_enumcharttype._pie,_enumcharttype._groupedbar)) {
case 0: 
case 1: 
case 2: 
case 3: {
 //BA.debugLineNum = 370;BA.debugLine="Return \"\"";
if (true) return "";
 break; }
default: {
 //BA.debugLineNum = 372;BA.debugLine="Return $\"${BuildXAxis},\"$";
if (true) return (""+__c.SmartStringFormatter("",(Object)(_buildxaxis()))+",");
 break; }
}
;
 //BA.debugLineNum = 374;BA.debugLine="End Sub";
return "";
}
public String  _hasxaxis2() throws Exception{
 //BA.debugLineNum = 376;BA.debugLine="private Sub HasXAxis2() As String";
 //BA.debugLineNum = 377;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._gauge,_enumcharttype._donut,_enumcharttype._pie,_enumcharttype._groupedbar)) {
case 0: 
case 1: 
case 2: 
case 3: {
 //BA.debugLineNum = 379;BA.debugLine="Return \"\"";
if (true) return "";
 break; }
default: {
 //BA.debugLineNum = 381;BA.debugLine="Return $\"type: \"category\",\"$";
if (true) return ("type: \"category\",");
 break; }
}
;
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return "";
}
public String  _hasxaxis3() throws Exception{
 //BA.debugLineNum = 385;BA.debugLine="private Sub HasXAxis3() As String";
 //BA.debugLineNum = 386;BA.debugLine="Select Case ChartType";
switch (BA.switchObjectToInt(_charttype,_enumcharttype._gauge,_enumcharttype._donut,_enumcharttype._pie)) {
case 0: 
case 1: 
case 2: {
 //BA.debugLineNum = 388;BA.debugLine="Return \"\"";
if (true) return "";
 break; }
default: {
 //BA.debugLineNum = 390;BA.debugLine="Return $\"tick: {         rotate: ${xangle},";
if (true) return ("tick: {\n"+"        rotate: "+__c.SmartStringFormatter("",(Object)(_xangle))+",\n"+"        multiline: false,\n"+"        tooltip: true\n"+"      },\n"+"      height: "+__c.SmartStringFormatter("",(Object)(_xaxisheight))+",");
 break; }
}
;
 //BA.debugLineNum = 397;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _id,String _stitle,String _height,String _width) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, ID As Str";
 //BA.debugLineNum = 44;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 45;BA.debugLine="mTitle = sTitle";
_mtitle = _stitle;
 //BA.debugLineNum = 46;BA.debugLine="EnumChartType.Initialize";
_enumcharttype._initialize(ba);
 //BA.debugLineNum = 47;BA.debugLine="BillBoardGauge.Initialize";
_billboardgauge._initialize(ba);
 //BA.debugLineNum = 48;BA.debugLine="BillBoardGauge.FullCircle = False";
_billboardgauge._fullcircle = __c.False;
 //BA.debugLineNum = 49;BA.debugLine="BillBoardGauge.Width = 80";
_billboardgauge._width = (int) (80);
 //BA.debugLineNum = 50;BA.debugLine="BillBoardGauge.MinValue = 0";
_billboardgauge._minvalue = (int) (0);
 //BA.debugLineNum = 51;BA.debugLine="BillBoardGauge.MaxValue = 100";
_billboardgauge._maxvalue = (int) (100);
 //BA.debugLineNum = 52;BA.debugLine="BillBoardGauge.ShowLabel = True";
_billboardgauge._showlabel = __c.True;
 //BA.debugLineNum = 53;BA.debugLine="BillBoardGauge.StartingAngle = -1.570796326794896";
_billboardgauge._startingangle = (float) (-1.5707963267948966);
 //BA.debugLineNum = 54;BA.debugLine="BillboardLegendPosition.Initialize";
_billboardlegendposition._initialize(ba);
 //BA.debugLineNum = 55;BA.debugLine="BillboardLegendPosition.bottom = \"bottom\"";
_billboardlegendposition._bottom = "bottom";
 //BA.debugLineNum = 56;BA.debugLine="BillboardLegendPosition.right = \"right\"";
_billboardlegendposition._right = "right";
 //BA.debugLineNum = 57;BA.debugLine="BillBoardRadar.Initialize";
_billboardradar._initialize(ba);
 //BA.debugLineNum = 58;BA.debugLine="BillBoardRadar.ShowLevelText = True";
_billboardradar._showleveltext = __c.True;
 //BA.debugLineNum = 59;BA.debugLine="BillBoardRadar.ShowLine = True";
_billboardradar._showline = __c.True;
 //BA.debugLineNum = 60;BA.debugLine="BillBoardRadar.ShowText = True";
_billboardradar._showtext = __c.True;
 //BA.debugLineNum = 61;BA.debugLine="BillBoardDonut.Initialize";
_billboarddonut._initialize(ba);
 //BA.debugLineNum = 62;BA.debugLine="BillBoardDonut.padAngle = 0";
_billboarddonut._padangle = (float) (0);
 //BA.debugLineNum = 63;BA.debugLine="BillBoardDonut.Title = \"\"";
_billboarddonut._title = "";
 //BA.debugLineNum = 64;BA.debugLine="BillBoardDonut.ShowLabel = True";
_billboarddonut._showlabel = __c.True;
 //BA.debugLineNum = 65;BA.debugLine="BillBoardDonut.Width = 80";
_billboarddonut._width = (int) (80);
 //BA.debugLineNum = 66;BA.debugLine="BillBoardLegend.Initialize";
_billboardlegend._initialize(ba);
 //BA.debugLineNum = 67;BA.debugLine="BillBoardLegend.Position = \"right\"";
_billboardlegend._position = "right";
 //BA.debugLineNum = 68;BA.debugLine="BillBoardLegend.Show = True";
_billboardlegend._show = __c.True;
 //BA.debugLineNum = 69;BA.debugLine="BillBoardLegend.UsePoint = False";
_billboardlegend._usepoint = __c.False;
 //BA.debugLineNum = 70;BA.debugLine="BillBoardLegend.Equally = True";
_billboardlegend._equally = __c.True;
 //BA.debugLineNum = 71;BA.debugLine="BillBoardLegend.Padding = True";
_billboardlegend._padding = __c.True;
 //BA.debugLineNum = 72;BA.debugLine="BillBoardPie.Initialize";
_billboardpie._initialize(ba);
 //BA.debugLineNum = 73;BA.debugLine="BillBoardPie.InnerRadius = 0";
_billboardpie._innerradius = (int) (0);
 //BA.debugLineNum = 74;BA.debugLine="BillBoardPie.PadAngle = 0";
_billboardpie._padangle = (float) (0);
 //BA.debugLineNum = 75;BA.debugLine="BillBoardPie.Padding = 0";
_billboardpie._padding = (int) (0);
 //BA.debugLineNum = 76;BA.debugLine="BillBoardPie.ShowLabel = True";
_billboardpie._showlabel = __c.True;
 //BA.debugLineNum = 77;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 78;BA.debugLine="cHeight = Height";
_cheight = _height;
 //BA.debugLineNum = 79;BA.debugLine="CompID = ID.tolowercase";
_compid = _id.toLowerCase();
 //BA.debugLineNum = 80;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 81;BA.debugLine="div.Initialize(CompID,\"div\")";
_div._initialize(ba,_compid,"div");
 //BA.debugLineNum = 82;BA.debugLine="series.Initialize";
_series.Initialize();
 //BA.debugLineNum = 83;BA.debugLine="series.clear";
_series.Clear();
 //BA.debugLineNum = 84;BA.debugLine="records.Initialize";
_records.Initialize();
 //BA.debugLineNum = 85;BA.debugLine="records.clear";
_records.Clear();
 //BA.debugLineNum = 86;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 87;BA.debugLine="Visibility = App.EnumVISIBILITY.visible";
_visibility = _app._enumvisibility._visible;
 //BA.debugLineNum = 88;BA.debugLine="ZDepth = App.Enumzdepth.ZDEPTH_none";
_zdepth = _app._enumzdepth._zdepth_none;
 //BA.debugLineNum = 89;BA.debugLine="xkey = \"\"";
_xkey = "";
 //BA.debugLineNum = 90;BA.debugLine="ChartType = EnumChartType.bar";
_charttype = _enumcharttype._bar;
 //BA.debugLineNum = 91;BA.debugLine="Labels = False";
_labels = __c.False;
 //BA.debugLineNum = 92;BA.debugLine="mTitle = sTitle";
_mtitle = _stitle;
 //BA.debugLineNum = 93;BA.debugLine="thresholds.Initialize";
_thresholds.Initialize();
 //BA.debugLineNum = 94;BA.debugLine="thresholds.clear";
_thresholds.Clear();
 //BA.debugLineNum = 95;BA.debugLine="YLabel = \"\"";
_ylabel = "";
 //BA.debugLineNum = 96;BA.debugLine="XLabel = \"\"";
_xlabel = "";
 //BA.debugLineNum = 97;BA.debugLine="rotated = False";
_rotated = __c.False;
 //BA.debugLineNum = 98;BA.debugLine="xangle = 0";
_xangle = (int) (0);
 //BA.debugLineNum = 99;BA.debugLine="XAxisHeight = 32";
_xaxisheight = (int) (32);
 //BA.debugLineNum = 100;BA.debugLine="ShowGrid = False";
_showgrid = __c.False;
 //BA.debugLineNum = 101;BA.debugLine="Zoom = False";
_zoom = __c.False;
 //BA.debugLineNum = 102;BA.debugLine="cWidth = Width";
_cwidth = _width;
 //BA.debugLineNum = 103;BA.debugLine="FitWidth = True";
_fitwidth = __c.True;
 //BA.debugLineNum = 104;BA.debugLine="Consolidate = True";
_consolidate = __c.True;
 //BA.debugLineNum = 105;BA.debugLine="DifferentColors = False";
_differentcolors = __c.False;
 //BA.debugLineNum = 106;BA.debugLine="bBuildGroups = False";
_bbuildgroups = __c.False;
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 284;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEBillBoar";
 //BA.debugLineNum = 285;BA.debugLine="div.RemoveAttribute(attr)";
_div._removeattribute(_attr);
 //BA.debugLineNum = 286;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 287;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 272;BA.debugLine="Sub RemoveClass(sClass As String) As UOEBillBoardC";
 //BA.debugLineNum = 273;BA.debugLine="div.RemoveClass(sClass)";
_div._removeclass(_sclass);
 //BA.debugLineNum = 274;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 275;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _setdata(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
 //BA.debugLineNum = 588;BA.debugLine="Sub SetData(lst As List) As UOEBillBoardChart";
 //BA.debugLineNum = 589;BA.debugLine="records = lst";
_records = _lst;
 //BA.debugLineNum = 590;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 591;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _setserieschartcolor(String _column,String _columncolor) throws Exception{
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
 //BA.debugLineNum = 320;BA.debugLine="Sub SetSeriesChartColor(Column As String, ColumnCo";
 //BA.debugLineNum = 321;BA.debugLine="If series.ContainsKey(Column) Then";
if (_series.ContainsKey((Object)(_column))) { 
 //BA.debugLineNum = 322;BA.debugLine="Dim seriesm As Map = series.Get(Column)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.Get((Object)(_column))));
 //BA.debugLineNum = 323;BA.debugLine="seriesm.Put(\"color\", ColumnColor)";
_seriesm.Put((Object)("color"),(Object)(_columncolor));
 //BA.debugLineNum = 324;BA.debugLine="series.Put(Column,seriesm)";
_series.Put((Object)(_column),(Object)(_seriesm.getObject()));
 };
 //BA.debugLineNum = 326;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _setseriescharttype(String _column,String _typeof) throws Exception{
anywheresoftware.b4a.objects.collections.Map _seriesm = null;
 //BA.debugLineNum = 310;BA.debugLine="Sub SetSeriesChartType(Column As String, TypeOf As";
 //BA.debugLineNum = 311;BA.debugLine="If series.ContainsKey(Column) Then";
if (_series.ContainsKey((Object)(_column))) { 
 //BA.debugLineNum = 312;BA.debugLine="Dim seriesm As Map = series.Get(Column)";
_seriesm = new anywheresoftware.b4a.objects.collections.Map();
_seriesm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_series.Get((Object)(_column))));
 //BA.debugLineNum = 313;BA.debugLine="seriesm.Put(\"type\", TypeOf)";
_seriesm.Put((Object)("type"),(Object)(_typeof));
 //BA.debugLineNum = 314;BA.debugLine="series.Put(Column,seriesm)";
_series.Put((Object)(_column),(Object)(_seriesm.getObject()));
 };
 //BA.debugLineNum = 316;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 317;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebillboardchart  _setxaxis(String _x_key,int _x_angle,int _x_height,boolean _x_labels) throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Sub SetXAxis(x_key As String, x_angle As Int,x_hei";
 //BA.debugLineNum = 117;BA.debugLine="xkey = x_key";
_xkey = _x_key;
 //BA.debugLineNum = 118;BA.debugLine="xangle = x_angle";
_xangle = _x_angle;
 //BA.debugLineNum = 119;BA.debugLine="XAxisHeight = x_height";
_xaxisheight = _x_height;
 //BA.debugLineNum = 120;BA.debugLine="Labels = x_labels";
_labels = _x_labels;
 //BA.debugLineNum = 121;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebillboardchart)(this);
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 600;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 601;BA.debugLine="div.ID = CompID";
_div._id = _compid;
 //BA.debugLineNum = 602;BA.debugLine="div.MaterialVisibility(Visibility)";
_div._materialvisibility(_visibility);
 //BA.debugLineNum = 603;BA.debugLine="div.MaterialZDepth(ZDepth)";
_div._materialzdepth(_zdepth);
 //BA.debugLineNum = 604;BA.debugLine="div.MaterialEnable(Enabled)";
_div._materialenable(_enabled);
 //BA.debugLineNum = 605;BA.debugLine="Return div.html";
if (true) return _div._html();
 //BA.debugLineNum = 606;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
