package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoedivider extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoedivider", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoedivider.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _visibility = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoedivider  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 31;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedivider)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedivider  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub AddClass(sClass As String) As UOEDivider";
 //BA.debugLineNum = 19;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 20;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedivider)(this);
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedivider  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 13;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 14;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedivider)(this);
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 42;BA.debugLine="Sub Initialize(thisApp As UOEApp, sid As String, t";
 //BA.debugLineNum = 44;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 45;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 46;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 47;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 48;BA.debugLine="Element.Initialize(sid,\"div\")";
_element._initialize(ba,_sid,"div");
 //BA.debugLineNum = 49;BA.debugLine="Element.AddClass(\"divider\")";
_element._addclass("divider");
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoedivider  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEDivider";
 //BA.debugLineNum = 37;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 38;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedivider)(this);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedivider  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub RemoveClass(sClass As String) As UOEDivider";
 //BA.debugLineNum = 25;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedivider)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 54;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 55;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 56;BA.debugLine="Return Element.tostring";
if (true) return _element._tostring();
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
