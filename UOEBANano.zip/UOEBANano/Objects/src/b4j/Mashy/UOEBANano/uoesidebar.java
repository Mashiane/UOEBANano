package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoesidebar extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoesidebar", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoesidebar.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _items = null;
public int _drawerwidth = 0;
public String _edge = "";
public String _activesideid = "";
public boolean _enabled = false;
public String _theme = "";
public String _visibility = "";
public boolean _isopen = false;
public boolean _isfixed = false;
public boolean _draggable = false;
public boolean _preventscrolling = false;
public boolean _hascollapse = false;
public b4j.Mashy.UOEBANano.uoecollapsible _mc = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 53;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return "";
}
public String  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub AddClass(sClass As String)";
 //BA.debugLineNum = 43;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public String  _addcollapsible() throws Exception{
String _skey = "";
int _kpos = 0;
 //BA.debugLineNum = 299;BA.debugLine="private Sub AddCollapsible()";
 //BA.debugLineNum = 300;BA.debugLine="Dim skey As String = $\"${ID}collapse\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+"collapse");
 //BA.debugLineNum = 301;BA.debugLine="Dim kPos As Int = Items.IndexOf(skey)";
_kpos = _items.IndexOf((Object)(_skey));
 //BA.debugLineNum = 302;BA.debugLine="If kPos = -1 Then";
if (_kpos==-1) { 
 //BA.debugLineNum = 303;BA.debugLine="Items.Add(ID & \"collapse\")";
_items.Add((Object)(_id+"collapse"));
 };
 //BA.debugLineNum = 305;BA.debugLine="End Sub";
return "";
}
public String  _adddivider() throws Exception{
b4j.Mashy.UOEBANano.uoedivider _md = null;
 //BA.debugLineNum = 247;BA.debugLine="Sub AddDivider";
 //BA.debugLineNum = 248;BA.debugLine="Dim md As UOEDivider";
_md = new b4j.Mashy.UOEBANano.uoedivider();
 //BA.debugLineNum = 249;BA.debugLine="md.Initialize(App,\"\",\"\")";
_md._initialize(ba,_app,"","");
 //BA.debugLineNum = 250;BA.debugLine="Items.Add(md.tostring)";
_items.Add((Object)(_md._tostring()));
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return "";
}
public String  _addheader(String _itemid,String _itemicon,String _itemtext,String _itembadge,boolean _badgenew,String _itemnavigateto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 189;BA.debugLine="Sub AddHeader(itemID As String, itemIcon As String";
 //BA.debugLineNum = 190;BA.debugLine="If hascollapse = False Then AddCollapsible";
if (_hascollapse==__c.False) { 
_addcollapsible();};
 //BA.debugLineNum = 191;BA.debugLine="mc.AddHeader(itemID,itemIcon,itemText, itemBadge,";
_mc._addheader(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme,_hasdivider,_hasevent);
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoesidebar  _addheader1(String _itemid,String _itemicon,String _itemtext,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub AddHeader1(itemID As String, itemIcon As Strin";
 //BA.debugLineNum = 25;BA.debugLine="mc.AddHeader(itemID,itemIcon,itemText,\"\",False,\"\"";
_mc._addheader(_itemid,_itemicon,_itemtext,"",__c.False,"",_itemtheme,_icontheme,_hasdivider,_hasevent);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoesidebar)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public String  _addheaderitem(String _parentid,String _itemid,String _iconname,String _itemtext,String _itemnavigateto,String _itembadge,boolean _badgenew,boolean _bhasdivider,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 194;BA.debugLine="Sub AddHeaderItem(parentID As String, itemID As St";
 //BA.debugLineNum = 195;BA.debugLine="mc.AddHeaderItem(parentID, itemID, iconName, item";
_mc._addheaderitem(_parentid,_itemid,_iconname,_itemtext,_itemnavigateto,_itembadge,_badgenew,_bhasdivider,_itemtheme,_icontheme,_hasevent);
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoesidebar  _addheaderitem1(String _parentid,String _itemid,String _itemicon,String _itemtext,String _itemgoto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddHeaderItem1(parentID As String,itemID As St";
 //BA.debugLineNum = 31;BA.debugLine="mc.AddHeaderItem(parentID,itemID,itemIcon,itemTex";
_mc._addheaderitem(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,"",__c.False,_hasdivider,_itemtheme,_icontheme,_hasevent);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoesidebar)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _additem(String _itemid,String _iconname,String _itemtext,String _itemnavigateto,boolean _bhasdivider,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 267;BA.debugLine="Sub AddItem(itemID As String, iconName As String,";
 //BA.debugLineNum = 268;BA.debugLine="If hascollapse = False Then AddCollapsible";
if (_hascollapse==__c.False) { 
_addcollapsible();};
 //BA.debugLineNum = 269;BA.debugLine="mc.AddItem(itemID,iconName,itemText, \"\",False,ite";
_mc._additem(_itemid,_iconname,_itemtext,"",__c.False,_itemnavigateto,_itemtheme,_icontheme,_bhasdivider,_hasevent);
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return "";
}
public String  _additemimage(String _itemid,String _imgurl,boolean _imgcircle,String _itemtext,String _href,boolean _bhasdivider,String _itemtheme) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _span = null;
 //BA.debugLineNum = 273;BA.debugLine="Sub AddItemImage(itemID As String, imgURL As Strin";
 //BA.debugLineNum = 274;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 276;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 277;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 278;BA.debugLine="li.AddClass(\"avatar\")";
_li._addclass("avatar");
 //BA.debugLineNum = 279;BA.debugLine="li.AddClass(\"no-padding\")";
_li._addclass("no-padding");
 //BA.debugLineNum = 280;BA.debugLine="li.MaterialWavesEffect(True)";
_li._materialwaveseffect(__c.True);
 //BA.debugLineNum = 282;BA.debugLine="modUOE.MaterialAddImage(App,li,imgURL,\"\",App.Imag";
_moduoe._materialaddimage(_app,_li,_imgurl,"",_app._imagehw,_app._imagehw,_imgcircle,__c.True,__c.True,_app._imagetopmargin);
 //BA.debugLineNum = 283;BA.debugLine="li.AddClass(\"waves-effect\")";
_li._addclass("waves-effect");
 //BA.debugLineNum = 284;BA.debugLine="App.MaterialUseTheme(itemTheme,li)";
_app._materialusetheme(_itemtheme,_li);
 //BA.debugLineNum = 285;BA.debugLine="li.AddAttribute(\"href\",href)";
_li._addattribute("href",_href);
 //BA.debugLineNum = 287;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 288;BA.debugLine="span.Initialize(itemID & \"-title\",\"span\")";
_span._initialize(ba,_itemid+"-title","span");
 //BA.debugLineNum = 289;BA.debugLine="span.AddClass(\"title\")";
_span._addclass("title");
 //BA.debugLineNum = 290;BA.debugLine="span.AddContent(itemText)";
_span._addcontent(_itemtext);
 //BA.debugLineNum = 291;BA.debugLine="App.MaterialUseTheme(itemTheme,span)";
_app._materialusetheme(_itemtheme,_span);
 //BA.debugLineNum = 292;BA.debugLine="span.AddStyleAttribute(\"vertical-align\",\"top\")";
_span._addstyleattribute("vertical-align","top");
 //BA.debugLineNum = 293;BA.debugLine="li.AddContent(span.HTML)";
_li._addcontent(_span._html());
 //BA.debugLineNum = 294;BA.debugLine="li.MaterialAddDividerOnCondition(bHasDivider,App.";
_li._materialadddivideroncondition(_bhasdivider,_app._enumvisibility._visible,_itemtheme);
 //BA.debugLineNum = 295;BA.debugLine="Items.Add(li.HTML)";
_items.Add((Object)(_li._html()));
 //BA.debugLineNum = 296;BA.debugLine="End Sub";
return "";
}
public String  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 37;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return "";
}
public String  _adduserview(String _username,String _useremail,String _userimageurl,String _backgroundimageurl) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _uli = null;
b4j.Mashy.UOEBANano.uoehtml _udiv = null;
b4j.Mashy.UOEBANano.uoehtml _bdiv = null;
b4j.Mashy.UOEBANano.uoeanchor _ui = null;
b4j.Mashy.UOEBANano.uoehtml _ui1 = null;
b4j.Mashy.UOEBANano.uoehtml _span = null;
b4j.Mashy.UOEBANano.uoehtml _ui2 = null;
b4j.Mashy.UOEBANano.uoehtml _span1 = null;
 //BA.debugLineNum = 199;BA.debugLine="Sub AddUserView(UserName As String, UserEmail As S";
 //BA.debugLineNum = 201;BA.debugLine="Dim uli As UOEHTML";
_uli = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 202;BA.debugLine="uli.Initialize(ID & \"-user\",\"li\")";
_uli._initialize(ba,_id+"-user","li");
 //BA.debugLineNum = 204;BA.debugLine="Dim udiv As UOEHTML";
_udiv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 205;BA.debugLine="udiv.Initialize(ID & \"-userview\",\"div\")";
_udiv._initialize(ba,_id+"-userview","div");
 //BA.debugLineNum = 206;BA.debugLine="udiv.AddClass(\"user-view\")";
_udiv._addclass("user-view");
 //BA.debugLineNum = 209;BA.debugLine="Dim bdiv As UOEHTML";
_bdiv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 210;BA.debugLine="bdiv.Initialize(ID & \"-background\",\"div\")";
_bdiv._initialize(ba,_id+"-background","div");
 //BA.debugLineNum = 211;BA.debugLine="bdiv.AddClass(\"background\")";
_bdiv._addclass("background");
 //BA.debugLineNum = 212;BA.debugLine="modUOE.MaterialAddImage(App,bdiv,BackgroundImageU";
_moduoe._materialaddimage(_app,_bdiv,_backgroundimageurl,"","","",__c.False,__c.False,__c.True,"0px");
 //BA.debugLineNum = 214;BA.debugLine="udiv.AddContent(bdiv.html)";
_udiv._addcontent(_bdiv._html());
 //BA.debugLineNum = 216;BA.debugLine="Dim ui As UOEAnchor";
_ui = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 217;BA.debugLine="ui.Initialize(App,\"\")";
_ui._initialize(ba,_app,"");
 //BA.debugLineNum = 218;BA.debugLine="ui.HREF = \"#!user\"";
_ui._href = "#!user";
 //BA.debugLineNum = 219;BA.debugLine="modUOE.MaterialAddImage(App,ui.element,UserImageU";
_moduoe._materialaddimage(_app,_ui._element,_userimageurl,"","","",__c.True,__c.True,__c.True,"0px");
 //BA.debugLineNum = 220;BA.debugLine="udiv.AddContent(ui.tostring)";
_udiv._addcontent(_ui._tostring());
 //BA.debugLineNum = 222;BA.debugLine="Dim ui1 As UOEHTML";
_ui1 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 223;BA.debugLine="ui1.initialize(\"\",\"a\")";
_ui1._initialize(ba,"","a");
 //BA.debugLineNum = 224;BA.debugLine="ui1.AddAttribute(\"href\",\"#!name\")";
_ui1._addattribute("href","#!name");
 //BA.debugLineNum = 225;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 226;BA.debugLine="span.Initialize(\"\",\"span\")";
_span._initialize(ba,"","span");
 //BA.debugLineNum = 227;BA.debugLine="span.AddClass(\"white-text name\")";
_span._addclass("white-text name");
 //BA.debugLineNum = 228;BA.debugLine="span.AddContent(UserName)";
_span._addcontent(_username);
 //BA.debugLineNum = 229;BA.debugLine="ui1.addcontent(span.html)";
_ui1._addcontent(_span._html());
 //BA.debugLineNum = 230;BA.debugLine="udiv.addcontent(ui1.html)";
_udiv._addcontent(_ui1._html());
 //BA.debugLineNum = 233;BA.debugLine="Dim ui2 As UOEHTML";
_ui2 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 234;BA.debugLine="ui2.initialize(\"\",\"a\")";
_ui2._initialize(ba,"","a");
 //BA.debugLineNum = 235;BA.debugLine="ui2.AddAttribute(\"href\",$\"mailto:${UserEmail}\"$)";
_ui2._addattribute("href",("mailto:"+__c.SmartStringFormatter("",(Object)(_useremail))+""));
 //BA.debugLineNum = 236;BA.debugLine="Dim span1 As UOEHTML";
_span1 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 237;BA.debugLine="span1.Initialize(\"\",\"span\")";
_span1._initialize(ba,"","span");
 //BA.debugLineNum = 238;BA.debugLine="span1.AddClass(\"white-text email\")";
_span1._addclass("white-text email");
 //BA.debugLineNum = 239;BA.debugLine="span1.AddContent(UserEmail)";
_span1._addcontent(_useremail);
 //BA.debugLineNum = 240;BA.debugLine="ui2.addcontent(span1.html)";
_ui2._addcontent(_span1._html());
 //BA.debugLineNum = 241;BA.debugLine="udiv.addcontent(ui2.html)";
_udiv._addcontent(_ui2._html());
 //BA.debugLineNum = 242;BA.debugLine="uli.addcontent(udiv.html)";
_uli._addcontent(_udiv._html());
 //BA.debugLineNum = 243;BA.debugLine="Items.Add(uli.HTML)";
_items.Add((Object)(_uli._html()));
 //BA.debugLineNum = 244;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 9;BA.debugLine="Public DrawerWidth As Int";
_drawerwidth = 0;
 //BA.debugLineNum = 10;BA.debugLine="Public edge As String";
_edge = "";
 //BA.debugLineNum = 11;BA.debugLine="Public ActiveSideID As String";
_activesideid = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 13;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 14;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Public isOpen As Boolean";
_isopen = false;
 //BA.debugLineNum = 16;BA.debugLine="Public isFixed As Boolean";
_isfixed = false;
 //BA.debugLineNum = 17;BA.debugLine="Public draggable As Boolean";
_draggable = false;
 //BA.debugLineNum = 18;BA.debugLine="Public preventScrolling As Boolean";
_preventscrolling = false;
 //BA.debugLineNum = 19;BA.debugLine="Private hascollapse As Boolean";
_hascollapse = false;
 //BA.debugLineNum = 20;BA.debugLine="Public mc As UOECollapsible";
_mc = new b4j.Mashy.UOEBANano.uoecollapsible();
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _close(int _idx) throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Sub Close(idx As Int)";
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _getcss() throws Exception{
String _strsize = "";
anywheresoftware.b4a.objects.collections.Map _css = null;
String _str = "";
 //BA.debugLineNum = 143;BA.debugLine="Sub GetCSS";
 //BA.debugLineNum = 144;BA.debugLine="If isFixed Then";
if (_isfixed) { 
 //BA.debugLineNum = 145;BA.debugLine="Dim strSize As String = $\"${DrawerWidth}px\"$";
_strsize = (""+__c.SmartStringFormatter("",(Object)(_drawerwidth))+"px");
 //BA.debugLineNum = 146;BA.debugLine="Dim css As Map";
_css = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 147;BA.debugLine="css.Initialize";
_css.Initialize();
 //BA.debugLineNum = 148;BA.debugLine="css.clear";
_css.Clear();
 //BA.debugLineNum = 149;BA.debugLine="css.Put(\"id\", \"header\")";
_css.Put((Object)("id"),(Object)("header"));
 //BA.debugLineNum = 150;BA.debugLine="css.Put(\"padding-left\", strSize)";
_css.Put((Object)("padding-left"),(Object)(_strsize));
 //BA.debugLineNum = 151;BA.debugLine="css.Put(\"width\", \"100%\")";
_css.Put((Object)("width"),(Object)("100%"));
 //BA.debugLineNum = 152;BA.debugLine="Dim str As String = App.Map2Json(css)";
_str = _app._map2json(_css);
 //BA.debugLineNum = 153;BA.debugLine="App.CSS.Add(str)";
_app._css.Add((Object)(_str));
 //BA.debugLineNum = 154;BA.debugLine="css.Put(\"id\", \"main\")";
_css.Put((Object)("id"),(Object)("main"));
 //BA.debugLineNum = 155;BA.debugLine="Dim str As String = App.Map2Json(css)";
_str = _app._map2json(_css);
 //BA.debugLineNum = 156;BA.debugLine="App.CSS.Add(str)";
_app._css.Add((Object)(_str));
 //BA.debugLineNum = 157;BA.debugLine="css.Put(\"id\", \"footer\")";
_css.Put((Object)("id"),(Object)("footer"));
 //BA.debugLineNum = 158;BA.debugLine="Dim str As String = App.Map2Json(css)";
_str = _app._map2json(_css);
 //BA.debugLineNum = 159;BA.debugLine="App.CSS.Add(str)";
_app._css.Add((Object)(_str));
 };
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.List  _getlinks(String _header) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.Map _hdrlinks = null;
 //BA.debugLineNum = 164;BA.debugLine="Sub GetLinks(Header As String) As List";
 //BA.debugLineNum = 165;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 166;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 167;BA.debugLine="lst.clear";
_lst.Clear();
 //BA.debugLineNum = 168;BA.debugLine="Header = Header.ToLowerCase";
_header = _header.toLowerCase();
 //BA.debugLineNum = 169;BA.debugLine="Dim hdrLinks As Map = mc.links";
_hdrlinks = new anywheresoftware.b4a.objects.collections.Map();
_hdrlinks = _mc._links;
 //BA.debugLineNum = 170;BA.debugLine="If hdrLinks.ContainsKey(Header) Then";
if (_hdrlinks.ContainsKey((Object)(_header))) { 
 //BA.debugLineNum = 171;BA.debugLine="lst = hdrLinks.Get(Header)";
_lst.setObject((java.util.List)(_hdrlinks.Get((Object)(_header))));
 };
 //BA.debugLineNum = 173;BA.debugLine="Return lst";
if (true) return _lst;
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return null;
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _ms = null;
String _str = "";
 //BA.debugLineNum = 104;BA.debugLine="Sub GetSettings As String";
 //BA.debugLineNum = 105;BA.debugLine="Dim ms As Map";
_ms = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 106;BA.debugLine="ms.Initialize";
_ms.Initialize();
 //BA.debugLineNum = 107;BA.debugLine="ms.clear";
_ms.Clear();
 //BA.debugLineNum = 108;BA.debugLine="ms.Put(\"id\", ID)";
_ms.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 109;BA.debugLine="ms.Put(\"instance\", \"sidenav\")";
_ms.Put((Object)("instance"),(Object)("sidenav"));
 //BA.debugLineNum = 110;BA.debugLine="ms.Put(\"draggable\", draggable)";
_ms.Put((Object)("draggable"),(Object)(_draggable));
 //BA.debugLineNum = 111;BA.debugLine="ms.Put(\"preventScrolling\", preventScrolling)";
_ms.Put((Object)("preventScrolling"),(Object)(_preventscrolling));
 //BA.debugLineNum = 112;BA.debugLine="ms.Put(\"edge\", edge)";
_ms.Put((Object)("edge"),(Object)(_edge));
 //BA.debugLineNum = 113;BA.debugLine="Dim str As String = App.Map2Json(ms)";
_str = _app._map2json(_ms);
 //BA.debugLineNum = 114;BA.debugLine="Return str";
if (true) return _str;
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return "";
}
public anywheresoftware.b4a.objects.collections.List  _gettexts(String _header) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.Map _hdrnames = null;
 //BA.debugLineNum = 177;BA.debugLine="Sub GetTexts(Header As String) As List";
 //BA.debugLineNum = 178;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 179;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 180;BA.debugLine="lst.clear";
_lst.Clear();
 //BA.debugLineNum = 181;BA.debugLine="Header = Header.ToLowerCase";
_header = _header.toLowerCase();
 //BA.debugLineNum = 182;BA.debugLine="Dim hdrNames As Map = mc.ItemNames";
_hdrnames = new anywheresoftware.b4a.objects.collections.Map();
_hdrnames = _mc._itemnames;
 //BA.debugLineNum = 183;BA.debugLine="If hdrNames.ContainsKey(Header) Then";
if (_hdrnames.ContainsKey((Object)(_header))) { 
 //BA.debugLineNum = 184;BA.debugLine="lst = hdrNames.Get(Header)";
_lst.setObject((java.util.List)(_hdrnames.Get((Object)(_header))));
 };
 //BA.debugLineNum = 186;BA.debugLine="Return lst";
if (true) return _lst;
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,boolean _bfixed,boolean _bopen,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 63;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 64;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 65;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 66;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 67;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 68;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 69;BA.debugLine="isOpen = bOpen";
_isopen = _bopen;
 //BA.debugLineNum = 70;BA.debugLine="ActiveSideID = \"\"";
_activesideid = "";
 //BA.debugLineNum = 71;BA.debugLine="edge = \"left\"";
_edge = "left";
 //BA.debugLineNum = 72;BA.debugLine="draggable = True";
_draggable = __c.True;
 //BA.debugLineNum = 73;BA.debugLine="isFixed = bFixed";
_isfixed = _bfixed;
 //BA.debugLineNum = 74;BA.debugLine="preventScrolling = True";
_preventscrolling = __c.True;
 //BA.debugLineNum = 75;BA.debugLine="hascollapse = False";
_hascollapse = __c.False;
 //BA.debugLineNum = 76;BA.debugLine="DrawerWidth = 300";
_drawerwidth = (int) (300);
 //BA.debugLineNum = 77;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 78;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 79;BA.debugLine="mc.Initialize(App,ID & \"-collapse\",App.EnumCollap";
_mc._initialize(ba,_app,_id+"-collapse",_app._enumcollapsibletype._accordion,__c.True,"");
 //BA.debugLineNum = 80;BA.debugLine="Element.Initialize(ID,\"ul\")";
_element._initialize(ba,_id,"ul");
 //BA.debugLineNum = 81;BA.debugLine="Element.AddClass(\"sidenav\")";
_element._addclass("sidenav");
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _open(int _idx) throws Exception{
 //BA.debugLineNum = 85;BA.debugLine="Sub Open(idx As Int)";
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub RemoveAttribute(attr As String)";
 //BA.debugLineNum = 58;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Sub RemoveClass(sClass As String)";
 //BA.debugLineNum = 48;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
String _strsideitem = "";
 //BA.debugLineNum = 118;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 119;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 120;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 121;BA.debugLine="Element.AddClassOnCondition(isFixed,\"sidenav-fixe";
_element._addclassoncondition(_isfixed,"sidenav-fixed");
 //BA.debugLineNum = 122;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 123;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 124;BA.debugLine="Element.AddStyleAttribute(\"width\",DrawerWidth & \"";
_element._addstyleattribute("width",BA.NumberToString(_drawerwidth)+"px");
 //BA.debugLineNum = 126;BA.debugLine="For Each strSideItem As String In Items";
{
final anywheresoftware.b4a.BA.IterableList group7 = _items;
final int groupLen7 = group7.getSize()
;int index7 = 0;
;
for (; index7 < groupLen7;index7++){
_strsideitem = BA.ObjectToString(group7.Get(index7));
 //BA.debugLineNum = 128;BA.debugLine="If strSideItem = ID & \"collapse\" Then";
if ((_strsideitem).equals(_id+"collapse")) { 
 //BA.debugLineNum = 129;BA.debugLine="Element.AddContent(mc.tostring)";
_element._addcontent(_mc._tostring());
 }else {
 //BA.debugLineNum = 131;BA.debugLine="Element.AddContent(strSideItem)";
_element._addcontent(_strsideitem);
 };
 }
};
 //BA.debugLineNum = 140;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
