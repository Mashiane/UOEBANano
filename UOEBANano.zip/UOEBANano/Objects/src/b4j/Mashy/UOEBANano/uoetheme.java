package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetheme extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetheme", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetheme.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _fc = "";
public String _fci = "";
public String _bc = "";
public String _bci = "";
public String _fcname = "";
public String _fciname = "";
public String _id = "";
public String _classdef = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public FC As String";
_fc = "";
 //BA.debugLineNum = 5;BA.debugLine="Public FCI As String";
_fci = "";
 //BA.debugLineNum = 6;BA.debugLine="Public BC As String";
_bc = "";
 //BA.debugLineNum = 7;BA.debugLine="Public BCI As String";
_bci = "";
 //BA.debugLineNum = 8;BA.debugLine="Public FCName As String";
_fcname = "";
 //BA.debugLineNum = 9;BA.debugLine="Public FCIName As String";
_fciname = "";
 //BA.debugLineNum = 10;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 11;BA.debugLine="Public ClassDef As String";
_classdef = "";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _getthemeclass(String _sforecolor,String _sforecolorintensity,String _sbackcolor,String _sbackcolorintensity) throws Exception{
String _sbc = "";
String _sbci = "";
String _sfc = "";
String _sfci = "";
String _script = "";
 //BA.debugLineNum = 30;BA.debugLine="private Sub GetThemeClass(sForeColor As String,sFo";
 //BA.debugLineNum = 31;BA.debugLine="Dim sBC As String = sBackColor";
_sbc = _sbackcolor;
 //BA.debugLineNum = 32;BA.debugLine="Dim sBCI As String = sBackColorIntensity";
_sbci = _sbackcolorintensity;
 //BA.debugLineNum = 33;BA.debugLine="Dim sFC As String = $\"${sForeColor}-text\"$";
_sfc = (""+__c.SmartStringFormatter("",(Object)(_sforecolor))+"-text");
 //BA.debugLineNum = 34;BA.debugLine="Dim sFCI As String = $\"text-${sForeColorIntensity";
_sfci = ("text-"+__c.SmartStringFormatter("",(Object)(_sforecolorintensity))+"");
 //BA.debugLineNum = 35;BA.debugLine="If sForeColor = \"\" Then sFC = \"\"";
if ((_sforecolor).equals("")) { 
_sfc = "";};
 //BA.debugLineNum = 36;BA.debugLine="If sForeColorIntensity = \"\" Then sFCI = \"\"";
if ((_sforecolorintensity).equals("")) { 
_sfci = "";};
 //BA.debugLineNum = 37;BA.debugLine="Dim script As String = $\"${sFC} ${sFCI} ${sBC} ${";
_script = (""+__c.SmartStringFormatter("",(Object)(_sfc))+" "+__c.SmartStringFormatter("",(Object)(_sfci))+" "+__c.SmartStringFormatter("",(Object)(_sbc))+" "+__c.SmartStringFormatter("",(Object)(_sbci))+"");
 //BA.debugLineNum = 38;BA.debugLine="script = script.trim";
_script = _script.trim();
 //BA.debugLineNum = 39;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,String _sid,String _sforecolor,String _sforecolorintensity,String _sbackcolor,String _sbackcolorintensity) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Public Sub Initialize(sID As String,sForeColor As";
 //BA.debugLineNum = 16;BA.debugLine="sID = sID.tolowercase";
_sid = _sid.toLowerCase();
 //BA.debugLineNum = 17;BA.debugLine="ID = sID";
_id = _sid;
 //BA.debugLineNum = 18;BA.debugLine="FCName = sForeColor";
_fcname = _sforecolor;
 //BA.debugLineNum = 19;BA.debugLine="FCIName = sForeColorIntensity";
_fciname = _sforecolorintensity;
 //BA.debugLineNum = 20;BA.debugLine="BC = sBackColor";
_bc = _sbackcolor;
 //BA.debugLineNum = 21;BA.debugLine="BCI = sBackColorIntensity";
_bci = _sbackcolorintensity;
 //BA.debugLineNum = 22;BA.debugLine="FC = $\"${sForeColor}-text\"$";
_fc = (""+__c.SmartStringFormatter("",(Object)(_sforecolor))+"-text");
 //BA.debugLineNum = 23;BA.debugLine="FCI = $\"text-${sForeColorIntensity}\"$";
_fci = ("text-"+__c.SmartStringFormatter("",(Object)(_sforecolorintensity))+"");
 //BA.debugLineNum = 24;BA.debugLine="If sForeColor = \"\" Then FC = \"\"";
if ((_sforecolor).equals("")) { 
_fc = "";};
 //BA.debugLineNum = 25;BA.debugLine="If sForeColorIntensity = \"\" Then FCI = \"\"";
if ((_sforecolorintensity).equals("")) { 
_fci = "";};
 //BA.debugLineNum = 26;BA.debugLine="ClassDef = GetThemeClass(sForeColor,sForeColorInt";
_classdef = _getthemeclass(_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
