package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoewaterball extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoewaterball", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoewaterball.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _vwidth = "";
public String _vheight = "";
public boolean _isloading = false;
public String _vnowrange = "";
public String _vtargetrange = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _range1 = "";
public String _range2 = "";
public String _range3 = "";
public int _wwidth = 0;
public int _wheight = 0;
public b4j.Mashy.UOEBANano.uoehtml _div = null;
public boolean _enabled = false;
public String _visibility = "";
public String _zdepth = "";
public boolean _verticallyalign = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoewaterball  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 124;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 125;BA.debugLine="div.AddAttribute(attr,value)";
_div._addattribute(_attr,_value);
 //BA.debugLineNum = 126;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Sub AddClass(sClass As String) As UOEWaterBall";
 //BA.debugLineNum = 113;BA.debugLine="div.AddClass(sClass)";
_div._addclass(_sclass);
 //BA.debugLineNum = 114;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 107;BA.debugLine="div.AddStyleAttribute(attribute,value)";
_div._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 108;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _centerinparent() throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub CenterInParent() As UOEWaterBall";
 //BA.debugLineNum = 47;BA.debugLine="div.AddClass(App.EnumAlignment.CenterDiv)";
_div._addclass(_app._enumalignment._centerdiv);
 //BA.debugLineNum = 48;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private vWidth As String";
_vwidth = "";
 //BA.debugLineNum = 5;BA.debugLine="Private vHeight As String";
_vheight = "";
 //BA.debugLineNum = 6;BA.debugLine="Public isLoading As Boolean";
_isloading = false;
 //BA.debugLineNum = 7;BA.debugLine="Private vnowRange As String ' the value now";
_vnowrange = "";
 //BA.debugLineNum = 8;BA.debugLine="Private vtargetRange As String ' the target value";
_vtargetrange = "";
 //BA.debugLineNum = 9;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 10;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 11;BA.debugLine="Private range1 As String";
_range1 = "";
 //BA.debugLineNum = 12;BA.debugLine="Private range2 As String";
_range2 = "";
 //BA.debugLineNum = 13;BA.debugLine="Private range3 As String";
_range3 = "";
 //BA.debugLineNum = 14;BA.debugLine="Private wWidth As Int";
_wwidth = 0;
 //BA.debugLineNum = 15;BA.debugLine="Private wHeight As Int";
_wheight = 0;
 //BA.debugLineNum = 16;BA.debugLine="Private div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 17;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 19;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 20;BA.debugLine="Public VerticallyAlign As Boolean";
_verticallyalign = false;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _script = "";
 //BA.debugLineNum = 67;BA.debugLine="Sub GetJavaScript As String";
 //BA.debugLineNum = 69;BA.debugLine="Dim script As String = $\"var _${ID}; 	var a${ID}";
_script = ("var _"+__c.SmartStringFormatter("",(Object)(_id))+";\n"+"	var a"+__c.SmartStringFormatter("",(Object)(_id))+" = [];\n"+"	var loadingEle = $('."+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var loading_width = loadingEle.width();\n"+"	var loading_height = loadingEle.height();\n"+"	$('."+__c.SmartStringFormatter("",(Object)(_id))+"').createWaterBall({\n"+"		cvs_config:{\n"+"			width:loading_width,\n"+"			height:loading_height\n"+"		},\n"+"		wave_config:{\n"+"            waveWidth:"+__c.SmartStringFormatter("",(Object)(_wwidth))+",\n"+"            waveHeight:"+__c.SmartStringFormatter("",(Object)(_wheight))+"\n"+"        },\n"+"        data_range:["+__c.SmartStringFormatter("",(Object)(_range1))+","+__c.SmartStringFormatter("",(Object)(_range2))+","+__c.SmartStringFormatter("",(Object)(_range3))+"],\n"+"        isLoading:"+__c.SmartStringFormatter("",(Object)(_isloading))+",\n"+"        nowRange:"+__c.SmartStringFormatter("",(Object)(_vnowrange))+",\n"+"        targetRange:"+__c.SmartStringFormatter("",(Object)(_vtargetrange))+"\n"+"	});");
 //BA.debugLineNum = 88;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,int _width,int _height) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 26;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 27;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 28;BA.debugLine="vWidth = Width";
_vwidth = BA.NumberToString(_width);
 //BA.debugLineNum = 29;BA.debugLine="vHeight = Height";
_vheight = BA.NumberToString(_height);
 //BA.debugLineNum = 30;BA.debugLine="range1 = \"50\"";
_range1 = "50";
 //BA.debugLineNum = 31;BA.debugLine="range2 = \"80\"";
_range2 = "80";
 //BA.debugLineNum = 32;BA.debugLine="range3 = \"100\"";
_range3 = "100";
 //BA.debugLineNum = 33;BA.debugLine="wWidth = \"0.02\"";
_wwidth = (int)(Double.parseDouble("0.02"));
 //BA.debugLineNum = 34;BA.debugLine="wHeight = \"5\"";
_wheight = (int)(Double.parseDouble("5"));
 //BA.debugLineNum = 35;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 36;BA.debugLine="Visibility = App.EnumVisibility.visible";
_visibility = _app._enumvisibility._visible;
 //BA.debugLineNum = 37;BA.debugLine="ZDepth = App.EnumZDepth.zdepth_none";
_zdepth = _app._enumzdepth._zdepth_none;
 //BA.debugLineNum = 38;BA.debugLine="VerticallyAlign = True";
_verticallyalign = __c.True;
 //BA.debugLineNum = 39;BA.debugLine="div.Initialize(ID,\"div\")";
_div._initialize(ba,_id,"div");
 //BA.debugLineNum = 40;BA.debugLine="div.AddClass(ID)";
_div._addclass(_id);
 //BA.debugLineNum = 41;BA.debugLine="div.AddStyleAttribute(\"width\",vWidth & \"px\")";
_div._addstyleattribute("width",_vwidth+"px");
 //BA.debugLineNum = 42;BA.debugLine="div.AddStyleAttribute(\"height\",vHeight & \"px\")";
_div._addstyleattribute("height",_vheight+"px");
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoewaterball  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEWaterBal";
 //BA.debugLineNum = 131;BA.debugLine="div.RemoveAttribute(attr)";
_div._removeattribute(_attr);
 //BA.debugLineNum = 132;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Sub RemoveClass(sClass As String) As UOEWaterBall";
 //BA.debugLineNum = 119;BA.debugLine="div.RemoveClass(sClass)";
_div._removeclass(_sclass);
 //BA.debugLineNum = 120;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _setranges(String _red,String _orange,String _green) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Sub SetRanges(red As String, orange As String, gre";
 //BA.debugLineNum = 53;BA.debugLine="range1 = red";
_range1 = _red;
 //BA.debugLineNum = 54;BA.debugLine="range2 = orange";
_range2 = _orange;
 //BA.debugLineNum = 55;BA.debugLine="range3 = green";
_range3 = _green;
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoewaterball  _setvalues(String _nowrange,String _targetrange) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub SetValues(nowRange As String, targetRange As S";
 //BA.debugLineNum = 61;BA.debugLine="vnowRange = nowRange";
_vnowrange = _nowrange;
 //BA.debugLineNum = 62;BA.debugLine="vtargetRange = targetRange";
_vtargetrange = _targetrange;
 //BA.debugLineNum = 63;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoewaterball)(this);
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 93;BA.debugLine="div.MaterialVisibility(Visibility)";
_div._materialvisibility(_visibility);
 //BA.debugLineNum = 94;BA.debugLine="div.MaterialZDepth(ZDepth)";
_div._materialzdepth(_zdepth);
 //BA.debugLineNum = 95;BA.debugLine="div.MaterialEnable(Enabled)";
_div._materialenable(_enabled);
 //BA.debugLineNum = 96;BA.debugLine="div.MaterialVerticalAlign(VerticallyAlign)";
_div._materialverticalalign(_verticallyalign);
 //BA.debugLineNum = 101;BA.debugLine="Return div.HTML";
if (true) return _div._html();
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
