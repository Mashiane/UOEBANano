package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoedropdownitem extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoedropdownitem", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoedropdownitem.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _li = null;
public String _theme = "";
public String _itemkey = "";
public String _href = "";
public String _text = "";
public boolean _enabled = false;
public String _icon = "";
public b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoedropdownitem  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 37;BA.debugLine="ai.AddAttribute(attr,value)";
_ai._addattribute(_attr,_value);
 //BA.debugLineNum = 38;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdownitem)(this);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdownitem  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub AddClass(sClass As String) As UOEDropDownItem";
 //BA.debugLineNum = 25;BA.debugLine="ai.AddClass(sClass)";
_ai._addclass(_sclass);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdownitem)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdownitem  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 19;BA.debugLine="ai.AddStyleAttribute(attribute,value)";
_ai._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 20;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdownitem)(this);
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Public ItemKey As String";
_itemkey = "";
 //BA.debugLineNum = 9;BA.debugLine="Private href As String";
_href = "";
 //BA.debugLineNum = 10;BA.debugLine="Private Text As String";
_text = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 12;BA.debugLine="Private Icon As String";
_icon = "";
 //BA.debugLineNum = 13;BA.debugLine="Public ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 14;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoehtml  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _parentid,String _itemid,String _itemicon,String _itemtext,String _itemnavigateto,boolean _itemactive,String _itemtheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 48;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,parentID A";
 //BA.debugLineNum = 50;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 51;BA.debugLine="parentID = parentID.ToLowerCase";
_parentid = _parentid.toLowerCase();
 //BA.debugLineNum = 52;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 53;BA.debugLine="ID = itemID";
_id = _itemid;
 //BA.debugLineNum = 54;BA.debugLine="Icon = itemIcon";
_icon = _itemicon;
 //BA.debugLineNum = 55;BA.debugLine="ItemKey = parentID & itemID";
_itemkey = _parentid+_itemid;
 //BA.debugLineNum = 56;BA.debugLine="href = itemNavigateTo";
_href = _itemnavigateto;
 //BA.debugLineNum = 57;BA.debugLine="Text = itemText";
_text = _itemtext;
 //BA.debugLineNum = 58;BA.debugLine="li.Initialize(ItemKey & \"-li\",\"li\")";
_li._initialize(ba,_itemkey+"-li","li");
 //BA.debugLineNum = 59;BA.debugLine="If itemActive = True Then";
if (_itemactive==__c.True) { 
 //BA.debugLineNum = 60;BA.debugLine="li.AddClass(\"active\")";
_li._addclass("active");
 };
 //BA.debugLineNum = 62;BA.debugLine="Theme = itemTheme";
_theme = _itemtheme;
 //BA.debugLineNum = 63;BA.debugLine="Enabled = False";
_enabled = __c.False;
 //BA.debugLineNum = 64;BA.debugLine="ai.Initialize(App,ItemKey,Icon,\"left\",False,Text,";
_ai._initialize(ba,_app,_itemkey,_icon,"left",__c.False,_text,_href,__c.True,_theme,"");
 //BA.debugLineNum = 65;BA.debugLine="ai.a.materialenable(Enabled)";
_ai._a._materialenable(_enabled);
 //BA.debugLineNum = 66;BA.debugLine="Return li";
if (true) return _li;
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdownitem  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEDropDown";
 //BA.debugLineNum = 43;BA.debugLine="ai.RemoveAttribute(attr)";
_ai._removeattribute(_attr);
 //BA.debugLineNum = 44;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdownitem)(this);
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdownitem  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub RemoveClass(sClass As String) As UOEDropDownIt";
 //BA.debugLineNum = 31;BA.debugLine="ai.RemoveClass(sClass)";
_ai._removeclass(_sclass);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdownitem)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _settooltip(String _position,String _delay,String _tooltip) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Sub SetToolTip(position As String, delay As String";
 //BA.debugLineNum = 71;BA.debugLine="ai.a.MaterialSetToolTip(position,delay,tooltip)";
_ai._a._materialsettooltip(_position,_delay,_tooltip);
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 77;BA.debugLine="ai.ID = ItemKey";
_ai._id = _itemkey;
 //BA.debugLineNum = 78;BA.debugLine="ai.Text = Text";
_ai._text = _text;
 //BA.debugLineNum = 79;BA.debugLine="ai.href = href";
_ai._href = _href;
 //BA.debugLineNum = 80;BA.debugLine="ai.a.MaterialEnable(Enabled)";
_ai._a._materialenable(_enabled);
 //BA.debugLineNum = 81;BA.debugLine="App.MaterialUseTheme(Theme,ai.a)";
_app._materialusetheme(_theme,_ai._a);
 //BA.debugLineNum = 82;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 83;BA.debugLine="Return li.html";
if (true) return _li._html();
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
