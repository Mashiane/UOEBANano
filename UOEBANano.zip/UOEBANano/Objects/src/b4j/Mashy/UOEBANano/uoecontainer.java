package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecontainer extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecontainer", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecontainer.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _items = null;
public boolean _enabled = false;
public String _theme = "";
public String _visibility = "";
public String _zdepth = "";
public b4j.Mashy.UOEBANano.uoegrid _grid = null;
public boolean _hoverable = false;
public boolean _centerinpage = false;
public boolean _scrollspy = false;
public boolean _section = false;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public int _divcounter = 0;
public String _j = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecontainer  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 962;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 963;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 964;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 965;BA.debugLine="End Sub";
return null;
}
public String  _addbillboardchart(int _row,int _col,b4j.Mashy.UOEBANano.uoebillboardchart _cont) throws Exception{
String _jscode = "";
 //BA.debugLineNum = 942;BA.debugLine="Sub AddBillBoardChart(row As Int,col As Int,cont A";
 //BA.debugLineNum = 943;BA.debugLine="AddComponent(row,col,cont.tostring)";
_addcomponent(_row,_col,_cont._tostring());
 //BA.debugLineNum = 944;BA.debugLine="Dim jscode As String = cont.getjavascript";
_jscode = _cont._getjavascript();
 //BA.debugLineNum = 945;BA.debugLine="App.JS.Add(jscode)";
_app._js.Add((Object)(_jscode));
 //BA.debugLineNum = 946;BA.debugLine="End Sub";
return "";
}
public String  _addblockquote(int _row,int _column,String _paraid,String _paratext,int _parawidth,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 754;BA.debugLine="Sub AddBlockQuote(row As Int,column As Int, paraid";
 //BA.debugLineNum = 755;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 756;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 757;BA.debugLine="ml.Initialize(App,paraid,\"h5\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h5",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 758;BA.debugLine="ml.BlockQuote = True";
_ml._blockquote = __c.True;
 //BA.debugLineNum = 759;BA.debugLine="ml.BlockQuoteWidth = paraWidth";
_ml._blockquotewidth = _parawidth;
 //BA.debugLineNum = 760;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 761;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 762;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 763;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 764;BA.debugLine="End Sub";
return "";
}
public String  _addbreadcrumbs(int _row,int _col,b4j.Mashy.UOEBANano.uoebreadcrumbs _cont) throws Exception{
 //BA.debugLineNum = 534;BA.debugLine="Sub AddBreadCrumbs(row As Int,col As Int,cont As U";
 //BA.debugLineNum = 535;BA.debugLine="RemoveComponent(cont.ID)";
_removecomponent(_cont._id);
 //BA.debugLineNum = 543;BA.debugLine="AddComponent(row,col,cont.tostring)";
_addcomponent(_row,_col,_cont._tostring());
 //BA.debugLineNum = 544;BA.debugLine="End Sub";
return "";
}
public String  _addbreak(int _row,int _column) throws Exception{
 //BA.debugLineNum = 523;BA.debugLine="Sub AddBreak(row As Int, column As Int)";
 //BA.debugLineNum = 524;BA.debugLine="AddParagraph(row,column,\"\",\"{BR}\",\"\",\"\")";
_addparagraph(_row,_column,"","{BR}","","");
 //BA.debugLineNum = 525;BA.debugLine="End Sub";
return "";
}
public String  _addbutton(int _row,int _column,b4j.Mashy.UOEBANano.uoebutton _btndef,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 554;BA.debugLine="Sub AddButton(row As Int,column As Int, btnDef As";
 //BA.debugLineNum = 555;BA.debugLine="RemoveComponent(btnDef.ID)";
_removecomponent(_btndef._id);
 //BA.debugLineNum = 556;BA.debugLine="AddComponent(row,column,btnDef.tostring)";
_addcomponent(_row,_column,_btndef._tostring());
 //BA.debugLineNum = 557;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 558;BA.debugLine="App.AddEvent(btnDef.id, \"click\")";
_app._addevent(_btndef._id,"click");
 };
 //BA.debugLineNum = 560;BA.debugLine="End Sub";
return "";
}
public String  _addbutton1(int _row,int _column,String _btnid,String _btntext,String _btnnavigateto,String _btntype,String _btnicon,String _btnsize,boolean _btnfitwidth,boolean _bpulse,boolean _benabled,String _btntheme,String _cclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 583;BA.debugLine="Sub AddButton1(row As Int,column As Int, btnID As";
 //BA.debugLineNum = 584;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 585;BA.debugLine="btn.Initialize(App,btnID,btnText,btnTheme)";
_btn._initialize(ba,_app,_btnid,_btntext,_btntheme);
 //BA.debugLineNum = 586;BA.debugLine="btn.HREF = btnNavigateTo";
_btn._href = _btnnavigateto;
 //BA.debugLineNum = 587;BA.debugLine="btn.SetButtonType(btnType)";
_btn._setbuttontype(_btntype);
 //BA.debugLineNum = 588;BA.debugLine="btn.Size = btnSize";
_btn._size = _btnsize;
 //BA.debugLineNum = 589;BA.debugLine="btn.Pulsing = bPulse";
_btn._pulsing = _bpulse;
 //BA.debugLineNum = 590;BA.debugLine="btn.Enabled = bEnabled";
_btn._enabled = _benabled;
 //BA.debugLineNum = 591;BA.debugLine="btn.AddClass(cClass)";
_btn._addclass(_cclass);
 //BA.debugLineNum = 592;BA.debugLine="btn.WavesType = App.EnumWavesType.light";
_btn._wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 593;BA.debugLine="btn.AddJustIcon(btnIcon)";
_btn._addjusticon(_btnicon);
 //BA.debugLineNum = 594;BA.debugLine="btn.FitWidth = btnFitWidth";
_btn._fitwidth = _btnfitwidth;
 //BA.debugLineNum = 595;BA.debugLine="AddButton(row,column,btn,hasEvent)";
_addbutton(_row,_column,_btn,_hasevent);
 //BA.debugLineNum = 596;BA.debugLine="End Sub";
return "";
}
public String  _addcard(int _row,int _column,b4j.Mashy.UOEBANano.uoecard _card) throws Exception{
 //BA.debugLineNum = 528;BA.debugLine="Sub AddCard(row As Int, column As Int, card As UOE";
 //BA.debugLineNum = 529;BA.debugLine="RemoveComponent(card.ID)";
_removecomponent(_card._id);
 //BA.debugLineNum = 530;BA.debugLine="AddComponent(row,column,card.tostring)";
_addcomponent(_row,_column,_card._tostring());
 //BA.debugLineNum = 531;BA.debugLine="End Sub";
return "";
}
public String  _addcarousel(int _row,int _column,b4j.Mashy.UOEBANano.uoecarousel _carousel) throws Exception{
String _settings = "";
 //BA.debugLineNum = 504;BA.debugLine="Sub AddCarousel(row As Int, column As Int, carouse";
 //BA.debugLineNum = 505;BA.debugLine="RemoveComponent(carousel.ID)";
_removecomponent(_carousel._id);
 //BA.debugLineNum = 507;BA.debugLine="Dim settings As String = carousel.getSettings";
_settings = _carousel._getsettings();
 //BA.debugLineNum = 508;BA.debugLine="App.Components.Add(settings)";
_app._components.Add((Object)(_settings));
 //BA.debugLineNum = 509;BA.debugLine="AddComponent(row,column,carousel.tostring)";
_addcomponent(_row,_column,_carousel._tostring());
 //BA.debugLineNum = 510;BA.debugLine="End Sub";
return "";
}
public String  _addcheckbox(int _row,int _column,b4j.Mashy.UOEBANano.uoecheckbox _checkbox) throws Exception{
 //BA.debugLineNum = 486;BA.debugLine="Sub AddCheckBox(row As Int, column As Int, checkBo";
 //BA.debugLineNum = 487;BA.debugLine="RemoveComponent(checkBox.ID)";
_removecomponent(_checkbox._id);
 //BA.debugLineNum = 488;BA.debugLine="AddComponent(row,column,checkBox.tostring)";
_addcomponent(_row,_column,_checkbox._tostring());
 //BA.debugLineNum = 489;BA.debugLine="End Sub";
return "";
}
public String  _addcheckbox1(int _row,int _column,String _cid,String _cvalue,String _ctitle,boolean _bchecked,boolean _bfilledin,boolean _benabled,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoecheckbox _c1 = null;
 //BA.debugLineNum = 492;BA.debugLine="Sub AddCheckBox1(row As Int, column As Int, cID As";
 //BA.debugLineNum = 493;BA.debugLine="Dim c1 As UOECheckBox";
_c1 = new b4j.Mashy.UOEBANano.uoecheckbox();
 //BA.debugLineNum = 494;BA.debugLine="c1.Initialize(App,cID,cID,cValue,cTitle,cTheme)";
_c1._initialize(ba,_app,_cid,_cid,_cvalue,_ctitle,_ctheme);
 //BA.debugLineNum = 495;BA.debugLine="c1.AddClass(cClass)";
_c1._addclass(_cclass);
 //BA.debugLineNum = 496;BA.debugLine="c1.Checked = bChecked";
_c1._checked = _bchecked;
 //BA.debugLineNum = 497;BA.debugLine="c1.FilledIn = bFilledIn";
_c1._filledin = _bfilledin;
 //BA.debugLineNum = 498;BA.debugLine="c1.Enabled = bEnabled";
_c1._enabled = _benabled;
 //BA.debugLineNum = 499;BA.debugLine="AddCheckBox(row,column,c1)";
_addcheckbox(_row,_column,_c1);
 //BA.debugLineNum = 500;BA.debugLine="End Sub";
return "";
}
public String  _addcheckboxgroup(int _row,int _column,b4j.Mashy.UOEBANano.uoecheckboxgroup _rg) throws Exception{
 //BA.debugLineNum = 480;BA.debugLine="Sub AddCheckBoxGroup(row As Int, column As Int, rg";
 //BA.debugLineNum = 481;BA.debugLine="RemoveComponent(rg.ID)";
_removecomponent(_rg._id);
 //BA.debugLineNum = 482;BA.debugLine="AddComponent(row,column,rg.ToString)";
_addcomponent(_row,_column,_rg._tostring());
 //BA.debugLineNum = 483;BA.debugLine="End Sub";
return "";
}
public String  _addchip(int _row,int _column,b4j.Mashy.UOEBANano.uoechip _chip,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 455;BA.debugLine="Sub AddChip(row As Int, column As Int, chip As UOE";
 //BA.debugLineNum = 456;BA.debugLine="RemoveComponent(chip.ID)";
_removecomponent(_chip._id);
 //BA.debugLineNum = 457;BA.debugLine="AddComponent(row,column,chip.ToString)";
_addcomponent(_row,_column,_chip._tostring());
 //BA.debugLineNum = 458;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 459;BA.debugLine="App.AddEvent(chip.ID,\"click\")";
_app._addevent(_chip._id,"click");
 };
 //BA.debugLineNum = 461;BA.debugLine="End Sub";
return "";
}
public String  _addchip1(int _row,int _column,String _cid,String _ctitle,String _cimageurl,boolean _ccanclose,String _ctheme,String _cclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoechip _chip = null;
 //BA.debugLineNum = 464;BA.debugLine="Sub AddChip1(row As Int, column As Int, cID As Str";
 //BA.debugLineNum = 465;BA.debugLine="Dim chip As UOEChip";
_chip = new b4j.Mashy.UOEBANano.uoechip();
 //BA.debugLineNum = 466;BA.debugLine="chip.Initialize(App,cID,cTitle, cImageURL,\"\",cThe";
_chip._initialize(ba,_app,_cid,_ctitle,_cimageurl,"",_ctheme);
 //BA.debugLineNum = 467;BA.debugLine="chip.CanClose = cCanClose";
_chip._canclose = _ccanclose;
 //BA.debugLineNum = 468;BA.debugLine="chip.AddClass(cClass)";
_chip._addclass(_cclass);
 //BA.debugLineNum = 469;BA.debugLine="AddChip(row,column,chip,hasEvent)";
_addchip(_row,_column,_chip,_hasevent);
 //BA.debugLineNum = 470;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 950;BA.debugLine="Sub AddClass(sClass As String) As UOEContainer";
 //BA.debugLineNum = 951;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 952;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 953;BA.debugLine="End Sub";
return null;
}
public String  _addcollapsible(int _row,int _column,b4j.Mashy.UOEBANano.uoecollapsible _rg) throws Exception{
 //BA.debugLineNum = 473;BA.debugLine="Sub AddCollapsible(row As Int, column As Int, rg A";
 //BA.debugLineNum = 474;BA.debugLine="RemoveComponent(rg.ID)";
_removecomponent(_rg._id);
 //BA.debugLineNum = 475;BA.debugLine="AddComponent(row,column,rg.ToString)";
_addcomponent(_row,_column,_rg._tostring());
 //BA.debugLineNum = 476;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _addcolumnclass(int _rowpos,int _columnpos,String _classname) throws Exception{
 //BA.debugLineNum = 902;BA.debugLine="Sub AddColumnClass(rowPos As Int, columnPos As Int";
 //BA.debugLineNum = 903;BA.debugLine="Grid.setColumnClass(rowPos,columnPos,className)";
_grid._setcolumnclass(_rowpos,_columnpos,_classname);
 //BA.debugLineNum = 904;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 905;BA.debugLine="End Sub";
return null;
}
public String  _addcomponent(int _rowpos,int _colpos,String _elhtml) throws Exception{
 //BA.debugLineNum = 994;BA.debugLine="Sub AddComponent(rowPos As Int, colPos As Int, elH";
 //BA.debugLineNum = 996;BA.debugLine="If rowPos = 0 And colPos = 0 Then";
if (_rowpos==0 && _colpos==0) { 
 //BA.debugLineNum = 997;BA.debugLine="AddContent(elHTML)";
_addcontent(_elhtml);
 }else {
 //BA.debugLineNum = 999;BA.debugLine="Grid.AddComponent(rowPos,colPos,elHTML)";
_grid._addcomponent(_rowpos,_colpos,_elhtml);
 };
 //BA.debugLineNum = 1001;BA.debugLine="End Sub";
return "";
}
public String  _addcontainer(int _row,int _column,b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
 //BA.debugLineNum = 548;BA.debugLine="Sub AddContainer(row As Int, column As Int, cont A";
 //BA.debugLineNum = 549;BA.debugLine="RemoveComponent(cont.ID)";
_removecomponent(_cont._id);
 //BA.debugLineNum = 550;BA.debugLine="AddComponent(row,column,cont.tostring)";
_addcomponent(_row,_column,_cont._tostring());
 //BA.debugLineNum = 551;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _addcontent(String _scontent) throws Exception{
 //BA.debugLineNum = 988;BA.debugLine="Sub AddContent(sContent As String) As UOEContainer";
 //BA.debugLineNum = 989;BA.debugLine="Element.AddContent(sContent)";
_element._addcontent(_scontent);
 //BA.debugLineNum = 990;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 991;BA.debugLine="End Sub";
return null;
}
public String  _addcontentlist(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
String _strcontent = "";
 //BA.debugLineNum = 1036;BA.debugLine="Sub AddContentList(lst As List)";
 //BA.debugLineNum = 1037;BA.debugLine="For Each strContent As String In lst";
{
final anywheresoftware.b4a.BA.IterableList group1 = _lst;
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_strcontent = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 1038;BA.debugLine="AddContent(strContent)";
_addcontent(_strcontent);
 }
};
 //BA.debugLineNum = 1040;BA.debugLine="End Sub";
return "";
}
public String  _addcontentlistreverse(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
int _ltot = 0;
int _lcnt = 0;
String _strcontent = "";
 //BA.debugLineNum = 1043;BA.debugLine="Sub AddContentListReverse(lst As List)";
 //BA.debugLineNum = 1044;BA.debugLine="Dim lTot As Int = lst.Size - 1";
_ltot = (int) (_lst.getSize()-1);
 //BA.debugLineNum = 1045;BA.debugLine="Dim lCnt As Int";
_lcnt = 0;
 //BA.debugLineNum = 1046;BA.debugLine="For lCnt = lTot To 0 Step -1";
{
final int step3 = -1;
final int limit3 = (int) (0);
_lcnt = _ltot ;
for (;_lcnt >= limit3 ;_lcnt = _lcnt + step3 ) {
 //BA.debugLineNum = 1047;BA.debugLine="Dim strContent As String = lst.Get(lCnt)";
_strcontent = BA.ObjectToString(_lst.Get(_lcnt));
 //BA.debugLineNum = 1048;BA.debugLine="AddContent(strContent)";
_addcontent(_strcontent);
 }
};
 //BA.debugLineNum = 1050;BA.debugLine="End Sub";
return "";
}
public String  _addcsscodeblock(int _row,int _column,String _code) throws Exception{
String _codeid = "";
 //BA.debugLineNum = 49;BA.debugLine="Sub AddCSSCodeBlock(row As Int, column As Int, cod";
 //BA.debugLineNum = 50;BA.debugLine="App.codeblock = App.codeblock + 1";
_app._codeblock = (int) (_app._codeblock+1);
 //BA.debugLineNum = 51;BA.debugLine="Dim codeid As String = $\"cd${App.codeblock}\"$";
_codeid = ("cd"+__c.SmartStringFormatter("",(Object)(_app._codeblock))+"");
 //BA.debugLineNum = 52;BA.debugLine="AddPrismCode(row,column,codeid,code,\"css\")";
_addprismcode(_row,_column,_codeid,_code,"css");
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return "";
}
public String  _adddatepicker(int _row,int _column,b4j.Mashy.UOEBANano.uoedatepicker _datepicker) throws Exception{
String _dps = "";
 //BA.debugLineNum = 432;BA.debugLine="Sub AddDatePicker(row As Int, column As Int, DateP";
 //BA.debugLineNum = 433;BA.debugLine="RemoveComponent(DatePicker.ID)";
_removecomponent(_datepicker._id);
 //BA.debugLineNum = 435;BA.debugLine="Dim dpS As String = DatePicker.getSettings";
_dps = _datepicker._getsettings();
 //BA.debugLineNum = 438;BA.debugLine="App.Components.Add(dpS)";
_app._components.Add((Object)(_dps));
 //BA.debugLineNum = 439;BA.debugLine="AddComponent(row,column,DatePicker.tostring)";
_addcomponent(_row,_column,_datepicker._tostring());
 //BA.debugLineNum = 440;BA.debugLine="End Sub";
return "";
}
public String  _adddatepicker1(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoedatepicker _dp = null;
 //BA.debugLineNum = 1013;BA.debugLine="Sub AddDatePicker1(row As Int, column As Int, cID";
 //BA.debugLineNum = 1014;BA.debugLine="Dim dp As UOEDatePicker";
_dp = new b4j.Mashy.UOEBANano.uoedatepicker();
 //BA.debugLineNum = 1015;BA.debugLine="dp.Initialize(App,cID,cTitle,App.EnumDateTimeType";
_dp._initialize(ba,_app,_cid,_ctitle,_app._enumdatetimetype._datepicker,_ctheme);
 //BA.debugLineNum = 1016;BA.debugLine="dp.showClearBtn = True";
_dp._showclearbtn = __c.True;
 //BA.debugLineNum = 1017;BA.debugLine="dp.DateTimeFormat = \"YYYY-MM-DD\"";
_dp._datetimeformat = "YYYY-MM-DD";
 //BA.debugLineNum = 1018;BA.debugLine="dp.IconName = cIconName";
_dp._iconname = _ciconname;
 //BA.debugLineNum = 1019;BA.debugLine="dp.AddClass(cClass)";
_dp._addclass(_cclass);
 //BA.debugLineNum = 1020;BA.debugLine="AddDatePicker(row,column,dp)";
_adddatepicker(_row,_column,_dp);
 //BA.debugLineNum = 1021;BA.debugLine="End Sub";
return "";
}
public String  _adddivider(int _row,int _column,String _ctheme) throws Exception{
String _dkey = "";
b4j.Mashy.UOEBANano.uoedivider _div = null;
 //BA.debugLineNum = 778;BA.debugLine="Sub AddDivider(row As Int, column As Int, cTheme A";
 //BA.debugLineNum = 779;BA.debugLine="divCounter = divCounter + 1";
_divcounter = (int) (_divcounter+1);
 //BA.debugLineNum = 780;BA.debugLine="Dim dKey As String = $\"divider${divCounter}\"$";
_dkey = ("divider"+__c.SmartStringFormatter("",(Object)(_divcounter))+"");
 //BA.debugLineNum = 781;BA.debugLine="Dim div As UOEDivider";
_div = new b4j.Mashy.UOEBANano.uoedivider();
 //BA.debugLineNum = 782;BA.debugLine="div.Initialize(App,dKey,cTheme)";
_div._initialize(ba,_app,_dkey,_ctheme);
 //BA.debugLineNum = 783;BA.debugLine="AddComponent(row,column,div.tostring)";
_addcomponent(_row,_column,_div._tostring());
 //BA.debugLineNum = 784;BA.debugLine="End Sub";
return "";
}
public String  _adddropdown(int _row,int _col,b4j.Mashy.UOEBANano.uoedropdown _eldropdown) throws Exception{
String _dds = "";
 //BA.debugLineNum = 418;BA.debugLine="Sub AddDropdown(row As Int, col As Int, elDropDown";
 //BA.debugLineNum = 419;BA.debugLine="RemoveComponent(elDropDown.ID)";
_removecomponent(_eldropdown._id);
 //BA.debugLineNum = 420;BA.debugLine="Dim dds As String = elDropDown.getSettings";
_dds = _eldropdown._getsettings();
 //BA.debugLineNum = 421;BA.debugLine="App.Components.Add(dds)";
_app._components.Add((Object)(_dds));
 //BA.debugLineNum = 422;BA.debugLine="AddComponent(row,col,elDropDown.ToString)";
_addcomponent(_row,_col,_eldropdown._tostring());
 //BA.debugLineNum = 423;BA.debugLine="End Sub";
return "";
}
public String  _addelement(b4j.Mashy.UOEBANano.uoehtml _el) throws Exception{
String _scode = "";
 //BA.debugLineNum = 841;BA.debugLine="Sub AddElement(el As UOEHTML)";
 //BA.debugLineNum = 842;BA.debugLine="If el <> Null Then";
if (_el!= null) { 
 //BA.debugLineNum = 843;BA.debugLine="Dim scode As String = el.tostring";
_scode = _el._tostring();
 //BA.debugLineNum = 844;BA.debugLine="RemoveComponent(el.ID)";
_removecomponent(_el._id);
 //BA.debugLineNum = 845;BA.debugLine="Element.AddContent(scode)";
_element._addcontent(_scode);
 };
 //BA.debugLineNum = 847;BA.debugLine="End Sub";
return "";
}
public String  _addemail(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _cplaceholder,String _chelpertext,int _clength,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeinput _inp = null;
 //BA.debugLineNum = 219;BA.debugLine="Sub AddEmail(row As Int, column As Int, cID As Str";
 //BA.debugLineNum = 220;BA.debugLine="Dim inp As UOEInput";
_inp = new b4j.Mashy.UOEBANano.uoeinput();
 //BA.debugLineNum = 221;BA.debugLine="inp.Initialize(App,cID,cTitle,cPlaceHolder,App.En";
_inp._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_app._enuminputtype._email,_ctheme);
 //BA.debugLineNum = 222;BA.debugLine="inp.HelperText = cHelperText";
_inp._helpertext = _chelpertext;
 //BA.debugLineNum = 223;BA.debugLine="inp.IconName = cIconName";
_inp._iconname = _ciconname;
 //BA.debugLineNum = 224;BA.debugLine="inp.MaxLength = cLength";
_inp._maxlength = _clength;
 //BA.debugLineNum = 225;BA.debugLine="inp.AddClass(cClass)";
_inp._addclass(_cclass);
 //BA.debugLineNum = 226;BA.debugLine="AddInput(row,column,inp)";
_addinput(_row,_column,_inp);
 //BA.debugLineNum = 227;BA.debugLine="End Sub";
return "";
}
public String  _addfab(b4j.Mashy.UOEBANano.uoefab _fab,boolean _hasevent) throws Exception{
String _dps = "";
 //BA.debugLineNum = 563;BA.debugLine="Sub AddFAB(fab As UOEFAB, hasEvent As Boolean)";
 //BA.debugLineNum = 564;BA.debugLine="RemoveComponent(fab.ID)";
_removecomponent(_fab._id);
 //BA.debugLineNum = 565;BA.debugLine="Dim dpS As String = fab.getSettings";
_dps = _fab._getsettings();
 //BA.debugLineNum = 568;BA.debugLine="App.Components.Add(dpS)";
_app._components.Add((Object)(_dps));
 //BA.debugLineNum = 569;BA.debugLine="AddComponent(0,0,fab.tostring)";
_addcomponent((int) (0),(int) (0),_fab._tostring());
 //BA.debugLineNum = 570;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 571;BA.debugLine="App.AddEvent(fab.ID, \"click\")";
_app._addevent(_fab._id,"click");
 };
 //BA.debugLineNum = 573;BA.debugLine="End Sub";
return "";
}
public String  _addfab1(String _fabid,String _href,String _icon,String _svisibility,String _icontheme,String _fabclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoefab _fab = null;
 //BA.debugLineNum = 575;BA.debugLine="Sub AddFab1(fabID As String, href As String, icon";
 //BA.debugLineNum = 576;BA.debugLine="Dim fab As UOEFAB";
_fab = new b4j.Mashy.UOEBANano.uoefab();
 //BA.debugLineNum = 577;BA.debugLine="fab.Initialize(App,fabID,href,icon, App.EnumButto";
_fab._initialize(ba,_app,_fabid,_href,_icon,_app._enumbuttonsize._large,_svisibility,_icontheme);
 //BA.debugLineNum = 578;BA.debugLine="fab.AddClass(fabClass)";
_fab._addclass(_fabclass);
 //BA.debugLineNum = 579;BA.debugLine="AddFAB(fab,hasEvent)";
_addfab(_fab,_hasevent);
 //BA.debugLineNum = 580;BA.debugLine="End Sub";
return "";
}
public String  _addfeature(b4j.Mashy.UOEBANano.uoefeature _feat) throws Exception{
 //BA.debugLineNum = 406;BA.debugLine="Sub AddFeature(feat As UOEFeature)";
 //BA.debugLineNum = 407;BA.debugLine="RemoveComponent(feat.ID)";
_removecomponent(_feat._id);
 //BA.debugLineNum = 408;BA.debugLine="AddComponent(0,0,feat.ToString)";
_addcomponent((int) (0),(int) (0),_feat._tostring());
 //BA.debugLineNum = 409;BA.debugLine="End Sub";
return "";
}
public String  _addfeature1(String _fid,String _stitle,String _sdescription,String _target,String _sthemename,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoefeature _md = null;
 //BA.debugLineNum = 311;BA.debugLine="Sub AddFeature1(fID As String, sTitle As String, s";
 //BA.debugLineNum = 312;BA.debugLine="Dim md As UOEFeature";
_md = new b4j.Mashy.UOEBANano.uoefeature();
 //BA.debugLineNum = 313;BA.debugLine="md.Initialize(App,fID,sTitle,sDescription,sThemeN";
_md._initialize(ba,_app,_fid,_stitle,_sdescription,_sthemename,_target);
 //BA.debugLineNum = 314;BA.debugLine="md.addclass(cClass)";
_md._addclass(_cclass);
 //BA.debugLineNum = 315;BA.debugLine="AddFeature(md)";
_addfeature(_md);
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
public String  _addfile(int _row,int _col,b4j.Mashy.UOEBANano.uoefile _elfile) throws Exception{
 //BA.debugLineNum = 412;BA.debugLine="Sub AddFile(row As Int, col As Int, elFile As UOEF";
 //BA.debugLineNum = 413;BA.debugLine="RemoveComponent(elFile.ID)";
_removecomponent(_elfile._id);
 //BA.debugLineNum = 414;BA.debugLine="AddComponent(row,col,elFile.ToString)";
_addcomponent(_row,_col,_elfile._tostring());
 //BA.debugLineNum = 415;BA.debugLine="End Sub";
return "";
}
public String  _addfile1(int _row,int _column,String _cid,String _ctitle,String _cplaceholder,String _chelpertext,boolean _bmultiple,boolean _bhideinput,boolean _bfitwidth,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoefile _fu = null;
 //BA.debugLineNum = 265;BA.debugLine="Sub AddFile1(row As Int, column As Int, cID As Str";
 //BA.debugLineNum = 266;BA.debugLine="Dim fu As UOEFile";
_fu = new b4j.Mashy.UOEBANano.uoefile();
 //BA.debugLineNum = 267;BA.debugLine="fu.Initialize(App,cID,cTitle,cPlaceHolder,bMultip";
_fu._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_bmultiple,_ctheme);
 //BA.debugLineNum = 268;BA.debugLine="fu.HelperText = cHelperText";
_fu._helpertext = _chelpertext;
 //BA.debugLineNum = 269;BA.debugLine="fu.AddClass(cClass)";
_fu._addclass(_cclass);
 //BA.debugLineNum = 270;BA.debugLine="fu.HideInput = bHideInput";
_fu._hideinput = _bhideinput;
 //BA.debugLineNum = 271;BA.debugLine="fu.FitWidth = bFitWidth";
_fu._fitwidth = _bfitwidth;
 //BA.debugLineNum = 272;BA.debugLine="AddFile(row,column,fu)";
_addfile(_row,_column,_fu);
 //BA.debugLineNum = 273;BA.debugLine="End Sub";
return "";
}
public String  _addflatbutton(int _row,int _column,String _btnid,String _btntext,String _btnvisibility,String _btnnavigateto,String _btntheme,String _cclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 640;BA.debugLine="Sub AddFlatButton(row As Int,column As Int, btnID";
 //BA.debugLineNum = 641;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 642;BA.debugLine="btn.Initialize(App,btnID,btnText,btnTheme)";
_btn._initialize(ba,_app,_btnid,_btntext,_btntheme);
 //BA.debugLineNum = 643;BA.debugLine="btn.Visibility = btnVisibility";
_btn._visibility = _btnvisibility;
 //BA.debugLineNum = 644;BA.debugLine="btn.HREF = btnNavigateTo";
_btn._href = _btnnavigateto;
 //BA.debugLineNum = 645;BA.debugLine="btn.SetButtonType(App.EnumButtonType.flat)";
_btn._setbuttontype(_app._enumbuttontype._flat);
 //BA.debugLineNum = 646;BA.debugLine="btn.Size = App.enumbuttonsize.medium";
_btn._size = _app._enumbuttonsize._medium;
 //BA.debugLineNum = 647;BA.debugLine="btn.AddClass(cClass)";
_btn._addclass(_cclass);
 //BA.debugLineNum = 648;BA.debugLine="btn.FitWidth = False";
_btn._fitwidth = __c.False;
 //BA.debugLineNum = 649;BA.debugLine="AddButton(row,column,btn,hasEvent)";
_addbutton(_row,_column,_btn,_hasevent);
 //BA.debugLineNum = 650;BA.debugLine="End Sub";
return "";
}
public String  _addfloatingbutton(int _row,int _column,String _btnid,String _btnicon,String _btnvisibility,String _btnnavigateto,String _btntheme,String _cclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 613;BA.debugLine="Sub AddFloatingButton(row As Int,column As Int, bt";
 //BA.debugLineNum = 614;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 615;BA.debugLine="btn.Initialize(App,btnID,\"\",btnTheme)";
_btn._initialize(ba,_app,_btnid,"",_btntheme);
 //BA.debugLineNum = 616;BA.debugLine="btn.Visibility = btnVisibility";
_btn._visibility = _btnvisibility;
 //BA.debugLineNum = 617;BA.debugLine="btn.HREF = btnNavigateTo";
_btn._href = _btnnavigateto;
 //BA.debugLineNum = 618;BA.debugLine="btn.SetButtonType(App.EnumButtonType.floating)";
_btn._setbuttontype(_app._enumbuttontype._floating);
 //BA.debugLineNum = 619;BA.debugLine="btn.Size = App.EnumButtonSize.medium";
_btn._size = _app._enumbuttonsize._medium;
 //BA.debugLineNum = 620;BA.debugLine="btn.AddClass(cClass)";
_btn._addclass(_cclass);
 //BA.debugLineNum = 621;BA.debugLine="btn.AddJustIcon(btnIcon)";
_btn._addjusticon(_btnicon);
 //BA.debugLineNum = 622;BA.debugLine="btn.FitWidth = False";
_btn._fitwidth = __c.False;
 //BA.debugLineNum = 623;BA.debugLine="AddButton(row,column,btn,hasEvent)";
_addbutton(_row,_column,_btn,_hasevent);
 //BA.debugLineNum = 624;BA.debugLine="End Sub";
return "";
}
public String  _addfooter(b4j.Mashy.UOEBANano.uoefooter _foot) throws Exception{
 //BA.debugLineNum = 443;BA.debugLine="Sub AddFooter(foot As UOEFooter)";
 //BA.debugLineNum = 444;BA.debugLine="RemoveComponent(foot.id)";
_removecomponent(_foot._id);
 //BA.debugLineNum = 445;BA.debugLine="AddComponent(0,0,foot.ToString)";
_addcomponent((int) (0),(int) (0),_foot._tostring());
 //BA.debugLineNum = 446;BA.debugLine="End Sub";
return "";
}
public String  _addh1(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 678;BA.debugLine="Sub AddH1(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 679;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 680;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 681;BA.debugLine="ml.Initialize(App,paraid,\"h1\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h1",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 682;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 683;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 684;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 685;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 686;BA.debugLine="End Sub";
return "";
}
public String  _addh2(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 689;BA.debugLine="Sub AddH2(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 690;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 691;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 692;BA.debugLine="ml.Initialize(App,paraid,\"h2\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h2",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 693;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 694;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 695;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 696;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 697;BA.debugLine="End Sub";
return "";
}
public String  _addh3(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 700;BA.debugLine="Sub AddH3(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 701;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 702;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 703;BA.debugLine="ml.Initialize(App,paraid,\"h3\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h3",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 704;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 705;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 706;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 707;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 708;BA.debugLine="End Sub";
return "";
}
public String  _addh4(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 711;BA.debugLine="Sub AddH4(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 712;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 713;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 714;BA.debugLine="ml.Initialize(App,paraid,\"h4\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h4",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 715;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 716;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 717;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 718;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 719;BA.debugLine="End Sub";
return "";
}
public String  _addh5(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 722;BA.debugLine="Sub AddH5(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 723;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 724;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 725;BA.debugLine="ml.Initialize(App,paraid,\"h5\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h5",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 726;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 727;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 728;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 729;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 730;BA.debugLine="End Sub";
return "";
}
public String  _addh6(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 733;BA.debugLine="Sub AddH6(row As Int,column As Int, paraid As Stri";
 //BA.debugLineNum = 734;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 735;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 736;BA.debugLine="ml.Initialize(App,paraid,\"h6\",paraText,paraTheme,";
_ml._initialize(ba,_app,_paraid,"h6",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 737;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 738;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 739;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 740;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 741;BA.debugLine="End Sub";
return "";
}
public String  _addhiddenparagraph(int _row,int _column,String _paraid,String _paratext) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
 //BA.debugLineNum = 745;BA.debugLine="Sub AddHiddenParagraph(row As Int,column As Int, p";
 //BA.debugLineNum = 746;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 747;BA.debugLine="ml.Initialize(App,paraid,\"p\",paratext,\"\",\"\")";
_ml._initialize(ba,_app,_paraid,"p",_paratext,"","");
 //BA.debugLineNum = 748;BA.debugLine="ml.Visibility = \"hide\"";
_ml._visibility = "hide";
 //BA.debugLineNum = 749;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 750;BA.debugLine="AddComponent(row,column,ml.tostring)";
_addcomponent(_row,_column,_ml._tostring());
 //BA.debugLineNum = 751;BA.debugLine="End Sub";
return "";
}
public String  _addhtml5video(int _row,int _col,b4j.Mashy.UOEBANano.uoehtml5video _video) throws Exception{
 //BA.debugLineNum = 394;BA.debugLine="Sub AddHTML5Video(row As Int, col As Int, video As";
 //BA.debugLineNum = 395;BA.debugLine="RemoveComponent(video.ID)";
_removecomponent(_video._id);
 //BA.debugLineNum = 396;BA.debugLine="AddComponent(row,col,video.ToString)";
_addcomponent(_row,_col,_video._tostring());
 //BA.debugLineNum = 397;BA.debugLine="End Sub";
return "";
}
public String  _addhtml5video1(int _row,int _column,String _cid,String _curl,boolean _bautoplay,boolean _ballowfullscreen,boolean _bshowcontrols,boolean _bloop,String _svideotype,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoehtml5video _vid1 = null;
 //BA.debugLineNum = 251;BA.debugLine="Sub AddHTML5Video1(row As Int, column As Int, cID";
 //BA.debugLineNum = 252;BA.debugLine="Dim vid1 As UOEHTML5Video";
_vid1 = new b4j.Mashy.UOEBANano.uoehtml5video();
 //BA.debugLineNum = 253;BA.debugLine="vid1.Initialize(App,cID, cURL)";
_vid1._initialize(ba,_app,_cid,_curl);
 //BA.debugLineNum = 254;BA.debugLine="vid1.AddClass(cClass)";
_vid1._addclass(_cclass);
 //BA.debugLineNum = 255;BA.debugLine="vid1.AutoPlay = bAutoPlay";
_vid1._autoplay = _bautoplay;
 //BA.debugLineNum = 256;BA.debugLine="vid1.AllowFullScreen = bAllowFullScreen";
_vid1._allowfullscreen = _ballowfullscreen;
 //BA.debugLineNum = 257;BA.debugLine="vid1.VideoType = sVideoType";
_vid1._videotype = _svideotype;
 //BA.debugLineNum = 258;BA.debugLine="vid1.ShowControls = bShowControls";
_vid1._showcontrols = _bshowcontrols;
 //BA.debugLineNum = 259;BA.debugLine="vid1.LoopIT = bLoop";
_vid1._loopit = _bloop;
 //BA.debugLineNum = 260;BA.debugLine="vid1.Responsive = True";
_vid1._responsive = __c.True;
 //BA.debugLineNum = 261;BA.debugLine="AddHTML5Video(row,column,vid1)";
_addhtml5video(_row,_column,_vid1);
 //BA.debugLineNum = 262;BA.debugLine="End Sub";
return "";
}
public String  _addhtmlcodeblock(int _row,int _column,String _code) throws Exception{
String _codeid = "";
 //BA.debugLineNum = 56;BA.debugLine="Sub AddHTMLCodeBlock(row As Int, column As Int, co";
 //BA.debugLineNum = 57;BA.debugLine="App.codeblock = App.codeblock + 1";
_app._codeblock = (int) (_app._codeblock+1);
 //BA.debugLineNum = 58;BA.debugLine="Dim codeid As String = $\"cd${App.codeblock}\"$";
_codeid = ("cd"+__c.SmartStringFormatter("",(Object)(_app._codeblock))+"");
 //BA.debugLineNum = 59;BA.debugLine="AddPrismCode(row,column,codeid,code,\"html\")";
_addprismcode(_row,_column,_codeid,_code,"html");
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _addicon(int _row,int _col,b4j.Mashy.UOEBANano.uoeicon _icon) throws Exception{
 //BA.debugLineNum = 388;BA.debugLine="Sub AddIcon(row As Int, col As Int, icon As UOEIco";
 //BA.debugLineNum = 389;BA.debugLine="RemoveComponent(icon.ID)";
_removecomponent(_icon._id);
 //BA.debugLineNum = 390;BA.debugLine="AddComponent(row,col,icon.ToString)";
_addcomponent(_row,_col,_icon._tostring());
 //BA.debugLineNum = 391;BA.debugLine="End Sub";
return "";
}
public String  _addicon1(int _row,int _column,String _cid,String _ciconname,String _ciconsize,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeicon _icon = null;
 //BA.debugLineNum = 242;BA.debugLine="Sub AddIcon1(row As Int, column As Int, cID As Str";
 //BA.debugLineNum = 243;BA.debugLine="Dim icon As UOEIcon";
_icon = new b4j.Mashy.UOEBANano.uoeicon();
 //BA.debugLineNum = 244;BA.debugLine="icon.Initialize(App,cID,cIconName,cTheme)";
_icon._initialize(ba,_app,_cid,_ciconname,_ctheme);
 //BA.debugLineNum = 245;BA.debugLine="icon.IconSize = cIconSize";
_icon._iconsize = _ciconsize;
 //BA.debugLineNum = 246;BA.debugLine="icon.AddClass(cClass)";
_icon._addclass(_cclass);
 //BA.debugLineNum = 247;BA.debugLine="AddIcon(row,column,icon)";
_addicon(_row,_column,_icon);
 //BA.debugLineNum = 248;BA.debugLine="End Sub";
return "";
}
public String  _addimage(int _row,int _col,b4j.Mashy.UOEBANano.uoeimage _img) throws Exception{
 //BA.debugLineNum = 382;BA.debugLine="Sub AddImage(row As Int, col As Int, img As UOEIma";
 //BA.debugLineNum = 383;BA.debugLine="RemoveComponent(img.id)";
_removecomponent(_img._id);
 //BA.debugLineNum = 384;BA.debugLine="AddComponent(row,col,img.ToString)";
_addcomponent(_row,_col,_img._tostring());
 //BA.debugLineNum = 385;BA.debugLine="End Sub";
return "";
}
public String  _addimage1(int _row,int _column,String _imgid,String _imgurl,String _imgalt,boolean _imgcircle,String _imgzdepth,boolean _bstatic,boolean _bfixsize,boolean _bresponsive,String _imgheight,String _imgwidth,String _cclass,String _cvisibility) throws Exception{
b4j.Mashy.UOEBANano.uoeimage _imgx = null;
 //BA.debugLineNum = 1053;BA.debugLine="Sub AddImage1(row As Int,column As Int, imgID As S";
 //BA.debugLineNum = 1054;BA.debugLine="imgID = imgID.ToLowerCase";
_imgid = _imgid.toLowerCase();
 //BA.debugLineNum = 1055;BA.debugLine="Dim imgx As UOEImage";
_imgx = new b4j.Mashy.UOEBANano.uoeimage();
 //BA.debugLineNum = 1056;BA.debugLine="imgx.Initialize(App,imgID,imgURL,imgAlt,bStatic)";
_imgx._initialize(ba,_app,_imgid,_imgurl,_imgalt,_bstatic);
 //BA.debugLineNum = 1057;BA.debugLine="imgx.ZDepth = imgZDepth";
_imgx._zdepth = _imgzdepth;
 //BA.debugLineNum = 1058;BA.debugLine="imgx.Circle = imgCircle";
_imgx._circle = _imgcircle;
 //BA.debugLineNum = 1059;BA.debugLine="imgx.Responsive = bResponsive";
_imgx._responsive = _bresponsive;
 //BA.debugLineNum = 1060;BA.debugLine="imgx.MaterialBoxed = bResponsive";
_imgx._materialboxed = _bresponsive;
 //BA.debugLineNum = 1061;BA.debugLine="imgx.AddClass(cClass)";
_imgx._addclass(_cclass);
 //BA.debugLineNum = 1062;BA.debugLine="imgx.Visibility = cVisibility";
_imgx._visibility = _cvisibility;
 //BA.debugLineNum = 1063;BA.debugLine="If bFixSize Then";
if (_bfixsize) { 
 //BA.debugLineNum = 1064;BA.debugLine="imgx.SetSize(imgHeight,imgWidth)";
_imgx._setsize(_imgheight,_imgwidth);
 };
 //BA.debugLineNum = 1066;BA.debugLine="AddImage(row,column,imgx)";
_addimage(_row,_column,_imgx);
 //BA.debugLineNum = 1067;BA.debugLine="End Sub";
return "";
}
public String  _addinput(int _row,int _col,b4j.Mashy.UOEBANano.uoeinput _inp) throws Exception{
String _jscode = "";
 //BA.debugLineNum = 374;BA.debugLine="Sub AddInput(row As Int, col As Int, inp As UOEInp";
 //BA.debugLineNum = 375;BA.debugLine="RemoveComponent(inp.ID)";
_removecomponent(_inp._id);
 //BA.debugLineNum = 376;BA.debugLine="Dim jsCode As String = inp.GetJavaScript";
_jscode = _inp._getjavascript();
 //BA.debugLineNum = 377;BA.debugLine="App.JS.Add(jsCode)";
_app._js.Add((Object)(_jscode));
 //BA.debugLineNum = 378;BA.debugLine="AddComponent(row,col,inp.tostring)";
_addcomponent(_row,_col,_inp._tostring());
 //BA.debugLineNum = 379;BA.debugLine="End Sub";
return "";
}
public String  _addjscodeblock(int _row,int _column,String _code) throws Exception{
String _codeid = "";
 //BA.debugLineNum = 63;BA.debugLine="Sub AddJSCodeBlock(row As Int, column As Int, code";
 //BA.debugLineNum = 64;BA.debugLine="App.codeblock = App.codeblock + 1";
_app._codeblock = (int) (_app._codeblock+1);
 //BA.debugLineNum = 65;BA.debugLine="Dim codeid As String = $\"cd${App.codeblock}\"$";
_codeid = ("cd"+__c.SmartStringFormatter("",(Object)(_app._codeblock))+"");
 //BA.debugLineNum = 66;BA.debugLine="AddPrismCode(row,column,codeid,code,\"js\")";
_addprismcode(_row,_column,_codeid,_code,"js");
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return "";
}
public String  _addlabel(int _row,int _column,b4j.Mashy.UOEBANano.uoelabel _lbl) throws Exception{
String _scode = "";
 //BA.debugLineNum = 659;BA.debugLine="Sub AddLabel(row As Int,column As Int, lbl As UOEL";
 //BA.debugLineNum = 660;BA.debugLine="RemoveComponent(lbl.ID)";
_removecomponent(_lbl._id);
 //BA.debugLineNum = 661;BA.debugLine="Dim scode As String = lbl.tostring";
_scode = _lbl._tostring();
 //BA.debugLineNum = 662;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 663;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 664;BA.debugLine="End Sub";
return "";
}
public String  _addlink(int _row,int _column,String _lnkid,String _lnktext,String _lnkurl) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _a = null;
String _scode = "";
 //BA.debugLineNum = 767;BA.debugLine="Sub AddLink(row As Int, column As Int, lnkID As St";
 //BA.debugLineNum = 768;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 769;BA.debugLine="a.Initialize(lnkID,\"a\")";
_a._initialize(ba,_lnkid,"a");
 //BA.debugLineNum = 770;BA.debugLine="a.SetHREF(lnkURL).AddContent(lnkText)";
_a._sethref(_lnkurl)._addcontent(_lnktext);
 //BA.debugLineNum = 771;BA.debugLine="Dim scode As String = a.tostring";
_scode = _a._tostring();
 //BA.debugLineNum = 772;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 773;BA.debugLine="RemoveComponent(lnkID)";
_removecomponent(_lnkid);
 //BA.debugLineNum = 774;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 775;BA.debugLine="End Sub";
return "";
}
public String  _addlist(int _row,int _col,b4j.Mashy.UOEBANano.uoelist _lst) throws Exception{
 //BA.debugLineNum = 137;BA.debugLine="Sub AddList(row As Int, col As Int, lst As UOEList";
 //BA.debugLineNum = 138;BA.debugLine="RemoveComponent(lst.ID)";
_removecomponent(_lst._id);
 //BA.debugLineNum = 139;BA.debugLine="AddComponent(row,col,lst.ToString)";
_addcomponent(_row,_col,_lst._tostring());
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public String  _addlistview(int _row,int _column,b4j.Mashy.UOEBANano.uoelistview _lv) throws Exception{
 //BA.debugLineNum = 449;BA.debugLine="Sub AddListView(row As Int, column As Int, lv As U";
 //BA.debugLineNum = 450;BA.debugLine="RemoveComponent(lv.ID)";
_removecomponent(_lv._id);
 //BA.debugLineNum = 451;BA.debugLine="AddComponent(row,column,lv.ToString)";
_addcomponent(_row,_column,_lv._tostring());
 //BA.debugLineNum = 452;BA.debugLine="End Sub";
return "";
}
public String  _addmodal(b4j.Mashy.UOEBANano.uoemodal _mdl) throws Exception{
String _mdls = "";
String _cssset = "";
 //BA.debugLineNum = 124;BA.debugLine="Sub AddModal(mdl As UOEModal)";
 //BA.debugLineNum = 125;BA.debugLine="RemoveComponent(mdl.ID)";
_removecomponent(_mdl._id);
 //BA.debugLineNum = 126;BA.debugLine="Dim mdls As String = mdl.getSettings";
_mdls = _mdl._getsettings();
 //BA.debugLineNum = 127;BA.debugLine="App.Components.add(mdls)";
_app._components.Add((Object)(_mdls));
 //BA.debugLineNum = 129;BA.debugLine="If mdl.HideScrollBar Then";
if (_mdl._hidescrollbar) { 
 //BA.debugLineNum = 130;BA.debugLine="Dim cssset As String = mdl.getCSS";
_cssset = _mdl._getcss();
 //BA.debugLineNum = 131;BA.debugLine="App.CSS.Add(cssset)";
_app._css.Add((Object)(_cssset));
 };
 //BA.debugLineNum = 133;BA.debugLine="AddComponent(0,0,mdl.ToString)";
_addcomponent((int) (0),(int) (0),_mdl._tostring());
 //BA.debugLineNum = 134;BA.debugLine="End Sub";
return "";
}
public String  _addnavbar(int _row,int _column,b4j.Mashy.UOEBANano.uoenavbar _nav) throws Exception{
 //BA.debugLineNum = 289;BA.debugLine="Sub AddNavBar(row As Int, column As Int, Nav As UO";
 //BA.debugLineNum = 290;BA.debugLine="RemoveComponent(Nav.ID)";
_removecomponent(_nav._id);
 //BA.debugLineNum = 291;BA.debugLine="AddComponent(row,column,Nav.tostring)";
_addcomponent(_row,_column,_nav._tostring());
 //BA.debugLineNum = 292;BA.debugLine="End Sub";
return "";
}
public String  _addpagination(int _row,int _column,b4j.Mashy.UOEBANano.uoepagination _pagination) throws Exception{
 //BA.debugLineNum = 180;BA.debugLine="Sub AddPagination(row As Int, column As Int, pagin";
 //BA.debugLineNum = 181;BA.debugLine="RemoveComponent(pagination.ID)";
_removecomponent(_pagination._id);
 //BA.debugLineNum = 182;BA.debugLine="AddComponent(row,column,pagination.tostring)";
_addcomponent(_row,_column,_pagination._tostring());
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return "";
}
public String  _addpagination1(int _row,int _column,String _cid,int _cactive,int _cpages,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoepagination _tbl = null;
 //BA.debugLineNum = 186;BA.debugLine="Sub AddPagination1(row As Int, column As Int, cID";
 //BA.debugLineNum = 187;BA.debugLine="Dim tbl As UOEPagination";
_tbl = new b4j.Mashy.UOEBANano.uoepagination();
 //BA.debugLineNum = 188;BA.debugLine="tbl.Initialize(App,cID,cPages,cTheme,cClass)";
_tbl._initialize(ba,_app,_cid,_cpages,_ctheme,_cclass);
 //BA.debugLineNum = 189;BA.debugLine="tbl.ActivePageNumber = cActive";
_tbl._activepagenumber = _cactive;
 //BA.debugLineNum = 190;BA.debugLine="AddPagination(row,column,tbl)";
_addpagination(_row,_column,_tbl);
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
return "";
}
public String  _addparagraph(int _row,int _column,String _paraid,String _paratext,String _paratheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
String _scode = "";
 //BA.debugLineNum = 667;BA.debugLine="Sub AddParagraph(row As Int,column As Int, paraid";
 //BA.debugLineNum = 668;BA.debugLine="paraid = paraid.tolowercase";
_paraid = _paraid.toLowerCase();
 //BA.debugLineNum = 669;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 670;BA.debugLine="ml.Initialize(App,paraid,\"p\",paraText,paraTheme,c";
_ml._initialize(ba,_app,_paraid,"p",_paratext,_paratheme,_cclass);
 //BA.debugLineNum = 671;BA.debugLine="Dim scode As String = ml.tostring";
_scode = _ml._tostring();
 //BA.debugLineNum = 672;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 673;BA.debugLine="RemoveComponent(paraid)";
_removecomponent(_paraid);
 //BA.debugLineNum = 674;BA.debugLine="AddComponent(row,column,scode)";
_addcomponent(_row,_column,_scode);
 //BA.debugLineNum = 675;BA.debugLine="End Sub";
return "";
}
public String  _addparallax(int _row,int _column,b4j.Mashy.UOEBANano.uoeparallax _parallax) throws Exception{
 //BA.debugLineNum = 296;BA.debugLine="Sub AddParallax(row As Int, column As Int, paralla";
 //BA.debugLineNum = 297;BA.debugLine="RemoveComponent(parallax.ID)";
_removecomponent(_parallax._id);
 //BA.debugLineNum = 298;BA.debugLine="AddComponent(row,column,parallax.tostring)";
_addcomponent(_row,_column,_parallax._tostring());
 //BA.debugLineNum = 299;BA.debugLine="End Sub";
return "";
}
public String  _addparallax1(int _row,int _column,String _cid,String _curl,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeparallax _par = null;
 //BA.debugLineNum = 302;BA.debugLine="Sub AddParallax1(row As Int, column As Int, cID As";
 //BA.debugLineNum = 303;BA.debugLine="Dim par As UOEParallax";
_par = new b4j.Mashy.UOEBANano.uoeparallax();
 //BA.debugLineNum = 304;BA.debugLine="par.Initialize(App,cID,cURL)";
_par._initialize(ba,_app,_cid,_curl);
 //BA.debugLineNum = 305;BA.debugLine="par.AddClass(cClass)";
_par._addclass(_cclass);
 //BA.debugLineNum = 306;BA.debugLine="AddParallax(row,column,par)";
_addparallax(_row,_column,_par);
 //BA.debugLineNum = 307;BA.debugLine="End Sub";
return "";
}
public String  _addpassword(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _cplaceholder,String _chelpertext,int _clength,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeinput _inp = null;
 //BA.debugLineNum = 277;BA.debugLine="Sub AddPassword(row As Int, column As Int, cID As";
 //BA.debugLineNum = 278;BA.debugLine="Dim inp As UOEInput";
_inp = new b4j.Mashy.UOEBANano.uoeinput();
 //BA.debugLineNum = 279;BA.debugLine="inp.Initialize(App,cID,cTitle,cPlaceHolder,App.En";
_inp._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_app._enuminputtype._password,_ctheme);
 //BA.debugLineNum = 280;BA.debugLine="inp.HelperText = cHelperText";
_inp._helpertext = _chelpertext;
 //BA.debugLineNum = 281;BA.debugLine="inp.IconName = cIconName";
_inp._iconname = _ciconname;
 //BA.debugLineNum = 282;BA.debugLine="inp.MaxLength = cLength";
_inp._maxlength = _clength;
 //BA.debugLineNum = 283;BA.debugLine="inp.AddClass(cClass)";
_inp._addclass(_cclass);
 //BA.debugLineNum = 284;BA.debugLine="AddInput(row,column,inp)";
_addinput(_row,_column,_inp);
 //BA.debugLineNum = 285;BA.debugLine="End Sub";
return "";
}
public String  _addpreloader(int _row,int _col,b4j.Mashy.UOEBANano.uoepreloader _prl) throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Sub AddPreloader(row As Int, col As Int, prl As UO";
 //BA.debugLineNum = 113;BA.debugLine="RemoveComponent(prl.ID)";
_removecomponent(_prl._id);
 //BA.debugLineNum = 114;BA.debugLine="AddComponent(row,col,prl.tostring)";
_addcomponent(_row,_col,_prl._tostring());
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return "";
}
public String  _addprismcode(int _row,int _column,String _codeid,String _codetext,String _codelanguage) throws Exception{
b4j.Mashy.UOEBANano.uoeprism _cl = null;
String _script = "";
 //BA.debugLineNum = 70;BA.debugLine="Sub AddPrismCode(row As Int, column As Int, codeid";
 //BA.debugLineNum = 71;BA.debugLine="Dim cl As UOEPrism";
_cl = new b4j.Mashy.UOEBANano.uoeprism();
 //BA.debugLineNum = 72;BA.debugLine="cl.Initialize(App,codeid,codeText,codeLanguage)";
_cl._initialize(ba,_app,_codeid,_codetext,_codelanguage);
 //BA.debugLineNum = 73;BA.debugLine="AddComponent(row,column,cl.tostring)";
_addcomponent(_row,_column,_cl._tostring());
 //BA.debugLineNum = 74;BA.debugLine="Dim script As String = cl.getJavaScript";
_script = _cl._getjavascript();
 //BA.debugLineNum = 75;BA.debugLine="App.JS.Add(script)";
_app._js.Add((Object)(_script));
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return "";
}
public String  _addprogress(int _row,int _column,b4j.Mashy.UOEBANano.uoeprogress _progress) throws Exception{
 //BA.debugLineNum = 165;BA.debugLine="Sub AddProgress(row As Int, column As Int, progres";
 //BA.debugLineNum = 166;BA.debugLine="RemoveComponent(progress.ID)";
_removecomponent(_progress._id);
 //BA.debugLineNum = 167;BA.debugLine="AddComponent(row,column,progress.tostring)";
_addcomponent(_row,_column,_progress._tostring());
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}
public String  _addprogress1(int _row,int _column,String _cid,boolean _bdeterminate,int _cpercentage,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeprogress _prg = null;
 //BA.debugLineNum = 171;BA.debugLine="Sub AddProgress1(row As Int, column As Int, cID As";
 //BA.debugLineNum = 172;BA.debugLine="Dim prg As UOEProgress";
_prg = new b4j.Mashy.UOEBANano.uoeprogress();
 //BA.debugLineNum = 173;BA.debugLine="prg.Initialize(App,cID,bDeterminate,cTheme)";
_prg._initialize(ba,_app,_cid,_bdeterminate,_ctheme);
 //BA.debugLineNum = 174;BA.debugLine="prg.Percentage = cPercentage";
_prg._percentage = _cpercentage;
 //BA.debugLineNum = 175;BA.debugLine="prg.AddClass(cClass)";
_prg._addclass(_cclass);
 //BA.debugLineNum = 176;BA.debugLine="AddProgress(row,column,prg)";
_addprogress(_row,_column,_prg);
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return "";
}
public String  _addradio(int _row,int _column,b4j.Mashy.UOEBANano.uoeradio _radio) throws Exception{
 //BA.debugLineNum = 331;BA.debugLine="Sub AddRadio(row As Int, column As Int, radio As U";
 //BA.debugLineNum = 332;BA.debugLine="RemoveComponent(radio.ID)";
_removecomponent(_radio._id);
 //BA.debugLineNum = 333;BA.debugLine="AddComponent(row,column,radio.tostring)";
_addcomponent(_row,_column,_radio._tostring());
 //BA.debugLineNum = 334;BA.debugLine="End Sub";
return "";
}
public String  _addradio1(int _row,int _column,String _cid,String _cname,String _cvalue,String _ctitle,boolean _bchecked,boolean _benabled,boolean _bwithgap,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeradio _radio = null;
 //BA.debugLineNum = 320;BA.debugLine="Sub AddRadio1(row As Int, column As Int, cID As St";
 //BA.debugLineNum = 321;BA.debugLine="Dim radio As UOERadio";
_radio = new b4j.Mashy.UOEBANano.uoeradio();
 //BA.debugLineNum = 322;BA.debugLine="radio.Initialize(App,cID,cName,cValue,cTitle,cThe";
_radio._initialize(ba,_app,_cid,_cname,_cvalue,_ctitle,_ctheme);
 //BA.debugLineNum = 323;BA.debugLine="radio.AddClass(cClass)";
_radio._addclass(_cclass);
 //BA.debugLineNum = 324;BA.debugLine="radio.WithGap = bWithGap";
_radio._withgap = _bwithgap;
 //BA.debugLineNum = 325;BA.debugLine="radio.Checked = bChecked";
_radio._checked = _bchecked;
 //BA.debugLineNum = 326;BA.debugLine="radio.Enabled = bEnabled";
_radio._enabled = _benabled;
 //BA.debugLineNum = 327;BA.debugLine="AddRadio(row,column,radio)";
_addradio(_row,_column,_radio);
 //BA.debugLineNum = 328;BA.debugLine="End Sub";
return "";
}
public String  _addradiogroup(int _row,int _col,b4j.Mashy.UOEBANano.uoeradiogroup _rg) throws Exception{
 //BA.debugLineNum = 106;BA.debugLine="Sub AddRadioGroup(row As Int, col As Int, rg As UO";
 //BA.debugLineNum = 107;BA.debugLine="RemoveComponent(rg.ID)";
_removecomponent(_rg._id);
 //BA.debugLineNum = 108;BA.debugLine="AddComponent(row,col, rg.ToString)";
_addcomponent(_row,_col,_rg._tostring());
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public String  _addraisedbutton(int _row,int _column,String _btnid,String _btntext,String _btnvisibility,String _btnnavigateto,String _btntheme,String _cclass,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 600;BA.debugLine="Sub AddRaisedButton(row As Int,column As Int, btnI";
 //BA.debugLineNum = 601;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 602;BA.debugLine="btn.Initialize(App,btnID,btnText,btnTheme)";
_btn._initialize(ba,_app,_btnid,_btntext,_btntheme);
 //BA.debugLineNum = 603;BA.debugLine="btn.Visibility = btnVisibility";
_btn._visibility = _btnvisibility;
 //BA.debugLineNum = 604;BA.debugLine="btn.HREF = btnNavigateTo";
_btn._href = _btnnavigateto;
 //BA.debugLineNum = 605;BA.debugLine="btn.SetButtonType(App.EnumButtonType.raised)";
_btn._setbuttontype(_app._enumbuttontype._raised);
 //BA.debugLineNum = 606;BA.debugLine="btn.Size = App.EnumButtonSize.medium";
_btn._size = _app._enumbuttonsize._medium;
 //BA.debugLineNum = 607;BA.debugLine="btn.AddClass(cClass)";
_btn._addclass(_cclass);
 //BA.debugLineNum = 608;BA.debugLine="btn.FitWidth = False";
_btn._fitwidth = __c.False;
 //BA.debugLineNum = 609;BA.debugLine="AddButton(row,column,btn,hasEvent)";
_addbutton(_row,_column,_btn,_hasevent);
 //BA.debugLineNum = 610;BA.debugLine="End Sub";
return "";
}
public String  _addrange(int _row,int _column,b4j.Mashy.UOEBANano.uoerange _range) throws Exception{
 //BA.debugLineNum = 159;BA.debugLine="Sub AddRange(row As Int, column As Int, range As U";
 //BA.debugLineNum = 160;BA.debugLine="RemoveComponent(range.ID)";
_removecomponent(_range._id);
 //BA.debugLineNum = 161;BA.debugLine="AddComponent(row,column,range.tostring)";
_addcomponent(_row,_column,_range._tostring());
 //BA.debugLineNum = 162;BA.debugLine="End Sub";
return "";
}
public String  _addrange1(int _row,int _column,String _rngid,String _rngcaption,float _lmin,float _lmax,float _lvalue,float _lstep,String _ltheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoerange _range = null;
 //BA.debugLineNum = 1004;BA.debugLine="Sub AddRange1(row As Int, column As Int, rngID As";
 //BA.debugLineNum = 1005;BA.debugLine="Dim range As UOERange";
_range = new b4j.Mashy.UOEBANano.uoerange();
 //BA.debugLineNum = 1006;BA.debugLine="range.Initialize(App,rngID,rngCaption, lMin,lMax,";
_range._initialize(ba,_app,_rngid,_rngcaption,_lmin,_lmax,_lvalue,_lstep,_ltheme);
 //BA.debugLineNum = 1007;BA.debugLine="range.AddClass(cClass)";
_range._addclass(_cclass);
 //BA.debugLineNum = 1008;BA.debugLine="AddRange(row,column,range)";
_addrange(_row,_column,_range);
 //BA.debugLineNum = 1009;BA.debugLine="End Sub";
return "";
}
public String  _addrangeslider(int _row,int _column,b4j.Mashy.UOEBANano.uoerangeslider _rangeslider) throws Exception{
String _rs = "";
 //BA.debugLineNum = 151;BA.debugLine="Sub AddRangeSlider(row As Int, column As Int, rang";
 //BA.debugLineNum = 152;BA.debugLine="RemoveComponent(rangeslider.ID)";
_removecomponent(_rangeslider._id);
 //BA.debugLineNum = 153;BA.debugLine="Dim rs As String = rangeslider.getjavascript";
_rs = _rangeslider._getjavascript();
 //BA.debugLineNum = 154;BA.debugLine="App.JS.Add(rs)";
_app._js.Add((Object)(_rs));
 //BA.debugLineNum = 155;BA.debugLine="AddComponent(row,column,rangeslider.tostring)";
_addcomponent(_row,_column,_rangeslider._tostring());
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public String  _addrangeslider1(int _row,int _column,String _cid,String _ctitle,float _cstart,float _cstop,float _cmin,float _cmax,float _cstep,boolean _cconnect,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoerangeslider _rangeslider = null;
 //BA.debugLineNum = 143;BA.debugLine="Sub AddRangeSlider1(row As Int, column As Int, cID";
 //BA.debugLineNum = 144;BA.debugLine="Dim rangeslider As UOERangeSlider";
_rangeslider = new b4j.Mashy.UOEBANano.uoerangeslider();
 //BA.debugLineNum = 145;BA.debugLine="rangeslider.Initialize(App,cID,cTitle,cStart,cSto";
_rangeslider._initialize(ba,_app,_cid,_ctitle,_cstart,_cstop,_cmin,_cmax,_cstep,__c.False,_ctheme);
 //BA.debugLineNum = 146;BA.debugLine="rangeslider.AddClass(cClass)";
_rangeslider._addclass(_cclass);
 //BA.debugLineNum = 147;BA.debugLine="AddRangeSlider(row,column,rangeslider)";
_addrangeslider(_row,_column,_rangeslider);
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _addrowclass(int _rowpos,String _classname) throws Exception{
 //BA.debugLineNum = 856;BA.debugLine="Sub AddRowClass(rowPos As Int, className As String";
 //BA.debugLineNum = 857;BA.debugLine="Grid.setRowClass(rowPos,className)";
_grid._setrowclass(_rowpos,_classname);
 //BA.debugLineNum = 858;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 859;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrows(int _rows2add,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 834;BA.debugLine="Sub AddRows(Rows2Add As Int, themeName As String,c";
 //BA.debugLineNum = 835;BA.debugLine="Grid.AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeN";
_grid._addrowsmpv(_rows2add,(int) (0),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 836;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 837;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsm(int _rows2add,int _margintoppx,int _marginbottompx,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 822;BA.debugLine="Sub AddRowsM(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 823;BA.debugLine="Grid.AddRowsMPV(Rows2Add, marginTopPx, marginBott";
_grid._addrowsmpv(_rows2add,_margintoppx,_marginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 824;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 825;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsm2(int _rows2add,int _margintoppx,int _marginbottompx,int _marginleftpx,int _marginrightpx,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 816;BA.debugLine="Sub AddRowsM2(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 817;BA.debugLine="Grid.AddRowsMPV(Rows2Add, marginTopPx, marginBott";
_grid._addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 818;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 819;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsmv(int _rows2add,int _margintoppx,int _marginbottompx,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 803;BA.debugLine="Sub AddRowsMV(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 804;BA.debugLine="Grid.AddRowsMPV(Rows2Add, marginTopPx , marginBot";
_grid._addrowsmpv(_rows2add,_margintoppx,_marginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 805;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 806;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsmv2(int _rows2add,int _margintoppx,int _marginbottompx,int _marginleftpx,int _marginrightpx,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 809;BA.debugLine="Sub AddRowsMV2(Rows2Add As Int, marginTopPx As Int";
 //BA.debugLineNum = 810;BA.debugLine="Grid.AddRowsMPV(Rows2Add, marginTopPx , marginBot";
_grid._addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 811;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 812;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsv(int _rows2add,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 828;BA.debugLine="Sub AddRowsV(Rows2Add As Int, rVisibility As Strin";
 //BA.debugLineNum = 829;BA.debugLine="Grid.AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeN";
_grid._addrowsmpv(_rows2add,(int) (0),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 830;BA.debugLine="Return Grid";
if (true) return _grid;
 //BA.debugLineNum = 831;BA.debugLine="End Sub";
return null;
}
public String  _addselect(int _row,int _col,b4j.Mashy.UOEBANano.uoeselect _elselect) throws Exception{
 //BA.debugLineNum = 426;BA.debugLine="Sub AddSelect(row As Int, col As Int, elSelect As";
 //BA.debugLineNum = 427;BA.debugLine="RemoveComponent(elSelect.ID)";
_removecomponent(_elselect._id);
 //BA.debugLineNum = 428;BA.debugLine="AddComponent(row,col,elSelect.ToString)";
_addcomponent(_row,_col,_elselect._tostring());
 //BA.debugLineNum = 429;BA.debugLine="End Sub";
return "";
}
public String  _addslider(int _row,int _column,b4j.Mashy.UOEBANano.uoeslider _slider) throws Exception{
 //BA.debugLineNum = 368;BA.debugLine="Sub AddSlider(row As Int, column As Int, slider As";
 //BA.debugLineNum = 369;BA.debugLine="RemoveComponent(slider.ID)";
_removecomponent(_slider._id);
 //BA.debugLineNum = 370;BA.debugLine="AddComponent(row,column,slider.tostring)";
_addcomponent(_row,_column,_slider._tostring());
 //BA.debugLineNum = 371;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 787;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 788;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 789;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 790;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _addstyleattributeoncondition(boolean _bcondition,String _attr,String _value) throws Exception{
 //BA.debugLineNum = 793;BA.debugLine="Sub AddStyleAttributeOnCondition(bCondition As Boo";
 //BA.debugLineNum = 794;BA.debugLine="Element.removeStyle(attr)";
_element._removestyle(_attr);
 //BA.debugLineNum = 795;BA.debugLine="If bCondition = True Then";
if (_bcondition==__c.True) { 
 //BA.debugLineNum = 796;BA.debugLine="AddStyleAttribute(attr,value)";
_addstyleattribute(_attr,_value);
 };
 //BA.debugLineNum = 798;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 799;BA.debugLine="End Sub";
return null;
}
public String  _addswitch(int _row,int _column,b4j.Mashy.UOEBANano.uoeswitch _switch) throws Exception{
 //BA.debugLineNum = 352;BA.debugLine="Sub AddSwitch(row As Int, column As Int, switch As";
 //BA.debugLineNum = 353;BA.debugLine="RemoveComponent(switch.ID)";
_removecomponent(_switch._id);
 //BA.debugLineNum = 354;BA.debugLine="AddComponent(row,column,switch.tostring)";
_addcomponent(_row,_column,_switch._tostring());
 //BA.debugLineNum = 355;BA.debugLine="End Sub";
return "";
}
public String  _addswitch1(int _row,int _column,String _cid,String _ctitle,String _context,String _cofftext,boolean _bchecked,boolean _benabled,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeswitch _switch = null;
 //BA.debugLineNum = 358;BA.debugLine="Sub AddSwitch1(row As Int, column As Int, cID As S";
 //BA.debugLineNum = 359;BA.debugLine="Dim switch As UOESwitch";
_switch = new b4j.Mashy.UOEBANano.uoeswitch();
 //BA.debugLineNum = 360;BA.debugLine="switch.Initialize(App,cID,cTitle,cOnText,cOffText";
_switch._initialize(ba,_app,_cid,_ctitle,_context,_cofftext,_ctheme);
 //BA.debugLineNum = 361;BA.debugLine="switch.addclass(cClass)";
_switch._addclass(_cclass);
 //BA.debugLineNum = 362;BA.debugLine="switch.Enabled = bEnabled";
_switch._enabled = _benabled;
 //BA.debugLineNum = 363;BA.debugLine="switch.checked = bChecked";
_switch._checked = _bchecked;
 //BA.debugLineNum = 364;BA.debugLine="AddSwitch(row,column,switch)";
_addswitch(_row,_column,_switch);
 //BA.debugLineNum = 365;BA.debugLine="End Sub";
return "";
}
public String  _addtable(int _row,int _column,b4j.Mashy.UOEBANano.uoetable _tbltable) throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Sub AddTable(row As Int, column As Int, tblTable A";
 //BA.debugLineNum = 101;BA.debugLine="RemoveComponent(tblTable.ID)";
_removecomponent(_tbltable._id);
 //BA.debugLineNum = 102;BA.debugLine="AddComponent(row,column,tblTable.tostring)";
_addcomponent(_row,_column,_tbltable._tostring());
 //BA.debugLineNum = 103;BA.debugLine="End Sub";
return "";
}
public String  _addtableexport(b4j.Mashy.UOEBANano.uoetableexport _te) throws Exception{
String _jscode = "";
 //BA.debugLineNum = 118;BA.debugLine="Sub AddTableExport(te As UOETableExport)";
 //BA.debugLineNum = 119;BA.debugLine="Dim jsCode As String = te.getJavaScript";
_jscode = _te._getjavascript();
 //BA.debugLineNum = 120;BA.debugLine="App.JS.Add(jsCode)";
_app._js.Add((Object)(_jscode));
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public String  _addtabs(int _row,int _column,b4j.Mashy.UOEBANano.uoetabs _vtab) throws Exception{
String _dps = "";
 //BA.debugLineNum = 513;BA.debugLine="Sub AddTabs(row As Int,column As Int, vtab As UOET";
 //BA.debugLineNum = 514;BA.debugLine="RemoveComponent(vtab.ID)";
_removecomponent(_vtab._id);
 //BA.debugLineNum = 516;BA.debugLine="Dim dpS As String = vtab.getSettings";
_dps = _vtab._getsettings();
 //BA.debugLineNum = 519;BA.debugLine="App.Components.Add(dpS)";
_app._components.Add((Object)(_dps));
 //BA.debugLineNum = 520;BA.debugLine="AddComponent(row,column,vtab.tostring)";
_addcomponent(_row,_column,_vtab._tostring());
 //BA.debugLineNum = 521;BA.debugLine="End Sub";
return "";
}
public String  _addtelephone(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _cplaceholder,String _chelpertext,int _clength,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeinput _inp = null;
 //BA.debugLineNum = 207;BA.debugLine="Sub AddTelephone(row As Int, column As Int, cID As";
 //BA.debugLineNum = 208;BA.debugLine="Dim inp As UOEInput";
_inp = new b4j.Mashy.UOEBANano.uoeinput();
 //BA.debugLineNum = 209;BA.debugLine="inp.Initialize(App,cID,cTitle,cPlaceHolder,App.En";
_inp._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_app._enuminputtype._tel,_ctheme);
 //BA.debugLineNum = 210;BA.debugLine="inp.HelperText = cHelperText";
_inp._helpertext = _chelpertext;
 //BA.debugLineNum = 211;BA.debugLine="inp.IconName = cIconName";
_inp._iconname = _ciconname;
 //BA.debugLineNum = 212;BA.debugLine="inp.MaxLength = cLength";
_inp._maxlength = _clength;
 //BA.debugLineNum = 213;BA.debugLine="inp.AddClass(cClass)";
_inp._addclass(_cclass);
 //BA.debugLineNum = 214;BA.debugLine="AddInput(row,column,inp)";
_addinput(_row,_column,_inp);
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public String  _addtextarea(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _cplaceholder,String _chelpertext,int _clength,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeinput _inp = null;
 //BA.debugLineNum = 195;BA.debugLine="Sub AddTextArea(row As Int, column As Int, cID As";
 //BA.debugLineNum = 196;BA.debugLine="Dim inp As UOEInput";
_inp = new b4j.Mashy.UOEBANano.uoeinput();
 //BA.debugLineNum = 197;BA.debugLine="inp.Initialize(App,cID,cTitle,cPlaceHolder,App.En";
_inp._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_app._enuminputtype._textarea,_ctheme);
 //BA.debugLineNum = 198;BA.debugLine="inp.HelperText = cHelperText";
_inp._helpertext = _chelpertext;
 //BA.debugLineNum = 199;BA.debugLine="inp.IconName = cIconName";
_inp._iconname = _ciconname;
 //BA.debugLineNum = 200;BA.debugLine="inp.MaxLength = cLength";
_inp._maxlength = _clength;
 //BA.debugLineNum = 201;BA.debugLine="inp.AddClass(cClass)";
_inp._addclass(_cclass);
 //BA.debugLineNum = 202;BA.debugLine="AddInput(row,column,inp)";
_addinput(_row,_column,_inp);
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
return "";
}
public String  _addtextbox(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _cplaceholder,String _chelpertext,int _clength,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoeinput _inp = null;
 //BA.debugLineNum = 231;BA.debugLine="Sub AddTextBox(row As Int, column As Int, cID As S";
 //BA.debugLineNum = 232;BA.debugLine="Dim inp As UOEInput";
_inp = new b4j.Mashy.UOEBANano.uoeinput();
 //BA.debugLineNum = 233;BA.debugLine="inp.Initialize(App,cID,cTitle,cPlaceHolder,App.En";
_inp._initialize(ba,_app,_cid,_ctitle,_cplaceholder,_app._enuminputtype._text,_ctheme);
 //BA.debugLineNum = 234;BA.debugLine="inp.HelperText = cHelperText";
_inp._helpertext = _chelpertext;
 //BA.debugLineNum = 235;BA.debugLine="inp.IconName = cIconName";
_inp._iconname = _ciconname;
 //BA.debugLineNum = 236;BA.debugLine="inp.MaxLength = cLength";
_inp._maxlength = _clength;
 //BA.debugLineNum = 237;BA.debugLine="inp.AddClass(cClass)";
_inp._addclass(_cclass);
 //BA.debugLineNum = 238;BA.debugLine="AddInput(row,column,inp)";
_addinput(_row,_column,_inp);
 //BA.debugLineNum = 239;BA.debugLine="End Sub";
return "";
}
public String  _addtimepicker1(int _row,int _column,String _cid,String _ciconname,String _ctitle,String _ctheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoedatepicker _dp1 = null;
 //BA.debugLineNum = 1025;BA.debugLine="Sub AddTimePicker1(row As Int, column As Int, cID";
 //BA.debugLineNum = 1026;BA.debugLine="Dim dp1 As UOEDatePicker";
_dp1 = new b4j.Mashy.UOEBANano.uoedatepicker();
 //BA.debugLineNum = 1027;BA.debugLine="dp1.Initialize(App,cID,cTitle,App.EnumDateTimeTyp";
_dp1._initialize(ba,_app,_cid,_ctitle,_app._enumdatetimetype._timepicker,_ctheme);
 //BA.debugLineNum = 1028;BA.debugLine="dp1.showClearBtn = True";
_dp1._showclearbtn = __c.True;
 //BA.debugLineNum = 1029;BA.debugLine="dp1.IconName = cIconName";
_dp1._iconname = _ciconname;
 //BA.debugLineNum = 1030;BA.debugLine="dp1.AddClass(cClass)";
_dp1._addclass(_cclass);
 //BA.debugLineNum = 1031;BA.debugLine="AddDatePicker(row,column,dp1)";
_adddatepicker(_row,_column,_dp1);
 //BA.debugLineNum = 1032;BA.debugLine="End Sub";
return "";
}
public String  _addtoc(int _row,int _column,b4j.Mashy.UOEBANano.uoetoc _tbl) throws Exception{
 //BA.debugLineNum = 653;BA.debugLine="Sub AddToC(row As Int, column As Int, tbl As UOETO";
 //BA.debugLineNum = 654;BA.debugLine="RemoveComponent(tbl.ID)";
_removecomponent(_tbl._id);
 //BA.debugLineNum = 655;BA.debugLine="AddComponent(row,column,tbl.ToString)";
_addcomponent(_row,_column,_tbl._tostring());
 //BA.debugLineNum = 656;BA.debugLine="End Sub";
return "";
}
public String  _addvbcodeblock(int _row,int _column,String _code) throws Exception{
String _codeid = "";
 //BA.debugLineNum = 42;BA.debugLine="Sub AddVBCodeBlock(row As Int, column As Int, code";
 //BA.debugLineNum = 43;BA.debugLine="App.codeblock = App.codeblock + 1";
_app._codeblock = (int) (_app._codeblock+1);
 //BA.debugLineNum = 44;BA.debugLine="Dim codeid As String = $\"cd${App.codeblock}\"$";
_codeid = ("cd"+__c.SmartStringFormatter("",(Object)(_app._codeblock))+"");
 //BA.debugLineNum = 45;BA.debugLine="AddPrismCode(row,column,codeid,code,\"vb\")";
_addprismcode(_row,_column,_codeid,_code,"vb");
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _addvideo(int _row,int _col,b4j.Mashy.UOEBANano.uoevideo _video) throws Exception{
 //BA.debugLineNum = 400;BA.debugLine="Sub AddVideo(row As Int, col As Int, video As UOEV";
 //BA.debugLineNum = 401;BA.debugLine="RemoveComponent(video.ID)";
_removecomponent(_video._id);
 //BA.debugLineNum = 402;BA.debugLine="AddComponent(row,col,video.tostring)";
_addcomponent(_row,_col,_video._tostring());
 //BA.debugLineNum = 403;BA.debugLine="End Sub";
return "";
}
public String  _addvideo1(int _row,int _column,String _cid,String _curl,boolean _bautoplay,boolean _ballowfullscreen,int _frameborder,boolean _bloop,boolean _bshowcontrols,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoevideo _vid1 = null;
 //BA.debugLineNum = 339;BA.debugLine="Sub AddVideo1(row As Int, column As Int, cID As St";
 //BA.debugLineNum = 340;BA.debugLine="Dim vid1 As UOEVideo";
_vid1 = new b4j.Mashy.UOEBANano.uoevideo();
 //BA.debugLineNum = 341;BA.debugLine="vid1.Initialize(App,cID, cURL)";
_vid1._initialize(ba,_app,_cid,_curl);
 //BA.debugLineNum = 342;BA.debugLine="vid1.AddClass(cClass)";
_vid1._addclass(_cclass);
 //BA.debugLineNum = 343;BA.debugLine="vid1.AutoPlay = bAutoPlay";
_vid1._autoplay = _bautoplay;
 //BA.debugLineNum = 344;BA.debugLine="vid1.AllowFullScreen = bAllowFullScreen";
_vid1._allowfullscreen = _ballowfullscreen;
 //BA.debugLineNum = 345;BA.debugLine="vid1.FrameBorder = FrameBorder";
_vid1._frameborder = BA.NumberToString(_frameborder);
 //BA.debugLineNum = 346;BA.debugLine="vid1.LoopIt = bLoop";
_vid1._loopit = _bloop;
 //BA.debugLineNum = 347;BA.debugLine="vid1.ShowControls = bShowControls";
_vid1._showcontrols = _bshowcontrols;
 //BA.debugLineNum = 348;BA.debugLine="AddVideo(row,column,vid1)";
_addvideo(_row,_column,_vid1);
 //BA.debugLineNum = 349;BA.debugLine="End Sub";
return "";
}
public String  _addwaterball(int _row,int _col,b4j.Mashy.UOEBANano.uoewaterball _cont) throws Exception{
String _jscode = "";
 //BA.debugLineNum = 24;BA.debugLine="Sub AddWaterBall(row As Int,col As Int,cont As UOE";
 //BA.debugLineNum = 25;BA.debugLine="AddComponent(row,col,cont.tostring)";
_addcomponent(_row,_col,_cont._tostring());
 //BA.debugLineNum = 26;BA.debugLine="Dim jsCode As String = cont.GetJavaScript";
_jscode = _cont._getjavascript();
 //BA.debugLineNum = 27;BA.debugLine="App.JS.Add(jsCode)";
_app._js.Add((Object)(_jscode));
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _addwaterball1(int _row,int _col,String _wid,int _red,int _orange,int _green,int _nowvalue,int _targetvalue,boolean _bisloading,String _height,String _width) throws Exception{
b4j.Mashy.UOEBANano.uoewaterball _wb = null;
 //BA.debugLineNum = 31;BA.debugLine="Sub AddWaterBall1(row As Int,col As Int,wid As Str";
 //BA.debugLineNum = 32;BA.debugLine="Dim wb As UOEWaterBall";
_wb = new b4j.Mashy.UOEBANano.uoewaterball();
 //BA.debugLineNum = 33;BA.debugLine="wb.Initialize(App,wid,width,height)";
_wb._initialize(ba,_app,_wid,(int)(Double.parseDouble(_width)),(int)(Double.parseDouble(_height)));
 //BA.debugLineNum = 34;BA.debugLine="wb.SetRanges(red,orange,green)";
_wb._setranges(BA.NumberToString(_red),BA.NumberToString(_orange),BA.NumberToString(_green));
 //BA.debugLineNum = 35;BA.debugLine="wb.SetValues(nowValue,targetValue)";
_wb._setvalues(BA.NumberToString(_nowvalue),BA.NumberToString(_targetvalue));
 //BA.debugLineNum = 36;BA.debugLine="wb.isLoading = bIsLoading";
_wb._isloading = _bisloading;
 //BA.debugLineNum = 37;BA.debugLine="wb.AddClass(\"center\")";
_wb._addclass("center");
 //BA.debugLineNum = 38;BA.debugLine="AddWaterBall(row,col,wb)";
_addwaterball(_row,_col,_wb);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 12;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Grid As UOEGrid";
_grid = new b4j.Mashy.UOEBANano.uoegrid();
 //BA.debugLineNum = 14;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 15;BA.debugLine="Public CenterInPage As Boolean";
_centerinpage = false;
 //BA.debugLineNum = 16;BA.debugLine="Public ScrollSpy As Boolean";
_scrollspy = false;
 //BA.debugLineNum = 17;BA.debugLine="Public Section As Boolean";
_section = false;
 //BA.debugLineNum = 18;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 19;BA.debugLine="Private divCounter As Int";
_divcounter = 0;
 //BA.debugLineNum = 20;BA.debugLine="Private j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebutton  _getfloatingbutton(String _btnid,String _btnicon,String _btntheme,String _cclass) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 627;BA.debugLine="Sub GetFloatingButton(btnID As String,btnIcon As S";
 //BA.debugLineNum = 628;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 629;BA.debugLine="btn.Initialize(App,btnID,\"\",btnTheme)";
_btn._initialize(ba,_app,_btnid,"",_btntheme);
 //BA.debugLineNum = 630;BA.debugLine="btn.SetButtonType(App.EnumButtonType.floating)";
_btn._setbuttontype(_app._enumbuttontype._floating);
 //BA.debugLineNum = 631;BA.debugLine="btn.Size = App.EnumButtonSize.medium";
_btn._size = _app._enumbuttonsize._medium;
 //BA.debugLineNum = 632;BA.debugLine="btn.AddClass(cClass)";
_btn._addclass(_cclass);
 //BA.debugLineNum = 633;BA.debugLine="btn.AddJustIcon(btnIcon)";
_btn._addjusticon(_btnicon);
 //BA.debugLineNum = 634;BA.debugLine="btn.FitWidth = False";
_btn._fitwidth = __c.False;
 //BA.debugLineNum = 635;BA.debugLine="RemoveComponent(btnID)";
_removecomponent(_btnid);
 //BA.debugLineNum = 636;BA.debugLine="Return btn";
if (true) return _btn;
 //BA.debugLineNum = 637;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _mvarid,boolean _bcenterinpage,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 921;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, mvarID As";
 //BA.debugLineNum = 922;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 923;BA.debugLine="ID = mvarID.tolowercase";
_id = _mvarid.toLowerCase();
 //BA.debugLineNum = 924;BA.debugLine="CenterInPage = bCenterInPage";
_centerinpage = _bcenterinpage;
 //BA.debugLineNum = 925;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 926;BA.debugLine="Element.AddClassOnCondition(bCenterInPage,\"contai";
_element._addclassoncondition(_bcenterinpage,"container");
 //BA.debugLineNum = 927;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 928;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 929;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 930;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 931;BA.debugLine="App.MaterialUseTheme(themeName,Element)";
_app._materialusetheme(_themename,_element);
 //BA.debugLineNum = 932;BA.debugLine="Grid.Initialize(App,mvarID)";
_grid._initialize(ba,_app,_mvarid);
 //BA.debugLineNum = 933;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 934;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 935;BA.debugLine="ScrollSpy = False";
_scrollspy = __c.False;
 //BA.debugLineNum = 936;BA.debugLine="Section = False";
_section = __c.False;
 //BA.debugLineNum = 937;BA.debugLine="divCounter = 0";
_divcounter = (int) (0);
 //BA.debugLineNum = 938;BA.debugLine="j = \"$\"";
_j = "$";
 //BA.debugLineNum = 939;BA.debugLine="End Sub";
return "";
}
public String  _refresh() throws Exception{
String _grd = "";
 //BA.debugLineNum = 850;BA.debugLine="private Sub Refresh";
 //BA.debugLineNum = 851;BA.debugLine="Dim grd As String = Grid.tostring";
_grd = _grid._tostring();
 //BA.debugLineNum = 852;BA.debugLine="Element.AddContent(grd)";
_element._addcontent(_grd);
 //BA.debugLineNum = 853;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 968;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEContaine";
 //BA.debugLineNum = 969;BA.debugLine="Element.RemoveAttr(attr)";
_element._removeattr(_attr);
 //BA.debugLineNum = 970;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 971;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 956;BA.debugLine="Sub RemoveClass(sClass As String) As UOEContainer";
 //BA.debugLineNum = 957;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 958;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 959;BA.debugLine="End Sub";
return null;
}
public String  _removecomponent(String _elid) throws Exception{
String _elkey = "";
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 79;BA.debugLine="Sub RemoveComponent(elID As String)";
 //BA.debugLineNum = 80;BA.debugLine="Try";
try { //BA.debugLineNum = 81;BA.debugLine="elID = elID.trim";
_elid = _elid.trim();
 //BA.debugLineNum = 82;BA.debugLine="If elID = \"\" Then Return";
if ((_elid).equals("")) { 
if (true) return "";};
 //BA.debugLineNum = 83;BA.debugLine="elID = elID.ToLowerCase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 84;BA.debugLine="Dim elKey As String = $\"#${elID}\"$";
_elkey = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 85;BA.debugLine="Dim el As BANanoElement = BANano.GetElement(elKe";
_el = _banano.GetElement(_elkey);
 //BA.debugLineNum = 86;BA.debugLine="If el <> Null Then";
if (_el!= null) { 
 //BA.debugLineNum = 87;BA.debugLine="el.Remove";
_el.Remove();
 };
 } 
       catch (Exception e11) {
			ba.setLastException(e11); //BA.debugLineNum = 90;BA.debugLine="Log(\"\")";
__c.Log("");
 };
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _replacerc(int _row,int _col,String _elhtml) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Sub ReplaceRC(row As Int, col As Int, elHTML As St";
 //BA.debugLineNum = 96;BA.debugLine="Grid.ReplaceRC(row, col, elHTML)";
_grid._replacerc(_row,_col,_elhtml);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecontainer  _setcolumnmargins(int _rowpos,int _colpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
 //BA.debugLineNum = 883;BA.debugLine="Sub setColumnMargins(rowPos As Int, colPos As Int,";
 //BA.debugLineNum = 885;BA.debugLine="Grid.setColumnMargins(rowPos, colPos, marginTop,";
_grid._setcolumnmargins(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright);
 //BA.debugLineNum = 886;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 887;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setcolumnmargins1(int _rowpos,int _colpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
 //BA.debugLineNum = 896;BA.debugLine="Sub setColumnMargins1(rowPos As Int, colPos As Int";
 //BA.debugLineNum = 897;BA.debugLine="Grid.setColumnMargins1(rowPos, colPos, marginTop,";
_grid._setcolumnmargins1(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright);
 //BA.debugLineNum = 898;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 899;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setcolumnpadding(int _rowpos,int _colpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
 //BA.debugLineNum = 876;BA.debugLine="Sub setColumnPadding(rowPos As Int, colPos As Int,";
 //BA.debugLineNum = 878;BA.debugLine="Grid.setColumnPadding(rowPos, colPos, paddingTop,";
_grid._setcolumnpadding(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);
 //BA.debugLineNum = 879;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 880;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setcolumnpadding1(int _rowpos,int _colpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
 //BA.debugLineNum = 914;BA.debugLine="Sub setColumnPadding1(rowPos As Int, colPos As Int";
 //BA.debugLineNum = 916;BA.debugLine="Grid.setColumnPadding1(rowPos, colPos, paddingTop";
_grid._setcolumnpadding1(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);
 //BA.debugLineNum = 917;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 918;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setrowmargins(int _rowpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
 //BA.debugLineNum = 862;BA.debugLine="Sub setRowMargins(rowPos As Int, marginTop As Int,";
 //BA.debugLineNum = 864;BA.debugLine="Grid.setRowMargins(rowPos, marginTop, marginBotto";
_grid._setrowmargins(_rowpos,_margintop,_marginbottom,_marginleft,_marginright);
 //BA.debugLineNum = 865;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 866;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setrowmargins1(int _rowpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
 //BA.debugLineNum = 890;BA.debugLine="Sub setRowMargins1(rowPos As Int, marginTop As Int";
 //BA.debugLineNum = 891;BA.debugLine="Grid.setRowMargins1(rowPos, marginTop, marginBott";
_grid._setrowmargins1(_rowpos,_margintop,_marginbottom,_marginleft,_marginright);
 //BA.debugLineNum = 892;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 893;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setrowpadding(int _rowpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
 //BA.debugLineNum = 869;BA.debugLine="Sub setRowPadding(rowPos As Int, paddingTop As Int";
 //BA.debugLineNum = 871;BA.debugLine="Grid.setRowPadding(rowPos, paddingTop, paddingBot";
_grid._setrowpadding(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);
 //BA.debugLineNum = 872;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 873;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecontainer  _setrowpadding1(int _rowpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
 //BA.debugLineNum = 908;BA.debugLine="Sub setRowPadding1(rowPos As Int, paddingTop As In";
 //BA.debugLineNum = 909;BA.debugLine="Grid.setRowPadding1(rowPos, paddingTop, paddingBo";
_grid._setrowpadding1(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);
 //BA.debugLineNum = 910;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecontainer)(this);
 //BA.debugLineNum = 911;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 974;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 975;BA.debugLine="Refresh";
_refresh();
 //BA.debugLineNum = 976;BA.debugLine="Element.AddClassOnCondition(ScrollSpy,\"scrollspy\"";
_element._addclassoncondition(_scrollspy,"scrollspy");
 //BA.debugLineNum = 977;BA.debugLine="Element.AddClassOnCondition(Section,\"section\")";
_element._addclassoncondition(_section,"section");
 //BA.debugLineNum = 978;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 979;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 980;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 981;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 982;BA.debugLine="Element.RemoveClassOnCondition(Section,\"container";
_element._removeclassoncondition(_section,"container");
 //BA.debugLineNum = 983;BA.debugLine="Return Element.tostring";
if (true) return _element._tostring();
 //BA.debugLineNum = 984;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
