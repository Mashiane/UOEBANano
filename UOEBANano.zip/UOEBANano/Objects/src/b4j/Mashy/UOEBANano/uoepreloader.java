package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoepreloader extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoepreloader", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoepreloader.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _el = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoepreloader  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 89;BA.debugLine="el.AddAttribute(attr,value)";
_el._addattribute(_attr,_value);
 //BA.debugLineNum = 90;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepreloader)(this);
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepreloader  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Sub AddClass(sClass As String) As UOEPreloader";
 //BA.debugLineNum = 77;BA.debugLine="el.AddClass(sClass)";
_el._addclass(_sclass);
 //BA.debugLineNum = 78;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepreloader)(this);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepreloader  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 11;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 12;BA.debugLine="el.AddStyleAttribute(attribute,value)";
_el._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 13;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepreloader)(this);
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Private el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 17;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 18;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 19;BA.debugLine="ID = sID.ToLowerCase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 20;BA.debugLine="el.Initialize(ID,\"div\")";
_el._initialize(ba,_id,"div");
 //BA.debugLineNum = 21;BA.debugLine="el.AddClass(\"preloader-wrapper\")";
_el._addclass("preloader-wrapper");
 //BA.debugLineNum = 22;BA.debugLine="el.AddClass(\"big\").AddClass(\"active\")";
_el._addclass("big")._addclass("active");
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoepreloader  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEPreloade";
 //BA.debugLineNum = 95;BA.debugLine="el.RemoveAttribute(attr)";
_el._removeattribute(_attr);
 //BA.debugLineNum = 96;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepreloader)(this);
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepreloader  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Sub RemoveClass(sClass As String) As UOEPreloader";
 //BA.debugLineNum = 83;BA.debugLine="el.RemoveClass(sClass)";
_el._removeclass(_sclass);
 //BA.debugLineNum = 84;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepreloader)(this);
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
String _script = "";
 //BA.debugLineNum = 26;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 27;BA.debugLine="el.ID = ID";
_el._id = _id;
 //BA.debugLineNum = 28;BA.debugLine="Dim script As String = $\"<div class=\"spinner-laye";
_script = ("<div class=\"spinner-layer spinner-blue\">\n"+"        <div class=\"circle-clipper left\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"gap-patch\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"circle-clipper right\">\n"+"          <div class=\"circle\"></div>\n"+"        </div>\n"+"      </div>\n"+"\n"+"      <div class=\"spinner-layer spinner-red\">\n"+"        <div class=\"circle-clipper left\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"gap-patch\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"circle-clipper right\">\n"+"          <div class=\"circle\"></div>\n"+"        </div>\n"+"      </div>\n"+"\n"+"      <div class=\"spinner-layer spinner-yellow\">\n"+"        <div class=\"circle-clipper left\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"gap-patch\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"circle-clipper right\">\n"+"          <div class=\"circle\"></div>\n"+"        </div>\n"+"      </div>\n"+"\n"+"      <div class=\"spinner-layer spinner-green\">\n"+"        <div class=\"circle-clipper left\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"gap-patch\">\n"+"          <div class=\"circle\"></div>\n"+"        </div><div class=\"circle-clipper right\">\n"+"          <div class=\"circle\"></div>\n"+"        </div>\n"+"      </div>");
 //BA.debugLineNum = 67;BA.debugLine="el.AddContent(script)";
_el._addcontent(_script);
 //BA.debugLineNum = 72;BA.debugLine="Return el.html";
if (true) return _el._html();
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
