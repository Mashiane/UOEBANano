package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoebadge extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoebadge", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoebadge.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _theme = "";
public String _text = "";
public boolean _isnew = false;
public String _visibility = "";
public String _zdepth = "";
public boolean _circle = false;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public boolean _waveseffect = false;
public String _wavestype = "";
public boolean _wavescircle = false;
public boolean _enabled = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoebadge  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 60;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 61;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebadge)(this);
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebadge  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Sub AddClass(sClass As String) As UOEBadge";
 //BA.debugLineNum = 48;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 49;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebadge)(this);
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebadge  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 23;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 24;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebadge)(this);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 8;BA.debugLine="Public IsNew As Boolean";
_isnew = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Circle As Boolean";
_circle = false;
 //BA.debugLineNum = 12;BA.debugLine="Public Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 14;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 15;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 16;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 17;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _btext,boolean _bisnew,String _btheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 28;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 30;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 31;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 32;BA.debugLine="Text = bText";
_text = _btext;
 //BA.debugLineNum = 33;BA.debugLine="IsNew = bIsNew";
_isnew = _bisnew;
 //BA.debugLineNum = 34;BA.debugLine="Circle = False";
_circle = __c.False;
 //BA.debugLineNum = 35;BA.debugLine="Element.Initialize(ID,\"span\")";
_element._initialize(ba,_id,"span");
 //BA.debugLineNum = 36;BA.debugLine="Element.addClass(\"badge\")";
_element._addclass("badge");
 //BA.debugLineNum = 37;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 38;BA.debugLine="Theme = bTheme";
_theme = _btheme;
 //BA.debugLineNum = 39;BA.debugLine="Visibility= App.EnumVisibility.hide";
_visibility = _app._enumvisibility._hide;
 //BA.debugLineNum = 40;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 41;BA.debugLine="WavesType= \"\"";
_wavestype = "";
 //BA.debugLineNum = 42;BA.debugLine="WavesEffect = False";
_waveseffect = __c.False;
 //BA.debugLineNum = 43;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebadge  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEBadge";
 //BA.debugLineNum = 66;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 67;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebadge)(this);
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebadge  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub RemoveClass(sClass As String) As UOEBadge";
 //BA.debugLineNum = 54;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebadge)(this);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
String _strt = "";
 //BA.debugLineNum = 71;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 72;BA.debugLine="If Text.Length > 0 Then";
if (_text.length()>0) { 
 //BA.debugLineNum = 73;BA.debugLine="Visibility = App.EnumVisibility.visible";
_visibility = _app._enumvisibility._visible;
 };
 //BA.debugLineNum = 75;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 76;BA.debugLine="App.MaterialUseThemeOnCondition(Not(IsNew),Theme,";
_app._materialusethemeoncondition(__c.Not(_isnew),_theme,_element);
 //BA.debugLineNum = 77;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 78;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 79;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 80;BA.debugLine="Element.MaterialWaveseffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 81;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 82;BA.debugLine="If Text.Length > 0 Then";
if (_text.length()>0) { 
 //BA.debugLineNum = 83;BA.debugLine="Dim strT As String = $\"{NBSP}${Text}{NBSP}\"$";
_strt = ("{NBSP}"+__c.SmartStringFormatter("",(Object)(_text))+"{NBSP}");
 //BA.debugLineNum = 84;BA.debugLine="Element.AddContent(strT)";
_element._addcontent(_strt);
 };
 //BA.debugLineNum = 86;BA.debugLine="Element.AddClassOnCondition(Circle,\"circle\")";
_element._addclassoncondition(_circle,"circle");
 //BA.debugLineNum = 87;BA.debugLine="Element.AddClassOnCondition(IsNew,\"new\")";
_element._addclassoncondition(_isnew,"new");
 //BA.debugLineNum = 88;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 89;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 90;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
