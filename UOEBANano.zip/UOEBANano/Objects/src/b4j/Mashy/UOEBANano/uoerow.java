package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoerow extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoerow", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoerow.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _rows = 0;
public int _margintop = 0;
public int _marginbottom = 0;
public int _marginleft = 0;
public int _marginright = 0;
public int _paddingtop = 0;
public int _paddingbottom = 0;
public int _paddingleft = 0;
public int _paddingright = 0;
public anywheresoftware.b4a.objects.collections.List _columns = null;
public String _visibility = "";
public String _themename = "";
public String _classname = "";
public int _row = 0;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Rows As Int";
_rows = 0;
 //BA.debugLineNum = 5;BA.debugLine="Public MarginTop As Int";
_margintop = 0;
 //BA.debugLineNum = 6;BA.debugLine="Public MarginBottom As Int";
_marginbottom = 0;
 //BA.debugLineNum = 7;BA.debugLine="Public MarginLeft As Int";
_marginleft = 0;
 //BA.debugLineNum = 8;BA.debugLine="Public MarginRight As Int";
_marginright = 0;
 //BA.debugLineNum = 9;BA.debugLine="Public PaddingTop As Int";
_paddingtop = 0;
 //BA.debugLineNum = 10;BA.debugLine="Public PaddingBottom As Int";
_paddingbottom = 0;
 //BA.debugLineNum = 11;BA.debugLine="Public PaddingLeft As Int";
_paddingleft = 0;
 //BA.debugLineNum = 12;BA.debugLine="Public PaddingRight As Int";
_paddingright = 0;
 //BA.debugLineNum = 13;BA.debugLine="Public Columns As List";
_columns = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 14;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Public ThemeName As String";
_themename = "";
 //BA.debugLineNum = 16;BA.debugLine="Public ClassName As String";
_classname = "";
 //BA.debugLineNum = 17;BA.debugLine="Public Row As Int";
_row = 0;
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 21;BA.debugLine="Columns.Initialize";
_columns.Initialize();
 //BA.debugLineNum = 22;BA.debugLine="Columns.clear";
_columns.Clear();
 //BA.debugLineNum = 23;BA.debugLine="Rows = 1";
_rows = (int) (1);
 //BA.debugLineNum = 24;BA.debugLine="MarginTop = 0";
_margintop = (int) (0);
 //BA.debugLineNum = 25;BA.debugLine="MarginBottom = 20";
_marginbottom = (int) (20);
 //BA.debugLineNum = 26;BA.debugLine="MarginLeft = 0";
_marginleft = (int) (0);
 //BA.debugLineNum = 27;BA.debugLine="MarginRight = 0";
_marginright = (int) (0);
 //BA.debugLineNum = 28;BA.debugLine="PaddingTop = 0";
_paddingtop = (int) (0);
 //BA.debugLineNum = 29;BA.debugLine="PaddingBottom = 0";
_paddingbottom = (int) (0);
 //BA.debugLineNum = 30;BA.debugLine="PaddingLeft = 0";
_paddingleft = (int) (0);
 //BA.debugLineNum = 31;BA.debugLine="PaddingRight = 0";
_paddingright = (int) (0);
 //BA.debugLineNum = 32;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 33;BA.debugLine="ThemeName = \"\"";
_themename = "";
 //BA.debugLineNum = 34;BA.debugLine="ClassName = \"\"";
_classname = "";
 //BA.debugLineNum = 35;BA.debugLine="Row = 0";
_row = (int) (0);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
