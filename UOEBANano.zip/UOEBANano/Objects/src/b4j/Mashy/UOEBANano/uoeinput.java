package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeinput extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeinput", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeinput.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _title = "";
public boolean _validate = false;
public String _theme = "";
public String _placeholder = "";
public b4j.Mashy.UOEBANano.uoehtml _div = null;
public b4j.Mashy.UOEBANano.uoehtml _inp = null;
public b4j.Mashy.UOEBANano.uoehtml _lbl = null;
public b4j.Mashy.UOEBANano.uoehtml _help = null;
public String _inptype = "";
public boolean _enabled = false;
public String _errormsg = "";
public String _successmsg = "";
public String _iconname = "";
public int _maxlength = 0;
public boolean _required = false;
public boolean _hoverable = false;
public String _zdepth = "";
public String _visibility = "";
public String _helpertext = "";
public boolean _inline = false;
public String _text = "";
public boolean _autofocus = false;
public boolean _hasautocomplete = false;
public anywheresoftware.b4a.objects.collections.List _items = null;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeinput  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 128;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 129;BA.debugLine="div.AddAttribute(attr,value)";
_div._addattribute(_attr,_value);
 //BA.debugLineNum = 130;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeinput  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 116;BA.debugLine="Sub AddClass(sClass As String) As UOEInput";
 //BA.debugLineNum = 117;BA.debugLine="div.AddClass(sClass)";
_div._addclass(_sclass);
 //BA.debugLineNum = 118;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeinput  _additem(String _itemtext,String _itemurl) throws Exception{
anywheresoftware.b4a.objects.collections.Map _im = null;
 //BA.debugLineNum = 108;BA.debugLine="Sub AddItem(itemText As String,itemURL As String)";
 //BA.debugLineNum = 109;BA.debugLine="hasAutoComplete = True";
_hasautocomplete = __c.True;
 //BA.debugLineNum = 110;BA.debugLine="Dim im As Map = CreateMap(\"id\":itemURL,\"text\": it";
_im = new anywheresoftware.b4a.objects.collections.Map();
_im = __c.createMap(new Object[] {(Object)("id"),(Object)(_itemurl),(Object)("text"),(Object)(_itemtext)});
 //BA.debugLineNum = 111;BA.debugLine="Items.Add(im)";
_items.Add((Object)(_im.getObject()));
 //BA.debugLineNum = 112;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoehtml  _addredstar(boolean _brequired,b4j.Mashy.UOEBANano.uoehtml _element) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _span = null;
 //BA.debugLineNum = 187;BA.debugLine="private Sub AddRedStar(bRequired As Boolean, Eleme";
 //BA.debugLineNum = 188;BA.debugLine="If bRequired = True Then";
if (_brequired==__c.True) { 
 //BA.debugLineNum = 189;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 190;BA.debugLine="span.Initialize(\"\",\"span\")";
_span._initialize(ba,"","span");
 //BA.debugLineNum = 191;BA.debugLine="span.AddContent(\"{NBSP}\").AddContent(\"*\")";
_span._addcontent("{NBSP}")._addcontent("*");
 //BA.debugLineNum = 192;BA.debugLine="App.MaterialUseTheme(\"redtransparent\",span)";
_app._materialusetheme("redtransparent",_span);
 //BA.debugLineNum = 193;BA.debugLine="Element.AddContent(span.HTML)";
_element._addcontent(_span._html());
 };
 //BA.debugLineNum = 195;BA.debugLine="Return Element";
if (true) return _element;
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeinput  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 63;BA.debugLine="inp.AddStyleAttribute(attribute,value)";
_inp._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 64;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return null;
}
public String  _buildautocomplete() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _kcnt = 0;
int _ktot = 0;
anywheresoftware.b4a.objects.collections.Map _ac = null;
String _mk = "";
String _mv = "";
String _script = "";
 //BA.debugLineNum = 230;BA.debugLine="private Sub BuildAutoComplete() As String";
 //BA.debugLineNum = 231;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 232;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 233;BA.debugLine="sb.Append(\"data: {\")";
_sb.Append("data: {");
 //BA.debugLineNum = 234;BA.debugLine="sb.Append(CRLF)";
_sb.Append(__c.CRLF);
 //BA.debugLineNum = 235;BA.debugLine="Dim kcnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 236;BA.debugLine="Dim ktot As Int = Items.Size - 1";
_ktot = (int) (_items.getSize()-1);
 //BA.debugLineNum = 238;BA.debugLine="Dim ac As Map  = Items.Get(0)";
_ac = new anywheresoftware.b4a.objects.collections.Map();
_ac.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_items.Get((int) (0))));
 //BA.debugLineNum = 239;BA.debugLine="Dim mk As String = ac.Get(\"id\")";
_mk = BA.ObjectToString(_ac.Get((Object)("id")));
 //BA.debugLineNum = 240;BA.debugLine="Dim mv As String = ac.Get(\"text\")";
_mv = BA.ObjectToString(_ac.Get((Object)("text")));
 //BA.debugLineNum = 241;BA.debugLine="Dim script As String = $\"\"${mv}\":${mk}\"$";
_script = ("\""+__c.SmartStringFormatter("",(Object)(_mv))+"\":"+__c.SmartStringFormatter("",(Object)(_mk))+"");
 //BA.debugLineNum = 242;BA.debugLine="sb.Append(script)";
_sb.Append(_script);
 //BA.debugLineNum = 243;BA.debugLine="For kcnt = 1 To ktot";
{
final int step12 = 1;
final int limit12 = _ktot;
_kcnt = (int) (1) ;
for (;_kcnt <= limit12 ;_kcnt = _kcnt + step12 ) {
 //BA.debugLineNum = 244;BA.debugLine="Dim ac As Map  = Items.Get(kcnt)";
_ac = new anywheresoftware.b4a.objects.collections.Map();
_ac.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_items.Get(_kcnt)));
 //BA.debugLineNum = 245;BA.debugLine="Dim mk As String = ac.Get(\"id\")";
_mk = BA.ObjectToString(_ac.Get((Object)("id")));
 //BA.debugLineNum = 246;BA.debugLine="Dim mv As String = ac.Get(\"text\")";
_mv = BA.ObjectToString(_ac.Get((Object)("text")));
 //BA.debugLineNum = 247;BA.debugLine="Dim script As String = $\"\"${mv}\":${mk}\"$";
_script = ("\""+__c.SmartStringFormatter("",(Object)(_mv))+"\":"+__c.SmartStringFormatter("",(Object)(_mk))+"");
 //BA.debugLineNum = 248;BA.debugLine="sb.Append(\",\")";
_sb.Append(",");
 //BA.debugLineNum = 249;BA.debugLine="sb.Append(script)";
_sb.Append(_script);
 }
};
 //BA.debugLineNum = 251;BA.debugLine="sb.Append(\"}\")";
_sb.Append("}");
 //BA.debugLineNum = 252;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 253;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Validate As Boolean";
_validate = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Placeholder As String";
_placeholder = "";
 //BA.debugLineNum = 11;BA.debugLine="Private div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Private inp As UOEHTML";
_inp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Private lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 14;BA.debugLine="Private help As UOEHTML";
_help = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 15;BA.debugLine="Public inpType As String";
_inptype = "";
 //BA.debugLineNum = 16;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 17;BA.debugLine="Public ErrorMsg As String";
_errormsg = "";
 //BA.debugLineNum = 18;BA.debugLine="Public SuccessMsg As String";
_successmsg = "";
 //BA.debugLineNum = 19;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 20;BA.debugLine="Public MaxLength As Int";
_maxlength = 0;
 //BA.debugLineNum = 21;BA.debugLine="Public Required As Boolean";
_required = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 23;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 24;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 25;BA.debugLine="Public HelperText As String";
_helpertext = "";
 //BA.debugLineNum = 26;BA.debugLine="Public Inline As Boolean";
_inline = false;
 //BA.debugLineNum = 27;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 28;BA.debugLine="Public AutoFocus As Boolean";
_autofocus = false;
 //BA.debugLineNum = 29;BA.debugLine="Private hasAutoComplete As Boolean";
_hasautocomplete = false;
 //BA.debugLineNum = 30;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 31;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _sj = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sbx = null;
String _script = "";
 //BA.debugLineNum = 199;BA.debugLine="Sub GetJavaScript As String";
 //BA.debugLineNum = 200;BA.debugLine="Dim sj As String = \"$\"";
_sj = "$";
 //BA.debugLineNum = 201;BA.debugLine="Dim sbx As StringBuilder";
_sbx = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 202;BA.debugLine="sbx.Initialize";
_sbx.Initialize();
 //BA.debugLineNum = 203;BA.debugLine="Dim script As String = \"\"";
_script = "";
 //BA.debugLineNum = 204;BA.debugLine="If inpType = App.EnumInputType.TextArea Then";
if ((_inptype).equals(_app._enuminputtype._textarea)) { 
 //BA.debugLineNum = 205;BA.debugLine="script = $\"M.textareaAutoResize($('#${ID}'));\"$";
_script = ("M.textareaAutoResize($('#"+__c.SmartStringFormatter("",(Object)(_id))+"'));");
 //BA.debugLineNum = 206;BA.debugLine="sbx.Append(script)";
_sbx.Append(_script);
 //BA.debugLineNum = 207;BA.debugLine="If MaxLength > 0 Then";
if (_maxlength>0) { 
 //BA.debugLineNum = 208;BA.debugLine="script = $\"${sj}('textarea#${ID}').characterCou";
_script = (""+__c.SmartStringFormatter("",(Object)(_sj))+"('textarea#"+__c.SmartStringFormatter("",(Object)(_id))+"').characterCounter();");
 //BA.debugLineNum = 209;BA.debugLine="sbx.Append(script)";
_sbx.Append(_script);
 };
 }else {
 //BA.debugLineNum = 212;BA.debugLine="If MaxLength > 0 Then";
if (_maxlength>0) { 
 //BA.debugLineNum = 213;BA.debugLine="script = $\"${sj}('input#${ID}').characterCounte";
_script = (""+__c.SmartStringFormatter("",(Object)(_sj))+"('input#"+__c.SmartStringFormatter("",(Object)(_id))+"').characterCounter();");
 //BA.debugLineNum = 214;BA.debugLine="sbx.Append(script)";
_sbx.Append(_script);
 };
 };
 //BA.debugLineNum = 218;BA.debugLine="If hasAutoComplete Then";
if (_hasautocomplete) { 
 //BA.debugLineNum = 219;BA.debugLine="script = $\"${sj}('#${ID}').autocomplete({ 		${Bu";
_script = (""+__c.SmartStringFormatter("",(Object)(_sj))+"('#"+__c.SmartStringFormatter("",(Object)(_id))+"').autocomplete({\n"+"		"+__c.SmartStringFormatter("",(Object)(_buildautocomplete()))+"\n"+"		});");
 //BA.debugLineNum = 222;BA.debugLine="sbx.Append(script)";
_sbx.Append(_script);
 };
 //BA.debugLineNum = 224;BA.debugLine="Return sbx.tostring";
if (true) return _sbx.ToString();
 //BA.debugLineNum = 228;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,String _splaceholder,String _sinputtype,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 69;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 70;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 71;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 72;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 73;BA.debugLine="Validate = False";
_validate = __c.False;
 //BA.debugLineNum = 74;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 75;BA.debugLine="Placeholder = sPlaceholder";
_placeholder = _splaceholder;
 //BA.debugLineNum = 76;BA.debugLine="inpType = sInputType";
_inptype = _sinputtype;
 //BA.debugLineNum = 77;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 78;BA.debugLine="Required = False";
_required = __c.False;
 //BA.debugLineNum = 79;BA.debugLine="ErrorMsg = \"Error\"";
_errormsg = "Error";
 //BA.debugLineNum = 80;BA.debugLine="SuccessMsg = \"Success\"";
_successmsg = "Success";
 //BA.debugLineNum = 81;BA.debugLine="Text = \"\"";
_text = "";
 //BA.debugLineNum = 82;BA.debugLine="div.Initialize(ID & \"p\",\"div\")";
_div._initialize(ba,_id+"p","div");
 //BA.debugLineNum = 83;BA.debugLine="div.AddClass(\"input-field\")";
_div._addclass("input-field");
 //BA.debugLineNum = 84;BA.debugLine="div.AddClass(\"col\")";
_div._addclass("col");
 //BA.debugLineNum = 85;BA.debugLine="div.AddClass(\"s12\")";
_div._addclass("s12");
 //BA.debugLineNum = 86;BA.debugLine="div.AddClass(\"m12\")";
_div._addclass("m12");
 //BA.debugLineNum = 87;BA.debugLine="div.AddClass(\"l12\")";
_div._addclass("l12");
 //BA.debugLineNum = 88;BA.debugLine="inp.Initialize(ID,\"input\")";
_inp._initialize(ba,_id,"input");
 //BA.debugLineNum = 89;BA.debugLine="inp.AddAttribute(\"placeholder\",Placeholder)";
_inp._addattribute("placeholder",_placeholder);
 //BA.debugLineNum = 90;BA.debugLine="inp.AddAttribute(\"type\",inpType)";
_inp._addattribute("type",_inptype);
 //BA.debugLineNum = 91;BA.debugLine="lbl.Initialize(ID & \"-label\",\"label\")";
_lbl._initialize(ba,_id+"-label","label");
 //BA.debugLineNum = 92;BA.debugLine="lbl.AddAttribute(\"for\",ID)";
_lbl._addattribute("for",_id);
 //BA.debugLineNum = 93;BA.debugLine="lbl.AddContent(Title)";
_lbl._addcontent(_title);
 //BA.debugLineNum = 94;BA.debugLine="lbl.AddClass(\"active\")";
_lbl._addclass("active");
 //BA.debugLineNum = 95;BA.debugLine="help.Initialize(ID & \"-help\",\"span\")";
_help._initialize(ba,_id+"-help","span");
 //BA.debugLineNum = 96;BA.debugLine="help.AddClass(\"helper-text\")";
_help._addclass("helper-text");
 //BA.debugLineNum = 97;BA.debugLine="HelperText = \"\"";
_helpertext = "";
 //BA.debugLineNum = 98;BA.debugLine="Inline = False";
_inline = __c.False;
 //BA.debugLineNum = 99;BA.debugLine="hasAutoComplete = False";
_hasautocomplete = __c.False;
 //BA.debugLineNum = 100;BA.debugLine="MaxLength = 0";
_maxlength = (int) (0);
 //BA.debugLineNum = 101;BA.debugLine="AutoFocus = False";
_autofocus = __c.False;
 //BA.debugLineNum = 102;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 103;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 104;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeinput  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 134;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEInput";
 //BA.debugLineNum = 135;BA.debugLine="div.RemoveAttribute(attr)";
_div._removeattribute(_attr);
 //BA.debugLineNum = 136;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeinput  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 122;BA.debugLine="Sub RemoveClass(sClass As String) As UOEInput";
 //BA.debugLineNum = 123;BA.debugLine="div.RemoveClass(sClass)";
_div._removeclass(_sclass);
 //BA.debugLineNum = 124;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeinput  _setmessages(String _onerror,String _onsuccess) throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Sub SetMessages(onError As String, onSuccess As St";
 //BA.debugLineNum = 141;BA.debugLine="ErrorMsg = onError";
_errormsg = _onerror;
 //BA.debugLineNum = 142;BA.debugLine="SuccessMsg = onSuccess";
_successmsg = _onsuccess;
 //BA.debugLineNum = 143;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeinput)(this);
 //BA.debugLineNum = 144;BA.debugLine="End Sub";
return null;
}
public String  _setval(String _svalue) throws Exception{
String _j = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sbx = null;
String _script = "";
 //BA.debugLineNum = 35;BA.debugLine="Public Sub setVal(sValue As String)";
 //BA.debugLineNum = 36;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 37;BA.debugLine="Dim sbx As StringBuilder";
_sbx = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 38;BA.debugLine="sbx.Initialize";
_sbx.Initialize();
 //BA.debugLineNum = 39;BA.debugLine="sbx.Append(\"$('#\").Append(ID).Append(\"').val(\").A";
_sbx.Append("$('#").Append(_id).Append("').val(").Append(_svalue).Append(");");
 //BA.debugLineNum = 40;BA.debugLine="If MaxLength > 0 Then";
if (_maxlength>0) { 
 //BA.debugLineNum = 41;BA.debugLine="sbx.Append($\"${j}('input#${ID}').characterCounte";
_sbx.Append((""+__c.SmartStringFormatter("",(Object)(_j))+"('input#"+__c.SmartStringFormatter("",(Object)(_id))+"').characterCounter();"));
 };
 //BA.debugLineNum = 43;BA.debugLine="Dim script As String = sbx.tostring";
_script = _sbx.ToString();
 //BA.debugLineNum = 44;BA.debugLine="BANano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public String  _setvaltextarea(String _svalue) throws Exception{
String _j = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sbx = null;
String _script = "";
 //BA.debugLineNum = 48;BA.debugLine="Public Sub setValTextArea(sValue As String)";
 //BA.debugLineNum = 49;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 50;BA.debugLine="Dim sbx As StringBuilder";
_sbx = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 51;BA.debugLine="sbx.Initialize";
_sbx.Initialize();
 //BA.debugLineNum = 52;BA.debugLine="sbx.Append(\"$('#\").Append(ID).Append(\"').val(\").A";
_sbx.Append("$('#").Append(_id).Append("').val(").Append(_svalue).Append(");");
 //BA.debugLineNum = 53;BA.debugLine="sbx.Append($\"M.textareaAutoResize($('#${ID}'));\"$";
_sbx.Append(("M.textareaAutoResize($('#"+__c.SmartStringFormatter("",(Object)(_id))+"'));"));
 //BA.debugLineNum = 54;BA.debugLine="If MaxLength > 0 Then";
if (_maxlength>0) { 
 //BA.debugLineNum = 55;BA.debugLine="sbx.Append($\"${j}('textarea#${ID}').characterCou";
_sbx.Append((""+__c.SmartStringFormatter("",(Object)(_j))+"('textarea#"+__c.SmartStringFormatter("",(Object)(_id))+"').characterCounter();"));
 };
 //BA.debugLineNum = 57;BA.debugLine="Dim script As String = sbx.tostring";
_script = _sbx.ToString();
 //BA.debugLineNum = 58;BA.debugLine="BANano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 147;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 148;BA.debugLine="div.MaterialVisibility(Visibility)";
_div._materialvisibility(_visibility);
 //BA.debugLineNum = 149;BA.debugLine="div.MaterialHoverable(Hoverable)";
_div._materialhoverable(_hoverable);
 //BA.debugLineNum = 150;BA.debugLine="div.MaterialZdepth(ZDepth)";
_div._materialzdepth(_zdepth);
 //BA.debugLineNum = 151;BA.debugLine="App.ApplyToolTip(ID,div)";
_app._applytooltip(_id,_div);
 //BA.debugLineNum = 152;BA.debugLine="div.AddClassOnCondition(Inline,\"inline\")";
_div._addclassoncondition(_inline,"inline");
 //BA.debugLineNum = 153;BA.debugLine="div.AddStyleAttributeOnCondition(Inline,\"display\"";
_div._addstyleattributeoncondition(_inline,"display","inline-block");
 //BA.debugLineNum = 154;BA.debugLine="div.AddAttributeOnCondition(AutoFocus,\"autofocus\"";
_div._addattributeoncondition(_autofocus,"autofocus","true");
 //BA.debugLineNum = 155;BA.debugLine="inp.AddClassOnCondition(Validate,\"validate\")";
_inp._addclassoncondition(_validate,"validate");
 //BA.debugLineNum = 156;BA.debugLine="inp.MaterialRequired(Required)";
_inp._materialrequired(_required);
 //BA.debugLineNum = 157;BA.debugLine="inp.AddClassOnCondition(hasAutoComplete,\"autocomp";
_inp._addclassoncondition(_hasautocomplete,"autocomplete");
 //BA.debugLineNum = 158;BA.debugLine="inp.AddLooseAttributeOnFalseCondition(Enabled,\"di";
_inp._addlooseattributeonfalsecondition(_enabled,"disabled");
 //BA.debugLineNum = 159;BA.debugLine="inp.AddAttribute(\"name\",ID)";
_inp._addattribute("name",_id);
 //BA.debugLineNum = 160;BA.debugLine="AddRedStar(Required,lbl)";
_addredstar(_required,_lbl);
 //BA.debugLineNum = 161;BA.debugLine="help.AddAttribute(\"data-error\",ErrorMsg)";
_help._addattribute("data-error",_errormsg);
 //BA.debugLineNum = 162;BA.debugLine="help.AddAttribute(\"data-success\",SuccessMsg)";
_help._addattribute("data-success",_successmsg);
 //BA.debugLineNum = 163;BA.debugLine="help.AddContent(HelperText)";
_help._addcontent(_helpertext);
 //BA.debugLineNum = 164;BA.debugLine="modUOE.MaterialAddIcon(App,div,IconName,\"\",Theme,";
_moduoe._materialaddicon(_app,_div,_iconname,"",_theme,__c.False,__c.False,__c.False,__c.True,__c.False);
 //BA.debugLineNum = 165;BA.debugLine="Select Case inpType";
switch (BA.switchObjectToInt(_inptype,_app._enuminputtype._textarea)) {
case 0: {
 //BA.debugLineNum = 167;BA.debugLine="inp.RemoveAttribute(\"type\")";
_inp._removeattribute("type");
 //BA.debugLineNum = 168;BA.debugLine="inp.settag(\"textarea\")";
_inp._settag("textarea");
 //BA.debugLineNum = 169;BA.debugLine="inp.AddClass(\"materialize-textarea\")";
_inp._addclass("materialize-textarea");
 //BA.debugLineNum = 170;BA.debugLine="inp.RemoveClass(\"validate\")";
_inp._removeclass("validate");
 break; }
}
;
 //BA.debugLineNum = 172;BA.debugLine="inp.AddAttribute(\"data-length\", MaxLength)";
_inp._addattribute("data-length",BA.NumberToString(_maxlength));
 //BA.debugLineNum = 173;BA.debugLine="inp.AddAttribute(\"data-instance\", inp.tag)";
_inp._addattribute("data-instance",_inp._tag);
 //BA.debugLineNum = 174;BA.debugLine="inp.AddAttribute(\"value\",Text)";
_inp._addattribute("value",_text);
 //BA.debugLineNum = 175;BA.debugLine="div.AddContent(inp.HTML)";
_div._addcontent(_inp._html());
 //BA.debugLineNum = 176;BA.debugLine="div.AddContent(lbl.HTML)";
_div._addcontent(_lbl._html());
 //BA.debugLineNum = 177;BA.debugLine="div.AddElement(help)";
_div._addelement(_help);
 //BA.debugLineNum = 182;BA.debugLine="Return div.html";
if (true) return _div._html();
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
