package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetableexport extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetableexport", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetableexport.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoepage _page = null;
public boolean _headers = false;
public boolean _footers = false;
public String _id = "";
public boolean _bootstrap = false;
public boolean _exportbuttons = false;
public String _position = "";
public String _ignorerows = "";
public String _ignorecols = "";
public boolean _trimwhitespace = false;
public boolean _rtl = false;
public String _vsheetname = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public Page As UOEPage";
_page = new b4j.Mashy.UOEBANano.uoepage();
 //BA.debugLineNum = 6;BA.debugLine="Public headers As Boolean";
_headers = false;
 //BA.debugLineNum = 7;BA.debugLine="Public footers As Boolean";
_footers = false;
 //BA.debugLineNum = 8;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 9;BA.debugLine="Public bootstrap As Boolean";
_bootstrap = false;
 //BA.debugLineNum = 10;BA.debugLine="Public exportButtons As Boolean";
_exportbuttons = false;
 //BA.debugLineNum = 11;BA.debugLine="Public position As String";
_position = "";
 //BA.debugLineNum = 12;BA.debugLine="Public ignoreRows As String";
_ignorerows = "";
 //BA.debugLineNum = 13;BA.debugLine="Public ignoreCols As String";
_ignorecols = "";
 //BA.debugLineNum = 14;BA.debugLine="Public trimWhitespace As Boolean";
_trimwhitespace = false;
 //BA.debugLineNum = 15;BA.debugLine="Public RTL As Boolean";
_rtl = false;
 //BA.debugLineNum = 16;BA.debugLine="Private vsheetname As String";
_vsheetname = "";
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _ws = "";
String _srtl = "";
String _shead = "";
String _sfoot = "";
String _script = "";
 //BA.debugLineNum = 40;BA.debugLine="Sub GetJavaScript As String";
 //BA.debugLineNum = 42;BA.debugLine="Dim ws As String = App.iif(trimWhitespace,\"true\",";
_ws = BA.ObjectToString(_app._iif(BA.ObjectToString(_trimwhitespace),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 43;BA.debugLine="Dim srtl As String = App.iif(RTL,\"true\",\"false\")";
_srtl = BA.ObjectToString(_app._iif(BA.ObjectToString(_rtl),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 44;BA.debugLine="Dim shead As String = App.iif(headers,\"true\",\"fal";
_shead = BA.ObjectToString(_app._iif(BA.ObjectToString(_headers),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 45;BA.debugLine="Dim sfoot As String = App.iif(footers,\"true\",\"fal";
_sfoot = BA.ObjectToString(_app._iif(BA.ObjectToString(_footers),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 47;BA.debugLine="Dim script As String = $\"var tbl${ID} = document.";
_script = ("var tbl"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	// Class applied to each export button element.\n"+"	new TableExport(tbl"+__c.SmartStringFormatter("",(Object)(_id))+", {\n"+"        headers: "+__c.SmartStringFormatter("",(Object)(_shead))+",                              \n"+"        footers: "+__c.SmartStringFormatter("",(Object)(_sfoot))+",                             \n"+"        formats: ['xlsx', 'xls', 'csv', 'txt'],            \n"+"		filename: '"+__c.SmartStringFormatter("",(Object)(_id))+"',                            \n"+"        bootstrap: "+__c.SmartStringFormatter("",(Object)(_bootstrap))+",                           \n"+"        position: '"+__c.SmartStringFormatter("",(Object)(_position))+"',                        \n"+"        ignoreRows: "+__c.SmartStringFormatter("",(Object)(_ignorerows))+",                          \n"+"        ignoreCols: "+__c.SmartStringFormatter("",(Object)(_ignorecols))+",                           \n"+"        ignoreCSS: '.tableexport-ignore',          \n"+"        emptyCSS: '.tableexport-empty',           \n"+"        trimWhitespace: "+__c.SmartStringFormatter("",(Object)(_ws))+",                     \n"+"        RTL: "+__c.SmartStringFormatter("",(Object)(_srtl))+",                        \n"+"        sheetname: '"+__c.SmartStringFormatter("",(Object)(_vsheetname))+"'                           \n"+"    });");
 //BA.debugLineNum = 64;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _tblname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, tblName A";
 //BA.debugLineNum = 21;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 22;BA.debugLine="headers = True";
_headers = __c.True;
 //BA.debugLineNum = 23;BA.debugLine="footers = True";
_footers = __c.True;
 //BA.debugLineNum = 24;BA.debugLine="ID =  tblName.tolowercase";
_id = _tblname.toLowerCase();
 //BA.debugLineNum = 25;BA.debugLine="bootstrap = True";
_bootstrap = __c.True;
 //BA.debugLineNum = 26;BA.debugLine="exportButtons = True";
_exportbuttons = __c.True;
 //BA.debugLineNum = 27;BA.debugLine="position = \"bottom\"";
_position = "bottom";
 //BA.debugLineNum = 28;BA.debugLine="ignoreRows = \"null\"";
_ignorerows = "null";
 //BA.debugLineNum = 29;BA.debugLine="ignoreCols =  \"null\"";
_ignorecols = "null";
 //BA.debugLineNum = 30;BA.debugLine="trimWhitespace = True";
_trimwhitespace = __c.True;
 //BA.debugLineNum = 31;BA.debugLine="RTL = False";
_rtl = __c.False;
 //BA.debugLineNum = 32;BA.debugLine="vsheetname = tblName";
_vsheetname = _tblname;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public String  _inquote(String _val) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="private Sub InQuote(val As String) As String";
 //BA.debugLineNum = 36;BA.debugLine="Return $\"\"${val}\"\"$";
if (true) return ("\""+__c.SmartStringFormatter("",(Object)(_val))+"\"");
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
