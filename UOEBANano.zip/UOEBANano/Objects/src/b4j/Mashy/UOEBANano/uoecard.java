package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecard extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecard", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecard.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoehtml _card = null;
public b4j.Mashy.UOEBANano.uoehtml _actions = null;
public b4j.Mashy.UOEBANano.uoehtml _content = null;
public String _imageurl = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _cardtype = "";
public String _cardsize = "";
public String _visibility = "";
public String _zdepth = "";
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.uoehtml _image = null;
public boolean _horizontal = false;
public b4j.Mashy.UOEBANano.uoehtml _stacked = null;
public b4j.Mashy.UOEBANano.uoehtml _reveal = null;
public boolean _breveal = false;
public boolean _hasactions = false;
public boolean _stickyaction = false;
public boolean _hastabs = false;
public b4j.Mashy.UOEBANano.uoehtml _tabs = null;
public b4j.Mashy.UOEBANano.uoehtml _ul = null;
public b4j.Mashy.UOEBANano.uoehtml _uldata = null;
public boolean _panel = false;
public int _small = 0;
public int _medium = 0;
public int _large = 0;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecard  _addaction(String _aid,String _atitle,String _ahref,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 207;BA.debugLine="Sub AddAction(aid As String, atitle As String, ahr";
 //BA.debugLineNum = 208;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 209;BA.debugLine="a.Initialize(aid,\"a\")";
_a._initialize(ba,_aid,"a");
 //BA.debugLineNum = 210;BA.debugLine="a.SetHREF(ahref).AddContent(atitle)";
_a._sethref(_ahref)._addcontent(_atitle);
 //BA.debugLineNum = 211;BA.debugLine="actions.AddContent(a.HTML)";
_actions._addcontent(_a._html());
 //BA.debugLineNum = 212;BA.debugLine="hasActions = True";
_hasactions = __c.True;
 //BA.debugLineNum = 213;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 214;BA.debugLine="App.AddEvent(aid, \"click\")";
_app._addevent(_aid,"click");
 };
 //BA.debugLineNum = 216;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 217;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 305;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 306;BA.debugLine="card.AddAttribute(attr,value)";
_card._addattribute(_attr,_value);
 //BA.debugLineNum = 307;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 308;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 293;BA.debugLine="Sub AddClass(sClass As String) As UOECard";
 //BA.debugLineNum = 294;BA.debugLine="card.AddClass(sClass)";
_card._addclass(_sclass);
 //BA.debugLineNum = 295;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 296;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addfab(String _btnid,String _btnicon,String _btnurl,String _btnsize,String _btntheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 118;BA.debugLine="Sub AddFAB(btnID As String, btnIcon As String, btn";
 //BA.debugLineNum = 119;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 120;BA.debugLine="a.Initialize(btnID,\"a\")";
_a._initialize(ba,_btnid,"a");
 //BA.debugLineNum = 121;BA.debugLine="a.AddClass(\"btn-floating\")";
_a._addclass("btn-floating");
 //BA.debugLineNum = 122;BA.debugLine="a.AddClass(\"halfway-fab\")";
_a._addclass("halfway-fab");
 //BA.debugLineNum = 123;BA.debugLine="a.MaterialWavesEffect(True)";
_a._materialwaveseffect(__c.True);
 //BA.debugLineNum = 124;BA.debugLine="a.MaterialWavesLight(True)";
_a._materialwaveslight(__c.True);
 //BA.debugLineNum = 125;BA.debugLine="a.SetZIndex(\"999\")";
_a._setzindex("999");
 //BA.debugLineNum = 126;BA.debugLine="App.MaterialUseTheme(btnTheme,a)";
_app._materialusetheme(_btntheme,_a);
 //BA.debugLineNum = 127;BA.debugLine="modUOE.MaterialAddIcon(App,a,btnIcon,\"\",btnTheme,";
_moduoe._materialaddicon(_app,_a,_btnicon,"",_btntheme,__c.False,__c.True,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 128;BA.debugLine="a.MaterialButtonSize(btnSize)";
_a._materialbuttonsize(_btnsize);
 //BA.debugLineNum = 129;BA.debugLine="Select Case CardType";
switch (BA.switchObjectToInt(_cardtype,_app._enumcardtype._basic)) {
case 0: {
 break; }
default: {
 //BA.debugLineNum = 132;BA.debugLine="image.AddElement(a)";
_image._addelement(_a);
 break; }
}
;
 //BA.debugLineNum = 134;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 135;BA.debugLine="App.AddEvent(btnID, \"click\")";
_app._addevent(_btnid,"click");
 };
 //BA.debugLineNum = 137;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addlink(String _aid,String _atitle,String _ahref,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _a = null;
b4j.Mashy.UOEBANano.uoehtml _p = null;
 //BA.debugLineNum = 192;BA.debugLine="Sub AddLink(aid As String, atitle As String, ahref";
 //BA.debugLineNum = 193;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 194;BA.debugLine="a.Initialize(aid,\"a\")";
_a._initialize(ba,_aid,"a");
 //BA.debugLineNum = 195;BA.debugLine="a.SetHREF(ahref).AddContent(atitle)";
_a._sethref(_ahref)._addcontent(_atitle);
 //BA.debugLineNum = 196;BA.debugLine="Dim p As UOEHTML";
_p = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 197;BA.debugLine="p.Initialize(\"\",\"p\")";
_p._initialize(ba,"","p");
 //BA.debugLineNum = 198;BA.debugLine="p.AddElement(a)";
_p._addelement(_a);
 //BA.debugLineNum = 199;BA.debugLine="content.AddElement(p)";
_content._addelement(_p);
 //BA.debugLineNum = 200;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 201;BA.debugLine="App.AddEvent(aid, \"click\")";
_app._addevent(_aid,"click");
 };
 //BA.debugLineNum = 203;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 204;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addparagraph(String _ptext,String _ptheme,String _pclass) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _span = null;
 //BA.debugLineNum = 177;BA.debugLine="Sub AddParagraph(pText As String, pTheme As String";
 //BA.debugLineNum = 178;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 179;BA.debugLine="span.Initialize(\"\",\"p\")";
_span._initialize(ba,"","p");
 //BA.debugLineNum = 180;BA.debugLine="span.AddClass(pClass).AddContent(pText)";
_span._addclass(_pclass)._addcontent(_ptext);
 //BA.debugLineNum = 181;BA.debugLine="App.MaterialUseTheme(pTheme,span)";
_app._materialusetheme(_ptheme,_span);
 //BA.debugLineNum = 182;BA.debugLine="Select Case CardType";
switch (BA.switchObjectToInt(_cardtype,_app._enumcardtype._reveal)) {
case 0: {
 //BA.debugLineNum = 184;BA.debugLine="reveal.AddContent(span.HTML)";
_reveal._addcontent(_span._html());
 break; }
default: {
 //BA.debugLineNum = 186;BA.debugLine="content.AddContent(span.HTML)";
_content._addcontent(_span._html());
 break; }
}
;
 //BA.debugLineNum = 188;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 189;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 287;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 288;BA.debugLine="card.AddStyleAttribute(attribute,value)";
_card._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 289;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 290;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addtab(String _tabid,String _tabtext,boolean _tabdisabled,b4j.Mashy.UOEBANano.uoecontainer _tabcont,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
b4j.Mashy.UOEBANano.uoehtml _dv = null;
 //BA.debugLineNum = 90;BA.debugLine="Sub AddTab(tabID As String, tabText As String, tab";
 //BA.debugLineNum = 91;BA.debugLine="hasTabs = True";
_hastabs = __c.True;
 //BA.debugLineNum = 92;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 93;BA.debugLine="li.Initialize(tabID & \"-tab\",\"li\")";
_li._initialize(ba,_tabid+"-tab","li");
 //BA.debugLineNum = 94;BA.debugLine="li.AddClass(\"tab\")";
_li._addclass("tab");
 //BA.debugLineNum = 95;BA.debugLine="li.AddClassOnCondition(tabDisabled,\"disabled\")";
_li._addclassoncondition(_tabdisabled,"disabled");
 //BA.debugLineNum = 96;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 97;BA.debugLine="a.Initialize(tabID,\"a\")";
_a._initialize(ba,_tabid,"a");
 //BA.debugLineNum = 98;BA.debugLine="a.sethref(\"#\" & tabID & \"dv\").AddContent(tabText)";
_a._sethref("#"+_tabid+"dv")._addcontent(_tabtext);
 //BA.debugLineNum = 99;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 101;BA.debugLine="ul.AddElement(li)";
_ul._addelement(_li);
 //BA.debugLineNum = 104;BA.debugLine="Dim dv As UOEHTML";
_dv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 105;BA.debugLine="dv.Initialize(tabID & \"-content\",\"div\")";
_dv._initialize(ba,_tabid+"-content","div");
 //BA.debugLineNum = 106;BA.debugLine="If tabCont <> Null Then";
if (_tabcont!= null) { 
 //BA.debugLineNum = 107;BA.debugLine="dv.AddContent(tabCont.tostring)";
_dv._addcontent(_tabcont._tostring());
 };
 //BA.debugLineNum = 110;BA.debugLine="uldata.AddContent(dv.HTML)";
_uldata._addcontent(_dv._html());
 //BA.debugLineNum = 111;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 112;BA.debugLine="App.AddEvent(tabID,\"click\")";
_app._addevent(_tabid,"click");
 };
 //BA.debugLineNum = 114;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _addtitle(String _stitle,String _themename,String _classname) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _span = null;
b4j.Mashy.UOEBANano.uoehtml _img = null;
b4j.Mashy.UOEBANano.uoehtml _spanc = null;
 //BA.debugLineNum = 141;BA.debugLine="Sub AddTitle(sTitle As String, themeName As String";
 //BA.debugLineNum = 142;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 143;BA.debugLine="span.Initialize(ID & \"-title\",\"span\")";
_span._initialize(ba,_id+"-title","span");
 //BA.debugLineNum = 144;BA.debugLine="span.AddClass(\"card-title\").AddContent(sTitle).Ad";
_span._addclass("card-title")._addcontent(_stitle)._addclass(_classname);
 //BA.debugLineNum = 145;BA.debugLine="App.MaterialUseTheme(themeName,span)";
_app._materialusetheme(_themename,_span);
 //BA.debugLineNum = 146;BA.debugLine="Select Case CardType";
switch (BA.switchObjectToInt(_cardtype,_app._enumcardtype._basic,_app._enumcardtype._image,_app._enumcardtype._reveal)) {
case 0: {
 //BA.debugLineNum = 148;BA.debugLine="content.AddContent(span.HTML)";
_content._addcontent(_span._html());
 break; }
case 1: {
 //BA.debugLineNum = 150;BA.debugLine="Dim img As UOEHTML";
_img = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 151;BA.debugLine="img.Initialize(ID & \"-img\",\"img\")";
_img._initialize(ba,_id+"-img","img");
 //BA.debugLineNum = 152;BA.debugLine="img.SetSRC(ImageURL,True)";
_img._setsrc(_imageurl,__c.True);
 //BA.debugLineNum = 153;BA.debugLine="image.AddElement(img)";
_image._addelement(_img);
 //BA.debugLineNum = 154;BA.debugLine="image.AddElement(span)";
_image._addelement(_span);
 break; }
case 2: {
 //BA.debugLineNum = 156;BA.debugLine="Dim img As UOEHTML";
_img = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 157;BA.debugLine="img.Initialize(ID & \"-img\",\"img\")";
_img._initialize(ba,_id+"-img","img");
 //BA.debugLineNum = 158;BA.debugLine="img.SetSRC(ImageURL,True)";
_img._setsrc(_imageurl,__c.True);
 //BA.debugLineNum = 159;BA.debugLine="img.AddClassOnCondition(bReveal,\"activator\")";
_img._addclassoncondition(_breveal,"activator");
 //BA.debugLineNum = 160;BA.debugLine="image.AddElement(img)";
_image._addelement(_img);
 //BA.debugLineNum = 162;BA.debugLine="span.AddClass(\"activator\")";
_span._addclass("activator");
 //BA.debugLineNum = 163;BA.debugLine="modUOE.MaterialAddIcon(App,span,\"mdi-more_vert\"";
_moduoe._materialaddicon(_app,_span,"mdi-more_vert","right","",__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 164;BA.debugLine="content.AddElement(span)";
_content._addelement(_span);
 //BA.debugLineNum = 166;BA.debugLine="Dim spanc As UOEHTML";
_spanc = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 167;BA.debugLine="spanc.Initialize(ID & \"-title\",\"span\")";
_spanc._initialize(ba,_id+"-title","span");
 //BA.debugLineNum = 168;BA.debugLine="spanc.AddClass(\"card-title\").AddContent(sTitle)";
_spanc._addclass("card-title")._addcontent(_stitle)._addclass(_classname);
 //BA.debugLineNum = 169;BA.debugLine="modUOE.MaterialAddIcon(App,spanc,\"mdi-close\",\"r";
_moduoe._materialaddicon(_app,_spanc,"mdi-close","right","",__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 170;BA.debugLine="App.MaterialUseTheme(themeName,spanc)";
_app._materialusetheme(_themename,_spanc);
 //BA.debugLineNum = 171;BA.debugLine="reveal.AddElement(spanc)";
_reveal._addelement(_spanc);
 break; }
}
;
 //BA.debugLineNum = 173;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 174;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Private card As UOEHTML";
_card = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 6;BA.debugLine="Private actions As UOEHTML";
_actions = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Private content As UOEHTML";
_content = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Public ImageURL As String";
_imageurl = "";
 //BA.debugLineNum = 9;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 10;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 11;BA.debugLine="Public CardType As String";
_cardtype = "";
 //BA.debugLineNum = 12;BA.debugLine="Public CardSize As String";
_cardsize = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 14;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 16;BA.debugLine="Private image As UOEHTML";
_image = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 17;BA.debugLine="Public Horizontal As Boolean";
_horizontal = false;
 //BA.debugLineNum = 18;BA.debugLine="Private stacked As UOEHTML";
_stacked = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 19;BA.debugLine="Private reveal As UOEHTML";
_reveal = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 20;BA.debugLine="Private bReveal As Boolean";
_breveal = false;
 //BA.debugLineNum = 21;BA.debugLine="Private hasActions As Boolean";
_hasactions = false;
 //BA.debugLineNum = 22;BA.debugLine="Public StickyAction As Boolean";
_stickyaction = false;
 //BA.debugLineNum = 23;BA.debugLine="Private hasTabs As Boolean";
_hastabs = false;
 //BA.debugLineNum = 24;BA.debugLine="Private tabs As UOEHTML";
_tabs = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 25;BA.debugLine="Private ul As UOEHTML";
_ul = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 26;BA.debugLine="Private uldata As UOEHTML";
_uldata = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 27;BA.debugLine="Public Panel As Boolean";
_panel = false;
 //BA.debugLineNum = 28;BA.debugLine="Private Small As Int";
_small = 0;
 //BA.debugLineNum = 29;BA.debugLine="Private Medium As Int";
_medium = 0;
 //BA.debugLineNum = 30;BA.debugLine="Private Large As Int";
_large = 0;
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _simageurl,String _scardtype,String _scardtheme,String _scontenttheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 35;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 37;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 38;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 39;BA.debugLine="ImageURL = sImageURL";
_imageurl = _simageurl;
 //BA.debugLineNum = 40;BA.debugLine="CardType = sCardType";
_cardtype = _scardtype;
 //BA.debugLineNum = 41;BA.debugLine="CardSize = App.EnumCardSize.normal";
_cardsize = _app._enumcardsize._normal;
 //BA.debugLineNum = 42;BA.debugLine="card.Initialize(ID,\"div\")";
_card._initialize(ba,_id,"div");
 //BA.debugLineNum = 43;BA.debugLine="card.AddClass(\"card\")";
_card._addclass("card");
 //BA.debugLineNum = 44;BA.debugLine="App.MaterialUseTheme(sCardTheme,card)";
_app._materialusetheme(_scardtheme,_card);
 //BA.debugLineNum = 45;BA.debugLine="content.Initialize(ID & \"-content\",\"div\")";
_content._initialize(ba,_id+"-content","div");
 //BA.debugLineNum = 46;BA.debugLine="content.AddClass(\"card-content\")";
_content._addclass("card-content");
 //BA.debugLineNum = 47;BA.debugLine="App.MaterialUseTheme(sContentTheme,content)";
_app._materialusetheme(_scontenttheme,_content);
 //BA.debugLineNum = 48;BA.debugLine="actions.Initialize(ID & \"-actions\",\"div\")";
_actions._initialize(ba,_id+"-actions","div");
 //BA.debugLineNum = 49;BA.debugLine="actions.AddClass(\"card-action\")";
_actions._addclass("card-action");
 //BA.debugLineNum = 50;BA.debugLine="image.Initialize(ID & \"-img\",\"div\")";
_image._initialize(ba,_id+"-img","div");
 //BA.debugLineNum = 51;BA.debugLine="image.addclass(\"card-image\")";
_image._addclass("card-image");
 //BA.debugLineNum = 52;BA.debugLine="stacked.Initialize(ID & \"-stacked\",\"div\")";
_stacked._initialize(ba,_id+"-stacked","div");
 //BA.debugLineNum = 53;BA.debugLine="stacked.AddClass(\"card-stacked\")";
_stacked._addclass("card-stacked");
 //BA.debugLineNum = 54;BA.debugLine="reveal.Initialize(ID & \"-reveal\",\"div\")";
_reveal._initialize(ba,_id+"-reveal","div");
 //BA.debugLineNum = 55;BA.debugLine="reveal.AddClass(\"card-reveal\")";
_reveal._addclass("card-reveal");
 //BA.debugLineNum = 56;BA.debugLine="tabs.Initialize(ID & \"-tabsdiv\",\"div\")";
_tabs._initialize(ba,_id+"-tabsdiv","div");
 //BA.debugLineNum = 57;BA.debugLine="tabs.addclass(\"card-tabs\")";
_tabs._addclass("card-tabs");
 //BA.debugLineNum = 58;BA.debugLine="ul.Initialize(ID & \"-tabs\",\"ul\")";
_ul._initialize(ba,_id+"-tabs","ul");
 //BA.debugLineNum = 59;BA.debugLine="ul.AddClass(\"tabs tabs-fixed-width\")";
_ul._addclass("tabs tabs-fixed-width");
 //BA.debugLineNum = 60;BA.debugLine="uldata.Initialize(ID & \"-data\",\"div\")";
_uldata._initialize(ba,_id+"-data","div");
 //BA.debugLineNum = 61;BA.debugLine="uldata.AddClass(\"card-content\")";
_uldata._addclass("card-content");
 //BA.debugLineNum = 62;BA.debugLine="Horizontal = False";
_horizontal = __c.False;
 //BA.debugLineNum = 63;BA.debugLine="bReveal = False";
_breveal = __c.False;
 //BA.debugLineNum = 64;BA.debugLine="If CardType = App.EnumCardType.Reveal Then";
if ((_cardtype).equals(_app._enumcardtype._reveal)) { 
 //BA.debugLineNum = 65;BA.debugLine="Horizontal = False";
_horizontal = __c.False;
 //BA.debugLineNum = 66;BA.debugLine="bReveal = True";
_breveal = __c.True;
 };
 //BA.debugLineNum = 68;BA.debugLine="hasActions = False";
_hasactions = __c.False;
 //BA.debugLineNum = 69;BA.debugLine="StickyAction = False";
_stickyaction = __c.False;
 //BA.debugLineNum = 70;BA.debugLine="hasTabs = False";
_hastabs = __c.False;
 //BA.debugLineNum = 71;BA.debugLine="Panel = False";
_panel = __c.False;
 //BA.debugLineNum = 72;BA.debugLine="Small = 12";
_small = (int) (12);
 //BA.debugLineNum = 73;BA.debugLine="Medium = 12";
_medium = (int) (12);
 //BA.debugLineNum = 74;BA.debugLine="Large = 12";
_large = (int) (12);
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecard  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 311;BA.debugLine="Sub RemoveAttribute(attr As String) As UOECard";
 //BA.debugLineNum = 312;BA.debugLine="card.RemoveAttribute(attr)";
_card._removeattribute(_attr);
 //BA.debugLineNum = 313;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 314;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 299;BA.debugLine="Sub RemoveClass(sClass As String) As UOECard";
 //BA.debugLineNum = 300;BA.debugLine="card.RemoveClass(sClass)";
_card._removeclass(_sclass);
 //BA.debugLineNum = 301;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 302;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecard  _setsizes(int _ismall,int _imedium,int _ilarge) throws Exception{
 //BA.debugLineNum = 78;BA.debugLine="Sub SetSizes(iSmall As Int, iMedium As Int, iLarge";
 //BA.debugLineNum = 79;BA.debugLine="Small = iSmall";
_small = _ismall;
 //BA.debugLineNum = 80;BA.debugLine="Medium = iMedium";
_medium = _imedium;
 //BA.debugLineNum = 81;BA.debugLine="Large = iLarge";
_large = _ilarge;
 //BA.debugLineNum = 82;BA.debugLine="card.AddClass(\"col\")";
_card._addclass("col");
 //BA.debugLineNum = 83;BA.debugLine="card.AddClass($\"s${Small}\"$)";
_card._addclass(("s"+__c.SmartStringFormatter("",(Object)(_small))+""));
 //BA.debugLineNum = 84;BA.debugLine="card.AddClass($\"m${Medium}\"$)";
_card._addclass(("m"+__c.SmartStringFormatter("",(Object)(_medium))+""));
 //BA.debugLineNum = 85;BA.debugLine="card.AddClass($\"l${Large}\"$)";
_card._addclass(("l"+__c.SmartStringFormatter("",(Object)(_large))+""));
 //BA.debugLineNum = 86;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecard)(this);
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 220;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 221;BA.debugLine="If Panel Then";
if (_panel) { 
 //BA.debugLineNum = 222;BA.debugLine="card.RemoveClass(\"card\").AddClass(\"card-panel\")";
_card._removeclass("card")._addclass("card-panel");
 };
 //BA.debugLineNum = 224;BA.debugLine="card.MaterialZDepth(ZDepth)";
_card._materialzdepth(_zdepth);
 //BA.debugLineNum = 225;BA.debugLine="card.MaterialVisibility(Visibility)";
_card._materialvisibility(_visibility);
 //BA.debugLineNum = 226;BA.debugLine="card.MaterialHoverable(Hoverable)";
_card._materialhoverable(_hoverable);
 //BA.debugLineNum = 227;BA.debugLine="card.AddClassOnCondition(Horizontal,\"horizontal\")";
_card._addclassoncondition(_horizontal,"horizontal");
 //BA.debugLineNum = 228;BA.debugLine="card.AddClassOnCondition(StickyAction,\"sticky-act";
_card._addclassoncondition(_stickyaction,"sticky-action");
 //BA.debugLineNum = 229;BA.debugLine="image.AddClassOnCondition(bReveal,\"waves-effect w";
_image._addclassoncondition(_breveal,"waves-effect waves-block waves-light");
 //BA.debugLineNum = 235;BA.debugLine="tabs.AddElement(ul)";
_tabs._addelement(_ul);
 //BA.debugLineNum = 236;BA.debugLine="Select Case CardType";
switch (BA.switchObjectToInt(_cardtype,_app._enumcardtype._basic,_app._enumcardtype._image,_app._enumcardtype._reveal)) {
case 0: {
 //BA.debugLineNum = 238;BA.debugLine="If Horizontal Then";
if (_horizontal) { 
 //BA.debugLineNum = 239;BA.debugLine="stacked.AddElement(content)";
_stacked._addelement(_content);
 //BA.debugLineNum = 240;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 241;BA.debugLine="card.AddElement(tabs)";
_card._addelement(_tabs);
 //BA.debugLineNum = 242;BA.debugLine="card.AddElement(uldata)";
_card._addelement(_uldata);
 };
 //BA.debugLineNum = 244;BA.debugLine="stacked.AddElement(actions)";
_stacked._addelement(_actions);
 //BA.debugLineNum = 245;BA.debugLine="card.AddElement(stacked)";
_card._addelement(_stacked);
 }else {
 //BA.debugLineNum = 247;BA.debugLine="card.AddElement(content)";
_card._addelement(_content);
 //BA.debugLineNum = 248;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 249;BA.debugLine="card.AddElement(tabs)";
_card._addelement(_tabs);
 //BA.debugLineNum = 250;BA.debugLine="card.AddElement(uldata)";
_card._addelement(_uldata);
 };
 //BA.debugLineNum = 252;BA.debugLine="If hasActions Then card.AddElement(actions)";
if (_hasactions) { 
_card._addelement(_actions);};
 };
 break; }
case 1: {
 //BA.debugLineNum = 255;BA.debugLine="card.AddElement(image)";
_card._addelement(_image);
 //BA.debugLineNum = 256;BA.debugLine="If Horizontal Then";
if (_horizontal) { 
 //BA.debugLineNum = 257;BA.debugLine="stacked.AddElement(content)";
_stacked._addelement(_content);
 //BA.debugLineNum = 258;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 259;BA.debugLine="card.AddElement(tabs)";
_card._addelement(_tabs);
 //BA.debugLineNum = 260;BA.debugLine="card.AddElement(uldata)";
_card._addelement(_uldata);
 };
 //BA.debugLineNum = 262;BA.debugLine="If hasActions Then stacked.AddElement(actions)";
if (_hasactions) { 
_stacked._addelement(_actions);};
 //BA.debugLineNum = 263;BA.debugLine="card.AddElement(stacked)";
_card._addelement(_stacked);
 }else {
 //BA.debugLineNum = 265;BA.debugLine="card.AddElement(content)";
_card._addelement(_content);
 //BA.debugLineNum = 266;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 267;BA.debugLine="card.AddElement(tabs)";
_card._addelement(_tabs);
 //BA.debugLineNum = 268;BA.debugLine="card.AddElement(uldata)";
_card._addelement(_uldata);
 };
 //BA.debugLineNum = 270;BA.debugLine="If hasActions Then card.AddElement(actions)";
if (_hasactions) { 
_card._addelement(_actions);};
 };
 break; }
case 2: {
 //BA.debugLineNum = 273;BA.debugLine="card.AddElement(image)";
_card._addelement(_image);
 //BA.debugLineNum = 274;BA.debugLine="card.AddElement(content)";
_card._addelement(_content);
 //BA.debugLineNum = 275;BA.debugLine="If hasTabs Then";
if (_hastabs) { 
 //BA.debugLineNum = 276;BA.debugLine="card.AddElement(tabs)";
_card._addelement(_tabs);
 //BA.debugLineNum = 277;BA.debugLine="card.AddElement(uldata)";
_card._addelement(_uldata);
 };
 //BA.debugLineNum = 279;BA.debugLine="If hasActions Then card.AddElement(actions)";
if (_hasactions) { 
_card._addelement(_actions);};
 //BA.debugLineNum = 280;BA.debugLine="card.AddElement(reveal)";
_card._addelement(_reveal);
 break; }
}
;
 //BA.debugLineNum = 282;BA.debugLine="App.ApplyToolTip(ID,card)";
_app._applytooltip(_id,_card);
 //BA.debugLineNum = 283;BA.debugLine="Return card.HTML";
if (true) return _card._html();
 //BA.debugLineNum = 284;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
