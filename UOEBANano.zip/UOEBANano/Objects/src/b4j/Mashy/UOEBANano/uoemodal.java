package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoemodal extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoemodal", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoemodal.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _id = "";
public boolean _enabled = false;
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoecontainer _content = null;
public boolean _dismissible = false;
public boolean _preventscrolling = false;
public boolean _fixedfooter = false;
public b4j.Mashy.UOEBANano.uoecontainer _footer = null;
public b4j.Mashy.UOEBANano.uoecontainer _header = null;
public boolean _isbottomsheet = false;
public String _startingtop = "";
public String _endingtop = "";
public String _theme = "";
public String _instance = "";
public anywheresoftware.b4a.objects.collections.List _fields = null;
public boolean _hidescrollbar = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoemodal  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 74;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 75;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 76;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoemodal)(this);
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoemodal  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Sub AddClass(sClass As String) As UOEModal";
 //BA.debugLineNum = 63;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 64;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoemodal)(this);
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Content As UOEContainer";
_content = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 11;BA.debugLine="Public dismissible As Boolean";
_dismissible = false;
 //BA.debugLineNum = 12;BA.debugLine="Public preventScrolling As Boolean";
_preventscrolling = false;
 //BA.debugLineNum = 13;BA.debugLine="Public fixedFooter As Boolean";
_fixedfooter = false;
 //BA.debugLineNum = 14;BA.debugLine="Public Footer As UOEContainer";
_footer = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 15;BA.debugLine="Public Header As UOEContainer";
_header = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 16;BA.debugLine="Public IsBottomSheet As Boolean";
_isbottomsheet = false;
 //BA.debugLineNum = 17;BA.debugLine="Public startingTop As String";
_startingtop = "";
 //BA.debugLineNum = 18;BA.debugLine="Public endingTop As String";
_endingtop = "";
 //BA.debugLineNum = 19;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 20;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 21;BA.debugLine="Public Fields As List";
_fields = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 22;BA.debugLine="Public HideScrollBar As Boolean";
_hidescrollbar = false;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
String _script = "";
 //BA.debugLineNum = 141;BA.debugLine="Sub Close";
 //BA.debugLineNum = 142;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Modal.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".close();");
 //BA.debugLineNum = 145;BA.debugLine="BANano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return "";
}
public String  _destroy() throws Exception{
String _script = "";
 //BA.debugLineNum = 133;BA.debugLine="Sub Destroy";
 //BA.debugLineNum = 134;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Modal.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".destroy();");
 //BA.debugLineNum = 137;BA.debugLine="BANano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _getcss() throws Exception{
String _sel = "";
anywheresoftware.b4a.objects.collections.Map _cssmap = null;
String _strcss = "";
 //BA.debugLineNum = 50;BA.debugLine="Sub getCSS As String";
 //BA.debugLineNum = 51;BA.debugLine="Dim sel As String = $\"#${ID}\"$";
_sel = ("#"+__c.SmartStringFormatter("",(Object)(_id))+"");
 //BA.debugLineNum = 52;BA.debugLine="Dim cssmap As Map";
_cssmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 53;BA.debugLine="cssmap.Initialize";
_cssmap.Initialize();
 //BA.debugLineNum = 54;BA.debugLine="cssmap.clear";
_cssmap.Clear();
 //BA.debugLineNum = 55;BA.debugLine="cssmap.Put(\"overflow\", \"hidden\")";
_cssmap.Put((Object)("overflow"),(Object)("hidden"));
 //BA.debugLineNum = 56;BA.debugLine="cssmap.Put(\"id\", sel)";
_cssmap.Put((Object)("id"),(Object)(_sel));
 //BA.debugLineNum = 57;BA.debugLine="Dim strcss As String = App.Map2Json(cssmap)";
_strcss = _app._map2json(_cssmap);
 //BA.debugLineNum = 58;BA.debugLine="Return strcss";
if (true) return _strcss;
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _ms = null;
String _str = "";
 //BA.debugLineNum = 110;BA.debugLine="Sub getSettings() As String";
 //BA.debugLineNum = 111;BA.debugLine="Dim ms As Map";
_ms = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 112;BA.debugLine="ms.Initialize";
_ms.Initialize();
 //BA.debugLineNum = 113;BA.debugLine="ms.clear";
_ms.Clear();
 //BA.debugLineNum = 114;BA.debugLine="ms.Put(\"id\", ID)";
_ms.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 115;BA.debugLine="ms.Put(\"instance\", \"modal\")";
_ms.Put((Object)("instance"),(Object)("modal"));
 //BA.debugLineNum = 116;BA.debugLine="ms.Put(\"startingTop\", startingTop)";
_ms.Put((Object)("startingTop"),(Object)(_startingtop));
 //BA.debugLineNum = 117;BA.debugLine="ms.Put(\"endingTop\", endingTop)";
_ms.Put((Object)("endingTop"),(Object)(_endingtop));
 //BA.debugLineNum = 118;BA.debugLine="ms.Put(\"dismissible\", dismissible)";
_ms.Put((Object)("dismissible"),(Object)(_dismissible));
 //BA.debugLineNum = 119;BA.debugLine="ms.Put(\"preventScrolling\", preventScrolling)";
_ms.Put((Object)("preventScrolling"),(Object)(_preventscrolling));
 //BA.debugLineNum = 120;BA.debugLine="Dim str As String = App.Map2Json(ms)";
_str = _app._map2json(_ms);
 //BA.debugLineNum = 121;BA.debugLine="Return str";
if (true) return _str;
 //BA.debugLineNum = 122;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _mvarid,String _mtheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 26;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, mvarID As";
 //BA.debugLineNum = 27;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 28;BA.debugLine="ID = mvarID.tolowercase";
_id = _mvarid.toLowerCase();
 //BA.debugLineNum = 29;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 30;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 31;BA.debugLine="Theme = mTheme";
_theme = _mtheme;
 //BA.debugLineNum = 32;BA.debugLine="Header.Initialize(App,ID & \"-header\",False,\"\")";
_header._initialize(ba,_app,_id+"-header",__c.False,"");
 //BA.debugLineNum = 33;BA.debugLine="Content.Initialize(App,ID & \"-content\",False,\"\")";
_content._initialize(ba,_app,_id+"-content",__c.False,"");
 //BA.debugLineNum = 34;BA.debugLine="Content.addclass(\"modal-content\")";
_content._addclass("modal-content");
 //BA.debugLineNum = 35;BA.debugLine="Footer.Initialize(App,ID & \"-footer\",False,\"\")";
_footer._initialize(ba,_app,_id+"-footer",__c.False,"");
 //BA.debugLineNum = 36;BA.debugLine="Footer.AddClass(\"modal-footer\")";
_footer._addclass("modal-footer");
 //BA.debugLineNum = 37;BA.debugLine="preventScrolling = True";
_preventscrolling = __c.True;
 //BA.debugLineNum = 38;BA.debugLine="dismissible = False";
_dismissible = __c.False;
 //BA.debugLineNum = 39;BA.debugLine="fixedFooter = False";
_fixedfooter = __c.False;
 //BA.debugLineNum = 40;BA.debugLine="IsBottomSheet = False";
_isbottomsheet = __c.False;
 //BA.debugLineNum = 41;BA.debugLine="startingTop = \"4%\"";
_startingtop = "4%";
 //BA.debugLineNum = 42;BA.debugLine="endingTop = \"10%\"";
_endingtop = "10%";
 //BA.debugLineNum = 43;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 44;BA.debugLine="Fields.Initialize";
_fields.Initialize();
 //BA.debugLineNum = 45;BA.debugLine="Fields.clear";
_fields.Clear();
 //BA.debugLineNum = 46;BA.debugLine="HideScrollBar = True";
_hidescrollbar = __c.True;
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
String _script = "";
 //BA.debugLineNum = 125;BA.debugLine="Sub Open";
 //BA.debugLineNum = 126;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Modal.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".open();");
 //BA.debugLineNum = 129;BA.debugLine="BANano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 130;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoemodal  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEModal";
 //BA.debugLineNum = 81;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 82;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoemodal)(this);
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoemodal  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 68;BA.debugLine="Sub RemoveClass(sClass As String) As UOEModal";
 //BA.debugLineNum = 69;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 70;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoemodal)(this);
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 87;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 88;BA.debugLine="Element.AddClass(\"modal\")";
_element._addclass("modal");
 //BA.debugLineNum = 89;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 90;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 91;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 92;BA.debugLine="Element.AddContent(Header.ToString)";
_element._addcontent(_header._tostring());
 //BA.debugLineNum = 93;BA.debugLine="Element.AddContent(Content.tostring)";
_element._addcontent(_content._tostring());
 //BA.debugLineNum = 94;BA.debugLine="Element.AddContent(Footer.tostring)";
_element._addcontent(_footer._tostring());
 //BA.debugLineNum = 95;BA.debugLine="If fixedFooter Then";
if (_fixedfooter) { 
 //BA.debugLineNum = 96;BA.debugLine="Element.AddClass(\"modal-fixed-footer\")";
_element._addclass("modal-fixed-footer");
 };
 //BA.debugLineNum = 98;BA.debugLine="If IsBottomSheet Then";
if (_isbottomsheet) { 
 //BA.debugLineNum = 99;BA.debugLine="Element.AddClass(\"bottom-sheet\")";
_element._addclass("bottom-sheet");
 };
 //BA.debugLineNum = 101;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
