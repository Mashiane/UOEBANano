package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeiconsize extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeiconsize", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeiconsize.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _large = "";
public String _medium = "";
public String _small = "";
public String _tiny = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public Large As String = \"large\"";
_large = "large";
 //BA.debugLineNum = 6;BA.debugLine="Public Medium As String= \"medium\"";
_medium = "medium";
 //BA.debugLineNum = 7;BA.debugLine="Public Small As String= \"small\"";
_small = "small";
 //BA.debugLineNum = 8;BA.debugLine="Public Tiny As String= \"tiny\"";
_tiny = "tiny";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
