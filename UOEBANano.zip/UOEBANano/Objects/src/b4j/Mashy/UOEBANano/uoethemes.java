package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoethemes extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoethemes", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoethemes.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _primary = "";
public String _danger = "";
public String _warn = "";
public String _success = "";
public String _info = "";
public String _muted = "";
public String _default = "";
public String _primarytext = "";
public String _dangertext = "";
public String _warntext = "";
public String _successtext = "";
public String _infotext = "";
public String _mutedtext = "";
public String _defaulttext = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano  'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public primary As String= \"primary\"";
_primary = "primary";
 //BA.debugLineNum = 6;BA.debugLine="Public danger As String = \"danger\"";
_danger = "danger";
 //BA.debugLineNum = 7;BA.debugLine="Public warn As String= \"warn\"";
_warn = "warn";
 //BA.debugLineNum = 8;BA.debugLine="Public success As String= \"success\"";
_success = "success";
 //BA.debugLineNum = 9;BA.debugLine="Public info As String= \"info\"";
_info = "info";
 //BA.debugLineNum = 10;BA.debugLine="Public muted As String= \"muted\"";
_muted = "muted";
 //BA.debugLineNum = 11;BA.debugLine="Public default As String= \"default\"";
_default = "default";
 //BA.debugLineNum = 12;BA.debugLine="Public primarytext As String= \"primarytext\"";
_primarytext = "primarytext";
 //BA.debugLineNum = 13;BA.debugLine="Public dangertext As String = \"dangertext\"";
_dangertext = "dangertext";
 //BA.debugLineNum = 14;BA.debugLine="Public warntext As String= \"warntext\"";
_warntext = "warntext";
 //BA.debugLineNum = 15;BA.debugLine="Public successtext As String= \"successtext\"";
_successtext = "successtext";
 //BA.debugLineNum = 16;BA.debugLine="Public infotext As String= \"infotext\"";
_infotext = "infotext";
 //BA.debugLineNum = 17;BA.debugLine="Public mutedtext As String= \"mutedtext\"";
_mutedtext = "mutedtext";
 //BA.debugLineNum = 18;BA.debugLine="Public defaulttext As String= \"defaulttext\"";
_defaulttext = "defaulttext";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Initialize()";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
