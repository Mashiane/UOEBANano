package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetoc extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetoc", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetoc.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _items = null;
public String _theme = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoetoc  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 61;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 62;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoc)(this);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetoc  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub AddClass(sClass As String) As UOETOC";
 //BA.debugLineNum = 49;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 50;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoc)(this);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public String  _addlink(String _lnkid,String _lnktext,String _lnkhref,String _lnktheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 32;BA.debugLine="Sub AddLink(lnkID As String,lnkText As String,lnkH";
 //BA.debugLineNum = 33;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 34;BA.debugLine="li.Initialize(lnkID & \"li\",\"li\")";
_li._initialize(ba,_lnkid+"li","li");
 //BA.debugLineNum = 35;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 36;BA.debugLine="a.Initialize(lnkID,\"a\")";
_a._initialize(ba,_lnkid,"a");
 //BA.debugLineNum = 37;BA.debugLine="a.SetHREF(lnkHREF).AddContent(lnkText)";
_a._sethref(_lnkhref)._addcontent(_lnktext);
 //BA.debugLineNum = 38;BA.debugLine="App.MaterialUseTheme(lnkTheme,a)";
_app._materialusetheme(_lnktheme,_a);
 //BA.debugLineNum = 39;BA.debugLine="a.AddCursor";
_a._addcursor();
 //BA.debugLineNum = 40;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 41;BA.debugLine="Items.Add(li.tostring)";
_items.Add((Object)(_li._tostring()));
 //BA.debugLineNum = 42;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 43;BA.debugLine="App.AddEvent(lnkID, \"click\")";
_app._addevent(_lnkid,"click");
 };
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetoc  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 27;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 28;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoc)(this);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 10;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 14;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 15;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 16;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 17;BA.debugLine="Visibility= \"\"";
_visibility = "";
 //BA.debugLineNum = 18;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 19;BA.debugLine="Element.Initialize(sid,\"ul\")";
_element._initialize(ba,_sid,"ul");
 //BA.debugLineNum = 20;BA.debugLine="Element.AddClass(\"section\").AddClass(\"table-of-co";
_element._addclass("section")._addclass("table-of-contents");
 //BA.debugLineNum = 21;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 22;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetoc  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub RemoveAttribute(attr As String) As UOETOC";
 //BA.debugLineNum = 67;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 68;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoc)(this);
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetoc  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub RemoveClass(sClass As String) As UOETOC";
 //BA.debugLineNum = 55;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetoc)(this);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 73;BA.debugLine="If Theme = \"\" Then Theme = App.Theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 74;BA.debugLine="Element.AddContentList(Items)";
_element._addcontentlist(_items);
 //BA.debugLineNum = 75;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 76;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 82;BA.debugLine="Return Element.tostring";
if (true) return _element._tostring();
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
