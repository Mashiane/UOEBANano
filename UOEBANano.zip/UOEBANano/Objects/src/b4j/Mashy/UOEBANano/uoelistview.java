package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoelistview extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoelistview", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoelistview.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _visibility = "";
public String _zdepth = "";
public boolean _enabled = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoelistview  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 34;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelistview)(this);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelistview  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub AddClass(sClass As String) As UOEListView";
 //BA.debugLineNum = 22;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelistview)(this);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public String  _addcontainer(String _itemid,b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
 //BA.debugLineNum = 85;BA.debugLine="Sub AddContainer(itemID As String, cont As UOECont";
 //BA.debugLineNum = 87;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 88;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 89;BA.debugLine="li.addcontent(cont.tostring)";
_li._addcontent(_cont._tostring());
 //BA.debugLineNum = 90;BA.debugLine="Element.AddElement(li)";
_element._addelement(_li);
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public String  _additem(String _itemid,String _itemicon,String _itemtext,String _itembadge,boolean _badgenew,String _itemnavigateto,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchor _div = null;
b4j.Mashy.UOEBANano.uoehtml _li = null;
 //BA.debugLineNum = 58;BA.debugLine="Sub AddItem(itemID As String, itemIcon As String,";
 //BA.debugLineNum = 60;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 62;BA.debugLine="Dim div As UOEAnchor";
_div = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 63;BA.debugLine="div.Initialize(App,itemID & \"a\")";
_div._initialize(ba,_app,_itemid+"a");
 //BA.debugLineNum = 64;BA.debugLine="div.element.MaterialCollapsibleHeader(True)";
_div._element._materialcollapsibleheader(__c.True);
 //BA.debugLineNum = 65;BA.debugLine="modUOE.materialAddIcon(App,div.Element,itemIcon,\"";
_moduoe._materialaddicon(_app,_div._element,_itemicon,"",_icontheme,__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 66;BA.debugLine="div.Element.AddContent(itemText)";
_div._element._addcontent(_itemtext);
 //BA.debugLineNum = 67;BA.debugLine="modUOE.MaterialAddBadge(App,div.Element,itemBadge";
_moduoe._materialaddbadge(_app,_div._element,_itembadge,_badgenew,_app._enumvisibility._visible,__c.True,"",__c.False);
 //BA.debugLineNum = 69;BA.debugLine="div.WavesEffect = True";
_div._waveseffect = __c.True;
 //BA.debugLineNum = 70;BA.debugLine="div.WavesType = App.EnumWavesType.Light";
_div._wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 71;BA.debugLine="div.TextVisible = True";
_div._textvisible = __c.True;
 //BA.debugLineNum = 72;BA.debugLine="div.Theme = itemTheme";
_div._theme = _itemtheme;
 //BA.debugLineNum = 73;BA.debugLine="div.href = itemNavigateTo";
_div._href = _itemnavigateto;
 //BA.debugLineNum = 75;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 76;BA.debugLine="li.Initialize(itemID,\"li\")";
_li._initialize(ba,_itemid,"li");
 //BA.debugLineNum = 77;BA.debugLine="li.addcontent(div.tostring)";
_li._addcontent(_div._tostring());
 //BA.debugLineNum = 78;BA.debugLine="Element.AddElement(li)";
_element._addelement(_li);
 //BA.debugLineNum = 79;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 80;BA.debugLine="App.AddEvent(itemID,\"click\")";
_app._addevent(_itemid,"click");
 };
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoelistview  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 16;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 17;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelistview)(this);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _itemid,String _itemtheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 45;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, itemID As";
 //BA.debugLineNum = 46;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 47;BA.debugLine="ID = itemID.tolowercase";
_id = _itemid.toLowerCase();
 //BA.debugLineNum = 48;BA.debugLine="Theme = itemTheme";
_theme = _itemtheme;
 //BA.debugLineNum = 49;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 50;BA.debugLine="Element.Initialize(ID,\"ul\")";
_element._initialize(ba,_id,"ul");
 //BA.debugLineNum = 51;BA.debugLine="Element.AddClass(\"collapsible\")";
_element._addclass("collapsible");
 //BA.debugLineNum = 52;BA.debugLine="Element.AddAttribute(\"data-collapsible\",App.EnumC";
_element._addattribute("data-collapsible",_app._enumcollapsibletype._accordion);
 //BA.debugLineNum = 53;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 54;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoelistview  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEListView";
 //BA.debugLineNum = 40;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 41;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelistview)(this);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelistview  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub RemoveClass(sClass As String) As UOEListView";
 //BA.debugLineNum = 28;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 29;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelistview)(this);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 95;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 96;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 97;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 98;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 99;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 100;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 105;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
