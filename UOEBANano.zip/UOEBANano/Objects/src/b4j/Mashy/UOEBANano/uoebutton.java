package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoebutton extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoebutton", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoebutton.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _text = "";
public boolean _enabled = false;
public String _size = "";
public String _buttontype = "";
public boolean _pulsing = false;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _href = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _theme = "";
public String _zdepth = "";
public String _visibility = "";
public boolean _isfab = false;
public boolean _click2toggle = false;
public boolean _horizontal = false;
public boolean _istoolbar = false;
public anywheresoftware.b4a.objects.collections.List _buttons = null;
public boolean _waveseffect = false;
public String _wavestype = "";
public boolean _wavescircle = false;
public boolean _hoverable = false;
public boolean _modaltrigger = false;
public boolean _modalclose = false;
public String _modalname = "";
public boolean _autofocus = false;
public boolean _fitwidth = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoebutton  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 52;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub AddClass(sClass As String) As UOEButton";
 //BA.debugLineNum = 40;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 41;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _addicon(String _siconname,String _siconalign,String _sicontheme,boolean _biconcircle,boolean _bwave) throws Exception{
 //BA.debugLineNum = 115;BA.debugLine="public Sub AddIcon(sIconName As String, siconAlign";
 //BA.debugLineNum = 116;BA.debugLine="Select Case ButtonType";
switch (BA.switchObjectToInt(_buttontype,_app._enumbuttontype._fab,_app._enumbuttontype._floating,_app._enumbuttontype._halfwayfab)) {
case 0: {
 //BA.debugLineNum = 118;BA.debugLine="siconAlign=\"\"";
_siconalign = "";
 //BA.debugLineNum = 119;BA.debugLine="bIconCircle = True";
_biconcircle = __c.True;
 break; }
case 1: {
 //BA.debugLineNum = 121;BA.debugLine="siconAlign=\"\"";
_siconalign = "";
 //BA.debugLineNum = 122;BA.debugLine="bIconCircle = True";
_biconcircle = __c.True;
 break; }
case 2: {
 //BA.debugLineNum = 124;BA.debugLine="siconAlign=\"\"";
_siconalign = "";
 //BA.debugLineNum = 125;BA.debugLine="bIconCircle = True";
_biconcircle = __c.True;
 break; }
}
;
 //BA.debugLineNum = 127;BA.debugLine="modUOE.MaterialAddIcon(App,Element,sIconName,sico";
_moduoe._materialaddicon(_app,_element,_siconname,_siconalign,_sicontheme,_biconcircle,_bwave,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 128;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _addiconwithcolors(String _iconname,String _forecolor,String _backcolor) throws Exception{
 //BA.debugLineNum = 108;BA.debugLine="Sub AddIconWithColors(IconName As String, ForeColo";
 //BA.debugLineNum = 110;BA.debugLine="AddIcon(IconName,\"\",ID & \"theme\",False,False)";
_addicon(_iconname,"",_id+"theme",__c.False,__c.False);
 //BA.debugLineNum = 111;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _addjusticon(String _iconname) throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Sub AddJustIcon(IconName As String) As UOEButton";
 //BA.debugLineNum = 102;BA.debugLine="If IconName = \"\" Then Return Me";
if ((_iconname).equals("")) { 
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);};
 //BA.debugLineNum = 103;BA.debugLine="AddIcon(IconName,\"\",Theme,False,False)";
_addicon(_iconname,"",_theme,__c.False,__c.False);
 //BA.debugLineNum = 104;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 34;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Private Text As String";
_text = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 7;BA.debugLine="Public Size As String";
_size = "";
 //BA.debugLineNum = 8;BA.debugLine="Public ButtonType As String";
_buttontype = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Pulsing As Boolean";
_pulsing = false;
 //BA.debugLineNum = 10;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 11;BA.debugLine="Public HREF As String";
_href = "";
 //BA.debugLineNum = 12;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 14;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 16;BA.debugLine="Public IsFAB As Boolean";
_isfab = false;
 //BA.debugLineNum = 17;BA.debugLine="Public Click2Toggle As Boolean";
_click2toggle = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Horizontal As Boolean";
_horizontal = false;
 //BA.debugLineNum = 19;BA.debugLine="Public IsToolBar As Boolean";
_istoolbar = false;
 //BA.debugLineNum = 20;BA.debugLine="Private Buttons As List";
_buttons = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 21;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 22;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 23;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 24;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 25;BA.debugLine="Public ModalTrigger As Boolean";
_modaltrigger = false;
 //BA.debugLineNum = 26;BA.debugLine="Public ModalClose As Boolean";
_modalclose = false;
 //BA.debugLineNum = 27;BA.debugLine="Public ModalName As String";
_modalname = "";
 //BA.debugLineNum = 28;BA.debugLine="Public AutoFocus As Boolean";
_autofocus = false;
 //BA.debugLineNum = 29;BA.debugLine="Public FitWidth As Boolean";
_fitwidth = false;
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebutton  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _btext,String _btheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 64;BA.debugLine="Sub Initialize(thisApp As UOEApp, sID As String,bT";
 //BA.debugLineNum = 65;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 66;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 67;BA.debugLine="Text = bText";
_text = _btext;
 //BA.debugLineNum = 68;BA.debugLine="ButtonType = App.EnumButtonType.raised";
_buttontype = _app._enumbuttontype._raised;
 //BA.debugLineNum = 69;BA.debugLine="Pulsing = False";
_pulsing = __c.False;
 //BA.debugLineNum = 70;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 71;BA.debugLine="HREF=\"#\"";
_href = "#";
 //BA.debugLineNum = 72;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 73;BA.debugLine="Size = App.EnumButtonSize.medium";
_size = _app._enumbuttonsize._medium;
 //BA.debugLineNum = 74;BA.debugLine="IsFAB = False";
_isfab = __c.False;
 //BA.debugLineNum = 75;BA.debugLine="Click2Toggle = False";
_click2toggle = __c.False;
 //BA.debugLineNum = 76;BA.debugLine="Horizontal = False";
_horizontal = __c.False;
 //BA.debugLineNum = 77;BA.debugLine="IsToolBar = False";
_istoolbar = __c.False;
 //BA.debugLineNum = 78;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 79;BA.debugLine="WavesEffect = True";
_waveseffect = __c.True;
 //BA.debugLineNum = 80;BA.debugLine="Buttons.Initialize";
_buttons.Initialize();
 //BA.debugLineNum = 81;BA.debugLine="Buttons.clear";
_buttons.Clear();
 //BA.debugLineNum = 82;BA.debugLine="WavesType = App.EnumWavesType.light";
_wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 83;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 84;BA.debugLine="Theme = bTheme";
_theme = _btheme;
 //BA.debugLineNum = 85;BA.debugLine="Element.Initialize(ID,\"a\")";
_element._initialize(ba,_id,"a");
 //BA.debugLineNum = 86;BA.debugLine="ModalClose = False";
_modalclose = __c.False;
 //BA.debugLineNum = 87;BA.debugLine="ModalTrigger = False";
_modaltrigger = __c.False;
 //BA.debugLineNum = 88;BA.debugLine="AutoFocus = False";
_autofocus = __c.False;
 //BA.debugLineNum = 89;BA.debugLine="FitWidth = False";
_fitwidth = __c.False;
 //BA.debugLineNum = 90;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEButton";
 //BA.debugLineNum = 58;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 59;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub RemoveClass(sClass As String) As UOEButton";
 //BA.debugLineNum = 46;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 47;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebutton  _setbuttontype(String _btntype) throws Exception{
 //BA.debugLineNum = 94;BA.debugLine="Sub SetButtonType(btnType As String) As UOEButton";
 //BA.debugLineNum = 95;BA.debugLine="ButtonType = btnType";
_buttontype = _btntype;
 //BA.debugLineNum = 96;BA.debugLine="Element.MaterialButtonType(ButtonType)";
_element._materialbuttontype(_buttontype);
 //BA.debugLineNum = 97;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebutton)(this);
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _fab = null;
b4j.Mashy.UOEBANano.uoehtml _li = null;
String _strbutton = "";
 //BA.debugLineNum = 132;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 133;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 142;BA.debugLine="Element.AddClass(\"btn\")";
_element._addclass("btn");
 //BA.debugLineNum = 143;BA.debugLine="If ButtonType = \"\" Then ButtonType = App.EnumButt";
if ((_buttontype).equals("")) { 
_buttontype = _app._enumbuttontype._raised;};
 //BA.debugLineNum = 144;BA.debugLine="Element.MaterialButtonType(ButtonType)";
_element._materialbuttontype(_buttontype);
 //BA.debugLineNum = 145;BA.debugLine="Select Case ButtonType";
switch (BA.switchObjectToInt(_buttontype,_app._enumbuttontype._fab,_app._enumbuttontype._floating,_app._enumbuttontype._halfwayfab)) {
case 0: {
 //BA.debugLineNum = 147;BA.debugLine="Text=\"\"";
_text = "";
 //BA.debugLineNum = 148;BA.debugLine="Element.RemoveClass(\"btn\")";
_element._removeclass("btn");
 break; }
case 1: {
 //BA.debugLineNum = 150;BA.debugLine="Text=\"\"";
_text = "";
 //BA.debugLineNum = 151;BA.debugLine="Element.RemoveClass(\"btn\")";
_element._removeclass("btn");
 break; }
case 2: {
 //BA.debugLineNum = 153;BA.debugLine="Text=\"\"";
_text = "";
 //BA.debugLineNum = 154;BA.debugLine="Element.AddClass(\"btn-floating\").AddClass(\"half";
_element._addclass("btn-floating")._addclass("halfway-fab");
 break; }
}
;
 //BA.debugLineNum = 156;BA.debugLine="Element.MaterialWavesEffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 157;BA.debugLine="Element.SetHRef(HREF)";
_element._sethref(_href);
 //BA.debugLineNum = 158;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 159;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 160;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 161;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 162;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 163;BA.debugLine="Element.AddClass(ButtonType)";
_element._addclass(_buttontype);
 //BA.debugLineNum = 164;BA.debugLine="Element.MaterialPulse(Pulsing)";
_element._materialpulse(_pulsing);
 //BA.debugLineNum = 165;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 166;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 167;BA.debugLine="Element.MaterialButtonSize(Size)";
_element._materialbuttonsize(_size);
 //BA.debugLineNum = 168;BA.debugLine="Element.AddContent(Text)";
_element._addcontent(_text);
 //BA.debugLineNum = 169;BA.debugLine="Element.AddClassOnCondition(ModalTrigger,\"modal-t";
_element._addclassoncondition(_modaltrigger,"modal-trigger");
 //BA.debugLineNum = 170;BA.debugLine="Element.AddAttributeOnCondition(AutoFocus,\"autofo";
_element._addattributeoncondition(_autofocus,"autofocus","true");
 //BA.debugLineNum = 171;BA.debugLine="If ModalName <> \"\" Then";
if ((_modalname).equals("") == false) { 
 //BA.debugLineNum = 172;BA.debugLine="Element.SetHREF($\"#${ModalName}\"$)";
_element._sethref(("#"+__c.SmartStringFormatter("",(Object)(_modalname))+""));
 //BA.debugLineNum = 173;BA.debugLine="Element.addattribute(\"data-target\", ModalName)";
_element._addattribute("data-target",_modalname);
 };
 //BA.debugLineNum = 175;BA.debugLine="Element.AddClassOnCondition(ModalClose,\"modal-clo";
_element._addclassoncondition(_modalclose,"modal-close");
 //BA.debugLineNum = 177;BA.debugLine="If IsFAB = True Then";
if (_isfab==__c.True) { 
 //BA.debugLineNum = 178;BA.debugLine="Dim fab As UOEHTML";
_fab = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 179;BA.debugLine="fab.Initialize(ID & \"fab\",\"div\")";
_fab._initialize(ba,_id+"fab","div");
 //BA.debugLineNum = 180;BA.debugLine="fab.AddClass(\"fixed-action-btn\")";
_fab._addclass("fixed-action-btn");
 //BA.debugLineNum = 181;BA.debugLine="fab.AddContent(Element.HTML)";
_fab._addcontent(_element._html());
 //BA.debugLineNum = 182;BA.debugLine="fab.MaterialClick2Toggle(Click2Toggle)";
_fab._materialclick2toggle(_click2toggle);
 //BA.debugLineNum = 183;BA.debugLine="fab.MaterialHorizontal(Horizontal)";
_fab._materialhorizontal(_horizontal);
 //BA.debugLineNum = 184;BA.debugLine="fab.MaterialToolBar(IsToolBar)";
_fab._materialtoolbar(_istoolbar);
 //BA.debugLineNum = 191;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 192;BA.debugLine="li.Initialize(ID & \"-buttons\",\"ul\")";
_li._initialize(ba,_id+"-buttons","ul");
 //BA.debugLineNum = 193;BA.debugLine="For Each strButton As String In Buttons";
{
final anywheresoftware.b4a.BA.IterableList group46 = _buttons;
final int groupLen46 = group46.getSize()
;int index46 = 0;
;
for (; index46 < groupLen46;index46++){
_strbutton = BA.ObjectToString(group46.Get(index46));
 //BA.debugLineNum = 194;BA.debugLine="li.AddContent(strButton)";
_li._addcontent(_strbutton);
 }
};
 //BA.debugLineNum = 196;BA.debugLine="fab.AddContent(li.HTML)";
_fab._addcontent(_li._html());
 //BA.debugLineNum = 201;BA.debugLine="Return fab.html";
if (true) return _fab._html();
 }else {
 //BA.debugLineNum = 207;BA.debugLine="Return Element.html";
if (true) return _element._html();
 };
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
