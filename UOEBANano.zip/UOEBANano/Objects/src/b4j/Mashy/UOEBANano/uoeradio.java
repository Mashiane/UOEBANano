package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeradio extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeradio", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeradio.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _theme = "";
public boolean _enabled = false;
public boolean _hoverable = false;
public boolean _withgap = false;
public boolean _checked = false;
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _zdepth = "";
public b4j.Mashy.UOEBANano.uoehtml _lbl = null;
public b4j.Mashy.UOEBANano.uoehtml _inp = null;
public b4j.Mashy.UOEBANano.uoehtml _spn = null;
public boolean _inline = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeradio  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 64;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 65;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradio)(this);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeradio  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub AddClass(sClass As String) As UOERadio";
 //BA.debugLineNum = 52;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradio)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeradio  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 25;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradio)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 8;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 9;BA.debugLine="Public WithGap As Boolean";
_withgap = false;
 //BA.debugLineNum = 10;BA.debugLine="Public Checked As Boolean";
_checked = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 12;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 15;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 16;BA.debugLine="Private lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 17;BA.debugLine="Private inp As UOEHTML";
_inp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 18;BA.debugLine="Private spn As UOEHTML";
_spn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 19;BA.debugLine="Public Inline As Boolean";
_inline = false;
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _sname,String _svalue,String _stitle,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 30;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 32;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 33;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 34;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 35;BA.debugLine="Checked = False";
_checked = __c.False;
 //BA.debugLineNum = 36;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 37;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 38;BA.debugLine="WithGap = False";
_withgap = __c.False;
 //BA.debugLineNum = 39;BA.debugLine="Element.Initialize(ID,\"p\")";
_element._initialize(ba,_id,"p");
 //BA.debugLineNum = 40;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 41;BA.debugLine="inp.Initialize(ID & \"-inp\",\"input\")";
_inp._initialize(ba,_id+"-inp","input");
 //BA.debugLineNum = 42;BA.debugLine="inp.SetTYPE(\"radio\")";
_inp._settype("radio");
 //BA.debugLineNum = 43;BA.debugLine="inp.SetNAME(sName)";
_inp._setname(_sname);
 //BA.debugLineNum = 44;BA.debugLine="inp.SetVALUE(sValue)";
_inp._setvalue(_svalue);
 //BA.debugLineNum = 45;BA.debugLine="spn.Initialize(ID & \"-span\",\"span\")";
_spn._initialize(ba,_id+"-span","span");
 //BA.debugLineNum = 46;BA.debugLine="spn.AddContent(sTitle & \"{NBSP}{NBSP}\")";
_spn._addcontent(_stitle+"{NBSP}{NBSP}");
 //BA.debugLineNum = 47;BA.debugLine="Inline = False";
_inline = __c.False;
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeradio  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Sub RemoveAttribute(attr As String) As UOERadio";
 //BA.debugLineNum = 70;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 71;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradio)(this);
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeradio  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub RemoveClass(sClass As String) As UOERadio";
 //BA.debugLineNum = 58;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 59;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradio)(this);
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 76;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 77;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 78;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 79;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 80;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 81;BA.debugLine="Element.MaterialHoverable(Hoverable)";
_element._materialhoverable(_hoverable);
 //BA.debugLineNum = 83;BA.debugLine="inp.AddAttributeOnCondition(Not(Enabled),\"disable";
_inp._addattributeoncondition(__c.Not(_enabled),"disabled","disabled");
 //BA.debugLineNum = 84;BA.debugLine="inp.AddAttributeOnCondition(Checked,\"checked\",\"ch";
_inp._addattributeoncondition(_checked,"checked","checked");
 //BA.debugLineNum = 85;BA.debugLine="inp.AddClassOnCondition(WithGap,\"with-gap\")";
_inp._addclassoncondition(_withgap,"with-gap");
 //BA.debugLineNum = 86;BA.debugLine="lbl.AddElement(inp)";
_lbl._addelement(_inp);
 //BA.debugLineNum = 87;BA.debugLine="lbl.AddElement(spn)";
_lbl._addelement(_spn);
 //BA.debugLineNum = 88;BA.debugLine="Element.AddElement(lbl)";
_element._addelement(_lbl);
 //BA.debugLineNum = 89;BA.debugLine="Element.AddClassOnCondition(Inline,\"inline\")";
_element._addclassoncondition(_inline,"inline");
 //BA.debugLineNum = 90;BA.debugLine="Element.AddStyleAttributeOnCondition(Inline,\"disp";
_element._addstyleattributeoncondition(_inline,"display","inline-block");
 //BA.debugLineNum = 91;BA.debugLine="Element.AddStyleAttributeOnCondition(Inline,\"padd";
_element._addstyleattributeoncondition(_inline,"padding","0 12px");
 //BA.debugLineNum = 97;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
