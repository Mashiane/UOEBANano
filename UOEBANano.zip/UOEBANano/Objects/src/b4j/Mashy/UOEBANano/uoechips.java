package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoechips extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoechips", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoechips.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _theme = "";
public String _visibility = "";
public boolean _waveseffect = false;
public String _wavestype = "";
public boolean _wavescircle = false;
public String _zdepth = "";
public boolean _enabled = false;
public anywheresoftware.b4a.objects.collections.List _initialwith = null;
public anywheresoftware.b4a.objects.collections.List _autocomplete = null;
public String _placeholder = "";
public String _secondaryplaceholder = "";
public String _onselect = "";
public String _ondelete = "";
public String _onadd = "";
public boolean _hoverable = false;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoechips  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 46;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 47;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechips  _addautocomplete(String _svalue) throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Sub AddAutoComplete(sValue As String) As UOEChips";
 //BA.debugLineNum = 91;BA.debugLine="If sValue = \"\" Then Return Me";
if ((_svalue).equals("")) { 
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);};
 //BA.debugLineNum = 92;BA.debugLine="If AutoComplete.IndexOf(sValue) = -1 Then AutoCom";
if (_autocomplete.IndexOf((Object)(_svalue))==-1) { 
_autocomplete.Add((Object)(_svalue));};
 //BA.debugLineNum = 93;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechips  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddClass(sClass As String) As UOEChips";
 //BA.debugLineNum = 34;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechips  _addinitialwith(String _svalue) throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Sub AddInitialWith(sValue As String) As UOEChips";
 //BA.debugLineNum = 84;BA.debugLine="If sValue = \"\" Then Return Me";
if ((_svalue).equals("")) { 
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);};
 //BA.debugLineNum = 85;BA.debugLine="If InitialWith.IndexOf(sValue) = -1 Then InitialW";
if (_initialwith.IndexOf((Object)(_svalue))==-1) { 
_initialwith.Add((Object)(_svalue));};
 //BA.debugLineNum = 86;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechips  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 28;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 29;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 10;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 11;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 12;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 14;BA.debugLine="Private InitialWith As List";
_initialwith = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 15;BA.debugLine="Private AutoComplete As List";
_autocomplete = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 16;BA.debugLine="Public PlaceHolder As String";
_placeholder = "";
 //BA.debugLineNum = 17;BA.debugLine="Public SecondaryPlaceHolder As String";
_secondaryplaceholder = "";
 //BA.debugLineNum = 18;BA.debugLine="Public OnSelect As String";
_onselect = "";
 //BA.debugLineNum = 19;BA.debugLine="Public OnDelete As String";
_ondelete = "";
 //BA.debugLineNum = 20;BA.debugLine="Public OnAdd As String";
_onadd = "";
 //BA.debugLineNum = 21;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 22;BA.debugLine="Public OnSelect As String";
_onselect = "";
 //BA.debugLineNum = 23;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _deletechip(int _idx) throws Exception{
String _script = "";
 //BA.debugLineNum = 120;BA.debugLine="Sub DeleteChip(idx As Int) As String";
 //BA.debugLineNum = 121;BA.debugLine="Dim script As String = $\"${Instance}.deleteChip($";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".deleteChip("+__c.SmartStringFormatter("",(Object)(_idx))+");");
 //BA.debugLineNum = 122;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 123;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _chipid,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 57;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, chipID As";
 //BA.debugLineNum = 59;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 60;BA.debugLine="InitialWith.Initialize";
_initialwith.Initialize();
 //BA.debugLineNum = 61;BA.debugLine="InitialWith.clear";
_initialwith.Clear();
 //BA.debugLineNum = 62;BA.debugLine="AutoComplete.Initialize";
_autocomplete.Initialize();
 //BA.debugLineNum = 63;BA.debugLine="AutoComplete.clear";
_autocomplete.Clear();
 //BA.debugLineNum = 64;BA.debugLine="PlaceHolder=\"\"";
_placeholder = "";
 //BA.debugLineNum = 65;BA.debugLine="SecondaryPlaceHolder=\"\"";
_secondaryplaceholder = "";
 //BA.debugLineNum = 66;BA.debugLine="OnSelect=\"\"";
_onselect = "";
 //BA.debugLineNum = 67;BA.debugLine="OnDelete=\"\"";
_ondelete = "";
 //BA.debugLineNum = 68;BA.debugLine="OnAdd=\"\"";
_onadd = "";
 //BA.debugLineNum = 69;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 70;BA.debugLine="ID = chipID.tolowercase";
_id = _chipid.toLowerCase();
 //BA.debugLineNum = 71;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 72;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 73;BA.debugLine="Element.AddClass(\"col\").AddClass(\"s12\").AddClass(";
_element._addclass("col")._addclass("s12")._addclass("m12")._addclass("l12");
 //BA.debugLineNum = 74;BA.debugLine="Element.AddClass(\"chips-initial\").AddClass(\"chips";
_element._addclass("chips-initial")._addclass("chips-placeholder");
 //BA.debugLineNum = 75;BA.debugLine="Element.AddClass(\"chips-autocomplete\").AddClass(\"";
_element._addclass("chips-autocomplete")._addclass("chips");
 //BA.debugLineNum = 76;BA.debugLine="WavesType = App.EnumWavesType.Light";
_wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 77;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 78;BA.debugLine="WavesEffect = True";
_waveseffect = __c.True;
 //BA.debugLineNum = 79;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoechips  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEChips";
 //BA.debugLineNum = 52;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechips  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub RemoveClass(sClass As String) As UOEChips";
 //BA.debugLineNum = 40;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 41;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechips)(this);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public String  _selectchip(int _idx) throws Exception{
String _script = "";
 //BA.debugLineNum = 126;BA.debugLine="Sub SelectChip(idx As Int) As String";
 //BA.debugLineNum = 127;BA.debugLine="Dim script As String = $\"${Instance}.selectChip($";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".selectChip("+__c.SmartStringFormatter("",(Object)(_idx))+");");
 //BA.debugLineNum = 128;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 129;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 153;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 154;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 155;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 156;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 157;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 158;BA.debugLine="App.materialusetheme(ID,Element)";
_app._materialusetheme(_id,_element);
 //BA.debugLineNum = 159;BA.debugLine="Element.MaterialWavesEffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 160;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 161;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 192;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
