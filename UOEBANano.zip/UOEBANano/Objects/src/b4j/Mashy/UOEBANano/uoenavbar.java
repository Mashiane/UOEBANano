package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoenavbar extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoenavbar", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoenavbar.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _theme = "";
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _nw = null;
public b4j.Mashy.UOEBANano.uoehtml _logo = null;
public b4j.Mashy.UOEBANano.uoehtml _leftmenu = null;
public b4j.Mashy.UOEBANano.uoehtml _rightmenu = null;
public String _leftmenuvisibility = "";
public String _rightmenuvisibility = "";
public String _logoposition = "";
public b4j.Mashy.UOEBANano.uoehtml _pcol = null;
public boolean _fixed = false;
public anywheresoftware.b4a.objects.collections.Map _dropdowns = null;
public b4j.Mashy.UOEBANano.uoecontainer _content = null;
public boolean _hascontents = false;
public b4j.Mashy.UOEBANano.uoesidebar _drawer = null;
public boolean _showmenuonlarge = false;
public boolean _hastabs = false;
public b4j.Mashy.UOEBANano.uoehtml _tabs = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 545;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 546;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 547;BA.debugLine="End Sub";
return "";
}
public String  _addavatar(String _itemid,String _itemimageurl,boolean _bcircle,String _itemtext,String _itemnavigateto,boolean _textvisible,String _itempos,String _itemvisibility,String _itemtheme,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoeanchoricon _a = null;
b4j.Mashy.UOEBANano.uoespan _st = null;
 //BA.debugLineNum = 408;BA.debugLine="Sub AddAvatar(itemID As String, itemImageURL As St";
 //BA.debugLineNum = 409;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 411;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 412;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 413;BA.debugLine="li.Initialize(sKey & \"li\", \"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 418;BA.debugLine="Dim a As UOEAnchorIcon";
_a = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 419;BA.debugLine="a.Initialize(App,itemID,\"\",\"\",False,\"\",itemNaviga";
_a._initialize(ba,_app,_itemid,"","",__c.False,"",_itemnavigateto,_textvisible,_itemtheme,"");
 //BA.debugLineNum = 420;BA.debugLine="modUOE.Materialaddimage(App,a.a,itemImageURL,\"\",A";
_moduoe._materialaddimage(_app,_a._a,_itemimageurl,"",_app._itemheight,_app._itemheight,_bcircle,__c.True,__c.True,_app._imagetopmargin);
 //BA.debugLineNum = 422;BA.debugLine="Dim st As UOESpan";
_st = new b4j.Mashy.UOEBANano.uoespan();
 //BA.debugLineNum = 423;BA.debugLine="st.Initialize(App,itemID & \"st\",itemText,True,App";
_st._initialize(ba,_app,_itemid+"st",_itemtext,__c.True,_app._enumvisibility._visible,_itemtheme);
 //BA.debugLineNum = 424;BA.debugLine="a.Text = st.tostring";
_a._text = _st._tostring();
 //BA.debugLineNum = 425;BA.debugLine="modUOE.MaterialaddBadge(App,a.a,\"\",False,App.Enum";
_moduoe._materialaddbadge(_app,_a._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 426;BA.debugLine="li.MaterialVisibility(itemVisibility)";
_li._materialvisibility(_itemvisibility);
 //BA.debugLineNum = 429;BA.debugLine="li.AddContent(a.tostring)";
_li._addcontent(_a._tostring());
 //BA.debugLineNum = 430;BA.debugLine="If itemPos.tolowercase = \"right\" Then";
if ((_itempos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 431;BA.debugLine="RightMenu.addcontentline(li.HTML)";
_rightmenu._addcontentline(_li._html());
 }else {
 //BA.debugLineNum = 433;BA.debugLine="LeftMenu.addcontentline(li.HTML)";
_leftmenu._addcontentline(_li._html());
 };
 //BA.debugLineNum = 435;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 436;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 438;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 440;BA.debugLine="End Sub";
return "";
}
public String  _addbutton(String _btnid,String _btntext,String _btniconname,String _btniconalign,String _btnnavigateto,String _btnsize,String _btnvisibility,String _btntheme,String _icontheme,String _btnpos,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 443;BA.debugLine="Sub AddButton(btnID As String, btnText As String,";
 //BA.debugLineNum = 444;BA.debugLine="btnID = btnID.tolowercase";
_btnid = _btnid.toLowerCase();
 //BA.debugLineNum = 445;BA.debugLine="Dim sKey As String = $\"${ID}${btnID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_btnid))+"");
 //BA.debugLineNum = 447;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 448;BA.debugLine="li.Initialize(sKey & \"li\", \"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 452;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 453;BA.debugLine="btn.Initialize(App,btnID,btnText,btnTheme)";
_btn._initialize(ba,_app,_btnid,_btntext,_btntheme);
 //BA.debugLineNum = 454;BA.debugLine="btn.Visibility = btnVisibility";
_btn._visibility = _btnvisibility;
 //BA.debugLineNum = 455;BA.debugLine="btn.HREF = btnNavigateTo";
_btn._href = _btnnavigateto;
 //BA.debugLineNum = 456;BA.debugLine="btn.SetButtonType(App.EnumButtonType.raised)";
_btn._setbuttontype(_app._enumbuttontype._raised);
 //BA.debugLineNum = 457;BA.debugLine="btn.AddIcon(btnIconName,btnIconAlign,iconTheme,Fa";
_btn._addicon(_btniconname,_btniconalign,_icontheme,__c.False,__c.False);
 //BA.debugLineNum = 458;BA.debugLine="btn.Size = btnSize";
_btn._size = _btnsize;
 //BA.debugLineNum = 460;BA.debugLine="li.AddContent(btn.tostring)";
_li._addcontent(_btn._tostring());
 //BA.debugLineNum = 461;BA.debugLine="If btnPos.tolowercase = \"right\" Then";
if ((_btnpos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 462;BA.debugLine="RightMenu.addcontentline(li.HTML)";
_rightmenu._addcontentline(_li._html());
 }else {
 //BA.debugLineNum = 464;BA.debugLine="LeftMenu.addcontentline(li.HTML)";
_leftmenu._addcontentline(_li._html());
 };
 //BA.debugLineNum = 466;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 467;BA.debugLine="App.AddEvent(btnID, \"click\")";
_app._addevent(_btnid,"click");
 }else {
 //BA.debugLineNum = 469;BA.debugLine="App.HeadersToFix.Put(btnID,btnID)";
_app._headerstofix.Put((Object)(_btnid),(Object)(_btnid));
 };
 //BA.debugLineNum = 471;BA.debugLine="End Sub";
return "";
}
public String  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 535;BA.debugLine="Sub AddClass(sClass As String)";
 //BA.debugLineNum = 536;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 537;BA.debugLine="End Sub";
return "";
}
public String  _adddividerl(String _themename) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 130;BA.debugLine="Sub AddDividerL(themeName As String)";
 //BA.debugLineNum = 131;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 132;BA.debugLine="div.Initialize(\"\",\"li\")";
_div._initialize(ba,"","li");
 //BA.debugLineNum = 133;BA.debugLine="div.AddClass(\"divider\")";
_div._addclass("divider");
 //BA.debugLineNum = 134;BA.debugLine="App.MaterialUseTheme(themeName,div)";
_app._materialusetheme(_themename,_div);
 //BA.debugLineNum = 135;BA.debugLine="LeftMenu.addcontentline(div.HTML)";
_leftmenu._addcontentline(_div._html());
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public String  _adddividerr(String _themename) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 121;BA.debugLine="Sub AddDividerR(themeName As String)";
 //BA.debugLineNum = 122;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 123;BA.debugLine="div.Initialize(\"\",\"li\")";
_div._initialize(ba,"","li");
 //BA.debugLineNum = 124;BA.debugLine="div.AddClass(\"divider\")";
_div._addclass("divider");
 //BA.debugLineNum = 125;BA.debugLine="App.MaterialUseTheme(themeName,div)";
_app._materialusetheme(_themename,_div);
 //BA.debugLineNum = 126;BA.debugLine="RightMenu.addcontentline(div.HTML)";
_rightmenu._addcontentline(_div._html());
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public String  _adddropdown(String _iid,String _itext,String _ivisibility,String _ileftorright,boolean _bhover,boolean _bcovertrigger,boolean _closeonclick,boolean _constrainwidth,String _itheme) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
b4j.Mashy.UOEBANano.uoehtml _i = null;
anywheresoftware.b4a.objects.collections.List _items = null;
anywheresoftware.b4a.objects.collections.Map _mset = null;
String _sset = "";
 //BA.debugLineNum = 475;BA.debugLine="Sub AddDropDown(iID As String,iText As String,iVis";
 //BA.debugLineNum = 476;BA.debugLine="Dim sKey As String = $\"${ID}${iID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_iid))+"");
 //BA.debugLineNum = 477;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 478;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 479;BA.debugLine="Dim i As UOEHTML";
_i = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 481;BA.debugLine="li.Initialize(sKey & \"li\",\"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 483;BA.debugLine="a.Initialize(iID,\"a\")";
_a._initialize(ba,_iid,"a");
 //BA.debugLineNum = 484;BA.debugLine="a.addattribute(\"data-target\",sKey & \"items\")";
_a._addattribute("data-target",_skey+"items");
 //BA.debugLineNum = 485;BA.debugLine="a.AddContent(iText)";
_a._addcontent(_itext);
 //BA.debugLineNum = 486;BA.debugLine="a.AddClass(\"dropdown-trigger\")";
_a._addclass("dropdown-trigger");
 //BA.debugLineNum = 488;BA.debugLine="i.Initialize(\"\",\"i\")";
_i._initialize(ba,"","i");
 //BA.debugLineNum = 489;BA.debugLine="i.AddClass(\"material-icons\")";
_i._addclass("material-icons");
 //BA.debugLineNum = 490;BA.debugLine="i.AddClass(\"right\")";
_i._addclass("right");
 //BA.debugLineNum = 491;BA.debugLine="i.AddContent(\"keyboard_arrow_right\")";
_i._addcontent("keyboard_arrow_right");
 //BA.debugLineNum = 492;BA.debugLine="a.AddElement(i)";
_a._addelement(_i);
 //BA.debugLineNum = 493;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 494;BA.debugLine="Dim items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 495;BA.debugLine="items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 496;BA.debugLine="items.clear";
_items.Clear();
 //BA.debugLineNum = 497;BA.debugLine="dropdowns.Put(sKey,items)";
_dropdowns.Put((Object)(_skey),(Object)(_items.getObject()));
 //BA.debugLineNum = 498;BA.debugLine="Select Case iLeftOrRight";
switch (BA.switchObjectToInt(_ileftorright,"left","right")) {
case 0: {
 //BA.debugLineNum = 500;BA.debugLine="LeftMenu.AddElementline(li)";
_leftmenu._addelementline(_li);
 break; }
case 1: {
 //BA.debugLineNum = 502;BA.debugLine="RightMenu.AddElementline(li)";
_rightmenu._addelementline(_li);
 break; }
}
;
 //BA.debugLineNum = 510;BA.debugLine="Dim mset As Map";
_mset = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 511;BA.debugLine="mset.Initialize";
_mset.Initialize();
 //BA.debugLineNum = 512;BA.debugLine="mset.clear";
_mset.Clear();
 //BA.debugLineNum = 513;BA.debugLine="mset.Put(\"id\", iID)";
_mset.Put((Object)("id"),(Object)(_iid));
 //BA.debugLineNum = 514;BA.debugLine="mset.Put(\"instance\", \"dropdown\")";
_mset.Put((Object)("instance"),(Object)("dropdown"));
 //BA.debugLineNum = 515;BA.debugLine="mset.Put(\"hover\", bHover)";
_mset.Put((Object)("hover"),(Object)(_bhover));
 //BA.debugLineNum = 516;BA.debugLine="mset.Put(\"closeOnClick\", closeOnClick)";
_mset.Put((Object)("closeOnClick"),(Object)(_closeonclick));
 //BA.debugLineNum = 517;BA.debugLine="mset.Put(\"coverTrigger\", bCoverTrigger)";
_mset.Put((Object)("coverTrigger"),(Object)(_bcovertrigger));
 //BA.debugLineNum = 518;BA.debugLine="mset.Put(\"constrainWidth\", constrainWidth)";
_mset.Put((Object)("constrainWidth"),(Object)(_constrainwidth));
 //BA.debugLineNum = 519;BA.debugLine="Dim sset As String = App.Map2Json(mset)";
_sset = _app._map2json(_mset);
 //BA.debugLineNum = 520;BA.debugLine="App.Components.add(sset)";
_app._components.Add((Object)(_sset));
 //BA.debugLineNum = 521;BA.debugLine="End Sub";
return "";
}
public String  _adddropdownavatar(String _itemid,String _imgurl,boolean _imgcircle,String _itemtext,String _itempos,String _itemvisibility,boolean _bconstrainwidth,String _itemtheme,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoedropdown _dp = null;
anywheresoftware.b4a.objects.collections.List _drpitems = null;
 //BA.debugLineNum = 306;BA.debugLine="Sub AddDropDownAvatar(itemID As String, imgURL As";
 //BA.debugLineNum = 307;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 308;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 310;BA.debugLine="Dim dp As UOEDropDown";
_dp = new b4j.Mashy.UOEBANano.uoedropdown();
 //BA.debugLineNum = 311;BA.debugLine="dp.Initialize(App,sKey,itemText,itemVisibility,Fa";
_dp._initialize(ba,_app,_skey,_itemtext,_itemvisibility,__c.False,_bconstrainwidth,_itemtheme);
 //BA.debugLineNum = 312;BA.debugLine="modUOE.MaterialAddImage(App,dp.a,imgURL,\"\",App.It";
_moduoe._materialaddimage(_app,_dp._a,_imgurl,"",_app._itemheight,_app._itemheight,_imgcircle,__c.True,__c.True,"5px");
 //BA.debugLineNum = 313;BA.debugLine="If itemPos.tolowercase = \"right\" Then";
if ((_itempos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 314;BA.debugLine="RightMenu.addcontentline(dp.tostring)";
_rightmenu._addcontentline(_dp._tostring());
 }else {
 //BA.debugLineNum = 316;BA.debugLine="LeftMenu.addcontentline(dp.tostring)";
_leftmenu._addcontentline(_dp._tostring());
 };
 //BA.debugLineNum = 319;BA.debugLine="Dim drpItems As List";
_drpitems = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 320;BA.debugLine="drpItems.Initialize";
_drpitems.Initialize();
 //BA.debugLineNum = 321;BA.debugLine="drpItems.clear";
_drpitems.Clear();
 //BA.debugLineNum = 322;BA.debugLine="dropdowns.Put(sKey,drpItems)";
_dropdowns.Put((Object)(_skey),(Object)(_drpitems.getObject()));
 //BA.debugLineNum = 323;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 324;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 326;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 328;BA.debugLine="End Sub";
return "";
}
public String  _adddropdowndivider(String _pid) throws Exception{
String _pkey = "";
b4j.Mashy.UOEBANano.uoehtml _md = null;
anywheresoftware.b4a.objects.collections.List _items = null;
String _scode = "";
 //BA.debugLineNum = 277;BA.debugLine="public Sub AddDropDownDivider(pID As String)";
 //BA.debugLineNum = 278;BA.debugLine="Dim pKey As String = $\"${ID}${pID}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_pid))+"");
 //BA.debugLineNum = 279;BA.debugLine="If dropdowns.ContainsKey(pKey) = False Then Retur";
if (_dropdowns.ContainsKey((Object)(_pkey))==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 280;BA.debugLine="Dim md As UOEHTML";
_md = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 281;BA.debugLine="md.Initialize(\"\",\"li\")";
_md._initialize(ba,"","li");
 //BA.debugLineNum = 282;BA.debugLine="md.AddClass(\"divider\")";
_md._addclass("divider");
 //BA.debugLineNum = 283;BA.debugLine="Dim items As List = dropdowns.Get(pKey)";
_items = new anywheresoftware.b4a.objects.collections.List();
_items.setObject((java.util.List)(_dropdowns.Get((Object)(_pkey))));
 //BA.debugLineNum = 284;BA.debugLine="Dim scode As String = md.tostring";
_scode = _md._tostring();
 //BA.debugLineNum = 285;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 286;BA.debugLine="items.Add(scode)";
_items.Add((Object)(_scode));
 //BA.debugLineNum = 287;BA.debugLine="dropdowns.Put(pKey,items)";
_dropdowns.Put((Object)(_pkey),(Object)(_items.getObject()));
 //BA.debugLineNum = 288;BA.debugLine="End Sub";
return "";
}
public String  _adddropdownitem(String _pid,String _iid,String _ihref,String _itext,String _ivisibility,String _itheme,boolean _hasevent) throws Exception{
String _pkey = "";
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _item = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
anywheresoftware.b4a.objects.collections.List _items = null;
String _scode = "";
 //BA.debugLineNum = 226;BA.debugLine="Sub AddDropDownItem(pID As String,iID As String,ih";
 //BA.debugLineNum = 227;BA.debugLine="If ihref = \"\" Then ihref = \"#!\"";
if ((_ihref).equals("")) { 
_ihref = "#!";};
 //BA.debugLineNum = 228;BA.debugLine="Dim pKey As String = $\"${ID}${pID}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_pid))+"");
 //BA.debugLineNum = 229;BA.debugLine="If dropdowns.ContainsKey(pKey) = False Then Retur";
if (_dropdowns.ContainsKey((Object)(_pkey))==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 230;BA.debugLine="Dim sKey As String = $\"${pKey}${iID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_pkey))+""+__c.SmartStringFormatter("",(Object)(_iid))+"");
 //BA.debugLineNum = 231;BA.debugLine="Dim item As UOEHTML";
_item = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 232;BA.debugLine="item.Initialize(sKey & \"li\",\"li\")";
_item._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 234;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 235;BA.debugLine="a.Initialize(iID,\"a\")";
_a._initialize(ba,_iid,"a");
 //BA.debugLineNum = 236;BA.debugLine="a.SetHREF(ihref)";
_a._sethref(_ihref);
 //BA.debugLineNum = 237;BA.debugLine="a.AddContent(iText)";
_a._addcontent(_itext);
 //BA.debugLineNum = 238;BA.debugLine="a.MaterialVisibility(iVisibility)";
_a._materialvisibility(_ivisibility);
 //BA.debugLineNum = 239;BA.debugLine="item.AddElement(a)";
_item._addelement(_a);
 //BA.debugLineNum = 240;BA.debugLine="Dim items As List = dropdowns.Get(pKey)";
_items = new anywheresoftware.b4a.objects.collections.List();
_items.setObject((java.util.List)(_dropdowns.Get((Object)(_pkey))));
 //BA.debugLineNum = 241;BA.debugLine="Dim scode As String = item.tostring";
_scode = _item._tostring();
 //BA.debugLineNum = 242;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 243;BA.debugLine="items.Add(scode)";
_items.Add((Object)(_scode));
 //BA.debugLineNum = 244;BA.debugLine="dropdowns.Put(pKey,items)";
_dropdowns.Put((Object)(_pkey),(Object)(_items.getObject()));
 //BA.debugLineNum = 245;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 246;BA.debugLine="App.AddEvent(iID, \"click\")";
_app._addevent(_iid,"click");
 }else {
 //BA.debugLineNum = 248;BA.debugLine="App.HeadersToFix.Put(iID,iID)";
_app._headerstofix.Put((Object)(_iid),(Object)(_iid));
 };
 //BA.debugLineNum = 250;BA.debugLine="End Sub";
return "";
}
public String  _adddropdownitem1(String _parentid,String _itemid,String _itemicon,String _itemtext,String _itemnavigateto,boolean _itemactive,boolean _bhasdivider,String _itemtheme,boolean _hasevent) throws Exception{
String _pkey = "";
b4j.Mashy.UOEBANano.uoedropdownitem _dpi = null;
anywheresoftware.b4a.objects.collections.List _items = null;
String _scode = "";
 //BA.debugLineNum = 253;BA.debugLine="Sub AddDropDownItem1(parentID As String, itemID As";
 //BA.debugLineNum = 254;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 255;BA.debugLine="parentID = parentID.tolowercase";
_parentid = _parentid.toLowerCase();
 //BA.debugLineNum = 256;BA.debugLine="If itemNavigateTo = \"\" Then itemNavigateTo = \"#!\"";
if ((_itemnavigateto).equals("")) { 
_itemnavigateto = "#!";};
 //BA.debugLineNum = 257;BA.debugLine="Dim pKey As String = $\"${ID}${parentID}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_parentid))+"");
 //BA.debugLineNum = 258;BA.debugLine="If dropdowns.ContainsKey(pKey) = False Then Retur";
if (_dropdowns.ContainsKey((Object)(_pkey))==__c.False) { 
if (true) return "";};
 //BA.debugLineNum = 259;BA.debugLine="itemIcon=\"\"";
_itemicon = "";
 //BA.debugLineNum = 260;BA.debugLine="Dim dpi As UOEDropDownItem";
_dpi = new b4j.Mashy.UOEBANano.uoedropdownitem();
 //BA.debugLineNum = 261;BA.debugLine="dpi.Initialize(App,pKey,itemID,itemIcon,itemText,";
_dpi._initialize(ba,_app,_pkey,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_itemtheme);
 //BA.debugLineNum = 262;BA.debugLine="dpi.li.MaterialAddDividerOnCondition(bhasDivider,";
_dpi._li._materialadddivideroncondition(_bhasdivider,_app._enumvisibility._visible,_itemtheme);
 //BA.debugLineNum = 264;BA.debugLine="Dim items As List = dropdowns.Get(pKey)";
_items = new anywheresoftware.b4a.objects.collections.List();
_items.setObject((java.util.List)(_dropdowns.Get((Object)(_pkey))));
 //BA.debugLineNum = 265;BA.debugLine="Dim scode As String = dpi.tostring";
_scode = _dpi._tostring();
 //BA.debugLineNum = 266;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 267;BA.debugLine="items.Add(scode)";
_items.Add((Object)(_scode));
 //BA.debugLineNum = 268;BA.debugLine="dropdowns.Put(pKey,items)";
_dropdowns.Put((Object)(_pkey),(Object)(_items.getObject()));
 //BA.debugLineNum = 269;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 270;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 272;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 274;BA.debugLine="End Sub";
return "";
}
public String  _addfab(String _sid,String _iconname,String _bsize,String _href,boolean _bpulse,String _bvisibility,String _btheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoebutton _btn = null;
 //BA.debugLineNum = 100;BA.debugLine="Sub AddFAB(sid As String,iconName As String, bSize";
 //BA.debugLineNum = 101;BA.debugLine="sid = sid.tolowercase";
_sid = _sid.toLowerCase();
 //BA.debugLineNum = 102;BA.debugLine="Dim btn As UOEButton";
_btn = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 103;BA.debugLine="btn.Initialize(App, sid,\"\",btheme)";
_btn._initialize(ba,_app,_sid,"",_btheme);
 //BA.debugLineNum = 104;BA.debugLine="btn.setbuttontype(App.EnumButtonType.halfwayfab)";
_btn._setbuttontype(_app._enumbuttontype._halfwayfab);
 //BA.debugLineNum = 105;BA.debugLine="btn.AddIcon(iconName,\"\",\"\",False,False)";
_btn._addicon(_iconname,"","",__c.False,__c.False);
 //BA.debugLineNum = 106;BA.debugLine="btn.Size = bSize";
_btn._size = _bsize;
 //BA.debugLineNum = 107;BA.debugLine="btn.HREF = href";
_btn._href = _href;
 //BA.debugLineNum = 108;BA.debugLine="btn.Visibility = bVisibility";
_btn._visibility = _bvisibility;
 //BA.debugLineNum = 109;BA.debugLine="btn.Pulsing = bPulse";
_btn._pulsing = _bpulse;
 //BA.debugLineNum = 111;BA.debugLine="Content.AddContent(btn.tostring)";
_content._addcontent(_btn._tostring());
 //BA.debugLineNum = 112;BA.debugLine="hasContents = True";
_hascontents = __c.True;
 //BA.debugLineNum = 113;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 114;BA.debugLine="App.AddEvent(sid, \"click\")";
_app._addevent(_sid,"click");
 }else {
 //BA.debugLineNum = 116;BA.debugLine="App.HeadersToFix.Put(sid,sid)";
_app._headerstofix.Put((Object)(_sid),(Object)(_sid));
 };
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}
public String  _addicon(String _itemid,String _iconname,String _itemnavigateto,boolean _itemactive,String _itempos,String _itemvisibility,String _itemtheme,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 356;BA.debugLine="Sub AddIcon(itemID As String, iconName As String,";
 //BA.debugLineNum = 358;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 359;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 360;BA.debugLine="li.Initialize(sKey & \"li\",\"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 361;BA.debugLine="li.MaterialVisibility(itemVisibility)";
_li._materialvisibility(_itemvisibility);
 //BA.debugLineNum = 362;BA.debugLine="If itemActive = True Then li.AddClass(\"active\")";
if (_itemactive==__c.True) { 
_li._addclass("active");};
 //BA.debugLineNum = 364;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 365;BA.debugLine="ai.Initialize(App,itemID,iconName,\"\",False,\"\",ite";
_ai._initialize(ba,_app,_itemid,_iconname,"",__c.False,"",_itemnavigateto,__c.False,_itemtheme,"");
 //BA.debugLineNum = 366;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 367;BA.debugLine="If itemPos.tolowercase = \"right\" Then";
if ((_itempos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 368;BA.debugLine="RightMenu.addcontentline(li.HTML)";
_rightmenu._addcontentline(_li._html());
 }else {
 //BA.debugLineNum = 370;BA.debugLine="LeftMenu.addcontentline(li.HTML)";
_leftmenu._addcontentline(_li._html());
 };
 //BA.debugLineNum = 372;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 373;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 375;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 377;BA.debugLine="End Sub";
return "";
}
public String  _addiconbadge(String _itemid,String _iconname,String _itemnavigateto,boolean _itemactive,String _itempos,String _itemvisibility,String _itemtheme,String _sbadge,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 380;BA.debugLine="Sub AddIconBadge(itemID As String, iconName As Str";
 //BA.debugLineNum = 382;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 383;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 384;BA.debugLine="li.Initialize(sKey & \"li\",\"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 385;BA.debugLine="li.MaterialVisibility(itemVisibility)";
_li._materialvisibility(_itemvisibility);
 //BA.debugLineNum = 386;BA.debugLine="If itemActive = True Then";
if (_itemactive==__c.True) { 
 //BA.debugLineNum = 387;BA.debugLine="li.AddClass(\"active\")";
_li._addclass("active");
 };
 //BA.debugLineNum = 390;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 391;BA.debugLine="ai.Initialize(App,itemID,iconName,\"\",False,\"\",ite";
_ai._initialize(ba,_app,_itemid,_iconname,"",__c.False,"",_itemnavigateto,__c.False,_itemtheme,"");
 //BA.debugLineNum = 392;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,sBadge,False,App";
_moduoe._materialaddbadge(_app,_ai._a,_sbadge,__c.False,_app._enumvisibility._visible,__c.False,"",__c.True);
 //BA.debugLineNum = 393;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 394;BA.debugLine="If itemPos.tolowercase = \"right\" Then";
if ((_itempos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 395;BA.debugLine="RightMenu.addcontentline(li.HTML)";
_rightmenu._addcontentline(_li._html());
 }else {
 //BA.debugLineNum = 397;BA.debugLine="LeftMenu.addcontentline(li.HTML)";
_leftmenu._addcontentline(_li._html());
 };
 //BA.debugLineNum = 399;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 400;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 402;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 404;BA.debugLine="End Sub";
return "";
}
public String  _addimagel(String _itemid,String _imgurl,boolean _imgcircle,String _imgheight,String _imgwidth,String _topmargin,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _md = null;
 //BA.debugLineNum = 291;BA.debugLine="Sub AddImageL(itemID As String, imgURL As String,";
 //BA.debugLineNum = 292;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 293;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 294;BA.debugLine="Dim md As UOEHTML";
_md = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 295;BA.debugLine="md.Initialize(sKey,\"li\")";
_md._initialize(ba,_skey,"li");
 //BA.debugLineNum = 296;BA.debugLine="modUOE.MaterialAddImage(App,md,imgURL,\"\",imgHeigh";
_moduoe._materialaddimage(_app,_md,_imgurl,"",_imgheight,_imgwidth,_imgcircle,__c.True,__c.True,_topmargin);
 //BA.debugLineNum = 297;BA.debugLine="LeftMenu.addcontentline(md.HTML)";
_leftmenu._addcontentline(_md._html());
 //BA.debugLineNum = 298;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 299;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 301;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 303;BA.debugLine="End Sub";
return "";
}
public String  _additem(String _iid,String _ihref,String _itext,String _ivisibility,String _ileftorright,boolean _bactive,String _itheme,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _item = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 200;BA.debugLine="Sub AddItem(iID As String,ihref As String,iText As";
 //BA.debugLineNum = 201;BA.debugLine="Dim sKey As String = $\"${ID}${iID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_iid))+"");
 //BA.debugLineNum = 202;BA.debugLine="Dim item As UOEHTML";
_item = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 203;BA.debugLine="item.Initialize(sKey & \"li\",\"li\")";
_item._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 204;BA.debugLine="item.AddClassOnCondition(bActive,\"active\")";
_item._addclassoncondition(_bactive,"active");
 //BA.debugLineNum = 206;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 207;BA.debugLine="a.Initialize(iID,\"a\")";
_a._initialize(ba,_iid,"a");
 //BA.debugLineNum = 208;BA.debugLine="a.SetHREF(ihref)";
_a._sethref(_ihref);
 //BA.debugLineNum = 209;BA.debugLine="a.AddContent(iText)";
_a._addcontent(_itext);
 //BA.debugLineNum = 210;BA.debugLine="a.MaterialVisibility(iVisibility)";
_a._materialvisibility(_ivisibility);
 //BA.debugLineNum = 211;BA.debugLine="item.AddElement(a)";
_item._addelement(_a);
 //BA.debugLineNum = 212;BA.debugLine="Select Case iLeftOrRight";
switch (BA.switchObjectToInt(_ileftorright,"left","right")) {
case 0: {
 //BA.debugLineNum = 214;BA.debugLine="LeftMenu.AddElementLine(item)";
_leftmenu._addelementline(_item);
 break; }
case 1: {
 //BA.debugLineNum = 216;BA.debugLine="RightMenu.AddElementLine(item)";
_rightmenu._addelementline(_item);
 break; }
}
;
 //BA.debugLineNum = 218;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 219;BA.debugLine="App.AddEvent(iID, \"click\")";
_app._addevent(_iid,"click");
 }else {
 //BA.debugLineNum = 221;BA.debugLine="App.HeadersToFix.Put(iID,iID)";
_app._headerstofix.Put((Object)(_iid),(Object)(_iid));
 };
 //BA.debugLineNum = 223;BA.debugLine="End Sub";
return "";
}
public String  _additembadge(String _itemid,String _iconname,String _iconalign,String _itemtext,String _href,boolean _textvisible,boolean _itemactive,String _badgetext,boolean _badgenew,String _itemvisibility,String _itempos,String _itemtheme,String _badgetheme,boolean _hasevent) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
 //BA.debugLineNum = 331;BA.debugLine="Sub AddItemBadge(itemID As String, iconName As Str";
 //BA.debugLineNum = 332;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 333;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 334;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 335;BA.debugLine="li.Initialize(sKey & \"li\",\"li\")";
_li._initialize(ba,_skey+"li","li");
 //BA.debugLineNum = 336;BA.debugLine="li.MaterialVisibility(itemVisibility)";
_li._materialvisibility(_itemvisibility);
 //BA.debugLineNum = 337;BA.debugLine="If itemActive = True Then li.AddClass(\"active\")";
if (_itemactive==__c.True) { 
_li._addclass("active");};
 //BA.debugLineNum = 339;BA.debugLine="Dim ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 340;BA.debugLine="ai.Initialize(App,itemID,iconName,iconAlign,False";
_ai._initialize(ba,_app,_itemid,_iconname,_iconalign,__c.False,_itemtext,_href,_textvisible,_itemtheme,"");
 //BA.debugLineNum = 341;BA.debugLine="modUOE.MaterialAddBadge(App,ai.a,badgeText,badgeN";
_moduoe._materialaddbadge(_app,_ai._a,_badgetext,_badgenew,_app._enumvisibility._visible,__c.True,_badgetheme,__c.False);
 //BA.debugLineNum = 342;BA.debugLine="li.AddContent(ai.tostring)";
_li._addcontent(_ai._tostring());
 //BA.debugLineNum = 343;BA.debugLine="If itemPos.tolowercase = \"right\" Then";
if ((_itempos.toLowerCase()).equals("right")) { 
 //BA.debugLineNum = 344;BA.debugLine="RightMenu.addcontentline(li.HTML)";
_rightmenu._addcontentline(_li._html());
 }else {
 //BA.debugLineNum = 346;BA.debugLine="LeftMenu.addcontentline(li.HTML)";
_leftmenu._addcontentline(_li._html());
 };
 //BA.debugLineNum = 348;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 349;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 351;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 353;BA.debugLine="End Sub";
return "";
}
public String  _additemleft(String _iid,String _href,String _itext,String _itheme,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 190;BA.debugLine="Sub AddItemLeft(iID As String, href As String,iTex";
 //BA.debugLineNum = 191;BA.debugLine="AddItem(iID,href,iText,\"\",App.EnumMenuPos.Left,Fa";
_additem(_iid,_href,_itext,"",_app._enummenupos._left,__c.False,_itheme,_hasevent);
 //BA.debugLineNum = 192;BA.debugLine="End Sub";
return "";
}
public String  _additemright(String _iid,String _href,String _itext,String _itheme,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 195;BA.debugLine="Sub AddItemRight(iID As String, href As String,iTe";
 //BA.debugLineNum = 196;BA.debugLine="AddItem(iID,href,iText,\"\",App.EnumMenuPos.Right,F";
_additem(_iid,_href,_itext,"",_app._enummenupos._right,__c.False,_itheme,_hasevent);
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public String  _addsubtitle(String _stitle) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _el = null;
 //BA.debugLineNum = 91;BA.debugLine="Sub AddSubTitle(sTitle As String)";
 //BA.debugLineNum = 92;BA.debugLine="Dim el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 93;BA.debugLine="el.Initialize(ID & \"-title\",\"span\")";
_el._initialize(ba,_id+"-title","span");
 //BA.debugLineNum = 94;BA.debugLine="el.AddContent(sTitle)";
_el._addcontent(_stitle);
 //BA.debugLineNum = 95;BA.debugLine="el.AddClass(\"nav-title\")";
_el._addclass("nav-title");
 //BA.debugLineNum = 96;BA.debugLine="Content.AddContent(el.HTML)";
_content._addcontent(_el._html());
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public String  _addtab(String _tabid,String _tabtext,boolean _tabdisabled,b4j.Mashy.UOEBANano.uoecontainer _tabcont) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
b4j.Mashy.UOEBANano.uoehtml _dv = null;
 //BA.debugLineNum = 29;BA.debugLine="Sub AddTab(tabID As String, tabText As String, tab";
 //BA.debugLineNum = 30;BA.debugLine="hasTabs = True";
_hastabs = __c.True;
 //BA.debugLineNum = 31;BA.debugLine="hasContents = True";
_hascontents = __c.True;
 //BA.debugLineNum = 32;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 33;BA.debugLine="li.Initialize(tabID & \"li\",\"li\")";
_li._initialize(ba,_tabid+"li","li");
 //BA.debugLineNum = 34;BA.debugLine="li.AddClass(\"tab\")";
_li._addclass("tab");
 //BA.debugLineNum = 35;BA.debugLine="li.AddClassOnCondition(tabDisabled,\"disabled\")";
_li._addclassoncondition(_tabdisabled,"disabled");
 //BA.debugLineNum = 36;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 37;BA.debugLine="a.Initialize(tabID,\"a\")";
_a._initialize(ba,_tabid,"a");
 //BA.debugLineNum = 38;BA.debugLine="a.sethref(\"#\" & tabID & \"dv\")";
_a._sethref("#"+_tabid+"dv");
 //BA.debugLineNum = 39;BA.debugLine="a.AddContent(tabText)";
_a._addcontent(_tabtext);
 //BA.debugLineNum = 40;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 42;BA.debugLine="tabs.AddElement(li)";
_tabs._addelement(_li);
 //BA.debugLineNum = 45;BA.debugLine="Dim dv As UOEHTML";
_dv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 46;BA.debugLine="dv.Initialize(tabID & \"dv\",\"div\")";
_dv._initialize(ba,_tabid+"dv","div");
 //BA.debugLineNum = 47;BA.debugLine="If tabCont <> Null Then";
if (_tabcont!= null) { 
 //BA.debugLineNum = 48;BA.debugLine="dv.AddContent(tabCont.tostring)";
_dv._addcontent(_tabcont._tostring());
 };
 //BA.debugLineNum = 51;BA.debugLine="Content.AddContent(dv.html)";
_content._addcontent(_dv._html());
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public String  _builddropdownstructures() throws Exception{
String _strkey = "";
String _ditems = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
anywheresoftware.b4a.objects.collections.List _items = null;
 //BA.debugLineNum = 177;BA.debugLine="private Sub BuildDropDownStructures";
 //BA.debugLineNum = 178;BA.debugLine="For Each strKey As String In dropdowns.Keys";
{
final anywheresoftware.b4a.BA.IterableList group1 = _dropdowns.Keys();
final int groupLen1 = group1.getSize()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_strkey = BA.ObjectToString(group1.Get(index1));
 //BA.debugLineNum = 179;BA.debugLine="Dim ditems As String = strKey & \"items\"";
_ditems = _strkey+"items";
 //BA.debugLineNum = 180;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 181;BA.debugLine="li.Initialize(ditems,\"ul\")";
_li._initialize(ba,_ditems,"ul");
 //BA.debugLineNum = 182;BA.debugLine="li.AddClass(\"dropdown-content\")";
_li._addclass("dropdown-content");
 //BA.debugLineNum = 183;BA.debugLine="Dim items As List = dropdowns.Get(strKey)";
_items = new anywheresoftware.b4a.objects.collections.List();
_items.setObject((java.util.List)(_dropdowns.Get((Object)(_strkey))));
 //BA.debugLineNum = 184;BA.debugLine="li.AddContentList(items)";
_li._addcontentlist(_items);
 //BA.debugLineNum = 185;BA.debugLine="Element.addcontent(li.HTML)";
_element._addcontent(_li._html());
 }
};
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Private nw As UOEHTML";
_nw = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Private logo As UOEHTML";
_logo = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Private LeftMenu As UOEHTML";
_leftmenu = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Private RightMenu As UOEHTML";
_rightmenu = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 14;BA.debugLine="Public LeftMenuVisibility As String";
_leftmenuvisibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Public RightMenuVisibility As String";
_rightmenuvisibility = "";
 //BA.debugLineNum = 16;BA.debugLine="Public LogoPosition As String";
_logoposition = "";
 //BA.debugLineNum = 17;BA.debugLine="Private pcol As UOEHTML";
_pcol = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 18;BA.debugLine="Public Fixed As Boolean";
_fixed = false;
 //BA.debugLineNum = 19;BA.debugLine="Private dropdowns As Map";
_dropdowns = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 20;BA.debugLine="Public Content As UOEContainer";
_content = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 21;BA.debugLine="Private hasContents As Boolean";
_hascontents = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Drawer As UOESideBar";
_drawer = new b4j.Mashy.UOEBANano.uoesidebar();
 //BA.debugLineNum = 23;BA.debugLine="Public ShowMenuOnLarge As Boolean";
_showmenuonlarge = false;
 //BA.debugLineNum = 24;BA.debugLine="Public hasTabs As Boolean";
_hastabs = false;
 //BA.debugLineNum = 25;BA.debugLine="Private tabs As UOEHTML";
_tabs = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,String _stitleposition,boolean _bfixed,boolean _bfixdrawer,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 55;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sID As Str";
 //BA.debugLineNum = 56;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 57;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 58;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 59;BA.debugLine="Element.Initialize(ID,\"nav\")";
_element._initialize(ba,_id,"nav");
 //BA.debugLineNum = 60;BA.debugLine="Element.SetROLE(\"navigation\")";
_element._setrole("navigation");
 //BA.debugLineNum = 61;BA.debugLine="nw.Initialize(\"navwrapper\",\"div\")";
_nw._initialize(ba,"navwrapper","div");
 //BA.debugLineNum = 62;BA.debugLine="nw.AddClass(\"nav-wrapper\")";
_nw._addclass("nav-wrapper");
 //BA.debugLineNum = 63;BA.debugLine="logo.Initialize(\"brandlogo\",\"a\")";
_logo._initialize(ba,"brandlogo","a");
 //BA.debugLineNum = 64;BA.debugLine="logo.AddClass(\"brand-logo\")";
_logo._addclass("brand-logo");
 //BA.debugLineNum = 65;BA.debugLine="logo.AddContent(sTitle)";
_logo._addcontent(_stitle);
 //BA.debugLineNum = 66;BA.debugLine="logo.MaterialVisibility(App.EnumVisibility.showon";
_logo._materialvisibility(_app._enumvisibility._showonmediumandup);
 //BA.debugLineNum = 67;BA.debugLine="LeftMenu.Initialize(ID & \"-leftmenu\",\"ul\")";
_leftmenu._initialize(ba,_id+"-leftmenu","ul");
 //BA.debugLineNum = 68;BA.debugLine="RightMenu.Initialize(ID & \"-rightmenu\",\"ul\")";
_rightmenu._initialize(ba,_id+"-rightmenu","ul");
 //BA.debugLineNum = 69;BA.debugLine="RightMenu.AddClass(\"right\")";
_rightmenu._addclass("right");
 //BA.debugLineNum = 70;BA.debugLine="pcol.Initialize(ID & \"-pcol\",\"div\")";
_pcol._initialize(ba,_id+"-pcol","div");
 //BA.debugLineNum = 71;BA.debugLine="pcol.AddClass(\"col\")";
_pcol._addclass("col");
 //BA.debugLineNum = 72;BA.debugLine="pcol.AddClass(\"s12\")";
_pcol._addclass("s12");
 //BA.debugLineNum = 73;BA.debugLine="LogoPosition = sTitlePosition";
_logoposition = _stitleposition;
 //BA.debugLineNum = 74;BA.debugLine="LeftMenuVisibility = App.EnumVisibility.hideonmed";
_leftmenuvisibility = _app._enumvisibility._hideonmedanddown;
 //BA.debugLineNum = 75;BA.debugLine="RightMenuVisibility = App.EnumVisibility.hideonme";
_rightmenuvisibility = _app._enumvisibility._hideonmedanddown;
 //BA.debugLineNum = 76;BA.debugLine="Fixed = bFixed";
_fixed = _bfixed;
 //BA.debugLineNum = 77;BA.debugLine="dropdowns.Initialize";
_dropdowns.Initialize();
 //BA.debugLineNum = 78;BA.debugLine="dropdowns.clear";
_dropdowns.Clear();
 //BA.debugLineNum = 79;BA.debugLine="Content.Initialize(App,ID & \"-navcontent\",False,\"";
_content._initialize(ba,_app,_id+"-navcontent",__c.False,"");
 //BA.debugLineNum = 80;BA.debugLine="Content.AddClass(\"nav-content\")";
_content._addclass("nav-content");
 //BA.debugLineNum = 81;BA.debugLine="hasContents = False";
_hascontents = __c.False;
 //BA.debugLineNum = 82;BA.debugLine="hasTabs = False";
_hastabs = __c.False;
 //BA.debugLineNum = 83;BA.debugLine="Drawer.Initialize(App,ID & \"-drawer\",bFixDrawer,F";
_drawer._initialize(ba,_app,_id+"-drawer",_bfixdrawer,__c.False,"");
 //BA.debugLineNum = 84;BA.debugLine="ShowMenuOnLarge = Not(bFixDrawer)";
_showmenuonlarge = __c.Not(_bfixdrawer);
 //BA.debugLineNum = 85;BA.debugLine="tabs.Initialize(ID & \"-navtabs\", \"ul\")";
_tabs._initialize(ba,_id+"-navtabs","ul");
 //BA.debugLineNum = 86;BA.debugLine="tabs.AddClass(\"tabs\")";
_tabs._addclass("tabs");
 //BA.debugLineNum = 87;BA.debugLine="tabs.AddClass(\"tabs-transparent\")";
_tabs._addclass("tabs-transparent");
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public String  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 550;BA.debugLine="Sub RemoveAttribute(attr As String)";
 //BA.debugLineNum = 551;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 552;BA.debugLine="End Sub";
return "";
}
public String  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 540;BA.debugLine="Sub RemoveClass(sClass As String)";
 //BA.debugLineNum = 541;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 542;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _menu = null;
b4j.Mashy.UOEBANano.uoehtml _i = null;
b4j.Mashy.UOEBANano.uoehtml _df = null;
 //BA.debugLineNum = 555;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 556;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 557;BA.debugLine="BuildDropDownStructures";
_builddropdownstructures();
 //BA.debugLineNum = 558;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 559;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 560;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 562;BA.debugLine="logo.AddClass(LogoPosition)";
_logo._addclass(_logoposition);
 //BA.debugLineNum = 564;BA.debugLine="nw.AddElement(logo)";
_nw._addelement(_logo);
 //BA.debugLineNum = 566;BA.debugLine="Dim menu As UOEHTML";
_menu = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 567;BA.debugLine="menu.Initialize(\"navmenu\",\"a\")";
_menu._initialize(ba,"navmenu","a");
 //BA.debugLineNum = 568;BA.debugLine="menu.SetHREF(\"#\")";
_menu._sethref("#");
 //BA.debugLineNum = 569;BA.debugLine="menu.addattribute(\"data-target\",ID & \"-drawer\")";
_menu._addattribute("data-target",_id+"-drawer");
 //BA.debugLineNum = 570;BA.debugLine="menu.AddClassOnCondition(ShowMenuOnLarge,\"show-on";
_menu._addclassoncondition(_showmenuonlarge,"show-on-large");
 //BA.debugLineNum = 571;BA.debugLine="menu.AddClass(\"sidenav-trigger\")";
_menu._addclass("sidenav-trigger");
 //BA.debugLineNum = 573;BA.debugLine="Dim i As UOEHTML";
_i = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 574;BA.debugLine="i.Initialize(\"\",\"i\")";
_i._initialize(ba,"","i");
 //BA.debugLineNum = 575;BA.debugLine="i.AddClass(\"material-icons\")";
_i._addclass("material-icons");
 //BA.debugLineNum = 576;BA.debugLine="i.AddContent(\"menu\")";
_i._addcontent("menu");
 //BA.debugLineNum = 577;BA.debugLine="menu.AddElement(i)";
_menu._addelement(_i);
 //BA.debugLineNum = 579;BA.debugLine="nw.AddElement(menu)";
_nw._addelement(_menu);
 //BA.debugLineNum = 580;BA.debugLine="LeftMenu.MaterialVisibility(LeftMenuVisibility)";
_leftmenu._materialvisibility(_leftmenuvisibility);
 //BA.debugLineNum = 581;BA.debugLine="RightMenu.MaterialVisibility(RightMenuVisibility)";
_rightmenu._materialvisibility(_rightmenuvisibility);
 //BA.debugLineNum = 583;BA.debugLine="nw.AddElement(LeftMenu)";
_nw._addelement(_leftmenu);
 //BA.debugLineNum = 584;BA.debugLine="nw.AddElement(RightMenu)";
_nw._addelement(_rightmenu);
 //BA.debugLineNum = 587;BA.debugLine="Element.AddClassOnCondition(hasContents,\"nav-exte";
_element._addclassoncondition(_hascontents,"nav-extended");
 //BA.debugLineNum = 588;BA.debugLine="pcol.AddElement(nw)";
_pcol._addelement(_nw);
 //BA.debugLineNum = 589;BA.debugLine="If hasContents Then";
if (_hascontents) { 
 //BA.debugLineNum = 590;BA.debugLine="pcol.AddContent(Content.tostring)";
_pcol._addcontent(_content._tostring());
 };
 //BA.debugLineNum = 592;BA.debugLine="Element.AddElement(pcol)";
_element._addelement(_pcol);
 //BA.debugLineNum = 593;BA.debugLine="If Fixed Then";
if (_fixed) { 
 //BA.debugLineNum = 594;BA.debugLine="Dim df As UOEHTML";
_df = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 595;BA.debugLine="df.Initialize(ID & \"-fixed\",\"div\")";
_df._initialize(ba,_id+"-fixed","div");
 //BA.debugLineNum = 596;BA.debugLine="df.AddClass(\"navbar-fixed\")";
_df._addclass("navbar-fixed");
 //BA.debugLineNum = 597;BA.debugLine="df.AddElement(Element)";
_df._addelement(_element);
 //BA.debugLineNum = 604;BA.debugLine="Return df.html";
if (true) return _df._html();
 }else {
 //BA.debugLineNum = 612;BA.debugLine="Return Element.html";
if (true) return _element._html();
 };
 //BA.debugLineNum = 614;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
