package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetabs extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetabs", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetabs.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _visibility = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _el = null;
public boolean _hoverable = false;
public anywheresoftware.b4a.objects.collections.List _tabs = null;
public String _zdepth = "";
public b4j.Mashy.UOEBANano.uoehtml _pdiv = null;
public String _instance = "";
public boolean _swipeable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoetabs  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 179;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 180;BA.debugLine="el.AddAttribute(attr,value)";
_el._addattribute(_attr,_value);
 //BA.debugLineNum = 181;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetabs)(this);
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetabs  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 167;BA.debugLine="Sub AddClass(sClass As String) As UOETabs";
 //BA.debugLineNum = 168;BA.debugLine="el.AddClass(sClass)";
_el._addclass(_sclass);
 //BA.debugLineNum = 169;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetabs)(this);
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetabs  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 22;BA.debugLine="el.AddStyleAttribute(attribute,value)";
_el._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetabs)(this);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public String  _addtab(String _tabid,String _tabtitle,boolean _tabactive,boolean _tabdisabled,int _sizesmall,int _sizemedium,int _sizelarge,b4j.Mashy.UOEBANano.uoecontainer _cont,boolean _hasevent) throws Exception{
String _skey = "";
String _tabkey = "";
String _tabkeya = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
b4j.Mashy.UOEBANano.uoehtml _tabdiv = null;
 //BA.debugLineNum = 64;BA.debugLine="Sub AddTab(TabID As String,tabTitle As String,tabA";
 //BA.debugLineNum = 65;BA.debugLine="Dim sKey As String = $\"${ID}${TabID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"");
 //BA.debugLineNum = 66;BA.debugLine="Dim tabKey As String = $\"tab${ID}${TabID}\"$";
_tabkey = ("tab"+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"");
 //BA.debugLineNum = 67;BA.debugLine="Dim tabKeyA As String = $\"tab${ID}${TabID}a\"$";
_tabkeya = ("tab"+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"a");
 //BA.debugLineNum = 68;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 69;BA.debugLine="li.Initialize(sKey,\"li\")";
_li._initialize(ba,_skey,"li");
 //BA.debugLineNum = 70;BA.debugLine="li.AddClass(\"tab\")";
_li._addclass("tab");
 //BA.debugLineNum = 71;BA.debugLine="li.AddClass(\"col\").AddClass(\"s\" & SizeSmall).AddC";
_li._addclass("col")._addclass("s"+BA.NumberToString(_sizesmall))._addclass("m"+BA.NumberToString(_sizemedium))._addclass("l"+BA.NumberToString(_sizelarge));
 //BA.debugLineNum = 72;BA.debugLine="li.AddClassOnCondition(tabDisabled,\"disabled\")";
_li._addclassoncondition(_tabdisabled,"disabled");
 //BA.debugLineNum = 73;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 74;BA.debugLine="a.Initialize(tabKeyA,\"a\")";
_a._initialize(ba,_tabkeya,"a");
 //BA.debugLineNum = 75;BA.debugLine="a.SetHREF(\"#\" & tabKey)";
_a._sethref("#"+_tabkey);
 //BA.debugLineNum = 76;BA.debugLine="a.AddContent(tabTitle)";
_a._addcontent(_tabtitle);
 //BA.debugLineNum = 77;BA.debugLine="a.AddClassOnCondition(tabActive,\"active\")";
_a._addclassoncondition(_tabactive,"active");
 //BA.debugLineNum = 78;BA.debugLine="App.MaterialUseTheme(Theme,a)";
_app._materialusetheme(_theme,_a);
 //BA.debugLineNum = 79;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 80;BA.debugLine="el.AddElement(li)";
_el._addelement(_li);
 //BA.debugLineNum = 82;BA.debugLine="Dim tabdiv As UOEHTML";
_tabdiv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 83;BA.debugLine="tabdiv.Initialize(tabKey,\"div\")";
_tabdiv._initialize(ba,_tabkey,"div");
 //BA.debugLineNum = 84;BA.debugLine="tabdiv.AddClass(\"col\").AddClass(\"s12\")";
_tabdiv._addclass("col")._addclass("s12");
 //BA.debugLineNum = 85;BA.debugLine="If cont <> Null Then";
if (_cont!= null) { 
 //BA.debugLineNum = 86;BA.debugLine="tabdiv.AddContent(cont.tostring)";
_tabdiv._addcontent(_cont._tostring());
 };
 //BA.debugLineNum = 88;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 89;BA.debugLine="App.AddEvent(tabKeyA,\"click\")";
_app._addevent(_tabkeya,"click");
 };
 //BA.debugLineNum = 91;BA.debugLine="tabs.Add(tabdiv.html)";
_tabs.Add((Object)(_tabdiv._html()));
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _addtabexternal(String _tabid,String _tabtitle,boolean _tabactive,boolean _tabdisabled,int _sizesmall,int _sizemedium,int _sizelarge,String _url,String _target,boolean _hasevent) throws Exception{
String _skey = "";
String _tabkeya = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 95;BA.debugLine="Sub AddTabExternal(TabID As String,tabTitle As Str";
 //BA.debugLineNum = 96;BA.debugLine="Dim sKey As String = $\"${ID}${TabID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"");
 //BA.debugLineNum = 97;BA.debugLine="Dim tabKeyA As String = $\"tab${ID}${TabID}a\"$";
_tabkeya = ("tab"+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"a");
 //BA.debugLineNum = 99;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 100;BA.debugLine="li.Initialize(sKey,\"li\")";
_li._initialize(ba,_skey,"li");
 //BA.debugLineNum = 101;BA.debugLine="li.AddClass(\"tab\")";
_li._addclass("tab");
 //BA.debugLineNum = 102;BA.debugLine="li.AddClass(\"col\")";
_li._addclass("col");
 //BA.debugLineNum = 103;BA.debugLine="li.AddClass(\"s\" & SizeSmall)";
_li._addclass("s"+BA.NumberToString(_sizesmall));
 //BA.debugLineNum = 104;BA.debugLine="li.AddClass(\"m\" & SizeMedium)";
_li._addclass("m"+BA.NumberToString(_sizemedium));
 //BA.debugLineNum = 105;BA.debugLine="li.AddClass(\"l\" & SizeLarge)";
_li._addclass("l"+BA.NumberToString(_sizelarge));
 //BA.debugLineNum = 106;BA.debugLine="li.AddClassOnCondition(tabDisabled,\"disabled\")";
_li._addclassoncondition(_tabdisabled,"disabled");
 //BA.debugLineNum = 107;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 108;BA.debugLine="a.Initialize(tabKeyA,\"a\")";
_a._initialize(ba,_tabkeya,"a");
 //BA.debugLineNum = 109;BA.debugLine="a.SetHREF(URL).AddContent(tabTitle)";
_a._sethref(_url)._addcontent(_tabtitle);
 //BA.debugLineNum = 110;BA.debugLine="a.AddClassOnCondition(tabActive,\"active\")";
_a._addclassoncondition(_tabactive,"active");
 //BA.debugLineNum = 111;BA.debugLine="App.MaterialUseTheme(Theme,a)";
_app._materialusetheme(_theme,_a);
 //BA.debugLineNum = 112;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 113;BA.debugLine="el.AddElement(li)";
_el._addelement(_li);
 //BA.debugLineNum = 114;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 115;BA.debugLine="App.AddEvent(tabKeyA,\"click\")";
_app._addevent(_tabkeya,"click");
 };
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Private el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 12;BA.debugLine="Private tabs As List";
_tabs = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Private pdiv As UOEHTML";
_pdiv = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 15;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 16;BA.debugLine="Public swipeable As Boolean";
_swipeable = false;
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _dpsettings = null;
String _strds = "";
 //BA.debugLineNum = 129;BA.debugLine="public Sub GetSettings As String";
 //BA.debugLineNum = 130;BA.debugLine="Dim dpSettings As Map";
_dpsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 131;BA.debugLine="dpSettings.Initialize";
_dpsettings.Initialize();
 //BA.debugLineNum = 132;BA.debugLine="dpSettings.clear";
_dpsettings.Clear();
 //BA.debugLineNum = 133;BA.debugLine="dpSettings.Put(\"id\", ID)";
_dpsettings.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 134;BA.debugLine="dpSettings.Put(\"instance\", \"tabs\")";
_dpsettings.Put((Object)("instance"),(Object)("tabs"));
 //BA.debugLineNum = 135;BA.debugLine="dpSettings.Put(\"swipeable\", swipeable)";
_dpsettings.Put((Object)("swipeable"),(Object)(_swipeable));
 //BA.debugLineNum = 136;BA.debugLine="Dim strDS As String = App.Map2JSON(dpSettings)";
_strds = _app._map2json(_dpsettings);
 //BA.debugLineNum = 137;BA.debugLine="Return strDS";
if (true) return _strds;
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public String  _gettabid(String _stabid) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub GetTabID(stabid As String) As String";
 //BA.debugLineNum = 59;BA.debugLine="Return $\"tab${ID}${stabid}a\"$";
if (true) return ("tab"+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_stabid))+"a");
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,boolean _fixedwidth,String _themename,String _cclass) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 27;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 28;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 29;BA.debugLine="ID = sID.ToLowerCase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 30;BA.debugLine="el.Initialize(ID,\"ul\")";
_el._initialize(ba,_id,"ul");
 //BA.debugLineNum = 31;BA.debugLine="el.AddClass(\"tabs\")";
_el._addclass("tabs");
 //BA.debugLineNum = 32;BA.debugLine="el.AddClassOnCondition(fixedWidth,\"tabs-fixed-wid";
_el._addclassoncondition(_fixedwidth,"tabs-fixed-width tab-demo");
 //BA.debugLineNum = 33;BA.debugLine="pdiv.Initialize(ID & \"-parent\",\"div\")";
_pdiv._initialize(ba,_id+"-parent","div");
 //BA.debugLineNum = 34;BA.debugLine="pdiv.AddClass(cClass)";
_pdiv._addclass(_cclass);
 //BA.debugLineNum = 35;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 36;BA.debugLine="tabs.Initialize";
_tabs.Initialize();
 //BA.debugLineNum = 37;BA.debugLine="tabs.clear";
_tabs.Clear();
 //BA.debugLineNum = 38;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 39;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 40;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 41;BA.debugLine="swipeable = True";
_swipeable = __c.True;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetabs  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 185;BA.debugLine="Sub RemoveAttribute(attr As String) As UOETabs";
 //BA.debugLineNum = 186;BA.debugLine="el.RemoveAttribute(attr)";
_el._removeattribute(_attr);
 //BA.debugLineNum = 187;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetabs)(this);
 //BA.debugLineNum = 188;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetabs  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 173;BA.debugLine="Sub RemoveClass(sClass As String) As UOETabs";
 //BA.debugLineNum = 174;BA.debugLine="el.RemoveClass(sClass)";
_el._removeclass(_sclass);
 //BA.debugLineNum = 175;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetabs)(this);
 //BA.debugLineNum = 176;BA.debugLine="End Sub";
return null;
}
public String  _selecttab(String _tabid) throws Exception{
String _skey = "";
String _script = "";
 //BA.debugLineNum = 142;BA.debugLine="Sub SelectTab(TabID As String)";
 //BA.debugLineNum = 143;BA.debugLine="Dim sKey As String = $\"${ID}${TabID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_tabid))+"");
 //BA.debugLineNum = 144;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Tabs.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".select('"+__c.SmartStringFormatter("",(Object)(_skey))+"');\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".updateTabIndicator();");
 //BA.debugLineNum = 148;BA.debugLine="Banano.eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 153;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 154;BA.debugLine="el.ID = ID";
_el._id = _id;
 //BA.debugLineNum = 155;BA.debugLine="el.MaterialEnable(Enabled).MaterialVisibility(Vis";
_el._materialenable(_enabled)._materialvisibility(_visibility)._materialzdepth(_zdepth);
 //BA.debugLineNum = 156;BA.debugLine="pdiv.AddElement(el)";
_pdiv._addelement(_el);
 //BA.debugLineNum = 157;BA.debugLine="pdiv.AddContentList(tabs)";
_pdiv._addcontentlist(_tabs);
 //BA.debugLineNum = 162;BA.debugLine="App.ApplyToolTip(ID,pdiv)";
_app._applytooltip(_id,_pdiv);
 //BA.debugLineNum = 163;BA.debugLine="Return pdiv.html";
if (true) return _pdiv._html();
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
