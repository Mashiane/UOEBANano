package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecopyrights extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecopyrights", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecopyrights.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _copyright = "";
public anywheresoftware.b4a.objects.collections.List _links = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _theme = "";
public String _visibility = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecopyrights  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 62;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 63;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub AddClass(sClass As String) As UOECopyRights";
 //BA.debugLineNum = 50;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 51;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _adddisclaimer() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Sub AddDisclaimer() As UOECopyRights";
 //BA.debugLineNum = 38;BA.debugLine="AddLink(\"footerdisclaimer\",\"{NBSP}Disclaimer{NBSP";
_addlink("footerdisclaimer","{NBSP}Disclaimer{NBSP}|",_app._disclaimerurl,"");
 //BA.debugLineNum = 39;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _addlink(String _lnkid,String _lnktext,String _lnkurl,String _lnktheme) throws Exception{
b4j.Mashy.UOEBANano.uoeanchoricon _a = null;
 //BA.debugLineNum = 73;BA.debugLine="Sub AddLink(lnkID As String, lnkText As String, ln";
 //BA.debugLineNum = 74;BA.debugLine="Dim a As UOEAnchorIcon";
_a = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 75;BA.debugLine="a.Initialize(App,lnkID,\"\",\"\",False,lnkText,lnkURL";
_a._initialize(ba,_app,_lnkid,"","",__c.False,_lnktext,_lnkurl,__c.True,_lnktheme,"");
 //BA.debugLineNum = 76;BA.debugLine="a.a.AddClass(\"right\")";
_a._a._addclass("right");
 //BA.debugLineNum = 77;BA.debugLine="Links.Add(a.tostring)";
_links.Add((Object)(_a._tostring()));
 //BA.debugLineNum = 78;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _addprivacypolicy() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub AddPrivacyPolicy() As UOECopyRights";
 //BA.debugLineNum = 44;BA.debugLine="AddLink(\"footerprivacy\",\"{NBSP}Privacy Policy\",Ap";
_addlink("footerprivacy","{NBSP}Privacy Policy",_app._privacypolicyurl,"");
 //BA.debugLineNum = 45;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 13;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 14;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 15;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _addtermsandconditions() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub AddTermsAndConditions() As UOECopyRights";
 //BA.debugLineNum = 32;BA.debugLine="AddLink(\"footerts\",\"Terms and Conditions{NBSP}|\",";
_addlink("footerts","Terms and Conditions{NBSP}|",_app._termsandconditionsurl,"");
 //BA.debugLineNum = 33;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Private CopyRight As String";
_copyright = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Links As List";
_links = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _stheme,String _sclass) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 20;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sTheme As";
 //BA.debugLineNum = 21;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 22;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 23;BA.debugLine="CopyRight = App.Copyrights";
_copyright = _app._copyrights;
 //BA.debugLineNum = 24;BA.debugLine="Element.Initialize(\"copyrights\",\"div\")";
_element._initialize(ba,"copyrights","div");
 //BA.debugLineNum = 25;BA.debugLine="Element.AddClass(\"footer-copyright\").addClass(sCl";
_element._addclass("footer-copyright")._addclass(_sclass);
 //BA.debugLineNum = 26;BA.debugLine="Links.Initialize";
_links.Initialize();
 //BA.debugLineNum = 27;BA.debugLine="Links.clear";
_links.Clear();
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecopyrights  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub RemoveAttribute(attr As String) As UOECopyRigh";
 //BA.debugLineNum = 68;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 69;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecopyrights  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub RemoveClass(sClass As String) As UOECopyRights";
 //BA.debugLineNum = 56;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecopyrights)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _pcont = null;
 //BA.debugLineNum = 82;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 83;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 84;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 85;BA.debugLine="Dim pcont As UOEHTML";
_pcont = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 86;BA.debugLine="pcont.Initialize(\"\",\"div\")";
_pcont._initialize(ba,"","div");
 //BA.debugLineNum = 87;BA.debugLine="pcont.AddClass(\"container\")";
_pcont._addclass("container");
 //BA.debugLineNum = 88;BA.debugLine="App.MaterialUseTheme(Theme,pcont)";
_app._materialusetheme(_theme,_pcont);
 //BA.debugLineNum = 89;BA.debugLine="If CopyRight <> \"\" Then";
if ((_copyright).equals("") == false) { 
 //BA.debugLineNum = 90;BA.debugLine="pcont.AddContent(\"© \").AddContent(CopyRight)";
_pcont._addcontent("© ")._addcontent(_copyright);
 };
 //BA.debugLineNum = 92;BA.debugLine="pcont.AddContentListReverse(Links)";
_pcont._addcontentlistreverse(_links);
 //BA.debugLineNum = 93;BA.debugLine="Element.AddElement(pcont)";
_element._addelement(_pcont);
 //BA.debugLineNum = 98;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
