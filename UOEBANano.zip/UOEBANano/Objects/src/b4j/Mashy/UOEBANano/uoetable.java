package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetable extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetable", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetable.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _zdepth = "";
public String _visibility = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _el = null;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.uoehtml _thead = null;
public b4j.Mashy.UOEBANano.uoehtml _tbody = null;
public anywheresoftware.b4a.objects.collections.List _rows = null;
public boolean _striped = false;
public boolean _highlight = false;
public boolean _centered = false;
public boolean _responsive = false;
public b4j.Mashy.UOEBANano.uoehtml _tfoot = null;
public b4j.Mashy.UOEBANano.uoecontainer _ptable = null;
public anywheresoftware.b4a.objects.collections.Map _headers = null;
public boolean _hasborder = false;
public boolean _overflow = false;
public String _onrowclick = "";
public String _activerow = "";
public String _caption = "";
public anywheresoftware.b4a.objects.collections.List _headerrows = null;
public anywheresoftware.b4a.objects.collections.List _footerrows = null;
public boolean _canexport = false;
public String _j = "";
public anywheresoftware.b4a.objects.collections.List _fields = null;
public anywheresoftware.b4a.objects.collections.Map _columns = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoetable  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 724;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 725;BA.debugLine="el.AddAttribute(attr,value)";
_el._addattribute(_attr,_value);
 //BA.debugLineNum = 726;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 727;BA.debugLine="End Sub";
return null;
}
public String  _addbody(anywheresoftware.b4a.objects.collections.List _rowfield,anywheresoftware.b4a.objects.collections.List _rowtitle,anywheresoftware.b4a.objects.collections.List _rowalignment,anywheresoftware.b4a.objects.collections.List _rowtheme,anywheresoftware.b4a.objects.collections.List _rowclass,anywheresoftware.b4a.objects.collections.List _colspan,anywheresoftware.b4a.objects.collections.List _coltag) throws Exception{
int _rtot = 0;
String _rkey = "";
b4j.Mashy.UOEBANano.uoehtml _hr = null;
int _hdrtot = 0;
int _hdrcnt = 0;
String _fldname = "";
b4j.Mashy.UOEBANano.uoehtml _td = null;
String _strcolspan = "";
String _scode = "";
 //BA.debugLineNum = 178;BA.debugLine="Sub AddBody(rowField As List,rowTitle As List, row";
 //BA.debugLineNum = 179;BA.debugLine="Dim rTot As Int = Rows.Size + 1";
_rtot = (int) (_rows.getSize()+1);
 //BA.debugLineNum = 180;BA.debugLine="Dim rKey As String = $\"rb${rTot}\"$";
_rkey = ("rb"+__c.SmartStringFormatter("",(Object)(_rtot))+"");
 //BA.debugLineNum = 181;BA.debugLine="Dim hr As UOEHTML";
_hr = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 182;BA.debugLine="hr.Initialize(rKey,\"tr\")";
_hr._initialize(ba,_rkey,"tr");
 //BA.debugLineNum = 184;BA.debugLine="Dim hdrTot As Int = rowField.Size - 1";
_hdrtot = (int) (_rowfield.getSize()-1);
 //BA.debugLineNum = 185;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 186;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step7 = 1;
final int limit7 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit7 ;_hdrcnt = _hdrcnt + step7 ) {
 //BA.debugLineNum = 187;BA.debugLine="Dim fldName As String = rowField.Get(hdrCnt)";
_fldname = BA.ObjectToString(_rowfield.Get(_hdrcnt));
 //BA.debugLineNum = 188;BA.debugLine="Dim td As UOEHTML";
_td = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 189;BA.debugLine="td.Initialize(\"\",\"td\")";
_td._initialize(ba,"","td");
 //BA.debugLineNum = 190;BA.debugLine="td.setname(fldName)";
_td._setname(_fldname);
 //BA.debugLineNum = 191;BA.debugLine="td.AddClass(fldName)";
_td._addclass(_fldname);
 //BA.debugLineNum = 192;BA.debugLine="If colTag <> Null And hdrCnt <= colTag.Size Then";
if (_coltag!= null && _hdrcnt<=_coltag.getSize()) { 
 //BA.debugLineNum = 193;BA.debugLine="td.SetTag(colTag.Get(hdrCnt))";
_td._settag(BA.ObjectToString(_coltag.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 195;BA.debugLine="If rowTitle <> Null And hdrCnt <= rowTitle.Size";
if (_rowtitle!= null && _hdrcnt<=_rowtitle.getSize()) { 
 //BA.debugLineNum = 196;BA.debugLine="td.AddContent(rowTitle.Get(hdrCnt))";
_td._addcontent(BA.ObjectToString(_rowtitle.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 198;BA.debugLine="If rowTheme <> Null And hdrCnt <= rowTheme.Size";
if (_rowtheme!= null && _hdrcnt<=_rowtheme.getSize()) { 
 //BA.debugLineNum = 199;BA.debugLine="App.materialusetheme(rowTheme.Get(hdrCnt),td)";
_app._materialusetheme(BA.ObjectToString(_rowtheme.Get(_hdrcnt)),_td);
 };
 //BA.debugLineNum = 201;BA.debugLine="If rowAlignment <> Null And hdrCnt <= rowAlignme";
if (_rowalignment!= null && _hdrcnt<=_rowalignment.getSize()) { 
 //BA.debugLineNum = 202;BA.debugLine="td.AddStyleAttribute(\"text-align\", rowAlignmen";
_td._addstyleattribute("text-align",BA.ObjectToString(_rowalignment.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 204;BA.debugLine="If rowClass <> Null And hdrCnt <= rowClass.Size";
if (_rowclass!= null && _hdrcnt<=_rowclass.getSize()) { 
 //BA.debugLineNum = 205;BA.debugLine="td.AddClass(rowClass.Get(hdrCnt))";
_td._addclass(BA.ObjectToString(_rowclass.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 207;BA.debugLine="If colSpan <> Null And hdrCnt <= colSpan.Size Th";
if (_colspan!= null && _hdrcnt<=_colspan.getSize()) { 
 //BA.debugLineNum = 208;BA.debugLine="Dim strColSpan As String = colSpan.Get(hdrCnt)";
_strcolspan = BA.ObjectToString(_colspan.Get(_hdrcnt));
 //BA.debugLineNum = 209;BA.debugLine="If strColSpan.Length > 0 Then";
if (_strcolspan.length()>0) { 
 //BA.debugLineNum = 210;BA.debugLine="td.AddAttribute(\"colspan\",strColSpan)";
_td._addattribute("colspan",_strcolspan);
 };
 };
 //BA.debugLineNum = 214;BA.debugLine="hr.AddElement(td)";
_hr._addelement(_td);
 }
};
 //BA.debugLineNum = 216;BA.debugLine="Dim scode As String = hr.tostring";
_scode = _hr._tostring();
 //BA.debugLineNum = 217;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 218;BA.debugLine="Rows.Add(scode)";
_rows.Add((Object)(_scode));
 //BA.debugLineNum = 219;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetable  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 712;BA.debugLine="Sub AddClass(sClass As String) As UOETable";
 //BA.debugLineNum = 713;BA.debugLine="el.AddClass(sClass)";
_el._addclass(_sclass);
 //BA.debugLineNum = 714;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 715;BA.debugLine="End Sub";
return null;
}
public String  _addfooter(anywheresoftware.b4a.objects.collections.List _rowfield,anywheresoftware.b4a.objects.collections.List _rowtitle,anywheresoftware.b4a.objects.collections.List _rowalignment,anywheresoftware.b4a.objects.collections.List _rowtheme,anywheresoftware.b4a.objects.collections.List _rowclass,anywheresoftware.b4a.objects.collections.List _colspan,anywheresoftware.b4a.objects.collections.List _coltag) throws Exception{
int _rtot = 0;
String _rkey = "";
b4j.Mashy.UOEBANano.uoehtml _hr = null;
int _hdrtot = 0;
int _hdrcnt = 0;
String _fldname = "";
b4j.Mashy.UOEBANano.uoehtml _td = null;
String _strcolspan = "";
String _scode = "";
 //BA.debugLineNum = 222;BA.debugLine="Sub AddFooter(rowField As List,rowTitle As List, r";
 //BA.debugLineNum = 223;BA.debugLine="Dim rTot As Int = FooterRows.Size + 1";
_rtot = (int) (_footerrows.getSize()+1);
 //BA.debugLineNum = 224;BA.debugLine="Dim rKey As String = $\"rb${rTot}\"$";
_rkey = ("rb"+__c.SmartStringFormatter("",(Object)(_rtot))+"");
 //BA.debugLineNum = 225;BA.debugLine="Dim hr As UOEHTML";
_hr = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 226;BA.debugLine="hr.Initialize(rKey,\"tr\")";
_hr._initialize(ba,_rkey,"tr");
 //BA.debugLineNum = 228;BA.debugLine="Dim hdrTot As Int = rowField.Size - 1";
_hdrtot = (int) (_rowfield.getSize()-1);
 //BA.debugLineNum = 229;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 230;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step7 = 1;
final int limit7 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit7 ;_hdrcnt = _hdrcnt + step7 ) {
 //BA.debugLineNum = 231;BA.debugLine="Dim fldName As String = rowField.Get(hdrCnt)";
_fldname = BA.ObjectToString(_rowfield.Get(_hdrcnt));
 //BA.debugLineNum = 232;BA.debugLine="Dim td As UOEHTML";
_td = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 233;BA.debugLine="td.Initialize(\"\",\"td\")";
_td._initialize(ba,"","td");
 //BA.debugLineNum = 234;BA.debugLine="td.setname(fldName)";
_td._setname(_fldname);
 //BA.debugLineNum = 235;BA.debugLine="td.AddClass(fldName)";
_td._addclass(_fldname);
 //BA.debugLineNum = 236;BA.debugLine="If colTag <> Null And hdrCnt <= colTag.Size Then";
if (_coltag!= null && _hdrcnt<=_coltag.getSize()) { 
 //BA.debugLineNum = 237;BA.debugLine="td.SetTag(colTag.Get(hdrCnt))";
_td._settag(BA.ObjectToString(_coltag.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 239;BA.debugLine="If rowTitle <> Null And hdrCnt <= rowTitle.Size";
if (_rowtitle!= null && _hdrcnt<=_rowtitle.getSize()) { 
 //BA.debugLineNum = 240;BA.debugLine="td.AddContent(rowTitle.Get(hdrCnt))";
_td._addcontent(BA.ObjectToString(_rowtitle.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 242;BA.debugLine="If rowTheme <> Null And hdrCnt <= rowTheme.Size";
if (_rowtheme!= null && _hdrcnt<=_rowtheme.getSize()) { 
 //BA.debugLineNum = 243;BA.debugLine="App.materialusetheme(rowTheme.Get(hdrCnt),td)";
_app._materialusetheme(BA.ObjectToString(_rowtheme.Get(_hdrcnt)),_td);
 };
 //BA.debugLineNum = 245;BA.debugLine="If rowAlignment <> Null And hdrCnt <= rowAlignme";
if (_rowalignment!= null && _hdrcnt<=_rowalignment.getSize()) { 
 //BA.debugLineNum = 246;BA.debugLine="td.AddStyleAttribute(\"text-align\", rowAlignment";
_td._addstyleattribute("text-align",BA.ObjectToString(_rowalignment.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 248;BA.debugLine="If rowClass <> Null And hdrCnt <= rowClass.Size";
if (_rowclass!= null && _hdrcnt<=_rowclass.getSize()) { 
 //BA.debugLineNum = 249;BA.debugLine="td.AddClass(rowClass.Get(hdrCnt))";
_td._addclass(BA.ObjectToString(_rowclass.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 251;BA.debugLine="If colSpan <> Null And hdrCnt <= colSpan.Size Th";
if (_colspan!= null && _hdrcnt<=_colspan.getSize()) { 
 //BA.debugLineNum = 252;BA.debugLine="Dim strColSpan As String = colSpan.Get(hdrCnt)";
_strcolspan = BA.ObjectToString(_colspan.Get(_hdrcnt));
 //BA.debugLineNum = 253;BA.debugLine="If strColSpan.Length > 0 Then";
if (_strcolspan.length()>0) { 
 //BA.debugLineNum = 254;BA.debugLine="td.AddAttribute(\"colspan\",strColSpan)";
_td._addattribute("colspan",_strcolspan);
 };
 };
 //BA.debugLineNum = 258;BA.debugLine="hr.AddElement(td)";
_hr._addelement(_td);
 }
};
 //BA.debugLineNum = 260;BA.debugLine="Dim scode As String = hr.tostring";
_scode = _hr._tostring();
 //BA.debugLineNum = 261;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 262;BA.debugLine="FooterRows.Add(scode)";
_footerrows.Add((Object)(_scode));
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetable  _addfootercontainer(b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
 //BA.debugLineNum = 267;BA.debugLine="Sub AddFooterContainer(cont As UOEContainer) As UO";
 //BA.debugLineNum = 268;BA.debugLine="tfoot.AddContent(cont.ToString)";
_tfoot._addcontent(_cont._tostring());
 //BA.debugLineNum = 269;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 270;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadercontainer(b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
 //BA.debugLineNum = 273;BA.debugLine="Sub AddHeaderContainer(cont As UOEContainer) As UO";
 //BA.debugLineNum = 274;BA.debugLine="pTable.AddContainer(1,1,cont)";
_ptable._addcontainer((int) (1),(int) (1),_cont);
 //BA.debugLineNum = 275;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 276;BA.debugLine="End Sub";
return null;
}
public String  _addheading(anywheresoftware.b4a.objects.collections.List _rowfield,anywheresoftware.b4a.objects.collections.List _rowtitle,anywheresoftware.b4a.objects.collections.List _rowalignment,anywheresoftware.b4a.objects.collections.List _rowtheme,anywheresoftware.b4a.objects.collections.List _rowclass,anywheresoftware.b4a.objects.collections.List _colspan,anywheresoftware.b4a.objects.collections.List _coltag) throws Exception{
int _rtot = 0;
String _rkey = "";
b4j.Mashy.UOEBANano.uoehtml _hr = null;
int _hdrtot = 0;
int _hdrcnt = 0;
String _fldname = "";
b4j.Mashy.UOEBANano.uoehtml _td = null;
String _strcolspan = "";
String _scode = "";
 //BA.debugLineNum = 134;BA.debugLine="Sub AddHeading(rowField As List,rowTitle As List,";
 //BA.debugLineNum = 135;BA.debugLine="Dim rTot As Int = HeaderRows.Size + 1";
_rtot = (int) (_headerrows.getSize()+1);
 //BA.debugLineNum = 136;BA.debugLine="Dim rKey As String = $\"rh${rTot}\"$";
_rkey = ("rh"+__c.SmartStringFormatter("",(Object)(_rtot))+"");
 //BA.debugLineNum = 137;BA.debugLine="Dim hr As UOEHTML";
_hr = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 138;BA.debugLine="hr.Initialize(rKey,\"tr\")";
_hr._initialize(ba,_rkey,"tr");
 //BA.debugLineNum = 140;BA.debugLine="Dim hdrTot As Int = rowField.Size - 1";
_hdrtot = (int) (_rowfield.getSize()-1);
 //BA.debugLineNum = 141;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 142;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step7 = 1;
final int limit7 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit7 ;_hdrcnt = _hdrcnt + step7 ) {
 //BA.debugLineNum = 143;BA.debugLine="Dim fldName As String = rowField.Get(hdrCnt)";
_fldname = BA.ObjectToString(_rowfield.Get(_hdrcnt));
 //BA.debugLineNum = 144;BA.debugLine="Dim td As UOEHTML";
_td = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 145;BA.debugLine="td.Initialize(\"\",\"td\")";
_td._initialize(ba,"","td");
 //BA.debugLineNum = 146;BA.debugLine="td.setname(fldName)";
_td._setname(_fldname);
 //BA.debugLineNum = 147;BA.debugLine="td.AddClass(fldName)";
_td._addclass(_fldname);
 //BA.debugLineNum = 148;BA.debugLine="If colTag <> Null And hdrCnt <= colTag.Size Then";
if (_coltag!= null && _hdrcnt<=_coltag.getSize()) { 
 //BA.debugLineNum = 149;BA.debugLine="td.SetTag(colTag.Get(hdrCnt))";
_td._settag(BA.ObjectToString(_coltag.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 151;BA.debugLine="If rowTitle <> Null And hdrCnt <= rowTitle.Size";
if (_rowtitle!= null && _hdrcnt<=_rowtitle.getSize()) { 
 //BA.debugLineNum = 152;BA.debugLine="td.AddContent(rowTitle.Get(hdrCnt))";
_td._addcontent(BA.ObjectToString(_rowtitle.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 154;BA.debugLine="If rowTheme <> Null And hdrCnt <= rowTheme.Size";
if (_rowtheme!= null && _hdrcnt<=_rowtheme.getSize()) { 
 //BA.debugLineNum = 155;BA.debugLine="App.materialusetheme(rowTheme.Get(hdrCnt),td)";
_app._materialusetheme(BA.ObjectToString(_rowtheme.Get(_hdrcnt)),_td);
 };
 //BA.debugLineNum = 157;BA.debugLine="If rowAlignment <> Null And hdrCnt <= rowAlignme";
if (_rowalignment!= null && _hdrcnt<=_rowalignment.getSize()) { 
 //BA.debugLineNum = 158;BA.debugLine="td.AddStyleAttribute(\"text-align\", rowAlignmen";
_td._addstyleattribute("text-align",BA.ObjectToString(_rowalignment.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 160;BA.debugLine="If rowClass <> Null And hdrCnt <= rowClass.Size";
if (_rowclass!= null && _hdrcnt<=_rowclass.getSize()) { 
 //BA.debugLineNum = 161;BA.debugLine="td.AddClass(rowClass.Get(hdrCnt))";
_td._addclass(BA.ObjectToString(_rowclass.Get(_hdrcnt)));
 };
 //BA.debugLineNum = 163;BA.debugLine="If colSpan <> Null And hdrCnt <= colSpan.Size Th";
if (_colspan!= null && _hdrcnt<=_colspan.getSize()) { 
 //BA.debugLineNum = 164;BA.debugLine="Dim strColSpan As String = colSpan.Get(hdrCnt)";
_strcolspan = BA.ObjectToString(_colspan.Get(_hdrcnt));
 //BA.debugLineNum = 165;BA.debugLine="If strColSpan.Length > 0 Then";
if (_strcolspan.length()>0) { 
 //BA.debugLineNum = 166;BA.debugLine="td.AddAttribute(\"colspan\",strColSpan)";
_td._addattribute("colspan",_strcolspan);
 };
 };
 //BA.debugLineNum = 170;BA.debugLine="hr.AddElement(td)";
_hr._addelement(_td);
 }
};
 //BA.debugLineNum = 172;BA.debugLine="Dim scode As String = hr.tostring";
_scode = _hr._tostring();
 //BA.debugLineNum = 173;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 174;BA.debugLine="HeaderRows.Add(scode)";
_headerrows.Add((Object)(_scode));
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetable  _addheadings(anywheresoftware.b4a.objects.collections.List _coltitles) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
b4j.Mashy.UOEBANano.uoehtml _th = null;
boolean _hasheader = false;
 //BA.debugLineNum = 310;BA.debugLine="Sub AddHeadings(colTitles As List) As UOETable";
 //BA.debugLineNum = 311;BA.debugLine="Dim hdrTot As Int = colTitles.Size - 1";
_hdrtot = (int) (_coltitles.getSize()-1);
 //BA.debugLineNum = 312;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 313;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 314;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 315;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 316;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 317;BA.debugLine="hdrName = colTitles.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_coltitles.Get(_hdrcnt));
 //BA.debugLineNum = 318;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 319;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 320;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 321;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 322;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 323;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 325;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 326;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 329;BA.debugLine="th.AddContent(hdrName)";
_th._addcontent(_hdrname);
 //BA.debugLineNum = 330;BA.debugLine="th1.title = hdrName";
_th1._title = _hdrname;
 //BA.debugLineNum = 331;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 332;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 334;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsalignment(anywheresoftware.b4a.objects.collections.List _colalign) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 396;BA.debugLine="Sub AddHeadingsAlignment(colAlign As List) As UOET";
 //BA.debugLineNum = 397;BA.debugLine="Dim hdrTot As Int = colAlign.Size - 1";
_hdrtot = (int) (_colalign.getSize()-1);
 //BA.debugLineNum = 398;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 399;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 400;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 401;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 402;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 403;BA.debugLine="hdrName = colAlign.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colalign.Get(_hdrcnt));
 //BA.debugLineNum = 404;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 405;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 406;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 407;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 408;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 409;BA.debugLine="th1 = Columns.get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 411;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 412;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 415;BA.debugLine="th.AddStyleAttribute(\"text-align\", hdrName)";
_th._addstyleattribute("text-align",_hdrname);
 //BA.debugLineNum = 416;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 417;BA.debugLine="th1.alignment = hdrName";
_th1._alignment = _hdrname;
 //BA.debugLineNum = 418;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 420;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 421;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsclasses(anywheresoftware.b4a.objects.collections.List _colclass) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 424;BA.debugLine="Sub AddHeadingsClasses(colClass As List) As UOETab";
 //BA.debugLineNum = 425;BA.debugLine="Dim hdrTot As Int = colClass.Size - 1";
_hdrtot = (int) (_colclass.getSize()-1);
 //BA.debugLineNum = 426;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 427;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 428;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 429;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 430;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 431;BA.debugLine="hdrName = colClass.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colclass.Get(_hdrcnt));
 //BA.debugLineNum = 432;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 433;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 434;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 435;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 436;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 437;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 439;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 440;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 443;BA.debugLine="th.addclass(hdrName)";
_th._addclass(_hdrname);
 //BA.debugLineNum = 444;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 445;BA.debugLine="th1.ClassName = hdrName";
_th1._classname = _hdrname;
 //BA.debugLineNum = 446;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 448;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 449;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsfields(anywheresoftware.b4a.objects.collections.List _colfields) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 338;BA.debugLine="Sub AddHeadingsFields(colFields As List) As UOETab";
 //BA.debugLineNum = 339;BA.debugLine="Dim hdrTot As Int = colFields.Size - 1";
_hdrtot = (int) (_colfields.getSize()-1);
 //BA.debugLineNum = 340;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 341;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 342;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 343;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 344;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 345;BA.debugLine="hdrName = colFields.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colfields.Get(_hdrcnt));
 //BA.debugLineNum = 346;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 347;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 348;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 349;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 350;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 351;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 353;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 354;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 356;BA.debugLine="th.setname(hdrName)";
_th._setname(_hdrname);
 //BA.debugLineNum = 357;BA.debugLine="th.AddClass(hdrName)";
_th._addclass(_hdrname);
 //BA.debugLineNum = 358;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 359;BA.debugLine="Fields.Add(hdrName)";
_fields.Add((Object)(_hdrname));
 //BA.debugLineNum = 360;BA.debugLine="th1.FieldName = hdrName";
_th1._fieldname = _hdrname;
 //BA.debugLineNum = 361;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 363;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsheights(anywheresoftware.b4a.objects.collections.List _colheights) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 368;BA.debugLine="Sub AddHeadingsHeights(colHeights As List) As UOET";
 //BA.debugLineNum = 369;BA.debugLine="Dim hdrTot As Int = colHeights.Size - 1";
_hdrtot = (int) (_colheights.getSize()-1);
 //BA.debugLineNum = 370;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 371;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 372;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 373;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 374;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 375;BA.debugLine="hdrName = colHeights.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colheights.Get(_hdrcnt));
 //BA.debugLineNum = 376;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 377;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 378;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 379;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 380;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 381;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 383;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 384;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 387;BA.debugLine="th.AddStyleAttribute(\"height\",hdrName & \"px\")";
_th._addstyleattribute("height",_hdrname+"px");
 //BA.debugLineNum = 388;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 389;BA.debugLine="th1.Height = hdrName";
_th1._height = _hdrname;
 //BA.debugLineNum = 390;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 392;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 393;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsthemes(anywheresoftware.b4a.objects.collections.List _colthemes) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
b4j.Mashy.UOEBANano.uoehtml _th = null;
boolean _hasheader = false;
 //BA.debugLineNum = 279;BA.debugLine="Sub AddHeadingsThemes(colThemes As List) As UOETab";
 //BA.debugLineNum = 280;BA.debugLine="Dim hdrTot As Int = colThemes.Size - 1";
_hdrtot = (int) (_colthemes.getSize()-1);
 //BA.debugLineNum = 281;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 282;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 283;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 284;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 285;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 286;BA.debugLine="hdrName = colThemes.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colthemes.Get(_hdrcnt));
 //BA.debugLineNum = 287;BA.debugLine="If hdrName = \"\" Then";
if ((_hdrname).equals("")) { 
 //BA.debugLineNum = 288;BA.debugLine="hdrName = App.theme";
_hdrname = _app._theme;
 };
 //BA.debugLineNum = 290;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 291;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 292;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 293;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 294;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 295;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 297;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 298;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 301;BA.debugLine="App.MaterialUseTheme(hdrName,th)";
_app._materialusetheme(_hdrname,_th);
 //BA.debugLineNum = 302;BA.debugLine="th1.Theme = hdrName";
_th1._theme = _hdrname;
 //BA.debugLineNum = 303;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 304;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 306;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 307;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingsvisibility(anywheresoftware.b4a.objects.collections.List _colvisibility) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 481;BA.debugLine="Sub AddHeadingsVisibility(colVisibility As List) A";
 //BA.debugLineNum = 482;BA.debugLine="Dim hdrTot As Int = colVisibility.Size - 1";
_hdrtot = (int) (_colvisibility.getSize()-1);
 //BA.debugLineNum = 483;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 484;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 485;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 486;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 487;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 488;BA.debugLine="hdrName = colVisibility.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colvisibility.Get(_hdrcnt));
 //BA.debugLineNum = 489;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 490;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 491;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 492;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 493;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 494;BA.debugLine="th1 = Columns.Get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 496;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 497;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 499;BA.debugLine="th.MaterialVisibility(hdrName)";
_th._materialvisibility(_hdrname);
 //BA.debugLineNum = 500;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 501;BA.debugLine="th1.Visibility = hdrName";
_th1._visibility = _hdrname;
 //BA.debugLineNum = 502;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 504;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 505;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addheadingswidths(anywheresoftware.b4a.objects.collections.List _colwidths) throws Exception{
int _hdrtot = 0;
int _hdrcnt = 0;
String _hdrstr = "";
String _hdrname = "";
b4j.Mashy.UOEBANano.uoehtml _th = null;
b4j.Mashy.UOEBANano.uoetableheading _th1 = null;
boolean _hasheader = false;
 //BA.debugLineNum = 453;BA.debugLine="Sub AddHeadingsWidths(colWidths As List) As UOETab";
 //BA.debugLineNum = 454;BA.debugLine="Dim hdrTot As Int = colWidths.Size - 1";
_hdrtot = (int) (_colwidths.getSize()-1);
 //BA.debugLineNum = 455;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 456;BA.debugLine="Dim hdrStr As String";
_hdrstr = "";
 //BA.debugLineNum = 457;BA.debugLine="Dim hdrName As String";
_hdrname = "";
 //BA.debugLineNum = 458;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 459;BA.debugLine="hdrStr = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 460;BA.debugLine="hdrName = colWidths.Get(hdrCnt)";
_hdrname = BA.ObjectToString(_colwidths.Get(_hdrcnt));
 //BA.debugLineNum = 461;BA.debugLine="Dim th As UOEHTML";
_th = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 462;BA.debugLine="Dim th1 As UOETableHeading";
_th1 = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 463;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 464;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 465;BA.debugLine="th = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 466;BA.debugLine="th1 = Columns.get(hdrStr)";
_th1 = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 }else {
 //BA.debugLineNum = 468;BA.debugLine="th.Initialize(hdrStr,\"th\")";
_th._initialize(ba,_hdrstr,"th");
 //BA.debugLineNum = 469;BA.debugLine="th1.Initialize";
_th1._initialize(ba);
 };
 //BA.debugLineNum = 472;BA.debugLine="th.AddStyleAttribute(\"width\",hdrName & \"px\")";
_th._addstyleattribute("width",_hdrname+"px");
 //BA.debugLineNum = 473;BA.debugLine="Headers.Put(hdrStr,th)";
_headers.Put((Object)(_hdrstr),(Object)(_th));
 //BA.debugLineNum = 474;BA.debugLine="th1.Width = hdrName";
_th1._width = _hdrname;
 //BA.debugLineNum = 475;BA.debugLine="Columns.Put(hdrStr,th1)";
_columns.Put((Object)(_hdrstr),(Object)(_th1));
 }
};
 //BA.debugLineNum = 477;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 478;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _addrow(anywheresoftware.b4a.objects.collections.List _data,anywheresoftware.b4a.objects.collections.List _datatheme,anywheresoftware.b4a.objects.collections.List _dataclass) throws Exception{
int _rtot = 0;
String _rkey = "";
b4j.Mashy.UOEBANano.uoehtml _tr1 = null;
String _scode = "";
 //BA.debugLineNum = 514;BA.debugLine="Sub AddRow(data As List,dataTheme As List,dataClas";
 //BA.debugLineNum = 516;BA.debugLine="Dim rTot As Int = Rows.size + 1";
_rtot = (int) (_rows.getSize()+1);
 //BA.debugLineNum = 517;BA.debugLine="Dim rKey As String = $\"${ID}_r${rTot}\"$";
_rkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"_r"+__c.SmartStringFormatter("",(Object)(_rtot))+"");
 //BA.debugLineNum = 519;BA.debugLine="Dim tr1 As UOEHTML = NewRow(rKey,data,dataTheme,d";
_tr1 = _newrow(_rkey,_data,_datatheme,_dataclass);
 //BA.debugLineNum = 520;BA.debugLine="Dim scode As String = tr1.tostring";
_scode = _tr1._tostring();
 //BA.debugLineNum = 521;BA.debugLine="scode = scode.Replace(CRLF,\"\")";
_scode = _scode.replace(__c.CRLF,"");
 //BA.debugLineNum = 522;BA.debugLine="Rows.Add(scode)";
_rows.Add((Object)(_scode));
 //BA.debugLineNum = 523;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 524;BA.debugLine="End Sub";
return null;
}
public String  _addrow1(int _pos,anywheresoftware.b4a.objects.collections.List _data,anywheresoftware.b4a.objects.collections.List _datatheme,anywheresoftware.b4a.objects.collections.List _dataclass) throws Exception{
String _rkey = "";
b4j.Mashy.UOEBANano.uoehtml _tr1 = null;
String _srow = "";
String _script = "";
 //BA.debugLineNum = 579;BA.debugLine="Sub AddRow1(pos As Int, data As List,dataTheme As";
 //BA.debugLineNum = 581;BA.debugLine="Dim rKey As String = $\"${ID}_r${DateTime.now}\"$";
_rkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"_r"+__c.SmartStringFormatter("",(Object)(__c.DateTime.getNow()))+"");
 //BA.debugLineNum = 583;BA.debugLine="Dim tr1 As UOEHTML = NewRow(rKey,data,dataTheme,d";
_tr1 = _newrow(_rkey,_data,_datatheme,_dataclass);
 //BA.debugLineNum = 584;BA.debugLine="Select Case pos";
switch (BA.switchObjectToInt(_pos,(int) (-1))) {
case 0: {
 //BA.debugLineNum = 587;BA.debugLine="Dim sRow As String = tr1.tostring";
_srow = _tr1._tostring();
 //BA.debugLineNum = 588;BA.debugLine="sRow = sRow.Replace(CRLF,\"\")";
_srow = _srow.replace(__c.CRLF,"");
 //BA.debugLineNum = 589;BA.debugLine="Dim script As String = $\"var newRow = '${sRow}'";
_script = ("var newRow = '"+__c.SmartStringFormatter("",(Object)(_srow))+"';\n"+"		var tbl = "+__c.SmartStringFormatter("",(Object)(_j))+"('#"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"		tbl.append(newRow);");
 //BA.debugLineNum = 592;BA.debugLine="Return script";
if (true) return _script;
 break; }
default: {
 //BA.debugLineNum = 594;BA.debugLine="Dim script As String = $\"var newRow = '${sRow}'";
_script = ("var newRow = '"+__c.SmartStringFormatter("",(Object)(_srow))+"';\n"+"		$('#"+__c.SmartStringFormatter("",(Object)(_id))+" > tbody > tr').eq("+__c.SmartStringFormatter("",(Object)(_pos))+"-1).before(newRow);");
 //BA.debugLineNum = 596;BA.debugLine="Return script";
if (true) return _script;
 break; }
}
;
 //BA.debugLineNum = 598;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetable  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 94;BA.debugLine="el.AddStyleAttribute(attribute,value)";
_el._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 95;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 7;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Private el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 13;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 14;BA.debugLine="Private thead As UOEHTML";
_thead = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 15;BA.debugLine="Private tbody As UOEHTML";
_tbody = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 16;BA.debugLine="Private Rows As List";
_rows = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 17;BA.debugLine="Public Striped As Boolean";
_striped = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Highlight As Boolean";
_highlight = false;
 //BA.debugLineNum = 19;BA.debugLine="Public Centered As Boolean";
_centered = false;
 //BA.debugLineNum = 20;BA.debugLine="Public Responsive As Boolean";
_responsive = false;
 //BA.debugLineNum = 21;BA.debugLine="Private tfoot As UOEHTML";
_tfoot = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 22;BA.debugLine="Private pTable As UOEContainer";
_ptable = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 23;BA.debugLine="Private Headers As Map";
_headers = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 24;BA.debugLine="Public HasBorder As Boolean";
_hasborder = false;
 //BA.debugLineNum = 25;BA.debugLine="Public OverFlow As Boolean";
_overflow = false;
 //BA.debugLineNum = 26;BA.debugLine="Public OnRowClick As String";
_onrowclick = "";
 //BA.debugLineNum = 27;BA.debugLine="Public ActiveRow As String";
_activerow = "";
 //BA.debugLineNum = 28;BA.debugLine="Public Caption As String";
_caption = "";
 //BA.debugLineNum = 29;BA.debugLine="Private HeaderRows As List";
_headerrows = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 30;BA.debugLine="Private FooterRows As List";
_footerrows = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 31;BA.debugLine="Public CanExport As Boolean";
_canexport = false;
 //BA.debugLineNum = 32;BA.debugLine="Private j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 33;BA.debugLine="Public Fields As List";
_fields = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 34;BA.debugLine="Public Columns As Map";
_columns = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _clear() throws Exception{
String _script = "";
 //BA.debugLineNum = 601;BA.debugLine="Sub Clear() As String";
 //BA.debugLineNum = 602;BA.debugLine="Dim script As String = $\"${j}('#${ID} tbody tr').";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"('#"+__c.SmartStringFormatter("",(Object)(_id))+" tbody tr').remove();");
 //BA.debugLineNum = 603;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 604;BA.debugLine="End Sub";
return "";
}
public String  _deleterow(String _rowpos) throws Exception{
String _script = "";
 //BA.debugLineNum = 508;BA.debugLine="Sub DeleteRow(rowPos As String) As String";
 //BA.debugLineNum = 509;BA.debugLine="Dim script As String = $\"document.getElementById(";
_script = ("document.getElementById(\""+__c.SmartStringFormatter("",(Object)(_id))+"\").deleteRow("+__c.SmartStringFormatter("",(Object)(_rowpos))+");");
 //BA.debugLineNum = 510;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 511;BA.debugLine="End Sub";
return "";
}
public String  _export2csv() throws Exception{
String _script = "";
 //BA.debugLineNum = 60;BA.debugLine="Sub Export2CSV() As String";
 //BA.debugLineNum = 61;BA.debugLine="CanExport = True";
_canexport = __c.True;
 //BA.debugLineNum = 62;BA.debugLine="Dim script As String = $\"${j}(\"#${ID}\").tableHTML";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+"\").tableHTMLExport({type:'csv',filename:'"+__c.SmartStringFormatter("",(Object)(_id))+".csv'});");
 //BA.debugLineNum = 63;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
public String  _export2json() throws Exception{
String _script = "";
 //BA.debugLineNum = 53;BA.debugLine="Sub Export2Json() As String";
 //BA.debugLineNum = 54;BA.debugLine="CanExport = True";
_canexport = __c.True;
 //BA.debugLineNum = 55;BA.debugLine="Dim script As String = $\"${j}(\"#${ID}\").tableHTML";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+"\").tableHTMLExport({type:'json',filename:'"+__c.SmartStringFormatter("",(Object)(_id))+".json'});");
 //BA.debugLineNum = 56;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public String  _export2pdf() throws Exception{
String _script = "";
 //BA.debugLineNum = 74;BA.debugLine="Sub Export2PDF() As String";
 //BA.debugLineNum = 75;BA.debugLine="CanExport = True";
_canexport = __c.True;
 //BA.debugLineNum = 76;BA.debugLine="Dim script As String = $\"${j}(\"#${ID}\").tableHTML";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+"\").tableHTMLExport({type:'pdf',filename:'"+__c.SmartStringFormatter("",(Object)(_id))+".pdf'});");
 //BA.debugLineNum = 77;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _export2txt() throws Exception{
String _script = "";
 //BA.debugLineNum = 67;BA.debugLine="Sub Export2Txt() As String";
 //BA.debugLineNum = 68;BA.debugLine="CanExport = True";
_canexport = __c.True;
 //BA.debugLineNum = 69;BA.debugLine="Dim script As String = $\"${j}(\"#${ID}\").tableHTML";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+"\").tableHTMLExport({type:'txt',filename:'"+__c.SmartStringFormatter("",(Object)(_id))+".txt'});");
 //BA.debugLineNum = 70;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 71;BA.debugLine="End Sub";
return "";
}
public String  _getrows(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 87;BA.debugLine="Sub GetRows(varName As String) As String";
 //BA.debugLineNum = 88;BA.debugLine="Dim script As String = $\"${varName} = getRows${ID";
_script = (""+__c.SmartStringFormatter("",(Object)(_varname))+" = getRows"+__c.SmartStringFormatter("",(Object)(_id))+"();");
 //BA.debugLineNum = 89;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _getrowscount(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 527;BA.debugLine="Sub GetRowsCount(varName As String) As String";
 //BA.debugLineNum = 528;BA.debugLine="Dim script As String = $\"var tbl = ${j}('#${ID} t";
_script = ("var tbl = "+__c.SmartStringFormatter("",(Object)(_j))+"('#"+__c.SmartStringFormatter("",(Object)(_id))+" tbody tr');\n"+""+__c.SmartStringFormatter("",(Object)(_varname))+" = tbl.length;");
 //BA.debugLineNum = 530;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 531;BA.debugLine="End Sub";
return "";
}
public String  _getrowsinternal() throws Exception{
int _hdrcnt = 0;
int _hdrtot = 0;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _hdrstr = "";
b4j.Mashy.UOEBANano.uoehtml _hdr = null;
String _colfield = "";
String _script = "";
 //BA.debugLineNum = 680;BA.debugLine="private Sub GetRowsInternal()";
 //BA.debugLineNum = 681;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 682;BA.debugLine="Dim hdrTot As Int = Headers.Size - 1";
_hdrtot = (int) (_headers.getSize()-1);
 //BA.debugLineNum = 683;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 684;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 685;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 686;BA.debugLine="Dim hdrStr As String = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 687;BA.debugLine="Dim hdr As UOEHTML = Headers.Get(hdrStr)";
_hdr = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 688;BA.debugLine="Dim colField As String = hdr.GetAttribute(\"name\"";
_colfield = _hdr._getattribute("name");
 //BA.debugLineNum = 689;BA.debugLine="If colField.Length > 0 Then";
if (_colfield.length()>0) { 
 //BA.debugLineNum = 690;BA.debugLine="Dim script As String = $\"var v${colField} = ${I";
_script = ("var v"+__c.SmartStringFormatter("",(Object)(_colfield))+" = "+__c.SmartStringFormatter("",(Object)(_id))+"row.find(\"[name="+__c.SmartStringFormatter("",(Object)(_colfield))+"]\").text();\n"+"			"+__c.SmartStringFormatter("",(Object)(_id))+"obj['"+__c.SmartStringFormatter("",(Object)(_colfield))+"'] = v"+__c.SmartStringFormatter("",(Object)(_colfield))+";\n"+"			"+__c.SmartStringFormatter("",(Object)(_id))+"obj['index'] = index;");
 //BA.debugLineNum = 693;BA.debugLine="sb.append(script).Append(CRLF)";
_sb.Append(_script).Append(__c.CRLF);
 };
 }
};
 //BA.debugLineNum = 696;BA.debugLine="Dim script As String = $\"var ${ID}data = []; 	${I";
_script = ("var "+__c.SmartStringFormatter("",(Object)(_id))+"data = [];\n"+"	"+__c.SmartStringFormatter("",(Object)(_id))+"rows = "+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+" tbody tr\");\n"+""+__c.SmartStringFormatter("",(Object)(_id))+"rows.each(function (index) {\n"+"    var "+__c.SmartStringFormatter("",(Object)(_id))+"row = "+__c.SmartStringFormatter("",(Object)(_j))+"(this);\n"+" 	var "+__c.SmartStringFormatter("",(Object)(_id))+"obj = {};\n"+"	"+__c.SmartStringFormatter("",(Object)(_sb.ToString()))+"\n"+"	"+__c.SmartStringFormatter("",(Object)(_id))+"data.push("+__c.SmartStringFormatter("",(Object)(_id))+"obj);\n"+"});\n"+"return "+__c.SmartStringFormatter("",(Object)(_id))+"data;");
 //BA.debugLineNum = 709;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoetableheading  _gettableheading(String _colname) throws Exception{
b4j.Mashy.UOEBANano.uoetableheading _hdr = null;
int _hdrcnt = 0;
String _hdrstr = "";
 //BA.debugLineNum = 37;BA.debugLine="Sub GetTableHeading(colName As String) As UOETable";
 //BA.debugLineNum = 38;BA.debugLine="Dim hdr As UOETableHeading";
_hdr = new b4j.Mashy.UOEBANano.uoetableheading();
 //BA.debugLineNum = 39;BA.debugLine="Dim hdrCnt As Int = Fields.IndexOf(colName)";
_hdrcnt = _fields.IndexOf((Object)(_colname));
 //BA.debugLineNum = 40;BA.debugLine="If hdrCnt >= 0 Then";
if (_hdrcnt>=0) { 
 //BA.debugLineNum = 41;BA.debugLine="Dim hdrStr As String = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 42;BA.debugLine="hdr = Columns.Get(hdrStr)";
_hdr = (b4j.Mashy.UOEBANano.uoetableheading)(_columns.Get((Object)(_hdrstr)));
 };
 //BA.debugLineNum = 44;BA.debugLine="Return hdr";
if (true) return _hdr;
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public String  _hidecolumn(String _colfieldname) throws Exception{
String _script = "";
 //BA.debugLineNum = 670;BA.debugLine="Sub HideColumn(colFieldName As String) As String";
 //BA.debugLineNum = 671;BA.debugLine="Dim script As String = $\"var tbl${ID} = ${j}(\"#${";
_script = ("var tbl"+__c.SmartStringFormatter("",(Object)(_id))+" = "+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+"\");\n"+"    var tblhead"+__c.SmartStringFormatter("",(Object)(_id))+" = "+__c.SmartStringFormatter("",(Object)(_j))+"(\"#"+__c.SmartStringFormatter("",(Object)(_id))+" th\");\n"+"	var colToHide"+__c.SmartStringFormatter("",(Object)(_id))+" = tblhead"+__c.SmartStringFormatter("",(Object)(_id))+".filter(\"."+__c.SmartStringFormatter("",(Object)(_colfieldname))+"\");\n"+"    var index"+__c.SmartStringFormatter("",(Object)(_id))+" = colToHide"+__c.SmartStringFormatter("",(Object)(_id))+".index();\n"+"    tbl"+__c.SmartStringFormatter("",(Object)(_id))+".find('tr :nth-child(' + (index"+__c.SmartStringFormatter("",(Object)(_id))+" + 1) + ')').toggle();");
 //BA.debugLineNum = 676;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 677;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _cclass) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 99;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 100;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 101;BA.debugLine="ID = sID.ToLowerCase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 102;BA.debugLine="pTable.Initialize(App,ID & \"p\",False,\"\")";
_ptable._initialize(ba,_app,_id+"p",__c.False,"");
 //BA.debugLineNum = 103;BA.debugLine="pTable.AddRowsM(1,0,0,\"\",\"\").AddColumnsOSMP(1,0,0";
_ptable._addrowsm((int) (1),(int) (0),(int) (0),"","")._addcolumnsosmp((int) (1),(int) (0),(int) (0),(int) (0),(int) (12),(int) (12),(int) (12),(int) (0),(int) (0),(int) (0),(int) (0),"","");
 //BA.debugLineNum = 104;BA.debugLine="el.Initialize(ID,\"table\")";
_el._initialize(ba,_id,"table");
 //BA.debugLineNum = 105;BA.debugLine="el.AddClass(cClass).SetNAME(ID)";
_el._addclass(_cclass)._setname(_id);
 //BA.debugLineNum = 106;BA.debugLine="el.AddStyleAttribute(\"border-collapse\",  \"collaps";
_el._addstyleattribute("border-collapse","collapse");
 //BA.debugLineNum = 107;BA.debugLine="thead.Initialize($\"${ID}thead\"$,\"thead\")";
_thead._initialize(ba,(""+__c.SmartStringFormatter("",(Object)(_id))+"thead"),"thead");
 //BA.debugLineNum = 108;BA.debugLine="tbody.Initialize($\"${ID}body\"$,\"tbody\")";
_tbody._initialize(ba,(""+__c.SmartStringFormatter("",(Object)(_id))+"body"),"tbody");
 //BA.debugLineNum = 109;BA.debugLine="tfoot.Initialize($\"${ID}foot\"$,\"tfoot\")";
_tfoot._initialize(ba,(""+__c.SmartStringFormatter("",(Object)(_id))+"foot"),"tfoot");
 //BA.debugLineNum = 110;BA.debugLine="Fields.Initialize";
_fields.Initialize();
 //BA.debugLineNum = 111;BA.debugLine="Fields.clear";
_fields.Clear();
 //BA.debugLineNum = 112;BA.debugLine="Rows.Initialize";
_rows.Initialize();
 //BA.debugLineNum = 113;BA.debugLine="Rows.clear";
_rows.Clear();
 //BA.debugLineNum = 114;BA.debugLine="Columns.Initialize";
_columns.Initialize();
 //BA.debugLineNum = 115;BA.debugLine="Columns.clear";
_columns.Clear();
 //BA.debugLineNum = 116;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 117;BA.debugLine="Striped = False";
_striped = __c.False;
 //BA.debugLineNum = 118;BA.debugLine="Highlight = False";
_highlight = __c.False;
 //BA.debugLineNum = 119;BA.debugLine="Headers.Initialize";
_headers.Initialize();
 //BA.debugLineNum = 120;BA.debugLine="Headers.clear";
_headers.Clear();
 //BA.debugLineNum = 121;BA.debugLine="HasBorder = True";
_hasborder = __c.True;
 //BA.debugLineNum = 122;BA.debugLine="OverFlow = False";
_overflow = __c.False;
 //BA.debugLineNum = 123;BA.debugLine="OnRowClick = \"\"";
_onrowclick = "";
 //BA.debugLineNum = 124;BA.debugLine="ActiveRow = \"activerow\"";
_activerow = "activerow";
 //BA.debugLineNum = 125;BA.debugLine="Caption = \"\"";
_caption = "";
 //BA.debugLineNum = 126;BA.debugLine="HeaderRows.Initialize";
_headerrows.Initialize();
 //BA.debugLineNum = 127;BA.debugLine="HeaderRows.clear";
_headerrows.Clear();
 //BA.debugLineNum = 128;BA.debugLine="FooterRows.Initialize";
_footerrows.Initialize();
 //BA.debugLineNum = 129;BA.debugLine="FooterRows.clear";
_footerrows.Clear();
 //BA.debugLineNum = 130;BA.debugLine="CanExport = False";
_canexport = __c.False;
 //BA.debugLineNum = 131;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoehtml  _newrow(String _rkey,anywheresoftware.b4a.objects.collections.List _data,anywheresoftware.b4a.objects.collections.List _datatheme,anywheresoftware.b4a.objects.collections.List _dataclass) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _tr1 = null;
int _hdrtot = 0;
int _hdrcnt = 0;
String _cell = "";
String _dkey = "";
String _hdrstr = "";
b4j.Mashy.UOEBANano.uoehtml _td = null;
boolean _hasheader = false;
b4j.Mashy.UOEBANano.uoehtml _th = null;
String _colalignment = "";
String _colfield = "";
String _tdtheme = "";
String _tdclass = "";
 //BA.debugLineNum = 534;BA.debugLine="private Sub NewRow(rKey As String,data As List,dat";
 //BA.debugLineNum = 536;BA.debugLine="Dim tr1 As UOEHTML";
_tr1 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 537;BA.debugLine="tr1.Initialize(rKey,\"tr\")";
_tr1._initialize(ba,_rkey,"tr");
 //BA.debugLineNum = 539;BA.debugLine="Dim hdrTot As Int = data.Size - 1";
_hdrtot = (int) (_data.getSize()-1);
 //BA.debugLineNum = 540;BA.debugLine="Dim hdrCnt As Int";
_hdrcnt = 0;
 //BA.debugLineNum = 542;BA.debugLine="For hdrCnt = 0 To hdrTot";
{
final int step5 = 1;
final int limit5 = _hdrtot;
_hdrcnt = (int) (0) ;
for (;_hdrcnt <= limit5 ;_hdrcnt = _hdrcnt + step5 ) {
 //BA.debugLineNum = 544;BA.debugLine="Dim cell As String = data.Get(hdrCnt)";
_cell = BA.ObjectToString(_data.Get(_hdrcnt));
 //BA.debugLineNum = 546;BA.debugLine="Dim dKey As String = $\"${rKey}_c${hdrCnt}\"$";
_dkey = (""+__c.SmartStringFormatter("",(Object)(_rkey))+"_c"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 548;BA.debugLine="Dim hdrStr As String = $\"head${hdrCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_hdrcnt))+"");
 //BA.debugLineNum = 549;BA.debugLine="Dim td As UOEHTML";
_td = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 550;BA.debugLine="td.Initialize(dKey,\"td\")";
_td._initialize(ba,_dkey,"td");
 //BA.debugLineNum = 551;BA.debugLine="td.AddContent(cell)";
_td._addcontent(_cell);
 //BA.debugLineNum = 553;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(h";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 554;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 555;BA.debugLine="Dim th As UOEHTML = Headers.Get(hdrStr)";
_th = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 556;BA.debugLine="Dim colAlignment As String = th.GetStyleAttribu";
_colalignment = _th._getstyleattribute("text-align");
 //BA.debugLineNum = 557;BA.debugLine="Dim colField As String = th.GetAttribute(\"name\"";
_colfield = _th._getattribute("name");
 //BA.debugLineNum = 559;BA.debugLine="td.AddStyleAttribute(\"text-align\", colAlignment";
_td._addstyleattribute("text-align",_colalignment);
 //BA.debugLineNum = 560;BA.debugLine="td.setname(colField)";
_td._setname(_colfield);
 //BA.debugLineNum = 561;BA.debugLine="td.AddClass(colField)";
_td._addclass(_colfield);
 };
 //BA.debugLineNum = 564;BA.debugLine="If dataTheme <> Null And hdrCnt <= dataTheme.Siz";
if (_datatheme!= null && _hdrcnt<=_datatheme.getSize()) { 
 //BA.debugLineNum = 565;BA.debugLine="Dim tdTheme As String = dataTheme.Get(hdrCnt)";
_tdtheme = BA.ObjectToString(_datatheme.Get(_hdrcnt));
 //BA.debugLineNum = 566;BA.debugLine="App.MaterialUseTheme(tdTheme,td)";
_app._materialusetheme(_tdtheme,_td);
 };
 //BA.debugLineNum = 569;BA.debugLine="If dataClass <> Null And hdrCnt <= dataClass.Siz";
if (_dataclass!= null && _hdrcnt<=_dataclass.getSize()) { 
 //BA.debugLineNum = 570;BA.debugLine="Dim tdClass As String = dataClass.Get(hdrCnt)";
_tdclass = BA.ObjectToString(_dataclass.Get(_hdrcnt));
 //BA.debugLineNum = 571;BA.debugLine="td.AddClass(tdClass)";
_td._addclass(_tdclass);
 };
 //BA.debugLineNum = 573;BA.debugLine="tr1.AddElement(td)";
_tr1._addelement(_td);
 }
};
 //BA.debugLineNum = 575;BA.debugLine="Return tr1";
if (true) return _tr1;
 //BA.debugLineNum = 576;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 730;BA.debugLine="Sub RemoveAttribute(attr As String) As UOETable";
 //BA.debugLineNum = 731;BA.debugLine="el.RemoveAttribute(attr)";
_el._removeattribute(_attr);
 //BA.debugLineNum = 732;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 733;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoetable  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 718;BA.debugLine="Sub RemoveClass(sClass As String) As UOETable";
 //BA.debugLineNum = 719;BA.debugLine="el.RemoveClass(sClass)";
_el._removeclass(_sclass);
 //BA.debugLineNum = 720;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoetable)(this);
 //BA.debugLineNum = 721;BA.debugLine="End Sub";
return null;
}
public String  _tableexport() throws Exception{
String _script = "";
 //BA.debugLineNum = 81;BA.debugLine="Sub TableExport() As String";
 //BA.debugLineNum = 82;BA.debugLine="Dim script As String = $\"${j}(\"${ID}\").tableExpor";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"(\""+__c.SmartStringFormatter("",(Object)(_id))+"\").tableExport();");
 //BA.debugLineNum = 83;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
int _mtot = 0;
b4j.Mashy.UOEBANano.uoehtml _tr = null;
int _mcnt = 0;
String _hdrstr = "";
boolean _hasheader = false;
b4j.Mashy.UOEBANano.uoehtml _hdr = null;
b4j.Mashy.UOEBANano.uoehtml _cap = null;
 //BA.debugLineNum = 607;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 611;BA.debugLine="pTable.ZDepth = ZDepth";
_ptable._zdepth = _zdepth;
 //BA.debugLineNum = 612;BA.debugLine="el.MaterialEnable(Enabled)";
_el._materialenable(_enabled);
 //BA.debugLineNum = 613;BA.debugLine="el.MaterialVisibility(Visibility)";
_el._materialvisibility(_visibility);
 //BA.debugLineNum = 614;BA.debugLine="el.AddClassOnCondition(Striped,\"striped\")";
_el._addclassoncondition(_striped,"striped");
 //BA.debugLineNum = 615;BA.debugLine="el.AddClassOnCondition(Highlight,\"highlight\")";
_el._addclassoncondition(_highlight,"highlight");
 //BA.debugLineNum = 616;BA.debugLine="el.AddClassOnCondition(Centered,\"centered\")";
_el._addclassoncondition(_centered,"centered");
 //BA.debugLineNum = 617;BA.debugLine="el.AddClassOnCondition(Responsive,\"responsive-tab";
_el._addclassoncondition(_responsive,"responsive-table");
 //BA.debugLineNum = 619;BA.debugLine="Dim mTot As Int = Headers.Size - 1";
_mtot = (int) (_headers.getSize()-1);
 //BA.debugLineNum = 620;BA.debugLine="If Headers.Size >= 0 Then";
if (_headers.getSize()>=0) { 
 //BA.debugLineNum = 621;BA.debugLine="Dim tr As UOEHTML";
_tr = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 622;BA.debugLine="tr.Initialize(\"\",\"tr\")";
_tr._initialize(ba,"","tr");
 //BA.debugLineNum = 623;BA.debugLine="Dim mCnt As Int";
_mcnt = 0;
 //BA.debugLineNum = 624;BA.debugLine="For mCnt = 0 To mTot";
{
final int step13 = 1;
final int limit13 = _mtot;
_mcnt = (int) (0) ;
for (;_mcnt <= limit13 ;_mcnt = _mcnt + step13 ) {
 //BA.debugLineNum = 625;BA.debugLine="Dim hdrStr As String = $\"head${mCnt}\"$";
_hdrstr = ("head"+__c.SmartStringFormatter("",(Object)(_mcnt))+"");
 //BA.debugLineNum = 626;BA.debugLine="Dim hasHeader As Boolean = Headers.ContainsKey(";
_hasheader = _headers.ContainsKey((Object)(_hdrstr));
 //BA.debugLineNum = 627;BA.debugLine="If hasHeader Then";
if (_hasheader) { 
 //BA.debugLineNum = 628;BA.debugLine="Dim hdr As UOEHTML = Headers.Get(hdrStr)";
_hdr = (b4j.Mashy.UOEBANano.uoehtml)(_headers.Get((Object)(_hdrstr)));
 //BA.debugLineNum = 629;BA.debugLine="tr.AddElement(hdr)";
_tr._addelement(_hdr);
 };
 }
};
 //BA.debugLineNum = 632;BA.debugLine="thead.AddElement(tr)";
_thead._addelement(_tr);
 };
 //BA.debugLineNum = 635;BA.debugLine="thead.AddContentList(HeaderRows)";
_thead._addcontentlist(_headerrows);
 //BA.debugLineNum = 636;BA.debugLine="If Caption.Length > 0 Then";
if (_caption.length()>0) { 
 //BA.debugLineNum = 637;BA.debugLine="Dim cap As UOEHTML";
_cap = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 638;BA.debugLine="cap.Initialize(ID & \"-caption\",\"caption\")";
_cap._initialize(ba,_id+"-caption","caption");
 //BA.debugLineNum = 639;BA.debugLine="cap.AddContent(Caption)";
_cap._addcontent(_caption);
 //BA.debugLineNum = 640;BA.debugLine="el.AddElement(cap)";
_el._addelement(_cap);
 };
 //BA.debugLineNum = 642;BA.debugLine="el.AddElement(thead)";
_el._addelement(_thead);
 //BA.debugLineNum = 643;BA.debugLine="tfoot.AddContentList(FooterRows)";
_tfoot._addcontentlist(_footerrows);
 //BA.debugLineNum = 644;BA.debugLine="el.AddElement(tfoot)";
_el._addelement(_tfoot);
 //BA.debugLineNum = 645;BA.debugLine="tbody.AddContentList(Rows)";
_tbody._addcontentlist(_rows);
 //BA.debugLineNum = 646;BA.debugLine="el.AddElement(tbody)";
_el._addelement(_tbody);
 //BA.debugLineNum = 652;BA.debugLine="pTable.AddComponent(1,1,el.html)";
_ptable._addcomponent((int) (1),(int) (1),_el._html());
 //BA.debugLineNum = 653;BA.debugLine="pTable.AddStyleAttributeOnCondition(OverFlow,\"ove";
_ptable._addstyleattributeoncondition(_overflow,"overflow-x","auto");
 //BA.debugLineNum = 666;BA.debugLine="Return pTable.tostring";
if (true) return _ptable._tostring();
 //BA.debugLineNum = 667;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
