package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeprogress extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeprogress", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeprogress.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _el = null;
public int _percentage = 0;
public b4j.Mashy.UOEBANano.uoehtml _perc = null;
public boolean _mdeterminate = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeprogress  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 66;BA.debugLine="el.AddAttribute(attr,value)";
_el._addattribute(_attr,_value);
 //BA.debugLineNum = 67;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprogress  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub AddClass(sClass As String) As UOEProgress";
 //BA.debugLineNum = 54;BA.debugLine="el.AddClass(sClass)";
_el._addclass(_sclass);
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprogress  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 17;BA.debugLine="el.AddStyleAttribute(attribute,value)";
_el._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 18;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 6;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 7;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 8;BA.debugLine="Private el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Percentage As Int";
_percentage = 0;
 //BA.debugLineNum = 10;BA.debugLine="Private perc As UOEHTML";
_perc = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Private mDeterminate As Boolean";
_mdeterminate = false;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeprogress  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,boolean _determinate,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 22;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 24;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 25;BA.debugLine="ID = sID.ToLowerCase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 26;BA.debugLine="el.Initialize(ID,\"div\")";
_el._initialize(ba,_id,"div");
 //BA.debugLineNum = 27;BA.debugLine="el.AddClass(\"progress\")";
_el._addclass("progress");
 //BA.debugLineNum = 28;BA.debugLine="mDeterminate = Determinate";
_mdeterminate = _determinate;
 //BA.debugLineNum = 29;BA.debugLine="Percentage = 0";
_percentage = (int) (0);
 //BA.debugLineNum = 30;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 31;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprogress  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEProgress";
 //BA.debugLineNum = 72;BA.debugLine="el.RemoveAttribute(attr)";
_el._removeattribute(_attr);
 //BA.debugLineNum = 73;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprogress  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Sub RemoveClass(sClass As String) As UOEProgress";
 //BA.debugLineNum = 60;BA.debugLine="el.RemoveClass(sClass)";
_el._removeclass(_sclass);
 //BA.debugLineNum = 61;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprogress)(this);
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 36;BA.debugLine="el.MaterialVisibility(Visibility)";
_el._materialvisibility(_visibility);
 //BA.debugLineNum = 37;BA.debugLine="perc.Initialize(\"\",\"div\")";
_perc._initialize(ba,"","div");
 //BA.debugLineNum = 38;BA.debugLine="perc.AddClassOnCondition(mDeterminate,\"determinat";
_perc._addclassoncondition(_mdeterminate,"determinate");
 //BA.debugLineNum = 39;BA.debugLine="perc.AddStyleAttribute(\"width\",$\"${Percentage}%\"$";
_perc._addstyleattribute("width",(""+__c.SmartStringFormatter("",(Object)(_percentage))+"%"));
 //BA.debugLineNum = 40;BA.debugLine="If mDeterminate = False Then";
if (_mdeterminate==__c.False) { 
 //BA.debugLineNum = 41;BA.debugLine="perc.AddClassOnFalseCondition(False,\"indetermina";
_perc._addclassonfalsecondition(__c.False,"indeterminate");
 };
 //BA.debugLineNum = 43;BA.debugLine="el.AddElement(perc)";
_el._addelement(_perc);
 //BA.debugLineNum = 48;BA.debugLine="App.ApplyToolTip(ID,perc)";
_app._applytooltip(_id,_perc);
 //BA.debugLineNum = 49;BA.debugLine="Return el.html";
if (true) return _el._html();
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
