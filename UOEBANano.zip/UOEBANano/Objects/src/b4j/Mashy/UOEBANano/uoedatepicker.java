package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoedatepicker extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoedatepicker", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoedatepicker.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _title = "";
public String _theme = "";
public boolean _enabled = false;
public String _iconname = "";
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _displaytype = "";
public boolean _autoclose = false;
public String _datetimeformat = "";
public String _defaultdate = "";
public boolean _setdefaultdate = false;
public boolean _disableweekends = false;
public int _firstday = 0;
public int _yearrange = 0;
public boolean _showmonthafteryear = false;
public boolean _showdaysinnextandpreviousmonths = false;
public boolean _showclearbtn = false;
public boolean _twelvehour = false;
public String _defaulttime = "";
public boolean _vibrate = false;
public String _timeformat = "";
public String _timeview = "";
public String _instance = "";
public String _settings = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 50;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub AddClass(sClass As String)";
 //BA.debugLineNum = 40;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public String  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 34;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Title As String";
_title = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 11;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Public DisplayType As String";
_displaytype = "";
 //BA.debugLineNum = 13;BA.debugLine="Public autoClose As Boolean";
_autoclose = false;
 //BA.debugLineNum = 14;BA.debugLine="Public DateTimeFormat As String";
_datetimeformat = "";
 //BA.debugLineNum = 15;BA.debugLine="Public defaultDate As String";
_defaultdate = "";
 //BA.debugLineNum = 16;BA.debugLine="Public setDefaultDate As Boolean";
_setdefaultdate = false;
 //BA.debugLineNum = 17;BA.debugLine="Public disableWeekends As Boolean";
_disableweekends = false;
 //BA.debugLineNum = 18;BA.debugLine="Public firstDay As Int";
_firstday = 0;
 //BA.debugLineNum = 19;BA.debugLine="Public yearRange As Int";
_yearrange = 0;
 //BA.debugLineNum = 20;BA.debugLine="Public showMonthAfterYear As Boolean";
_showmonthafteryear = false;
 //BA.debugLineNum = 21;BA.debugLine="Public showDaysInNextAndPreviousMonths As Boolean";
_showdaysinnextandpreviousmonths = false;
 //BA.debugLineNum = 22;BA.debugLine="Public showClearBtn As Boolean";
_showclearbtn = false;
 //BA.debugLineNum = 23;BA.debugLine="Public twelveHour As Boolean";
_twelvehour = false;
 //BA.debugLineNum = 24;BA.debugLine="Public defaultTime As String";
_defaulttime = "";
 //BA.debugLineNum = 25;BA.debugLine="Public vibrate As Boolean";
_vibrate = false;
 //BA.debugLineNum = 26;BA.debugLine="Public TimeFormat As String";
_timeformat = "";
 //BA.debugLineNum = 27;BA.debugLine="Public TimeView As String";
_timeview = "";
 //BA.debugLineNum = 28;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 29;BA.debugLine="Public Settings As String";
_settings = "";
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
public String  _getdate(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 189;BA.debugLine="Sub GetDate(varName As String) As String";
 //BA.debugLineNum = 190;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Datepicker.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".toString();");
 //BA.debugLineNum = 193;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _dpsettings = null;
String _strds = "";
 //BA.debugLineNum = 89;BA.debugLine="public Sub GetSettings As String";
 //BA.debugLineNum = 90;BA.debugLine="Dim dpSettings As Map";
_dpsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 91;BA.debugLine="dpSettings.Initialize";
_dpsettings.Initialize();
 //BA.debugLineNum = 92;BA.debugLine="dpSettings.clear";
_dpsettings.Clear();
 //BA.debugLineNum = 93;BA.debugLine="dpSettings.Put(\"id\", ID)";
_dpsettings.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 94;BA.debugLine="dpSettings.Put(\"instance\", DisplayType)";
_dpsettings.Put((Object)("instance"),(Object)(_displaytype));
 //BA.debugLineNum = 95;BA.debugLine="dpSettings.Put(\"displayType\", DisplayType)";
_dpsettings.Put((Object)("displayType"),(Object)(_displaytype));
 //BA.debugLineNum = 96;BA.debugLine="dpSettings.Put(\"showClearBtn\", showClearBtn)";
_dpsettings.Put((Object)("showClearBtn"),(Object)(_showclearbtn));
 //BA.debugLineNum = 97;BA.debugLine="dpSettings.Put(\"showDaysInNextAndPreviousMonths\",";
_dpsettings.Put((Object)("showDaysInNextAndPreviousMonths"),(Object)(_showdaysinnextandpreviousmonths));
 //BA.debugLineNum = 98;BA.debugLine="dpSettings.Put(\"showMonthAfterYear\", showMonthAft";
_dpsettings.Put((Object)("showMonthAfterYear"),(Object)(_showmonthafteryear));
 //BA.debugLineNum = 99;BA.debugLine="dpSettings.Put(\"yearRange\", yearRange)";
_dpsettings.Put((Object)("yearRange"),(Object)(_yearrange));
 //BA.debugLineNum = 100;BA.debugLine="dpSettings.Put(\"firstDay\", firstDay)";
_dpsettings.Put((Object)("firstDay"),(Object)(_firstday));
 //BA.debugLineNum = 101;BA.debugLine="dpSettings.Put(\"disableWeekends\", disableWeekends";
_dpsettings.Put((Object)("disableWeekends"),(Object)(_disableweekends));
 //BA.debugLineNum = 102;BA.debugLine="dpSettings.Put(\"setDefaultDate\", setDefaultDate)";
_dpsettings.Put((Object)("setDefaultDate"),(Object)(_setdefaultdate));
 //BA.debugLineNum = 103;BA.debugLine="dpSettings.Put(\"format\", DateTimeFormat)";
_dpsettings.Put((Object)("format"),(Object)(_datetimeformat));
 //BA.debugLineNum = 104;BA.debugLine="dpSettings.Put(\"autoClose\", autoClose)";
_dpsettings.Put((Object)("autoClose"),(Object)(_autoclose));
 //BA.debugLineNum = 105;BA.debugLine="dpSettings.Put(\"twelveHour\", twelveHour)";
_dpsettings.Put((Object)("twelveHour"),(Object)(_twelvehour));
 //BA.debugLineNum = 106;BA.debugLine="dpSettings.Put(\"defaultTime\", defaultTime)";
_dpsettings.Put((Object)("defaultTime"),(Object)(_defaulttime));
 //BA.debugLineNum = 107;BA.debugLine="dpSettings.Put(\"vibrate\", vibrate)";
_dpsettings.Put((Object)("vibrate"),(Object)(_vibrate));
 //BA.debugLineNum = 108;BA.debugLine="dpSettings.Put(\"TimeView\", TimeView)";
_dpsettings.Put((Object)("TimeView"),(Object)(_timeview));
 //BA.debugLineNum = 109;BA.debugLine="Dim strDS As String = App.Map2JSON(dpSettings)";
_strds = _app._map2json(_dpsettings);
 //BA.debugLineNum = 110;BA.debugLine="Return strDS";
if (true) return _strds;
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _gettime(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 197;BA.debugLine="Sub GetTime(varName As String) As String";
 //BA.debugLineNum = 198;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Timepicker.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".time();");
 //BA.debugLineNum = 201;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return "";
}
public String  _gotodate(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 214;BA.debugLine="Sub GoToDate(varName As String) As String";
 //BA.debugLineNum = 215;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Datepicker.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".gotoDate("+__c.SmartStringFormatter("",(Object)(_varname))+");");
 //BA.debugLineNum = 218;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 219;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,String _sdisplaytype,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 59;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 61;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 62;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 63;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 64;BA.debugLine="Element.Initialize(ID,\"input\")";
_element._initialize(ba,_id,"input");
 //BA.debugLineNum = 65;BA.debugLine="Element.SetTYPE(\"text\")";
_element._settype("text");
 //BA.debugLineNum = 66;BA.debugLine="DisplayType = sDisplayType";
_displaytype = _sdisplaytype;
 //BA.debugLineNum = 67;BA.debugLine="autoClose = False";
_autoclose = __c.False;
 //BA.debugLineNum = 68;BA.debugLine="DateTimeFormat = \"yyyy-mm-dd\"";
_datetimeformat = "yyyy-mm-dd";
 //BA.debugLineNum = 69;BA.debugLine="TimeFormat = \"HH:mm\"";
_timeformat = "HH:mm";
 //BA.debugLineNum = 70;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 71;BA.debugLine="Theme = sTHeme";
_theme = _stheme;
 //BA.debugLineNum = 72;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 73;BA.debugLine="IconName = \"\"";
_iconname = "";
 //BA.debugLineNum = 74;BA.debugLine="defaultDate = \"now\"";
_defaultdate = "now";
 //BA.debugLineNum = 75;BA.debugLine="disableWeekends = False";
_disableweekends = __c.False;
 //BA.debugLineNum = 76;BA.debugLine="firstDay = 0";
_firstday = (int) (0);
 //BA.debugLineNum = 77;BA.debugLine="yearRange = 10";
_yearrange = (int) (10);
 //BA.debugLineNum = 78;BA.debugLine="showMonthAfterYear = True";
_showmonthafteryear = __c.True;
 //BA.debugLineNum = 79;BA.debugLine="showDaysInNextAndPreviousMonths = True";
_showdaysinnextandpreviousmonths = __c.True;
 //BA.debugLineNum = 80;BA.debugLine="showClearBtn = True";
_showclearbtn = __c.True;
 //BA.debugLineNum = 81;BA.debugLine="defaultTime = \"now\"";
_defaulttime = "now";
 //BA.debugLineNum = 82;BA.debugLine="vibrate = True";
_vibrate = __c.True;
 //BA.debugLineNum = 83;BA.debugLine="twelveHour = False";
_twelvehour = __c.False;
 //BA.debugLineNum = 84;BA.debugLine="setDefaultDate	= True";
_setdefaultdate = __c.True;
 //BA.debugLineNum = 85;BA.debugLine="TimeView = \"hours\"  'minutes";
_timeview = "hours";
 //BA.debugLineNum = 86;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub RemoveAttribute(attr As String)";
 //BA.debugLineNum = 55;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public String  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Sub RemoveClass(sClass As String)";
 //BA.debugLineNum = 45;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public String  _setdate(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 206;BA.debugLine="Sub SetDate(varName As String) As String";
 //BA.debugLineNum = 207;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Datepicker.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".setDate("+__c.SmartStringFormatter("",(Object)(_varname))+");");
 //BA.debugLineNum = 210;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 211;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
 //BA.debugLineNum = 114;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 115;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 116;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 117;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 118;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 119;BA.debugLine="Element.AddClass(DisplayType)";
_element._addclass(_displaytype);
 //BA.debugLineNum = 120;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 121;BA.debugLine="div.Initialize(ID & \"-div\",\"div\")";
_div._initialize(ba,_id+"-div","div");
 //BA.debugLineNum = 122;BA.debugLine="div.AddClass(\"input-field\")";
_div._addclass("input-field");
 //BA.debugLineNum = 123;BA.debugLine="div.AddClass(\"col\").AddClass(\"s12\").AddClass(\"m12";
_div._addclass("col")._addclass("s12")._addclass("m12")._addclass("l12");
 //BA.debugLineNum = 124;BA.debugLine="div.AddElement(Element)";
_div._addelement(_element);
 //BA.debugLineNum = 126;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 127;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 128;BA.debugLine="lbl.SetFOR(ID).AddContent(Title).AddClass(\"active";
_lbl._setfor(_id)._addcontent(_title)._addclass("active");
 //BA.debugLineNum = 129;BA.debugLine="div.AddElement(lbl)";
_div._addelement(_lbl);
 //BA.debugLineNum = 130;BA.debugLine="Select Case DisplayType";
switch (BA.switchObjectToInt(_displaytype,_app._enumdatetimetype._datepicker,_app._enumdatetimetype._timepicker)) {
case 0: {
 break; }
case 1: {
 break; }
}
;
 //BA.debugLineNum = 147;BA.debugLine="Return div.html";
if (true) return _div._html();
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
