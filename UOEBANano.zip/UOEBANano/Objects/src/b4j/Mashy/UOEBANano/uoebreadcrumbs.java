package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoebreadcrumbs extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoebreadcrumbs", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoebreadcrumbs.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _buttons = null;
public boolean _enabled = false;
public String _visibility = "";
public String _zdepth = "";
public boolean _waveseffect = false;
public String _wavestype = "";
public boolean _wavescircle = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 55;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _addbutton(String _btnid,String _btntext,String _btnnav2,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 66;BA.debugLine="Sub AddButton(btnID As String, btnText As String,";
 //BA.debugLineNum = 67;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 68;BA.debugLine="a.Initialize(btnID,\"a\")";
_a._initialize(ba,_btnid,"a");
 //BA.debugLineNum = 69;BA.debugLine="a.AddAttribute(\"href\",btnNav2)";
_a._addattribute("href",_btnnav2);
 //BA.debugLineNum = 70;BA.debugLine="a.AddClass(\"breadcrumb\").AddContent(btnText)";
_a._addclass("breadcrumb")._addcontent(_btntext);
 //BA.debugLineNum = 71;BA.debugLine="Buttons.Add(a.HTML)";
_buttons.Add((Object)(_a._html()));
 //BA.debugLineNum = 72;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 73;BA.debugLine="App.AddEvent(btnID,\"click\")";
_app._addevent(_btnid,"click");
 };
 //BA.debugLineNum = 75;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub AddClass(sClass As String) As UOEBreadCrumbs";
 //BA.debugLineNum = 43;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 44;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 19;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 20;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 21;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Buttons As List";
_buttons = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 13;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 14;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 15;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 25;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 27;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 28;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 29;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 30;BA.debugLine="Element.Initialize(ID,\"nav\")";
_element._initialize(ba,_id,"nav");
 //BA.debugLineNum = 31;BA.debugLine="Buttons.Initialize";
_buttons.Initialize();
 //BA.debugLineNum = 32;BA.debugLine="Buttons.clear";
_buttons.Clear();
 //BA.debugLineNum = 33;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 34;BA.debugLine="Visibility= \"\"";
_visibility = "";
 //BA.debugLineNum = 35;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 36;BA.debugLine="WavesType= \"\"";
_wavestype = "";
 //BA.debugLineNum = 37;BA.debugLine="WavesEffect = False";
_waveseffect = __c.False;
 //BA.debugLineNum = 38;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEBreadCru";
 //BA.debugLineNum = 61;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 62;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoebreadcrumbs  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub RemoveClass(sClass As String) As UOEBreadCrumb";
 //BA.debugLineNum = 49;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 50;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoebreadcrumbs)(this);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _wrapper = null;
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 79;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 80;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 81;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 82;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 83;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 84;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 85;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 86;BA.debugLine="Element.MaterialWaveseffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 87;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 88;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 89;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 91;BA.debugLine="Dim wrapper As UOEHTML";
_wrapper = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 92;BA.debugLine="wrapper.Initialize(\"\",\"div\")";
_wrapper._initialize(ba,"","div");
 //BA.debugLineNum = 93;BA.debugLine="wrapper.AddClass(\"nav-wrapper\")";
_wrapper._addclass("nav-wrapper");
 //BA.debugLineNum = 95;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 96;BA.debugLine="div.Initialize(\"\",\"div\")";
_div._initialize(ba,"","div");
 //BA.debugLineNum = 97;BA.debugLine="div.AddClass(\"col s12\")";
_div._addclass("col s12");
 //BA.debugLineNum = 98;BA.debugLine="div.AddContentList(Buttons)";
_div._addcontentlist(_buttons);
 //BA.debugLineNum = 100;BA.debugLine="wrapper.AddContent(div.HTML)";
_wrapper._addcontent(_div._html());
 //BA.debugLineNum = 101;BA.debugLine="Element.AddContent(wrapper.HTML)";
_element._addcontent(_wrapper._html());
 //BA.debugLineNum = 106;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
