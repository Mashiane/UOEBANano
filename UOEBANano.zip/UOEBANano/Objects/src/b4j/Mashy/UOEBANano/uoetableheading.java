package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoetableheading extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoetableheading", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoetableheading.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _theme = "";
public String _classname = "";
public String _fieldname = "";
public String _height = "";
public String _width = "";
public String _visibility = "";
public String _alignment = "";
public String _title = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 3;BA.debugLine="Public ClassName As String";
_classname = "";
 //BA.debugLineNum = 4;BA.debugLine="Public FieldName As String";
_fieldname = "";
 //BA.debugLineNum = 5;BA.debugLine="Public Height As String";
_height = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Width As String";
_width = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Alignment As String";
_alignment = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
