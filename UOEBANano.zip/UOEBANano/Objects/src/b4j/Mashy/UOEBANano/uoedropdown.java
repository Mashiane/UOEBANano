package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoedropdown extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoedropdown", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoedropdown.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _text = "";
public String _iconname = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _dp = null;
public b4j.Mashy.UOEBANano.uoehtml _a = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _zdepth = "";
public String _visibility = "";
public boolean _enabled = false;
public anywheresoftware.b4a.objects.collections.Map _dropdownitems = null;
public boolean _isbutton = false;
public boolean _hoverable = false;
public boolean _constrainwidth = false;
public boolean _covertrigger = false;
public boolean _closeonclick = false;
public boolean _hover = false;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoedropdown  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 44;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 45;BA.debugLine="dp.AddAttribute(attr,value)";
_dp._addattribute(_attr,_value);
 //BA.debugLineNum = 46;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdown  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub AddClass(sClass As String) As UOEDropDown";
 //BA.debugLineNum = 33;BA.debugLine="dp.AddClass(sClass)";
_dp._addclass(_sclass);
 //BA.debugLineNum = 34;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdown  _addcontent(String _scontent) throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Sub AddContent(sContent As String) As UOEDropDown";
 //BA.debugLineNum = 94;BA.debugLine="dp.AddContent(sContent)";
_dp._addcontent(_scontent);
 //BA.debugLineNum = 95;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdown  _adddivider(String _themename) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
anywheresoftware.b4a.objects.collections.List _lstitems = null;
 //BA.debugLineNum = 99;BA.debugLine="Sub AddDivider(themeName As String) As UOEDropDown";
 //BA.debugLineNum = 100;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 101;BA.debugLine="div.Initialize(\"\",\"li\")";
_div._initialize(ba,"","li");
 //BA.debugLineNum = 102;BA.debugLine="div.AddClass(\"divider\")";
_div._addclass("divider");
 //BA.debugLineNum = 103;BA.debugLine="App.MaterialUseTheme(themeName,div)";
_app._materialusetheme(_themename,_div);
 //BA.debugLineNum = 104;BA.debugLine="If DropDownItems.ContainsKey(ID) Then";
if (_dropdownitems.ContainsKey((Object)(_id))) { 
 //BA.debugLineNum = 105;BA.debugLine="Dim lstItems As List = DropDownItems.Get(ID)";
_lstitems = new anywheresoftware.b4a.objects.collections.List();
_lstitems.setObject((java.util.List)(_dropdownitems.Get((Object)(_id))));
 //BA.debugLineNum = 106;BA.debugLine="lstItems.Add(div.html)";
_lstitems.Add((Object)(_div._html()));
 //BA.debugLineNum = 107;BA.debugLine="DropDownItems.Put(ID,lstItems)";
_dropdownitems.Put((Object)(_id),(Object)(_lstitems.getObject()));
 };
 //BA.debugLineNum = 109;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return null;
}
public String  _additem(String _itemid,String _itemicon,String _itemtext,String _itemnavigateto,boolean _bhasdivider,boolean _itemactive,String _itemtheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoedropdownitem _dpi = null;
anywheresoftware.b4a.objects.collections.List _lstitems = null;
 //BA.debugLineNum = 113;BA.debugLine="Sub AddItem(itemID As String, itemIcon As String,";
 //BA.debugLineNum = 114;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 115;BA.debugLine="Dim dpi As UOEDropDownItem";
_dpi = new b4j.Mashy.UOEBANano.uoedropdownitem();
 //BA.debugLineNum = 116;BA.debugLine="dpi.Initialize(App,ID,itemID,itemIcon,itemText,it";
_dpi._initialize(ba,_app,_id,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_itemtheme);
 //BA.debugLineNum = 117;BA.debugLine="modUOE.MaterialAddBadge(App,dpi.ai.a,\"\",False,App";
_moduoe._materialaddbadge(_app,_dpi._ai._a,"",__c.False,_app._enumvisibility._hide,__c.True,"",__c.False);
 //BA.debugLineNum = 118;BA.debugLine="dpi.li.MaterialAddDividerOnCondition(bhasDivider,";
_dpi._li._materialadddivideroncondition(_bhasdivider,_app._enumvisibility._visible,_itemtheme);
 //BA.debugLineNum = 120;BA.debugLine="If DropDownItems.ContainsKey(ID) Then";
if (_dropdownitems.ContainsKey((Object)(_id))) { 
 //BA.debugLineNum = 121;BA.debugLine="Dim lstItems As List = DropDownItems.Get(ID)";
_lstitems = new anywheresoftware.b4a.objects.collections.List();
_lstitems.setObject((java.util.List)(_dropdownitems.Get((Object)(_id))));
 //BA.debugLineNum = 122;BA.debugLine="lstItems.Add(dpi.tostring)";
_lstitems.Add((Object)(_dpi._tostring()));
 //BA.debugLineNum = 123;BA.debugLine="DropDownItems.Put(ID,lstItems)";
_dropdownitems.Put((Object)(_id),(Object)(_lstitems.getObject()));
 //BA.debugLineNum = 124;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 125;BA.debugLine="App.AddEvent(dpi.id,\"click\")";
_app._addevent(_dpi._id,"click");
 };
 };
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public String  _additembadge(String _itemid,String _itemtext,String _href,boolean _itemactive,String _badgetext,boolean _badgenew,boolean _bhasdivider,String _itemtheme,String _badgetheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoedropdownitem _dpi = null;
anywheresoftware.b4a.objects.collections.List _lstitems = null;
 //BA.debugLineNum = 131;BA.debugLine="Sub AddItemBadge(itemID As String, itemText As Str";
 //BA.debugLineNum = 132;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 133;BA.debugLine="Dim dpi As UOEDropDownItem";
_dpi = new b4j.Mashy.UOEBANano.uoedropdownitem();
 //BA.debugLineNum = 134;BA.debugLine="dpi.Initialize(App,ID,itemID,\"\",itemText,href,ite";
_dpi._initialize(ba,_app,_id,_itemid,"",_itemtext,_href,_itemactive,_itemtheme);
 //BA.debugLineNum = 135;BA.debugLine="modUOE.MaterialAddBadge(App,dpi.ai.a,badgeText,ba";
_moduoe._materialaddbadge(_app,_dpi._ai._a,_badgetext,_badgenew,_app._enumvisibility._visible,__c.True,_badgetheme,__c.False);
 //BA.debugLineNum = 136;BA.debugLine="dpi.li.MaterialAddDividerOnCondition(bhasDivider,";
_dpi._li._materialadddivideroncondition(_bhasdivider,_app._enumvisibility._visible,_itemtheme);
 //BA.debugLineNum = 138;BA.debugLine="If DropDownItems.ContainsKey(ID) Then";
if (_dropdownitems.ContainsKey((Object)(_id))) { 
 //BA.debugLineNum = 139;BA.debugLine="Dim lstItems As List = DropDownItems.Get(ID)";
_lstitems = new anywheresoftware.b4a.objects.collections.List();
_lstitems.setObject((java.util.List)(_dropdownitems.Get((Object)(_id))));
 //BA.debugLineNum = 140;BA.debugLine="lstItems.Add(dpi.tostring)";
_lstitems.Add((Object)(_dpi._tostring()));
 //BA.debugLineNum = 141;BA.debugLine="DropDownItems.Put(ID,lstItems)";
_dropdownitems.Put((Object)(_id),(Object)(_lstitems.getObject()));
 //BA.debugLineNum = 142;BA.debugLine="If hasEvent = True Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 143;BA.debugLine="App.AddEvent(dp.id,\"click\")";
_app._addevent(_dp._id,"click");
 };
 };
 //BA.debugLineNum = 146;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoedropdown  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 27;BA.debugLine="dp.AddStyleAttribute(attribute,value)";
_dp._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 28;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 6;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Public dp As UOEHTML";
_dp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 10;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 14;BA.debugLine="Private DropDownItems As Map";
_dropdownitems = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 15;BA.debugLine="Public IsButton As Boolean";
_isbutton = false;
 //BA.debugLineNum = 16;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 17;BA.debugLine="Private constrainWidth As Boolean";
_constrainwidth = false;
 //BA.debugLineNum = 18;BA.debugLine="Public coverTrigger As Boolean";
_covertrigger = false;
 //BA.debugLineNum = 19;BA.debugLine="Public closeOnClick As Boolean";
_closeonclick = false;
 //BA.debugLineNum = 20;BA.debugLine="Public hover As Boolean";
_hover = false;
 //BA.debugLineNum = 21;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
String _script = "";
 //BA.debugLineNum = 176;BA.debugLine="Sub Close As String";
 //BA.debugLineNum = 177;BA.debugLine="Dim script As String = $\"${Instance}.close();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".close();");
 //BA.debugLineNum = 178;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 179;BA.debugLine="End Sub";
return "";
}
public String  _destroy() throws Exception{
String _script = "";
 //BA.debugLineNum = 182;BA.debugLine="Sub Destroy As String";
 //BA.debugLineNum = 183;BA.debugLine="Dim script As String = $\"${Instance}.destroy();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".destroy();");
 //BA.debugLineNum = 184;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 185;BA.debugLine="End Sub";
return "";
}
public String  _dropdownel(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 200;BA.debugLine="Sub dropdownEl(varName As String) As String";
 //BA.debugLineNum = 201;BA.debugLine="Dim script As String = $\"${varName} = ${Instance}";
_script = (""+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".dropdownEl;");
 //BA.debugLineNum = 202;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
return "";
}
public String  _focusedindex(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 194;BA.debugLine="Sub focusedIndex(varName As String) As String";
 //BA.debugLineNum = 195;BA.debugLine="Dim script As String = $\"${varName} = ${Instance}";
_script = (""+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".focusedIndex;");
 //BA.debugLineNum = 196;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 197;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _mset = null;
String _sset = "";
 //BA.debugLineNum = 251;BA.debugLine="Sub GetSettings As String";
 //BA.debugLineNum = 252;BA.debugLine="Dim mset As Map";
_mset = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 253;BA.debugLine="mset.Initialize";
_mset.Initialize();
 //BA.debugLineNum = 254;BA.debugLine="mset.clear";
_mset.Clear();
 //BA.debugLineNum = 255;BA.debugLine="mset.Put(\"id\", ID)";
_mset.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 256;BA.debugLine="mset.Put(\"instance\", \"dropdown\")";
_mset.Put((Object)("instance"),(Object)("dropdown"));
 //BA.debugLineNum = 257;BA.debugLine="mset.Put(\"hover\", hover)";
_mset.Put((Object)("hover"),(Object)(_hover));
 //BA.debugLineNum = 258;BA.debugLine="mset.Put(\"closeOnClick\", closeOnClick)";
_mset.Put((Object)("closeOnClick"),(Object)(_closeonclick));
 //BA.debugLineNum = 259;BA.debugLine="mset.Put(\"coverTrigger\", coverTrigger)";
_mset.Put((Object)("coverTrigger"),(Object)(_covertrigger));
 //BA.debugLineNum = 260;BA.debugLine="mset.Put(\"constrainWidth\", constrainWidth)";
_mset.Put((Object)("constrainWidth"),(Object)(_constrainwidth));
 //BA.debugLineNum = 261;BA.debugLine="Dim sset As String = App.Map2Json(mset)";
_sset = _app._map2json(_mset);
 //BA.debugLineNum = 262;BA.debugLine="Return sset";
if (true) return _sset;
 //BA.debugLineNum = 263;BA.debugLine="End Sub";
return "";
}
public String  _getstructure(String _sout) throws Exception{
String _mains = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _kcnt = 0;
int _ktot = 0;
String _drpitem = "";
anywheresoftware.b4a.objects.collections.List _lstx = null;
String _stritem = "";
String _sb1 = "";
 //BA.debugLineNum = 148;BA.debugLine="private Sub GetStructure(sout As String) As String";
 //BA.debugLineNum = 149;BA.debugLine="Dim mains As String";
_mains = "";
 //BA.debugLineNum = 150;BA.debugLine="mains = sout";
_mains = _sout;
 //BA.debugLineNum = 151;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 152;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 153;BA.debugLine="Dim kCnt As Int = 0";
_kcnt = (int) (0);
 //BA.debugLineNum = 154;BA.debugLine="Dim kTot As Int = DropDownItems.Size - 1";
_ktot = (int) (_dropdownitems.getSize()-1);
 //BA.debugLineNum = 155;BA.debugLine="For kCnt = 0 To kTot";
{
final int step7 = 1;
final int limit7 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit7 ;_kcnt = _kcnt + step7 ) {
 //BA.debugLineNum = 156;BA.debugLine="Dim drpItem As String = DropDownItems.GetKeyAt(k";
_drpitem = BA.ObjectToString(_dropdownitems.GetKeyAt(_kcnt));
 //BA.debugLineNum = 157;BA.debugLine="Dim lstx As List = DropDownItems.Get(drpItem)";
_lstx = new anywheresoftware.b4a.objects.collections.List();
_lstx.setObject((java.util.List)(_dropdownitems.Get((Object)(_drpitem))));
 //BA.debugLineNum = 158;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 159;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 160;BA.debugLine="For Each stritem As String In lstx";
{
final anywheresoftware.b4a.BA.IterableList group12 = _lstx;
final int groupLen12 = group12.getSize()
;int index12 = 0;
;
for (; index12 < groupLen12;index12++){
_stritem = BA.ObjectToString(group12.Get(index12));
 //BA.debugLineNum = 161;BA.debugLine="sb.Append(stritem)";
_sb.Append(_stritem);
 }
};
 //BA.debugLineNum = 163;BA.debugLine="Dim sb1 As String = sb.tostring";
_sb1 = _sb.ToString();
 //BA.debugLineNum = 164;BA.debugLine="mains = mains.Replace(drpItem & \"-dropitems\",sb1";
_mains = _mains.replace(_drpitem+"-dropitems",_sb1);
 }
};
 //BA.debugLineNum = 166;BA.debugLine="Return mains";
if (true) return _mains;
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _itemid,String _itemtext,String _itemvisibility,boolean _bisbutton,boolean _bconstrainwidth,String _itemtheme) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 56;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, itemID As";
 //BA.debugLineNum = 58;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 59;BA.debugLine="ID = itemID.tolowercase";
_id = _itemid.toLowerCase();
 //BA.debugLineNum = 60;BA.debugLine="Text = itemText";
_text = _itemtext;
 //BA.debugLineNum = 61;BA.debugLine="IconName = \"keyboard_arrow_right\"";
_iconname = "keyboard_arrow_right";
 //BA.debugLineNum = 62;BA.debugLine="Theme = itemTheme";
_theme = _itemtheme;
 //BA.debugLineNum = 63;BA.debugLine="dp.Initialize(ID & \"-dropdown\",\"li\")";
_dp._initialize(ba,_id+"-dropdown","li");
 //BA.debugLineNum = 64;BA.debugLine="a.Initialize(ID,\"a\")";
_a._initialize(ba,_id,"a");
 //BA.debugLineNum = 65;BA.debugLine="App.MaterialUseTheme(itemTheme,a)";
_app._materialusetheme(_itemtheme,_a);
 //BA.debugLineNum = 66;BA.debugLine="a.MaterialVisibility(itemVisibility)";
_a._materialvisibility(_itemvisibility);
 //BA.debugLineNum = 67;BA.debugLine="a.AddClass(\"dropdown-trigger\")";
_a._addclass("dropdown-trigger");
 //BA.debugLineNum = 68;BA.debugLine="a.AddAttribute(\"href\",\"#\")";
_a._addattribute("href","#");
 //BA.debugLineNum = 69;BA.debugLine="a.AddAttribute(\"data-target\",ID & \"-items\")";
_a._addattribute("data-target",_id+"-items");
 //BA.debugLineNum = 70;BA.debugLine="constrainWidth = bConstrainWidth";
_constrainwidth = _bconstrainwidth;
 //BA.debugLineNum = 71;BA.debugLine="IsButton = bIsButton";
_isbutton = _bisbutton;
 //BA.debugLineNum = 72;BA.debugLine="If bIsButton = False Then";
if (_bisbutton==__c.False) { 
 //BA.debugLineNum = 73;BA.debugLine="a.AddStyleAttribute(\"text-align\", \"center\")";
_a._addstyleattribute("text-align","center");
 };
 //BA.debugLineNum = 77;BA.debugLine="ZDepth=\"\"";
_zdepth = "";
 //BA.debugLineNum = 78;BA.debugLine="Visibility = itemVisibility";
_visibility = _itemvisibility;
 //BA.debugLineNum = 79;BA.debugLine="coverTrigger = False";
_covertrigger = __c.False;
 //BA.debugLineNum = 80;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 81;BA.debugLine="DropDownItems.Initialize";
_dropdownitems.Initialize();
 //BA.debugLineNum = 82;BA.debugLine="DropDownItems.clear";
_dropdownitems.Clear();
 //BA.debugLineNum = 83;BA.debugLine="closeOnClick = True";
_closeonclick = __c.True;
 //BA.debugLineNum = 84;BA.debugLine="hover = True";
_hover = __c.True;
 //BA.debugLineNum = 85;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 86;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 87;BA.debugLine="lst.clear";
_lst.Clear();
 //BA.debugLineNum = 88;BA.debugLine="DropDownItems.Put(ID,lst)";
_dropdownitems.Put((Object)(_id),(Object)(_lst.getObject()));
 //BA.debugLineNum = 89;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _isopen(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 206;BA.debugLine="Sub isOpen(varName As String) As String";
 //BA.debugLineNum = 207;BA.debugLine="Dim script As String = $\"${varName} = ${Instance}";
_script = (""+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".isOpen;");
 //BA.debugLineNum = 208;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 209;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
String _script = "";
 //BA.debugLineNum = 170;BA.debugLine="Sub Open As String";
 //BA.debugLineNum = 171;BA.debugLine="Dim script As String = $\"${Instance}.open();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".open();");
 //BA.debugLineNum = 172;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
return "";
}
public String  _recalculatedimensions() throws Exception{
String _script = "";
 //BA.debugLineNum = 188;BA.debugLine="Sub recalculateDimensions As String";
 //BA.debugLineNum = 189;BA.debugLine="Dim script As String = $\"${Instance}.recalculateD";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".recalculateDimensions();");
 //BA.debugLineNum = 190;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 191;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoedropdown  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEDropDown";
 //BA.debugLineNum = 51;BA.debugLine="dp.RemoveAttribute(attr)";
_dp._removeattribute(_attr);
 //BA.debugLineNum = 52;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 53;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoedropdown  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Sub RemoveClass(sClass As String) As UOEDropDown";
 //BA.debugLineNum = 39;BA.debugLine="dp.RemoveClass(sClass)";
_dp._removeclass(_sclass);
 //BA.debugLineNum = 40;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoedropdown)(this);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _ul = null;
String _sout = "";
 //BA.debugLineNum = 212;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 213;BA.debugLine="a.ID = ID";
_a._id = _id;
 //BA.debugLineNum = 214;BA.debugLine="a.MaterialVisibility(Visibility)";
_a._materialvisibility(_visibility);
 //BA.debugLineNum = 215;BA.debugLine="a.MaterialZDepth(ZDepth)";
_a._materialzdepth(_zdepth);
 //BA.debugLineNum = 216;BA.debugLine="a.MaterialEnable(Enabled)";
_a._materialenable(_enabled);
 //BA.debugLineNum = 217;BA.debugLine="a.MaterialButton(IsButton)";
_a._materialbutton(_isbutton);
 //BA.debugLineNum = 218;BA.debugLine="a.addcontent(Text)";
_a._addcontent(_text);
 //BA.debugLineNum = 219;BA.debugLine="modUOE.MaterialAddIcon(App,a,IconName,\"right\",The";
_moduoe._materialaddicon(_app,_a,_iconname,"right",_theme,__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 220;BA.debugLine="App.MaterialUseTheme(Theme,a)";
_app._materialusetheme(_theme,_a);
 //BA.debugLineNum = 221;BA.debugLine="dp.Addelement(a)";
_dp._addelement(_a);
 //BA.debugLineNum = 223;BA.debugLine="Dim ul As UOEHTML";
_ul = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 224;BA.debugLine="ul.Initialize(ID & \"-items\",\"ul\")";
_ul._initialize(ba,_id+"-items","ul");
 //BA.debugLineNum = 225;BA.debugLine="ul.AddClass(\"dropdown-content\")";
_ul._addclass("dropdown-content");
 //BA.debugLineNum = 226;BA.debugLine="ul.AddContent(ID & \"-dropitems\")";
_ul._addcontent(_id+"-dropitems");
 //BA.debugLineNum = 227;BA.debugLine="dp.AddElement(ul)";
_dp._addelement(_ul);
 //BA.debugLineNum = 228;BA.debugLine="dp.SetElementTypeOnCondition(IsButton, \"div\")";
_dp._setelementtypeoncondition(_isbutton,"div");
 //BA.debugLineNum = 229;BA.debugLine="Dim sout As String = dp.html";
_sout = _dp._html();
 //BA.debugLineNum = 230;BA.debugLine="sout = GetStructure(sout)";
_sout = _getstructure(_sout);
 //BA.debugLineNum = 231;BA.debugLine="sout = sout.Replace(CRLF,\"\")";
_sout = _sout.replace(__c.CRLF,"");
 //BA.debugLineNum = 236;BA.debugLine="App.ApplyToolTip(ID,dp)";
_app._applytooltip(_id,_dp);
 //BA.debugLineNum = 237;BA.debugLine="Return sout";
if (true) return _sout;
 //BA.debugLineNum = 238;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
