package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeanchoricon extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeanchoricon", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeanchoricon.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _a = null;
public String _theme = "";
public boolean _enabled = false;
public boolean _textvisible = false;
public String _text = "";
public String _href = "";
public boolean _isfab = false;
public boolean _click2toggle = false;
public boolean _horizontal = false;
public boolean _istoolbar = false;
public anywheresoftware.b4a.objects.collections.List _buttons = null;
public String _iconname = "";
public String _iconalignment = "";
public boolean _iconcircle = false;
public String _icontheme = "";
public boolean _waveseffect = false;
public String _visibility = "";
public String _wavestype = "";
public boolean _wavescircle = false;
public String _zdepth = "";
public boolean _activator = false;
public boolean _floating = false;
public String _alignment = "";
public boolean _inlist = false;
public boolean _inline = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeanchoricon  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 89;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 90;BA.debugLine="a.AddAttribute(attr,value)";
_a._addattribute(_attr,_value);
 //BA.debugLineNum = 91;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeanchoricon)(this);
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeanchoricon  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 77;BA.debugLine="Sub AddClass(sClass As String) As UOEAnchorIcon";
 //BA.debugLineNum = 78;BA.debugLine="a.AddClass(sClass)";
_a._addclass(_sclass);
 //BA.debugLineNum = 79;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeanchoricon)(this);
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeanchoricon  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 38;BA.debugLine="a.AddStyleAttribute(attribute,value)";
_a._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 39;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeanchoricon)(this);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Public a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Public TextVisible As Boolean";
_textvisible = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 12;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 13;BA.debugLine="Public HREF As String";
_href = "";
 //BA.debugLineNum = 14;BA.debugLine="Public IsFAB As Boolean";
_isfab = false;
 //BA.debugLineNum = 15;BA.debugLine="Public Click2Toggle As Boolean";
_click2toggle = false;
 //BA.debugLineNum = 16;BA.debugLine="Public Horizontal As Boolean";
_horizontal = false;
 //BA.debugLineNum = 17;BA.debugLine="Public IsToolBar As Boolean";
_istoolbar = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Buttons As List";
_buttons = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 19;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 20;BA.debugLine="Public IconAlignment As String";
_iconalignment = "";
 //BA.debugLineNum = 21;BA.debugLine="Public IconCircle As Boolean";
_iconcircle = false;
 //BA.debugLineNum = 22;BA.debugLine="Public IconTheme As String";
_icontheme = "";
 //BA.debugLineNum = 23;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 24;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 25;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 26;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 27;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 28;BA.debugLine="Public Activator As Boolean";
_activator = false;
 //BA.debugLineNum = 29;BA.debugLine="Public Floating As Boolean";
_floating = false;
 //BA.debugLineNum = 30;BA.debugLine="Public Alignment As String";
_alignment = "";
 //BA.debugLineNum = 31;BA.debugLine="Public InList As Boolean";
_inlist = false;
 //BA.debugLineNum = 32;BA.debugLine="Public InLine As Boolean";
_inline = false;
 //BA.debugLineNum = 33;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _itemid,String _itemicon,String _itemiconalign,boolean _itemiconcircle,String _itemtext,String _itemnavigateto,boolean _btextvisible,String _itemtheme,String _itemicontheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, itemID As";
 //BA.debugLineNum = 45;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 46;BA.debugLine="Alignment=\"\"";
_alignment = "";
 //BA.debugLineNum = 47;BA.debugLine="InList = False";
_inlist = __c.False;
 //BA.debugLineNum = 48;BA.debugLine="InLine = False";
_inline = __c.False;
 //BA.debugLineNum = 49;BA.debugLine="Activator = False";
_activator = __c.False;
 //BA.debugLineNum = 50;BA.debugLine="Floating = False";
_floating = __c.False;
 //BA.debugLineNum = 51;BA.debugLine="ID = itemID.tolowercase";
_id = _itemid.toLowerCase();
 //BA.debugLineNum = 52;BA.debugLine="HREF = itemNavigateTo";
_href = _itemnavigateto;
 //BA.debugLineNum = 53;BA.debugLine="TextVisible = bTextVisible";
_textvisible = _btextvisible;
 //BA.debugLineNum = 54;BA.debugLine="Text = itemText";
_text = _itemtext;
 //BA.debugLineNum = 55;BA.debugLine="Theme = itemTheme";
_theme = _itemtheme;
 //BA.debugLineNum = 56;BA.debugLine="IsFAB = False";
_isfab = __c.False;
 //BA.debugLineNum = 57;BA.debugLine="Click2Toggle = False";
_click2toggle = __c.False;
 //BA.debugLineNum = 58;BA.debugLine="Horizontal = False";
_horizontal = __c.False;
 //BA.debugLineNum = 59;BA.debugLine="IsToolBar = False";
_istoolbar = __c.False;
 //BA.debugLineNum = 60;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 61;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 62;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 63;BA.debugLine="IconName = itemIcon";
_iconname = _itemicon;
 //BA.debugLineNum = 64;BA.debugLine="IconAlignment = itemIconAlign";
_iconalignment = _itemiconalign;
 //BA.debugLineNum = 65;BA.debugLine="IconTheme = itemIconTheme";
_icontheme = _itemicontheme;
 //BA.debugLineNum = 66;BA.debugLine="IconCircle = itemIconCircle";
_iconcircle = _itemiconcircle;
 //BA.debugLineNum = 67;BA.debugLine="Buttons.Initialize";
_buttons.Initialize();
 //BA.debugLineNum = 68;BA.debugLine="Buttons.clear";
_buttons.Clear();
 //BA.debugLineNum = 69;BA.debugLine="a.Initialize(ID,\"a\")";
_a._initialize(ba,_id,"a");
 //BA.debugLineNum = 70;BA.debugLine="WavesType = App.EnumWavesType.Light";
_wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 71;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 72;BA.debugLine="WavesEffect = True";
_waveseffect = __c.True;
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeanchoricon  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 95;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEAnchorIc";
 //BA.debugLineNum = 96;BA.debugLine="a.RemoveAttribute(attr)";
_a._removeattribute(_attr);
 //BA.debugLineNum = 97;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeanchoricon)(this);
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeanchoricon  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 83;BA.debugLine="Sub RemoveClass(sClass As String) As UOEAnchorIcon";
 //BA.debugLineNum = 84;BA.debugLine="a.RemoveClass(sClass)";
_a._removeclass(_sclass);
 //BA.debugLineNum = 85;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeanchoricon)(this);
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _fab = null;
b4j.Mashy.UOEBANano.uoehtml _li = null;
String _strbutton = "";
 //BA.debugLineNum = 101;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 103;BA.debugLine="a.ID = ID";
_a._id = _id;
 //BA.debugLineNum = 104;BA.debugLine="a.MaterialWavesEffect(WavesEffect)";
_a._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 105;BA.debugLine="a.SetHRef(HREF)";
_a._sethref(_href);
 //BA.debugLineNum = 106;BA.debugLine="App.MaterialUseTheme(Theme,a)";
_app._materialusetheme(_theme,_a);
 //BA.debugLineNum = 107;BA.debugLine="a.MaterialEnable(Enabled)";
_a._materialenable(_enabled);
 //BA.debugLineNum = 108;BA.debugLine="a.MaterialZDepth(ZDepth)";
_a._materialzdepth(_zdepth);
 //BA.debugLineNum = 109;BA.debugLine="a.MaterialVisibility(Visibility)";
_a._materialvisibility(_visibility);
 //BA.debugLineNum = 111;BA.debugLine="If a.ClassExists(\"fixed-action-btn\") = True Then";
if (_a._classexists("fixed-action-btn")==__c.True) { 
_iconcircle = __c.True;};
 //BA.debugLineNum = 112;BA.debugLine="If a.ClassExists(\"halfway-fab\") = True Then IconC";
if (_a._classexists("halfway-fab")==__c.True) { 
_iconcircle = __c.True;};
 //BA.debugLineNum = 113;BA.debugLine="If a.ClassExists(\"btn-floating\") = True Then Icon";
if (_a._classexists("btn-floating")==__c.True) { 
_iconcircle = __c.True;};
 //BA.debugLineNum = 114;BA.debugLine="modUOE.MaterialAddIcon(App,a,IconName,IconAlignme";
_moduoe._materialaddicon(_app,_a,_iconname,_iconalignment,_icontheme,_iconcircle,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 115;BA.debugLine="a.MaterialWavesType(WavesType)";
_a._materialwavestype(_wavestype);
 //BA.debugLineNum = 116;BA.debugLine="a.MaterialWavesCircle(WavesCircle)";
_a._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 117;BA.debugLine="a.AddClassOnCondition(Activator,\"activator\")";
_a._addclassoncondition(_activator,"activator");
 //BA.debugLineNum = 118;BA.debugLine="a.AddClassOnCondition(Floating, \"btn-floating\")";
_a._addclassoncondition(_floating,"btn-floating");
 //BA.debugLineNum = 119;BA.debugLine="a.AddClass(Alignment)";
_a._addclass(_alignment);
 //BA.debugLineNum = 120;BA.debugLine="If TextVisible = True Then a.AddContent(Text)";
if (_textvisible==__c.True) { 
_a._addcontent(_text);};
 //BA.debugLineNum = 121;BA.debugLine="If IsFAB = True Then";
if (_isfab==__c.True) { 
 //BA.debugLineNum = 122;BA.debugLine="Dim fab As UOEHTML";
_fab = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 123;BA.debugLine="fab.Initialize(ID & \"fab\",\"div\")";
_fab._initialize(ba,_id+"fab","div");
 //BA.debugLineNum = 124;BA.debugLine="fab.AddClass(\"fixed-action-btn\")";
_fab._addclass("fixed-action-btn");
 //BA.debugLineNum = 125;BA.debugLine="fab.AddContent(a.HTML)";
_fab._addcontent(_a._html());
 //BA.debugLineNum = 126;BA.debugLine="fab.MaterialClick2Toggle(Click2Toggle)";
_fab._materialclick2toggle(_click2toggle);
 //BA.debugLineNum = 127;BA.debugLine="fab.MaterialHorizontal(Horizontal)";
_fab._materialhorizontal(_horizontal);
 //BA.debugLineNum = 128;BA.debugLine="fab.MaterialToolBar(IsToolBar)";
_fab._materialtoolbar(_istoolbar);
 //BA.debugLineNum = 135;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 136;BA.debugLine="li.Initialize(\"\",\"ul\")";
_li._initialize(ba,"","ul");
 //BA.debugLineNum = 137;BA.debugLine="For Each strButton As String In Buttons";
{
final anywheresoftware.b4a.BA.IterableList group28 = _buttons;
final int groupLen28 = group28.getSize()
;int index28 = 0;
;
for (; index28 < groupLen28;index28++){
_strbutton = BA.ObjectToString(group28.Get(index28));
 //BA.debugLineNum = 138;BA.debugLine="li.AddContent(strButton)";
_li._addcontent(_strbutton);
 }
};
 //BA.debugLineNum = 140;BA.debugLine="fab.AddContent(li.HTML)";
_fab._addcontent(_li._html());
 //BA.debugLineNum = 141;BA.debugLine="Return fab.html";
if (true) return _fab._html();
 }else {
 //BA.debugLineNum = 143;BA.debugLine="If InList = True Then";
if (_inlist==__c.True) { 
 //BA.debugLineNum = 144;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 145;BA.debugLine="li.Initialize(\"\",\"li\")";
_li._initialize(ba,"","li");
 //BA.debugLineNum = 146;BA.debugLine="If InLine = True Then";
if (_inline==__c.True) { 
 //BA.debugLineNum = 147;BA.debugLine="li.AddStyleAttribute(\"display\",\"inline\")";
_li._addstyleattribute("display","inline");
 };
 //BA.debugLineNum = 149;BA.debugLine="li.AddContent(a.HTML)";
_li._addcontent(_a._html());
 //BA.debugLineNum = 150;BA.debugLine="Return li.html";
if (true) return _li._html();
 }else {
 //BA.debugLineNum = 152;BA.debugLine="Return a.html";
if (true) return _a._html();
 };
 };
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
