package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecheckboxgroup extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecheckboxgroup", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecheckboxgroup.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _title = "";
public String _theme = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _container = null;
public String _visibility = "";
public String _zdepth = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecheckboxgroup  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 67;BA.debugLine="Container.AddAttribute(attr,value)";
_container._addattribute(_attr,_value);
 //BA.debugLineNum = 68;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecheckboxgroup)(this);
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecheckboxgroup  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 54;BA.debugLine="Sub AddClass(sClass As String) As UOECheckBoxGroup";
 //BA.debugLineNum = 55;BA.debugLine="Container.AddClass(sClass)";
_container._addclass(_sclass);
 //BA.debugLineNum = 56;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecheckboxgroup)(this);
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return null;
}
public String  _additem(String _itemid,String _itemvalue,String _itemtext,boolean _binline,boolean _benabled,boolean _bselected) throws Exception{
b4j.Mashy.UOEBANano.uoecheckbox _rad = null;
 //BA.debugLineNum = 78;BA.debugLine="Sub AddItem(itemID As String, itemValue As String,";
 //BA.debugLineNum = 79;BA.debugLine="Dim rad As UOECheckBox";
_rad = new b4j.Mashy.UOEBANano.uoecheckbox();
 //BA.debugLineNum = 80;BA.debugLine="rad.Initialize(App,itemID,ID,itemValue,itemText,\"";
_rad._initialize(ba,_app,_itemid,_id,_itemvalue,_itemtext,"");
 //BA.debugLineNum = 81;BA.debugLine="rad.Checked = bSelected";
_rad._checked = _bselected;
 //BA.debugLineNum = 82;BA.debugLine="rad.Enabled = bEnabled";
_rad._enabled = _benabled;
 //BA.debugLineNum = 83;BA.debugLine="rad.Inline = bInline";
_rad._inline = _binline;
 //BA.debugLineNum = 84;BA.debugLine="Container.AddContent(rad.tostring)";
_container._addcontent(_rad._tostring());
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecheckboxgroup  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 31;BA.debugLine="Container.AddStyleAttribute(attribute,value)";
_container._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecheckboxgroup)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _checkall(String _bstatus) throws Exception{
String _script = "";
 //BA.debugLineNum = 16;BA.debugLine="Sub CheckAll(bStatus As String)";
 //BA.debugLineNum = 17;BA.debugLine="If bStatus = \"1\" Then bStatus = \"true\"";
if ((_bstatus).equals("1")) { 
_bstatus = "true";};
 //BA.debugLineNum = 18;BA.debugLine="If bStatus = \"0\" Then bStatus = \"false\"";
if ((_bstatus).equals("0")) { 
_bstatus = "false";};
 //BA.debugLineNum = 19;BA.debugLine="If bStatus = \"y\" Then bStatus = \"true\"";
if ((_bstatus).equals("y")) { 
_bstatus = "true";};
 //BA.debugLineNum = 20;BA.debugLine="If bStatus = \"n\" Then bStatus = \"false\"";
if ((_bstatus).equals("n")) { 
_bstatus = "false";};
 //BA.debugLineNum = 21;BA.debugLine="If bStatus = True Then bStatus = \"true\"";
if ((_bstatus).equals(BA.ObjectToString(__c.True))) { 
_bstatus = "true";};
 //BA.debugLineNum = 22;BA.debugLine="If bStatus = False Then bStatus = \"false\"";
if ((_bstatus).equals(BA.ObjectToString(__c.False))) { 
_bstatus = "false";};
 //BA.debugLineNum = 23;BA.debugLine="Dim script As String = $\"var tblChkBox${ID} = $('";
_script = ("var tblChkBox"+__c.SmartStringFormatter("",(Object)(_id))+" = $('#"+__c.SmartStringFormatter("",(Object)(_id))+" input:checkbox');\n"+"	console.log(tblChkBox"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	$(tblChkBox"+__c.SmartStringFormatter("",(Object)(_id))+").prop('checked', "+__c.SmartStringFormatter("",(Object)(_bstatus))+");");
 //BA.debugLineNum = 26;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Private Container As UOEHTML";
_container = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 12;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,boolean _bshowtitle,String _themename) throws Exception{
innerInitialize(_ba);
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
 //BA.debugLineNum = 37;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 38;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 39;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 40;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 41;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 42;BA.debugLine="Container.Initialize(ID,\"div\")";
_container._initialize(ba,_id,"div");
 //BA.debugLineNum = 43;BA.debugLine="If bShowTitle Then";
if (_bshowtitle) { 
 //BA.debugLineNum = 44;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 45;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 46;BA.debugLine="lbl.SetFOR(ID).AddContent(sTitle)";
_lbl._setfor(_id)._addcontent(_stitle);
 //BA.debugLineNum = 47;BA.debugLine="App.MaterialUseTheme(themeName,lbl)";
_app._materialusetheme(_themename,_lbl);
 //BA.debugLineNum = 48;BA.debugLine="Container.AddElement(lbl)";
_container._addelement(_lbl);
 };
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecheckboxgroup  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 72;BA.debugLine="Sub RemoveAttribute(attr As String) As UOECheckBox";
 //BA.debugLineNum = 73;BA.debugLine="Container.RemoveAttribute(attr)";
_container._removeattribute(_attr);
 //BA.debugLineNum = 74;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecheckboxgroup)(this);
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecheckboxgroup  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub RemoveClass(sClass As String) As UOECheckBoxGr";
 //BA.debugLineNum = 61;BA.debugLine="Container.RemoveClass(sClass)";
_container._removeclass(_sclass);
 //BA.debugLineNum = 62;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecheckboxgroup)(this);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 89;BA.debugLine="Container.MaterialVisibility(Visibility).Material";
_container._materialvisibility(_visibility)._materialenable(_enabled);
 //BA.debugLineNum = 90;BA.debugLine="App.MaterialUseTheme(Theme,Container)";
_app._materialusetheme(_theme,_container);
 //BA.debugLineNum = 91;BA.debugLine="Container.MaterialZDepth(ZDepth).MaterialVisibili";
_container._materialzdepth(_zdepth)._materialvisibility(_visibility);
 //BA.debugLineNum = 96;BA.debugLine="App.ApplyToolTip(ID,Container)";
_app._applytooltip(_id,_container);
 //BA.debugLineNum = 97;BA.debugLine="Return Container.html";
if (true) return _container._html();
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
