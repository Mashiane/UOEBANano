package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoepage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoepage", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoepage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _theme = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _pagemain = null;
public b4j.Mashy.UOEBANano.uoecontainer _content = null;
public b4j.Mashy.UOEBANano.uoehtml _pageheader = null;
public b4j.Mashy.UOEBANano.uoehtml _pagefooter = null;
public b4j.Mashy.UOEBANano.uoecontainer _footer = null;
public boolean _hasfooter = false;
public boolean _fixedfooter = false;
public boolean _hascopyright = false;
public String _backgroundimage = "";
public b4j.Mashy.UOEBANano.uoenavbar _navbar = null;
public b4j.Mashy.UOEBANano.uoesidebar _drawer = null;
public boolean _autosizelogo = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _addtooltip(String _sid,String _text,String _position,int _delay) throws Exception{
b4j.Mashy.UOEBANano.uoetooltip _tt = null;
 //BA.debugLineNum = 259;BA.debugLine="Sub AddToolTip(sID As String, text As String, posi";
 //BA.debugLineNum = 260;BA.debugLine="sID = sID.tolowercase";
_sid = _sid.toLowerCase();
 //BA.debugLineNum = 261;BA.debugLine="If position = \"\" Then position = App.TooltipPosit";
if ((_position).equals("")) { 
_position = _app._tooltipposition;};
 //BA.debugLineNum = 262;BA.debugLine="If delay = -1 Or delay = 0 Then delay = App.Toolt";
if (_delay==-1 || _delay==0) { 
_delay = (int)(Double.parseDouble(_app._tooltipdelay));};
 //BA.debugLineNum = 263;BA.debugLine="Dim tt As UOEToolTip";
_tt = new b4j.Mashy.UOEBANano.uoetooltip();
 //BA.debugLineNum = 264;BA.debugLine="tt.Initialize(sID,text,position,delay,\"\")";
_tt._initialize(ba,_sid,_text,_position,_delay,"");
 //BA.debugLineNum = 265;BA.debugLine="App.ToolTips.Put(sID,tt)";
_app._tooltips.Put((Object)(_sid),(Object)(_tt));
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return "";
}
public String  _addtooltip1(String _sid,String _text) throws Exception{
 //BA.debugLineNum = 254;BA.debugLine="Sub AddTooltip1(sID As String, text As String)";
 //BA.debugLineNum = 255;BA.debugLine="AddToolTip(sID,text,\"\",-1)";
_addtooltip(_sid,_text,"",(int) (-1));
 //BA.debugLineNum = 256;BA.debugLine="End Sub";
return "";
}
public String  _callmethod(String _sappname,String _sclassname,String _smethod) throws Exception{
String _script = "";
 //BA.debugLineNum = 30;BA.debugLine="Sub CallMethod(sAppName As String, sClassName As S";
 //BA.debugLineNum = 31;BA.debugLine="sAppName = sAppName.ToLowerCase";
_sappname = _sappname.toLowerCase();
 //BA.debugLineNum = 32;BA.debugLine="sClassName = sClassName.ToLowerCase";
_sclassname = _sclassname.toLowerCase();
 //BA.debugLineNum = 33;BA.debugLine="sMethod = sMethod.ToLowerCase";
_smethod = _smethod.toLowerCase();
 //BA.debugLineNum = 34;BA.debugLine="Dim script As String = $\"_banano_${sAppName}_${sC";
_script = ("_banano_"+__c.SmartStringFormatter("",(Object)(_sappname))+"_"+__c.SmartStringFormatter("",(Object)(_sclassname))+"."+__c.SmartStringFormatter("",(Object)(_smethod))+"");
 //BA.debugLineNum = 35;BA.debugLine="script = script.Replace(\"__\",\"_\")";
_script = _script.replace("__","_");
 //BA.debugLineNum = 36;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 6;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 7;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 8;BA.debugLine="Private pageMain As UOEHTML";
_pagemain = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Content As UOEContainer";
_content = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 10;BA.debugLine="Public pageHeader As UOEHTML";
_pageheader = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Private pageFooter As UOEHTML";
_pagefooter = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Public Footer As UOEContainer";
_footer = new b4j.Mashy.UOEBANano.uoecontainer();
 //BA.debugLineNum = 13;BA.debugLine="Public HasFooter As Boolean";
_hasfooter = false;
 //BA.debugLineNum = 14;BA.debugLine="Public FixedFooter As Boolean";
_fixedfooter = false;
 //BA.debugLineNum = 15;BA.debugLine="Public HasCopyright As Boolean";
_hascopyright = false;
 //BA.debugLineNum = 16;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 17;BA.debugLine="Public BackgroundImage As String";
_backgroundimage = "";
 //BA.debugLineNum = 18;BA.debugLine="Public NavBar As UOENavBar";
_navbar = new b4j.Mashy.UOEBANano.uoenavbar();
 //BA.debugLineNum = 19;BA.debugLine="Public Drawer As UOESideBar";
_drawer = new b4j.Mashy.UOEBANano.uoesidebar();
 //BA.debugLineNum = 20;BA.debugLine="Public AutoSizeLogo As Boolean";
_autosizelogo = false;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _create() throws Exception{
String _fcolor = "";
String _bcolor = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _body = null;
String _sdrawer = "";
String _strx = "";
b4j.Mashy.UOEBANano.uoecopyrights _foot = null;
String _sbody = "";
com.ab.banano.BANanoElement _elbody = null;
String _jsonstyle = "";
int _dptot = 0;
int _dpcnt = 0;
String _strds = "";
anywheresoftware.b4a.objects.collections.Map _dpmap = null;
String _instancetype = "";
String _instanceid = "";
com.ab.banano.BANanoObject _dp = null;
int _jstot = 0;
int _jscnt = 0;
String _jscode = "";
int _csstot = 0;
int _csscnt = 0;
String _strcss = "";
anywheresoftware.b4a.objects.collections.Map _cssmap = null;
String _cssid = "";
com.ab.banano.BANanoElement _cssobj = null;
anywheresoftware.b4a.objects.collections.Map _mdrawer = null;
String _strkey = "";
 //BA.debugLineNum = 345;BA.debugLine="public Sub Create()";
 //BA.debugLineNum = 347;BA.debugLine="Dim fColor As String = App.GetForeColorHex(Theme)";
_fcolor = _app._getforecolorhex(_theme);
 //BA.debugLineNum = 348;BA.debugLine="Dim bColor As String = App.GetBackGroundColorHex(";
_bcolor = _app._getbackgroundcolorhex(_theme);
 //BA.debugLineNum = 349;BA.debugLine="If Footer.Theme = \"\" Then Footer.Theme = App.them";
if ((_footer._theme).equals("")) { 
_footer._theme = _app._theme;};
 //BA.debugLineNum = 351;BA.debugLine="Dim body As StringBuilder";
_body = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 352;BA.debugLine="body.Initialize";
_body.Initialize();
 //BA.debugLineNum = 384;BA.debugLine="pageMain.AddContent(Content.ToString)";
_pagemain._addcontent(_content._tostring());
 //BA.debugLineNum = 387;BA.debugLine="Dim sdrawer As String = Drawer.ToString";
_sdrawer = _drawer._tostring();
 //BA.debugLineNum = 388;BA.debugLine="Dim strx As String = Drawer.getSettings";
_strx = _drawer._getsettings();
 //BA.debugLineNum = 389;BA.debugLine="App.Components.Add(strx)";
_app._components.Add((Object)(_strx));
 //BA.debugLineNum = 390;BA.debugLine="Drawer.getCSS";
_drawer._getcss();
 //BA.debugLineNum = 391;BA.debugLine="pageHeader.AddContent(sdrawer)";
_pageheader._addcontent(_sdrawer);
 //BA.debugLineNum = 392;BA.debugLine="pageHeader.AddContent(NavBar.ToString)";
_pageheader._addcontent(_navbar._tostring());
 //BA.debugLineNum = 393;BA.debugLine="body.Append(pageHeader.html)";
_body.Append(_pageheader._html());
 //BA.debugLineNum = 394;BA.debugLine="body.Append(pageMain.html)";
_body.Append(_pagemain._html());
 //BA.debugLineNum = 396;BA.debugLine="If HasFooter Then";
if (_hasfooter) { 
 //BA.debugLineNum = 397;BA.debugLine="App.MaterialUseTheme(Footer.Theme,Footer.element";
_app._materialusetheme(_footer._theme,_footer._element);
 //BA.debugLineNum = 398;BA.debugLine="App.MaterialUseTheme(Footer.Theme,pageFooter)";
_app._materialusetheme(_footer._theme,_pagefooter);
 //BA.debugLineNum = 399;BA.debugLine="pageFooter.AddContent(Footer.ToString)";
_pagefooter._addcontent(_footer._tostring());
 //BA.debugLineNum = 400;BA.debugLine="If HasCopyright Then";
if (_hascopyright) { 
 //BA.debugLineNum = 401;BA.debugLine="Dim foot As UOECopyRights";
_foot = new b4j.Mashy.UOEBANano.uoecopyrights();
 //BA.debugLineNum = 402;BA.debugLine="foot.Initialize(App,\"foot\",Footer.theme)";
_foot._initialize(ba,_app,"foot",_footer._theme);
 //BA.debugLineNum = 403;BA.debugLine="foot.AddTermsAndConditions";
_foot._addtermsandconditions();
 //BA.debugLineNum = 404;BA.debugLine="foot.AddDisclaimer";
_foot._adddisclaimer();
 //BA.debugLineNum = 405;BA.debugLine="foot.AddPrivacyPolicy";
_foot._addprivacypolicy();
 //BA.debugLineNum = 406;BA.debugLine="pageFooter.AddContent(foot.tostring)";
_pagefooter._addcontent(_foot._tostring());
 };
 //BA.debugLineNum = 408;BA.debugLine="body.Append(pageFooter.HTML)";
_body.Append(_pagefooter._html());
 };
 //BA.debugLineNum = 418;BA.debugLine="Dim sBody As String = body.tostring";
_sbody = _body.ToString();
 //BA.debugLineNum = 420;BA.debugLine="Dim elBody As BANanoElement = Banano.GetElement(\"";
_elbody = _banano.GetElement("#body");
 //BA.debugLineNum = 421;BA.debugLine="elBody.Empty";
_elbody.Empty();
 //BA.debugLineNum = 422;BA.debugLine="elBody.SetHTML(sBody)";
_elbody.SetHTML(_sbody);
 //BA.debugLineNum = 423;BA.debugLine="elBody.AddClass(bColor)";
_elbody.AddClass(_bcolor);
 //BA.debugLineNum = 425;BA.debugLine="Banano.Eval(\"M.AutoInit();\")";
_banano.Eval((Object)("M.AutoInit();"));
 //BA.debugLineNum = 428;BA.debugLine="If AutoSizeLogo Then";
if (_autosizelogo) { 
 //BA.debugLineNum = 429;BA.debugLine="Dim jsonStyle As String = $\"{ \"font-size\": \"2.1v";
_jsonstyle = ("{ \"font-size\": \"2.1vw\", \"font-weight\": \"bold\" }");
 //BA.debugLineNum = 430;BA.debugLine="Banano.GetElement(\"#navbar\").SetStyle(jsonStyle)";
_banano.GetElement("#navbar").SetStyle(_jsonstyle);
 };
 //BA.debugLineNum = 434;BA.debugLine="Dim jsonStyle As String = $\"{ \"padding-top\": \"0px";
_jsonstyle = ("{ \"padding-top\": \"0px\" }");
 //BA.debugLineNum = 435;BA.debugLine="Banano.GetElement(\".page-footer\").SetStyle(jsonSt";
_banano.GetElement(".page-footer").SetStyle(_jsonstyle);
 //BA.debugLineNum = 437;BA.debugLine="If FixedFooter Then";
if (_fixedfooter) { 
 //BA.debugLineNum = 438;BA.debugLine="Dim jsonStyle As String = $\"{ \"display\": \"flex\",";
_jsonstyle = ("{ \"display\": \"flex\", \"min-height\": \"100vh\", \"flex-direction\": \"column\" }");
 //BA.debugLineNum = 439;BA.debugLine="Banano.GetElement(\"body\").SetStyle(jsonStyle)";
_banano.GetElement("body").SetStyle(_jsonstyle);
 //BA.debugLineNum = 440;BA.debugLine="Dim jsonStyle As String = $\"{ \"flex\": \"1 0 auto\"";
_jsonstyle = ("{ \"flex\": \"1 0 auto\" }");
 //BA.debugLineNum = 441;BA.debugLine="Banano.GetElement(\"main\").SetStyle(jsonStyle)";
_banano.GetElement("main").SetStyle(_jsonstyle);
 };
 //BA.debugLineNum = 446;BA.debugLine="Banano.Eval(\"M.updateTextFields();\")";
_banano.Eval((Object)("M.updateTextFields();"));
 //BA.debugLineNum = 447;BA.debugLine="Dim dpTot As Int = App.Components.Size - 1";
_dptot = (int) (_app._components.getSize()-1);
 //BA.debugLineNum = 448;BA.debugLine="Dim dpCnt As Int";
_dpcnt = 0;
 //BA.debugLineNum = 449;BA.debugLine="For dpCnt = 0 To dpTot";
{
final int step50 = 1;
final int limit50 = _dptot;
_dpcnt = (int) (0) ;
for (;_dpcnt <= limit50 ;_dpcnt = _dpcnt + step50 ) {
 //BA.debugLineNum = 450;BA.debugLine="Dim strDS As String = App.Components.Get(dpCnt)";
_strds = BA.ObjectToString(_app._components.Get(_dpcnt));
 //BA.debugLineNum = 451;BA.debugLine="Dim dpMap As Map = App.Json2Map(strDS)";
_dpmap = new anywheresoftware.b4a.objects.collections.Map();
_dpmap = _app._json2map(_strds);
 //BA.debugLineNum = 452;BA.debugLine="Dim instancetype As String = dpMap.get(\"instance";
_instancetype = BA.ObjectToString(_dpmap.Get((Object)("instance")));
 //BA.debugLineNum = 453;BA.debugLine="Dim instanceID As String = dpMap.Get(\"id\")";
_instanceid = BA.ObjectToString(_dpmap.Get((Object)("id")));
 //BA.debugLineNum = 455;BA.debugLine="dpMap.Remove(\"instance\")";
_dpmap.Remove((Object)("instance"));
 //BA.debugLineNum = 456;BA.debugLine="dpMap.Remove(\"id\")";
_dpmap.Remove((Object)("id"));
 //BA.debugLineNum = 458;BA.debugLine="Dim dp As BANanoObject";
_dp = new com.ab.banano.BANanoObject();
 //BA.debugLineNum = 459;BA.debugLine="dp = App.jQ.Selector($\"#${instanceID}\"$)";
_dp = _app._jq.Selector((Object)(("#"+__c.SmartStringFormatter("",(Object)(_instanceid))+"")));
 //BA.debugLineNum = 460;BA.debugLine="dp.RunMethod(instancetype, dpMap)";
_dp.RunMethod(_instancetype,(Object)(_dpmap.getObject()));
 }
};
 //BA.debugLineNum = 463;BA.debugLine="Dim jsTot As Int = App.JS.Size - 1";
_jstot = (int) (_app._js.getSize()-1);
 //BA.debugLineNum = 464;BA.debugLine="Dim jsCnt As Int";
_jscnt = 0;
 //BA.debugLineNum = 465;BA.debugLine="For jsCnt = 0 To jsTot";
{
final int step63 = 1;
final int limit63 = _jstot;
_jscnt = (int) (0) ;
for (;_jscnt <= limit63 ;_jscnt = _jscnt + step63 ) {
 //BA.debugLineNum = 466;BA.debugLine="Dim jsCode As String = App.JS.Get(jsCnt)";
_jscode = BA.ObjectToString(_app._js.Get(_jscnt));
 //BA.debugLineNum = 467;BA.debugLine="Banano.eval(jsCode)";
_banano.Eval((Object)(_jscode));
 }
};
 //BA.debugLineNum = 470;BA.debugLine="Dim cssTot As Int = App.CSS.Size - 1";
_csstot = (int) (_app._css.getSize()-1);
 //BA.debugLineNum = 471;BA.debugLine="Dim cssCnt As Int";
_csscnt = 0;
 //BA.debugLineNum = 472;BA.debugLine="For cssCnt = 0 To cssTot";
{
final int step69 = 1;
final int limit69 = _csstot;
_csscnt = (int) (0) ;
for (;_csscnt <= limit69 ;_csscnt = _csscnt + step69 ) {
 //BA.debugLineNum = 473;BA.debugLine="Dim strcss As String = App.CSS.Get(cssCnt)";
_strcss = BA.ObjectToString(_app._css.Get(_csscnt));
 //BA.debugLineNum = 474;BA.debugLine="Dim cssmap As Map = App.Json2Map(strcss)";
_cssmap = new anywheresoftware.b4a.objects.collections.Map();
_cssmap = _app._json2map(_strcss);
 //BA.debugLineNum = 475;BA.debugLine="Dim cssid As String = cssmap.Get(\"id\")";
_cssid = BA.ObjectToString(_cssmap.Get((Object)("id")));
 //BA.debugLineNum = 476;BA.debugLine="cssmap.Remove(\"id\")";
_cssmap.Remove((Object)("id"));
 //BA.debugLineNum = 477;BA.debugLine="strcss = App.Map2Json(cssmap)";
_strcss = _app._map2json(_cssmap);
 //BA.debugLineNum = 478;BA.debugLine="Dim cssobj As BANanoElement";
_cssobj = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 479;BA.debugLine="cssobj = Banano.GetElement(cssid)";
_cssobj = _banano.GetElement(_cssid);
 //BA.debugLineNum = 480;BA.debugLine="cssobj.SetStyle(strcss)";
_cssobj.SetStyle(_strcss);
 }
};
 //BA.debugLineNum = 483;BA.debugLine="Dim mdrawer As Map = App.HeadersToFix";
_mdrawer = new anywheresoftware.b4a.objects.collections.Map();
_mdrawer = _app._headerstofix;
 //BA.debugLineNum = 484;BA.debugLine="For Each strKey As String In mdrawer.Keys";
{
final anywheresoftware.b4a.BA.IterableList group80 = _mdrawer.Keys();
final int groupLen80 = group80.getSize()
;int index80 = 0;
;
for (; index80 < groupLen80;index80++){
_strkey = BA.ObjectToString(group80.Get(index80));
 //BA.debugLineNum = 485;BA.debugLine="App.RemoveEvent(strKey)";
_app._removeevent(_strkey);
 }
};
 //BA.debugLineNum = 487;BA.debugLine="End Sub";
return "";
}
public String  _createe(String _eventsmethod,Object _eventhandler) throws Exception{
 //BA.debugLineNum = 337;BA.debugLine="public Sub CreateE(EventsMethod As String, EVentHa";
 //BA.debugLineNum = 339;BA.debugLine="Create";
_create();
 //BA.debugLineNum = 341;BA.debugLine="App.BindEvents(EventsMethod, EVentHandler)";
_app._bindevents(_eventsmethod,_eventhandler);
 //BA.debugLineNum = 342;BA.debugLine="End Sub";
return "";
}
public String  _enable(String _elid,boolean _bstatus) throws Exception{
String _elkey = "";
 //BA.debugLineNum = 270;BA.debugLine="Sub Enable(elID As String, bStatus As Boolean)";
 //BA.debugLineNum = 271;BA.debugLine="elID = elID.ToLowerCase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 272;BA.debugLine="Dim elKey As String = $\"#${elID}\"$";
_elkey = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 273;BA.debugLine="If bStatus Then";
if (_bstatus) { 
 //BA.debugLineNum = 274;BA.debugLine="removeAttr(elID,\"disabled\")";
_removeattr(_elid,"disabled");
 }else {
 //BA.debugLineNum = 276;BA.debugLine="Banano.GetElement(elKey).SetAttr(\"disabled\",\"tru";
_banano.GetElement(_elkey).SetAttr("disabled","true");
 };
 //BA.debugLineNum = 278;BA.debugLine="End Sub";
return "";
}
public String  _execute(String _jscode) throws Exception{
 //BA.debugLineNum = 333;BA.debugLine="Sub Execute(jsCode As String)";
 //BA.debugLineNum = 334;BA.debugLine="Banano.Eval(jsCode)";
_banano.Eval((Object)(_jscode));
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return "";
}
public com.ab.banano.BANanoElement  _getelementbyname(String _elid) throws Exception{
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 142;BA.debugLine="Sub GetElementByName(elID As String) As BANanoElem";
 //BA.debugLineNum = 143;BA.debugLine="Dim el As BANanoElement = Banano.GetElement($\"[na";
_el = _banano.GetElement(("[name='"+__c.SmartStringFormatter("",(Object)(_elid))+"']"));
 //BA.debugLineNum = 144;BA.debugLine="Return el";
if (true) return _el;
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return null;
}
public String  _getlocalstorage(String _skey) throws Exception{
String _svalue = "";
 //BA.debugLineNum = 47;BA.debugLine="Sub GetLocalStorage(sKey As String) As String";
 //BA.debugLineNum = 48;BA.debugLine="sKey = sKey.ToLowerCase";
_skey = _skey.toLowerCase();
 //BA.debugLineNum = 49;BA.debugLine="Dim svalue As String = Banano.GetLocalStorage(sKe";
_svalue = BA.ObjectToString(_banano.GetLocalStorage(_skey));
 //BA.debugLineNum = 50;BA.debugLine="svalue = App.CStr(svalue)";
_svalue = _app._cstr((Object)(_svalue));
 //BA.debugLineNum = 51;BA.debugLine="svalue = svalue.Replace(\"undefined\",\"\")";
_svalue = _svalue.replace("undefined","");
 //BA.debugLineNum = 52;BA.debugLine="svalue = svalue.Replace(\"null\",\"\")";
_svalue = _svalue.replace("null","");
 //BA.debugLineNum = 53;BA.debugLine="svalue = svalue.trim";
_svalue = _svalue.trim();
 //BA.debugLineNum = 54;BA.debugLine="Return svalue";
if (true) return _svalue;
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public String  _getradio(String _elid) throws Exception{
String _svalue = "";
 //BA.debugLineNum = 148;BA.debugLine="Sub GetRadio(elID As String) As String";
 //BA.debugLineNum = 149;BA.debugLine="elID = elID.tolowercase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 150;BA.debugLine="Dim sValue As String";
_svalue = "";
 //BA.debugLineNum = 151;BA.debugLine="sValue = Banano.RunJavascriptMethod(\"getRadio\",Ar";
_svalue = BA.ObjectToString(_banano.RunJavascriptMethod("getRadio",anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_elid})));
 //BA.debugLineNum = 152;BA.debugLine="Return sValue";
if (true) return _svalue;
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public String  _gettextbox(String _elid) throws Exception{
String _elkey = "";
String _stext = "";
 //BA.debugLineNum = 72;BA.debugLine="Sub GetTextBox(elID As String) As String";
 //BA.debugLineNum = 73;BA.debugLine="elID = elID.tolowercase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 74;BA.debugLine="Dim elKey As String = $\"#${elID}\"$";
_elkey = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 75;BA.debugLine="Dim sText As String = Banano.GetElement(elKey).Ge";
_stext = _banano.GetElement(_elkey).GetValue();
 //BA.debugLineNum = 76;BA.debugLine="sText = sText.trim";
_stext = _stext.trim();
 //BA.debugLineNum = 77;BA.debugLine="Return sText";
if (true) return _stext;
 //BA.debugLineNum = 78;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,boolean _bcenter,String _snavbartitle,String _snavbartitleposition,boolean _bnavbarfixed,boolean _bfixdrawer,String _stheme,String _sclass) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 228;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 229;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 230;BA.debugLine="App.NewPage";
_app._newpage();
 //BA.debugLineNum = 231;BA.debugLine="App.M.Initialize(\"M\")";
_app._m.Initialize((Object)("M"));
 //BA.debugLineNum = 232;BA.debugLine="App.jQ.Initialize(\"$\")";
_app._jq.Initialize((Object)("$"));
 //BA.debugLineNum = 233;BA.debugLine="App.HeadersToFix.Initialize";
_app._headerstofix.Initialize();
 //BA.debugLineNum = 234;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 235;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 236;BA.debugLine="pageMain.Initialize(\"main\",\"main\")";
_pagemain._initialize(ba,"main","main");
 //BA.debugLineNum = 237;BA.debugLine="pageHeader.Initialize(\"header\",\"header\")";
_pageheader._initialize(ba,"header","header");
 //BA.debugLineNum = 238;BA.debugLine="Content.Initialize(App,sID,bCenter,\"\")";
_content._initialize(ba,_app,_sid,_bcenter,"");
 //BA.debugLineNum = 239;BA.debugLine="Content.AddClass(sclass)";
_content._addclass(_sclass);
 //BA.debugLineNum = 240;BA.debugLine="pageFooter.Initialize(\"footer\",\"footer\")";
_pagefooter._initialize(ba,"footer","footer");
 //BA.debugLineNum = 241;BA.debugLine="pageFooter.AddClass(\"page-footer\")";
_pagefooter._addclass("page-footer");
 //BA.debugLineNum = 242;BA.debugLine="Footer.Initialize(App,\"footer\" & sID,bCenter,sThe";
_footer._initialize(ba,_app,"footer"+_sid,_bcenter,_stheme);
 //BA.debugLineNum = 243;BA.debugLine="BackgroundImage = \"\"";
_backgroundimage = "";
 //BA.debugLineNum = 244;BA.debugLine="NavBar.Initialize(App,\"navbar\",sNavBarTitle,sNavB";
_navbar._initialize(ba,_app,"navbar",_snavbartitle,_snavbartitleposition,_bnavbarfixed,_bfixdrawer,_stheme);
 //BA.debugLineNum = 245;BA.debugLine="Drawer = NavBar.drawer";
_drawer = _navbar._drawer;
 //BA.debugLineNum = 246;BA.debugLine="HasCopyright = True";
_hascopyright = __c.True;
 //BA.debugLineNum = 247;BA.debugLine="FixedFooter = True";
_fixedfooter = __c.True;
 //BA.debugLineNum = 248;BA.debugLine="HasFooter = True";
_hasfooter = __c.True;
 //BA.debugLineNum = 249;BA.debugLine="Footer.CenterInPage = False";
_footer._centerinpage = __c.False;
 //BA.debugLineNum = 250;BA.debugLine="Footer.Theme = App.theme";
_footer._theme = _app._theme;
 //BA.debugLineNum = 251;BA.debugLine="End Sub";
return "";
}
public String  _printthis(String _elid) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 40;BA.debugLine="Sub PrintThis(elID As String) As String";
 //BA.debugLineNum = 41;BA.debugLine="elID = elID.tolowercase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 42;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 43;BA.debugLine="Dim script As String = $\"${j}('#${elID}').printTh";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"('#"+__c.SmartStringFormatter("",(Object)(_elid))+"').printThis();");
 //BA.debugLineNum = 44;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public String  _pulse(String _elid,boolean _bstatus) throws Exception{
String _elkey = "";
 //BA.debugLineNum = 490;BA.debugLine="Sub Pulse(elID As String, bStatus As Boolean)";
 //BA.debugLineNum = 491;BA.debugLine="elID = elID.ToLowerCase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 492;BA.debugLine="Dim elKey As String = $\"#${elID}\"$";
_elkey = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 493;BA.debugLine="If bStatus Then";
if (_bstatus) { 
 //BA.debugLineNum = 494;BA.debugLine="Banano.GetElement(elKey).AddClass(\"pulse\")";
_banano.GetElement(_elkey).AddClass("pulse");
 }else {
 //BA.debugLineNum = 496;BA.debugLine="Banano.GetElement(elKey).RemoveClass(\"pulse\")";
_banano.GetElement(_elkey).RemoveClass("pulse");
 };
 //BA.debugLineNum = 498;BA.debugLine="End Sub";
return "";
}
public String  _refresh() throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Sub Refresh";
 //BA.debugLineNum = 82;BA.debugLine="Banano.Eval(\"M.updateTextFields();\")";
_banano.Eval((Object)("M.updateTextFields();"));
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public String  _removeattr(String _elid,String _attrname) throws Exception{
 //BA.debugLineNum = 288;BA.debugLine="Sub removeAttr(elID As String, attrName As String)";
 //BA.debugLineNum = 289;BA.debugLine="elID = elID.tolowercase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 290;BA.debugLine="App.jQ.Selector($\"#${elID}\"$).RunMethod(\"removeAt";
_app._jq.Selector((Object)(("#"+__c.SmartStringFormatter("",(Object)(_elid))+""))).RunMethod("removeAttr",(Object)(new Object[]{(Object)(_attrname)}));
 //BA.debugLineNum = 291;BA.debugLine="End Sub";
return "";
}
public String  _removeattr1(String _elid,String _attrname) throws Exception{
String _ekey = "";
 //BA.debugLineNum = 281;BA.debugLine="Sub removeAttr1(elID As String, attrName As String";
 //BA.debugLineNum = 282;BA.debugLine="elID = elID.ToLowerCase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 283;BA.debugLine="Dim eKey As String = $\"#${elID}\"$";
_ekey = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 284;BA.debugLine="Banano.GetElement(eKey).SetAttr(attrName, Null)";
_banano.GetElement(_ekey).SetAttr(_attrname,BA.ObjectToString(__c.Null));
 //BA.debugLineNum = 285;BA.debugLine="End Sub";
return "";
}
public String  _setlocalstorage(String _skey,String _svalue) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub SetLocalStorage(sKey As String, sValue As Stri";
 //BA.debugLineNum = 58;BA.debugLine="sKey = sKey.ToLowerCase";
_skey = _skey.toLowerCase();
 //BA.debugLineNum = 59;BA.debugLine="Banano.SetLocalStorage(sKey,sValue)";
_banano.SetLocalStorage(_skey,(Object)(_svalue));
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public String  _setradio(String _elid,String _elvalue) throws Exception{
 //BA.debugLineNum = 114;BA.debugLine="Sub SetRadio(elID As String,elValue As String)";
 //BA.debugLineNum = 115;BA.debugLine="Banano.RunJavascriptMethod(\"setRadio\",Array As St";
_banano.RunJavascriptMethod("setRadio",anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{_elid,_elvalue}));
 //BA.debugLineNum = 116;BA.debugLine="End Sub";
return "";
}
public String  _settextbox(String _elid,String _txtvalue) throws Exception{
String _j = "";
com.ab.banano.BANanoElement _el = null;
String _slength = "";
String _itype = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sbcode = null;
String _script = "";
 //BA.debugLineNum = 86;BA.debugLine="Sub setTextBox(elID As String, txtValue As String)";
 //BA.debugLineNum = 87;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 88;BA.debugLine="elID = elID.ToLowerCase";
_elid = _elid.toLowerCase();
 //BA.debugLineNum = 89;BA.debugLine="elID = $\"#${elID}\"$";
_elid = ("#"+__c.SmartStringFormatter("",(Object)(_elid))+"");
 //BA.debugLineNum = 90;BA.debugLine="Dim el As BANanoElement = Banano.GetElement(elID)";
_el = _banano.GetElement(_elid);
 //BA.debugLineNum = 91;BA.debugLine="el.SetValue(txtValue)";
_el.SetValue(_txtvalue);
 //BA.debugLineNum = 93;BA.debugLine="Dim slength As String = el.GetAttr(\"data-length\")";
_slength = _el.GetAttr("data-length");
 //BA.debugLineNum = 94;BA.debugLine="Dim itype As String = el.GetAttr(\"data-instance\")";
_itype = _el.GetAttr("data-instance");
 //BA.debugLineNum = 95;BA.debugLine="If itype = \"textarea\" Then";
if ((_itype).equals("textarea")) { 
 //BA.debugLineNum = 96;BA.debugLine="Dim sbcode As StringBuilder";
_sbcode = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 97;BA.debugLine="sbcode.Initialize";
_sbcode.Initialize();
 //BA.debugLineNum = 98;BA.debugLine="Dim script As String = $\"M.textareaAutoResize(${";
_script = ("M.textareaAutoResize("+__c.SmartStringFormatter("",(Object)(_j))+"('"+__c.SmartStringFormatter("",(Object)(_elid))+"'));");
 //BA.debugLineNum = 99;BA.debugLine="sbcode.Append(script)";
_sbcode.Append(_script);
 //BA.debugLineNum = 100;BA.debugLine="If slength <> \"0\" Then";
if ((_slength).equals("0") == false) { 
 //BA.debugLineNum = 101;BA.debugLine="Dim script As String = $\"${j}('textarea${elID}'";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"('textarea"+__c.SmartStringFormatter("",(Object)(_elid))+"').characterCounter();");
 //BA.debugLineNum = 102;BA.debugLine="sbcode.Append(script)";
_sbcode.Append(_script);
 };
 //BA.debugLineNum = 104;BA.debugLine="Banano.Eval(sbcode.ToString)";
_banano.Eval((Object)(_sbcode.ToString()));
 }else if((_itype).equals("input")) { 
 //BA.debugLineNum = 106;BA.debugLine="If slength <> \"0\" Then";
if ((_slength).equals("0") == false) { 
 //BA.debugLineNum = 107;BA.debugLine="Dim script As String = $\"${j}('input${elID}').c";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+"('input"+__c.SmartStringFormatter("",(Object)(_elid))+"').characterCounter();");
 //BA.debugLineNum = 108;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 };
 };
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _showerror(String _scontent) throws Exception{
String _script = "";
 //BA.debugLineNum = 301;BA.debugLine="Sub ShowError(sContent As String) As String";
 //BA.debugLineNum = 302;BA.debugLine="Dim script As String = ShowToast(sContent,3000,Tr";
_script = _showtoast(_scontent,(int) (3000),__c.True,"white.red");
 //BA.debugLineNum = 303;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 304;BA.debugLine="End Sub";
return "";
}
public String  _showerror1(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 327;BA.debugLine="Sub ShowError1(varName As String) As String";
 //BA.debugLineNum = 328;BA.debugLine="Dim script As String = $\"M.toast({html:${varName}";
_script = ("M.toast({html:"+__c.SmartStringFormatter("",(Object)(_varname))+", displayLength:3000, classes:'rounded white-text red'});");
 //BA.debugLineNum = 329;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
return "";
}
public String  _showsuccess(String _scontent) throws Exception{
String _script = "";
 //BA.debugLineNum = 295;BA.debugLine="Sub ShowSuccess(sContent As String) As String";
 //BA.debugLineNum = 296;BA.debugLine="Dim script As String = ShowToast(sContent,3000,Tr";
_script = _showtoast(_scontent,(int) (3000),__c.True,"white.green");
 //BA.debugLineNum = 297;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 298;BA.debugLine="End Sub";
return "";
}
public String  _showsuccess1(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 321;BA.debugLine="Sub ShowSuccess1(varName As String) As String";
 //BA.debugLineNum = 322;BA.debugLine="Dim script As String = $\"M.toast({html:${varName}";
_script = ("M.toast({html:"+__c.SmartStringFormatter("",(Object)(_varname))+", displayLength:3000, classes:'rounded white-text green'});");
 //BA.debugLineNum = 323;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return "";
}
public String  _showtoast(String _scontent,int _duration,boolean _brounded,String _themename) throws Exception{
String _tclass = "";
b4j.Mashy.UOEBANano.uoehtml _div = null;
String _srounded = "";
String _sout = "";
String _str = "";
 //BA.debugLineNum = 307;BA.debugLine="Sub ShowToast(sContent As String, Duration As Int,";
 //BA.debugLineNum = 308;BA.debugLine="Dim tClass As String = App.MaterialGetTheme(theme";
_tclass = _app._materialgettheme(_themename);
 //BA.debugLineNum = 309;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 310;BA.debugLine="div.Initialize(\"\",\"div\")";
_div._initialize(ba,"","div");
 //BA.debugLineNum = 311;BA.debugLine="div.AddContent(sContent)";
_div._addcontent(_scontent);
 //BA.debugLineNum = 312;BA.debugLine="Dim srounded As String = \"\"";
_srounded = "";
 //BA.debugLineNum = 313;BA.debugLine="srounded = App.iif(bRounded,\"rounded\",\"\")";
_srounded = BA.ObjectToString(_app._iif(BA.ObjectToString(_brounded),(Object)("rounded"),(Object)("")));
 //BA.debugLineNum = 314;BA.debugLine="Dim sout As String = div.HTML";
_sout = _div._html();
 //BA.debugLineNum = 315;BA.debugLine="sout = sout.Replace(CRLF,\"\")";
_sout = _sout.replace(__c.CRLF,"");
 //BA.debugLineNum = 316;BA.debugLine="Dim str As String = $\"M.toast({html:'${sout}', di";
_str = ("M.toast({html:'"+__c.SmartStringFormatter("",(Object)(_sout))+"', displayLength:"+__c.SmartStringFormatter("",(Object)(_duration))+", classes:'"+__c.SmartStringFormatter("",(Object)(_srounded))+" "+__c.SmartStringFormatter("",(Object)(_tclass))+"'});");
 //BA.debugLineNum = 317;BA.debugLine="Return str";
if (true) return _str;
 //BA.debugLineNum = 318;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodal(String _stitle,String _scontent) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 163;BA.debugLine="Sub SweetModal(sTitle As String, sContent As Strin";
 //BA.debugLineNum = 164;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 165;BA.debugLine="Dim script As String = $\"${j}.sweetModal({ 	title";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal({\n"+"	title: '"+__c.SmartStringFormatter("",(Object)(_stitle))+"',\n"+"	content: '"+__c.SmartStringFormatter("",(Object)(_scontent))+"'\n"+"});");
 //BA.debugLineNum = 169;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 170;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalalert(String _stitle,String _scontent) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 156;BA.debugLine="Sub SweetModalAlert(sTitle As String, sContent As";
 //BA.debugLineNum = 157;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 158;BA.debugLine="Dim script As String = $\"${j}.sweetModal('${sTitl";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal('"+__c.SmartStringFormatter("",(Object)(_stitle))+"', '"+__c.SmartStringFormatter("",(Object)(_scontent))+"');");
 //BA.debugLineNum = 159;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 160;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalconfirm(String _stitle,String _scontent,String _onyes,String _oncancel) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 208;BA.debugLine="Sub SweetModalConfirm(sTitle As String, sContent A";
 //BA.debugLineNum = 209;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 210;BA.debugLine="Dim script As String = $\"${j}.sweetModal.confirm(";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.confirm('"+__c.SmartStringFormatter("",(Object)(_stitle))+"', '"+__c.SmartStringFormatter("",(Object)(_scontent))+"', function() {\n"+"	"+__c.SmartStringFormatter("",(Object)(_onyes))+"\n"+"}, function() {\n"+"	"+__c.SmartStringFormatter("",(Object)(_oncancel))+"\n"+"});");
 //BA.debugLineNum = 215;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 216;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalerror(String _stitle,String _scontent) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 197;BA.debugLine="Sub SweetModalError(sTitle As String, sContent As";
 //BA.debugLineNum = 198;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 199;BA.debugLine="Dim script As String = $\"${j}.sweetModal({ 	conte";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal({\n"+"	content: '"+__c.SmartStringFormatter("",(Object)(_scontent))+"',\n"+"	title: '"+__c.SmartStringFormatter("",(Object)(_stitle))+"',\n"+"	icon: "+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_ERROR\n"+"	});");
 //BA.debugLineNum = 204;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 205;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalprompt(String _stitle,String _scontent,String _sdefault,String _onval) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 219;BA.debugLine="Sub SweetModalPrompt(sTitle As String, sContent As";
 //BA.debugLineNum = 220;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 221;BA.debugLine="Dim script As String = $\"${j}.sweetModal.prompt('";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.prompt('"+__c.SmartStringFormatter("",(Object)(_stitle))+"', '"+__c.SmartStringFormatter("",(Object)(_scontent))+"', '"+__c.SmartStringFormatter("",(Object)(_sdefault))+"', function(val) {\n"+"	"+__c.SmartStringFormatter("",(Object)(_onval))+"\n"+"});");
 //BA.debugLineNum = 224;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 225;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalsuccess(String _stitle,String _scontent) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 185;BA.debugLine="Sub SweetModalSuccess(sTitle As String, sContent A";
 //BA.debugLineNum = 186;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 187;BA.debugLine="Dim script As String = $\"${j}.sweetModal({ 	conte";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal({\n"+"	content: '"+__c.SmartStringFormatter("",(Object)(_scontent))+"',\n"+"	title: '"+__c.SmartStringFormatter("",(Object)(_stitle))+"',\n"+"	icon: "+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_SUCCESS\n"+"	});");
 //BA.debugLineNum = 192;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 193;BA.debugLine="End Sub";
return "";
}
public String  _sweetmodalwarning(String _stitle,String _scontent) throws Exception{
String _j = "";
String _script = "";
 //BA.debugLineNum = 174;BA.debugLine="Sub SweetModalWarning(sTitle As String, sContent A";
 //BA.debugLineNum = 175;BA.debugLine="Dim j As String = \"$\"";
_j = "$";
 //BA.debugLineNum = 176;BA.debugLine="Dim script As String = $\"${j}.sweetModal({ 	conte";
_script = (""+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal({\n"+"	content: '"+__c.SmartStringFormatter("",(Object)(_scontent))+"',\n"+"	title: '"+__c.SmartStringFormatter("",(Object)(_stitle))+"',\n"+"	icon: "+__c.SmartStringFormatter("",(Object)(_j))+".sweetModal.ICON_WARNING\n"+"	});");
 //BA.debugLineNum = 181;BA.debugLine="Execute(script)";
_execute(_script);
 //BA.debugLineNum = 182;BA.debugLine="End Sub";
return "";
}
public String  _toasterror(String _serror) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub ToastError(sError As String)";
 //BA.debugLineNum = 64;BA.debugLine="Execute(ShowError(sError))";
_execute(_showerror(_serror));
 //BA.debugLineNum = 65;BA.debugLine="End Sub";
return "";
}
public String  _toastsuccess(String _ssuccess) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub ToastSuccess(sSuccess As String)";
 //BA.debugLineNum = 68;BA.debugLine="Execute(ShowSuccess(sSuccess))";
_execute(_showsuccess(_ssuccess));
 //BA.debugLineNum = 69;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
