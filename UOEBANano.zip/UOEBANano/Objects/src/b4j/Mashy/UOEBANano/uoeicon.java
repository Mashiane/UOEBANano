package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeicon extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeicon", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeicon.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _iconname = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _alignment = "";
public boolean _addcursor = false;
public boolean _circle = false;
public boolean _waveeffects = false;
public boolean _prefix = false;
public boolean _waveseffect = false;
public String _visibility = "";
public String _wavestype = "";
public boolean _wavescircle = false;
public String _zdepth = "";
public boolean _enabled = false;
public String _iconsize = "";
public boolean _close = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeicon  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 46;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 47;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeicon  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub AddClass(sClass As String) As UOEIcon";
 //BA.debugLineNum = 34;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 35;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeicon  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 28;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 29;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Alignment As String";
_alignment = "";
 //BA.debugLineNum = 10;BA.debugLine="Public AddCursor As Boolean";
_addcursor = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Circle As Boolean";
_circle = false;
 //BA.debugLineNum = 12;BA.debugLine="Public WaveEffects As Boolean";
_waveeffects = false;
 //BA.debugLineNum = 13;BA.debugLine="Public Prefix As Boolean";
_prefix = false;
 //BA.debugLineNum = 14;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 15;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 16;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 17;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 18;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 19;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 20;BA.debugLine="Public IconSize As String";
_iconsize = "";
 //BA.debugLineNum = 21;BA.debugLine="Public Close As Boolean";
_close = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeicon  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _siconname,String _sthemename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 57;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sid As St";
 //BA.debugLineNum = 58;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 59;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 60;BA.debugLine="Close = False";
_close = __c.False;
 //BA.debugLineNum = 61;BA.debugLine="IconName = sIconName";
_iconname = _siconname;
 //BA.debugLineNum = 62;BA.debugLine="Prefix = False";
_prefix = __c.False;
 //BA.debugLineNum = 63;BA.debugLine="Circle = False";
_circle = __c.False;
 //BA.debugLineNum = 64;BA.debugLine="AddCursor = False";
_addcursor = __c.False;
 //BA.debugLineNum = 65;BA.debugLine="Theme = sThemeName";
_theme = _sthemename;
 //BA.debugLineNum = 66;BA.debugLine="WaveEffects = True";
_waveeffects = __c.True;
 //BA.debugLineNum = 67;BA.debugLine="Alignment = \"\"";
_alignment = "";
 //BA.debugLineNum = 68;BA.debugLine="Element.Initialize(ID,\"i\")";
_element._initialize(ba,_id,"i");
 //BA.debugLineNum = 69;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 70;BA.debugLine="Visibility= \"\"";
_visibility = "";
 //BA.debugLineNum = 71;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 72;BA.debugLine="WavesType = App.EnumWavesType.Light";
_wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 73;BA.debugLine="IconSize = \"\"";
_iconsize = "";
 //BA.debugLineNum = 74;BA.debugLine="WavesEffect = True";
_waveseffect = __c.True;
 //BA.debugLineNum = 75;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 76;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeicon  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEIcon";
 //BA.debugLineNum = 52;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeicon  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 39;BA.debugLine="Sub RemoveClass(sClass As String) As UOEIcon";
 //BA.debugLineNum = 40;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 41;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeicon)(this);
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return null;
}
public String  _removewave() throws Exception{
 //BA.debugLineNum = 80;BA.debugLine="Sub RemoveWave";
 //BA.debugLineNum = 81;BA.debugLine="WaveEffects = False";
_waveeffects = __c.False;
 //BA.debugLineNum = 82;BA.debugLine="WavesType = \"\"";
_wavestype = "";
 //BA.debugLineNum = 83;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 88;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 89;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 90;BA.debugLine="Element.MaterialBuildIcon(IconName, Alignment)";
_element._materialbuildicon(_iconname,_alignment);
 //BA.debugLineNum = 91;BA.debugLine="Element.MaterialCircle(Circle)";
_element._materialcircle(_circle);
 //BA.debugLineNum = 93;BA.debugLine="Element.MaterialWavesEffect(WaveEffects)";
_element._materialwaveseffect(_waveeffects);
 //BA.debugLineNum = 94;BA.debugLine="Element.AddClassOnCondition(Prefix,\"prefix\")";
_element._addclassoncondition(_prefix,"prefix");
 //BA.debugLineNum = 95;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 96;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 97;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 98;BA.debugLine="Element.MaterialWavesEffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 99;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 100;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 101;BA.debugLine="App.ApplyTooltip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 102;BA.debugLine="Element.MaterialIconSize(IconSize)";
_element._materialiconsize(_iconsize);
 //BA.debugLineNum = 103;BA.debugLine="Element.MaterialClose(Close)";
_element._materialclose(BA.ObjectToString(_close));
 //BA.debugLineNum = 104;BA.debugLine="If AddCursor = True Then Element.addcursor";
if (_addcursor==__c.True) { 
_element._addcursor();};
 //BA.debugLineNum = 109;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
