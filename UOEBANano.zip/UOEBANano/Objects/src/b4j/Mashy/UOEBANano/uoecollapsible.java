package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecollapsible extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecollapsible", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecollapsible.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _visibility = "";
public anywheresoftware.b4a.objects.collections.Map _headers = null;
public anywheresoftware.b4a.objects.collections.Map _bodies = null;
public boolean _popout = false;
public boolean _nopadding = false;
public String _zdepth = "";
public boolean _enabled = false;
public boolean _hoverable = false;
public anywheresoftware.b4a.objects.collections.Map _haschildren = null;
public boolean _normalize = false;
public String _lastheader = "";
public String _lastheadertitle = "";
public boolean _showarrows = false;
public anywheresoftware.b4a.objects.collections.Map _links = null;
public anywheresoftware.b4a.objects.collections.Map _itemnames = null;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecollapsible  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 77;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 78;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollapsible  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 34;BA.debugLine="Sub AddClass(sClass As String)  As UOECollapsible";
 //BA.debugLineNum = 35;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 36;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public String  _addheader(String _itemid,String _itemicon,String _itemtext,String _itembadge,boolean _badgenew,String _itemnavigateto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchor _div = null;
b4j.Mashy.UOEBANano.uoehtml _spn = null;
b4j.Mashy.UOEBANano.uoedivider _md = null;
String _sout = "";
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.List _lst1 = null;
anywheresoftware.b4a.objects.collections.List _lst2 = null;
 //BA.debugLineNum = 141;BA.debugLine="Sub AddHeader(itemID As String, itemIcon As String";
 //BA.debugLineNum = 142;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 143;BA.debugLine="hasChildren.Put(itemID,False)";
_haschildren.Put((Object)(_itemid),(Object)(__c.False));
 //BA.debugLineNum = 145;BA.debugLine="Dim div As UOEAnchor";
_div = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 146;BA.debugLine="div.Initialize(App,itemID)";
_div._initialize(ba,_app,_itemid);
 //BA.debugLineNum = 147;BA.debugLine="div.element.MaterialCollapsibleHeader(True)";
_div._element._materialcollapsibleheader(__c.True);
 //BA.debugLineNum = 148;BA.debugLine="div.IsDiv = Normalize";
_div._isdiv = _normalize;
 //BA.debugLineNum = 149;BA.debugLine="modUOE.materialAddIcon(App,div.Element,itemIcon,\"";
_moduoe._materialaddicon(_app,_div._element,_itemicon,"",_icontheme,__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 152;BA.debugLine="Dim spn As UOEHTML";
_spn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 153;BA.debugLine="spn.Initialize(itemID & \"-span\",\"span\")";
_spn._initialize(ba,_itemid+"-span","span");
 //BA.debugLineNum = 154;BA.debugLine="spn.AddContent(itemText)";
_spn._addcontent(_itemtext);
 //BA.debugLineNum = 155;BA.debugLine="div.Element.AddElement(spn)";
_div._element._addelement(_spn);
 //BA.debugLineNum = 157;BA.debugLine="modUOE.MaterialAddBadge(App,div.Element,itemBadge";
_moduoe._materialaddbadge(_app,_div._element,_itembadge,_badgenew,_app._enumvisibility._visible,__c.True,"",__c.False);
 //BA.debugLineNum = 158;BA.debugLine="If ShowArrows Then";
if (_showarrows) { 
 //BA.debugLineNum = 159;BA.debugLine="modUOE.MaterialAddIcon(App,div.element,\"mdi-keyb";
_moduoe._materialaddicon(_app,_div._element,"mdi-keyboard_arrow_right","right","",__c.False,__c.False,__c.False,__c.False,__c.False);
 };
 //BA.debugLineNum = 161;BA.debugLine="div.WavesEffect = True";
_div._waveseffect = __c.True;
 //BA.debugLineNum = 162;BA.debugLine="div.WavesType = App.EnumWavesType.Light";
_div._wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 163;BA.debugLine="div.TextVisible = True";
_div._textvisible = __c.True;
 //BA.debugLineNum = 164;BA.debugLine="div.Theme = itemTheme";
_div._theme = _itemtheme;
 //BA.debugLineNum = 165;BA.debugLine="div.href = itemNavigateTo";
_div._href = _itemnavigateto;
 //BA.debugLineNum = 166;BA.debugLine="If hasDivider = True Then";
if (_hasdivider==__c.True) { 
 //BA.debugLineNum = 167;BA.debugLine="Dim md As UOEDivider";
_md = new b4j.Mashy.UOEBANano.uoedivider();
 //BA.debugLineNum = 168;BA.debugLine="md.Initialize(App,\"\",\"\")";
_md._initialize(ba,_app,"","");
 //BA.debugLineNum = 169;BA.debugLine="Dim sout As String = div.tostring & md.tostring";
_sout = _div._tostring()+_md._tostring();
 //BA.debugLineNum = 170;BA.debugLine="Headers.Put(itemID,sout)";
_headers.Put((Object)(_itemid),(Object)(_sout));
 }else {
 //BA.debugLineNum = 173;BA.debugLine="Headers.Put(itemID,div.tostring)";
_headers.Put((Object)(_itemid),(Object)(_div._tostring()));
 };
 //BA.debugLineNum = 175;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 176;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 177;BA.debugLine="lst.clear";
_lst.Clear();
 //BA.debugLineNum = 178;BA.debugLine="Dim lst1 As List";
_lst1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 179;BA.debugLine="lst1.Initialize";
_lst1.Initialize();
 //BA.debugLineNum = 180;BA.debugLine="lst1.clear";
_lst1.Clear();
 //BA.debugLineNum = 181;BA.debugLine="Dim lst2 As List";
_lst2 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 182;BA.debugLine="lst2.Initialize";
_lst2.Initialize();
 //BA.debugLineNum = 183;BA.debugLine="lst2.clear";
_lst2.Clear();
 //BA.debugLineNum = 184;BA.debugLine="Bodies.Put(itemID,lst)";
_bodies.Put((Object)(_itemid),(Object)(_lst.getObject()));
 //BA.debugLineNum = 185;BA.debugLine="Links.Put(itemID,lst1)";
_links.Put((Object)(_itemid),(Object)(_lst1.getObject()));
 //BA.debugLineNum = 186;BA.debugLine="ItemNames.Put(itemID,lst2)";
_itemnames.Put((Object)(_itemid),(Object)(_lst2.getObject()));
 //BA.debugLineNum = 187;BA.debugLine="LastHeader = itemID";
_lastheader = _itemid;
 //BA.debugLineNum = 188;BA.debugLine="LastHeaderTitle = itemText";
_lastheadertitle = _itemtext;
 //BA.debugLineNum = 189;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 190;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 192;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return "";
}
public String  _addheaderbody(String _itemid,String _itembody) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 308;BA.debugLine="Sub AddHeaderBody(itemID As String, itemBody As St";
 //BA.debugLineNum = 309;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 310;BA.debugLine="If Headers.ContainsKey(itemID) Then";
if (_headers.ContainsKey((Object)(_itemid))) { 
 //BA.debugLineNum = 311;BA.debugLine="Dim lst As List = Bodies.Get(itemID)";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst.setObject((java.util.List)(_bodies.Get((Object)(_itemid))));
 //BA.debugLineNum = 312;BA.debugLine="lst.Add(itemBody)";
_lst.Add((Object)(_itembody));
 //BA.debugLineNum = 313;BA.debugLine="Bodies.Put(itemID,lst)";
_bodies.Put((Object)(_itemid),(Object)(_lst.getObject()));
 //BA.debugLineNum = 314;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
public String  _addheadercontainer(String _itemid,b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 319;BA.debugLine="Sub AddHeaderContainer(itemID As String, cont As U";
 //BA.debugLineNum = 320;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 321;BA.debugLine="If Headers.ContainsKey(itemID) Then";
if (_headers.ContainsKey((Object)(_itemid))) { 
 //BA.debugLineNum = 322;BA.debugLine="Dim lst As List = Bodies.Get(itemID)";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst.setObject((java.util.List)(_bodies.Get((Object)(_itemid))));
 //BA.debugLineNum = 323;BA.debugLine="lst.Add(cont.tostring)";
_lst.Add((Object)(_cont._tostring()));
 //BA.debugLineNum = 324;BA.debugLine="Bodies.Put(itemID,lst)";
_bodies.Put((Object)(_itemid),(Object)(_lst.getObject()));
 //BA.debugLineNum = 325;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 327;BA.debugLine="End Sub";
return "";
}
public String  _addheaderitem(String _parentid,String _itemid,String _iconname,String _itemtext,String _itemnavigateto,String _itembadge,boolean _badgenew,boolean _bhasdivider,String _itemtheme,String _icontheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchor _div = null;
b4j.Mashy.UOEBANano.uoehtml _li = null;
String _hdr = "";
b4j.Mashy.UOEBANano.uoehtml _div1 = null;
b4j.Mashy.UOEBANano.uoehtml _divx = null;
b4j.Mashy.UOEBANano.uoedivider _divider = null;
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.List _lst1 = null;
anywheresoftware.b4a.objects.collections.List _lst2 = null;
 //BA.debugLineNum = 246;BA.debugLine="Sub AddHeaderItem(parentID As String, itemID As St";
 //BA.debugLineNum = 247;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 248;BA.debugLine="parentID = parentID.tolowercase";
_parentid = _parentid.toLowerCase();
 //BA.debugLineNum = 249;BA.debugLine="hasChildren.Put(parentID,True)";
_haschildren.Put((Object)(_parentid),(Object)(__c.True));
 //BA.debugLineNum = 250;BA.debugLine="If Headers.ContainsKey(parentID) = False Then";
if (_headers.ContainsKey((Object)(_parentid))==__c.False) { 
 //BA.debugLineNum = 251;BA.debugLine="Log(parentID & \" header does not exist on sideba";
__c.Log(_parentid+" header does not exist on sidebar");
 //BA.debugLineNum = 252;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 254;BA.debugLine="App.HeadersToFix.Put(parentID,parentID)";
_app._headerstofix.Put((Object)(_parentid),(Object)(_parentid));
 //BA.debugLineNum = 256;BA.debugLine="Dim div As UOEAnchor";
_div = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 257;BA.debugLine="div.Initialize(App,itemID)";
_div._initialize(ba,_app,_itemid);
 //BA.debugLineNum = 258;BA.debugLine="div.IsDiv = Normalize";
_div._isdiv = _normalize;
 //BA.debugLineNum = 259;BA.debugLine="modUOE.MaterialAddBadge(App,div.Element,itemBadge";
_moduoe._materialaddbadge(_app,_div._element,_itembadge,_badgenew,_app._enumvisibility._visible,__c.True,"",__c.False);
 //BA.debugLineNum = 260;BA.debugLine="modUOE.MaterialAddIcon(App,div.Element,iconName,\"";
_moduoe._materialaddicon(_app,_div._element,_iconname,"",_icontheme,__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 261;BA.debugLine="div.WavesEffect = True";
_div._waveseffect = __c.True;
 //BA.debugLineNum = 262;BA.debugLine="div.WavesType = App.EnumWavesType.Light";
_div._wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 263;BA.debugLine="div.TextVisible = True";
_div._textvisible = __c.True;
 //BA.debugLineNum = 264;BA.debugLine="div.Theme = itemTheme";
_div._theme = _itemtheme;
 //BA.debugLineNum = 265;BA.debugLine="div.Text = itemText";
_div._text = _itemtext;
 //BA.debugLineNum = 266;BA.debugLine="div.href = itemNavigateTo";
_div._href = _itemnavigateto;
 //BA.debugLineNum = 267;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 268;BA.debugLine="li.Initialize(\"\",\"li\")";
_li._initialize(ba,"","li");
 //BA.debugLineNum = 269;BA.debugLine="li.AddContent(div.tostring)";
_li._addcontent(_div._tostring());
 //BA.debugLineNum = 270;BA.debugLine="Dim hdr As String = li.html";
_hdr = _li._html();
 //BA.debugLineNum = 271;BA.debugLine="If bHasDivider = True Then";
if (_bhasdivider==__c.True) { 
 //BA.debugLineNum = 272;BA.debugLine="Dim div1 As UOEHTML";
_div1 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 273;BA.debugLine="div1.Initialize(\"\",\"li\")";
_div1._initialize(ba,"","li");
 //BA.debugLineNum = 275;BA.debugLine="Dim divx As UOEHTML";
_divx = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 276;BA.debugLine="divx.Initialize(\"\",\"div\")";
_divx._initialize(ba,"","div");
 //BA.debugLineNum = 277;BA.debugLine="divx.AddClass(\"divider\")";
_divx._addclass("divider");
 //BA.debugLineNum = 278;BA.debugLine="div1.AddElement(divx)";
_div1._addelement(_divx);
 //BA.debugLineNum = 280;BA.debugLine="Dim divider As UOEDivider";
_divider = new b4j.Mashy.UOEBANano.uoedivider();
 //BA.debugLineNum = 281;BA.debugLine="divider.Initialize(App,\"\",itemTheme)";
_divider._initialize(ba,_app,"",_itemtheme);
 //BA.debugLineNum = 282;BA.debugLine="hdr = hdr & divider.tostring";
_hdr = _hdr+_divider._tostring();
 };
 //BA.debugLineNum = 284;BA.debugLine="If Headers.ContainsKey(parentID) Then";
if (_headers.ContainsKey((Object)(_parentid))) { 
 //BA.debugLineNum = 285;BA.debugLine="Dim lst As List = Bodies.Get(parentID)";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst.setObject((java.util.List)(_bodies.Get((Object)(_parentid))));
 //BA.debugLineNum = 286;BA.debugLine="lst.Add(hdr)";
_lst.Add((Object)(_hdr));
 //BA.debugLineNum = 287;BA.debugLine="Bodies.Put(parentID,lst)";
_bodies.Put((Object)(_parentid),(Object)(_lst.getObject()));
 };
 //BA.debugLineNum = 290;BA.debugLine="If Links.ContainsKey(parentID) And itemNavigateTo";
if (_links.ContainsKey((Object)(_parentid)) && _itemnavigateto.length()>0) { 
 //BA.debugLineNum = 291;BA.debugLine="Dim lst1 As List";
_lst1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 292;BA.debugLine="lst1 = Links.Get(parentID)";
_lst1.setObject((java.util.List)(_links.Get((Object)(_parentid))));
 //BA.debugLineNum = 293;BA.debugLine="lst1.Add(itemNavigateTo)";
_lst1.Add((Object)(_itemnavigateto));
 //BA.debugLineNum = 294;BA.debugLine="Links.Put(parentID,lst1)";
_links.Put((Object)(_parentid),(Object)(_lst1.getObject()));
 //BA.debugLineNum = 295;BA.debugLine="Dim lst2 As List";
_lst2 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 296;BA.debugLine="lst2 = ItemNames.Get(parentID)";
_lst2.setObject((java.util.List)(_itemnames.Get((Object)(_parentid))));
 //BA.debugLineNum = 297;BA.debugLine="lst2.Add(itemText)";
_lst2.Add((Object)(_itemtext));
 //BA.debugLineNum = 298;BA.debugLine="ItemNames.Put(parentID,lst2)";
_itemnames.Put((Object)(_parentid),(Object)(_lst2.getObject()));
 };
 //BA.debugLineNum = 300;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 301;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 303;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 305;BA.debugLine="End Sub";
return "";
}
public String  _addheaderitemsimple(String _parentid,String _itemid,String _itemicon,String _itemtext,String _itemgoto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 241;BA.debugLine="Sub AddHeaderItemSimple(parentID As String,itemID";
 //BA.debugLineNum = 242;BA.debugLine="AddHeaderItem(parentID,itemID,itemIcon,itemText,i";
_addheaderitem(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,"",__c.False,_hasdivider,_itemtheme,_icontheme,_hasevent);
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
return "";
}
public String  _addheadersimple(String _itemid,String _itemicon,String _itemtext,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 131;BA.debugLine="Sub AddHeaderSimple(itemID As String, itemIcon As";
 //BA.debugLineNum = 132;BA.debugLine="AddHeader(itemID,itemIcon,itemText,\"\",False,\"\",it";
_addheader(_itemid,_itemicon,_itemtext,"",__c.False,"",_itemtheme,_icontheme,_hasdivider,_hasevent);
 //BA.debugLineNum = 133;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecollapsible  _addhiddenheadertitle2body() throws Exception{
b4j.Mashy.UOEBANano.uoelabel _ml = null;
 //BA.debugLineNum = 50;BA.debugLine="Sub AddHiddenHeaderTitle2Body() As UOECollapsible";
 //BA.debugLineNum = 51;BA.debugLine="If Headers.ContainsKey(LastHeader) Then";
if (_headers.ContainsKey((Object)(_lastheader))) { 
 //BA.debugLineNum = 52;BA.debugLine="Dim ml As UOELabel";
_ml = new b4j.Mashy.UOEBANano.uoelabel();
 //BA.debugLineNum = 53;BA.debugLine="ml.Initialize(App,LastHeader,App.EnumLabelSize.p";
_ml._initialize(ba,_app,_lastheader,_app._enumlabelsize._paragraph,_lastheadertitle+". ","","");
 //BA.debugLineNum = 54;BA.debugLine="ml.Visibility = App.EnumVisibility.hide";
_ml._visibility = _app._enumvisibility._hide;
 //BA.debugLineNum = 55;BA.debugLine="AddHeaderBody(LastHeader,ml.tostring)";
_addheaderbody(_lastheader,_ml._tostring());
 };
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public String  _additem(String _itemid,String _itemicon,String _itemtext,String _itembadge,boolean _badgenew,String _itemnavigateto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoeanchor _div = null;
b4j.Mashy.UOEBANano.uoedivider _md = null;
String _sout = "";
anywheresoftware.b4a.objects.collections.List _lst1 = null;
anywheresoftware.b4a.objects.collections.List _lst2 = null;
 //BA.debugLineNum = 197;BA.debugLine="Sub AddItem(itemID As String, itemIcon As String,";
 //BA.debugLineNum = 198;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 199;BA.debugLine="hasChildren.Put(itemID,False)";
_haschildren.Put((Object)(_itemid),(Object)(__c.False));
 //BA.debugLineNum = 201;BA.debugLine="Dim div As UOEAnchor";
_div = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 202;BA.debugLine="div.Initialize(App,itemID)";
_div._initialize(ba,_app,_itemid);
 //BA.debugLineNum = 203;BA.debugLine="div.IsDiv = Normalize";
_div._isdiv = _normalize;
 //BA.debugLineNum = 204;BA.debugLine="div.element.MaterialCollapsibleHeader(True)";
_div._element._materialcollapsibleheader(__c.True);
 //BA.debugLineNum = 205;BA.debugLine="modUOE.materialAddIcon(App,div.Element,itemIcon,\"";
_moduoe._materialaddicon(_app,_div._element,_itemicon,"",_icontheme,__c.False,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 206;BA.debugLine="div.Element.AddContent(itemText)";
_div._element._addcontent(_itemtext);
 //BA.debugLineNum = 207;BA.debugLine="modUOE.MaterialAddBadge(App,div.Element,itemBadge";
_moduoe._materialaddbadge(_app,_div._element,_itembadge,_badgenew,_app._enumvisibility._visible,__c.True,"",__c.False);
 //BA.debugLineNum = 208;BA.debugLine="div.WavesEffect = True";
_div._waveseffect = __c.True;
 //BA.debugLineNum = 209;BA.debugLine="div.WavesType = App.EnumWavesType.Light";
_div._wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 210;BA.debugLine="div.TextVisible = True";
_div._textvisible = __c.True;
 //BA.debugLineNum = 211;BA.debugLine="div.Theme = itemTheme";
_div._theme = _itemtheme;
 //BA.debugLineNum = 212;BA.debugLine="div.href = itemNavigateTo";
_div._href = _itemnavigateto;
 //BA.debugLineNum = 213;BA.debugLine="If hasDivider = True Then";
if (_hasdivider==__c.True) { 
 //BA.debugLineNum = 214;BA.debugLine="Dim md As UOEDivider";
_md = new b4j.Mashy.UOEBANano.uoedivider();
 //BA.debugLineNum = 215;BA.debugLine="md.Initialize(App,\"\",\"\")";
_md._initialize(ba,_app,"","");
 //BA.debugLineNum = 216;BA.debugLine="Dim sout As String = div.tostring & md.tostring";
_sout = _div._tostring()+_md._tostring();
 //BA.debugLineNum = 217;BA.debugLine="Headers.Put(itemID,sout)";
_headers.Put((Object)(_itemid),(Object)(_sout));
 }else {
 //BA.debugLineNum = 220;BA.debugLine="Headers.Put(itemID,div.tostring)";
_headers.Put((Object)(_itemid),(Object)(_div._tostring()));
 };
 //BA.debugLineNum = 223;BA.debugLine="If Links.ContainsKey(itemID) And itemNavigateTo.L";
if (_links.ContainsKey((Object)(_itemid)) && _itemnavigateto.length()>0) { 
 //BA.debugLineNum = 224;BA.debugLine="Dim lst1 As List";
_lst1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 225;BA.debugLine="lst1 = Links.Get(itemID)";
_lst1.setObject((java.util.List)(_links.Get((Object)(_itemid))));
 //BA.debugLineNum = 226;BA.debugLine="lst1.Add(itemNavigateTo)";
_lst1.Add((Object)(_itemnavigateto));
 //BA.debugLineNum = 227;BA.debugLine="Links.Put(itemID,lst1)";
_links.Put((Object)(_itemid),(Object)(_lst1.getObject()));
 //BA.debugLineNum = 228;BA.debugLine="Dim lst2 As List";
_lst2 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 229;BA.debugLine="lst2 = ItemNames.Get(itemID)";
_lst2.setObject((java.util.List)(_itemnames.Get((Object)(_itemid))));
 //BA.debugLineNum = 230;BA.debugLine="lst2.Add(itemText)";
_lst2.Add((Object)(_itemtext));
 //BA.debugLineNum = 231;BA.debugLine="ItemNames.Put(itemID,lst2)";
_itemnames.Put((Object)(_itemid),(Object)(_lst2.getObject()));
 };
 //BA.debugLineNum = 233;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 234;BA.debugLine="App.AddEvent(itemID, \"click\")";
_app._addevent(_itemid,"click");
 }else {
 //BA.debugLineNum = 236;BA.debugLine="App.HeadersToFix.Put(itemID,itemID)";
_app._headerstofix.Put((Object)(_itemid),(Object)(_itemid));
 };
 //BA.debugLineNum = 238;BA.debugLine="End Sub";
return "";
}
public String  _additemsimple(String _itemid,String _itemicon,String _itemtext,String _itemgoto,String _itemtheme,String _icontheme,boolean _hasdivider,boolean _hasevent) throws Exception{
 //BA.debugLineNum = 136;BA.debugLine="Sub AddItemSimple(itemID As String, itemIcon As St";
 //BA.debugLineNum = 137;BA.debugLine="AddItem(itemID,itemIcon,itemText,\"\",False,itemGoT";
_additem(_itemid,_itemicon,_itemtext,"",__c.False,_itemgoto,_itemtheme,_icontheme,_hasdivider,_hasevent);
 //BA.debugLineNum = 138;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecollapsible  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 29;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 30;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return null;
}
public String  _bodyof(String _sid) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Sub BodyOf(sID As String) As String";
 //BA.debugLineNum = 41;BA.debugLine="sID = sID.ToLowerCase";
_sid = _sid.toLowerCase();
 //BA.debugLineNum = 42;BA.debugLine="If Headers.ContainsKey(sID) Then";
if (_headers.ContainsKey((Object)(_sid))) { 
 //BA.debugLineNum = 43;BA.debugLine="Return sID & \"bdy\"";
if (true) return _sid+"bdy";
 }else {
 //BA.debugLineNum = 45;BA.debugLine="Return \"\"";
if (true) return "";
 };
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Private Headers As Map";
_headers = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 11;BA.debugLine="Private Bodies As Map";
_bodies = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 12;BA.debugLine="Public PopOut As Boolean";
_popout = false;
 //BA.debugLineNum = 13;BA.debugLine="Private NoPadding As Boolean";
_nopadding = false;
 //BA.debugLineNum = 14;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 16;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 17;BA.debugLine="Private hasChildren As Map";
_haschildren = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 18;BA.debugLine="Public Normalize As Boolean";
_normalize = false;
 //BA.debugLineNum = 19;BA.debugLine="Private LastHeader As String";
_lastheader = "";
 //BA.debugLineNum = 20;BA.debugLine="Private LastHeaderTitle As String";
_lastheadertitle = "";
 //BA.debugLineNum = 21;BA.debugLine="Public ShowArrows As Boolean";
_showarrows = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Links As Map";
_links = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 23;BA.debugLine="Public ItemNames As Map";
_itemnames = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 24;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public String  _close(int _idx) throws Exception{
String _script = "";
 //BA.debugLineNum = 123;BA.debugLine="Sub Close(idx As Int)";
 //BA.debugLineNum = 124;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Collapsible.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".close("+__c.SmartStringFormatter("",(Object)(_idx))+");");
 //BA.debugLineNum = 127;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public String  _getstructure() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _drpitem = "";
String _hdr = "";
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _div = null;
boolean _bhaschildren = false;
b4j.Mashy.UOEBANano.uoehtml _ul = null;
anywheresoftware.b4a.objects.collections.List _lstx = null;
 //BA.debugLineNum = 330;BA.debugLine="private Sub GetStructure As String";
 //BA.debugLineNum = 331;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 332;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 333;BA.debugLine="Dim kTot As Int = Headers.Size - 1";
_ktot = (int) (_headers.getSize()-1);
 //BA.debugLineNum = 334;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 335;BA.debugLine="For kCnt = 0 To kTot";
{
final int step5 = 1;
final int limit5 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit5 ;_kcnt = _kcnt + step5 ) {
 //BA.debugLineNum = 336;BA.debugLine="Dim drpItem As String = Headers.GetKeyAt(kCnt)";
_drpitem = BA.ObjectToString(_headers.GetKeyAt(_kcnt));
 //BA.debugLineNum = 337;BA.debugLine="Dim hdr As String = Headers.GetDefault(drpItem,\"";
_hdr = BA.ObjectToString(_headers.GetDefault((Object)(_drpitem),(Object)("")));
 //BA.debugLineNum = 339;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 340;BA.debugLine="li.Initialize(drpItem & \"-header\",\"li\")";
_li._initialize(ba,_drpitem+"-header","li");
 //BA.debugLineNum = 341;BA.debugLine="li.AddContent(hdr)";
_li._addcontent(_hdr);
 //BA.debugLineNum = 343;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 344;BA.debugLine="div.Initialize(drpItem & \"-body\",\"div\")";
_div._initialize(ba,_drpitem+"-body","div");
 //BA.debugLineNum = 345;BA.debugLine="div.AddClass(\"collapsible-body\")";
_div._addclass("collapsible-body");
 //BA.debugLineNum = 346;BA.debugLine="Dim bHasChildren As Boolean = hasChildren.Get(dr";
_bhaschildren = BA.ObjectToBoolean(_haschildren.Get((Object)(_drpitem)));
 //BA.debugLineNum = 347;BA.debugLine="If bHasChildren Then";
if (_bhaschildren) { 
 //BA.debugLineNum = 348;BA.debugLine="Dim ul As UOEHTML";
_ul = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 349;BA.debugLine="ul.Initialize(\"\",\"ul\")";
_ul._initialize(ba,"","ul");
 //BA.debugLineNum = 350;BA.debugLine="Dim lstx As List = Bodies.Get(drpItem)";
_lstx = new anywheresoftware.b4a.objects.collections.List();
_lstx.setObject((java.util.List)(_bodies.Get((Object)(_drpitem))));
 //BA.debugLineNum = 351;BA.debugLine="ul.AddContentList(lstx)";
_ul._addcontentlist(_lstx);
 //BA.debugLineNum = 352;BA.debugLine="div.AddContent(ul.HTML)";
_div._addcontent(_ul._html());
 //BA.debugLineNum = 353;BA.debugLine="li.AddContent(div.HTML)";
_li._addcontent(_div._html());
 }else {
 //BA.debugLineNum = 355;BA.debugLine="If Bodies.ContainsKey(drpItem) Then";
if (_bodies.ContainsKey((Object)(_drpitem))) { 
 //BA.debugLineNum = 356;BA.debugLine="Dim lstx As List = Bodies.Get(drpItem)";
_lstx = new anywheresoftware.b4a.objects.collections.List();
_lstx.setObject((java.util.List)(_bodies.Get((Object)(_drpitem))));
 //BA.debugLineNum = 357;BA.debugLine="div.AddContentList(lstx)";
_div._addcontentlist(_lstx);
 //BA.debugLineNum = 358;BA.debugLine="li.AddContent(div.HTML)";
_li._addcontent(_div._html());
 };
 };
 //BA.debugLineNum = 361;BA.debugLine="sb.Append(li.HTML)";
_sb.Append(_li._html());
 }
};
 //BA.debugLineNum = 363;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 364;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _itemid,String _itemtype,boolean _bnopadding,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 88;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, itemID As";
 //BA.debugLineNum = 89;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 90;BA.debugLine="ID = itemID.tolowercase";
_id = _itemid.toLowerCase();
 //BA.debugLineNum = 91;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 92;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 93;BA.debugLine="Element.Initialize(ID,\"ul\")";
_element._initialize(ba,_id,"ul");
 //BA.debugLineNum = 94;BA.debugLine="Element.AddClass(\"collapsible\")";
_element._addclass("collapsible");
 //BA.debugLineNum = 95;BA.debugLine="Element.AddAttribute(\"data-collapsible\",itemType)";
_element._addattribute("data-collapsible",_itemtype);
 //BA.debugLineNum = 96;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 97;BA.debugLine="Headers.Initialize";
_headers.Initialize();
 //BA.debugLineNum = 98;BA.debugLine="Headers.clear";
_headers.Clear();
 //BA.debugLineNum = 99;BA.debugLine="Bodies.Initialize";
_bodies.Initialize();
 //BA.debugLineNum = 100;BA.debugLine="Bodies.clear";
_bodies.Clear();
 //BA.debugLineNum = 101;BA.debugLine="PopOut = False";
_popout = __c.False;
 //BA.debugLineNum = 102;BA.debugLine="NoPadding = bNoPadding";
_nopadding = _bnopadding;
 //BA.debugLineNum = 103;BA.debugLine="hasChildren.Initialize";
_haschildren.Initialize();
 //BA.debugLineNum = 104;BA.debugLine="hasChildren.clear";
_haschildren.Clear();
 //BA.debugLineNum = 105;BA.debugLine="Normalize = False";
_normalize = __c.False;
 //BA.debugLineNum = 106;BA.debugLine="ShowArrows = True";
_showarrows = __c.True;
 //BA.debugLineNum = 107;BA.debugLine="Links.Initialize";
_links.Initialize();
 //BA.debugLineNum = 108;BA.debugLine="Links.clear";
_links.Clear();
 //BA.debugLineNum = 109;BA.debugLine="ItemNames.Initialize";
_itemnames.Initialize();
 //BA.debugLineNum = 110;BA.debugLine="ItemNames.clear";
_itemnames.Clear();
 //BA.debugLineNum = 111;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 112;BA.debugLine="End Sub";
return "";
}
public String  _open(int _idx) throws Exception{
String _script = "";
 //BA.debugLineNum = 115;BA.debugLine="Sub Open(idx As Int)";
 //BA.debugLineNum = 116;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Collapsible.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".open("+__c.SmartStringFormatter("",(Object)(_idx))+");");
 //BA.debugLineNum = 119;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 120;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecollapsible  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 82;BA.debugLine="Sub RemoveAttribute(attr As String)  As UOECollaps";
 //BA.debugLineNum = 83;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 84;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecollapsible  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Sub RemoveClass(sClass As String)  As UOECollapsib";
 //BA.debugLineNum = 71;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 72;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecollapsible)(this);
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _lim = null;
 //BA.debugLineNum = 367;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 368;BA.debugLine="Element.AddClassOnCondition(PopOut,\"popout\")";
_element._addclassoncondition(_popout,"popout");
 //BA.debugLineNum = 369;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 370;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 371;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 372;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 373;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 375;BA.debugLine="Element.AddContent(GetStructure)";
_element._addcontent(_getstructure());
 //BA.debugLineNum = 380;BA.debugLine="If NoPadding = True Then";
if (_nopadding==__c.True) { 
 //BA.debugLineNum = 381;BA.debugLine="Dim lim As UOEHTML";
_lim = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 382;BA.debugLine="lim.Initialize(\"\",\"li\")";
_lim._initialize(ba,"","li");
 //BA.debugLineNum = 383;BA.debugLine="lim.AddClass(\"no-padding\")";
_lim._addclass("no-padding");
 //BA.debugLineNum = 384;BA.debugLine="lim.AddContent(Element.HTML)";
_lim._addcontent(_element._html());
 //BA.debugLineNum = 385;BA.debugLine="Return lim.html";
if (true) return _lim._html();
 }else {
 //BA.debugLineNum = 387;BA.debugLine="Return Element.html";
if (true) return _element._html();
 };
 //BA.debugLineNum = 389;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
