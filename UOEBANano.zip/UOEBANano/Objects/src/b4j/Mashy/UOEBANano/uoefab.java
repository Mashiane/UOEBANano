package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoefab extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoefab", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoefab.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public b4j.Mashy.UOEBANano.uoeanchoricon _ai = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _href = "";
public String _iconname = "";
public String _icontheme = "";
public String _theme = "";
public boolean _pulse = false;
public String _zdepth = "";
public String _visibility = "";
public String _size = "";
public boolean _click2toggle = false;
public anywheresoftware.b4a.objects.collections.List _buttons = null;
public String _direction = "";
public boolean _hoverenabled = false;
public boolean _toolbarenabled = false;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoefab  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 72;BA.debugLine="ai.AddAttribute(attr,value)";
_ai._addattribute(_attr,_value);
 //BA.debugLineNum = 73;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefab)(this);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public String  _addbutton(String _btnid,String _btnicon,String _btnnav2,String _btntheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoebutton _b = null;
 //BA.debugLineNum = 83;BA.debugLine="Sub AddButton(btnID As String, btnIcon As String,";
 //BA.debugLineNum = 84;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 85;BA.debugLine="li.Initialize(\"\",\"li\")";
_li._initialize(ba,"","li");
 //BA.debugLineNum = 86;BA.debugLine="Dim b As UOEButton";
_b = new b4j.Mashy.UOEBANano.uoebutton();
 //BA.debugLineNum = 87;BA.debugLine="b.Initialize(App,btnID,\"\",btnTheme)";
_b._initialize(ba,_app,_btnid,"",_btntheme);
 //BA.debugLineNum = 88;BA.debugLine="b.Setbuttontype(App.EnumButtonType.floating)";
_b._setbuttontype(_app._enumbuttontype._floating);
 //BA.debugLineNum = 89;BA.debugLine="b.href = btnNav2";
_b._href = _btnnav2;
 //BA.debugLineNum = 90;BA.debugLine="b.AddIcon(btnIcon,\"\",btnTheme,False,False)";
_b._addicon(_btnicon,"",_btntheme,__c.False,__c.False);
 //BA.debugLineNum = 91;BA.debugLine="b.waveseffect = False";
_b._waveseffect = __c.False;
 //BA.debugLineNum = 92;BA.debugLine="b.FitWidth = False";
_b._fitwidth = __c.False;
 //BA.debugLineNum = 93;BA.debugLine="li.AddContent(b.tostring)";
_li._addcontent(_b._tostring());
 //BA.debugLineNum = 94;BA.debugLine="buttons.Add(li.html)";
_buttons.Add((Object)(_li._html()));
 //BA.debugLineNum = 95;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 96;BA.debugLine="App.AddEvent(btnID,\"click\")";
_app._addevent(_btnid,"click");
 };
 //BA.debugLineNum = 98;BA.debugLine="App.HeadersToFix.Put(ID,ID)";
_app._headerstofix.Put((Object)(_id),(Object)(_id));
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoefab  _addclass(String _sclass) throws Exception{
boolean _bh = false;
 //BA.debugLineNum = 55;BA.debugLine="Sub AddClass(sClass As String) As UOEFAB";
 //BA.debugLineNum = 56;BA.debugLine="ai.AddClass(sClass)";
_ai._addclass(_sclass);
 //BA.debugLineNum = 57;BA.debugLine="Dim bh As Boolean = sClass.Contains(\"pulse\")";
_bh = _sclass.contains("pulse");
 //BA.debugLineNum = 58;BA.debugLine="If bh Then";
if (_bh) { 
 //BA.debugLineNum = 59;BA.debugLine="Pulse = True";
_pulse = __c.True;
 };
 //BA.debugLineNum = 61;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefab)(this);
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefab  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 26;BA.debugLine="ai.AddStyleAttribute(attribute,value)";
_ai._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 27;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefab)(this);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Private ai As UOEAnchorIcon";
_ai = new b4j.Mashy.UOEBANano.uoeanchoricon();
 //BA.debugLineNum = 6;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 7;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 8;BA.debugLine="Private href As String";
_href = "";
 //BA.debugLineNum = 9;BA.debugLine="Private IconName As String";
_iconname = "";
 //BA.debugLineNum = 10;BA.debugLine="Private IconTheme As String";
_icontheme = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Pulse As Boolean";
_pulse = false;
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Size As String";
_size = "";
 //BA.debugLineNum = 16;BA.debugLine="Public Click2Toggle As Boolean";
_click2toggle = false;
 //BA.debugLineNum = 17;BA.debugLine="Private buttons As List";
_buttons = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 18;BA.debugLine="Public Direction As String";
_direction = "";
 //BA.debugLineNum = 19;BA.debugLine="Public hoverEnabled As Boolean";
_hoverenabled = false;
 //BA.debugLineNum = 20;BA.debugLine="Private toolbarEnabled As Boolean";
_toolbarenabled = false;
 //BA.debugLineNum = 21;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
String _script = "";
 //BA.debugLineNum = 138;BA.debugLine="Sub Close";
 //BA.debugLineNum = 139;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"div');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.FloatingActionButton.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".close();");
 //BA.debugLineNum = 142;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _dpsettings = null;
String _strds = "";
 //BA.debugLineNum = 145;BA.debugLine="public Sub GetSettings As String";
 //BA.debugLineNum = 146;BA.debugLine="Dim dpSettings As Map";
_dpsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 147;BA.debugLine="dpSettings.Initialize";
_dpsettings.Initialize();
 //BA.debugLineNum = 148;BA.debugLine="dpSettings.clear";
_dpsettings.Clear();
 //BA.debugLineNum = 149;BA.debugLine="dpSettings.Put(\"id\", ID)";
_dpsettings.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 150;BA.debugLine="dpSettings.Put(\"instance\", \"floatingActionButton\"";
_dpsettings.Put((Object)("instance"),(Object)("floatingActionButton"));
 //BA.debugLineNum = 151;BA.debugLine="dpSettings.Put(\"hoverEnabled\", hoverEnabled)";
_dpsettings.Put((Object)("hoverEnabled"),(Object)(_hoverenabled));
 //BA.debugLineNum = 152;BA.debugLine="dpSettings.Put(\"direction\", Direction)";
_dpsettings.Put((Object)("direction"),(Object)(_direction));
 //BA.debugLineNum = 153;BA.debugLine="dpSettings.Put(\"toolbarEnabled\", toolbarEnabled)";
_dpsettings.Put((Object)("toolbarEnabled"),(Object)(_toolbarenabled));
 //BA.debugLineNum = 154;BA.debugLine="Dim strDS As String = App.Map2JSON(dpSettings)";
_strds = _app._map2json(_dpsettings);
 //BA.debugLineNum = 155;BA.debugLine="Return strDS";
if (true) return _strds;
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _shref,String _siconname,String _ssize,String _svisibility,String _sicontheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 32;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 33;BA.debugLine="If sIconTheme = \"\" Then sIconTheme = \"white.lb\"";
if ((_sicontheme).equals("")) { 
_sicontheme = "white.lb";};
 //BA.debugLineNum = 34;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 35;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 36;BA.debugLine="IconName = sIconName";
_iconname = _siconname;
 //BA.debugLineNum = 37;BA.debugLine="IconTheme = sIconTheme";
_icontheme = _sicontheme;
 //BA.debugLineNum = 38;BA.debugLine="href = shref";
_href = _shref;
 //BA.debugLineNum = 39;BA.debugLine="ZDepth=\"\"";
_zdepth = "";
 //BA.debugLineNum = 40;BA.debugLine="Size = sSize";
_size = _ssize;
 //BA.debugLineNum = 41;BA.debugLine="Click2Toggle =False";
_click2toggle = __c.False;
 //BA.debugLineNum = 42;BA.debugLine="ai.Initialize(App,ID,IconName,\"\",False,\"\",href,Fa";
_ai._initialize(ba,_app,_id,_iconname,"",__c.False,"",_href,__c.False,_sicontheme,"");
 //BA.debugLineNum = 43;BA.debugLine="ai.Floating = True";
_ai._floating = __c.True;
 //BA.debugLineNum = 44;BA.debugLine="Theme = sIconTheme";
_theme = _sicontheme;
 //BA.debugLineNum = 45;BA.debugLine="Direction = App.EnumFABDirection.Top";
_direction = _app._enumfabdirection._top;
 //BA.debugLineNum = 46;BA.debugLine="Visibility = sVisibility";
_visibility = _svisibility;
 //BA.debugLineNum = 47;BA.debugLine="hoverEnabled = True";
_hoverenabled = __c.True;
 //BA.debugLineNum = 48;BA.debugLine="toolbarEnabled = False";
_toolbarenabled = __c.False;
 //BA.debugLineNum = 49;BA.debugLine="buttons.Initialize";
_buttons.Initialize();
 //BA.debugLineNum = 50;BA.debugLine="buttons.clear";
_buttons.Clear();
 //BA.debugLineNum = 51;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
String _script = "";
 //BA.debugLineNum = 130;BA.debugLine="Sub Open";
 //BA.debugLineNum = 131;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"div');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.FloatingActionButton.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".open();");
 //BA.debugLineNum = 134;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoefab  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 77;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEFAB";
 //BA.debugLineNum = 78;BA.debugLine="ai.RemoveAttribute(attr)";
_ai._removeattribute(_attr);
 //BA.debugLineNum = 79;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefab)(this);
 //BA.debugLineNum = 80;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefab  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub RemoveClass(sClass As String) As UOEFAB";
 //BA.debugLineNum = 66;BA.debugLine="ai.RemoveClass(sClass)";
_ai._removeclass(_sclass);
 //BA.debugLineNum = 67;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefab)(this);
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 103;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 104;BA.debugLine="ai.ID = ID";
_ai._id = _id;
 //BA.debugLineNum = 105;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 106;BA.debugLine="ai.a.ID = ID";
_ai._a._id = _id;
 //BA.debugLineNum = 112;BA.debugLine="modUOE.MaterialAddIcon(App,ai.a,IconName,\"\",IconT";
_moduoe._materialaddicon(_app,_ai._a,_iconname,"",_icontheme,__c.True,__c.False,__c.False,__c.False,__c.False);
 //BA.debugLineNum = 113;BA.debugLine="ai.a.MaterialPulse(Pulse)";
_ai._a._materialpulse(_pulse);
 //BA.debugLineNum = 114;BA.debugLine="ai.a.MaterialVisibility(Visibility)";
_ai._a._materialvisibility(_visibility);
 //BA.debugLineNum = 115;BA.debugLine="ai.a.MaterialButtonSize(Size)";
_ai._a._materialbuttonsize(_size);
 //BA.debugLineNum = 116;BA.debugLine="ai.Click2Toggle = Click2Toggle";
_ai._click2toggle = _click2toggle;
 //BA.debugLineNum = 117;BA.debugLine="ai.Horizontal = toolbarEnabled";
_ai._horizontal = _toolbarenabled;
 //BA.debugLineNum = 118;BA.debugLine="ai.buttons = buttons";
_ai._buttons = _buttons;
 //BA.debugLineNum = 119;BA.debugLine="ai.isfab = True";
_ai._isfab = __c.True;
 //BA.debugLineNum = 120;BA.debugLine="ai.IsToolBar = toolbarEnabled";
_ai._istoolbar = _toolbarenabled;
 //BA.debugLineNum = 125;BA.debugLine="App.ApplyToolTip(ID,ai.a)";
_app._applytooltip(_id,_ai._a);
 //BA.debugLineNum = 126;BA.debugLine="Return ai.tostring";
if (true) return _ai._tostring();
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
