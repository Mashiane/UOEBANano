package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoechip extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoechip", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoechip.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _imageurl = "";
public String _text = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _imagealt = "";
public boolean _canclose = false;
public String _theme = "";
public String _visibility = "";
public boolean _waveseffect = false;
public String _wavestype = "";
public boolean _wavescircle = false;
public String _zdepth = "";
public boolean _enabled = false;
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoechip  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 58;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 59;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechip)(this);
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechip  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 45;BA.debugLine="Sub AddClass(sClass As String) As UOEChip";
 //BA.debugLineNum = 46;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 47;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechip)(this);
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechip  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 23;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 24;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechip)(this);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public ImageURL As String";
_imageurl = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Text As String";
_text = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public ImageAlt As String";
_imagealt = "";
 //BA.debugLineNum = 10;BA.debugLine="Public CanClose As Boolean";
_canclose = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public WavesEffect As Boolean";
_waveseffect = false;
 //BA.debugLineNum = 14;BA.debugLine="Public WavesType As String";
_wavestype = "";
 //BA.debugLineNum = 15;BA.debugLine="Public WavesCircle As Boolean";
_wavescircle = false;
 //BA.debugLineNum = 16;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 17;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _chipid,String _chiptext,String _chipimg,String _chipimgalt,String _chiptheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 28;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, chipID As";
 //BA.debugLineNum = 30;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 31;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 32;BA.debugLine="ImageURL = chipImg";
_imageurl = _chipimg;
 //BA.debugLineNum = 33;BA.debugLine="Text = chipText";
_text = _chiptext;
 //BA.debugLineNum = 34;BA.debugLine="ID = chipID.tolowercase";
_id = _chipid.toLowerCase();
 //BA.debugLineNum = 35;BA.debugLine="CanClose = False";
_canclose = __c.False;
 //BA.debugLineNum = 36;BA.debugLine="Theme = chipTheme";
_theme = _chiptheme;
 //BA.debugLineNum = 37;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 38;BA.debugLine="Element.AddClass(\"chip\")";
_element._addclass("chip");
 //BA.debugLineNum = 39;BA.debugLine="WavesType = App.EnumWavesType.Light";
_wavestype = _app._enumwavestype._light;
 //BA.debugLineNum = 40;BA.debugLine="WavesCircle = False";
_wavescircle = __c.False;
 //BA.debugLineNum = 41;BA.debugLine="WavesEffect = True";
_waveseffect = __c.True;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoechip  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEChip";
 //BA.debugLineNum = 64;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 65;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechip)(this);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoechip  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 51;BA.debugLine="Sub RemoveClass(sClass As String) As UOEChip";
 //BA.debugLineNum = 52;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoechip)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 70;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 71;BA.debugLine="If Theme = \"\" Then Theme = App.theme";
if ((_theme).equals("")) { 
_theme = _app._theme;};
 //BA.debugLineNum = 76;BA.debugLine="modUOE.MaterialAddImage(App,Element,ImageURL,Imag";
_moduoe._materialaddimage(_app,_element,_imageurl,_imagealt,"","",__c.False,__c.True,__c.True,"");
 //BA.debugLineNum = 77;BA.debugLine="Element.AddContent(Text)";
_element._addcontent(_text);
 //BA.debugLineNum = 78;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 79;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 80;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 81;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 82;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 83;BA.debugLine="Element.MaterialWavesEffect(WavesEffect)";
_element._materialwaveseffect(_waveseffect);
 //BA.debugLineNum = 84;BA.debugLine="Element.MaterialWavesType(WavesType)";
_element._materialwavestype(_wavestype);
 //BA.debugLineNum = 85;BA.debugLine="Element.MaterialWavesCircle(WavesCircle)";
_element._materialwavescircle(_wavescircle);
 //BA.debugLineNum = 86;BA.debugLine="If CanClose = True Then";
if (_canclose==__c.True) { 
 //BA.debugLineNum = 87;BA.debugLine="modUOE.MaterialAddIcon(App,Element,\"mdi-close\",T";
_moduoe._materialaddicon(_app,_element,"mdi-close",_theme,"",__c.False,__c.True,__c.True,__c.False,_canclose);
 };
 //BA.debugLineNum = 93;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
