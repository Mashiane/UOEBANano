package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeswitch extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeswitch", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeswitch.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _ontext = "";
public String _offtext = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _switch = null;
public boolean _hoverable = false;
public String _title = "";
public String _visibility = "";
public String _zdepth = "";
public String _theme = "";
public boolean _showtitle = false;
public boolean _checked = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeswitch  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 53;BA.debugLine="switch.AddAttribute(attr,value)";
_switch._addattribute(_attr,_value);
 //BA.debugLineNum = 54;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeswitch)(this);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeswitch  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Sub AddClass(sClass As String) As UOESwitch";
 //BA.debugLineNum = 65;BA.debugLine="switch.AddClass(sClass)";
_switch._addclass(_sclass);
 //BA.debugLineNum = 66;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeswitch)(this);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeswitch  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 23;BA.debugLine="switch.AddStyleAttribute(attribute,value)";
_switch._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 24;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeswitch)(this);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private OnText As String";
_ontext = "";
 //BA.debugLineNum = 7;BA.debugLine="Private OffText As String";
_offtext = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Private switch As UOEHTML";
_switch = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 10;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 11;BA.debugLine="Private Title As String";
_title = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Private theme As String";
_theme = "";
 //BA.debugLineNum = 16;BA.debugLine="Private ShowTitle As Boolean";
_showtitle = false;
 //BA.debugLineNum = 17;BA.debugLine="Public Checked As Boolean";
_checked = false;
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,String _sontext,String _sofftext,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 29;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 31;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 32;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 33;BA.debugLine="OnText = sOnText";
_ontext = _sontext;
 //BA.debugLineNum = 34;BA.debugLine="OffText = sOffText";
_offtext = _sofftext;
 //BA.debugLineNum = 35;BA.debugLine="switch.Initialize(ID,\"div\")";
_switch._initialize(ba,_id,"div");
 //BA.debugLineNum = 36;BA.debugLine="switch.AddClass(\"switch\")";
_switch._addclass("switch");
 //BA.debugLineNum = 37;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 38;BA.debugLine="theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 39;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 40;BA.debugLine="ShowTitle = True";
_showtitle = __c.True;
 //BA.debugLineNum = 41;BA.debugLine="Checked = False";
_checked = __c.False;
 //BA.debugLineNum = 42;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeswitch  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub RemoveAttribute(attr As String) As UOESwitch";
 //BA.debugLineNum = 59;BA.debugLine="switch.RemoveAttribute(attr)";
_switch._removeattribute(_attr);
 //BA.debugLineNum = 60;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeswitch)(this);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeswitch  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub RemoveClass(sClass As String) As UOESwitch";
 //BA.debugLineNum = 47;BA.debugLine="switch.RemoveClass(sClass)";
_switch._removeclass(_sclass);
 //BA.debugLineNum = 48;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeswitch)(this);
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
b4j.Mashy.UOEBANano.uoehtml _inp = null;
b4j.Mashy.UOEBANano.uoehtml _span = null;
b4j.Mashy.UOEBANano.uoehtml _p = null;
 //BA.debugLineNum = 70;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 71;BA.debugLine="switch.MaterialEnable(Enabled)";
_switch._materialenable(_enabled);
 //BA.debugLineNum = 72;BA.debugLine="switch.MaterialZDepth(ZDepth)";
_switch._materialzdepth(_zdepth);
 //BA.debugLineNum = 73;BA.debugLine="switch.MaterialVisibility(Visibility)";
_switch._materialvisibility(_visibility);
 //BA.debugLineNum = 74;BA.debugLine="App.ApplyToolTip(ID,switch)";
_app._applytooltip(_id,_switch);
 //BA.debugLineNum = 75;BA.debugLine="switch.ID = ID";
_switch._id = _id;
 //BA.debugLineNum = 76;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 77;BA.debugLine="lbl.Initialize(\"\",\"label\")";
_lbl._initialize(ba,"","label");
 //BA.debugLineNum = 78;BA.debugLine="lbl.AddContent(OffText)";
_lbl._addcontent(_offtext);
 //BA.debugLineNum = 79;BA.debugLine="Dim inp As UOEHTML";
_inp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 80;BA.debugLine="inp.Initialize($\"${ID}-inp\"$,\"input\")";
_inp._initialize(ba,(""+__c.SmartStringFormatter("",(Object)(_id))+"-inp"),"input");
 //BA.debugLineNum = 81;BA.debugLine="inp.AddAttribute(\"type\",\"checkbox\")";
_inp._addattribute("type","checkbox");
 //BA.debugLineNum = 82;BA.debugLine="inp.AddAttributeOnCondition(Not(Enabled),\"disable";
_inp._addattributeoncondition(__c.Not(_enabled),"disabled","true");
 //BA.debugLineNum = 83;BA.debugLine="inp.AddAttributeOnCondition(Checked,\"checked\",\"ch";
_inp._addattributeoncondition(_checked,"checked","checked");
 //BA.debugLineNum = 84;BA.debugLine="Dim span As UOEHTML";
_span = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 85;BA.debugLine="span.Initialize(ID & \"-span\",\"span\")";
_span._initialize(ba,_id+"-span","span");
 //BA.debugLineNum = 86;BA.debugLine="span.AddClass(\"lever\")";
_span._addclass("lever");
 //BA.debugLineNum = 87;BA.debugLine="lbl.AddContent(inp.HTML)";
_lbl._addcontent(_inp._html());
 //BA.debugLineNum = 88;BA.debugLine="lbl.AddContent(span.HTML)";
_lbl._addcontent(_span._html());
 //BA.debugLineNum = 89;BA.debugLine="lbl.AddContent(OnText)";
_lbl._addcontent(_ontext);
 //BA.debugLineNum = 90;BA.debugLine="switch.AddContent(lbl.HTML)";
_switch._addcontent(_lbl._html());
 //BA.debugLineNum = 91;BA.debugLine="If ShowTitle = False Then Return switch.HTML";
if (_showtitle==__c.False) { 
if (true) return _switch._html();};
 //BA.debugLineNum = 92;BA.debugLine="Dim p As UOEHTML";
_p = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 93;BA.debugLine="p.Initialize(\"\",\"p\")";
_p._initialize(ba,"","p");
 //BA.debugLineNum = 94;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 95;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 96;BA.debugLine="lbl.SetFOR(ID).AddContent(Title)";
_lbl._setfor(_id)._addcontent(_title);
 //BA.debugLineNum = 97;BA.debugLine="App.MaterialUseTheme(theme,lbl)";
_app._materialusetheme(_theme,_lbl);
 //BA.debugLineNum = 98;BA.debugLine="p.AddElement(lbl)";
_p._addelement(_lbl);
 //BA.debugLineNum = 99;BA.debugLine="p.AddContent(switch.HTML)";
_p._addcontent(_switch._html());
 //BA.debugLineNum = 104;BA.debugLine="Return p.html";
if (true) return _p._html();
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
