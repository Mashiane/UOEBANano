package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoerangeslider extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoerangeslider", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoerangeslider.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public float _minvalue = 0f;
public float _maxvalue = 0f;
public b4j.Mashy.UOEBANano.uoehtml _range = null;
public boolean _hoverable = false;
public String _title = "";
public boolean _enabled = false;
public String _visibility = "";
public String _zdepth = "";
public String _theme = "";
public boolean _connect = false;
public float _startat = 0f;
public float _stopat = 0f;
public float _stepa = 0f;
public String _orientation = "";
public int _decimals = 0;
public boolean _showtitle = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoerangeslider  _addattribute(String _attr,String _svalue) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Sub AddAttribute(attr As String, sValue As String)";
 //BA.debugLineNum = 65;BA.debugLine="range.AddAttribute(attr,sValue)";
_range._addattribute(_attr,_svalue);
 //BA.debugLineNum = 66;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerangeslider)(this);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerangeslider  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Sub AddClass(sClass As String)  As UOERangeSlider";
 //BA.debugLineNum = 53;BA.debugLine="range.AddClass(sClass)";
_range._addclass(_sclass);
 //BA.debugLineNum = 54;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerangeslider)(this);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerangeslider  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 26;BA.debugLine="range.AddStyleAttribute(attribute,value)";
_range._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 27;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerangeslider)(this);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private MinValue As Float";
_minvalue = 0f;
 //BA.debugLineNum = 7;BA.debugLine="Private MaxValue As Float";
_maxvalue = 0f;
 //BA.debugLineNum = 8;BA.debugLine="Private range As UOEHTML";
_range = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 10;BA.debugLine="Private Title As String";
_title = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 14;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 15;BA.debugLine="Private Connect As Boolean";
_connect = false;
 //BA.debugLineNum = 16;BA.debugLine="Private StartAt As Float";
_startat = 0f;
 //BA.debugLineNum = 17;BA.debugLine="Private StopAt As Float";
_stopat = 0f;
 //BA.debugLineNum = 18;BA.debugLine="Private StepA As Float";
_stepa = 0f;
 //BA.debugLineNum = 19;BA.debugLine="Private Orientation As String";
_orientation = "";
 //BA.debugLineNum = 20;BA.debugLine="Public Decimals As Int";
_decimals = 0;
 //BA.debugLineNum = 21;BA.debugLine="Public ShowTitle As Boolean";
_showtitle = false;
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _bconnect = "";
String _script = "";
 //BA.debugLineNum = 109;BA.debugLine="Sub getJavaScript As String";
 //BA.debugLineNum = 110;BA.debugLine="Dim bConnect As String = App.iif(Connect,\"true\",\"";
_bconnect = BA.ObjectToString(_app._iif(BA.ObjectToString(_connect),(Object)("true"),(Object)("false")));
 //BA.debugLineNum = 111;BA.debugLine="Dim script As String = $\"var slider${ID} = docume";
_script = ("var slider"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"  noUiSlider.create(slider"+__c.SmartStringFormatter("",(Object)(_id))+", {\n"+"   start: ["+__c.SmartStringFormatter("",(Object)(_startat))+", "+__c.SmartStringFormatter("",(Object)(_stopat))+"],\n"+"   connect: "+__c.SmartStringFormatter("",(Object)(_bconnect))+",\n"+"   step: "+__c.SmartStringFormatter("",(Object)(_stepa))+",\n"+"   orientation: '"+__c.SmartStringFormatter("",(Object)(_orientation))+"',\n"+"   range: {\n"+"	'min': "+__c.SmartStringFormatter("",(Object)(_minvalue))+",\n"+"	'max': "+__c.SmartStringFormatter("",(Object)(_maxvalue))+"\n"+"   },\n"+"   format: wNumb({\n"+"     decimals: "+__c.SmartStringFormatter("",(Object)(_decimals))+"\n"+"   })\n"+"  });");
 //BA.debugLineNum = 125;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 126;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,float _lstart,float _lstop,float _sminvalue,float _smaxvalue,float _lstep,boolean _bconnect,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 31;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 33;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 34;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 35;BA.debugLine="MaxValue = sMaxValue";
_maxvalue = _smaxvalue;
 //BA.debugLineNum = 36;BA.debugLine="MinValue = sMinValue";
_minvalue = _sminvalue;
 //BA.debugLineNum = 37;BA.debugLine="Connect = bConnect";
_connect = _bconnect;
 //BA.debugLineNum = 38;BA.debugLine="StartAt = lStart";
_startat = _lstart;
 //BA.debugLineNum = 39;BA.debugLine="StopAt = lStop";
_stopat = _lstop;
 //BA.debugLineNum = 40;BA.debugLine="StepA = lStep";
_stepa = _lstep;
 //BA.debugLineNum = 41;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 42;BA.debugLine="range.Initialize(ID,\"div\")";
_range._initialize(ba,_id,"div");
 //BA.debugLineNum = 43;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 44;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 45;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 46;BA.debugLine="Orientation = App.EnumSliderOrientation.horizonta";
_orientation = _app._enumsliderorientation._horizontal;
 //BA.debugLineNum = 47;BA.debugLine="Decimals = 0";
_decimals = (int) (0);
 //BA.debugLineNum = 48;BA.debugLine="ShowTitle = True";
_showtitle = __c.True;
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoerangeslider  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Sub RemoveAttribute(attr As String)  As UOERangeSl";
 //BA.debugLineNum = 71;BA.debugLine="range.RemoveAttribute(attr)";
_range._removeattribute(_attr);
 //BA.debugLineNum = 72;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerangeslider)(this);
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerangeslider  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub RemoveClass(sClass As String)  As UOERangeSlid";
 //BA.debugLineNum = 59;BA.debugLine="range.RemoveClass(sClass)";
_range._removeclass(_sclass);
 //BA.debugLineNum = 60;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerangeslider)(this);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _p = null;
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
 //BA.debugLineNum = 77;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 78;BA.debugLine="range.MaterialEnable(Enabled)";
_range._materialenable(_enabled);
 //BA.debugLineNum = 79;BA.debugLine="range.MaterialZDepth(ZDepth)";
_range._materialzdepth(_zdepth);
 //BA.debugLineNum = 80;BA.debugLine="range.MaterialVisibility(Visibility)";
_range._materialvisibility(_visibility);
 //BA.debugLineNum = 81;BA.debugLine="App.ApplyToolTip(ID,range)";
_app._applytooltip(_id,_range);
 //BA.debugLineNum = 82;BA.debugLine="If ShowTitle Then";
if (_showtitle) { 
 //BA.debugLineNum = 83;BA.debugLine="Dim p As UOEHTML";
_p = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 84;BA.debugLine="p.Initialize(ID & \"parent\",\"p\")";
_p._initialize(ba,_id+"parent","p");
 //BA.debugLineNum = 85;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 86;BA.debugLine="lbl.Initialize(ID & \"lbl\",\"label\")";
_lbl._initialize(ba,_id+"lbl","label");
 //BA.debugLineNum = 87;BA.debugLine="lbl.SetFOR(ID)";
_lbl._setfor(_id);
 //BA.debugLineNum = 88;BA.debugLine="lbl.AddContent(Title)";
_lbl._addcontent(_title);
 //BA.debugLineNum = 89;BA.debugLine="App.MaterialUseTheme(Theme,lbl)";
_app._materialusetheme(_theme,_lbl);
 //BA.debugLineNum = 90;BA.debugLine="p.AddElement(lbl)";
_p._addelement(_lbl);
 //BA.debugLineNum = 91;BA.debugLine="p.AddContent(range.HTML)";
_p._addcontent(_range._html());
 //BA.debugLineNum = 98;BA.debugLine="Return p.html";
if (true) return _p._html();
 }else {
 //BA.debugLineNum = 104;BA.debugLine="Return range.html";
if (true) return _range._html();
 };
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
