package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeprism extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeprism", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeprism.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _zdepth = "";
public String _visibility = "";
public boolean _hoverable = false;
public b4j.Mashy.UOEBANano.uoehtml _codeel = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeprism  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 34;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 35;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 36;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 37;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprism  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 22;BA.debugLine="Sub AddClass(sClass As String) As UOEPrism";
 //BA.debugLineNum = 23;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 24;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprism  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 16;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 17;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 18;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprism  _addtext(String _stext) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub AddText(sText As String) As UOEPrism";
 //BA.debugLineNum = 47;BA.debugLine="sText = sText.Replace(\" \", \"&nbsp;\")";
_stext = _stext.replace(" ","&nbsp;");
 //BA.debugLineNum = 48;BA.debugLine="sText = sText.Replace(QUOTE,\"&quot;\")";
_stext = _stext.replace(__c.QUOTE,"&quot;");
 //BA.debugLineNum = 49;BA.debugLine="sText = sText.Replace(\"'\",\"&apos;\")";
_stext = _stext.replace("'","&apos;");
 //BA.debugLineNum = 50;BA.debugLine="sText = sText.Replace(\"<\",\"&lt;\")";
_stext = _stext.replace("<","&lt;");
 //BA.debugLineNum = 51;BA.debugLine="sText = sText.Replace(\">\",\"&gt;\")";
_stext = _stext.replace(">","&gt;");
 //BA.debugLineNum = 52;BA.debugLine="codeEL.AddContent(sText)";
_codeel._addcontent(_stext);
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 6;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 10;BA.debugLine="Private codeEL As UOEHTML";
_codeel = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public String  _getjavascript() throws Exception{
String _script = "";
 //BA.debugLineNum = 93;BA.debugLine="Sub GetJavaScript As String";
 //BA.debugLineNum = 94;BA.debugLine="Dim script As String = $\"var ${ID}block = documen";
_script = ("var "+__c.SmartStringFormatter("",(Object)(_id))+"block = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_codeel._id))+"');\n"+"	Prism.highlightElement("+__c.SmartStringFormatter("",(Object)(_id))+"block);");
 //BA.debugLineNum = 96;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeprism  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _btext,String _lang) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 57;BA.debugLine="Sub Initialize(thisApp As UOEApp, sID As String,bT";
 //BA.debugLineNum = 58;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 59;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 60;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 61;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 62;BA.debugLine="bText = bText.Replace(\" \", \"&nbsp;\")";
_btext = _btext.replace(" ","&nbsp;");
 //BA.debugLineNum = 63;BA.debugLine="bText = bText.Replace(QUOTE,\"&quot;\")";
_btext = _btext.replace(__c.QUOTE,"&quot;");
 //BA.debugLineNum = 64;BA.debugLine="bText = bText.Replace(\"'\",\"&apos;\")";
_btext = _btext.replace("'","&apos;");
 //BA.debugLineNum = 65;BA.debugLine="bText = bText.Replace(\"<\",\"&lt;\")";
_btext = _btext.replace("<","&lt;");
 //BA.debugLineNum = 66;BA.debugLine="bText = bText.Replace(\">\",\"&gt;\")";
_btext = _btext.replace(">","&gt;");
 //BA.debugLineNum = 67;BA.debugLine="Element.Initialize(ID,\"pre\")";
_element._initialize(ba,_id,"pre");
 //BA.debugLineNum = 68;BA.debugLine="Element.AddClass(\"language-\" & lang)";
_element._addclass("language-"+_lang);
 //BA.debugLineNum = 69;BA.debugLine="Element.AddClass(\"line-numbers\")";
_element._addclass("line-numbers");
 //BA.debugLineNum = 70;BA.debugLine="Element.AddAttribute(\"data-src\", \"prism-line-numb";
_element._addattribute("data-src","prism-line-numbers.js");
 //BA.debugLineNum = 71;BA.debugLine="codeEL.Initialize(ID & \"-code\",\"code\")";
_codeel._initialize(ba,_id+"-code","code");
 //BA.debugLineNum = 72;BA.debugLine="codeEL.AddContent(bText)";
_codeel._addcontent(_btext);
 //BA.debugLineNum = 73;BA.debugLine="codeEL.AddClass(\"col s12\")";
_codeel._addclass("col s12");
 //BA.debugLineNum = 74;BA.debugLine="codeEL.AddClass(\"language-\" & lang)";
_codeel._addclass("language-"+_lang);
 //BA.debugLineNum = 75;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprism  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEPrism";
 //BA.debugLineNum = 41;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 42;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeprism  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub RemoveClass(sClass As String) As UOEPrism";
 //BA.debugLineNum = 29;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 30;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeprism)(this);
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 79;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 80;BA.debugLine="ID = ID.tolowercase";
_id = _id.toLowerCase();
 //BA.debugLineNum = 82;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 83;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 84;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 85;BA.debugLine="Element.AddElement(codeEL)";
_element._addelement(_codeel);
 //BA.debugLineNum = 90;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
