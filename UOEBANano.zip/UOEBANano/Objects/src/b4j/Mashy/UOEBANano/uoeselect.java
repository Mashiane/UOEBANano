package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeselect extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeselect", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeselect.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _title = "";
public String _theme = "";
public String _prompt = "";
public b4j.Mashy.UOEBANano.uoehtml _div = null;
public b4j.Mashy.UOEBANano.uoehtml _sel = null;
public b4j.Mashy.UOEBANano.uoehtml _lbl = null;
public boolean _enabled = false;
public boolean _inline = false;
public String _iconname = "";
public boolean _multiple = false;
public anywheresoftware.b4a.objects.collections.List _items = null;
public boolean _isicons = false;
public boolean _hoverable = false;
public String _visibility = "";
public String _zdepth = "";
public boolean _autofocus = false;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeselect  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 68;BA.debugLine="div.AddAttribute(attr,value)";
_div._addattribute(_attr,_value);
 //BA.debugLineNum = 69;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub AddClass(sClass As String) As UOESelect";
 //BA.debugLineNum = 56;BA.debugLine="div.AddClass(sClass)";
_div._addclass(_sclass);
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _addimage(String _itemid,String _itemvalue,String _itemtext,String _itemimageurl,String _itemalignment,boolean _itemcircle) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _opt = null;
 //BA.debugLineNum = 89;BA.debugLine="Sub AddImage(itemID As String, itemValue As String";
 //BA.debugLineNum = 90;BA.debugLine="isicons = True";
_isicons = __c.True;
 //BA.debugLineNum = 91;BA.debugLine="Dim opt As UOEHTML";
_opt = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 92;BA.debugLine="opt.Initialize(itemID,\"option\")";
_opt._initialize(ba,_itemid,"option");
 //BA.debugLineNum = 93;BA.debugLine="opt.AddAttribute(\"value\",itemValue)";
_opt._addattribute("value",_itemvalue);
 //BA.debugLineNum = 94;BA.debugLine="opt.AddAttribute(\"data-icon\", itemImageURL)";
_opt._addattribute("data-icon",_itemimageurl);
 //BA.debugLineNum = 95;BA.debugLine="opt.AddClassOnCondition(itemCircle,\"circle\")";
_opt._addclassoncondition(_itemcircle,"circle");
 //BA.debugLineNum = 96;BA.debugLine="opt.AddClass(itemAlignment)";
_opt._addclass(_itemalignment);
 //BA.debugLineNum = 97;BA.debugLine="opt.AddContent(itemText)";
_opt._addcontent(_itemtext);
 //BA.debugLineNum = 98;BA.debugLine="items.Add(opt.HTML)";
_items.Add((Object)(_opt._html()));
 //BA.debugLineNum = 99;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _additem(String _itemid,String _itemvalue,String _itemtext) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _opt = null;
 //BA.debugLineNum = 79;BA.debugLine="Sub AddItem(itemID As String, itemValue As String,";
 //BA.debugLineNum = 80;BA.debugLine="Dim opt As UOEHTML";
_opt = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 81;BA.debugLine="opt.Initialize(itemID,\"option\")";
_opt._initialize(ba,_itemid,"option");
 //BA.debugLineNum = 82;BA.debugLine="opt.AddAttribute(\"value\",itemValue)";
_opt._addattribute("value",_itemvalue);
 //BA.debugLineNum = 83;BA.debugLine="opt.AddContent(itemText)";
_opt._addcontent(_itemtext);
 //BA.debugLineNum = 84;BA.debugLine="items.Add(opt.HTML)";
_items.Add((Object)(_opt._html()));
 //BA.debugLineNum = 85;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 86;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 28;BA.debugLine="div.AddStyleAttribute(attribute,value)";
_div._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 29;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Title As String";
_title = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Private Prompt As String";
_prompt = "";
 //BA.debugLineNum = 9;BA.debugLine="Private div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 10;BA.debugLine="Private sel As UOEHTML";
_sel = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Private lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 13;BA.debugLine="Public Inline As Boolean";
_inline = false;
 //BA.debugLineNum = 14;BA.debugLine="Public IconName As String";
_iconname = "";
 //BA.debugLineNum = 15;BA.debugLine="Private Multiple As Boolean";
_multiple = false;
 //BA.debugLineNum = 16;BA.debugLine="Private items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 17;BA.debugLine="Private isicons As Boolean";
_isicons = false;
 //BA.debugLineNum = 18;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 19;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 20;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 21;BA.debugLine="Public AutoFocus As Boolean";
_autofocus = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return "";
}
public String  _getselectedvalues(String _varname) throws Exception{
String _script = "";
 //BA.debugLineNum = 139;BA.debugLine="Sub GetSelectedValues(varName As String) As String";
 //BA.debugLineNum = 140;BA.debugLine="Dim script As String = $\"${varName} = ${Instance}";
_script = (""+__c.SmartStringFormatter("",(Object)(_varname))+" = "+__c.SmartStringFormatter("",(Object)(_instance))+".getSelectedValues();");
 //BA.debugLineNum = 141;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 142;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeselect  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _sicon,String _stitle,String _sprompt,boolean _bmultiple,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 33;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 35;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 36;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 37;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 38;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 39;BA.debugLine="Prompt = sPrompt";
_prompt = _sprompt;
 //BA.debugLineNum = 40;BA.debugLine="Inline = False";
_inline = __c.False;
 //BA.debugLineNum = 41;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 42;BA.debugLine="Multiple = bMultiple";
_multiple = _bmultiple;
 //BA.debugLineNum = 43;BA.debugLine="IconName = sIcon";
_iconname = _sicon;
 //BA.debugLineNum = 44;BA.debugLine="items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 45;BA.debugLine="items.clear";
_items.Clear();
 //BA.debugLineNum = 46;BA.debugLine="isicons=False";
_isicons = __c.False;
 //BA.debugLineNum = 47;BA.debugLine="AutoFocus = False";
_autofocus = __c.False;
 //BA.debugLineNum = 48;BA.debugLine="div.Initialize(ID & \"p\",\"div\")";
_div._initialize(ba,_id+"p","div");
 //BA.debugLineNum = 49;BA.debugLine="div.AddClass(\"input-field\").AddClass(\"col\").AddCl";
_div._addclass("input-field")._addclass("col")._addclass("s12")._addclass("m12")._addclass("l12");
 //BA.debugLineNum = 50;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 51;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 73;BA.debugLine="Sub RemoveAttribute(attr As String) As UOESelect";
 //BA.debugLineNum = 74;BA.debugLine="div.RemoveAttribute(attr)";
_div._removeattribute(_attr);
 //BA.debugLineNum = 75;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeselect  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub RemoveClass(sClass As String) As UOESelect";
 //BA.debugLineNum = 62;BA.debugLine="div.RemoveClass(sClass)";
_div._removeclass(_sclass);
 //BA.debugLineNum = 63;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeselect)(this);
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _opt = null;
 //BA.debugLineNum = 104;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 105;BA.debugLine="div.MaterialEnable(Enabled)";
_div._materialenable(_enabled);
 //BA.debugLineNum = 106;BA.debugLine="div.MaterialZDepth(ZDepth)";
_div._materialzdepth(_zdepth);
 //BA.debugLineNum = 107;BA.debugLine="div.MaterialVisibility(Visibility)";
_div._materialvisibility(_visibility);
 //BA.debugLineNum = 108;BA.debugLine="App.ApplyToolTip(ID,div)";
_app._applytooltip(_id,_div);
 //BA.debugLineNum = 109;BA.debugLine="div.AddClassOnCondition(Inline,\"inline\")";
_div._addclassoncondition(_inline,"inline");
 //BA.debugLineNum = 110;BA.debugLine="sel.Initialize(ID,\"select\")";
_sel._initialize(ba,_id,"select");
 //BA.debugLineNum = 111;BA.debugLine="sel.AddAttributeOnCondition(AutoFocus,\"autofocus\"";
_sel._addattributeoncondition(_autofocus,"autofocus","true");
 //BA.debugLineNum = 112;BA.debugLine="If Multiple = True Then sel.AddLooseAttribute(\"mu";
if (_multiple==__c.True) { 
_sel._addlooseattribute("multiple");};
 //BA.debugLineNum = 113;BA.debugLine="sel.AddClassOnCondition(isicons,\"icons\").Material";
_sel._addclassoncondition(_isicons,"icons")._materialenable(_enabled);
 //BA.debugLineNum = 115;BA.debugLine="If Prompt.Length > 0 Then";
if (_prompt.length()>0) { 
 //BA.debugLineNum = 116;BA.debugLine="Dim opt As UOEHTML";
_opt = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 117;BA.debugLine="opt.Initialize(\"\",\"option\")";
_opt._initialize(ba,"","option");
 //BA.debugLineNum = 118;BA.debugLine="opt.AddLooseAttribute(\"disabled\").AddLooseAttrib";
_opt._addlooseattribute("disabled")._addlooseattribute("selected");
 //BA.debugLineNum = 119;BA.debugLine="opt.AddContent(Prompt).AddAttribute(\"value\",\"\")";
_opt._addcontent(_prompt)._addattribute("value","");
 //BA.debugLineNum = 120;BA.debugLine="sel.AddContent(opt.HTML)";
_sel._addcontent(_opt._html());
 };
 //BA.debugLineNum = 122;BA.debugLine="sel.AddContentList(items)";
_sel._addcontentlist(_items);
 //BA.debugLineNum = 123;BA.debugLine="lbl.Initialize(\"\",\"label\")";
_lbl._initialize(ba,"","label");
 //BA.debugLineNum = 124;BA.debugLine="lbl.AddContent(Title)";
_lbl._addcontent(_title);
 //BA.debugLineNum = 125;BA.debugLine="modUOE.MaterialAddIcon(App,div,IconName,\"\",Theme,";
_moduoe._materialaddicon(_app,_div,_iconname,"",_theme,__c.False,__c.False,__c.False,__c.True,__c.False);
 //BA.debugLineNum = 126;BA.debugLine="div.AddContent(sel.HTML)";
_div._addcontent(_sel._html());
 //BA.debugLineNum = 127;BA.debugLine="div.AddContent(lbl.HTML)";
_div._addcontent(_lbl._html());
 //BA.debugLineNum = 135;BA.debugLine="Return div.html";
if (true) return _div._html();
 //BA.debugLineNum = 136;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
