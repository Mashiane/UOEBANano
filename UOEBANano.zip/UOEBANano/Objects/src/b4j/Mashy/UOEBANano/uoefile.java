package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoefile extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoefile", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoefile.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public b4j.Mashy.UOEBANano.uoehtml _fu = null;
public String _placeholder = "";
public boolean _hoverable = false;
public String _theme = "";
public boolean _enabled = false;
public String _zdepth = "";
public String _visibility = "";
public String _onchange = "";
public boolean _fixcell = false;
public boolean _validate = false;
public String _helpertext = "";
public String _errormsg = "";
public String _successmsg = "";
public b4j.Mashy.UOEBANano.uoehtml _btn = null;
public b4j.Mashy.UOEBANano.uoehtml _fpw = null;
public b4j.Mashy.UOEBANano.uoehtml _help = null;
public boolean _hideinput = false;
public boolean _fitwidth = false;
public String _title = "";
public boolean _multiple = false;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoefile  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 70;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 71;BA.debugLine="fu.AddAttribute(attr,value)";
_fu._addattribute(_attr,_value);
 //BA.debugLineNum = 72;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefile)(this);
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefile  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub AddClass(sClass As String) As UOEFile";
 //BA.debugLineNum = 59;BA.debugLine="fu.AddClass(sClass)";
_fu._addclass(_sclass);
 //BA.debugLineNum = 60;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefile)(this);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefile  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 31;BA.debugLine="fu.AddStyleAttribute(attribute,value)";
_fu._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefile)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private fu As UOEHTML";
_fu = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 7;BA.debugLine="Private Placeholder As String";
_placeholder = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 9;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 13;BA.debugLine="Public OnChange As String";
_onchange = "";
 //BA.debugLineNum = 14;BA.debugLine="Public FixCell As Boolean";
_fixcell = false;
 //BA.debugLineNum = 15;BA.debugLine="Public Validate As Boolean";
_validate = false;
 //BA.debugLineNum = 16;BA.debugLine="Public HelperText As String";
_helpertext = "";
 //BA.debugLineNum = 17;BA.debugLine="Public ErrorMsg As String";
_errormsg = "";
 //BA.debugLineNum = 18;BA.debugLine="Public SuccessMsg As String";
_successmsg = "";
 //BA.debugLineNum = 19;BA.debugLine="Private btn As UOEHTML";
_btn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 20;BA.debugLine="Private fpw As UOEHTML";
_fpw = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 21;BA.debugLine="Private help As UOEHTML";
_help = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 22;BA.debugLine="Public HideInput As Boolean";
_hideinput = false;
 //BA.debugLineNum = 23;BA.debugLine="Public FitWidth As Boolean";
_fitwidth = false;
 //BA.debugLineNum = 24;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 25;BA.debugLine="Public Multiple As Boolean";
_multiple = false;
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,String _splaceholder,boolean _bmultiple,String _stheme) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 36;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 38;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 39;BA.debugLine="If sTheme = \"\" Then";
if ((_stheme).equals("")) { 
 //BA.debugLineNum = 40;BA.debugLine="sTheme = App.Theme";
_stheme = _app._theme;
 };
 //BA.debugLineNum = 42;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 43;BA.debugLine="Placeholder = sPlaceholder";
_placeholder = _splaceholder;
 //BA.debugLineNum = 44;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 45;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 46;BA.debugLine="ErrorMsg = \"Error\"";
_errormsg = "Error";
 //BA.debugLineNum = 47;BA.debugLine="SuccessMsg = \"Success\"";
_successmsg = "Success";
 //BA.debugLineNum = 48;BA.debugLine="HelperText = \"\"";
_helpertext = "";
 //BA.debugLineNum = 49;BA.debugLine="OnChange = \"\"";
_onchange = "";
 //BA.debugLineNum = 50;BA.debugLine="HideInput = False";
_hideinput = __c.False;
 //BA.debugLineNum = 51;BA.debugLine="FitWidth = False";
_fitwidth = __c.False;
 //BA.debugLineNum = 52;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 53;BA.debugLine="Theme = sTheme";
_theme = _stheme;
 //BA.debugLineNum = 54;BA.debugLine="Multiple = bMultiple";
_multiple = _bmultiple;
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoefile  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEFile";
 //BA.debugLineNum = 77;BA.debugLine="fu.RemoveAttribute(attr)";
_fu._removeattribute(_attr);
 //BA.debugLineNum = 78;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefile)(this);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefile  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Sub RemoveClass(sClass As String) As UOEFile";
 //BA.debugLineNum = 65;BA.debugLine="fu.RemoveClass(sClass)";
_fu._removeclass(_sclass);
 //BA.debugLineNum = 66;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefile)(this);
 //BA.debugLineNum = 67;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _spn = null;
b4j.Mashy.UOEBANano.uoehtml _inp = null;
b4j.Mashy.UOEBANano.uoehtml _fa = null;
 //BA.debugLineNum = 82;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 83;BA.debugLine="If FitWidth Then";
if (_fitwidth) { 
 //BA.debugLineNum = 84;BA.debugLine="HideInput = True";
_hideinput = __c.True;
 };
 //BA.debugLineNum = 86;BA.debugLine="If HideInput Then";
if (_hideinput) { 
 //BA.debugLineNum = 87;BA.debugLine="HelperText=\"\"";
_helpertext = "";
 };
 //BA.debugLineNum = 90;BA.debugLine="help.Initialize(ID & \"-span\",\"span\")";
_help._initialize(ba,_id+"-span","span");
 //BA.debugLineNum = 91;BA.debugLine="help.AddClass(\"helper-text\")";
_help._addclass("helper-text");
 //BA.debugLineNum = 92;BA.debugLine="fu.Initialize(ID & \"-div\",\"div\")";
_fu._initialize(ba,_id+"-div","div");
 //BA.debugLineNum = 93;BA.debugLine="fu.AddClass(\"file-field\")";
_fu._addclass("file-field");
 //BA.debugLineNum = 94;BA.debugLine="fu.AddClass(\"input-field\")";
_fu._addclass("input-field");
 //BA.debugLineNum = 95;BA.debugLine="fu.AddClass(\"col\")";
_fu._addclass("col");
 //BA.debugLineNum = 96;BA.debugLine="fu.AddClass(\"s12\")";
_fu._addclass("s12");
 //BA.debugLineNum = 97;BA.debugLine="fu.AddClass(\"m12\")";
_fu._addclass("m12");
 //BA.debugLineNum = 98;BA.debugLine="fu.AddClass(\"l12\")";
_fu._addclass("l12");
 //BA.debugLineNum = 99;BA.debugLine="btn.Initialize(ID & \"-button\",\"div\")";
_btn._initialize(ba,_id+"-button","div");
 //BA.debugLineNum = 100;BA.debugLine="btn.AddClass(\"btn\")";
_btn._addclass("btn");
 //BA.debugLineNum = 101;BA.debugLine="btn.AddStyleAttributeOnCondition(FitWidth,\"width\"";
_btn._addstyleattributeoncondition(_fitwidth,"width","100%");
 //BA.debugLineNum = 103;BA.debugLine="Dim spn As UOEHTML";
_spn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 104;BA.debugLine="spn.Initialize(ID & \"-span\",\"span\")";
_spn._initialize(ba,_id+"-span","span");
 //BA.debugLineNum = 105;BA.debugLine="spn.AddContent(Title)";
_spn._addcontent(_title);
 //BA.debugLineNum = 106;BA.debugLine="btn.AddElement(spn)";
_btn._addelement(_spn);
 //BA.debugLineNum = 108;BA.debugLine="Dim inp As UOEHTML";
_inp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 109;BA.debugLine="inp.Initialize(ID,\"input\")";
_inp._initialize(ba,_id,"input");
 //BA.debugLineNum = 110;BA.debugLine="inp.SetTYPE(\"file\")";
_inp._settype("file");
 //BA.debugLineNum = 111;BA.debugLine="inp.AddLooseAttributeOnCondition(Multiple,\"multip";
_inp._addlooseattributeoncondition(_multiple,"multiple");
 //BA.debugLineNum = 112;BA.debugLine="btn.AddElement(inp)";
_btn._addelement(_inp);
 //BA.debugLineNum = 115;BA.debugLine="App.MaterialUseTheme(Theme,btn)";
_app._materialusetheme(_theme,_btn);
 //BA.debugLineNum = 116;BA.debugLine="fu.AddElement(btn)";
_fu._addelement(_btn);
 //BA.debugLineNum = 117;BA.debugLine="fpw.Initialize(\"\",\"div\")";
_fpw._initialize(ba,"","div");
 //BA.debugLineNum = 118;BA.debugLine="fpw.AddClass(\"file-path-wrapper\")";
_fpw._addclass("file-path-wrapper");
 //BA.debugLineNum = 119;BA.debugLine="fu.MaterialVisibility(Visibility)";
_fu._materialvisibility(_visibility);
 //BA.debugLineNum = 120;BA.debugLine="fu.MaterialHoverable(Hoverable)";
_fu._materialhoverable(_hoverable);
 //BA.debugLineNum = 121;BA.debugLine="fu.MaterialZdepth(ZDepth)";
_fu._materialzdepth(_zdepth);
 //BA.debugLineNum = 122;BA.debugLine="App.ApplyToolTip(ID,fu)";
_app._applytooltip(_id,_fu);
 //BA.debugLineNum = 123;BA.debugLine="help.AddAttribute(\"data-error\",ErrorMsg)";
_help._addattribute("data-error",_errormsg);
 //BA.debugLineNum = 124;BA.debugLine="help.AddAttribute(\"data-success\",SuccessMsg)";
_help._addattribute("data-success",_successmsg);
 //BA.debugLineNum = 125;BA.debugLine="help.AddContent(HelperText)";
_help._addcontent(_helpertext);
 //BA.debugLineNum = 127;BA.debugLine="Dim inp As UOEHTML";
_inp = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 128;BA.debugLine="inp.Initialize(\"\",\"input\")";
_inp._initialize(ba,"","input");
 //BA.debugLineNum = 129;BA.debugLine="inp.AddClass(\"file-path\")";
_inp._addclass("file-path");
 //BA.debugLineNum = 130;BA.debugLine="inp.AddClassOnCondition(Validate,\"validate\")";
_inp._addclassoncondition(_validate,"validate");
 //BA.debugLineNum = 131;BA.debugLine="inp.SetTYPE(\"text\")";
_inp._settype("text");
 //BA.debugLineNum = 132;BA.debugLine="inp.AddAttribute(\"placeholder\",Placeholder)";
_inp._addattribute("placeholder",_placeholder);
 //BA.debugLineNum = 133;BA.debugLine="inp.AddStyleAttributeOnCondition(HideInput,\"displ";
_inp._addstyleattributeoncondition(_hideinput,"display","none");
 //BA.debugLineNum = 134;BA.debugLine="fpw.addelement(inp)";
_fpw._addelement(_inp);
 //BA.debugLineNum = 140;BA.debugLine="Dim fa As UOEHTML";
_fa = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 141;BA.debugLine="fa.Initialize(\"\",\"form\")";
_fa._initialize(ba,"","form");
 //BA.debugLineNum = 142;BA.debugLine="fa.AddAttribute(\"action\",\"#\")";
_fa._addattribute("action","#");
 //BA.debugLineNum = 143;BA.debugLine="fa.AddElement(fu)";
_fa._addelement(_fu);
 //BA.debugLineNum = 144;BA.debugLine="Return fa.HTML";
if (true) return _fa._html();
 //BA.debugLineNum = 145;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
