package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoegrid extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoegrid", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoegrid.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public anywheresoftware.b4a.objects.collections.Map _rows = null;
public anywheresoftware.b4a.objects.collections.Map _columns = null;
public int _lastrow = 0;
public anywheresoftware.b4a.objects.collections.Map _colclass = null;
public anywheresoftware.b4a.objects.collections.Map _padclass = null;
public anywheresoftware.b4a.objects.collections.Map _marclass = null;
public anywheresoftware.b4a.objects.collections.Map _offclass = null;
public anywheresoftware.b4a.objects.collections.Map _rc = null;
public String _rowclass = "";
public String _cellclass = "";
public boolean _showid = false;
public String _parentid = "";
public anywheresoftware.b4a.objects.collections.Map _components = null;
public anywheresoftware.b4a.objects.collections.Map _rowclasses = null;
public anywheresoftware.b4a.objects.collections.Map _columnclasses = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public anywheresoftware.b4a.objects.collections.Map _rowpadding = null;
public anywheresoftware.b4a.objects.collections.Map _rowmargins = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnosmpv(int _icolumns,int _ioffsetsmall,int _ioffsetmedium,int _ioffsetlarge,int _isizesmall,int _isizemedium,int _isizelarge,int _imargintop,int _imarginbottom,int _imarginleft,int _imarginright,int _ipaddingtop,int _ipaddingbottom,int _ipaddingleft,int _ipaddingright,String _sthemename,String _svisibility,String _sclassname) throws Exception{
b4j.Mashy.UOEBANano.uoecolumn _ncell = null;
String _rowkey = "";
b4j.Mashy.UOEBANano.uoerow _oldrow = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
 //BA.debugLineNum = 310;BA.debugLine="Sub AddColumnOSMPV(iColumns As Int,iOffsetSmall As";
 //BA.debugLineNum = 314;BA.debugLine="Dim nCell As UOEColumn";
_ncell = new b4j.Mashy.UOEBANano.uoecolumn();
 //BA.debugLineNum = 315;BA.debugLine="nCell.Initialize";
_ncell._initialize(ba);
 //BA.debugLineNum = 316;BA.debugLine="nCell = CreateColumn(iColumns,iOffsetSmall,iOffse";
_ncell = _createcolumn(_icolumns,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,(int) (0),_isizesmall,_isizemedium,_isizelarge,BA.NumberToString(0),_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_sthemename,_svisibility,_sclassname);
 //BA.debugLineNum = 318;BA.debugLine="Dim rowkey As String = $\"r${LastRow}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_lastrow))+"");
 //BA.debugLineNum = 320;BA.debugLine="If Rows.ContainsKey(rowkey) Then";
if (_rows.ContainsKey((Object)(_rowkey))) { 
 //BA.debugLineNum = 322;BA.debugLine="Dim oldRow As UOERow";
_oldrow = new b4j.Mashy.UOEBANano.uoerow();
 //BA.debugLineNum = 323;BA.debugLine="oldRow.Initialize";
_oldrow._initialize(ba);
 //BA.debugLineNum = 324;BA.debugLine="oldRow = Rows.Get(rowkey)";
_oldrow = (b4j.Mashy.UOEBANano.uoerow)(_rows.Get((Object)(_rowkey)));
 //BA.debugLineNum = 326;BA.debugLine="Dim cols As List = oldRow.Columns";
_cols = new anywheresoftware.b4a.objects.collections.List();
_cols = _oldrow._columns;
 //BA.debugLineNum = 327;BA.debugLine="cols.add(nCell)";
_cols.Add((Object)(_ncell));
 //BA.debugLineNum = 328;BA.debugLine="Rows.Put(rowkey,oldRow)";
_rows.Put((Object)(_rowkey),(Object)(_oldrow));
 }else {
 //BA.debugLineNum = 330;BA.debugLine="Log(\"UOEGrid - AddColumnOSMPV: A row has not bee";
__c.Log("UOEGrid - AddColumnOSMPV: A row has not been added yet to the grid!");
 };
 //BA.debugLineNum = 332;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 333;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumns(int _columns2add,int _spansmall,int _spanmedium,int _spanlarge,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 389;BA.debugLine="Sub AddColumns(Columns2Add As Int, SpanSmall As In";
 //BA.debugLineNum = 390;BA.debugLine="AddColumnOSMPV(Columns2Add, 0,0,0,SpanSmall, Span";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),_spansmall,_spanmedium,_spanlarge,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 391;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 392;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumns12(int _columns2add,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 383;BA.debugLine="Sub AddColumns12(Columns2Add As Int, sThemeName As";
 //BA.debugLineNum = 384;BA.debugLine="AddColumnOSMPV(Columns2Add,0,0,0,12,12,12,0,0,0,0";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),(int) (12),(int) (12),(int) (12),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_sthemename,"",_classname);
 //BA.debugLineNum = 385;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 386;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumns12mp(int _columns2add,int _imargintoppx,int _imarginbottompx,int _ipaddingleftpx,int _ipaddingrightpx,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 349;BA.debugLine="Sub AddColumns12MP(Columns2Add As Int, iMarginTopP";
 //BA.debugLineNum = 350;BA.debugLine="AddColumnOSMPV(Columns2Add, 0,0,0,12,12,12, iMarg";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),(int) (12),(int) (12),(int) (12),_imargintoppx,_imarginbottompx,_ipaddingleftpx,_ipaddingrightpx,(int) (0),(int) (0),(int) (0),(int) (0),_sthemename,"",_classname);
 //BA.debugLineNum = 351;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 352;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumns12mpv(int _columns2add,int _imargintoppx,int _imarginbottompx,int _ipaddingleftpx,int _ipaddingrightpx,String _svisibility,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 342;BA.debugLine="Sub AddColumns12MPV(Columns2Add As Int, iMarginTop";
 //BA.debugLineNum = 343;BA.debugLine="AddColumnOSMPV(Columns2Add ,0,0,0,12,12,12, iMarg";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),(int) (12),(int) (12),(int) (12),_imargintoppx,_imarginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),_ipaddingleftpx,_ipaddingrightpx,_sthemename,_svisibility,_classname);
 //BA.debugLineNum = 344;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 345;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumns12v(int _columns2add,String _svisibility,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 377;BA.debugLine="Sub AddColumns12V(Columns2Add As Int, sVisibility";
 //BA.debugLineNum = 378;BA.debugLine="AddColumnOSMPV(Columns2Add,0,0,0,12,12,12,0,0,0,0";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),(int) (12),(int) (12),(int) (12),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_sthemename,_svisibility,_classname);
 //BA.debugLineNum = 379;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 380;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnsos(int _columns2add,int _ioffsetsmall,int _ioffsetmedium,int _ioffsetlarge,int _isizesmall,int _isizemedium,int _isizelarge,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 336;BA.debugLine="Sub AddColumnsOS(Columns2Add As Int, iOffsetSmall";
 //BA.debugLineNum = 337;BA.debugLine="AddColumnOSMPV(Columns2Add, iOffsetSmall, iOffset";
_addcolumnosmpv(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_sthemename,"",_classname);
 //BA.debugLineNum = 338;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 339;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnsosmp(int _columns2add,int _offsetsmall,int _offsetmedium,int _offsetlarge,int _sizesmall,int _sizemedium,int _sizelarge,int _rmargintop,int _rmarginbottom,int _rpaddingleft,int _rpaddingright,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 370;BA.debugLine="Sub AddColumnsOSMP(Columns2Add As Int, OffsetSmall";
 //BA.debugLineNum = 371;BA.debugLine="AddColumnOSMPV(Columns2Add,OffsetSmall, OffsetMed";
_addcolumnosmpv(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_rmargintop,_rmarginbottom,(int) (0),(int) (0),(int) (0),(int) (0),_rpaddingleft,_rpaddingright,_sthemename,"",_classname);
 //BA.debugLineNum = 372;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 373;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnsosmpv(int _columns2add,int _offsetsmall,int _offsetmedium,int _offsetlarge,int _sizesmall,int _sizemedium,int _sizelarge,int _margintoppx,int _marginbottompx,int _paddingleftpx,int _paddingrightpx,String _svisibility,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 355;BA.debugLine="Sub AddColumnsOSMPV(Columns2Add As Int, OffsetSmal";
 //BA.debugLineNum = 357;BA.debugLine="AddColumnOSMPV(Columns2Add, OffsetSmall, OffsetMe";
_addcolumnosmpv(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_margintoppx,_marginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),_paddingleftpx,_paddingrightpx,_sthemename,_svisibility,_classname);
 //BA.debugLineNum = 359;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 360;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnsosv(int _columns2add,int _ioffsetsmall,int _ioffsetmedium,int _ioffsetlarge,int _isizesmall,int _isizemedium,int _isizelarge,String _svisibility,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 396;BA.debugLine="Sub AddColumnsOSV(Columns2Add As Int, iOffsetSmall";
 //BA.debugLineNum = 397;BA.debugLine="AddColumnOSMPV(Columns2Add , iOffsetSmall , iOffs";
_addcolumnosmpv(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_sthemename,_svisibility,_classname);
 //BA.debugLineNum = 398;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 399;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addcolumnssp(int _columns2add,int _sizesmall,int _sizemedium,int _sizelarge,int _rpaddingleft,int _rpaddingright,String _sthemename,String _classname) throws Exception{
 //BA.debugLineNum = 364;BA.debugLine="Sub AddColumnsSP(Columns2Add As Int, SizeSmall As";
 //BA.debugLineNum = 365;BA.debugLine="AddColumnOSMPV(Columns2Add, 0,0,0,SizeSmall, Size";
_addcolumnosmpv(_columns2add,(int) (0),(int) (0),(int) (0),_sizesmall,_sizemedium,_sizelarge,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_rpaddingleft,_rpaddingright,_sthemename,"",_classname);
 //BA.debugLineNum = 366;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 367;BA.debugLine="End Sub";
return null;
}
public String  _addcomponent(int _rowpos,int _colpos,String _elhtml) throws Exception{
String _cellkey = "";
anywheresoftware.b4a.objects.collections.List _lst = null;
 //BA.debugLineNum = 435;BA.debugLine="Sub AddComponent(rowPos As Int, colPos As Int, elH";
 //BA.debugLineNum = 436;BA.debugLine="Dim cellKey As String = $\"${parentID}r${rowPos}c$";
_cellkey = (""+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"c"+__c.SmartStringFormatter("",(Object)(_colpos))+"");
 //BA.debugLineNum = 437;BA.debugLine="Dim lst As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 438;BA.debugLine="If Components.ContainsKey(cellKey) Then";
if (_components.ContainsKey((Object)(_cellkey))) { 
 //BA.debugLineNum = 439;BA.debugLine="lst = Components.Get(cellKey)";
_lst.setObject((java.util.List)(_components.Get((Object)(_cellkey))));
 }else {
 //BA.debugLineNum = 441;BA.debugLine="lst.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 442;BA.debugLine="lst.clear";
_lst.Clear();
 };
 //BA.debugLineNum = 444;BA.debugLine="lst.Add(elHTML)";
_lst.Add((Object)(_elhtml));
 //BA.debugLineNum = 445;BA.debugLine="Components.Put(cellKey,lst)";
_components.Put((Object)(_cellkey),(Object)(_lst.getObject()));
 //BA.debugLineNum = 446;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoegrid  _addrows(int _rows2add,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 73;BA.debugLine="Sub AddRows(Rows2Add As Int, themeName As String,c";
 //BA.debugLineNum = 74;BA.debugLine="AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName,\"";
_addrowsmpv(_rows2add,(int) (0),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 75;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 76;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsm(int _rows2add,int _margintoppx,int _marginbottompx,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub AddRowsM(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 62;BA.debugLine="AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx,";
_addrowsmpv(_rows2add,_margintoppx,_marginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 63;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsm2(int _rows2add,int _margintoppx,int _marginbottompx,int _marginleftpx,int _marginrightpx,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub AddRowsM2(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 56;BA.debugLine="AddRowsMPV(Rows2Add, marginTopPx, marginBottomPx,";
_addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,(int) (0),(int) (0),(int) (0),(int) (0),_themename,"",_classname);
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsmpv(int _irows,int _imargintop,int _imarginbottom,int _imarginleft,int _imarginright,int _ipaddingtop,int _ipaddingbottom,int _ipaddingleft,int _ipaddingright,String _sthemename,String _svisibility,String _sclassname) throws Exception{
b4j.Mashy.UOEBANano.uoerow _nrow = null;
String _rowkey = "";
 //BA.debugLineNum = 293;BA.debugLine="Sub AddRowsMPV(iRows As Int, iMarginTop As Int, iM";
 //BA.debugLineNum = 297;BA.debugLine="LastRow = Rows.size";
_lastrow = _rows.getSize();
 //BA.debugLineNum = 299;BA.debugLine="Dim nRow As UOERow";
_nrow = new b4j.Mashy.UOEBANano.uoerow();
 //BA.debugLineNum = 300;BA.debugLine="nRow.Initialize";
_nrow._initialize(ba);
 //BA.debugLineNum = 301;BA.debugLine="nRow  = CreateRow(iRows,iMarginTop,iMarginBottom,";
_nrow = _createrow(_irows,_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_svisibility,_sthemename,__c.False,_sclassname);
 //BA.debugLineNum = 303;BA.debugLine="Dim rowKey As String = $\"r${LastRow}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_lastrow))+"");
 //BA.debugLineNum = 305;BA.debugLine="Rows.Put(rowKey,nRow)";
_rows.Put((Object)(_rowkey),(Object)(_nrow));
 //BA.debugLineNum = 306;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 307;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsmv(int _rows2add,int _margintoppx,int _marginbottompx,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub AddRowsMV(Rows2Add As Int, marginTopPx As Int,";
 //BA.debugLineNum = 43;BA.debugLine="AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx";
_addrowsmpv(_rows2add,_margintoppx,_marginbottompx,(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 44;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsmv2(int _rows2add,int _margintoppx,int _marginbottompx,int _marginleftpx,int _marginrightpx,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub AddRowsMV2(Rows2Add As Int, marginTopPx As Int";
 //BA.debugLineNum = 49;BA.debugLine="AddRowsMPV(Rows2Add, marginTopPx , marginBottomPx";
_addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 50;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoegrid  _addrowsv(int _rows2add,String _rvisibility,String _themename,String _classname) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub AddRowsV(Rows2Add As Int, rVisibility As Strin";
 //BA.debugLineNum = 68;BA.debugLine="AddRowsMPV(Rows2Add, 0,20,0,0,0,0,0,0,themeName,r";
_addrowsmpv(_rows2add,(int) (0),(int) (20),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),(int) (0),_themename,_rvisibility,_classname);
 //BA.debugLineNum = 69;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoegrid)(this);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return null;
}
public String  _buildcolumnclass(b4j.Mashy.UOEBANano.uoecolumn _col) throws Exception{
String _strspans = "";
String _stroffsets = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 552;BA.debugLine="private Sub BuildColumnClass(col As UOEColumn) As";
 //BA.debugLineNum = 553;BA.debugLine="Dim strSpans As String = BuildSpans(col.SpanSmall";
_strspans = _buildspans(_col._spansmall,_col._spanmedium,_col._spanlarge);
 //BA.debugLineNum = 554;BA.debugLine="Dim strOffSets As String = BuildOffsets(col.offse";
_stroffsets = _buildoffsets(_col._offsetsmall,_col._offsetmedium,_col._offsetlarge);
 //BA.debugLineNum = 556;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 557;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 558;BA.debugLine="sb.Append($\"${cellClass} \"$)";
_sb.Append((""+__c.SmartStringFormatter("",(Object)(_cellclass))+" "));
 //BA.debugLineNum = 559;BA.debugLine="sb.Append(strSpans)";
_sb.Append(_strspans);
 //BA.debugLineNum = 561;BA.debugLine="sb.Append(strOffSets)";
_sb.Append(_stroffsets);
 //BA.debugLineNum = 562;BA.debugLine="Return sb.tostring.trim";
if (true) return _sb.ToString().trim();
 //BA.debugLineNum = 563;BA.debugLine="End Sub";
return "";
}
public String  _buildcolumnstyle(b4j.Mashy.UOEBANano.uoecolumn _col) throws Exception{
anywheresoftware.b4a.objects.collections.Map _rowc = null;
String _rowkey = "";
boolean _hascolumn = false;
String _strmargins = "";
String _strpadding = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 598;BA.debugLine="private Sub BuildColumnStyle(col As UOEColumn) As";
 //BA.debugLineNum = 599;BA.debugLine="Dim rowc As Map";
_rowc = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 600;BA.debugLine="rowc.Initialize";
_rowc.Initialize();
 //BA.debugLineNum = 601;BA.debugLine="rowc.clear";
_rowc.Clear();
 //BA.debugLineNum = 602;BA.debugLine="Dim rowKey As String = $\"r${col.Row}c${col.Col}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_col._row))+"c"+__c.SmartStringFormatter("",(Object)(_col._col))+"");
 //BA.debugLineNum = 603;BA.debugLine="Dim hascolumn As Boolean = rowPadding.ContainsKey";
_hascolumn = _rowpadding.ContainsKey((Object)(_rowkey));
 //BA.debugLineNum = 604;BA.debugLine="If hascolumn Then";
if (_hascolumn) { 
 //BA.debugLineNum = 605;BA.debugLine="rowc = rowPadding.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowpadding.Get((Object)(_rowkey))));
 //BA.debugLineNum = 606;BA.debugLine="col.PaddingTop = rowc.get(\"pt\")";
_col._paddingtop = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pt"))));
 //BA.debugLineNum = 607;BA.debugLine="col.PaddingBottom = rowc.get(\"pb\")";
_col._paddingbottom = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pb"))));
 //BA.debugLineNum = 608;BA.debugLine="col.PaddingLeft = rowc.get(\"pl\")";
_col._paddingleft = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pl"))));
 //BA.debugLineNum = 609;BA.debugLine="col.PaddingRight = rowc.get(\"pr\")";
_col._paddingright = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pr"))));
 };
 //BA.debugLineNum = 611;BA.debugLine="Dim hascolumn As Boolean = rowMargins.ContainsKey";
_hascolumn = _rowmargins.ContainsKey((Object)(_rowkey));
 //BA.debugLineNum = 612;BA.debugLine="If hascolumn Then";
if (_hascolumn) { 
 //BA.debugLineNum = 613;BA.debugLine="rowc = rowMargins.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowmargins.Get((Object)(_rowkey))));
 //BA.debugLineNum = 614;BA.debugLine="col.MarginTop = rowc.get(\"mt\")";
_col._margintop = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mt"))));
 //BA.debugLineNum = 615;BA.debugLine="col.MarginBottom = rowc.get(\"mb\")";
_col._marginbottom = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mb"))));
 //BA.debugLineNum = 616;BA.debugLine="col.MarginLeft = rowc.get(\"ml\")";
_col._marginleft = (int)(BA.ObjectToNumber(_rowc.Get((Object)("ml"))));
 //BA.debugLineNum = 617;BA.debugLine="col.MarginRight = rowc.get(\"mr\")";
_col._marginright = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mr"))));
 };
 //BA.debugLineNum = 620;BA.debugLine="Dim strMargins As String = BuildMargins(col.Margi";
_strmargins = _buildmargins(_col._margintop,_col._marginbottom,_col._marginleft,_col._marginright);
 //BA.debugLineNum = 621;BA.debugLine="Dim strPadding As String = BuildPadding(col.Paddi";
_strpadding = _buildpadding(_col._paddingtop,_col._paddingbottom,_col._paddingleft,_col._paddingright);
 //BA.debugLineNum = 622;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 623;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 625;BA.debugLine="sb.Append(strMargins)";
_sb.Append(_strmargins);
 //BA.debugLineNum = 627;BA.debugLine="sb.Append(strPadding)";
_sb.Append(_strpadding);
 //BA.debugLineNum = 628;BA.debugLine="Return sb.tostring.trim";
if (true) return _sb.ToString().trim();
 //BA.debugLineNum = 629;BA.debugLine="End Sub";
return "";
}
public String  _buildmargins(int _mt,int _mb,int _ml,int _mr) throws Exception{
String _pvalue = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _colkey = "";
String _colc = "";
 //BA.debugLineNum = 721;BA.debugLine="Private Sub BuildMargins(MT As Int, MB As Int, ML";
 //BA.debugLineNum = 722;BA.debugLine="Dim pvalue As String = \"0\"";
_pvalue = "0";
 //BA.debugLineNum = 723;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 724;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 726;BA.debugLine="Dim kTot As Int = marClass.Size - 1";
_ktot = (int) (_marclass.getSize()-1);
 //BA.debugLineNum = 727;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 728;BA.debugLine="For kCnt = 0 To kTot";
{
final int step6 = 1;
final int limit6 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit6 ;_kcnt = _kcnt + step6 ) {
 //BA.debugLineNum = 729;BA.debugLine="Dim colKey As String = marClass.GetKeyAt(kCnt)";
_colkey = BA.ObjectToString(_marclass.GetKeyAt(_kcnt));
 //BA.debugLineNum = 730;BA.debugLine="Dim colC As String = marClass.Get(colKey)";
_colc = BA.ObjectToString(_marclass.Get((Object)(_colkey)));
 //BA.debugLineNum = 731;BA.debugLine="Select Case colKey";
switch (BA.switchObjectToInt(_colkey,"mt","mb","ml","mr")) {
case 0: {
 //BA.debugLineNum = 733;BA.debugLine="pvalue = CStr(MT)";
_pvalue = _cstr((Object)(_mt));
 break; }
case 1: {
 //BA.debugLineNum = 735;BA.debugLine="pvalue = CStr(MB)";
_pvalue = _cstr((Object)(_mb));
 break; }
case 2: {
 //BA.debugLineNum = 737;BA.debugLine="pvalue = CStr(ML)";
_pvalue = _cstr((Object)(_ml));
 break; }
case 3: {
 //BA.debugLineNum = 739;BA.debugLine="pvalue = CStr(MR)";
_pvalue = _cstr((Object)(_mr));
 break; }
}
;
 //BA.debugLineNum = 741;BA.debugLine="sb.Append(colC)";
_sb.Append(_colc);
 //BA.debugLineNum = 742;BA.debugLine="sb.Append(pvalue)";
_sb.Append(_pvalue);
 //BA.debugLineNum = 743;BA.debugLine="sb.Append(\"px !important; \")";
_sb.Append("px !important; ");
 }
};
 //BA.debugLineNum = 745;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 746;BA.debugLine="End Sub";
return "";
}
public String  _buildoffsets(int _os,int _om,int _ol) throws Exception{
String _pvalue = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _colkey = "";
String _colc = "";
 //BA.debugLineNum = 666;BA.debugLine="Private Sub BuildOffsets(OS As Int, OM As Int, OL";
 //BA.debugLineNum = 667;BA.debugLine="Dim pvalue As String = \"0\"";
_pvalue = "0";
 //BA.debugLineNum = 668;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 669;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 670;BA.debugLine="Dim kTot As Int = offClass.Size - 1";
_ktot = (int) (_offclass.getSize()-1);
 //BA.debugLineNum = 671;BA.debugLine="Dim kCnt As Int = 0";
_kcnt = (int) (0);
 //BA.debugLineNum = 672;BA.debugLine="For kCnt = 0 To kTot";
{
final int step6 = 1;
final int limit6 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit6 ;_kcnt = _kcnt + step6 ) {
 //BA.debugLineNum = 673;BA.debugLine="Dim colKey As String = offClass.GetKeyAt(kCnt)";
_colkey = BA.ObjectToString(_offclass.GetKeyAt(_kcnt));
 //BA.debugLineNum = 675;BA.debugLine="Dim colC As String = offClass.Get(colKey)";
_colc = BA.ObjectToString(_offclass.Get((Object)(_colkey)));
 //BA.debugLineNum = 677;BA.debugLine="Select Case colKey";
switch (BA.switchObjectToInt(_colkey,"s","m","l")) {
case 0: {
 //BA.debugLineNum = 679;BA.debugLine="pvalue = CStr(OS)";
_pvalue = _cstr((Object)(_os));
 break; }
case 1: {
 //BA.debugLineNum = 681;BA.debugLine="pvalue = CStr(OM)";
_pvalue = _cstr((Object)(_om));
 break; }
case 2: {
 //BA.debugLineNum = 683;BA.debugLine="pvalue = CStr(OL)";
_pvalue = _cstr((Object)(_ol));
 break; }
}
;
 //BA.debugLineNum = 685;BA.debugLine="sb.Append(colC)";
_sb.Append(_colc);
 //BA.debugLineNum = 686;BA.debugLine="sb.Append(pvalue)";
_sb.Append(_pvalue);
 //BA.debugLineNum = 687;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 }
};
 //BA.debugLineNum = 689;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 690;BA.debugLine="End Sub";
return "";
}
public String  _buildpadding(int _pt,int _pb,int _pl,int _pr) throws Exception{
String _pvalue = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _colkey = "";
String _colc = "";
 //BA.debugLineNum = 693;BA.debugLine="Private Sub BuildPadding(PT As Int, PB As Int, PL";
 //BA.debugLineNum = 694;BA.debugLine="Dim pvalue As String = \"0\"";
_pvalue = "0";
 //BA.debugLineNum = 695;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 696;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 698;BA.debugLine="Dim kTot As Int = padClass.Size - 1";
_ktot = (int) (_padclass.getSize()-1);
 //BA.debugLineNum = 699;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 700;BA.debugLine="For kCnt = 0 To kTot";
{
final int step6 = 1;
final int limit6 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit6 ;_kcnt = _kcnt + step6 ) {
 //BA.debugLineNum = 701;BA.debugLine="Dim colKey As String = padClass.GetKeyAt(kCnt)";
_colkey = BA.ObjectToString(_padclass.GetKeyAt(_kcnt));
 //BA.debugLineNum = 702;BA.debugLine="Dim colC As String = padClass.Get(colKey)";
_colc = BA.ObjectToString(_padclass.Get((Object)(_colkey)));
 //BA.debugLineNum = 703;BA.debugLine="Select Case colKey";
switch (BA.switchObjectToInt(_colkey,"pt","pb","pl","pr")) {
case 0: {
 //BA.debugLineNum = 705;BA.debugLine="pvalue = CStr(PT)";
_pvalue = _cstr((Object)(_pt));
 break; }
case 1: {
 //BA.debugLineNum = 707;BA.debugLine="pvalue = CStr(PB)";
_pvalue = _cstr((Object)(_pb));
 break; }
case 2: {
 //BA.debugLineNum = 709;BA.debugLine="pvalue = CStr(PL)";
_pvalue = _cstr((Object)(_pl));
 break; }
case 3: {
 //BA.debugLineNum = 711;BA.debugLine="pvalue = CStr(PR)";
_pvalue = _cstr((Object)(_pr));
 break; }
}
;
 //BA.debugLineNum = 713;BA.debugLine="sb.Append(colC)";
_sb.Append(_colc);
 //BA.debugLineNum = 714;BA.debugLine="sb.Append(pvalue)";
_sb.Append(_pvalue);
 //BA.debugLineNum = 715;BA.debugLine="sb.Append(\"px !important; \")";
_sb.Append("px !important; ");
 }
};
 //BA.debugLineNum = 717;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 718;BA.debugLine="End Sub";
return "";
}
public String  _buildrow(b4j.Mashy.UOEBANano.uoerow _row) throws Exception{
int _rowtot = 0;
int _rowcnt = 0;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
String _rowkey = "";
b4j.Mashy.UOEBANano.uoehtml _trow = null;
String _strrowclass = "";
String _strrowstyle = "";
String _classkey = "";
anywheresoftware.b4a.objects.collections.Map _cm = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
int _colcnt = 0;
int _coltot = 0;
int _lastcolumn = 0;
b4j.Mashy.UOEBANano.uoecolumn _column = null;
int _colcnt1 = 0;
int _coltot1 = 0;
String _cellkey = "";
b4j.Mashy.UOEBANano.uoehtml _tcolumn = null;
String _strcolumnclass = "";
String _strcolumnstyle = "";
anywheresoftware.b4a.objects.collections.List _lst = null;
String _strrow = "";
 //BA.debugLineNum = 463;BA.debugLine="private Sub BuildRow(row As UOERow) As String";
 //BA.debugLineNum = 465;BA.debugLine="Dim rowTot As Int = row.Rows";
_rowtot = _row._rows;
 //BA.debugLineNum = 466;BA.debugLine="Dim rowCnt As Int";
_rowcnt = 0;
 //BA.debugLineNum = 467;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 468;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 470;BA.debugLine="For rowCnt = 1 To rowTot";
{
final int step5 = 1;
final int limit5 = _rowtot;
_rowcnt = (int) (1) ;
for (;_rowcnt <= limit5 ;_rowcnt = _rowcnt + step5 ) {
 //BA.debugLineNum = 471;BA.debugLine="LastRow = LastRow + 1";
_lastrow = (int) (_lastrow+1);
 //BA.debugLineNum = 472;BA.debugLine="row.Row = LastRow";
_row._row = _lastrow;
 //BA.debugLineNum = 473;BA.debugLine="Dim rowKey As String = $\"${parentID}r${LastRow}\"";
_rowkey = (""+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_lastrow))+"");
 //BA.debugLineNum = 474;BA.debugLine="Dim tRow As UOEHTML";
_trow = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 475;BA.debugLine="tRow.Initialize(rowKey,\"div\")";
_trow._initialize(ba,_rowkey,"div");
 //BA.debugLineNum = 476;BA.debugLine="Dim strRowClass As String = BuildRowClass";
_strrowclass = _buildrowclass();
 //BA.debugLineNum = 477;BA.debugLine="Dim strRowStyle As String = BuildRowStyle(row)";
_strrowstyle = _buildrowstyle(_row);
 //BA.debugLineNum = 478;BA.debugLine="tRow.AddClass(strRowClass)";
_trow._addclass(_strrowclass);
 //BA.debugLineNum = 479;BA.debugLine="tRow.AddAttribute(\"style\",strRowStyle)";
_trow._addattribute("style",_strrowstyle);
 //BA.debugLineNum = 480;BA.debugLine="tRow.AddClass(row.ClassName)";
_trow._addclass(_row._classname);
 //BA.debugLineNum = 482;BA.debugLine="App.MaterialUseTheme(row.ThemeName,tRow)";
_app._materialusetheme(_row._themename,_trow);
 //BA.debugLineNum = 484;BA.debugLine="Dim classKey As String = $\"r${LastRow}\"$";
_classkey = ("r"+__c.SmartStringFormatter("",(Object)(_lastrow))+"");
 //BA.debugLineNum = 485;BA.debugLine="If rowClasses.ContainsKey(classKey) Then";
if (_rowclasses.ContainsKey((Object)(_classkey))) { 
 //BA.debugLineNum = 487;BA.debugLine="Dim cm As Map = rowClasses.Get(classKey)";
_cm = new anywheresoftware.b4a.objects.collections.Map();
_cm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowclasses.Get((Object)(_classkey))));
 //BA.debugLineNum = 488;BA.debugLine="tRow.AddClass(MapKeys2Delim(cm,\" \"))";
_trow._addclass(_mapkeys2delim(_cm," "));
 };
 //BA.debugLineNum = 493;BA.debugLine="Dim cols As List = row.Columns";
_cols = new anywheresoftware.b4a.objects.collections.List();
_cols = _row._columns;
 //BA.debugLineNum = 495;BA.debugLine="Dim colCnt As Int = 0";
_colcnt = (int) (0);
 //BA.debugLineNum = 496;BA.debugLine="Dim colTot As Int = cols.Size - 1";
_coltot = (int) (_cols.getSize()-1);
 //BA.debugLineNum = 498;BA.debugLine="Dim LastColumn As Int = 0";
_lastcolumn = (int) (0);
 //BA.debugLineNum = 499;BA.debugLine="For colCnt = 0 To colTot";
{
final int step26 = 1;
final int limit26 = _coltot;
_colcnt = (int) (0) ;
for (;_colcnt <= limit26 ;_colcnt = _colcnt + step26 ) {
 //BA.debugLineNum = 501;BA.debugLine="Dim column As UOEColumn";
_column = new b4j.Mashy.UOEBANano.uoecolumn();
 //BA.debugLineNum = 502;BA.debugLine="column.Initialize";
_column._initialize(ba);
 //BA.debugLineNum = 503;BA.debugLine="column = cols.Get(colCnt)";
_column = (b4j.Mashy.UOEBANano.uoecolumn)(_cols.Get(_colcnt));
 //BA.debugLineNum = 504;BA.debugLine="Dim colCnt1 As Int = 0";
_colcnt1 = (int) (0);
 //BA.debugLineNum = 505;BA.debugLine="Dim colTot1 As Int = column.Columns";
_coltot1 = _column._columns;
 //BA.debugLineNum = 506;BA.debugLine="For colCnt1 = 1 To colTot1";
{
final int step32 = 1;
final int limit32 = _coltot1;
_colcnt1 = (int) (1) ;
for (;_colcnt1 <= limit32 ;_colcnt1 = _colcnt1 + step32 ) {
 //BA.debugLineNum = 508;BA.debugLine="LastColumn = LastColumn + 1";
_lastcolumn = (int) (_lastcolumn+1);
 //BA.debugLineNum = 509;BA.debugLine="column.Row = LastRow";
_column._row = _lastrow;
 //BA.debugLineNum = 510;BA.debugLine="column.Col = LastColumn";
_column._col = _lastcolumn;
 //BA.debugLineNum = 511;BA.debugLine="Dim cellKey As String = $\"${rowKey}c${LastColu";
_cellkey = (""+__c.SmartStringFormatter("",(Object)(_rowkey))+"c"+__c.SmartStringFormatter("",(Object)(_lastcolumn))+"");
 //BA.debugLineNum = 513;BA.debugLine="RC.Put(cellKey,cellKey)";
_rc.Put((Object)(_cellkey),(Object)(_cellkey));
 //BA.debugLineNum = 520;BA.debugLine="Dim tColumn As UOEHTML";
_tcolumn = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 521;BA.debugLine="tColumn.Initialize(cellKey,\"div\")";
_tcolumn._initialize(ba,_cellkey,"div");
 //BA.debugLineNum = 522;BA.debugLine="Dim strColumnClass As String = BuildColumnClas";
_strcolumnclass = _buildcolumnclass(_column);
 //BA.debugLineNum = 523;BA.debugLine="Dim strColumnStyle As String = BuildColumnStyl";
_strcolumnstyle = _buildcolumnstyle(_column);
 //BA.debugLineNum = 524;BA.debugLine="tColumn.AddClass(strColumnClass)";
_tcolumn._addclass(_strcolumnclass);
 //BA.debugLineNum = 525;BA.debugLine="tColumn.AddAttribute(\"style\",strColumnStyle)";
_tcolumn._addattribute("style",_strcolumnstyle);
 //BA.debugLineNum = 526;BA.debugLine="tColumn.AddClass(column.ClassName)";
_tcolumn._addclass(_column._classname);
 //BA.debugLineNum = 528;BA.debugLine="App.MaterialUseTheme(column.Theme,tColumn)";
_app._materialusetheme(_column._theme,_tcolumn);
 //BA.debugLineNum = 530;BA.debugLine="Dim classKey As String = $\"r${LastRow}c${LastC";
_classkey = ("r"+__c.SmartStringFormatter("",(Object)(_lastrow))+"c"+__c.SmartStringFormatter("",(Object)(_lastcolumn))+"");
 //BA.debugLineNum = 531;BA.debugLine="If columnClasses.ContainsKey(classKey) Then";
if (_columnclasses.ContainsKey((Object)(_classkey))) { 
 //BA.debugLineNum = 533;BA.debugLine="Dim cm As Map = columnClasses.Get(classKey)";
_cm = new anywheresoftware.b4a.objects.collections.Map();
_cm.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_columnclasses.Get((Object)(_classkey))));
 //BA.debugLineNum = 534;BA.debugLine="tColumn.AddClass(MapKeys2Delim(cm,\" \"))";
_tcolumn._addclass(_mapkeys2delim(_cm," "));
 };
 //BA.debugLineNum = 536;BA.debugLine="If Components.ContainsKey(cellKey) Then";
if (_components.ContainsKey((Object)(_cellkey))) { 
 //BA.debugLineNum = 537;BA.debugLine="Dim lst As List = Components.Get(cellKey)";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst.setObject((java.util.List)(_components.Get((Object)(_cellkey))));
 //BA.debugLineNum = 538;BA.debugLine="tColumn.AddContentList(lst)";
_tcolumn._addcontentlist(_lst);
 };
 //BA.debugLineNum = 540;BA.debugLine="tRow.AddElement(tColumn)";
_trow._addelement(_tcolumn);
 }
};
 }
};
 //BA.debugLineNum = 544;BA.debugLine="Dim strRow As String = tRow.tostring";
_strrow = _trow._tostring();
 //BA.debugLineNum = 545;BA.debugLine="sb.Append(strRow).Append(CRLF)";
_sb.Append(_strrow).Append(__c.CRLF);
 }
};
 //BA.debugLineNum = 548;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 549;BA.debugLine="End Sub";
return "";
}
public String  _buildrowclass() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 632;BA.debugLine="private Sub BuildRowClass() As String";
 //BA.debugLineNum = 633;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 634;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 635;BA.debugLine="sb.Append($\"${rowClass} \"$)";
_sb.Append((""+__c.SmartStringFormatter("",(Object)(_rowclass))+" "));
 //BA.debugLineNum = 636;BA.debugLine="Return sb.tostring.trim";
if (true) return _sb.ToString().trim();
 //BA.debugLineNum = 637;BA.debugLine="End Sub";
return "";
}
public String  _buildrowstyle(b4j.Mashy.UOEBANano.uoerow _row) throws Exception{
anywheresoftware.b4a.objects.collections.Map _rowc = null;
String _rowkey = "";
boolean _hasrow = false;
String _strmargins = "";
String _strpadding = "";
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 565;BA.debugLine="private Sub BuildRowStyle(row As UOERow) As String";
 //BA.debugLineNum = 566;BA.debugLine="Dim rowc As Map";
_rowc = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 567;BA.debugLine="rowc.Initialize";
_rowc.Initialize();
 //BA.debugLineNum = 568;BA.debugLine="rowc.clear";
_rowc.Clear();
 //BA.debugLineNum = 569;BA.debugLine="Dim rowKey As String = $\"r${row.Row}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_row._row))+"");
 //BA.debugLineNum = 570;BA.debugLine="Dim hasrow As Boolean = rowPadding.ContainsKey(ro";
_hasrow = _rowpadding.ContainsKey((Object)(_rowkey));
 //BA.debugLineNum = 571;BA.debugLine="If hasrow Then";
if (_hasrow) { 
 //BA.debugLineNum = 572;BA.debugLine="rowc = rowPadding.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowpadding.Get((Object)(_rowkey))));
 //BA.debugLineNum = 573;BA.debugLine="row.PaddingTop = rowc.get(\"pt\")";
_row._paddingtop = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pt"))));
 //BA.debugLineNum = 574;BA.debugLine="row.PaddingBottom = rowc.get(\"pb\")";
_row._paddingbottom = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pb"))));
 //BA.debugLineNum = 575;BA.debugLine="row.PaddingLeft = rowc.get(\"pl\")";
_row._paddingleft = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pl"))));
 //BA.debugLineNum = 576;BA.debugLine="row.PaddingRight = rowc.get(\"pr\")";
_row._paddingright = (int)(BA.ObjectToNumber(_rowc.Get((Object)("pr"))));
 };
 //BA.debugLineNum = 578;BA.debugLine="Dim hasrow As Boolean = rowMargins.ContainsKey(ro";
_hasrow = _rowmargins.ContainsKey((Object)(_rowkey));
 //BA.debugLineNum = 579;BA.debugLine="If hasrow Then";
if (_hasrow) { 
 //BA.debugLineNum = 580;BA.debugLine="rowc = rowMargins.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowmargins.Get((Object)(_rowkey))));
 //BA.debugLineNum = 581;BA.debugLine="row.MarginTop = rowc.get(\"mt\")";
_row._margintop = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mt"))));
 //BA.debugLineNum = 582;BA.debugLine="row.MarginBottom = rowc.get(\"mb\")";
_row._marginbottom = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mb"))));
 //BA.debugLineNum = 583;BA.debugLine="row.MarginLeft = rowc.get(\"ml\")";
_row._marginleft = (int)(BA.ObjectToNumber(_rowc.Get((Object)("ml"))));
 //BA.debugLineNum = 584;BA.debugLine="row.MarginRight = rowc.get(\"mr\")";
_row._marginright = (int)(BA.ObjectToNumber(_rowc.Get((Object)("mr"))));
 };
 //BA.debugLineNum = 587;BA.debugLine="Dim strMargins As String = BuildMargins(row.Margi";
_strmargins = _buildmargins(_row._margintop,_row._marginbottom,_row._marginleft,_row._marginright);
 //BA.debugLineNum = 588;BA.debugLine="Dim strPadding As String = BuildPadding(row.Paddi";
_strpadding = _buildpadding(_row._paddingtop,_row._paddingbottom,_row._paddingleft,_row._paddingright);
 //BA.debugLineNum = 589;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 590;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 592;BA.debugLine="sb.Append(strMargins)";
_sb.Append(_strmargins);
 //BA.debugLineNum = 594;BA.debugLine="sb.Append(strPadding)";
_sb.Append(_strpadding);
 //BA.debugLineNum = 595;BA.debugLine="Return sb.tostring.trim";
if (true) return _sb.ToString().trim();
 //BA.debugLineNum = 596;BA.debugLine="End Sub";
return "";
}
public String  _buildspans(int _ss,int _sm,int _sl) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _colkey = "";
String _colc = "";
 //BA.debugLineNum = 640;BA.debugLine="Private Sub BuildSpans(SS As Int, SM As Int, SL As";
 //BA.debugLineNum = 641;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 642;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 644;BA.debugLine="Dim kTot As Int = colClass.Size - 1";
_ktot = (int) (_colclass.getSize()-1);
 //BA.debugLineNum = 645;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 646;BA.debugLine="For kCnt = 0 To kTot";
{
final int step5 = 1;
final int limit5 = _ktot;
_kcnt = (int) (0) ;
for (;_kcnt <= limit5 ;_kcnt = _kcnt + step5 ) {
 //BA.debugLineNum = 647;BA.debugLine="Dim colKey As String = colClass.GetKeyAt(kCnt)";
_colkey = BA.ObjectToString(_colclass.GetKeyAt(_kcnt));
 //BA.debugLineNum = 649;BA.debugLine="Dim colC As String = colClass.Get(colKey)";
_colc = BA.ObjectToString(_colclass.Get((Object)(_colkey)));
 //BA.debugLineNum = 650;BA.debugLine="sb.Append(colC)";
_sb.Append(_colc);
 //BA.debugLineNum = 652;BA.debugLine="Select Case colKey";
switch (BA.switchObjectToInt(_colkey,"s","m","l")) {
case 0: {
 //BA.debugLineNum = 654;BA.debugLine="sb.Append(SS)";
_sb.Append(BA.NumberToString(_ss));
 break; }
case 1: {
 //BA.debugLineNum = 656;BA.debugLine="sb.Append(SM)";
_sb.Append(BA.NumberToString(_sm));
 break; }
case 2: {
 //BA.debugLineNum = 658;BA.debugLine="sb.Append(SL)";
_sb.Append(BA.NumberToString(_sl));
 break; }
}
;
 //BA.debugLineNum = 660;BA.debugLine="sb.Append(\" \")";
_sb.Append(" ");
 }
};
 //BA.debugLineNum = 662;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 663;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 5;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 8;BA.debugLine="Private Rows As Map";
_rows = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 10;BA.debugLine="Private Columns As Map";
_columns = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 13;BA.debugLine="Private LastRow As Int";
_lastrow = 0;
 //BA.debugLineNum = 15;BA.debugLine="Private colClass As Map = CreateMap(\"s\": \"s\",\"m\":";
_colclass = new anywheresoftware.b4a.objects.collections.Map();
_colclass = __c.createMap(new Object[] {(Object)("s"),(Object)("s"),(Object)("m"),(Object)("m"),(Object)("l"),(Object)("l")});
 //BA.debugLineNum = 17;BA.debugLine="Private padClass As Map = CreateMap(\"pt\":\"padding";
_padclass = new anywheresoftware.b4a.objects.collections.Map();
_padclass = __c.createMap(new Object[] {(Object)("pt"),(Object)("padding-top:"),(Object)("pb"),(Object)("padding-bottom:"),(Object)("pl"),(Object)("padding-left:"),(Object)("pr"),(Object)("padding-right:")});
 //BA.debugLineNum = 19;BA.debugLine="Private marClass As Map = CreateMap(\"mt\":\"margin-";
_marclass = new anywheresoftware.b4a.objects.collections.Map();
_marclass = __c.createMap(new Object[] {(Object)("mt"),(Object)("margin-top:"),(Object)("mb"),(Object)("margin-bottom:"),(Object)("ml"),(Object)("margin-left:"),(Object)("mr"),(Object)("margin-right:")});
 //BA.debugLineNum = 21;BA.debugLine="Private offClass As Map = CreateMap(\"s\":\"offset-s";
_offclass = new anywheresoftware.b4a.objects.collections.Map();
_offclass = __c.createMap(new Object[] {(Object)("s"),(Object)("offset-s"),(Object)("m"),(Object)("offset-m"),(Object)("l"),(Object)("offset-l")});
 //BA.debugLineNum = 23;BA.debugLine="Private RC As Map";
_rc = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 24;BA.debugLine="Private rowClass As String = \"row\"";
_rowclass = "row";
 //BA.debugLineNum = 25;BA.debugLine="Private cellClass As String = \"col\"";
_cellclass = "col";
 //BA.debugLineNum = 27;BA.debugLine="Public ShowID As Boolean";
_showid = false;
 //BA.debugLineNum = 28;BA.debugLine="Private parentID As String";
_parentid = "";
 //BA.debugLineNum = 29;BA.debugLine="Private Components As Map";
_components = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 30;BA.debugLine="Private rowClasses As Map";
_rowclasses = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 31;BA.debugLine="Private columnClasses As Map";
_columnclasses = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 32;BA.debugLine="Public App As UOEApp	'ignore";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 33;BA.debugLine="Public rowPadding As Map";
_rowpadding = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 34;BA.debugLine="Public rowMargins As Map";
_rowmargins = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public boolean  _columnexists(int _rowpos,int _colpos) throws Exception{
String _rowcol = "";
 //BA.debugLineNum = 755;BA.debugLine="Sub ColumnExists(rowPos As Int, colPos As Int) As";
 //BA.debugLineNum = 756;BA.debugLine="Dim rowcol As String = $\"r${rowPos}c${colPos}\"$";
_rowcol = ("r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"c"+__c.SmartStringFormatter("",(Object)(_colpos))+"");
 //BA.debugLineNum = 757;BA.debugLine="Return RC.ContainsKey(rowcol)";
if (true) return _rc.ContainsKey((Object)(_rowcol));
 //BA.debugLineNum = 758;BA.debugLine="End Sub";
return false;
}
public b4j.Mashy.UOEBANano.uoecolumn  _createcolumn(int _columns2add,int _offsetsmall,int _offsetmedium,int _offsetlarge,int _offsetxlarge,int _spansmall,int _spanmedium,int _spanlarge,String _spanxlarge,int _margintop,int _marginbottom,int _marginleft,int _marginright,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright,String _theme,String _visibility,String _classname) throws Exception{
b4j.Mashy.UOEBANano.uoecolumn _ncell = null;
 //BA.debugLineNum = 243;BA.debugLine="private Sub CreateColumn(Columns2Add As Int,  Offs";
 //BA.debugLineNum = 245;BA.debugLine="Dim nCell As UOEColumn";
_ncell = new b4j.Mashy.UOEBANano.uoecolumn();
 //BA.debugLineNum = 246;BA.debugLine="nCell.Initialize";
_ncell._initialize(ba);
 //BA.debugLineNum = 247;BA.debugLine="nCell.Columns = Columns2Add";
_ncell._columns = _columns2add;
 //BA.debugLineNum = 248;BA.debugLine="nCell.OffsetSmall = OffsetSmall";
_ncell._offsetsmall = _offsetsmall;
 //BA.debugLineNum = 249;BA.debugLine="nCell.OffsetMedium = OffsetMedium";
_ncell._offsetmedium = _offsetmedium;
 //BA.debugLineNum = 250;BA.debugLine="nCell.OffsetLarge = OffsetLarge";
_ncell._offsetlarge = _offsetlarge;
 //BA.debugLineNum = 251;BA.debugLine="nCell.SpanSmall = SpanSmall";
_ncell._spansmall = _spansmall;
 //BA.debugLineNum = 252;BA.debugLine="nCell.SpanMedium = SpanMedium";
_ncell._spanmedium = _spanmedium;
 //BA.debugLineNum = 253;BA.debugLine="nCell.SpanLarge = SpanLarge";
_ncell._spanlarge = _spanlarge;
 //BA.debugLineNum = 254;BA.debugLine="nCell.MarginTop = MarginTop";
_ncell._margintop = _margintop;
 //BA.debugLineNum = 255;BA.debugLine="nCell.MarginBottom = MarginBottom";
_ncell._marginbottom = _marginbottom;
 //BA.debugLineNum = 256;BA.debugLine="nCell.MarginLeft = MarginLeft";
_ncell._marginleft = _marginleft;
 //BA.debugLineNum = 257;BA.debugLine="nCell.MarginRight = MarginRight";
_ncell._marginright = _marginright;
 //BA.debugLineNum = 258;BA.debugLine="nCell.PaddingBottom = PaddingBottom";
_ncell._paddingbottom = _paddingbottom;
 //BA.debugLineNum = 259;BA.debugLine="nCell.PaddingLeft = PaddingLeft";
_ncell._paddingleft = _paddingleft;
 //BA.debugLineNum = 260;BA.debugLine="nCell.PaddingTop = PaddingTop";
_ncell._paddingtop = _paddingtop;
 //BA.debugLineNum = 261;BA.debugLine="nCell.PaddingRight = PaddingRight";
_ncell._paddingright = _paddingright;
 //BA.debugLineNum = 262;BA.debugLine="nCell.Visibility = Visibility";
_ncell._visibility = _visibility;
 //BA.debugLineNum = 263;BA.debugLine="nCell.ClassName = ClassName";
_ncell._classname = _classname;
 //BA.debugLineNum = 264;BA.debugLine="nCell.Theme = Theme";
_ncell._theme = _theme;
 //BA.debugLineNum = 265;BA.debugLine="Return nCell";
if (true) return _ncell;
 //BA.debugLineNum = 266;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerow  _createrow(int _rows2add,int _margintop,int _marginbottom,int _marginleft,int _marginright,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright,String _visibility,String _themename,boolean _centerinpage,String _classname) throws Exception{
b4j.Mashy.UOEBANano.uoerow _nr = null;
 //BA.debugLineNum = 224;BA.debugLine="private Sub CreateRow(Rows2Add As Int, MarginTop A";
 //BA.debugLineNum = 225;BA.debugLine="Dim nr As UOERow";
_nr = new b4j.Mashy.UOEBANano.uoerow();
 //BA.debugLineNum = 226;BA.debugLine="nr.Initialize";
_nr._initialize(ba);
 //BA.debugLineNum = 227;BA.debugLine="nr.MarginBottom = MarginBottom";
_nr._marginbottom = _marginbottom;
 //BA.debugLineNum = 228;BA.debugLine="nr.MarginLeft = MarginLeft";
_nr._marginleft = _marginleft;
 //BA.debugLineNum = 229;BA.debugLine="nr.MarginRight = MarginRight";
_nr._marginright = _marginright;
 //BA.debugLineNum = 230;BA.debugLine="nr.MarginTop = MarginTop";
_nr._margintop = _margintop;
 //BA.debugLineNum = 231;BA.debugLine="nr.PaddingBottom = PaddingBottom";
_nr._paddingbottom = _paddingbottom;
 //BA.debugLineNum = 232;BA.debugLine="nr.PaddingLeft = PaddingLeft";
_nr._paddingleft = _paddingleft;
 //BA.debugLineNum = 233;BA.debugLine="nr.PaddingRight = PaddingRight";
_nr._paddingright = _paddingright;
 //BA.debugLineNum = 234;BA.debugLine="nr.PaddingTop = PaddingTop";
_nr._paddingtop = _paddingtop;
 //BA.debugLineNum = 235;BA.debugLine="nr.ThemeName = ThemeName";
_nr._themename = _themename;
 //BA.debugLineNum = 236;BA.debugLine="nr.Visibility = Visibility";
_nr._visibility = _visibility;
 //BA.debugLineNum = 237;BA.debugLine="nr.ClassName = ClassName";
_nr._classname = _classname;
 //BA.debugLineNum = 238;BA.debugLine="nr.Rows = Rows2Add";
_nr._rows = _rows2add;
 //BA.debugLineNum = 239;BA.debugLine="Return nr";
if (true) return _nr;
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return null;
}
public String  _cstr(Object _o) throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="private Sub CStr(o As Object) As String";
 //BA.debugLineNum = 38;BA.debugLine="Return \"\" & o";
if (true) return ""+BA.ObjectToString(_o);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return "";
}
public int  _howmanyrows() throws Exception{
 //BA.debugLineNum = 761;BA.debugLine="Sub HowManyRows() As Int";
 //BA.debugLineNum = 762;BA.debugLine="Return LastRow";
if (true) return _lastrow;
 //BA.debugLineNum = 763;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _parent) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 269;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, parent As";
 //BA.debugLineNum = 270;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 271;BA.debugLine="Rows.Initialize";
_rows.Initialize();
 //BA.debugLineNum = 272;BA.debugLine="Rows.clear";
_rows.Clear();
 //BA.debugLineNum = 273;BA.debugLine="LastRow = 0";
_lastrow = (int) (0);
 //BA.debugLineNum = 274;BA.debugLine="RC.Initialize";
_rc.Initialize();
 //BA.debugLineNum = 275;BA.debugLine="RC.clear";
_rc.Clear();
 //BA.debugLineNum = 276;BA.debugLine="Columns.Initialize";
_columns.Initialize();
 //BA.debugLineNum = 277;BA.debugLine="Columns.clear";
_columns.Clear();
 //BA.debugLineNum = 278;BA.debugLine="ShowID = False";
_showid = __c.False;
 //BA.debugLineNum = 279;BA.debugLine="parentID = parent.tolowercase";
_parentid = _parent.toLowerCase();
 //BA.debugLineNum = 280;BA.debugLine="Components.Initialize";
_components.Initialize();
 //BA.debugLineNum = 281;BA.debugLine="Components.clear";
_components.Clear();
 //BA.debugLineNum = 282;BA.debugLine="rowClasses.Initialize";
_rowclasses.Initialize();
 //BA.debugLineNum = 283;BA.debugLine="rowClasses.clear";
_rowclasses.Clear();
 //BA.debugLineNum = 284;BA.debugLine="columnClasses.Initialize";
_columnclasses.Initialize();
 //BA.debugLineNum = 285;BA.debugLine="columnClasses.clear";
_columnclasses.Clear();
 //BA.debugLineNum = 286;BA.debugLine="rowPadding.Initialize";
_rowpadding.Initialize();
 //BA.debugLineNum = 287;BA.debugLine="rowPadding.clear";
_rowpadding.Clear();
 //BA.debugLineNum = 288;BA.debugLine="rowMargins.Initialize";
_rowmargins.Initialize();
 //BA.debugLineNum = 289;BA.debugLine="rowMargins.clear";
_rowmargins.Clear();
 //BA.debugLineNum = 290;BA.debugLine="End Sub";
return "";
}
public String  _mapkeys2delim(anywheresoftware.b4a.objects.collections.Map _m,String _delim) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _ktot = 0;
int _kcnt = 0;
String _strkey = "";
 //BA.debugLineNum = 448;BA.debugLine="private Sub MapKeys2Delim(m As Map, delim As Strin";
 //BA.debugLineNum = 449;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 450;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 451;BA.debugLine="Dim kTot As Int = m.Size - 1";
_ktot = (int) (_m.getSize()-1);
 //BA.debugLineNum = 452;BA.debugLine="Dim kCnt As Int";
_kcnt = 0;
 //BA.debugLineNum = 453;BA.debugLine="Dim strKey As String = m.getkeyat(0)";
_strkey = BA.ObjectToString(_m.GetKeyAt((int) (0)));
 //BA.debugLineNum = 454;BA.debugLine="sb.Append(strKey)";
_sb.Append(_strkey);
 //BA.debugLineNum = 455;BA.debugLine="For kCnt = 1 To kTot";
{
final int step7 = 1;
final int limit7 = _ktot;
_kcnt = (int) (1) ;
for (;_kcnt <= limit7 ;_kcnt = _kcnt + step7 ) {
 //BA.debugLineNum = 456;BA.debugLine="Dim strKey As String = m.getkeyat(kCnt)";
_strkey = BA.ObjectToString(_m.GetKeyAt(_kcnt));
 //BA.debugLineNum = 457;BA.debugLine="sb.Append(delim).append(strKey)";
_sb.Append(_delim).Append(_strkey);
 }
};
 //BA.debugLineNum = 459;BA.debugLine="Return sb.ToString";
if (true) return _sb.ToString();
 //BA.debugLineNum = 460;BA.debugLine="End Sub";
return "";
}
public String  _replacerc(int _rowpos,int _colpos,String _elhtml) throws Exception{
String _cellkey = "";
com.ab.banano.BANanoElement _elbody = null;
 //BA.debugLineNum = 423;BA.debugLine="Sub ReplaceRC(rowPos As Int, colPos As Int, elHTML";
 //BA.debugLineNum = 424;BA.debugLine="Dim cellKey As String = $\"#${parentID}r${rowPos}c";
_cellkey = ("#"+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"c"+__c.SmartStringFormatter("",(Object)(_colpos))+"");
 //BA.debugLineNum = 425;BA.debugLine="Dim elBody As BANanoElement";
_elbody = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 426;BA.debugLine="elBody = BANano.GetElement(cellKey)";
_elbody = _banano.GetElement(_cellkey);
 //BA.debugLineNum = 427;BA.debugLine="If elBody <> Null Then";
if (_elbody!= null) { 
 //BA.debugLineNum = 428;BA.debugLine="elBody.Empty";
_elbody.Empty();
 //BA.debugLineNum = 429;BA.debugLine="elBody.SetHTML(elHTML)";
_elbody.SetHTML(_elhtml);
 };
 //BA.debugLineNum = 431;BA.debugLine="End Sub";
return "";
}
public boolean  _rowexists(int _rowpos) throws Exception{
String _rowcol = "";
 //BA.debugLineNum = 749;BA.debugLine="Sub RowExists(rowPos As Int) As Boolean";
 //BA.debugLineNum = 750;BA.debugLine="Dim rowcol As String = $\"r${rowPos}\"$";
_rowcol = ("r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"");
 //BA.debugLineNum = 751;BA.debugLine="Return Rows.ContainsKey(rowcol)";
if (true) return _rows.ContainsKey((Object)(_rowcol));
 //BA.debugLineNum = 752;BA.debugLine="End Sub";
return false;
}
public String  _setcolumnclass(int _rowpos,int _columnpos,String _classname) throws Exception{
anywheresoftware.b4a.objects.collections.Map _rowc = null;
String _rowkey = "";
 //BA.debugLineNum = 208;BA.debugLine="Sub setColumnClass(rowPos As Int, columnPos As Int";
 //BA.debugLineNum = 210;BA.debugLine="Dim rowc As Map";
_rowc = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 211;BA.debugLine="Dim rowKey As String = $\"r${rowPos}c${columnPos}\"";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"c"+__c.SmartStringFormatter("",(Object)(_columnpos))+"");
 //BA.debugLineNum = 212;BA.debugLine="If columnClasses.ContainsKey(rowKey) Then";
if (_columnclasses.ContainsKey((Object)(_rowkey))) { 
 //BA.debugLineNum = 213;BA.debugLine="rowc = columnClasses.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_columnclasses.Get((Object)(_rowkey))));
 }else {
 //BA.debugLineNum = 215;BA.debugLine="rowc.Initialize";
_rowc.Initialize();
 //BA.debugLineNum = 216;BA.debugLine="rowc.clear";
_rowc.Clear();
 };
 //BA.debugLineNum = 218;BA.debugLine="rowc.Put(className,className)";
_rowc.Put((Object)(_classname),(Object)(_classname));
 //BA.debugLineNum = 219;BA.debugLine="columnClasses.Put(rowKey,rowc)";
_columnclasses.Put((Object)(_rowkey),(Object)(_rowc.getObject()));
 //BA.debugLineNum = 220;BA.debugLine="End Sub";
return "";
}
public String  _setcolumnmargins(int _rowpos,int _colpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
String _srow = "";
String _scol = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcy = null;
 //BA.debugLineNum = 95;BA.debugLine="Sub setColumnMargins(rowPos As Int, colPos As Int,";
 //BA.debugLineNum = 97;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 98;BA.debugLine="Dim sCol As String = CStr(colPos)";
_scol = _cstr((Object)(_colpos));
 //BA.debugLineNum = 99;BA.debugLine="Dim rowKey As String = $\"r${sRow}c${sCol}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_srow))+"c"+__c.SmartStringFormatter("",(Object)(_scol))+"");
 //BA.debugLineNum = 100;BA.debugLine="Dim rowcy As Map = CreateMap(\"mt\": CStr(marginTop";
_rowcy = new anywheresoftware.b4a.objects.collections.Map();
_rowcy = __c.createMap(new Object[] {(Object)("mt"),(Object)(_cstr((Object)(_margintop))),(Object)("mb"),(Object)(_cstr((Object)(_marginbottom))),(Object)("ml"),(Object)(_cstr((Object)(_marginleft))),(Object)("mr"),(Object)(_cstr((Object)(_marginright)))});
 //BA.debugLineNum = 101;BA.debugLine="rowMargins.Put(rowKey,rowcy)";
_rowmargins.Put((Object)(_rowkey),(Object)(_rowcy.getObject()));
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public String  _setcolumnmargins1(int _rowpos,int _colpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
String _srow = "";
String _scol = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcx = null;
String _str = "";
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 162;BA.debugLine="Sub setColumnMargins1(rowPos As Int, colPos As Int";
 //BA.debugLineNum = 164;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 165;BA.debugLine="Dim sCol As String = CStr(colPos)";
_scol = _cstr((Object)(_colpos));
 //BA.debugLineNum = 166;BA.debugLine="Dim rowKey As String = $\"#${parentID}r${sRow}c${s";
_rowkey = ("#"+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_srow))+"c"+__c.SmartStringFormatter("",(Object)(_scol))+"");
 //BA.debugLineNum = 167;BA.debugLine="Dim rowcx As Map";
_rowcx = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 168;BA.debugLine="rowcx.Initialize";
_rowcx.Initialize();
 //BA.debugLineNum = 169;BA.debugLine="rowcx.clear";
_rowcx.Clear();
 //BA.debugLineNum = 170;BA.debugLine="rowcx.Put(\"margin-top\", CStr(marginTop) & \"px\")";
_rowcx.Put((Object)("margin-top"),(Object)(_cstr((Object)(_margintop))+"px"));
 //BA.debugLineNum = 171;BA.debugLine="rowcx.Put(\"margin-bottom\", CStr(marginBottom) & \"";
_rowcx.Put((Object)("margin-bottom"),(Object)(_cstr((Object)(_marginbottom))+"px"));
 //BA.debugLineNum = 172;BA.debugLine="rowcx.Put(\"margin-left\", CStr(marginLeft) & \"px\")";
_rowcx.Put((Object)("margin-left"),(Object)(_cstr((Object)(_marginleft))+"px"));
 //BA.debugLineNum = 173;BA.debugLine="rowcx.Put(\"margin-right\", CStr(marginRight) & \"px";
_rowcx.Put((Object)("margin-right"),(Object)(_cstr((Object)(_marginright))+"px"));
 //BA.debugLineNum = 174;BA.debugLine="Dim str As String = App.Map2Json(rowcx)";
_str = _app._map2json(_rowcx);
 //BA.debugLineNum = 175;BA.debugLine="Dim el As BANanoElement";
_el = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 176;BA.debugLine="el = BANano.GetElement(rowKey)";
_el = _banano.GetElement(_rowkey);
 //BA.debugLineNum = 177;BA.debugLine="el.SetStyle(str)";
_el.SetStyle(_str);
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _setcolumnpadding(int _rowpos,int _colpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
String _srow = "";
String _scol = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcx = null;
 //BA.debugLineNum = 114;BA.debugLine="Sub setColumnPadding(rowPos As Int, colPos As Int,";
 //BA.debugLineNum = 116;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 117;BA.debugLine="Dim sCol As String = CStr(colPos)";
_scol = _cstr((Object)(_colpos));
 //BA.debugLineNum = 118;BA.debugLine="Dim rowKey As String = $\"r${sRow}c${sCol}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_srow))+"c"+__c.SmartStringFormatter("",(Object)(_scol))+"");
 //BA.debugLineNum = 119;BA.debugLine="Dim rowcx As Map = CreateMap(\"pt\": CStr(paddingTo";
_rowcx = new anywheresoftware.b4a.objects.collections.Map();
_rowcx = __c.createMap(new Object[] {(Object)("pt"),(Object)(_cstr((Object)(_paddingtop))),(Object)("pb"),(Object)(_cstr((Object)(_paddingbottom))),(Object)("pl"),(Object)(_cstr((Object)(_paddingleft))),(Object)("pr"),(Object)(_cstr((Object)(_paddingright)))});
 //BA.debugLineNum = 120;BA.debugLine="rowPadding.Put(rowKey,rowcx)";
_rowpadding.Put((Object)(_rowkey),(Object)(_rowcx.getObject()));
 //BA.debugLineNum = 121;BA.debugLine="End Sub";
return "";
}
public String  _setcolumnpadding1(int _rowpos,int _colpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
String _srow = "";
String _scol = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcx = null;
String _str = "";
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 124;BA.debugLine="Sub setColumnPadding1(rowPos As Int, colPos As Int";
 //BA.debugLineNum = 126;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 127;BA.debugLine="Dim sCol As String = CStr(colPos)";
_scol = _cstr((Object)(_colpos));
 //BA.debugLineNum = 128;BA.debugLine="Dim rowKey As String = $\"#${parentID}r${sRow}c${s";
_rowkey = ("#"+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_srow))+"c"+__c.SmartStringFormatter("",(Object)(_scol))+"");
 //BA.debugLineNum = 129;BA.debugLine="Dim rowcx As Map";
_rowcx = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 130;BA.debugLine="rowcx.Initialize";
_rowcx.Initialize();
 //BA.debugLineNum = 131;BA.debugLine="rowcx.clear";
_rowcx.Clear();
 //BA.debugLineNum = 132;BA.debugLine="rowcx.Put(\"padding-top\", CStr(paddingTop) & \"px\")";
_rowcx.Put((Object)("padding-top"),(Object)(_cstr((Object)(_paddingtop))+"px"));
 //BA.debugLineNum = 133;BA.debugLine="rowcx.Put(\"padding-bottom\", CStr(paddingBottom) &";
_rowcx.Put((Object)("padding-bottom"),(Object)(_cstr((Object)(_paddingbottom))+"px"));
 //BA.debugLineNum = 134;BA.debugLine="rowcx.Put(\"padding-left\", CStr(paddingLeft) & \"px";
_rowcx.Put((Object)("padding-left"),(Object)(_cstr((Object)(_paddingleft))+"px"));
 //BA.debugLineNum = 135;BA.debugLine="rowcx.Put(\"padding-right\", CStr(paddingRight) & \"";
_rowcx.Put((Object)("padding-right"),(Object)(_cstr((Object)(_paddingright))+"px"));
 //BA.debugLineNum = 136;BA.debugLine="Dim str As String = App.Map2Json(rowcx)";
_str = _app._map2json(_rowcx);
 //BA.debugLineNum = 137;BA.debugLine="Dim el As BANanoElement";
_el = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 138;BA.debugLine="el = BANano.GetElement(rowKey)";
_el = _banano.GetElement(_rowkey);
 //BA.debugLineNum = 139;BA.debugLine="el.SetStyle(str)";
_el.SetStyle(_str);
 //BA.debugLineNum = 140;BA.debugLine="End Sub";
return "";
}
public String  _setrowclass(int _rowpos,String _classname) throws Exception{
anywheresoftware.b4a.objects.collections.Map _rowc = null;
String _rowkey = "";
 //BA.debugLineNum = 80;BA.debugLine="Sub setRowClass(rowPos As Int, className As String";
 //BA.debugLineNum = 82;BA.debugLine="Dim rowc As Map";
_rowc = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 83;BA.debugLine="Dim rowKey As String = $\"r${rowPos}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_rowpos))+"");
 //BA.debugLineNum = 84;BA.debugLine="If rowClasses.ContainsKey(rowKey) Then";
if (_rowclasses.ContainsKey((Object)(_rowkey))) { 
 //BA.debugLineNum = 85;BA.debugLine="rowc = rowClasses.Get(rowKey)";
_rowc.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_rowclasses.Get((Object)(_rowkey))));
 }else {
 //BA.debugLineNum = 87;BA.debugLine="rowc.Initialize";
_rowc.Initialize();
 //BA.debugLineNum = 88;BA.debugLine="rowc.clear";
_rowc.Clear();
 };
 //BA.debugLineNum = 90;BA.debugLine="rowc.Put(className,className)";
_rowc.Put((Object)(_classname),(Object)(_classname));
 //BA.debugLineNum = 91;BA.debugLine="rowClasses.Put(rowKey,rowc)";
_rowclasses.Put((Object)(_rowkey),(Object)(_rowc.getObject()));
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public String  _setrowmargins(int _rowpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
String _srow = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcb = null;
 //BA.debugLineNum = 105;BA.debugLine="Sub setRowMargins(rowPos As Int, marginTop As Int,";
 //BA.debugLineNum = 107;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 108;BA.debugLine="Dim rowKey As String = $\"r${sRow}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_srow))+"");
 //BA.debugLineNum = 109;BA.debugLine="Dim rowcb As Map = CreateMap(\"mt\": CStr(marginTop";
_rowcb = new anywheresoftware.b4a.objects.collections.Map();
_rowcb = __c.createMap(new Object[] {(Object)("mt"),(Object)(_cstr((Object)(_margintop))),(Object)("mb"),(Object)(_cstr((Object)(_marginbottom))),(Object)("ml"),(Object)(_cstr((Object)(_marginleft))),(Object)("mr"),(Object)(_cstr((Object)(_marginright)))});
 //BA.debugLineNum = 110;BA.debugLine="rowMargins.Put(rowKey,rowcb)";
_rowmargins.Put((Object)(_rowkey),(Object)(_rowcb.getObject()));
 //BA.debugLineNum = 111;BA.debugLine="End Sub";
return "";
}
public String  _setrowmargins1(int _rowpos,int _margintop,int _marginbottom,int _marginleft,int _marginright) throws Exception{
String _srow = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcx = null;
String _str = "";
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 181;BA.debugLine="Sub setRowMargins1(rowPos As Int, marginTop As Int";
 //BA.debugLineNum = 183;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 184;BA.debugLine="Dim rowKey As String = $\"#${parentID}r${sRow}\"$";
_rowkey = ("#"+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_srow))+"");
 //BA.debugLineNum = 185;BA.debugLine="Dim rowcx As Map";
_rowcx = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 186;BA.debugLine="rowcx.Initialize";
_rowcx.Initialize();
 //BA.debugLineNum = 187;BA.debugLine="rowcx.clear";
_rowcx.Clear();
 //BA.debugLineNum = 188;BA.debugLine="rowcx.Put(\"margin-top\", CStr(marginTop) & \"px\")";
_rowcx.Put((Object)("margin-top"),(Object)(_cstr((Object)(_margintop))+"px"));
 //BA.debugLineNum = 189;BA.debugLine="rowcx.Put(\"margin-bottom\", CStr(marginBottom) & \"";
_rowcx.Put((Object)("margin-bottom"),(Object)(_cstr((Object)(_marginbottom))+"px"));
 //BA.debugLineNum = 190;BA.debugLine="rowcx.Put(\"margin-left\", CStr(marginLeft) & \"px\")";
_rowcx.Put((Object)("margin-left"),(Object)(_cstr((Object)(_marginleft))+"px"));
 //BA.debugLineNum = 191;BA.debugLine="rowcx.Put(\"margin-right\", CStr(marginRight) & \"px";
_rowcx.Put((Object)("margin-right"),(Object)(_cstr((Object)(_marginright))+"px"));
 //BA.debugLineNum = 192;BA.debugLine="Dim str As String = App.Map2Json(rowcx)";
_str = _app._map2json(_rowcx);
 //BA.debugLineNum = 193;BA.debugLine="Dim el As BANanoElement";
_el = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 194;BA.debugLine="el = BANano.GetElement(rowKey)";
_el = _banano.GetElement(_rowkey);
 //BA.debugLineNum = 195;BA.debugLine="el.SetStyle(str)";
_el.SetStyle(_str);
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return "";
}
public String  _setrowpadding(int _rowpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
String _srow = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowca = null;
 //BA.debugLineNum = 199;BA.debugLine="Sub setRowPadding(rowPos As Int, paddingTop As Int";
 //BA.debugLineNum = 201;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 202;BA.debugLine="Dim rowKey As String = $\"r${sRow}\"$";
_rowkey = ("r"+__c.SmartStringFormatter("",(Object)(_srow))+"");
 //BA.debugLineNum = 203;BA.debugLine="Dim rowca As Map = CreateMap(\"pt\": CStr(paddingTo";
_rowca = new anywheresoftware.b4a.objects.collections.Map();
_rowca = __c.createMap(new Object[] {(Object)("pt"),(Object)(_cstr((Object)(_paddingtop))),(Object)("pb"),(Object)(_cstr((Object)(_paddingbottom))),(Object)("pl"),(Object)(_cstr((Object)(_paddingleft))),(Object)("pr"),(Object)(_cstr((Object)(_paddingright)))});
 //BA.debugLineNum = 204;BA.debugLine="rowPadding.Put(rowKey,rowca)";
_rowpadding.Put((Object)(_rowkey),(Object)(_rowca.getObject()));
 //BA.debugLineNum = 205;BA.debugLine="End Sub";
return "";
}
public String  _setrowpadding1(int _rowpos,int _paddingtop,int _paddingbottom,int _paddingleft,int _paddingright) throws Exception{
String _srow = "";
String _rowkey = "";
anywheresoftware.b4a.objects.collections.Map _rowcx = null;
String _str = "";
com.ab.banano.BANanoElement _el = null;
 //BA.debugLineNum = 143;BA.debugLine="Sub setRowPadding1(rowPos As Int, paddingTop As In";
 //BA.debugLineNum = 145;BA.debugLine="Dim sRow As String = CStr(rowPos)";
_srow = _cstr((Object)(_rowpos));
 //BA.debugLineNum = 146;BA.debugLine="Dim rowKey As String = $\"#${parentID}r${sRow}\"$";
_rowkey = ("#"+__c.SmartStringFormatter("",(Object)(_parentid))+"r"+__c.SmartStringFormatter("",(Object)(_srow))+"");
 //BA.debugLineNum = 147;BA.debugLine="Dim rowcx As Map";
_rowcx = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 148;BA.debugLine="rowcx.Initialize";
_rowcx.Initialize();
 //BA.debugLineNum = 149;BA.debugLine="rowcx.clear";
_rowcx.Clear();
 //BA.debugLineNum = 150;BA.debugLine="rowcx.Put(\"padding-top\", CStr(paddingTop) & \"px\")";
_rowcx.Put((Object)("padding-top"),(Object)(_cstr((Object)(_paddingtop))+"px"));
 //BA.debugLineNum = 151;BA.debugLine="rowcx.Put(\"padding-bottom\", CStr(paddingBottom) &";
_rowcx.Put((Object)("padding-bottom"),(Object)(_cstr((Object)(_paddingbottom))+"px"));
 //BA.debugLineNum = 152;BA.debugLine="rowcx.Put(\"padding-left\", CStr(paddingLeft) & \"px";
_rowcx.Put((Object)("padding-left"),(Object)(_cstr((Object)(_paddingleft))+"px"));
 //BA.debugLineNum = 153;BA.debugLine="rowcx.Put(\"padding-right\", CStr(paddingRight) & \"";
_rowcx.Put((Object)("padding-right"),(Object)(_cstr((Object)(_paddingright))+"px"));
 //BA.debugLineNum = 154;BA.debugLine="Dim str As String = App.Map2Json(rowcx)";
_str = _app._map2json(_rowcx);
 //BA.debugLineNum = 155;BA.debugLine="Dim el As BANanoElement";
_el = new com.ab.banano.BANanoElement();
 //BA.debugLineNum = 156;BA.debugLine="el = BANano.GetElement(rowKey)";
_el = _banano.GetElement(_rowkey);
 //BA.debugLineNum = 157;BA.debugLine="el.SetStyle(str)";
_el.SetStyle(_str);
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _rowcnt = 0;
int _rowtot = 0;
String _rowkey = "";
b4j.Mashy.UOEBANano.uoerow _currentrow = null;
String _strrow = "";
 //BA.debugLineNum = 402;BA.debugLine="Sub ToString() As String";
 //BA.debugLineNum = 404;BA.debugLine="LastRow = 0";
_lastrow = (int) (0);
 //BA.debugLineNum = 405;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 406;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 408;BA.debugLine="Dim rowCnt As Int = 0";
_rowcnt = (int) (0);
 //BA.debugLineNum = 409;BA.debugLine="Dim rowTot As Int = Rows.Size - 1";
_rowtot = (int) (_rows.getSize()-1);
 //BA.debugLineNum = 410;BA.debugLine="For rowCnt = 0 To rowTot";
{
final int step6 = 1;
final int limit6 = _rowtot;
_rowcnt = (int) (0) ;
for (;_rowcnt <= limit6 ;_rowcnt = _rowcnt + step6 ) {
 //BA.debugLineNum = 411;BA.debugLine="Dim rowKey As String = Rows.GetKeyAt(rowCnt)";
_rowkey = BA.ObjectToString(_rows.GetKeyAt(_rowcnt));
 //BA.debugLineNum = 412;BA.debugLine="Dim currentRow As UOERow";
_currentrow = new b4j.Mashy.UOEBANano.uoerow();
 //BA.debugLineNum = 413;BA.debugLine="currentRow.Initialize";
_currentrow._initialize(ba);
 //BA.debugLineNum = 414;BA.debugLine="currentRow = Rows.Get(rowKey)";
_currentrow = (b4j.Mashy.UOEBANano.uoerow)(_rows.Get((Object)(_rowkey)));
 //BA.debugLineNum = 415;BA.debugLine="Dim strRow As String = BuildRow(currentRow)";
_strrow = _buildrow(_currentrow);
 //BA.debugLineNum = 416;BA.debugLine="sb.Append(strRow)";
_sb.Append(_strrow);
 //BA.debugLineNum = 417;BA.debugLine="sb.append(CRLF)";
_sb.Append(__c.CRLF);
 }
};
 //BA.debugLineNum = 419;BA.debugLine="Return sb.tostring";
if (true) return _sb.ToString();
 //BA.debugLineNum = 420;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
