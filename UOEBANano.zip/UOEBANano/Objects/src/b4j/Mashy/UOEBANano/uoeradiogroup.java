package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeradiogroup extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeradiogroup", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeradiogroup.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _title = "";
public String _theme = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _container = null;
public String _visibility = "";
public String _zdepth = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeradiogroup  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 52;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 53;BA.debugLine="Container.AddAttribute(attr,value)";
_container._addattribute(_attr,_value);
 //BA.debugLineNum = 54;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradiogroup)(this);
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeradiogroup  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 40;BA.debugLine="Sub AddClass(sClass As String) As UOERadioGroup";
 //BA.debugLineNum = 41;BA.debugLine="Container.AddClass(sClass)";
_container._addclass(_sclass);
 //BA.debugLineNum = 42;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradiogroup)(this);
 //BA.debugLineNum = 43;BA.debugLine="End Sub";
return null;
}
public String  _additem(String _itemid,String _itemvalue,String _itemtext,boolean _withgap,boolean _binline,boolean _benabled,boolean _bselected) throws Exception{
b4j.Mashy.UOEBANano.uoeradio _rad = null;
 //BA.debugLineNum = 64;BA.debugLine="Sub AddItem(itemID As String, itemValue As String,";
 //BA.debugLineNum = 65;BA.debugLine="Dim rad As UOERadio";
_rad = new b4j.Mashy.UOEBANano.uoeradio();
 //BA.debugLineNum = 66;BA.debugLine="rad.Initialize(App,itemID,ID,itemValue,itemText,\"";
_rad._initialize(ba,_app,_itemid,_id,_itemvalue,_itemtext,"");
 //BA.debugLineNum = 67;BA.debugLine="rad.Checked = bSelected";
_rad._checked = _bselected;
 //BA.debugLineNum = 68;BA.debugLine="rad.Enabled = bEnabled";
_rad._enabled = _benabled;
 //BA.debugLineNum = 69;BA.debugLine="rad.Inline = bInline";
_rad._inline = _binline;
 //BA.debugLineNum = 70;BA.debugLine="rad.WithGap = withGap";
_rad._withgap = _withgap;
 //BA.debugLineNum = 71;BA.debugLine="Container.AddContent(rad.tostring)";
_container._addcontent(_rad._tostring());
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeradiogroup  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 17;BA.debugLine="Container.AddStyleAttribute(attribute,value)";
_container._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 18;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradiogroup)(this);
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Private Container As UOEHTML";
_container = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 10;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,boolean _btitlevisible,String _themename) throws Exception{
innerInitialize(_ba);
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 24;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 25;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 26;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 27;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 28;BA.debugLine="Container.Initialize(ID,\"div\")";
_container._initialize(ba,_id,"div");
 //BA.debugLineNum = 29;BA.debugLine="If bTitleVisible Then";
if (_btitlevisible) { 
 //BA.debugLineNum = 30;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 31;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 32;BA.debugLine="lbl.SetFOR(ID).AddContent(sTitle)";
_lbl._setfor(_id)._addcontent(_stitle);
 //BA.debugLineNum = 33;BA.debugLine="App.MaterialUseTheme(themeName,lbl)";
_app._materialusetheme(_themename,_lbl);
 //BA.debugLineNum = 34;BA.debugLine="Container.AddElement(lbl)";
_container._addelement(_lbl);
 };
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeradiogroup  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub RemoveAttribute(attr As String) As UOERadioGro";
 //BA.debugLineNum = 59;BA.debugLine="Container.RemoveAttribute(attr)";
_container._removeattribute(_attr);
 //BA.debugLineNum = 60;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradiogroup)(this);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeradiogroup  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 46;BA.debugLine="Sub RemoveClass(sClass As String) As UOERadioGroup";
 //BA.debugLineNum = 47;BA.debugLine="Container.RemoveClass(sClass)";
_container._removeclass(_sclass);
 //BA.debugLineNum = 48;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeradiogroup)(this);
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 75;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 76;BA.debugLine="Container.MaterialVisibility(Visibility).Material";
_container._materialvisibility(_visibility)._materialenable(_enabled);
 //BA.debugLineNum = 77;BA.debugLine="App.MaterialUseTheme(Theme,Container)";
_app._materialusetheme(_theme,_container);
 //BA.debugLineNum = 78;BA.debugLine="Container.MaterialZDepth(ZDepth).MaterialVisibili";
_container._materialzdepth(_zdepth)._materialvisibility(_visibility);
 //BA.debugLineNum = 83;BA.debugLine="App.ApplyToolTip(ID,Container)";
_app._applytooltip(_id,_container);
 //BA.debugLineNum = 84;BA.debugLine="Return Container.html";
if (true) return _container._html();
 //BA.debugLineNum = 85;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
