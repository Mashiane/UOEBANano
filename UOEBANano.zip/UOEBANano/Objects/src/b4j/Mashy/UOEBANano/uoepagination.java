package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoepagination extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoepagination", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoepagination.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _id = "";
public String _theme = "";
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _visibility = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _el = null;
public boolean _hoverable = false;
public int _ptot = 0;
public int _activepagenumber = 0;
public anywheresoftware.b4a.objects.collections.Map _links = null;
public boolean _showarrows = false;
public anywheresoftware.b4a.objects.collections.Map _texts = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoepagination  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 187;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 188;BA.debugLine="el.AddAttribute(attr,value)";
_el._addattribute(_attr,_value);
 //BA.debugLineNum = 189;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 175;BA.debugLine="Sub AddClass(sClass As String) As UOEPagination";
 //BA.debugLineNum = 176;BA.debugLine="el.AddClass(sClass)";
_el._addclass(_sclass);
 //BA.debugLineNum = 177;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _addlink(String _pglink) throws Exception{
int _pgnumber = 0;
String _pkey = "";
 //BA.debugLineNum = 47;BA.debugLine="Sub AddLink(pgLink As String) As UOEPagination";
 //BA.debugLineNum = 48;BA.debugLine="Dim pgNumber As Int = links.size + 1";
_pgnumber = (int) (_links.getSize()+1);
 //BA.debugLineNum = 49;BA.debugLine="Dim pKey As String = $\"${ID}page${pgNumber}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"page"+__c.SmartStringFormatter("",(Object)(_pgnumber))+"");
 //BA.debugLineNum = 50;BA.debugLine="links.Put(pKey,pgLink)";
_links.Put((Object)(_pkey),(Object)(_pglink));
 //BA.debugLineNum = 53;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 54;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _addlink1(int _pgnumber,String _pglink) throws Exception{
String _pkey = "";
 //BA.debugLineNum = 82;BA.debugLine="Sub AddLink1(pgNumber As Int, pgLink As String) As";
 //BA.debugLineNum = 83;BA.debugLine="Dim pKey As String = $\"${ID}page${pgNumber}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"page"+__c.SmartStringFormatter("",(Object)(_pgnumber))+"");
 //BA.debugLineNum = 84;BA.debugLine="links.Put(pKey,pgLink)";
_links.Put((Object)(_pkey),(Object)(_pglink));
 //BA.debugLineNum = 87;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return null;
}
public String  _addlink2(String _pgtext) throws Exception{
int _pgnumber = 0;
String _pkey = "";
 //BA.debugLineNum = 56;BA.debugLine="private Sub AddLink2(pgText As String)";
 //BA.debugLineNum = 57;BA.debugLine="Dim pgNumber As Int = texts.size + 1";
_pgnumber = (int) (_texts.getSize()+1);
 //BA.debugLineNum = 58;BA.debugLine="Dim pKey As String = $\"${ID}page${pgNumber}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"page"+__c.SmartStringFormatter("",(Object)(_pgnumber))+"");
 //BA.debugLineNum = 59;BA.debugLine="texts.Put(pKey,pgText)";
_texts.Put((Object)(_pkey),(Object)(_pgtext));
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoepagination  _addlinks(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
String _strlink = "";
 //BA.debugLineNum = 63;BA.debugLine="Sub AddLinks(lst As List) As UOEPagination";
 //BA.debugLineNum = 64;BA.debugLine="If lst <> Null Then";
if (_lst!= null) { 
 //BA.debugLineNum = 65;BA.debugLine="For Each strLink As String In lst";
{
final anywheresoftware.b4a.BA.IterableList group2 = _lst;
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_strlink = BA.ObjectToString(group2.Get(index2));
 //BA.debugLineNum = 66;BA.debugLine="AddLink(strLink)";
_addlink(_strlink);
 }
};
 };
 //BA.debugLineNum = 69;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 22;BA.debugLine="el.AddStyleAttribute(attribute,value)";
_el._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 23;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _addtexts(anywheresoftware.b4a.objects.collections.List _lst) throws Exception{
String _strlink = "";
 //BA.debugLineNum = 72;BA.debugLine="Sub AddTexts(lst As List) As UOEPagination";
 //BA.debugLineNum = 73;BA.debugLine="If lst <> Null Then";
if (_lst!= null) { 
 //BA.debugLineNum = 74;BA.debugLine="For Each strLink As String In lst";
{
final anywheresoftware.b4a.BA.IterableList group2 = _lst;
final int groupLen2 = group2.getSize()
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_strlink = BA.ObjectToString(group2.Get(index2));
 //BA.debugLineNum = 75;BA.debugLine="AddLink2(strLink)";
_addlink2(_strlink);
 }
};
 };
 //BA.debugLineNum = 78;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 5;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 6;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 7;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 9;BA.debugLine="Private el As UOEHTML";
_el = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 10;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 11;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 12;BA.debugLine="Private pTot As Int";
_ptot = 0;
 //BA.debugLineNum = 13;BA.debugLine="Public ActivePageNumber As Int";
_activepagenumber = 0;
 //BA.debugLineNum = 14;BA.debugLine="Private links As Map";
_links = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 15;BA.debugLine="Public ShowArrows As Boolean";
_showarrows = false;
 //BA.debugLineNum = 16;BA.debugLine="Private texts As Map";
_texts = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,int _totpages,String _themename,String _classname) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 27;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 29;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 30;BA.debugLine="ID = sID.ToLowerCase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 31;BA.debugLine="el.Initialize(ID,\"ul\")";
_el._initialize(ba,_id,"ul");
 //BA.debugLineNum = 32;BA.debugLine="el.AddClass(\"pagination\")";
_el._addclass("pagination");
 //BA.debugLineNum = 33;BA.debugLine="el.addClass(className)";
_el._addclass(_classname);
 //BA.debugLineNum = 34;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 35;BA.debugLine="ActivePageNumber = 0";
_activepagenumber = (int) (0);
 //BA.debugLineNum = 36;BA.debugLine="pTot = totPages";
_ptot = _totpages;
 //BA.debugLineNum = 37;BA.debugLine="links.Initialize";
_links.Initialize();
 //BA.debugLineNum = 38;BA.debugLine="links.clear";
_links.Clear();
 //BA.debugLineNum = 39;BA.debugLine="texts.Initialize";
_texts.Initialize();
 //BA.debugLineNum = 40;BA.debugLine="texts.clear";
_texts.Clear();
 //BA.debugLineNum = 41;BA.debugLine="ShowArrows = True";
_showarrows = __c.True;
 //BA.debugLineNum = 42;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 43;BA.debugLine="App.MaterialUseTheme(Theme,el)";
_app._materialusetheme(_theme,_el);
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoepagination  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 193;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEPaginati";
 //BA.debugLineNum = 194;BA.debugLine="el.RemoveAttribute(attr)";
_el._removeattribute(_attr);
 //BA.debugLineNum = 195;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 196;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoepagination  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 181;BA.debugLine="Sub RemoveClass(sClass As String) As UOEPagination";
 //BA.debugLineNum = 182;BA.debugLine="el.RemoveClass(sClass)";
_el._removeclass(_sclass);
 //BA.debugLineNum = 183;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoepagination)(this);
 //BA.debugLineNum = 184;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _la = null;
String _pkey = "";
b4j.Mashy.UOEBANano.uoehtml _i = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
int _pcnt = 0;
b4j.Mashy.UOEBANano.uoehtml _ep = null;
String _href = "";
boolean _haspkey = false;
boolean _hastext = false;
String _txt = "";
b4j.Mashy.UOEBANano.uoehtml _ra = null;
 //BA.debugLineNum = 91;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 92;BA.debugLine="el.ID = ID";
_el._id = _id;
 //BA.debugLineNum = 93;BA.debugLine="el.MaterialEnable(Enabled)";
_el._materialenable(_enabled);
 //BA.debugLineNum = 94;BA.debugLine="el.MaterialVisibility(Visibility)";
_el._materialvisibility(_visibility);
 //BA.debugLineNum = 96;BA.debugLine="Dim la As UOEHTML";
_la = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 97;BA.debugLine="Dim pKey As String = $\"${ID}pagefirst\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"pagefirst");
 //BA.debugLineNum = 98;BA.debugLine="la.Initialize(ID & \"first\",\"li\")";
_la._initialize(ba,_id+"first","li");
 //BA.debugLineNum = 100;BA.debugLine="Dim i As UOEHTML";
_i = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 101;BA.debugLine="i.Initialize(\"\",\"i\")";
_i._initialize(ba,"","i");
 //BA.debugLineNum = 102;BA.debugLine="i.AddClass(\"waves-effect\")";
_i._addclass("waves-effect");
 //BA.debugLineNum = 103;BA.debugLine="i.addclass(\"material-icons\")";
_i._addclass("material-icons");
 //BA.debugLineNum = 104;BA.debugLine="i.AddClass(\"disabled\")";
_i._addclass("disabled");
 //BA.debugLineNum = 105;BA.debugLine="i.AddContent(\"chevron_left\")";
_i._addcontent("chevron_left");
 //BA.debugLineNum = 107;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 108;BA.debugLine="a.Initialize(pKey,\"a\")";
_a._initialize(ba,_pkey,"a");
 //BA.debugLineNum = 109;BA.debugLine="a.SetHREF(\"#!\")";
_a._sethref("#!");
 //BA.debugLineNum = 110;BA.debugLine="a.AddElement(i)";
_a._addelement(_i);
 //BA.debugLineNum = 111;BA.debugLine="la.AddElement(a)";
_la._addelement(_a);
 //BA.debugLineNum = 113;BA.debugLine="If ShowArrows Then el.AddElement(la)";
if (_showarrows) { 
_el._addelement(_la);};
 //BA.debugLineNum = 115;BA.debugLine="Dim pCnt As Int";
_pcnt = 0;
 //BA.debugLineNum = 116;BA.debugLine="pTot = links.Size";
_ptot = _links.getSize();
 //BA.debugLineNum = 117;BA.debugLine="For pCnt = 1 To pTot";
{
final int step21 = 1;
final int limit21 = _ptot;
_pcnt = (int) (1) ;
for (;_pcnt <= limit21 ;_pcnt = _pcnt + step21 ) {
 //BA.debugLineNum = 118;BA.debugLine="pKey = $\"${ID}page${pCnt}\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"page"+__c.SmartStringFormatter("",(Object)(_pcnt))+"");
 //BA.debugLineNum = 119;BA.debugLine="Dim ep As UOEHTML";
_ep = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 120;BA.debugLine="ep.Initialize(\"\",\"li\")";
_ep._initialize(ba,"","li");
 //BA.debugLineNum = 121;BA.debugLine="ep.AddClass(\"waves-effect\")";
_ep._addclass("waves-effect");
 //BA.debugLineNum = 122;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 123;BA.debugLine="Dim href As String = \"#!\"";
_href = "#!";
 //BA.debugLineNum = 124;BA.debugLine="a.Initialize(pKey,\"a\")";
_a._initialize(ba,_pkey,"a");
 //BA.debugLineNum = 125;BA.debugLine="a.AddContent(pCnt)";
_a._addcontent(BA.NumberToString(_pcnt));
 //BA.debugLineNum = 126;BA.debugLine="Dim haspKey As Boolean = links.ContainsKey(pKey)";
_haspkey = _links.ContainsKey((Object)(_pkey));
 //BA.debugLineNum = 127;BA.debugLine="If haspKey Then";
if (_haspkey) { 
 //BA.debugLineNum = 128;BA.debugLine="href = links.GetDefault(pKey,\"#!\")";
_href = BA.ObjectToString(_links.GetDefault((Object)(_pkey),(Object)("#!")));
 //BA.debugLineNum = 129;BA.debugLine="a.SetHREF(href)";
_a._sethref(_href);
 }else {
 //BA.debugLineNum = 131;BA.debugLine="a.SetHREF(href)";
_a._sethref(_href);
 };
 //BA.debugLineNum = 134;BA.debugLine="Dim hasText As Boolean = texts.ContainsKey(pKey)";
_hastext = _texts.ContainsKey((Object)(_pkey));
 //BA.debugLineNum = 135;BA.debugLine="If hasText Then";
if (_hastext) { 
 //BA.debugLineNum = 136;BA.debugLine="Dim txt As String = texts.Get(pKey)";
_txt = BA.ObjectToString(_texts.Get((Object)(_pkey)));
 //BA.debugLineNum = 137;BA.debugLine="a.MaterialSetToolTip(\"bottom\",\"300\",txt)";
_a._materialsettooltip("bottom","300",_txt);
 };
 //BA.debugLineNum = 139;BA.debugLine="ep.AddElement(a)";
_ep._addelement(_a);
 //BA.debugLineNum = 140;BA.debugLine="If ActivePageNumber = pCnt Then";
if (_activepagenumber==_pcnt) { 
 //BA.debugLineNum = 141;BA.debugLine="ep.AddClass(\"active\")";
_ep._addclass("active");
 };
 //BA.debugLineNum = 143;BA.debugLine="el.AddElement(ep)";
_el._addelement(_ep);
 }
};
 //BA.debugLineNum = 147;BA.debugLine="Dim ra As UOEHTML";
_ra = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 148;BA.debugLine="pKey = $\"${ID}pagelast\"$";
_pkey = (""+__c.SmartStringFormatter("",(Object)(_id))+"pagelast");
 //BA.debugLineNum = 149;BA.debugLine="ra.Initialize(ID & \"last\",\"li\")";
_ra._initialize(ba,_id+"last","li");
 //BA.debugLineNum = 151;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 152;BA.debugLine="a.Initialize(pKey,\"a\")";
_a._initialize(ba,_pkey,"a");
 //BA.debugLineNum = 153;BA.debugLine="a.SetHREF(\"#!\")";
_a._sethref("#!");
 //BA.debugLineNum = 155;BA.debugLine="Dim i As UOEHTML";
_i = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 156;BA.debugLine="i.Initialize(\"\",\"i\")";
_i._initialize(ba,"","i");
 //BA.debugLineNum = 157;BA.debugLine="i.AddClass(\"waves-effect\")";
_i._addclass("waves-effect");
 //BA.debugLineNum = 158;BA.debugLine="i.addclass(\"material-icons\")";
_i._addclass("material-icons");
 //BA.debugLineNum = 159;BA.debugLine="i.AddContent(\"chevron_right\")";
_i._addcontent("chevron_right");
 //BA.debugLineNum = 161;BA.debugLine="a.AddElement(i)";
_a._addelement(_i);
 //BA.debugLineNum = 162;BA.debugLine="ra.AddElement(a)";
_ra._addelement(_a);
 //BA.debugLineNum = 164;BA.debugLine="If ShowArrows Then";
if (_showarrows) { 
 //BA.debugLineNum = 165;BA.debugLine="el.AddElement(ra)";
_el._addelement(_ra);
 };
 //BA.debugLineNum = 171;BA.debugLine="Return el.html";
if (true) return _el._html();
 //BA.debugLineNum = 172;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
