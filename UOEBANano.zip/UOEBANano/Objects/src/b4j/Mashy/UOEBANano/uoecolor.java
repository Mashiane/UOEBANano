package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecolor extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecolor", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecolor.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _amber = "";
public String _black = "";
public String _blue = "";
public String _bluegrey = "";
public String _brown = "";
public String _cyan = "";
public String _deeporange = "";
public String _deeppurple = "";
public String _green = "";
public String _grey = "";
public String _indigo = "";
public String _lightblue = "";
public String _lightgreen = "";
public String _lime = "";
public String _orange = "";
public String _pink = "";
public String _purple = "";
public String _red = "";
public String _teal = "";
public String _transparent = "";
public String _white = "";
public String _normal = "";
public String _yellow = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public AMBER As String = \"amber\"";
_amber = "amber";
 //BA.debugLineNum = 6;BA.debugLine="Public BLACK As String = \"black\"";
_black = "black";
 //BA.debugLineNum = 7;BA.debugLine="Public BLUE As String = \"blue\"";
_blue = "blue";
 //BA.debugLineNum = 8;BA.debugLine="Public BLUEGREY As String = \"blue-grey\"";
_bluegrey = "blue-grey";
 //BA.debugLineNum = 9;BA.debugLine="Public BROWN As String = \"brown\"";
_brown = "brown";
 //BA.debugLineNum = 10;BA.debugLine="Public CYAN As String = \"cyan\"";
_cyan = "cyan";
 //BA.debugLineNum = 11;BA.debugLine="Public DEEPORANGE As String = \"deep-orange\"";
_deeporange = "deep-orange";
 //BA.debugLineNum = 12;BA.debugLine="Public DEEPPURPLE As String = \"deep-purple\"";
_deeppurple = "deep-purple";
 //BA.debugLineNum = 13;BA.debugLine="Public GREEN As String = \"green\"";
_green = "green";
 //BA.debugLineNum = 14;BA.debugLine="Public GREY As String = \"grey\"";
_grey = "grey";
 //BA.debugLineNum = 15;BA.debugLine="Public INDIGO As String = \"indigo\"";
_indigo = "indigo";
 //BA.debugLineNum = 16;BA.debugLine="Public LIGHTBLUE As String = \"light-blue\"";
_lightblue = "light-blue";
 //BA.debugLineNum = 17;BA.debugLine="Public LIGHTGREEN As String = \"light-green\"";
_lightgreen = "light-green";
 //BA.debugLineNum = 18;BA.debugLine="Public LIME As String = \"lime\"";
_lime = "lime";
 //BA.debugLineNum = 19;BA.debugLine="Public ORANGE As String = \"orange\"";
_orange = "orange";
 //BA.debugLineNum = 20;BA.debugLine="Public PINK As String = \"pink\"";
_pink = "pink";
 //BA.debugLineNum = 21;BA.debugLine="Public PURPLE As String = \"purple\"";
_purple = "purple";
 //BA.debugLineNum = 22;BA.debugLine="Public RED As String = \"red\"";
_red = "red";
 //BA.debugLineNum = 23;BA.debugLine="Public TEAL As String = \"teal\"";
_teal = "teal";
 //BA.debugLineNum = 24;BA.debugLine="Public TRANSPARENT As String = \"transparent\"";
_transparent = "transparent";
 //BA.debugLineNum = 25;BA.debugLine="Public WHITE As String = \"white\"";
_white = "white";
 //BA.debugLineNum = 26;BA.debugLine="Public NORMAL As String = \"\"";
_normal = "";
 //BA.debugLineNum = 27;BA.debugLine="Public YELLOW As String = \"yellow\"";
_yellow = "yellow";
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 30;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
