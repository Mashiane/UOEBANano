package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeslider extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeslider", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeslider.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _items = null;
public boolean _enabled = false;
public String _id = "";
public String _theme = "";
public String _visibility = "";
public String _zdepth = "";
public b4j.Mashy.UOEBANano.uoehtml _slides = null;
public boolean _indicators = false;
public String _height = "";
public String _transition = "";
public String _interval = "";
public boolean _hoverable = false;
public boolean _fullscreen = false;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeslider  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 42;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 43;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 44;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeslider)(this);
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeslider  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddClass(sClass As String) As UOESlider";
 //BA.debugLineNum = 31;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeslider)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public String  _addslide(String _slideid,String _imgurl,String _title,String _alignment,String _description,String _titletheme,String _descriptiontheme) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoeimage _img = null;
b4j.Mashy.UOEBANano.uoehtml _content = null;
b4j.Mashy.UOEBANano.uoehtml _h3 = null;
b4j.Mashy.UOEBANano.uoehtml _h5 = null;
 //BA.debugLineNum = 76;BA.debugLine="Sub AddSlide(slideID As String, imgURL As String,";
 //BA.debugLineNum = 78;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 79;BA.debugLine="li.Initialize(slideID,\"li\")";
_li._initialize(ba,_slideid,"li");
 //BA.debugLineNum = 81;BA.debugLine="Dim img As UOEImage";
_img = new b4j.Mashy.UOEBANano.uoeimage();
 //BA.debugLineNum = 82;BA.debugLine="img.Initialize(App,slideID & \"-img\",imgURL,\"\",Tru";
_img._initialize(ba,_app,_slideid+"-img",_imgurl,"",__c.True);
 //BA.debugLineNum = 85;BA.debugLine="img.Element.AddStyleAttribute(\"object-fit\",\"conta";
_img._element._addstyleattribute("object-fit","contain");
 //BA.debugLineNum = 86;BA.debugLine="li.AddContent(img.tostring)";
_li._addcontent(_img._tostring());
 //BA.debugLineNum = 88;BA.debugLine="Dim content As UOEHTML";
_content = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 89;BA.debugLine="content.Initialize(slideID & \"-content\",\"div\")";
_content._initialize(ba,_slideid+"-content","div");
 //BA.debugLineNum = 90;BA.debugLine="content.addclass(\"caption\")";
_content._addclass("caption");
 //BA.debugLineNum = 91;BA.debugLine="content.MaterialAlignText(Alignment)";
_content._materialaligntext(_alignment);
 //BA.debugLineNum = 93;BA.debugLine="Dim h3 As UOEHTML";
_h3 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 94;BA.debugLine="h3.Initialize(\"\",\"h3\")";
_h3._initialize(ba,"","h3");
 //BA.debugLineNum = 95;BA.debugLine="h3.AddContent(Title)";
_h3._addcontent(_title);
 //BA.debugLineNum = 96;BA.debugLine="App.MaterialUseTheme(titleTheme,h3)";
_app._materialusetheme(_titletheme,_h3);
 //BA.debugLineNum = 98;BA.debugLine="Dim h5 As UOEHTML";
_h5 = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 99;BA.debugLine="h5.Initialize(\"\",\"h5\")";
_h5._initialize(ba,"","h5");
 //BA.debugLineNum = 100;BA.debugLine="h5.AddContent(Description)";
_h5._addcontent(_description);
 //BA.debugLineNum = 101;BA.debugLine="App.MaterialUseTheme(descriptionTheme,h5)";
_app._materialusetheme(_descriptiontheme,_h5);
 //BA.debugLineNum = 103;BA.debugLine="content.AddContent(h3.HTML)";
_content._addcontent(_h3._html());
 //BA.debugLineNum = 104;BA.debugLine="content.AddContent(h5.HTML)";
_content._addcontent(_h5._html());
 //BA.debugLineNum = 107;BA.debugLine="li.AddContent(content.HTML)";
_li._addcontent(_content._html());
 //BA.debugLineNum = 108;BA.debugLine="Slides.addcontent(li.HTML)";
_slides._addcontent(_li._html());
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeslider  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 25;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeslider)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 6;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 7;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 8;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 11;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 12;BA.debugLine="Private Slides As UOEHTML";
_slides = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 13;BA.debugLine="Public Indicators As Boolean";
_indicators = false;
 //BA.debugLineNum = 14;BA.debugLine="Public Height As String";
_height = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Transition As String";
_transition = "";
 //BA.debugLineNum = 16;BA.debugLine="Public Interval As String";
_interval = "";
 //BA.debugLineNum = 17;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 18;BA.debugLine="Public FullScreen As Boolean";
_fullscreen = false;
 //BA.debugLineNum = 19;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _ms = null;
String _str = "";
 //BA.debugLineNum = 139;BA.debugLine="Sub GetSettings As String";
 //BA.debugLineNum = 140;BA.debugLine="Dim ms As Map";
_ms = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 141;BA.debugLine="ms.Initialize";
_ms.Initialize();
 //BA.debugLineNum = 142;BA.debugLine="ms.clear";
_ms.Clear();
 //BA.debugLineNum = 143;BA.debugLine="ms.Put(\"id\", ID)";
_ms.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 144;BA.debugLine="ms.Put(\"instance\", \"slider\")";
_ms.Put((Object)("instance"),(Object)("slider"));
 //BA.debugLineNum = 145;BA.debugLine="ms.put(\"indicators\", Indicators)";
_ms.Put((Object)("indicators"),(Object)(_indicators));
 //BA.debugLineNum = 146;BA.debugLine="ms.Put(\"height\", Height)";
_ms.Put((Object)("height"),(Object)(_height));
 //BA.debugLineNum = 147;BA.debugLine="ms.Put(\"transition\", Transition)";
_ms.Put((Object)("transition"),(Object)(_transition));
 //BA.debugLineNum = 148;BA.debugLine="ms.Put(\"interval\", Interval)";
_ms.Put((Object)("interval"),(Object)(_interval));
 //BA.debugLineNum = 149;BA.debugLine="Dim str As String = App.Map2Json(ms)";
_str = _app._map2json(_ms);
 //BA.debugLineNum = 150;BA.debugLine="Return str";
if (true) return _str;
 //BA.debugLineNum = 151;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _mvarid) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, mvarID As";
 //BA.debugLineNum = 56;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 57;BA.debugLine="ID = mvarID.tolowercase";
_id = _mvarid.toLowerCase();
 //BA.debugLineNum = 58;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 59;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 60;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 61;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 62;BA.debugLine="Indicators = True";
_indicators = __c.True;
 //BA.debugLineNum = 63;BA.debugLine="Transition = \"500\"";
_transition = "500";
 //BA.debugLineNum = 64;BA.debugLine="Height = \"400\"";
_height = "400";
 //BA.debugLineNum = 65;BA.debugLine="Interval = \"6000\"";
_interval = "6000";
 //BA.debugLineNum = 66;BA.debugLine="Theme = \"\"";
_theme = "";
 //BA.debugLineNum = 67;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 68;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 69;BA.debugLine="Slides.Initialize(ID & \"-slides\",\"ul\")";
_slides._initialize(ba,_id+"-slides","ul");
 //BA.debugLineNum = 70;BA.debugLine="Slides.addclass(\"slides\")";
_slides._addclass("slides");
 //BA.debugLineNum = 71;BA.debugLine="FullScreen = False";
_fullscreen = __c.False;
 //BA.debugLineNum = 72;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 73;BA.debugLine="End Sub";
return "";
}
public String  _nextslide() throws Exception{
String _script = "";
 //BA.debugLineNum = 154;BA.debugLine="Sub NextSlide() As String";
 //BA.debugLineNum = 155;BA.debugLine="Dim script As String = $\"${Instance}.next();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".next();");
 //BA.debugLineNum = 156;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 157;BA.debugLine="End Sub";
return "";
}
public String  _pause() throws Exception{
String _script = "";
 //BA.debugLineNum = 172;BA.debugLine="Sub Pause() As String";
 //BA.debugLineNum = 173;BA.debugLine="Dim script As String = $\"${Instance}.pause();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".pause();");
 //BA.debugLineNum = 174;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public String  _previousslide() throws Exception{
String _script = "";
 //BA.debugLineNum = 160;BA.debugLine="Sub PreviousSlide() As String";
 //BA.debugLineNum = 161;BA.debugLine="Dim script As String = $\"${Instance}.prev();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".prev();");
 //BA.debugLineNum = 162;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 163;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeslider  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub RemoveAttribute(attr As String) As UOESlider";
 //BA.debugLineNum = 49;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 50;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeslider)(this);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeslider  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub RemoveClass(sClass As String) As UOESlider";
 //BA.debugLineNum = 37;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 38;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeslider)(this);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return null;
}
public String  _start() throws Exception{
String _script = "";
 //BA.debugLineNum = 166;BA.debugLine="Sub Start() As String";
 //BA.debugLineNum = 167;BA.debugLine="Dim script As String = $\"${Instance}.start();\"$";
_script = (""+__c.SmartStringFormatter("",(Object)(_instance))+".start();");
 //BA.debugLineNum = 168;BA.debugLine="Return script";
if (true) return _script;
 //BA.debugLineNum = 169;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 112;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 113;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 114;BA.debugLine="Slides.ID = ID & \"-slides\"";
_slides._id = _id+"-slides";
 //BA.debugLineNum = 115;BA.debugLine="Element.AddClass(\"slider\")";
_element._addclass("slider");
 //BA.debugLineNum = 116;BA.debugLine="Element.AddClassOnCondition(FullScreen,\"fullscree";
_element._addclassoncondition(_fullscreen,"fullscreen");
 //BA.debugLineNum = 117;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 118;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 119;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 120;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 121;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 122;BA.debugLine="Element.AddContent(Slides.HTML)";
_element._addcontent(_slides._html());
 //BA.debugLineNum = 127;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 128;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
