package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;

public class moduoe extends Object{
public static moduoe mostCurrent = new moduoe();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.moduoe", null);
		ba.loadHtSubs(moduoe.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.Mashy.UOEBANano.moduoe", ba);
		}
	}
    public static Class<?> getObject() {
		return moduoe.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static com.ab.banano.BANano _banano = null;
public static anywheresoftware.b4a.objects.collections.Map _resources = null;
public static String  _addresource(String _sfile) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub AddResource(sFile As String)";
 //BA.debugLineNum = 54;BA.debugLine="Resources.Put(sFile,sFile)";
_resources.Put((Object)(_sfile),(Object)(_sfile));
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static b4j.Mashy.UOEBANano.uoehtml  _materialaddbadge(b4j.Mashy.UOEBANano.uoeapp _thisapp,b4j.Mashy.UOEBANano.uoehtml _element,String _stext,boolean _bnew,String _svisibility,boolean _bcircle,String _stheme,boolean _baddclass1) throws Exception{
b4j.Mashy.UOEBANano.uoebadge _badge = null;
 //BA.debugLineNum = 102;BA.debugLine="Sub MaterialAddBadge(thisApp As UOEApp, Element As";
 //BA.debugLineNum = 104;BA.debugLine="Dim badge As UOEBadge";
_badge = new b4j.Mashy.UOEBANano.uoebadge();
 //BA.debugLineNum = 105;BA.debugLine="badge.Initialize(thisApp,Element.id & \"-badge\",sT";
_badge._initialize(ba,_thisapp,_element._id+"-badge",_stext,_bnew,_stheme);
 //BA.debugLineNum = 106;BA.debugLine="badge.Circle = bCircle";
_badge._circle = _bcircle;
 //BA.debugLineNum = 107;BA.debugLine="badge.element.MaterialVisibility(sVisibility)";
_badge._element._materialvisibility(_svisibility);
 //BA.debugLineNum = 108;BA.debugLine="If bAddClass1 = True Then";
if (_baddclass1==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 109;BA.debugLine="badge.Element.AddClass(\"badge1\")";
_badge._element._addclass("badge1");
 //BA.debugLineNum = 110;BA.debugLine="badge.Element.RemoveClass(\"badge\")";
_badge._element._removeclass("badge");
 };
 //BA.debugLineNum = 112;BA.debugLine="Element.AddContent(badge.tostring)";
_element._addcontent(_badge._tostring());
 //BA.debugLineNum = 114;BA.debugLine="Return Element";
if (true) return _element;
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return null;
}
public static b4j.Mashy.UOEBANano.uoehtml  _materialaddicon(b4j.Mashy.UOEBANano.uoeapp _thisapp,b4j.Mashy.UOEBANano.uoehtml _element,String _iconname,String _iconpos,String _icontheme,boolean _iconcircle,boolean _bwave,boolean _bcursor,boolean _bprefix,boolean _bclose) throws Exception{
String _iconid = "";
b4j.Mashy.UOEBANano.uoeicon _icn = null;
 //BA.debugLineNum = 58;BA.debugLine="public Sub MaterialAddIcon(thisApp As UOEApp, Elem";
 //BA.debugLineNum = 60;BA.debugLine="Dim iconID As String = Element.ID & \"-icon\"";
_iconid = _element._id+"-icon";
 //BA.debugLineNum = 61;BA.debugLine="If Element.ClassExists(\"fixed-action-btn\") = True";
if (_element._classexists("fixed-action-btn")==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 62;BA.debugLine="IconCircle = True";
_iconcircle = anywheresoftware.b4a.keywords.Common.True;
 }else if(_element._classexists("halfway-fab")==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 64;BA.debugLine="IconCircle = True";
_iconcircle = anywheresoftware.b4a.keywords.Common.True;
 }else if(_element._classexists("btn-floating")==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 66;BA.debugLine="IconCircle = True";
_iconcircle = anywheresoftware.b4a.keywords.Common.True;
 };
 //BA.debugLineNum = 68;BA.debugLine="If IconName.Length > 0 Then";
if (_iconname.length()>0) { 
 //BA.debugLineNum = 69;BA.debugLine="Dim icn As UOEIcon";
_icn = new b4j.Mashy.UOEBANano.uoeicon();
 //BA.debugLineNum = 70;BA.debugLine="icn.Initialize(thisApp,iconID,IconName,IconTheme";
_icn._initialize(ba,_thisapp,_iconid,_iconname,_icontheme);
 //BA.debugLineNum = 71;BA.debugLine="icn.IconName = IconName";
_icn._iconname = _iconname;
 //BA.debugLineNum = 72;BA.debugLine="icn.Alignment = iconPos";
_icn._alignment = _iconpos;
 //BA.debugLineNum = 73;BA.debugLine="icn.AddCursor = bCursor";
_icn._addcursor = _bcursor;
 //BA.debugLineNum = 74;BA.debugLine="icn.Circle = IconCircle";
_icn._circle = _iconcircle;
 //BA.debugLineNum = 75;BA.debugLine="icn.WavesEffect = bWave";
_icn._waveseffect = _bwave;
 //BA.debugLineNum = 76;BA.debugLine="icn.Prefix = bPrefix";
_icn._prefix = _bprefix;
 //BA.debugLineNum = 77;BA.debugLine="icn.Theme = IconTheme";
_icn._theme = _icontheme;
 //BA.debugLineNum = 78;BA.debugLine="icn.Close = bClose";
_icn._close = _bclose;
 //BA.debugLineNum = 79;BA.debugLine="Element.AddContent(icn.tostring)";
_element._addcontent(_icn._tostring());
 };
 //BA.debugLineNum = 81;BA.debugLine="Return Element";
if (true) return _element;
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return null;
}
public static b4j.Mashy.UOEBANano.uoehtml  _materialaddimage(b4j.Mashy.UOEBANano.uoeapp _thisapp,b4j.Mashy.UOEBANano.uoehtml _element,String _imgurl,String _imgalt,String _imgheight,String _imgwidth,boolean _imgcircle,boolean _imgresponsive,boolean _imgstatic,String _topmargin) throws Exception{
b4j.Mashy.UOEBANano.uoeimage _img = null;
 //BA.debugLineNum = 86;BA.debugLine="public Sub MaterialAddImage(thisApp As UOEApp, Ele";
 //BA.debugLineNum = 87;BA.debugLine="If imgURL.Length > 0 Then";
if (_imgurl.length()>0) { 
 //BA.debugLineNum = 88;BA.debugLine="Dim img As UOEImage";
_img = new b4j.Mashy.UOEBANano.uoeimage();
 //BA.debugLineNum = 89;BA.debugLine="img.Initialize(thisApp,Element.ID & \"-img\",imgUR";
_img._initialize(ba,_thisapp,_element._id+"-img",_imgurl,_imgalt,_imgstatic);
 //BA.debugLineNum = 90;BA.debugLine="img.SetSize(imgHeight,imgWidth)";
_img._setsize(_imgheight,_imgwidth);
 //BA.debugLineNum = 91;BA.debugLine="img.Circle = imgCircle";
_img._circle = _imgcircle;
 //BA.debugLineNum = 92;BA.debugLine="img.SetMarginTop(topMargin)";
_img._setmargintop(_topmargin);
 //BA.debugLineNum = 93;BA.debugLine="img.Responsive = imgResponsive";
_img._responsive = _imgresponsive;
 //BA.debugLineNum = 94;BA.debugLine="img.Static = imgStatic";
_img._static = _imgstatic;
 //BA.debugLineNum = 95;BA.debugLine="Element.AddContent(img.tostring)";
_element._addcontent(_img._tostring());
 };
 //BA.debugLineNum = 97;BA.debugLine="Return Element";
if (true) return _element;
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return null;
}
public static String  _prepareresources() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub PrepareResources";
 //BA.debugLineNum = 8;BA.debugLine="Resources.Initialize";
_resources.Initialize();
 //BA.debugLineNum = 9;BA.debugLine="Resources.clear";
_resources.Clear();
 //BA.debugLineNum = 10;BA.debugLine="AddResource(\"materialfont.css\")";
_addresource("materialfont.css");
 //BA.debugLineNum = 11;BA.debugLine="AddResource(\"materialize.min.css\")";
_addresource("materialize.min.css");
 //BA.debugLineNum = 12;BA.debugLine="AddResource(\"preloader.css\")";
_addresource("preloader.css");
 //BA.debugLineNum = 13;BA.debugLine="AddResource(\"jquery-3.3.1.min.js\")";
_addresource("jquery-3.3.1.min.js");
 //BA.debugLineNum = 14;BA.debugLine="AddResource(\"jquery.timeago.min.js\")";
_addresource("jquery.timeago.min.js");
 //BA.debugLineNum = 15;BA.debugLine="AddResource(\"materialize.min.js\")";
_addresource("materialize.min.js");
 //BA.debugLineNum = 17;BA.debugLine="AddResource(\"all.min.css\")";
_addresource("all.min.css");
 //BA.debugLineNum = 18;BA.debugLine="AddResource(\"all.min.js\")";
_addresource("all.min.js");
 //BA.debugLineNum = 19;BA.debugLine="AddResource(\"nouislider.css\")";
_addresource("nouislider.css");
 //BA.debugLineNum = 20;BA.debugLine="AddResource(\"nouislider.min.js\")";
_addresource("nouislider.min.js");
 //BA.debugLineNum = 21;BA.debugLine="AddResource(\"jquery.sweet-modal.min.css\")";
_addresource("jquery.sweet-modal.min.css");
 //BA.debugLineNum = 22;BA.debugLine="AddResource(\"jquery.sweet-modal.min.js\")";
_addresource("jquery.sweet-modal.min.js");
 //BA.debugLineNum = 24;BA.debugLine="AddResource(\"Blob.min.js\")";
_addresource("Blob.min.js");
 //BA.debugLineNum = 25;BA.debugLine="AddResource(\"canvas-toBlob.js\")";
_addresource("canvas-toBlob.js");
 //BA.debugLineNum = 26;BA.debugLine="AddResource(\"dom-to-image.min.js\")";
_addresource("dom-to-image.min.js");
 //BA.debugLineNum = 27;BA.debugLine="AddResource(\"FileSaver.min.js\")";
_addresource("FileSaver.min.js");
 //BA.debugLineNum = 28;BA.debugLine="AddResource(\"printThis.js\")";
_addresource("printThis.js");
 //BA.debugLineNum = 30;BA.debugLine="AddResource(\"tableexport.min.css\")";
_addresource("tableexport.min.css");
 //BA.debugLineNum = 31;BA.debugLine="AddResource(\"xlsx.core.min.js\")";
_addresource("xlsx.core.min.js");
 //BA.debugLineNum = 32;BA.debugLine="AddResource(\"tableexport.min.js\")";
_addresource("tableexport.min.js");
 //BA.debugLineNum = 35;BA.debugLine="AddResource(\"jquery.toolbar.css\")";
_addresource("jquery.toolbar.css");
 //BA.debugLineNum = 36;BA.debugLine="AddResource(\"jquery.toolbar.min.js\")";
_addresource("jquery.toolbar.min.js");
 //BA.debugLineNum = 38;BA.debugLine="AddResource(\"billboard.min.css\")";
_addresource("billboard.min.css");
 //BA.debugLineNum = 39;BA.debugLine="AddResource(\"billboard.pkgd.min.js\")";
_addresource("billboard.pkgd.min.js");
 //BA.debugLineNum = 41;BA.debugLine="AddResource(\"tableHTMLExport.js\")";
_addresource("tableHTMLExport.js");
 //BA.debugLineNum = 43;BA.debugLine="AddResource(\"prism.css\")";
_addresource("prism.css");
 //BA.debugLineNum = 44;BA.debugLine="AddResource(\"prism-vs.css\")";
_addresource("prism-vs.css");
 //BA.debugLineNum = 45;BA.debugLine="AddResource(\"prism-line-numbers.css\")";
_addresource("prism-line-numbers.css");
 //BA.debugLineNum = 46;BA.debugLine="AddResource(\"prism.js\")";
_addresource("prism.js");
 //BA.debugLineNum = 47;BA.debugLine="AddResource(\"prism-line-numbers.js\")";
_addresource("prism-line-numbers.js");
 //BA.debugLineNum = 49;BA.debugLine="AddResource(\"billboard.min.css\")";
_addresource("billboard.min.css");
 //BA.debugLineNum = 50;BA.debugLine="AddResource(\"billboard.pkgd.min.js\")";
_addresource("billboard.pkgd.min.js");
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Public BANano As BANano 'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 4;BA.debugLine="Public Resources As Map";
_resources = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 5;BA.debugLine="End Sub";
return "";
}
}
