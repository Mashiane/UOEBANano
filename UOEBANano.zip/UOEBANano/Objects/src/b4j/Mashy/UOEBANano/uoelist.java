package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoelist extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoelist", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoelist.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _visibility = "";
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public boolean _order = false;
public anywheresoftware.b4a.objects.collections.List _items = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoelist  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 153;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 154;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 155;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Sub AddClass(sClass As String) As UOEList";
 //BA.debugLineNum = 141;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 142;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _adddivider(String _themename) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 130;BA.debugLine="Sub AddDivider(themeName As String) As UOEList";
 //BA.debugLineNum = 131;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 132;BA.debugLine="div.Initialize(\"\",\"li\")";
_div._initialize(ba,"","li");
 //BA.debugLineNum = 133;BA.debugLine="div.AddClass(\"divider\")";
_div._addclass("divider");
 //BA.debugLineNum = 134;BA.debugLine="App.MaterialUseTheme(themeName,div)";
_app._materialusetheme(_themename,_div);
 //BA.debugLineNum = 135;BA.debugLine="Items.Add(div.HTML)";
_items.Add((Object)(_div._html()));
 //BA.debugLineNum = 136;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 137;BA.debugLine="End Sub";
return null;
}
public String  _addimage(String _itemid,String _imgurl,boolean _imgcircle,String _imgheight,String _imgwidth,String _topmargin) throws Exception{
String _skey = "";
b4j.Mashy.UOEBANano.uoehtml _md = null;
 //BA.debugLineNum = 120;BA.debugLine="Sub AddImage(itemID As String, imgURL As String, i";
 //BA.debugLineNum = 121;BA.debugLine="itemID = itemID.tolowercase";
_itemid = _itemid.toLowerCase();
 //BA.debugLineNum = 122;BA.debugLine="Dim sKey As String = $\"${ID}${itemID}\"$";
_skey = (""+__c.SmartStringFormatter("",(Object)(_id))+""+__c.SmartStringFormatter("",(Object)(_itemid))+"");
 //BA.debugLineNum = 123;BA.debugLine="Dim md As UOEHTML";
_md = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 124;BA.debugLine="md.Initialize(sKey,\"li\")";
_md._initialize(ba,_skey,"li");
 //BA.debugLineNum = 125;BA.debugLine="modUOE.MaterialAddImage(App,md,imgURL,\"\",imgHeigh";
_moduoe._materialaddimage(_app,_md,_imgurl,"",_imgheight,_imgwidth,_imgcircle,__c.True,__c.True,_topmargin);
 //BA.debugLineNum = 126;BA.debugLine="Items.Add(md.HTML)";
_items.Add((Object)(_md._html()));
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return "";
}
public String  _additem(String _txtid,String _txttext,String _txttheme) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _p = null;
 //BA.debugLineNum = 108;BA.debugLine="Sub AddItem(txtID As String,txtText As String, txt";
 //BA.debugLineNum = 109;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 110;BA.debugLine="li.Initialize(ID & txtID,\"li\")";
_li._initialize(ba,_id+_txtid,"li");
 //BA.debugLineNum = 111;BA.debugLine="Dim p As UOEHTML";
_p = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 112;BA.debugLine="p.Initialize(txtID & \"-span\",\"span\")";
_p._initialize(ba,_txtid+"-span","span");
 //BA.debugLineNum = 113;BA.debugLine="p.AddContent(txtText)";
_p._addcontent(_txttext);
 //BA.debugLineNum = 114;BA.debugLine="App.MaterialUseTheme(txtTheme,p)";
_app._materialusetheme(_txttheme,_p);
 //BA.debugLineNum = 115;BA.debugLine="li.AddElement(p)";
_li._addelement(_p);
 //BA.debugLineNum = 116;BA.debugLine="Items.Add(li.HTML)";
_items.Add((Object)(_li._html()));
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _addlink(String _lnkid,String _lnktext,String _lnkhref,String _lnktheme,boolean _hasevent) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _li = null;
b4j.Mashy.UOEBANano.uoehtml _a = null;
 //BA.debugLineNum = 92;BA.debugLine="Sub AddLink(lnkID As String,lnkText As String,lnkH";
 //BA.debugLineNum = 93;BA.debugLine="Dim li As UOEHTML";
_li = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 94;BA.debugLine="li.Initialize(ID & lnkID,\"li\")";
_li._initialize(ba,_id+_lnkid,"li");
 //BA.debugLineNum = 95;BA.debugLine="Dim a As UOEHTML";
_a = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 96;BA.debugLine="a.Initialize(lnkID,\"a\")";
_a._initialize(ba,_lnkid,"a");
 //BA.debugLineNum = 97;BA.debugLine="a.SetHREF(lnkHREF)";
_a._sethref(_lnkhref);
 //BA.debugLineNum = 98;BA.debugLine="a.AddContent(lnkText)";
_a._addcontent(_lnktext);
 //BA.debugLineNum = 99;BA.debugLine="App.MaterialUseTheme(lnkTheme,a)";
_app._materialusetheme(_lnktheme,_a);
 //BA.debugLineNum = 100;BA.debugLine="li.AddElement(a)";
_li._addelement(_a);
 //BA.debugLineNum = 101;BA.debugLine="Items.Add(li.HTML)";
_items.Add((Object)(_li._html()));
 //BA.debugLineNum = 102;BA.debugLine="If hasEvent = true Then";
if (_hasevent==__c.True) { 
 //BA.debugLineNum = 103;BA.debugLine="App.AddEvent(lnkID,\"click\")";
_app._addevent(_lnkid,"click");
 };
 //BA.debugLineNum = 105;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoelist  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 14;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 15;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 16;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _ascircles() throws Exception{
 //BA.debugLineNum = 20;BA.debugLine="Sub AsCircles As UOEList";
 //BA.debugLineNum = 21;BA.debugLine="Element.SetListStyleCircle";
_element._setliststylecircle();
 //BA.debugLineNum = 22;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 23;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _asdisk() throws Exception{
 //BA.debugLineNum = 26;BA.debugLine="Sub AsDisk As UOEList";
 //BA.debugLineNum = 27;BA.debugLine="Element.SetListStyleDisk";
_element._setliststyledisk();
 //BA.debugLineNum = 28;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _asnone() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Sub AsNone As UOEList";
 //BA.debugLineNum = 33;BA.debugLine="Element.SetListStyleNone";
_element._setliststylenone();
 //BA.debugLineNum = 34;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _assquare() throws Exception{
 //BA.debugLineNum = 38;BA.debugLine="Sub AsSquare As UOEList";
 //BA.debugLineNum = 39;BA.debugLine="Element.SetListStyleSquare";
_element._setliststylesquare();
 //BA.debugLineNum = 40;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 7;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 8;BA.debugLine="Private Order As Boolean";
_order = false;
 //BA.debugLineNum = 9;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,boolean _border,boolean _binline) throws Exception{
innerInitialize(_ba);
anywheresoftware.b4a.objects.collections.Map _css = null;
String _str = "";
 //BA.debugLineNum = 69;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 70;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 71;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 72;BA.debugLine="Visibility= \"\"";
_visibility = "";
 //BA.debugLineNum = 73;BA.debugLine="Order = bOrder";
_order = _border;
 //BA.debugLineNum = 74;BA.debugLine="Element.Initialize(sid,\"ul\")";
_element._initialize(ba,_sid,"ul");
 //BA.debugLineNum = 75;BA.debugLine="If Order Then";
if (_order) { 
 //BA.debugLineNum = 76;BA.debugLine="Element.settag(\"ol\")";
_element._settag("ol");
 };
 //BA.debugLineNum = 78;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 79;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 80;BA.debugLine="If bInline Then";
if (_binline) { 
 //BA.debugLineNum = 81;BA.debugLine="Dim css As Map";
_css = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 82;BA.debugLine="css.Initialize";
_css.Initialize();
 //BA.debugLineNum = 83;BA.debugLine="css.clear";
_css.Clear();
 //BA.debugLineNum = 84;BA.debugLine="css.Put(\"id\", $\"#${ID} li\"$)";
_css.Put((Object)("id"),(Object)(("#"+__c.SmartStringFormatter("",(Object)(_id))+" li")));
 //BA.debugLineNum = 85;BA.debugLine="css.put(\"display\", \"inline\")";
_css.Put((Object)("display"),(Object)("inline"));
 //BA.debugLineNum = 86;BA.debugLine="Dim str As String = App.Map2Json(css)";
_str = _app._map2json(_css);
 //BA.debugLineNum = 87;BA.debugLine="App.CSS.Add(str)";
_app._css.Add((Object)(_str));
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoelist  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 158;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEList";
 //BA.debugLineNum = 159;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 160;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 161;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 146;BA.debugLine="Sub RemoveClass(sClass As String) As UOEList";
 //BA.debugLineNum = 147;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 148;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _showlowercase() throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub ShowLowerCase As UOEList";
 //BA.debugLineNum = 54;BA.debugLine="Element.SetTypeLowerCase";
_element._settypelowercase();
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _showlowercaseroman() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub ShowLowerCaseRoman As UOEList";
 //BA.debugLineNum = 64;BA.debugLine="Element.SetTypeLowerCaseRoman";
_element._settypelowercaseroman();
 //BA.debugLineNum = 65;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _shownumbers() throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub ShowNumbers As UOEList";
 //BA.debugLineNum = 44;BA.debugLine="Element.SetTypeNumbers";
_element._settypenumbers();
 //BA.debugLineNum = 45;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _showuppercase() throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Sub ShowUpperCase As UOEList";
 //BA.debugLineNum = 49;BA.debugLine="Element.SetTypeUpperCase";
_element._settypeuppercase();
 //BA.debugLineNum = 50;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoelist  _showuppercaseroman() throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub ShowUpperCaseRoman As UOEList";
 //BA.debugLineNum = 59;BA.debugLine="Element.SetTypeUpperCaseRoman";
_element._settypeuppercaseroman();
 //BA.debugLineNum = 60;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoelist)(this);
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 164;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 165;BA.debugLine="Element.AddContentList(Items)";
_element._addcontentlist(_items);
 //BA.debugLineNum = 166;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 167;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 168;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 174;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 175;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
