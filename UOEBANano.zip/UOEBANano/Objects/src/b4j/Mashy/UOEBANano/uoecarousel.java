package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecarousel extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecarousel", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecarousel.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _id = "";
public String _theme = "";
public String _visibility = "";
public String _zdepth = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public anywheresoftware.b4a.objects.collections.List _items = null;
public boolean _isslider = false;
public int _duration = 0;
public int _dist = 0;
public int _shift = 0;
public int _padding = 0;
public boolean _fullwidth = false;
public boolean _indicators = false;
public boolean _nowrap = false;
public boolean _center = false;
public boolean _hoverable = false;
public int _interval = 0;
public int _numvisible = 0;
public String _instance = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoecarousel  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 47;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 48;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 49;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _addcarouselfixeditem() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _fi = null;
 //BA.debugLineNum = 85;BA.debugLine="Sub AddCarouselFixedItem As UOECarousel";
 //BA.debugLineNum = 86;BA.debugLine="Dim fi As UOEHTML";
_fi = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 87;BA.debugLine="fi.Initialize(\"\",\"div\")";
_fi._initialize(ba,"","div");
 //BA.debugLineNum = 88;BA.debugLine="fi.AddClass(\"carousel-fixed-item\")";
_fi._addclass("carousel-fixed-item");
 //BA.debugLineNum = 89;BA.debugLine="fi.AddClass(\"center\")";
_fi._addclass("center");
 //BA.debugLineNum = 90;BA.debugLine="Items.Add(fi.HTML)";
_items.Add((Object)(_fi._html()));
 //BA.debugLineNum = 91;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 35;BA.debugLine="Sub AddClass(sClass As String) As UOECarousel";
 //BA.debugLineNum = 36;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 37;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 38;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _addcontainer(b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 105;BA.debugLine="Sub AddContainer(cont As UOEContainer) As UOECarou";
 //BA.debugLineNum = 106;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 107;BA.debugLine="div.Initialize(cont.id & \"-parent\",\"div\")";
_div._initialize(ba,_cont._id+"-parent","div");
 //BA.debugLineNum = 108;BA.debugLine="div.AddClass(\"carousel-item\")";
_div._addclass("carousel-item");
 //BA.debugLineNum = 109;BA.debugLine="div.AddCursor";
_div._addcursor();
 //BA.debugLineNum = 110;BA.debugLine="If cont <> Null Then";
if (_cont!= null) { 
 //BA.debugLineNum = 111;BA.debugLine="div.AddContent(cont.tostring)";
_div._addcontent(_cont._tostring());
 };
 //BA.debugLineNum = 113;BA.debugLine="Items.Add(div.HTML)";
_items.Add((Object)(_div._html()));
 //BA.debugLineNum = 114;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _additem(String _itemid,String _itemhtml) throws Exception{
b4j.Mashy.UOEBANano.uoehtml _div = null;
 //BA.debugLineNum = 95;BA.debugLine="Sub AddItem(itemid As String, itemHTML As String)";
 //BA.debugLineNum = 96;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 97;BA.debugLine="div.Initialize(itemid,\"div\")";
_div._initialize(ba,_itemid,"div");
 //BA.debugLineNum = 98;BA.debugLine="div.AddClass(\"carousel-item\")";
_div._addclass("carousel-item");
 //BA.debugLineNum = 99;BA.debugLine="div.AddContent(itemHTML)";
_div._addcontent(_itemhtml);
 //BA.debugLineNum = 100;BA.debugLine="Items.Add(div.HTML)";
_items.Add((Object)(_div._html()));
 //BA.debugLineNum = 101;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _addslide(String _itemid,String _href,String _imgurl) throws Exception{
b4j.Mashy.UOEBANano.uoeanchor _slideitem = null;
 //BA.debugLineNum = 118;BA.debugLine="Sub AddSlide(itemID As String, href As String, img";
 //BA.debugLineNum = 119;BA.debugLine="Dim slideItem As UOEAnchor";
_slideitem = new b4j.Mashy.UOEBANano.uoeanchor();
 //BA.debugLineNum = 120;BA.debugLine="slideItem.Initialize(App,itemID)";
_slideitem._initialize(ba,_app,_itemid);
 //BA.debugLineNum = 121;BA.debugLine="slideItem.AddClass(\"carousel-item\")";
_slideitem._addclass("carousel-item");
 //BA.debugLineNum = 122;BA.debugLine="slideItem.HREF = href";
_slideitem._href = _href;
 //BA.debugLineNum = 123;BA.debugLine="modUOE.MaterialAddImage(App,slideItem.element,img";
_moduoe._materialaddimage(_app,_slideitem._element,_imgurl,"","","",__c.False,__c.True,__c.True,"");
 //BA.debugLineNum = 124;BA.debugLine="slideItem.WavesEffect = False";
_slideitem._waveseffect = __c.False;
 //BA.debugLineNum = 125;BA.debugLine="Items.Add(slideItem.ToString)";
_items.Add((Object)(_slideitem._tostring()));
 //BA.debugLineNum = 126;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 127;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 30;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 31;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Banano As BANano";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 8;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 10;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 11;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 12;BA.debugLine="Private Items As List";
_items = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 13;BA.debugLine="Public IsSlider As Boolean";
_isslider = false;
 //BA.debugLineNum = 14;BA.debugLine="Public Duration As Int";
_duration = 0;
 //BA.debugLineNum = 15;BA.debugLine="Public Dist As Int";
_dist = 0;
 //BA.debugLineNum = 16;BA.debugLine="Public Shift As Int";
_shift = 0;
 //BA.debugLineNum = 17;BA.debugLine="Public Padding As Int";
_padding = 0;
 //BA.debugLineNum = 18;BA.debugLine="Public FullWidth As Boolean";
_fullwidth = false;
 //BA.debugLineNum = 19;BA.debugLine="Public Indicators As Boolean";
_indicators = false;
 //BA.debugLineNum = 20;BA.debugLine="Public NoWrap As Boolean";
_nowrap = false;
 //BA.debugLineNum = 21;BA.debugLine="Public Center As Boolean";
_center = false;
 //BA.debugLineNum = 22;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 23;BA.debugLine="Public Interval As Int";
_interval = 0;
 //BA.debugLineNum = 24;BA.debugLine="Public numVisible As Int";
_numvisible = 0;
 //BA.debugLineNum = 25;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public String  _getsettings() throws Exception{
anywheresoftware.b4a.objects.collections.Map _dpsettings = null;
String _strds = "";
 //BA.debugLineNum = 174;BA.debugLine="public Sub GetSettings As String";
 //BA.debugLineNum = 175;BA.debugLine="Dim dpSettings As Map";
_dpsettings = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 176;BA.debugLine="dpSettings.Initialize";
_dpsettings.Initialize();
 //BA.debugLineNum = 177;BA.debugLine="dpSettings.clear";
_dpsettings.Clear();
 //BA.debugLineNum = 178;BA.debugLine="dpSettings.Put(\"id\", ID)";
_dpsettings.Put((Object)("id"),(Object)(_id));
 //BA.debugLineNum = 179;BA.debugLine="dpSettings.Put(\"instance\", \"carousel\")";
_dpsettings.Put((Object)("instance"),(Object)("carousel"));
 //BA.debugLineNum = 180;BA.debugLine="dpSettings.Put(\"fullwidth\", FullWidth)";
_dpsettings.Put((Object)("fullwidth"),(Object)(_fullwidth));
 //BA.debugLineNum = 181;BA.debugLine="dpSettings.Put(\"duration\", Duration)";
_dpsettings.Put((Object)("duration"),(Object)(_duration));
 //BA.debugLineNum = 182;BA.debugLine="dpSettings.Put(\"numVisible\", numVisible)";
_dpsettings.Put((Object)("numVisible"),(Object)(_numvisible));
 //BA.debugLineNum = 183;BA.debugLine="dpSettings.Put(\"dist\", Dist)";
_dpsettings.Put((Object)("dist"),(Object)(_dist));
 //BA.debugLineNum = 184;BA.debugLine="dpSettings.Put(\"shift\", Shift)";
_dpsettings.Put((Object)("shift"),(Object)(_shift));
 //BA.debugLineNum = 185;BA.debugLine="dpSettings.Put(\"padding\", Padding)";
_dpsettings.Put((Object)("padding"),(Object)(_padding));
 //BA.debugLineNum = 186;BA.debugLine="dpSettings.Put(\"indicators\", Indicators)";
_dpsettings.Put((Object)("indicators"),(Object)(_indicators));
 //BA.debugLineNum = 187;BA.debugLine="dpSettings.Put(\"nowrap\", NoWrap)";
_dpsettings.Put((Object)("nowrap"),(Object)(_nowrap));
 //BA.debugLineNum = 188;BA.debugLine="Dim strDS As String = App.Map2JSON(dpSettings)";
_strds = _app._map2json(_dpsettings);
 //BA.debugLineNum = 189;BA.debugLine="Return strDS";
if (true) return _strds;
 //BA.debugLineNum = 190;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _mvarid) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 59;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, mvarID As";
 //BA.debugLineNum = 61;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 62;BA.debugLine="ID = mvarID.tolowercase";
_id = _mvarid.toLowerCase();
 //BA.debugLineNum = 63;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 64;BA.debugLine="Theme = \"\"";
_theme = "";
 //BA.debugLineNum = 65;BA.debugLine="Center = False";
_center = __c.False;
 //BA.debugLineNum = 66;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 67;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 68;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 69;BA.debugLine="Items.Initialize";
_items.Initialize();
 //BA.debugLineNum = 70;BA.debugLine="Items.clear";
_items.Clear();
 //BA.debugLineNum = 71;BA.debugLine="IsSlider = False";
_isslider = __c.False;
 //BA.debugLineNum = 72;BA.debugLine="Duration = 200";
_duration = (int) (200);
 //BA.debugLineNum = 73;BA.debugLine="Dist = -100";
_dist = (int) (-100);
 //BA.debugLineNum = 74;BA.debugLine="Shift = 0";
_shift = (int) (0);
 //BA.debugLineNum = 75;BA.debugLine="Padding = 0";
_padding = (int) (0);
 //BA.debugLineNum = 76;BA.debugLine="FullWidth = True";
_fullwidth = __c.True;
 //BA.debugLineNum = 77;BA.debugLine="Indicators = True";
_indicators = __c.True;
 //BA.debugLineNum = 78;BA.debugLine="NoWrap = False";
_nowrap = __c.False;
 //BA.debugLineNum = 79;BA.debugLine="Interval = 2000";
_interval = (int) (2000);
 //BA.debugLineNum = 80;BA.debugLine="numVisible = 5";
_numvisible = (int) (5);
 //BA.debugLineNum = 81;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _nextslide() throws Exception{
String _script = "";
 //BA.debugLineNum = 151;BA.debugLine="Sub NextSlide()";
 //BA.debugLineNum = 152;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Carousel.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".next();");
 //BA.debugLineNum = 155;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 156;BA.debugLine="End Sub";
return "";
}
public String  _previousslide() throws Exception{
String _script = "";
 //BA.debugLineNum = 159;BA.debugLine="Sub PreviousSlide()";
 //BA.debugLineNum = 160;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Carousel.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".prev();");
 //BA.debugLineNum = 163;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoecarousel  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub RemoveAttribute(attr As String) As UOECarousel";
 //BA.debugLineNum = 54;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoecarousel  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 41;BA.debugLine="Sub RemoveClass(sClass As String) As UOECarousel";
 //BA.debugLineNum = 42;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 43;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoecarousel)(this);
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return null;
}
public String  _setslide(int _slidepos) throws Exception{
String _script = "";
 //BA.debugLineNum = 167;BA.debugLine="Sub SetSlide(slidePos As Int)";
 //BA.debugLineNum = 168;BA.debugLine="Dim script As String = $\"var inst${ID} = document";
_script = ("var inst"+__c.SmartStringFormatter("",(Object)(_id))+" = document.getElementById('"+__c.SmartStringFormatter("",(Object)(_id))+"');\n"+"	var "+__c.SmartStringFormatter("",(Object)(_instance))+" = M.Carousel.getInstance(inst"+__c.SmartStringFormatter("",(Object)(_id))+");\n"+"	"+__c.SmartStringFormatter("",(Object)(_instance))+".set("+__c.SmartStringFormatter("",(Object)(_slidepos))+");");
 //BA.debugLineNum = 171;BA.debugLine="Banano.Eval(script)";
_banano.Eval((Object)(_script));
 //BA.debugLineNum = 172;BA.debugLine="End Sub";
return "";
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 130;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 131;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 132;BA.debugLine="Element.AddClass(\"carousel\")";
_element._addclass("carousel");
 //BA.debugLineNum = 133;BA.debugLine="Element.AddClassOnCondition(IsSlider,\"carousel-sl";
_element._addclassoncondition(_isslider,"carousel-slider");
 //BA.debugLineNum = 134;BA.debugLine="Element.AddAttributeOnCondition(Indicators,\"data-";
_element._addattributeoncondition(_indicators,"data-indicators","true");
 //BA.debugLineNum = 135;BA.debugLine="Element.AddClassOnCondition(Center,\"center\")";
_element._addclassoncondition(_center,"center");
 //BA.debugLineNum = 136;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 137;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 138;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 139;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 140;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 141;BA.debugLine="Element.AddContentList(Items)";
_element._addcontentlist(_items);
 //BA.debugLineNum = 147;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
