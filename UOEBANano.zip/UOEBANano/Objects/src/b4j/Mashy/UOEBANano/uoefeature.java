package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoefeature extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoefeature", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoefeature.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public boolean _enabled = false;
public String _id = "";
public String _theme = "";
public String _visibility = "";
public String _zdepth = "";
public String _title = "";
public String _description = "";
public b4j.Mashy.UOEBANano.uoehtml _ttc = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoefeature  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 30;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 31;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 32;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefeature)(this);
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefeature  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub AddClass(sClass As String) As UOEFeature";
 //BA.debugLineNum = 19;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 20;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefeature)(this);
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefeature  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 44;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 45;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefeature)(this);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 6;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 7;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Title As String";
_title = "";
 //BA.debugLineNum = 12;BA.debugLine="Public Description As String";
_description = "";
 //BA.debugLineNum = 13;BA.debugLine="Private ttc As UOEHTML";
_ttc = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 14;BA.debugLine="End Sub";
return "";
}
public String  _close() throws Exception{
com.ab.banano.BANanoObject _f = null;
 //BA.debugLineNum = 97;BA.debugLine="Sub Close";
 //BA.debugLineNum = 98;BA.debugLine="Dim f As BANanoObject";
_f = new com.ab.banano.BANanoObject();
 //BA.debugLineNum = 99;BA.debugLine="f = App.JQ.Selector($\"#${ID}\"$)";
_f = _app._jq.Selector((Object)(("#"+__c.SmartStringFormatter("",(Object)(_id))+"")));
 //BA.debugLineNum = 100;BA.debugLine="f.RunMethod(\"tapTarget\", \"close\")";
_f.RunMethod("tapTarget",(Object)("close"));
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _mvarid,String _stitle,String _sdescription,String _sthemename,String _targetfab) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 50;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, mvarID As";
 //BA.debugLineNum = 51;BA.debugLine="targetFAB = targetFAB.tolowercase";
_targetfab = _targetfab.toLowerCase();
 //BA.debugLineNum = 53;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 54;BA.debugLine="ID = mvarID.tolowercase";
_id = _mvarid.toLowerCase();
 //BA.debugLineNum = 55;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 56;BA.debugLine="Element.AddClass(\"tap-target\")";
_element._addclass("tap-target");
 //BA.debugLineNum = 57;BA.debugLine="Element.AddAttribute(\"data-target\",targetFAB)";
_element._addattribute("data-target",_targetfab);
 //BA.debugLineNum = 58;BA.debugLine="ttc.Initialize(\"\",\"div\")";
_ttc._initialize(ba,"","div");
 //BA.debugLineNum = 59;BA.debugLine="ttc.AddClass(\"tap-target-content\")";
_ttc._addclass("tap-target-content");
 //BA.debugLineNum = 60;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 61;BA.debugLine="Theme = sThemeName";
_theme = _sthemename;
 //BA.debugLineNum = 62;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 63;BA.debugLine="ZDepth = \"\"";
_zdepth = "";
 //BA.debugLineNum = 64;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 65;BA.debugLine="Description = sDescription";
_description = _sdescription;
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _open() throws Exception{
com.ab.banano.BANanoObject _f = null;
 //BA.debugLineNum = 90;BA.debugLine="Sub Open";
 //BA.debugLineNum = 91;BA.debugLine="Dim f As BANanoObject";
_f = new com.ab.banano.BANanoObject();
 //BA.debugLineNum = 92;BA.debugLine="f = App.JQ.Selector($\"#${ID}\"$)";
_f = _app._jq.Selector((Object)(("#"+__c.SmartStringFormatter("",(Object)(_id))+"")));
 //BA.debugLineNum = 93;BA.debugLine="f.RunMethod(\"tapTarget\", \"open\")";
_f.RunMethod("tapTarget",(Object)("open"));
 //BA.debugLineNum = 94;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoefeature  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 36;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEFeature";
 //BA.debugLineNum = 37;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 38;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefeature)(this);
 //BA.debugLineNum = 39;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoefeature  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 24;BA.debugLine="Sub RemoveClass(sClass As String) As UOEFeature";
 //BA.debugLineNum = 25;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoefeature)(this);
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 69;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 71;BA.debugLine="ttc.AddHeading(5,Title)";
_ttc._addheading((int) (5),_title);
 //BA.debugLineNum = 72;BA.debugLine="ttc.AddParagraph(Description)";
_ttc._addparagraph(_description);
 //BA.debugLineNum = 73;BA.debugLine="App.MaterialUseTheme(Theme,ttc)";
_app._materialusetheme(_theme,_ttc);
 //BA.debugLineNum = 74;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 75;BA.debugLine="Element.sethref(\"\")";
_element._sethref("");
 //BA.debugLineNum = 76;BA.debugLine="App.MaterialUseTheme(Theme,Element)";
_app._materialusetheme(_theme,_element);
 //BA.debugLineNum = 77;BA.debugLine="Element.MaterialEnable(Enabled)";
_element._materialenable(_enabled);
 //BA.debugLineNum = 78;BA.debugLine="Element.MaterialZDepth(ZDepth)";
_element._materialzdepth(_zdepth);
 //BA.debugLineNum = 79;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 80;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 81;BA.debugLine="Element.AddElement(ttc)";
_element._addelement(_ttc);
 //BA.debugLineNum = 86;BA.debugLine="Return Element.HTML";
if (true) return _element._html();
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
