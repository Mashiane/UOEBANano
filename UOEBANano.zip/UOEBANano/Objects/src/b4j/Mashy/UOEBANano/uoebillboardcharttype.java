package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoebillboardcharttype extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoebillboardcharttype", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoebillboardcharttype.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public String _line = "";
public String _spline = "";
public String _areaspline = "";
public String _stepchart = "";
public String _bubble = "";
public String _area = "";
public String _areastep = "";
public String _arealinerange = "";
public String _areasplinerange = "";
public String _bar = "";
public String _pie = "";
public String _donut = "";
public String _gauge = "";
public String _groupedbar = "";
public String _horizontalbar = "";
public String _stackedbar = "";
public String _radar = "";
public String _scatter = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public line As String = \"line\"";
_line = "line";
 //BA.debugLineNum = 5;BA.debugLine="Public spline As String = \"spline\"";
_spline = "spline";
 //BA.debugLineNum = 6;BA.debugLine="Public areaspline As String = \"area-spline\"";
_areaspline = "area-spline";
 //BA.debugLineNum = 7;BA.debugLine="Public stepchart As String = \"step\"";
_stepchart = "step";
 //BA.debugLineNum = 8;BA.debugLine="Public bubble As String = \"bubble\"";
_bubble = "bubble";
 //BA.debugLineNum = 9;BA.debugLine="Public area As String = \"area\"";
_area = "area";
 //BA.debugLineNum = 10;BA.debugLine="Public areastep As String = \"area-step\"";
_areastep = "area-step";
 //BA.debugLineNum = 11;BA.debugLine="Public arealinerange As String = \"area-line-range";
_arealinerange = "area-line-range";
 //BA.debugLineNum = 12;BA.debugLine="Public areasplinerange As String = \"area-spline-r";
_areasplinerange = "area-spline-range";
 //BA.debugLineNum = 13;BA.debugLine="Public bar As String = \"bar\"";
_bar = "bar";
 //BA.debugLineNum = 14;BA.debugLine="Public pie As String = \"pie\"";
_pie = "pie";
 //BA.debugLineNum = 15;BA.debugLine="Public donut As String = \"donut\"";
_donut = "donut";
 //BA.debugLineNum = 16;BA.debugLine="Public gauge As String = \"gauge\"";
_gauge = "gauge";
 //BA.debugLineNum = 17;BA.debugLine="Public groupedbar As String = \"grouped-bar\"";
_groupedbar = "grouped-bar";
 //BA.debugLineNum = 18;BA.debugLine="Public horizontalbar As String = \"horizontalbar\"";
_horizontalbar = "horizontalbar";
 //BA.debugLineNum = 19;BA.debugLine="Public stackedbar As String = \"stackedbar\"";
_stackedbar = "stackedbar";
 //BA.debugLineNum = 20;BA.debugLine="Public radar As String = \"radar\"";
_radar = "radar";
 //BA.debugLineNum = 21;BA.debugLine="Public scatter As String = \"scatter\"";
_scatter = "scatter";
 //BA.debugLineNum = 22;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 24;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
