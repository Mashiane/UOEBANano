package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoecolumn extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoecolumn", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoecolumn.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public int _columns = 0;
public int _offsetsmall = 0;
public int _offsetmedium = 0;
public int _offsetlarge = 0;
public int _spansmall = 0;
public int _spanmedium = 0;
public int _spanlarge = 0;
public int _margintop = 0;
public int _marginbottom = 0;
public int _marginleft = 0;
public int _marginright = 0;
public int _paddingtop = 0;
public int _paddingbottom = 0;
public int _paddingleft = 0;
public int _paddingright = 0;
public String _theme = "";
public String _visibility = "";
public String _classname = "";
public int _row = 0;
public int _col = 0;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public Columns As Int";
_columns = 0;
 //BA.debugLineNum = 5;BA.debugLine="Public OffsetSmall As Int";
_offsetsmall = 0;
 //BA.debugLineNum = 6;BA.debugLine="Public OffsetMedium As Int";
_offsetmedium = 0;
 //BA.debugLineNum = 7;BA.debugLine="Public OffsetLarge As Int";
_offsetlarge = 0;
 //BA.debugLineNum = 8;BA.debugLine="Public SpanSmall As Int";
_spansmall = 0;
 //BA.debugLineNum = 9;BA.debugLine="Public SpanMedium As Int";
_spanmedium = 0;
 //BA.debugLineNum = 10;BA.debugLine="Public SpanLarge As Int";
_spanlarge = 0;
 //BA.debugLineNum = 11;BA.debugLine="Public MarginTop As Int";
_margintop = 0;
 //BA.debugLineNum = 12;BA.debugLine="Public MarginBottom As Int";
_marginbottom = 0;
 //BA.debugLineNum = 13;BA.debugLine="Public MarginLeft As Int";
_marginleft = 0;
 //BA.debugLineNum = 14;BA.debugLine="Public MarginRight As Int";
_marginright = 0;
 //BA.debugLineNum = 15;BA.debugLine="Public PaddingTop As Int";
_paddingtop = 0;
 //BA.debugLineNum = 16;BA.debugLine="Public PaddingBottom As Int";
_paddingbottom = 0;
 //BA.debugLineNum = 17;BA.debugLine="Public PaddingLeft As Int";
_paddingleft = 0;
 //BA.debugLineNum = 18;BA.debugLine="Public PaddingRight As Int";
_paddingright = 0;
 //BA.debugLineNum = 19;BA.debugLine="Public Theme As String";
_theme = "";
 //BA.debugLineNum = 20;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 21;BA.debugLine="Public ClassName As String";
_classname = "";
 //BA.debugLineNum = 22;BA.debugLine="Public Row As Int";
_row = 0;
 //BA.debugLineNum = 23;BA.debugLine="Public Col As Int";
_col = 0;
 //BA.debugLineNum = 24;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 26;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 27;BA.debugLine="Columns = 1";
_columns = (int) (1);
 //BA.debugLineNum = 28;BA.debugLine="OffsetSmall = 0";
_offsetsmall = (int) (0);
 //BA.debugLineNum = 29;BA.debugLine="OffsetMedium = 0";
_offsetmedium = (int) (0);
 //BA.debugLineNum = 30;BA.debugLine="OffsetLarge = 0";
_offsetlarge = (int) (0);
 //BA.debugLineNum = 31;BA.debugLine="SpanSmall = 12";
_spansmall = (int) (12);
 //BA.debugLineNum = 32;BA.debugLine="SpanMedium = 12";
_spanmedium = (int) (12);
 //BA.debugLineNum = 33;BA.debugLine="SpanLarge = 12";
_spanlarge = (int) (12);
 //BA.debugLineNum = 34;BA.debugLine="MarginTop = 0";
_margintop = (int) (0);
 //BA.debugLineNum = 35;BA.debugLine="MarginBottom = 0";
_marginbottom = (int) (0);
 //BA.debugLineNum = 36;BA.debugLine="MarginLeft = 0";
_marginleft = (int) (0);
 //BA.debugLineNum = 37;BA.debugLine="MarginRight = 0";
_marginright = (int) (0);
 //BA.debugLineNum = 38;BA.debugLine="PaddingTop = 0";
_paddingtop = (int) (0);
 //BA.debugLineNum = 39;BA.debugLine="PaddingBottom = 0";
_paddingbottom = (int) (0);
 //BA.debugLineNum = 40;BA.debugLine="PaddingRight = 0";
_paddingright = (int) (0);
 //BA.debugLineNum = 41;BA.debugLine="PaddingLeft = 0";
_paddingleft = (int) (0);
 //BA.debugLineNum = 42;BA.debugLine="Theme = \"\"";
_theme = "";
 //BA.debugLineNum = 43;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 44;BA.debugLine="ClassName = \"\"";
_classname = "";
 //BA.debugLineNum = 45;BA.debugLine="Row = 0";
_row = (int) (0);
 //BA.debugLineNum = 46;BA.debugLine="Col = 0";
_col = (int) (0);
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
