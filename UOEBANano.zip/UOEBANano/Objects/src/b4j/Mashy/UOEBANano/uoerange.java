package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoerange extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoerange", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoerange.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public float _minvalue = 0f;
public float _maxvalue = 0f;
public float _value = 0f;
public float _stepwith = 0f;
public b4j.Mashy.UOEBANano.uoehtml _range = null;
public boolean _hoverable = false;
public String _title = "";
public boolean _enabled = false;
public String _visibility = "";
public String _zdepth = "";
public String _theme = "";
public boolean _showtitle = false;
public b4j.Mashy.UOEBANano.uoehtml _container = null;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoerange  _addattribute(String _attr,String _svalue) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub AddAttribute(attr As String, sValue As String)";
 //BA.debugLineNum = 66;BA.debugLine="range.AddAttribute(attr,sValue)";
_range._addattribute(_attr,_svalue);
 //BA.debugLineNum = 67;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerange)(this);
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerange  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 53;BA.debugLine="Sub AddClass(sClass As String) As UOERange";
 //BA.debugLineNum = 54;BA.debugLine="range.AddClass(sClass)";
_range._addclass(_sclass);
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerange)(this);
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerange  _addstyleattribute(String _attribute,String _svalue) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub AddStyleAttribute(attribute As String, sValue";
 //BA.debugLineNum = 24;BA.debugLine="range.AddStyleAttribute(attribute,sValue)";
_range._addstyleattribute(_attribute,_svalue);
 //BA.debugLineNum = 25;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerange)(this);
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private MinValue As Float";
_minvalue = 0f;
 //BA.debugLineNum = 7;BA.debugLine="Private MaxValue As Float";
_maxvalue = 0f;
 //BA.debugLineNum = 8;BA.debugLine="Public Value As Float";
_value = 0f;
 //BA.debugLineNum = 9;BA.debugLine="Public StepWith As Float";
_stepwith = 0f;
 //BA.debugLineNum = 10;BA.debugLine="Private range As UOEHTML";
_range = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 11;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 12;BA.debugLine="Private Title As String";
_title = "";
 //BA.debugLineNum = 13;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 14;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 15;BA.debugLine="Public ZDepth As String";
_zdepth = "";
 //BA.debugLineNum = 16;BA.debugLine="Public Hoverable As Boolean";
_hoverable = false;
 //BA.debugLineNum = 17;BA.debugLine="Private Theme As String";
_theme = "";
 //BA.debugLineNum = 18;BA.debugLine="Public ShowTitle As Boolean";
_showtitle = false;
 //BA.debugLineNum = 19;BA.debugLine="Public Container As UOEHTML";
_container = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _stitle,float _sminvalue,float _smaxvalue,float _svalue,float _sstep,String _themename) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 29;BA.debugLine="Public Sub Initialize(thisApp As UOEApp,sid As Str";
 //BA.debugLineNum = 31;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 32;BA.debugLine="ID = sid.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 33;BA.debugLine="MaxValue = sMaxValue";
_maxvalue = _smaxvalue;
 //BA.debugLineNum = 34;BA.debugLine="MinValue = sMinValue";
_minvalue = _sminvalue;
 //BA.debugLineNum = 35;BA.debugLine="Value = sValue";
_value = _svalue;
 //BA.debugLineNum = 36;BA.debugLine="Title = sTitle";
_title = _stitle;
 //BA.debugLineNum = 37;BA.debugLine="StepWith = sStep";
_stepwith = _sstep;
 //BA.debugLineNum = 38;BA.debugLine="range.Initialize(ID & \"-inp\",\"input\")";
_range._initialize(ba,_id+"-inp","input");
 //BA.debugLineNum = 39;BA.debugLine="range.AddAttribute(\"min\",MinValue)";
_range._addattribute("min",BA.NumberToString(_minvalue));
 //BA.debugLineNum = 40;BA.debugLine="range.AddAttribute(\"max\",MaxValue)";
_range._addattribute("max",BA.NumberToString(_maxvalue));
 //BA.debugLineNum = 41;BA.debugLine="range.AddAttribute(\"type\",\"range\")";
_range._addattribute("type","range");
 //BA.debugLineNum = 42;BA.debugLine="range.AddAttribute(\"step\",StepWith)";
_range._addattribute("step",BA.NumberToString(_stepwith));
 //BA.debugLineNum = 43;BA.debugLine="range.SetNAME(ID).setvalue(sValue)";
_range._setname(_id)._setvalue(BA.NumberToString(_svalue));
 //BA.debugLineNum = 44;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 45;BA.debugLine="Visibility = \"\"";
_visibility = "";
 //BA.debugLineNum = 46;BA.debugLine="Theme = themeName";
_theme = _themename;
 //BA.debugLineNum = 47;BA.debugLine="ShowTitle = True";
_showtitle = __c.True;
 //BA.debugLineNum = 48;BA.debugLine="Container.Initialize(ID,\"p\")";
_container._initialize(ba,_id,"p");
 //BA.debugLineNum = 49;BA.debugLine="Container.AddClass(\"range-field\")";
_container._addclass("range-field");
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoerange  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 71;BA.debugLine="Sub RemoveAttribute(attr As String) As UOERange";
 //BA.debugLineNum = 72;BA.debugLine="range.RemoveAttribute(attr)";
_range._removeattribute(_attr);
 //BA.debugLineNum = 73;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerange)(this);
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoerange  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Sub RemoveClass(sClass As String) As UOERange";
 //BA.debugLineNum = 60;BA.debugLine="range.RemoveClass(sClass)";
_range._removeclass(_sclass);
 //BA.debugLineNum = 61;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoerange)(this);
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
b4j.Mashy.UOEBANano.uoehtml _lbl = null;
 //BA.debugLineNum = 77;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 78;BA.debugLine="range.MaterialEnable(Enabled)";
_range._materialenable(_enabled);
 //BA.debugLineNum = 79;BA.debugLine="range.MaterialZDepth(ZDepth)";
_range._materialzdepth(_zdepth);
 //BA.debugLineNum = 80;BA.debugLine="range.MaterialVisibility(Visibility)";
_range._materialvisibility(_visibility);
 //BA.debugLineNum = 81;BA.debugLine="App.ApplyToolTip(ID,range)";
_app._applytooltip(_id,_range);
 //BA.debugLineNum = 82;BA.debugLine="If ShowTitle = True Then";
if (_showtitle==__c.True) { 
 //BA.debugLineNum = 83;BA.debugLine="Dim lbl As UOEHTML";
_lbl = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 84;BA.debugLine="lbl.Initialize(ID & \"-lbl\",\"label\")";
_lbl._initialize(ba,_id+"-lbl","label");
 //BA.debugLineNum = 85;BA.debugLine="lbl.SetFOR(ID)";
_lbl._setfor(_id);
 //BA.debugLineNum = 86;BA.debugLine="lbl.AddContent(Title)";
_lbl._addcontent(_title);
 //BA.debugLineNum = 87;BA.debugLine="App.MaterialUseTheme(Theme,lbl)";
_app._materialusetheme(_theme,_lbl);
 //BA.debugLineNum = 88;BA.debugLine="Container.AddElement(lbl)";
_container._addelement(_lbl);
 };
 //BA.debugLineNum = 90;BA.debugLine="Container.AddContent(range.HTML)";
_container._addcontent(_range._html());
 //BA.debugLineNum = 95;BA.debugLine="Return Container.html";
if (true) return _container._html();
 //BA.debugLineNum = 96;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
