package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoeparallax extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoeparallax", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoeparallax.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.Mashy.UOEBANano.uoeapp _app = null;
public String _id = "";
public String _image = "";
public boolean _enabled = false;
public b4j.Mashy.UOEBANano.uoehtml _element = null;
public String _visibility = "";
public String _instance = "";
public int _height = 0;
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public b4j.Mashy.UOEBANano.uoeparallax  _addattribute(String _attr,String _value) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub AddAttribute(attr As String, value As String)";
 //BA.debugLineNum = 62;BA.debugLine="Element.AddAttribute(attr,value)";
_element._addattribute(_attr,_value);
 //BA.debugLineNum = 63;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeparallax  _addclass(String _sclass) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Sub AddClass(sClass As String) As UOEParallax";
 //BA.debugLineNum = 50;BA.debugLine="Element.AddClass(sClass)";
_element._addclass(_sclass);
 //BA.debugLineNum = 51;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeparallax  _addcontainer(b4j.Mashy.UOEBANano.uoecontainer _cont) throws Exception{
 //BA.debugLineNum = 43;BA.debugLine="Sub AddContainer(cont As UOEContainer) As UOEParal";
 //BA.debugLineNum = 44;BA.debugLine="Element.AddContent(cont.ToString)";
_element._addcontent(_cont._tostring());
 //BA.debugLineNum = 45;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeparallax  _addstyleattribute(String _attribute,String _value) throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub AddStyleAttribute(attribute As String, value A";
 //BA.debugLineNum = 17;BA.debugLine="Element.AddStyleAttribute(attribute,value)";
_element._addstyleattribute(_attribute,_value);
 //BA.debugLineNum = 18;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return null;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Private App As UOEApp";
_app = new b4j.Mashy.UOEBANano.uoeapp();
 //BA.debugLineNum = 5;BA.debugLine="Public ID As String";
_id = "";
 //BA.debugLineNum = 6;BA.debugLine="Private Image As String";
_image = "";
 //BA.debugLineNum = 7;BA.debugLine="Public Enabled As Boolean";
_enabled = false;
 //BA.debugLineNum = 8;BA.debugLine="Private Element As UOEHTML";
_element = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 9;BA.debugLine="Public Visibility As String";
_visibility = "";
 //BA.debugLineNum = 10;BA.debugLine="Public Instance As String";
_instance = "";
 //BA.debugLineNum = 11;BA.debugLine="Public Height As Int";
_height = 0;
 //BA.debugLineNum = 12;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,b4j.Mashy.UOEBANano.uoeapp _thisapp,String _sid,String _simage) throws Exception{
innerInitialize(_ba);
b4j.Mashy.UOEBANano.uoehtml _div = null;
b4j.Mashy.UOEBANano.uoehtml _img = null;
 //BA.debugLineNum = 23;BA.debugLine="Public Sub Initialize(thisApp As UOEApp, sID As St";
 //BA.debugLineNum = 25;BA.debugLine="App = thisApp";
_app = _thisapp;
 //BA.debugLineNum = 26;BA.debugLine="ID = sID.tolowercase";
_id = _sid.toLowerCase();
 //BA.debugLineNum = 27;BA.debugLine="Enabled = True";
_enabled = __c.True;
 //BA.debugLineNum = 28;BA.debugLine="Image = sImage";
_image = _simage;
 //BA.debugLineNum = 29;BA.debugLine="Element.Initialize(ID,\"div\")";
_element._initialize(ba,_id,"div");
 //BA.debugLineNum = 30;BA.debugLine="Dim div As UOEHTML";
_div = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 31;BA.debugLine="div.Initialize(ID & \"-parallax\",\"div\")";
_div._initialize(ba,_id+"-parallax","div");
 //BA.debugLineNum = 32;BA.debugLine="div.AddClass(\"parallax\")";
_div._addclass("parallax");
 //BA.debugLineNum = 33;BA.debugLine="Dim img As UOEHTML";
_img = new b4j.Mashy.UOEBANano.uoehtml();
 //BA.debugLineNum = 34;BA.debugLine="img.Initialize(ID & \"-img\",\"img\")";
_img._initialize(ba,_id+"-img","img");
 //BA.debugLineNum = 35;BA.debugLine="img.SetSRC(Image,True)";
_img._setsrc(_image,__c.True);
 //BA.debugLineNum = 36;BA.debugLine="div.AddElement(img)";
_div._addelement(_img);
 //BA.debugLineNum = 37;BA.debugLine="Element.AddElement(div)";
_element._addelement(_div);
 //BA.debugLineNum = 38;BA.debugLine="Instance = $\"${ID}inst\"$";
_instance = (""+__c.SmartStringFormatter("",(Object)(_id))+"inst");
 //BA.debugLineNum = 39;BA.debugLine="Height = 500";
_height = (int) (500);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public b4j.Mashy.UOEBANano.uoeparallax  _removeattribute(String _attr) throws Exception{
 //BA.debugLineNum = 67;BA.debugLine="Sub RemoveAttribute(attr As String) As UOEParallax";
 //BA.debugLineNum = 68;BA.debugLine="Element.RemoveAttribute(attr)";
_element._removeattribute(_attr);
 //BA.debugLineNum = 69;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 70;BA.debugLine="End Sub";
return null;
}
public b4j.Mashy.UOEBANano.uoeparallax  _removeclass(String _sclass) throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="Sub RemoveClass(sClass As String) As UOEParallax";
 //BA.debugLineNum = 56;BA.debugLine="Element.RemoveClass(sClass)";
_element._removeclass(_sclass);
 //BA.debugLineNum = 57;BA.debugLine="Return Me";
if (true) return (b4j.Mashy.UOEBANano.uoeparallax)(this);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return null;
}
public String  _tostring() throws Exception{
 //BA.debugLineNum = 73;BA.debugLine="Sub ToString As String";
 //BA.debugLineNum = 74;BA.debugLine="Element.ID = ID";
_element._id = _id;
 //BA.debugLineNum = 75;BA.debugLine="Element.MaterialEnable(Enabled).AddClass(\"paralla";
_element._materialenable(_enabled)._addclass("parallax-container");
 //BA.debugLineNum = 76;BA.debugLine="Element.MaterialVisibility(Visibility)";
_element._materialvisibility(_visibility);
 //BA.debugLineNum = 78;BA.debugLine="App.ApplyToolTip(ID,Element)";
_app._applytooltip(_id,_element);
 //BA.debugLineNum = 86;BA.debugLine="Return Element.html";
if (true) return _element._html();
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
