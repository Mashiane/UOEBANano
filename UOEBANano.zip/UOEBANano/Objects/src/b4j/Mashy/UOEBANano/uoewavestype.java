package b4j.Mashy.UOEBANano;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class uoewavestype extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.Mashy.UOEBANano", "b4j.Mashy.UOEBANano.uoewavestype", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.Mashy.UOEBANano.uoewavestype.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public com.ab.banano.BANano _banano = null;
public String _green = "";
public String _light = "";
public String _normal = "";
public String _orange = "";
public String _purple = "";
public String _red = "";
public String _teal = "";
public String _yellow = "";
public b4j.Mashy.UOEBANano.moduoe _moduoe = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 3;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="Public BANano As BANano	'ignore";
_banano = new com.ab.banano.BANano();
 //BA.debugLineNum = 5;BA.debugLine="Public Green As String= \"waves-green\"";
_green = "waves-green";
 //BA.debugLineNum = 6;BA.debugLine="Public Light As String= \"waves-light\"";
_light = "waves-light";
 //BA.debugLineNum = 7;BA.debugLine="Public Normal As String= \"\"";
_normal = "";
 //BA.debugLineNum = 8;BA.debugLine="Public Orange As String= \"waves-orange\"";
_orange = "waves-orange";
 //BA.debugLineNum = 9;BA.debugLine="Public Purple As String = \"waves-purple\"";
_purple = "waves-purple";
 //BA.debugLineNum = 10;BA.debugLine="Public Red As String= \"waves-red\"";
_red = "waves-red";
 //BA.debugLineNum = 11;BA.debugLine="Public Teal As String= \"waves-teal\"";
_teal = "waves-teal";
 //BA.debugLineNum = 12;BA.debugLine="Public Yellow As String= \"waves-yellow\"";
_yellow = "waves-yellow";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 15;BA.debugLine="Sub Initialize";
 //BA.debugLineNum = 17;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
