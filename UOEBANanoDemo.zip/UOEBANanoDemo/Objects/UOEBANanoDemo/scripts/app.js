<!-- This WebApp/WebSite was created using BANano v2.09, a B4X library written by Alain Bailleul (2018 - 2019). -->
// =========================== Umbrella (modified by Alain Bailleul) ===========================
var u=function(t,e){return this instanceof u?t instanceof u?t:("string"==typeof t&&(t=this.select(t,e)),t&&t.nodeName&&(t=[t]),void(this.nodes=this.slice(t))):new u(t,e)};u.prototype={get length(){return this.nodes.length}},u.prototype.nodes=[],u.prototype.addClass=function(){return this.eacharg(arguments,function(t,e){t.classList.add(e)})},u.prototype.adjacent=function(i,t,n){return"number"==typeof t&&(t=0===t?[]:new Array(t).join().split(",").map(Number.call,Number)),this.each(function(r,o){var e=document.createDocumentFragment();u(t||{}).map(function(t,e){var n="function"==typeof i?i.call(this,t,e,r,o):i;return"string"==typeof n?this.generate(n):u(n)}).each(function(t){this.isInPage(t)?e.appendChild(u(t).clone().first()):e.appendChild(t)}),n.call(this,r,e)})},u.prototype.after=function(t,e){return this.adjacent(t,e,function(t,e){t.parentNode.insertBefore(e,t.nextSibling)})},u.prototype.append=function(t,e){return this.adjacent(t,e,function(t,e){t.appendChild(e)})},u.prototype.args=function(t,e,n){return"function"==typeof t&&(t=t(e,n)),"string"!=typeof t&&(t=this.slice(t).map(this.str(e,n))),t.toString().split(/[\s,]+/).filter(function(t){return t.length})},u.prototype.array=function(o){o=o;var i=this;return this.nodes.reduce(function(t,e,n){var r;return o?((r=o.call(i,e,n))||(r=!1),"string"==typeof r&&(r=u(r)),r instanceof u&&(r=r.nodes)):r=e.innerHTML,t.concat(!1!==r?r:[])},[])},u.prototype.attr=function(t,e,r){return r=r?"data-":"",this.pairs(t,e,function(t,e){return t.getAttribute(r+e)},function(t,e,n){t.setAttribute(r+e,n)})},u.prototype.before=function(t,e){return this.adjacent(t,e,function(t,e){t.parentNode.insertBefore(e,t)})},u.prototype.children=function(t){return this.map(function(t){return this.slice(t.children)}).filter(t)},u.prototype.clone=function(){return this.map(function(t,e){var n=t.cloneNode(!0),r=this.getAll(n);return this.getAll(t).each(function(t,e){for(var n in this.mirror)this.mirror[n]&&this.mirror[n](t,r.nodes[e])}),n})},u.prototype.toU=function(){for(var t=[],e=0;e<this.nodes.length;e++)t.push(u(this.nodes[e]));return t},u.prototype.css=function(t,e){return this.pairs(t,e,function(t,e){return getStyle(t,e)},function(t,e,n){setStyle(t,e,n)})},u.prototype.getAll=function(t){return u([t].concat(u("*",t).nodes))},u.prototype.mirror={},u.prototype.mirror.events=function(t,e){if(t._e)for(var n in t._e)t._e[n].forEach(function(t){u(e).on(n,t)})},u.prototype.mirror.select=function(t,e){u(t).is("select")&&(e.value=t.value)},u.prototype.mirror.textarea=function(t,e){u(t).is("textarea")&&(e.value=t.value)},u.prototype.closest=function(e){return this.map(function(t){do{if(u(t).is(e))return t}while((t=t.parentNode)&&t!==document)})},u.prototype.data=function(t,e){return this.attr(t,e,!0)},u.prototype.each=function(t){return this.nodes.forEach(t.bind(this)),this},u.prototype.eacharg=function(n,r){return this.each(function(e,t){this.args(n,e,t).forEach(function(t){r.call(this,e,t)},this)})},u.prototype.empty = function() {return this.each(function(e) {for (var t = e.children, r = 0; r < t.length; r++) {var i = t[r];var n = document.getElementById(i.id);if (n) {var o = n.cloneNode(!0);n.parentNode.replaceChild(o, n)}}for (; e.firstChild;) e.removeChild(e.firstChild)})},u.prototype.filter=function(e){var t=function(t){return t.matches=t.matches||t.msMatchesSelector||t.webkitMatchesSelector,t.matches(e||"*")};return"function"==typeof e&&(t=e),e instanceof u&&(t=function(t){return-1!==e.nodes.indexOf(t)}),u(this.nodes.filter(t))},u.prototype.find=function(e){return this.map(function(t){return u(e||"*",t)})},u.prototype.first=function(){return this.nodes[0]||!1},u.prototype.bananofirst=function(){return u(this.nodes[0])||!1},u.prototype.generate=function(t){return/^\s*<tr[> ]/.test(t)?u(document.createElement("table")).html(t).children().children().nodes:/^\s*<t(h|d)[> ]/.test(t)?u(document.createElement("table")).html(t).children().children().children().nodes:/^\s*</.test(t)?u(document.createElement("div")).html(t).children().nodes:document.createTextNode(t)},u.prototype.handle=function(){var t=this.slice(arguments).map(function(e){return"function"==typeof e?function(t){t.preventDefault(),e.apply(this,arguments)}:e},this);return this.on.apply(this,t)},u.prototype.hasClass=function(){return this.is("."+this.args(arguments).join("."))},u.prototype.html=function(e){return void 0===e?this.first().innerHTML||"":this.each(function(t){t.innerHTML=e})},u.prototype.is=function(t){return 0<this.filter(t).length},u.prototype.isInPage=function(t){return t!==document.body&&document.body.contains(t)},u.prototype.bananolastlast=function(){return u(this.nodes[this.length-1])||!1},u.prototype.last=function(){return this.nodes[this.length-1]||!1},u.prototype.map=function(t){return t?u(this.array(t)).unique():this},u.prototype.not=function(e){return this.filter(function(t){return!u(t).is(e||!0)})},u.prototype.off=function(t){return this.eacharg(t,function(e,n){u(e._e?e._e[n]:[]).each(function(t){e.removeEventListener(n,t)})})},u.prototype.on=function(t,e,r){if("string"==typeof e){var o=e;e=function(e){var n=arguments;u(e.currentTarget).find(o).each(function(t){if(t===e.target||t.contains(e.target)){try{Object.defineProperty(e,"currentTarget",{get:function(){return t}})}catch(t){}r.apply(t,n)}})}}var n=function(t){return e.apply(this,[t].concat(t.detail||[]))};return this.eacharg(t,function(t,e){t.addEventListener(e,n),t._e=t._e||{},t._e[e]=t._e[e]||[],t._e[e].push(n)})},u.prototype.pairs=function(n,t,e,r){if(void 0!==t){var o=n;(n={})[o]=t}return"object"==typeof n?this.each(function(t){for(var e in n)r(t,e,n[e])}):this.length?e(this.first(),n):""},u.prototype.param=function(e){return Object.keys(e).map(function(t){return this.uri(t)+"="+this.uri(e[t])}.bind(this)).join("&")},u.prototype.parent=function(t){return this.map(function(t){return t.parentNode}).filter(t)},u.prototype.prepend=function(t,e){return this.adjacent(t,e,function(t,e){t.insertBefore(e,t.firstChild)})},u.prototype.remove=function(){return this.each(function(t){u(t).empty();t.parentNode&&t.parentNode.removeChild(t)})},u.prototype.removeClass=function(){return this.eacharg(arguments,function(t,e){t.classList.remove(e)})},u.prototype.replace=function(t,e){var n=[];return this.adjacent(t,e,function(t,e){n=n.concat(this.slice(e.children)),t.parentNode.replaceChild(e,t)}),u(n)},u.prototype.scroll=function(){return this.first().scrollIntoView({behavior:"smooth"}),this},u.prototype.select=function(t,e){return t=t.replace(/^\s*/,"").replace(/\s*$/,""),/^</.test(t)?u().generate(t):(e||document).querySelectorAll(t)},u.prototype.serialize=function(){var r=this;return this.slice(this.first().elements).reduce(function(e,n){return!n.name||n.disabled||"file"===n.type?e:/(checkbox|radio)/.test(n.type)&&!n.checked?e:"select-multiple"===n.type?(u(n.options).each(function(t){t.selected&&(e+="&"+r.uri(n.name)+"="+r.uri(t.value))}),e):e+"&"+r.uri(n.name)+"="+r.uri(n.value)},"").slice(1)},u.prototype.siblings=function(t){return this.parent().children(t).not(this)},u.prototype.size=function(){return this.first().getBoundingClientRect()},u.prototype.hasAttr=function(t){return null!=this.attr(t)},u.prototype.slice=function(t){return t&&0!==t.length&&"string"!=typeof t&&"[object Function]"!==t.toString()?t.length?[].slice.call(t.nodes||t):[t]:[]},u.prototype.str=function(e,n){return function(t){return"function"==typeof t?t.call(this,e,n):t.toString()}},u.prototype.text=function(e){return void 0===e?this.first().textContent||"":this.each(function(t){t.textContent=e})},u.prototype.toggleClass=function(t,e){return!!e===e?this[e?"addClass":"removeClass"](t):this.eacharg(t,function(t,e){t.classList.toggle(e)})},u.prototype.trigger=function(t){var o=this.slice(arguments).slice(1);return this.eacharg(t,function(t,e){var n,r={bubbles:!0,cancelable:!0,detail:o};try{n=new window.CustomEvent(e,r)}catch(t){(n=document.createEvent("CustomEvent")).initCustomEvent(e,!0,!0,o)}t.dispatchEvent(n)})},u.prototype.checked=function (bool) {if (bool === undefined) {return this.checked().value || false;} return this.each(function (node) {node.checked = bool;});},u.prototype.value=function (text) {if (text === undefined) {return this.first().value || '';} return this.each(function (node) {node.value = text;});},u.prototype.unique=function(){return u(this.nodes.reduce(function(t,e){return null!=e&&!1!==e&&-1===t.indexOf(e)?t.concat(e):t},[]))},u.prototype.uri=function(t){return encodeURIComponent(t).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A").replace(/%20/g,"+")},u.prototype.wrap=function(t){return this.map(function(e){return u(t).each(function(t){(function(t){for(;t.firstElementChild;)t=t.firstElementChild;return u(t)})(t).append(e.cloneNode(!0)),e.parentNode.replaceChild(t,e)})})},"object"==typeof module&&module.exports&&(module.exports=u,module.exports.u=u);
// =========================== Vault ===========================
!function(e,t){"function"==typeof define&&define.amd?define(t):"object"==typeof exports?module.exports=t:e.vault=t()}(this,function(){"use strict";var e=window.localStorage;return{set:function(t,n){t&&void 0!==n&&(e[t]=JSON.stringify(n))},get:function(t){var n=e[t];return void 0!==n?JSON.parse(n):void 0},remove:function(t){e.hasOwnProperty(t)&&delete e[t]},empty:function(){e.clear()}}});
// =========================== uoebanano ===========================
var _banano_uoebanano_moduoe = new banano_uoebanano_moduoe();function banano_uoebanano_uoetabs() {var self;this._id='';this._theme='';this._app= new banano_uoebanano_uoeapp();this._visibility='';this._enabled=false;this._el= new banano_uoebanano_uoehtml();this._hoverable=false;this._tabs=[];this._zdepth='';this._pdiv= new banano_uoebanano_uoehtml();this._instance='';this._swipeable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._el.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_fixedwidth,_themename,_cclass) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._el.initialize(self._id,"ul");self._el.addclass("tabs");self._el.addclassoncondition(_fixedwidth,"tabs-fixed-width tab-demo");self._pdiv.initialize(self._id+"parent","div");self._pdiv.addclass(_cclass);self._enabled = true;self._tabs.length=0;self._tabs.length=0;self._zdepth = "";self._theme = _themename;self._instance = "" + self._id + "inst";self._swipeable = true;};this.gettabid= function(_stabid) {if (self==null) self=this;return "tab" + self._id + "" + _stabid + "a";};this.addtab= function(_tabid,_tabtitle,_tabactive,_tabdisabled,_sizesmall,_sizemedium,_sizelarge,_cont) {if (self==null) self=this;var _skey;var _tabkey;var _tabkeya;var _li;var _a;var _tabdiv;_skey="" + self._id + "" + _tabid + "";_tabkey="tab" + self._id + "" + _tabid + "";_tabkeya="tab" + self._id + "" + _tabid + "a";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey,"li");_li.addclass("tab");_li.addclass("col").addclass("s"+_sizesmall).addclass("m"+_sizemedium).addclass("l"+_sizelarge);_li.addclassoncondition(_tabdisabled,"disabled");_a= new banano_uoebanano_uoehtml();_a.initialize(_tabkeya,"a");_a.sethref("#"+_tabkey);_a.addcontent(_tabtitle);_a.addclassoncondition(_tabactive,"active");self._app.materialusetheme(self._theme,_a);_li.addelement(_a);self._el.addelement(_li);_tabdiv= new banano_uoebanano_uoehtml();_tabdiv.initialize(_tabkey,"div");_tabdiv.addclass("col").addclass("s12");if (_cont!=null) {_tabdiv.addcontent(_cont.tostring());}self._tabs.push(_tabdiv.html());};this.addtabexternal= function(_tabid,_tabtitle,_tabactive,_tabdisabled,_sizesmall,_sizemedium,_sizelarge,_url,_target) {if (self==null) self=this;var _skey;var _tabkeya;var _li;var _a;_skey="" + self._id + "" + _tabid + "";_tabkeya="tab" + self._id + "" + _tabid + "a";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey,"li");_li.addclass("tab");_li.addclass("col").addclass("s"+_sizesmall).addclass("m"+_sizemedium).addclass("l"+_sizelarge);_li.addclassoncondition(_tabdisabled,"disabled");_a= new banano_uoebanano_uoehtml();_a.initialize(_tabkeya,"a");_a.sethref(_url).addcontent(_tabtitle).addclassoncondition(_tabactive,"active");self._app.materialusetheme(self._theme,_a);_li.addelement(_a);self._el.addelement(_li);};this.getsettings= function() {if (self==null) self=this;var _dpsettings;var _strds;_dpsettings={};_dpsettings={};_dpsettings={};_dpsettings["id"]=self._id;_dpsettings["instance"]="tabs";_dpsettings["swipeable"]=self._swipeable;_strds=self._app.map2json(_dpsettings);return _strds;};this.selecttab= function(_tabid) {if (self==null) self=this;var _skey;var _script;_skey="" + self._id + "" + _tabid + "";_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Tabs.getInstance(inst" + self._id + "); \n	" + self._instance + ".select('" + _skey + "'); \n	" + self._instance + ".updateTabIndicator();";eval(_script);};this.tostring= function() {if (self==null) self=this;self._el._id = self._id;self._el.materialenable(self._enabled).materialvisibility(self._visibility).materialzdepth(self._zdepth);self._pdiv.addelement(self._el);self._pdiv.addcontentlist(self._tabs);self._app.applytooltip(self._id,self._pdiv);return self._pdiv.html();};this.addclass= function(_sclass) {if (self==null) self=this;self._el.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._el.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._el.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._el.removeattribute(_attr);return self;};}function banano_uoebanano_uoecheckbox() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._enabled=false;this._hoverable=false;this._filledin=false;this._checked=false;this._visibility='';this._element= new banano_uoebanano_uoehtml();this._zdepth='';this._lbl= new banano_uoebanano_uoehtml();this._inp= new banano_uoebanano_uoehtml();this._spn= new banano_uoebanano_uoehtml();this._inline=false;this._theme='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_sname,_svalue,_stitle,_themename) {if (self==null) self=this;self._app = _thisapp;if (_themename == "") {_themename = self._app._theme;}self._theme = _themename;self._id = _sid.toLowerCase();self._filledin = false;self._checked = false;self._enabled = true;self._visibility = "";self._element.initialize(self._id,"p");self._lbl.initialize(self._id+"lbl","label");self._inp.initialize(self._id+"inp","input");self._inp.settype("checkbox").setname(_sname).setvalue(_svalue);self._spn.initialize(self._id+"-span","span");self._spn.addcontent(_stitle+"{NBSP}{NBSP}");self._inline = false;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;if (self._theme == "") {self._theme = self._app._theme;}self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.materialhoverable(self._hoverable);self._inp.addattributeoncondition(!(self._enabled),"disabled","disabled");self._inp.addattributeoncondition(self._checked,"checked","checked");self._inp.addclassoncondition(self._filledin,"filled-in");self._lbl.addelement(self._inp);self._lbl.addelement(self._spn);self._element.addelement(self._lbl);self._element.addclassoncondition(self._inline,"inline");self._element.addstyleattributeoncondition(self._inline,"display","inline-block");self._element.addstyleattributeoncondition(self._inline,"padding","0 12px");return self._element.html();};this.setindeterminate= function() {if (self==null) self=this;var _script;_script="// Set checkbox on forms.html to indeterminate \n    var chk" + self._id + " = document.getElementById('" + self._id + "inp'); \n    if (chk" + self._id + " !== null) chk" + self._id + ".indeterminate = true;";eval(_script);};}function banano_uoebanano_uoecheckboxgroup() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._title='';this._theme='';this._enabled=false;this._container= new banano_uoebanano_uoehtml();this._visibility='';this._zdepth='';this.checkall= function(_bstatus) {if (self==null) self=this;var _script;if (_bstatus == "1") {_bstatus = "true";}if (_bstatus == "0") {_bstatus = "false";}if (_bstatus == "y") {_bstatus = "true";}if (_bstatus == "n") {_bstatus = "false";}if (_bstatus == true) {_bstatus = "true";}if (_bstatus == false) {_bstatus = "false";}_script="var tblChkBox" + self._id + " = $('#" + self._id + " input:checkbox'); \n	console.log(tblChkBox" + self._id + "); \n	$(tblChkBox" + self._id + ").prop('checked', " + _bstatus + ");";eval(_script);};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._container.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_bshowtitle,_themename) {if (self==null) self=this;var _lbl;self._app = _thisapp;self._id = _sid.toLowerCase();self._theme = _themename;self._enabled = true;self._container.initialize(self._id,"div");if (_bshowtitle) {_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id).addcontent(_stitle);self._app.materialusetheme(_themename,_lbl);self._container.addelement(_lbl);}};this.addclass= function(_sclass) {if (self==null) self=this;self._container.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._container.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._container.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._container.removeattribute(_attr);return self;};this.additem= function(_itemid,_itemvalue,_itemtext,_binline,_benabled,_bselected) {if (self==null) self=this;var _rad;_rad= new banano_uoebanano_uoecheckbox();_rad.initialize(self._app,_itemid,self._id,_itemvalue,_itemtext,"");_rad._checked = _bselected;_rad._enabled = _benabled;_rad._inline = _binline;self._container.addcontent(_rad.tostring());};this.tostring= function() {if (self==null) self=this;self._container.materialvisibility(self._visibility).materialenable(self._enabled);self._app.materialusetheme(self._theme,self._container);self._container.materialzdepth(self._zdepth).materialvisibility(self._visibility);self._app.applytooltip(self._id,self._container);return self._container.html();};}function banano_uoebanano_uoechip() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._imageurl='';this._text='';this._element= new banano_uoebanano_uoehtml();this._imagealt='';this._canclose=false;this._theme='';this._visibility='';this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._zdepth='';this._enabled=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_chipid,_chiptext,_chipimg,_chipimgalt,_chiptheme) {if (self==null) self=this;self._app = _thisapp;self._enabled = true;self._imageurl = _chipimg;self._text = _chiptext;self._id = _chipid.toLowerCase();self._canclose = false;self._theme = _chiptheme;self._element.initialize(self._id,"div");self._element.addclass("chip");self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._waveseffect = true;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;if (self._theme == "") {self._theme = self._app._theme;}_banano_uoebanano_moduoe.materialaddimage(self._app,self._element,self._imageurl,self._imagealt,"","",false,true,true,"");self._element.addcontent(self._text);self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.materialwaveseffect(self._waveseffect);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);if (self._canclose == true) {_banano_uoebanano_moduoe.materialaddicon(self._app,self._element,"mdi-close",self._theme,"",false,true,true,false,self._canclose);}return self._element.html();};}function banano_uoebanano_uoechips() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._visibility='';this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._zdepth='';this._enabled=false;this._initialwith=[];this._autocomplete=[];this._placeholder='';this._secondaryplaceholder='';this._onselect='';this._ondelete='';this._onadd='';this._hoverable=false;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_chipid,_themename) {if (self==null) self=this;self._app = _thisapp;self._initialwith.length=0;self._initialwith.length=0;self._autocomplete.length=0;self._autocomplete.length=0;self._placeholder = "";self._secondaryplaceholder = "";self._onselect = "";self._ondelete = "";self._onadd = "";self._enabled = true;self._id = _chipid.toLowerCase();self._theme = _themename;self._element.initialize(self._id,"div");self._element.addclass("col").addclass("s12").addclass("m12").addclass("l12");self._element.addclass("chips-initial").addclass("chips-placeholder");self._element.addclass("chips-autocomplete").addclass("chips");self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._waveseffect = true;self._instance = "" + self._id + "inst";};this.addinitialwith= function(_svalue) {if (self==null) self=this;if (_svalue == "") { return self;}if (self._initialwith.indexOf(_svalue) == -1) {self._initialwith.push(_svalue);}return self;};this.addautocomplete= function(_svalue) {if (self==null) self=this;if (_svalue == "") { return self;}if (self._autocomplete.indexOf(_svalue) == -1) {self._autocomplete.push(_svalue);}return self;};this.deletechip= function(_idx) {if (self==null) self=this;var _script;_script="" + self._instance + ".deleteChip(" + _idx + ");";return _script;};this.selectchip= function(_idx) {if (self==null) self=this;var _script;_script="" + self._instance + ".selectChip(" + _idx + ");";return _script;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.materialusetheme(self._id,self._element);self._element.materialwaveseffect(self._waveseffect);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);return self._element.html();};}function banano_uoebanano_uoecollapsible() {var self;this._id='';this._theme='';this._element= new banano_uoebanano_uoehtml();this._app= new banano_uoebanano_uoeapp();this._visibility='';this._headers={};this._bodies={};this._popout=false;this._nopadding=false;this._zdepth='';this._enabled=false;this._hoverable=false;this._haschildren={};this._normalize=false;this._lastheader='';this._lastheadertitle='';this._showarrows=false;this._links={};this._itemnames={};this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.bodyof= function(_sid) {if (self==null) self=this;_sid = _sid.toLowerCase();if ((_sid in self._headers)) {return _sid+"bdy";} else {return "";}};this.addhiddenheadertitle2body= function() {if (self==null) self=this;var _ml;if ((self._lastheader in self._headers)) {_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,self._lastheader,self._app._enumlabelsize._paragraph,self._lastheadertitle+". ","","");_ml._visibility = self._app._enumvisibility._hide;self.addheaderbody(self._lastheader,_ml.tostring());}return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_itemid,_itemtype,_bnopadding,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _itemid.toLowerCase();self._theme = _themename;self._enabled = true;self._element.initialize(self._id,"ul");self._element.addclass("collapsible");self._element.addattribute("data-collapsible",_itemtype);self._visibility = "";self._headers={};self._headers={};self._bodies={};self._bodies={};self._popout = false;self._nopadding = _bnopadding;self._haschildren={};self._haschildren={};self._normalize = false;self._showarrows = true;self._links={};self._links={};self._itemnames={};self._itemnames={};self._instance = "" + self._id + "inst";};this.open= function(_idx) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Collapsible.getInstance(inst" + self._id + "); \n	" + self._instance + ".open(" + _idx + ");";eval(_script);};this.close= function(_idx) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Collapsible.getInstance(inst" + self._id + "); \n	" + self._instance + ".close(" + _idx + ");";eval(_script);};this.addheadersimple= function(_itemid,_itemicon,_itemtext,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;self.addheader(_itemid,_itemicon,_itemtext,"",false,"",_itemtheme,_icontheme,_hasdivider);};this.additemsimple= function(_itemid,_itemicon,_itemtext,_itemgoto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;self.additem(_itemid,_itemicon,_itemtext,"",false,_itemgoto,_itemtheme,_icontheme,_hasdivider);};this.addheader= function(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;var _div;var _spn;var _md;var _sout;var _lst;var _lst1;var _lst2;_itemid = _itemid.toLowerCase();self._haschildren[_itemid]=false;_div= new banano_uoebanano_uoeanchor();_div.initialize(self._app,_itemid);_div._element.materialcollapsibleheader(true);_div._isdiv = self._normalize;_banano_uoebanano_moduoe.materialaddicon(self._app,_div._element,_itemicon,"",_icontheme,false,false,false,false,false);_spn= new banano_uoebanano_uoehtml();_spn.initialize(_itemid+"-span","span");_spn.addcontent(_itemtext);_div._element.addelement(_spn);_banano_uoebanano_moduoe.materialaddbadge(self._app,_div._element,_itembadge,_badgenew,self._app._enumvisibility._visible,true,"",false);if (self._showarrows) {_banano_uoebanano_moduoe.materialaddicon(self._app,_div._element,"mdi-keyboard_arrow_right","right","",false,false,false,false,false);}_div._waveseffect = true;_div._wavestype = self._app._enumwavestype._light;_div._textvisible = true;_div._theme = _itemtheme;_div._href = _itemnavigateto;if (_hasdivider == true) {_md= new banano_uoebanano_uoedivider();_md.initialize(self._app,"","");_sout=_div.tostring(+_md.tostring());self._headers[_itemid]=_sout;} else {self._headers[_itemid]=_div.tostring();}_lst=[];_lst.length=0;_lst.length=0;_lst1=[];_lst1.length=0;_lst1.length=0;_lst2=[];_lst2.length=0;_lst2.length=0;self._bodies[_itemid]=_lst;self._links[_itemid]=_lst1;self._itemnames[_itemid]=_lst2;self._lastheader = _itemid;self._lastheadertitle = _itemtext;self._app.addevent(_itemid,"click");};this.additem= function(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;var _div;var _md;var _sout;var _lst1;var _lst2;_itemid = _itemid.toLowerCase();self._haschildren[_itemid]=false;_div= new banano_uoebanano_uoeanchor();_div.initialize(self._app,_itemid);_div._isdiv = self._normalize;_div._element.materialcollapsibleheader(true);_banano_uoebanano_moduoe.materialaddicon(self._app,_div._element,_itemicon,"",_icontheme,false,false,false,false,false);_div._element.addcontent(_itemtext);_banano_uoebanano_moduoe.materialaddbadge(self._app,_div._element,_itembadge,_badgenew,self._app._enumvisibility._visible,true,"",false);_div._waveseffect = true;_div._wavestype = self._app._enumwavestype._light;_div._textvisible = true;_div._theme = _itemtheme;_div._href = _itemnavigateto;if (_hasdivider == true) {_md= new banano_uoebanano_uoedivider();_md.initialize(self._app,"","");_sout=_div.tostring(+_md.tostring());self._headers[_itemid]=_sout;} else {self._headers[_itemid]=_div.tostring();}if ((_itemid in self._links) && _itemnavigateto.length>0) {_lst1=[];_lst1 = self._links[_itemid];_lst1.push(_itemnavigateto);self._links[_itemid]=_lst1;_lst2=[];_lst2 = self._itemnames[_itemid];_lst2.push(_itemtext);self._itemnames[_itemid]=_lst2;}self._app.addevent(_itemid,"click");};this.addheaderitemsimple= function(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;self.addheaderitem(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,"",false,_hasdivider,_itemtheme,_icontheme);};this.addheaderitem= function(_parentid,_itemid,_iconname,_itemtext,_itemnavigateto,_itembadge,_badgenew,_bhasdivider,_itemtheme,_icontheme) {if (self==null) self=this;var _div;var _li;var _hdr;var _div1;var _divx;var _divider;var _lst;var _lst1;var _lst2;_itemid = _itemid.toLowerCase();_parentid = _parentid.toLowerCase();self._haschildren[_parentid]=true;if ((_parentid in self._headers) == false) {console.log(_parentid+" header does not exist on sidebar");return;}_div= new banano_uoebanano_uoeanchor();_div.initialize(self._app,_itemid);_div._isdiv = self._normalize;_banano_uoebanano_moduoe.materialaddbadge(self._app,_div._element,_itembadge,_badgenew,self._app._enumvisibility._visible,true,"",false);_banano_uoebanano_moduoe.materialaddicon(self._app,_div._element,_iconname,"",_icontheme,false,false,false,false,false);_div._waveseffect = true;_div._wavestype = self._app._enumwavestype._light;_div._textvisible = true;_div._theme = _itemtheme;_div._text = _itemtext;_div._href = _itemnavigateto;_li= new banano_uoebanano_uoehtml();_li.initialize("","li");_li.addcontent(_div.tostring());_hdr=_li.html();if (_bhasdivider == true) {_div1= new banano_uoebanano_uoehtml();_div1.initialize("","li");_divx= new banano_uoebanano_uoehtml();_divx.initialize("","div");_divx.addclass("divider");_div1.addelement(_divx);_divider= new banano_uoebanano_uoedivider();_divider.initialize(self._app,"",_itemtheme);_hdr = _hdr+_divider.tostring();}if ((_parentid in self._headers)) {_lst=self._bodies[_parentid];_lst.push(_hdr);self._bodies[_parentid]=_lst;}if ((_parentid in self._links) && _itemnavigateto.length>0) {_lst1=[];_lst1 = self._links[_parentid];_lst1.push(_itemnavigateto);self._links[_parentid]=_lst1;_lst2=[];_lst2 = self._itemnames[_parentid];_lst2.push(_itemtext);self._itemnames[_parentid]=_lst2;}self._app.addevent(_itemid,"click");};this.addheaderbody= function(_itemid,_itembody) {if (self==null) self=this;var _lst;_itemid = _itemid.toLowerCase();if ((_itemid in self._headers)) {_lst=self._bodies[_itemid];_lst.push(_itembody);self._bodies[_itemid]=_lst;}};this.addheadercontainer= function(_itemid,_cont) {if (self==null) self=this;var _lst;_itemid = _itemid.toLowerCase();if ((_itemid in self._headers)) {_lst=self._bodies[_itemid];_lst.push(_cont.tostring());self._bodies[_itemid]=_lst;}};this.getstructure= function() {if (self==null) self=this;var _sb;var _ktot;var _kcnt;var _drpitem;var _hdr;var _li;var _div;var _bhaschildren;var _ul;var _lstx;_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._headers).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_drpitem=banano_getB4JKeyAt(self._headers,_kcnt);_hdr=(self._headers[_drpitem] || "");_li= new banano_uoebanano_uoehtml();_li.initialize(_drpitem+"hdr","li");_li.addcontent(_hdr);_div= new banano_uoebanano_uoehtml();_div.initialize(_drpitem+"bdy","div");_div.addclass("collapsible-body");_bhaschildren=self._haschildren[_drpitem];if (_bhaschildren) {_ul= new banano_uoebanano_uoehtml();_ul.initialize("","ul");_lstx=self._bodies[_drpitem];_ul.addcontentlist(_lstx);_div.addcontent(_ul.html());_li.addcontent(_div.html());} else {if ((_drpitem in self._bodies)) {_lstx=self._bodies[_drpitem];_div.addcontentlist(_lstx);_li.addcontent(_div.html());}}_sb.append(_li.html());}return _sb.toString();};this.tostring= function() {if (self==null) self=this;var _lim;self._element.addclassoncondition(self._popout,"popout");self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addcontent(self.getstructure());if (self._nopadding == true) {_lim= new banano_uoebanano_uoehtml();_lim.initialize("","li");_lim.addclass("no-padding");_lim.addcontent(self._element.html());return _lim.html();} else {return self._element.html();}};}function banano_uoebanano_uoecontainer() {var self;this._id='';this._element= new banano_uoebanano_uoehtml();this._items=[];this._enabled=false;this._theme='';this._visibility='';this._zdepth='';this._grid= new banano_uoebanano_uoegrid();this._hoverable=false;this._centerinpage=false;this._scrollspy=false;this._section=false;this._app= new banano_uoebanano_uoeapp();this._divcounter=0;this._j='';this.removecomponent= function(_elid) {if (self==null) self=this;};this.replacerc= function(_row,_col,_elhtml) {if (self==null) self=this;self._grid.replacerc(_row,_col,_elhtml);};this.addtable= function(_row,_column,_tbltable) {if (self==null) self=this;self.removecomponent(_tbltable._id);self.addcomponent(_row,_column,_tbltable.tostring());};this.addradiogroup= function(_row,_col,_rg) {if (self==null) self=this;self.removecomponent(_rg._id);self.addcomponent(_row,_col,_rg.tostring());};this.addpreloader= function(_row,_col,_prl) {if (self==null) self=this;self.removecomponent(_prl._id);self.addcomponent(_row,_col,_prl.tostring());};this.addmodal= function(_mdl) {if (self==null) self=this;var _mdls;var _cssset;self.removecomponent(_mdl._id);_mdls=_mdl.getsettings();self._app._components.push(_mdls);if (_mdl._hidescrollbar) {_cssset=_mdl.getcss();self._app._css.push(_cssset);}self.addcomponent(0,0,_mdl.tostring());};this.addlist= function(_row,_col,_lst) {if (self==null) self=this;self.removecomponent(_lst._id);self.addcomponent(_row,_col,_lst.tostring());};this.addrangeslider1= function(_row,_column,_cid,_ctitle,_cstart,_cstop,_cmin,_cmax,_cstep,_cconnect,_ctheme,_cclass) {if (self==null) self=this;var _rangeslider;_rangeslider= new banano_uoebanano_uoerangeslider();_rangeslider.initialize(self._app,_cid,_ctitle,_cstart,_cstop,_cmin,_cmax,_cstep,false,_ctheme);_rangeslider.addclass(_cclass);self.addrangeslider(_row,_column,_rangeslider);};this.addrangeslider= function(_row,_column,_rangeslider) {if (self==null) self=this;var _rs;self.removecomponent(_rangeslider._id);_rs=_rangeslider.getsettings();self._app._js.push(_rs);self.addcomponent(_row,_column,_rangeslider.tostring());};this.addrange= function(_row,_column,_range) {if (self==null) self=this;self.removecomponent(_range._id);self.addcomponent(_row,_column,_range.tostring());};this.addprogress= function(_row,_column,_progress) {if (self==null) self=this;self.removecomponent(_progress._id);self.addcomponent(_row,_column,_progress.tostring());};this.addprogress1= function(_row,_column,_cid,_bdeterminate,_cpercentage,_ctheme,_cclass) {if (self==null) self=this;var _prg;_prg= new banano_uoebanano_uoeprogress();_prg.initialize(self._app,_cid,_bdeterminate,_ctheme);_prg._percentage = _cpercentage;_prg.addclass(_cclass);self.addprogress(_row,_column,_prg);};this.addpagination= function(_row,_column,_pagination) {if (self==null) self=this;self.removecomponent(_pagination._id);self.addcomponent(_row,_column,_pagination.tostring());};this.addpagination1= function(_row,_column,_cid,_cactive,_cpages,_ctheme,_cclass) {if (self==null) self=this;var _tbl;_tbl= new banano_uoebanano_uoepagination();_tbl.initialize(self._app,_cid,_cpages,_ctheme,_cclass);_tbl._activepagenumber = _cactive;self.addpagination(_row,_column,_tbl);};this.addtextarea= function(_row,_column,_cid,_ciconname,_ctitle,_cplaceholder,_chelpertext,_clength,_ctheme,_cclass) {if (self==null) self=this;var _inp;_inp= new banano_uoebanano_uoeinput();_inp.initialize(self._app,_cid,_ctitle,_cplaceholder,self._app._enuminputtype._textarea,_ctheme);_inp._helpertext = _chelpertext;_inp._iconname = _ciconname;_inp._maxlength = _clength;_inp.addclass(_cclass);self.addinput(_row,_column,_inp);};this.addtelephone= function(_row,_column,_cid,_ciconname,_ctitle,_cplaceholder,_chelpertext,_clength,_ctheme,_cclass) {if (self==null) self=this;var _inp;_inp= new banano_uoebanano_uoeinput();_inp.initialize(self._app,_cid,_ctitle,_cplaceholder,self._app._enuminputtype._tel,_ctheme);_inp._helpertext = _chelpertext;_inp._iconname = _ciconname;_inp._maxlength = _clength;_inp.addclass(_cclass);self.addinput(_row,_column,_inp);};this.addemail= function(_row,_column,_cid,_ciconname,_ctitle,_cplaceholder,_chelpertext,_clength,_ctheme,_cclass) {if (self==null) self=this;var _inp;_inp= new banano_uoebanano_uoeinput();_inp.initialize(self._app,_cid,_ctitle,_cplaceholder,self._app._enuminputtype._email,_ctheme);_inp._helpertext = _chelpertext;_inp._iconname = _ciconname;_inp._maxlength = _clength;_inp.addclass(_cclass);self.addinput(_row,_column,_inp);};this.addtextbox= function(_row,_column,_cid,_ciconname,_ctitle,_cplaceholder,_chelpertext,_clength,_ctheme,_cclass) {if (self==null) self=this;var _inp;_inp= new banano_uoebanano_uoeinput();_inp.initialize(self._app,_cid,_ctitle,_cplaceholder,self._app._enuminputtype._text,_ctheme);_inp._helpertext = _chelpertext;_inp._iconname = _ciconname;_inp._maxlength = _clength;_inp.addclass(_cclass);self.addinput(_row,_column,_inp);};this.addicon1= function(_row,_column,_cid,_ciconname,_ciconsize,_ctheme,_cclass) {if (self==null) self=this;var _icon;_icon= new banano_uoebanano_uoeicon();_icon.initialize(self._app,_cid,_ciconname,_ctheme);_icon._iconsize = _ciconsize;_icon.addclass(_cclass);self.addicon(_row,_column,_icon);};this.addhtml5video1= function(_row,_column,_cid,_curl,_bautoplay,_ballowfullscreen,_bshowcontrols,_bloop,_svideotype,_cclass) {if (self==null) self=this;var _vid1;_vid1= new banano_uoebanano_uoehtml5video();_vid1.initialize(self._app,_cid,_curl);_vid1.addclass(_cclass);_vid1._autoplay = _bautoplay;_vid1._allowfullscreen = _ballowfullscreen;_vid1._videotype = _svideotype;_vid1._showcontrols = _bshowcontrols;_vid1._loopit = _bloop;_vid1._responsive = true;self.addhtml5video(_row,_column,_vid1);};this.addfile1= function(_row,_column,_cid,_ctitle,_cplaceholder,_chelpertext,_bmultiple,_bhideinput,_bfitwidth,_ctheme,_cclass) {if (self==null) self=this;var _fu;_fu= new banano_uoebanano_uoefile();_fu.initialize(self._app,_cid,_ctitle,_cplaceholder,_bmultiple,_ctheme);_fu._helpertext = _chelpertext;_fu.addclass(_cclass);_fu._hideinput = _bhideinput;_fu._fitwidth = _bfitwidth;self.addfile(_row,_column,_fu);};this.addpassword= function(_row,_column,_cid,_ciconname,_ctitle,_cplaceholder,_chelpertext,_clength,_ctheme,_cclass) {if (self==null) self=this;var _inp;_inp= new banano_uoebanano_uoeinput();_inp.initialize(self._app,_cid,_ctitle,_cplaceholder,self._app._enuminputtype._password,_ctheme);_inp._helpertext = _chelpertext;_inp._iconname = _ciconname;_inp._maxlength = _clength;_inp.addclass(_cclass);self.addinput(_row,_column,_inp);};this.addnavbar= function(_row,_column,_nav) {if (self==null) self=this;self.removecomponent(_nav._id);self.addcomponent(_row,_column,_nav.tostring());};this.addparallax= function(_row,_column,_parallax) {if (self==null) self=this;self.removecomponent(_parallax._id);self.addcomponent(_row,_column,_parallax.tostring());};this.addparallax1= function(_row,_column,_cid,_curl,_cclass) {if (self==null) self=this;var _par;_par= new banano_uoebanano_uoeparallax();_par.initialize(self._app,_cid,_curl);_par.addclass(_cclass);self.addparallax(_row,_column,_par);};this.addfeature1= function(_fid,_stitle,_sdescription,_target,_sthemename,_cclass) {if (self==null) self=this;var _md;_md= new banano_uoebanano_uoefeature();_md.initialize(self._app,_fid,_stitle,_sdescription,_sthemename,_target);_md.addclass(_cclass);self.addfeature(_md);};this.addradio1= function(_row,_column,_cid,_cname,_cvalue,_ctitle,_bchecked,_benabled,_bwithgap,_ctheme,_cclass) {if (self==null) self=this;var _radio;_radio= new banano_uoebanano_uoeradio();_radio.initialize(self._app,_cid,_cname,_cvalue,_ctitle,_ctheme);_radio.addclass(_cclass);_radio._withgap = _bwithgap;_radio._checked = _bchecked;_radio._enabled = _benabled;self.addradio(_row,_column,_radio);};this.addradio= function(_row,_column,_radio) {if (self==null) self=this;self.removecomponent(_radio._id);self.addcomponent(_row,_column,_radio.tostring());};this.addvideo1= function(_row,_column,_cid,_curl,_bautoplay,_ballowfullscreen,_frameborder,_bloop,_bshowcontrols,_cclass) {if (self==null) self=this;var _vid1;_vid1= new banano_uoebanano_uoevideo();_vid1.initialize(self._app,_cid,_curl);_vid1.addclass(_cclass);_vid1._autoplay = _bautoplay;_vid1._allowfullscreen = _ballowfullscreen;_vid1._frameborder = _frameborder;_vid1._loopit = _bloop;_vid1._showcontrols = _bshowcontrols;self.addvideo(_row,_column,_vid1);};this.addswitch= function(_row,_column,_switch) {if (self==null) self=this;self.removecomponent(_switch._id);self.addcomponent(_row,_column,_switch.tostring());};this.addswitch1= function(_row,_column,_cid,_ctitle,_context,_cofftext,_bchecked,_benabled,_ctheme,_cclass) {if (self==null) self=this;var _switch;_switch= new banano_uoebanano_uoeswitch();_switch.initialize(self._app,_cid,_ctitle,_context,_cofftext,_ctheme);_switch.addclass(_cclass);_switch._enabled = _benabled;_switch._checked = _bchecked;self.addswitch(_row,_column,_switch);};this.addslider= function(_row,_column,_slider) {if (self==null) self=this;self.removecomponent(_slider._id);self.addcomponent(_row,_column,_slider.tostring());};this.addinput= function(_row,_col,_inp) {if (self==null) self=this;var _script;self.removecomponent(_inp._id);if (_inp._inptype == "textarea") {_script="M.textareaAutoResize(" + self._j + "('#" + _inp._id + "'));";self._app._js.push(_script);if (_inp._maxlength>0) {_script="" + self._j + "('textarea#" + _inp._id + "').characterCounter();";self._app._js.push(_script);}} else {if (_inp._maxlength>0) {_script="" + self._j + "('input#" + _inp._id + "').characterCounter();";self._app._js.push(_script);}}self.addcomponent(_row,_col,_inp.tostring());};this.addimage= function(_row,_col,_img) {if (self==null) self=this;self.removecomponent(_img._id);self.addcomponent(_row,_col,_img.tostring());};this.addicon= function(_row,_col,_icon) {if (self==null) self=this;self.removecomponent(_icon._id);self.addcomponent(_row,_col,_icon.tostring());};this.addhtml5video= function(_row,_col,_video) {if (self==null) self=this;self.removecomponent(_video._id);self.addcomponent(_row,_col,_video.tostring());};this.addvideo= function(_row,_col,_video) {if (self==null) self=this;self.removecomponent(_video._id);self.addcomponent(_row,_col,_video.tostring());};this.addfeature= function(_feat) {if (self==null) self=this;self.removecomponent(_feat._id);self.addcomponent(0,0,_feat.tostring());};this.addfile= function(_row,_col,_elfile) {if (self==null) self=this;self.removecomponent(_elfile._id);self.addcomponent(_row,_col,_elfile.tostring());};this.adddropdown= function(_row,_col,_eldropdown) {if (self==null) self=this;var _dds;self.removecomponent(_eldropdown._id);_dds=_eldropdown.getsettings();self._app._components.push(_dds);self.addcomponent(_row,_col,_eldropdown.tostring());};this.addselect= function(_row,_col,_elselect) {if (self==null) self=this;self.removecomponent(_elselect._id);self.addcomponent(_row,_col,_elselect.tostring());};this.adddatepicker= function(_row,_column,_datepicker) {if (self==null) self=this;var _dps;self.removecomponent(_datepicker._id);_dps=_datepicker.getsettings();self._app._components.push(_dps);self.addcomponent(_row,_column,_datepicker.tostring());};this.addfooter= function(_foot) {if (self==null) self=this;self.removecomponent(_foot._id);self.addcomponent(0,0,_foot.tostring());};this.addlistview= function(_row,_column,_lv) {if (self==null) self=this;self.removecomponent(_lv._id);self.addcomponent(_row,_column,_lv.tostring());};this.addchip= function(_row,_column,_chip) {if (self==null) self=this;self.removecomponent(_chip._id);self.addcomponent(_row,_column,_chip.tostring());};this.addchip1= function(_row,_column,_cid,_ctitle,_cimageurl,_ccanclose,_ctheme,_cclass) {if (self==null) self=this;var _chip;_chip= new banano_uoebanano_uoechip();_chip.initialize(self._app,_cid,_ctitle,_cimageurl,"",_ctheme);_chip._canclose = _ccanclose;_chip.addclass(_cclass);self.addchip(_row,_column,_chip);};this.addcollapsible= function(_row,_column,_rg) {if (self==null) self=this;self.removecomponent(_rg._id);self.addcomponent(_row,_column,_rg.tostring());};this.addcheckboxgroup= function(_row,_column,_rg) {if (self==null) self=this;self.removecomponent(_rg._id);self.addcomponent(_row,_column,_rg.tostring());};this.addcheckbox= function(_row,_column,_checkbox) {if (self==null) self=this;self.removecomponent(_checkbox._id);self.addcomponent(_row,_column,_checkbox.tostring());};this.addcheckbox1= function(_row,_column,_cid,_cvalue,_ctitle,_bchecked,_bfilledin,_benabled,_ctheme,_cclass) {if (self==null) self=this;var _c1;_c1= new banano_uoebanano_uoecheckbox();_c1.initialize(self._app,_cid,_cid,_cvalue,_ctitle,_ctheme);_c1.addclass(_cclass);_c1._checked = _bchecked;_c1._filledin = _bfilledin;_c1._enabled = _benabled;self.addcheckbox(_row,_column,_c1);};this.addcarousel= function(_row,_column,_carousel) {if (self==null) self=this;var _settings;self.removecomponent(_carousel._id);_settings=_carousel.getsettings();self._app._components.push(_settings);self.addcomponent(_row,_column,_carousel.tostring());};this.addtabs= function(_row,_column,_vtab) {if (self==null) self=this;var _dps;self.removecomponent(_vtab._id);_dps=_vtab.getsettings();self._app._components.push(_dps);self.addcomponent(_row,_column,_vtab.tostring());};this.addbreak= function(_row,_column) {if (self==null) self=this;self.addparagraph(_row,_column,"","{BR}","","");};this.addcard= function(_row,_column,_card) {if (self==null) self=this;self.removecomponent(_card._id);self.addcomponent(_row,_column,_card.tostring());};this.addbreadcrumbs= function(_row,_col,_cont) {if (self==null) self=this;self.removecomponent(_cont._id);self.addcomponent(_row,_col,_cont.tostring());};this.addcontainer= function(_row,_column,_cont) {if (self==null) self=this;self.removecomponent(_cont._id);self.addcomponent(_row,_column,_cont.tostring());};this.addbutton= function(_row,_column,_btndef) {if (self==null) self=this;self.removecomponent(_btndef._id);self.addcomponent(_row,_column,_btndef.tostring());self._app.addevent(_btndef._id,"click");};this.addfab= function(_fab) {if (self==null) self=this;var _dps;self.removecomponent(_fab._id);_dps=_fab.getsettings();self._app._components.push(_dps);self.addcomponent(0,0,_fab.tostring());};this.addfab1= function(_fabid,_href,_icon,_svisibility,_icontheme,_fabclass) {if (self==null) self=this;var _fab;_fab= new banano_uoebanano_uoefab();_fab.initialize(self._app,_fabid,_href,_icon,self._app._enumbuttonsize._large,_svisibility,_icontheme);_fab.addclass(_fabclass);self.addfab(_fab);};this.addbutton1= function(_row,_column,_btnid,_btntext,_btnnavigateto,_btntype,_btnicon,_btnsize,_btnfitwidth,_bpulse,_benabled,_btntheme,_cclass) {if (self==null) self=this;var _btn;_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,_btntext,_btntheme);_btn._href = _btnnavigateto;_btn.setbuttontype(_btntype);_btn._size = _btnsize;_btn._pulsing = _bpulse;_btn._enabled = _benabled;_btn.addclass(_cclass);_btn._wavestype = self._app._enumwavestype._light;_btn.addjusticon(_btnicon);_btn._fitwidth = _btnfitwidth;self.addbutton(_row,_column,_btn);};this.addraisedbutton= function(_row,_column,_btnid,_btntext,_btnvisibility,_btnnavigateto,_btntheme,_cclass) {if (self==null) self=this;var _btn;_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,_btntext,_btntheme);_btn._visibility = _btnvisibility;_btn._href = _btnnavigateto;_btn.setbuttontype(self._app._enumbuttontype._raised);_btn._size = self._app._enumbuttonsize._medium;_btn.addclass(_cclass);_btn._fitwidth = false;self.addbutton(_row,_column,_btn);};this.addfloatingbutton= function(_row,_column,_btnid,_btnicon,_btnvisibility,_btnnavigateto,_btntheme,_cclass) {if (self==null) self=this;var _btn;_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,"",_btntheme);_btn._visibility = _btnvisibility;_btn._href = _btnnavigateto;_btn.setbuttontype(self._app._enumbuttontype._floating);_btn._size = self._app._enumbuttonsize._medium;_btn.addclass(_cclass);_btn.addjusticon(_btnicon);_btn._fitwidth = false;self.addbutton(_row,_column,_btn);};this.getfloatingbutton= function(_btnid,_btnicon,_btntheme,_cclass) {if (self==null) self=this;var _btn;_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,"",_btntheme);_btn.setbuttontype(self._app._enumbuttontype._floating);_btn._size = self._app._enumbuttonsize._medium;_btn.addclass(_cclass);_btn.addjusticon(_btnicon);_btn._fitwidth = false;self.removecomponent(_btnid);return _btn;};this.addflatbutton= function(_row,_column,_btnid,_btntext,_btnvisibility,_btnnavigateto,_btntheme,_cclass) {if (self==null) self=this;var _btn;_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,_btntext,_btntheme);_btn._visibility = _btnvisibility;_btn._href = _btnnavigateto;_btn.setbuttontype(self._app._enumbuttontype._flat);_btn._size = self._app._enumbuttonsize._medium;_btn.addclass(_cclass);_btn._fitwidth = false;self.addbutton(_row,_column,_btn);};this.addtoc= function(_row,_column,_tbl) {if (self==null) self=this;self.removecomponent(_tbl._id);self.addcomponent(_row,_column,_tbl.tostring());};this.addlabel= function(_row,_column,_lbl) {if (self==null) self=this;var _scode;self.removecomponent(_lbl._id);_scode=_lbl.tostring();_scode = _scode.split("\n").join("");self.addcomponent(_row,_column,_scode);};this.addparagraph= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"p",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh1= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h1",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh2= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h2",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh3= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h3",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh4= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h4",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh5= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h5",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addh6= function(_row,_column,_paraid,_paratext,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h6",_paratext,_paratheme,_cclass);_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addhiddenparagraph= function(_row,_column,_paraid,_paratext) {if (self==null) self=this;var _ml;_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"p",_paratext,"","");_ml._visibility = "hide";self.removecomponent(_paraid);self.addcomponent(_row,_column,_ml.tostring());};this.addblockquote= function(_row,_column,_paraid,_paratext,_parawidth,_paratheme,_cclass) {if (self==null) self=this;var _ml;var _scode;_paraid = _paraid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_paraid,"h5",_paratext,_paratheme,_cclass);_ml._blockquote = true;_ml._blockquotewidth = _parawidth;_scode=_ml.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_paraid);self.addcomponent(_row,_column,_scode);};this.addlink= function(_row,_column,_lnkid,_lnktext,_lnkurl) {if (self==null) self=this;var _a;var _scode;_a= new banano_uoebanano_uoehtml();_a.initialize(_lnkid,"a");_a.sethref(_lnkurl).addcontent(_lnktext);_scode=_a.tostring();_scode = _scode.split("\n").join("");self.removecomponent(_lnkid);self.addcomponent(_row,_column,_scode);};this.adddivider= function(_row,_column,_ctheme) {if (self==null) self=this;var _dkey;var _div;self._divcounter = self._divcounter+1;_dkey="divider" + self._divcounter + "";_div= new banano_uoebanano_uoedivider();_div.initialize(self._app,_dkey,_ctheme);self.addcomponent(_row,_column,_div.tostring());};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addstyleattributeoncondition= function(_bcondition,_attr,_value) {if (self==null) self=this;self._element.removestyle(_attr);if (_bcondition == true) {self.addstyleattribute(_attr,_value);}return self;};this.addrowsmv= function(_rows2add,_margintoppx,_marginbottompx,_rvisibility,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,0,0,0,0,0,0,_themename,_rvisibility,_classname);return self._grid;};this.addrowsmv2= function(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,_rvisibility,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,0,0,0,0,_themename,_rvisibility,_classname);return self._grid;};this.addrowsm2= function(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,0,0,0,0,_themename,"",_classname);return self._grid;};this.addrowsm= function(_rows2add,_margintoppx,_marginbottompx,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,0,0,0,0,0,0,_themename,"",_classname);return self._grid;};this.addrowsv= function(_rows2add,_rvisibility,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,0,20,0,0,0,0,0,0,_themename,_rvisibility,_classname);return self._grid;};this.addrows= function(_rows2add,_themename,_classname) {if (self==null) self=this;self._grid.addrowsmpv(_rows2add,0,20,0,0,0,0,0,0,_themename,"",_classname);return self._grid;};this.addelement= function(_el) {if (self==null) self=this;var _scode;if (_el!=null) {_scode=_el.tostring();self.removecomponent(_el._id);self._element.addcontent(_scode);}};this.refresh= function() {if (self==null) self=this;var _grd;_grd=self._grid.tostring();self._element.addcontent(_grd);};this.addrowclass= function(_rowpos,_classname) {if (self==null) self=this;self._grid.setrowclass(_rowpos,_classname);return self;};this.setrowmargins= function(_rowpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;self._grid.setrowmargins(_rowpos,_margintop,_marginbottom,_marginleft,_marginright);return self;};this.setrowpadding= function(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;self._grid.setrowpadding(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);return self;};this.setcolumnpadding= function(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;self._grid.setcolumnpadding(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);return self;};this.setcolumnmargins= function(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;self._grid.setcolumnmargins(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright);return self;};this.setrowmargins1= function(_rowpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;self._grid.setrowmargins1(_rowpos,_margintop,_marginbottom,_marginleft,_marginright);return self;};this.setcolumnmargins1= function(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;self._grid.setcolumnmargins1(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright);return self;};this.addcolumnclass= function(_rowpos,_columnpos,_classname) {if (self==null) self=this;self._grid.setcolumnclass(_rowpos,_columnpos,_classname);return self;};this.setrowpadding1= function(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;self._grid.setrowpadding1(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);return self;};this.setcolumnpadding1= function(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;self._grid.setcolumnpadding1(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright);return self;};this.initialize= function(_thisapp,_mvarid,_bcenterinpage,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _mvarid.toLowerCase();self._centerinpage = _bcenterinpage;self._element.initialize(self._id,"div");self._element.addclassoncondition(_bcenterinpage,"container");self._items.length=0;self._items.length=0;self._enabled = true;self._theme = _themename;self._app.materialusetheme(_themename,self._element);self._grid.initialize(self._app,_mvarid);self._visibility = "";self._zdepth = "";self._scrollspy = false;self._section = false;self._divcounter = 0;self._j = "$";};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattr(_attr);return self;};this.tostring= function() {if (self==null) self=this;self.refresh();self._element.addclassoncondition(self._scrollspy,"scrollspy");self._element.addclassoncondition(self._section,"section");self._element._id = self._id;self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._element.removeclassoncondition(self._section,"container");return self._element.tostring();};this.addcontent= function(_scontent) {if (self==null) self=this;self._element.addcontent(_scontent);return self;};this.addcomponent= function(_rowpos,_colpos,_elhtml) {if (self==null) self=this;if (_rowpos == 0 && _colpos == 0) {self.addcontent(_elhtml);} else {self._grid.addcomponent(_rowpos,_colpos,_elhtml);}};this.addrange1= function(_row,_column,_rngid,_rngcaption,_lmin,_lmax,_lvalue,_lstep,_ltheme,_cclass) {if (self==null) self=this;var _range;_range= new banano_uoebanano_uoerange();_range.initialize(self._app,_rngid,_rngcaption,_lmin,_lmax,_lvalue,_lstep,_ltheme);_range.addclass(_cclass);self.addrange(_row,_column,_range);};this.adddatepicker1= function(_row,_column,_cid,_ciconname,_ctitle,_ctheme,_cclass) {if (self==null) self=this;var _dp;_dp= new banano_uoebanano_uoedatepicker();_dp.initialize(self._app,_cid,_ctitle,self._app._enumdatetimetype._datepicker,_ctheme);_dp._showclearbtn = true;_dp._datetimeformat = "YYYY-MM-DD";_dp._iconname = _ciconname;_dp.addclass(_cclass);self.adddatepicker(_row,_column,_dp);};this.addtimepicker1= function(_row,_column,_cid,_ciconname,_ctitle,_ctheme,_cclass) {if (self==null) self=this;var _dp1;_dp1= new banano_uoebanano_uoedatepicker();_dp1.initialize(self._app,_cid,_ctitle,self._app._enumdatetimetype._timepicker,_ctheme);_dp1._showclearbtn = true;_dp1._iconname = _ciconname;_dp1.addclass(_cclass);self.adddatepicker(_row,_column,_dp1);};this.addcontentlist= function(_lst) {if (self==null) self=this;var _strcontent;for (var _strcontentindex=0;_strcontentindex<_lst.length;_strcontentindex++) {_strcontent=_lst[_strcontentindex];self.addcontent(_strcontent);}};this.addcontentlistreverse= function(_lst) {if (self==null) self=this;var _ltot;var _lcnt;var _strcontent;_ltot=_lst.length-1;_lcnt=0;for (_lcnt=_ltot;_lcnt>=0;_lcnt-=1) {_strcontent=_lst[_lcnt];self.addcontent(_strcontent);}};this.addimage1= function(_row,_column,_imgid,_imgurl,_imgalt,_imgcircle,_imgzdepth,_bstatic,_bfixsize,_bresponsive,_imgheight,_imgwidth,_cclass,_cvisibility) {if (self==null) self=this;var _imgx;_imgid = _imgid.toLowerCase();_imgx= new banano_uoebanano_uoeimage();_imgx.initialize(self._app,_imgid,_imgurl,_imgalt,_bstatic);_imgx._zdepth = _imgzdepth;_imgx._circle = _imgcircle;_imgx._responsive = _bresponsive;_imgx._materialboxed = _bresponsive;_imgx.addclass(_cclass);_imgx._visibility = _cvisibility;if (_bfixsize) {_imgx.setsize(_imgheight,_imgwidth);}self.addimage(_row,_column,_imgx);};}function banano_uoebanano_uoecopyrights() {var self;this._app= new banano_uoebanano_uoeapp();this._copyright='';this._links=[];this._element= new banano_uoebanano_uoehtml();this._theme='';this._visibility='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_stheme,_sclass) {if (self==null) self=this;self._app = _thisapp;self._theme = _stheme;self._copyright = self._app._copyrights;self._element.initialize("","div");self._element.addclass("footer-copyright").addclass(_sclass);self._links.length=0;self._links.length=0;};this.addtermsandconditions= function() {if (self==null) self=this;self.addlink("footerts","Terms and Conditions{NBSP}|",self._app._termsandconditionsurl,"");return self;};this.adddisclaimer= function() {if (self==null) self=this;self.addlink("footerdisclaimer","{NBSP}Disclaimer{NBSP}|",self._app._disclaimerurl,"");return self;};this.addprivacypolicy= function() {if (self==null) self=this;self.addlink("footerprivacy","{NBSP}Privacy Policy",self._app._privacypolicyurl,"");return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.addlink= function(_lnkid,_lnktext,_lnkurl,_lnktheme) {if (self==null) self=this;var _a;_a= new banano_uoebanano_uoeanchoricon();_a.initialize(self._app,_lnkid,"","",false,_lnktext,_lnkurl,true,_lnktheme,"");_a._a.addclass("right");self._links.push(_a.tostring());return self;};this.tostring= function() {if (self==null) self=this;var _pcont;self._app.materialusetheme(self._theme,self._element);self._element.materialvisibility(self._visibility);_pcont= new banano_uoebanano_uoehtml();_pcont.initialize("","div");_pcont.addclass("container");self._app.materialusetheme(self._theme,_pcont);if (self._copyright!="") {_pcont.addcontent("© ").addcontent(self._copyright);}_pcont.addcontentlistreverse(self._links);self._element.addelement(_pcont);return self._element.html();};}function banano_uoebanano_uoedatepicker() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._title='';this._theme='';this._enabled=false;this._iconname='';this._visibility='';this._element= new banano_uoebanano_uoehtml();this._displaytype='';this._autoclose=false;this._datetimeformat='';this._defaultdate='';this._setdefaultdate=false;this._disableweekends=false;this._firstday=0;this._yearrange=0;this._showmonthafteryear=false;this._showdaysinnextandpreviousmonths=false;this._showclearbtn=false;this._twelvehour=false;this._defaulttime='';this._vibrate=false;this._timeformat='';this._timeview='';this._instance='';this._settings='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);};this.initialize= function(_thisapp,_sid,_stitle,_sdisplaytype,_stheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._enabled = true;self._element.initialize(self._id,"input");self._element.settype("text");self._displaytype = _sdisplaytype;self._autoclose = false;self._datetimeformat = "yyyy-mm-dd";self._timeformat = "HH:mm";self._title = _stitle;self._theme = _stheme;self._enabled = true;self._iconname = "";self._defaultdate = "now";self._disableweekends = false;self._firstday = 0;self._yearrange = 10;self._showmonthafteryear = true;self._showdaysinnextandpreviousmonths = true;self._showclearbtn = true;self._defaulttime = "now";self._vibrate = true;self._twelvehour = false;self._setdefaultdate = true;self._timeview = "hours";self._instance = "" + self._id + "inst";};this.getsettings= function() {if (self==null) self=this;var _dpsettings;var _strds;_dpsettings={};_dpsettings={};_dpsettings={};_dpsettings["id"]=self._id;_dpsettings["instance"]=self._displaytype;_dpsettings["displayType"]=self._displaytype;_dpsettings["showClearBtn"]=self._showclearbtn;_dpsettings["showDaysInNextAndPreviousMonths"]=self._showdaysinnextandpreviousmonths;_dpsettings["showMonthAfterYear"]=self._showmonthafteryear;_dpsettings["yearRange"]=self._yearrange;_dpsettings["firstDay"]=self._firstday;_dpsettings["disableWeekends"]=self._disableweekends;_dpsettings["setDefaultDate"]=self._setdefaultdate;_dpsettings["format"]=self._datetimeformat;_dpsettings["autoClose"]=self._autoclose;_dpsettings["twelveHour"]=self._twelvehour;_dpsettings["defaultTime"]=self._defaulttime;_dpsettings["vibrate"]=self._vibrate;_dpsettings["TimeView"]=self._timeview;_strds=self._app.map2json(_dpsettings);return _strds;};this.tostring= function() {if (self==null) self=this;var _div;var _lbl;self._element.materialenable(self._enabled);self._app.materialusetheme(self._theme,self._element);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addclass(self._displaytype);_div= new banano_uoebanano_uoehtml();_div.initialize(self._id+"div","div");_div.addclass("input-field");_div.addclass("col").addclass("s12").addclass("m12").addclass("l12");_div.addelement(self._element);_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id).addcontent(self._title).addclass("active");_div.addelement(_lbl);switch ("" + self._displaytype) {case "" + self._app._enumdatetimetype._datepicker:break;case "" + self._app._enumdatetimetype._timepicker:break;}return _div.html();};this.getdate= function(_varname) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + _varname + " = " + self._instance + ".toString();";return _script;};this.gettime= function(_varname) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Timepicker.getInstance(inst" + self._id + "); \n	" + _varname + " = " + self._instance + ".time();";return _script;};this.setdate= function(_varname) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + self._instance + ".setDate(" + _varname + ");";return _script;};this.gotodate= function(_varname) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Datepicker.getInstance(inst" + self._id + "); \n	" + self._instance + ".gotoDate(" + _varname + ");";return _script;};}function banano_uoebanano_uoedivider() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._visibility='';this._theme='';this._element= new banano_uoebanano_uoehtml();this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_sid,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._visibility = "";self._theme = _themename;self._element.initialize(_sid,"div");self._element.addclass("divider");};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.materialvisibility(self._visibility);return self._element.tostring();};}function banano_uoebanano_uoedropdown() {var self;this._id='';this._text='';this._iconname='';this._theme='';this._dp= new banano_uoebanano_uoehtml();this._a= new banano_uoebanano_uoehtml();this._app= new banano_uoebanano_uoeapp();this._zdepth='';this._visibility='';this._enabled=false;this._dropdownitems={};this._isbutton=false;this._hoverable=false;this._constrainwidth=false;this._covertrigger=false;this._closeonclick=false;this._hover=false;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._dp.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._dp.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._dp.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._dp.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._dp.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_itemid,_itemtext,_itemvisibility,_bisbutton,_bconstrainwidth,_itemtheme) {if (self==null) self=this;var _lst;self._app = _thisapp;self._id = _itemid.toLowerCase();self._text = _itemtext;self._iconname = "keyboard_arrow_right";self._theme = _itemtheme;self._dp.initialize(self._id+"li","li");self._a.initialize(self._id,"a");self._app.materialusetheme(_itemtheme,self._a);self._a.materialvisibility(_itemvisibility);self._a.addclass("dropdown-trigger").addattribute("href","#");self._a.addattribute("data-target",self._id+"items");self._constrainwidth = _bconstrainwidth;self._isbutton = _bisbutton;if (_bisbutton == false) {self._a.addstyleattribute("text-align","center");}self._zdepth = "";self._visibility = _itemvisibility;self._covertrigger = false;self._enabled = true;self._dropdownitems={};self._dropdownitems={};self._closeonclick = true;self._hover = true;_lst=[];_lst.length=0;_lst.length=0;self._dropdownitems[self._id]=_lst;self._instance = "" + self._id + "inst";};this.addcontent= function(_scontent) {if (self==null) self=this;self._dp.addcontent(_scontent);return self;};this.adddivider= function(_themename) {if (self==null) self=this;var _div;var _lstitems;_div= new banano_uoebanano_uoehtml();_div.initialize("","li");_div.addclass("divider");self._app.materialusetheme(_themename,_div);if ((self._id in self._dropdownitems)) {_lstitems=self._dropdownitems[self._id];_lstitems.push(_div.html());self._dropdownitems[self._id]=_lstitems;}return self;};this.additem= function(_itemid,_itemicon,_itemtext,_itemnavigateto,_bhasdivider,_itemactive,_itemtheme) {if (self==null) self=this;var _dpi;var _lstitems;_itemid = _itemid.toLowerCase();_dpi= new banano_uoebanano_uoedropdownitem();_dpi.initialize(self._app,self._id,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_itemtheme);_banano_uoebanano_moduoe.materialaddbadge(self._app,_dpi._ai._a,"",false,self._app._enumvisibility._hide,true,"",false);_dpi._li.materialadddivideroncondition(_bhasdivider,self._app._enumvisibility._visible,_itemtheme);if ((self._id in self._dropdownitems)) {_lstitems=self._dropdownitems[self._id];_lstitems.push(_dpi.tostring());self._dropdownitems[self._id]=_lstitems;}};this.additembadge= function(_itemid,_itemtext,_href,_itemactive,_badgetext,_badgenew,_bhasdivider,_itemtheme,_badgetheme) {if (self==null) self=this;var _dpi;var _lstitems;_itemid = _itemid.toLowerCase();_dpi= new banano_uoebanano_uoedropdownitem();_dpi.initialize(self._app,self._id,_itemid,"",_itemtext,_href,_itemactive,_itemtheme);_banano_uoebanano_moduoe.materialaddbadge(self._app,_dpi._ai._a,_badgetext,_badgenew,self._app._enumvisibility._visible,true,_badgetheme,false);_dpi._li.materialadddivideroncondition(_bhasdivider,self._app._enumvisibility._visible,_itemtheme);if ((self._id in self._dropdownitems)) {_lstitems=self._dropdownitems[self._id];_lstitems.push(_dpi.tostring());self._dropdownitems[self._id]=_lstitems;}};this.getstructure= function(_sout) {if (self==null) self=this;var _mains;var _sb;var _kcnt;var _ktot;var _drpitem;var _lstx;var _stritem;var _sb1;_mains='';_mains = _sout;_sb=new StringBuilder();_sb.isinitialized=true;_kcnt=0;_ktot=Object.keys(self._dropdownitems).length-1;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_drpitem=banano_getB4JKeyAt(self._dropdownitems,_kcnt);_lstx=self._dropdownitems[_drpitem];_sb=new StringBuilder();_sb.isinitialized=true;for (var _stritemindex=0;_stritemindex<_lstx.length;_stritemindex++) {_stritem=_lstx[_stritemindex];_sb.append(_stritem);}_sb1=_sb.toString();_mains = _mains.split(_drpitem+"dropitems").join(_sb1);}return _mains;};this.open= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".open();";return _script;};this.close= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".close();";return _script;};this.destroy= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".destroy();";return _script;};this.recalculatedimensions= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".recalculateDimensions();";return _script;};this.focusedindex= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = " + self._instance + ".focusedIndex;";return _script;};this.dropdownel= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = " + self._instance + ".dropdownEl;";return _script;};this.isopen= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = " + self._instance + ".isOpen;";return _script;};this.tostring= function() {if (self==null) self=this;var _ul;var _sout;self._a._id = self._id;self._a.materialvisibility(self._visibility);self._a.materialzdepth(self._zdepth);self._a.materialenable(self._enabled);self._a.materialbutton(self._isbutton);self._a.addcontent(self._text);_banano_uoebanano_moduoe.materialaddicon(self._app,self._a,self._iconname,"right",self._theme,false,false,false,false,false);self._app.materialusetheme(self._theme,self._a);self._dp.addelement(self._a);_ul= new banano_uoebanano_uoehtml();_ul.initialize(self._id+"items","ul");_ul.addclass("dropdown-content");_ul.addcontent(self._id+"dropitems");self._dp.addelement(_ul);self._dp.setelementtypeoncondition(self._isbutton,"div");_sout=self._dp.html();_sout = self.getstructure(_sout);_sout = _sout.split("\n").join("");self._app.applytooltip(self._id,self._dp);return _sout;};this.injectjs= function() {if (self==null) self=this;};this.getsettings= function() {if (self==null) self=this;var _mset;var _sset;_mset={};_mset={};_mset={};_mset["id"]=self._id;_mset["instance"]="dropdown";_mset["hover"]=self._hover;_mset["closeOnClick"]=self._closeonclick;_mset["coverTrigger"]=self._covertrigger;_mset["constrainWidth"]=self._constrainwidth;_sset=self._app.map2json(_mset);return _sset;};}function banano_uoebanano_uoesliderorientation() {var self;this._horizontal="horizontal";this._vertical="vertical";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoedropdownitem() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._li= new banano_uoebanano_uoehtml();this._theme='';this._itemkey='';this._href='';this._text='';this._enabled=false;this._icon='';this._ai= new banano_uoebanano_uoeanchoricon();this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._ai.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._ai.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._ai.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._ai.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._ai.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_parentid,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_itemtheme) {if (self==null) self=this;self._app = _thisapp;_parentid = _parentid.toLowerCase();_itemid = _itemid.toLowerCase();self._id = _itemid;self._icon = _itemicon;self._itemkey = _parentid+_itemid;self._href = _itemnavigateto;self._text = _itemtext;self._li.initialize(self._itemkey+"li","li");if (_itemactive == true) {self._li.addclass("active");}self._theme = _itemtheme;self._enabled = false;self._ai.initialize(self._app,self._itemkey,self._icon,"left",false,self._text,self._href,true,self._theme,"");self._ai._a.materialenable(self._enabled);return self._li;};this.settooltip= function(_position,_delay,_tooltip) {if (self==null) self=this;self._ai._a.materialsettooltip(_position,_delay,_tooltip);};this.tostring= function() {if (self==null) self=this;self._ai._id = self._itemkey;self._ai._text = self._text;self._ai._href = self._href;self._ai._a.materialenable(self._enabled);self._app.materialusetheme(self._theme,self._ai._a);self._li.addcontent(self._ai.tostring());return self._li.html();};}function banano_uoebanano_uoefab() {var self;this._ai= new banano_uoebanano_uoeanchoricon();this._id='';this._app= new banano_uoebanano_uoeapp();this._href='';this._iconname='';this._icontheme='';this._theme='';this._pulse=false;this._zdepth='';this._visibility='';this._size='';this._click2toggle=false;this._buttons=[];this._direction='';this._hoverenabled=false;this._toolbarenabled=false;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._ai.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_shref,_siconname,_ssize,_svisibility,_sicontheme) {if (self==null) self=this;if (_sicontheme == "") {_sicontheme = "white.lb";}self._app = _thisapp;self._id = _sid.toLowerCase();self._iconname = _siconname;self._icontheme = _sicontheme;self._href = _shref;self._zdepth = "";self._size = _ssize;self._click2toggle = false;self._ai.initialize(self._app,self._id,self._iconname,"",false,"",self._href,false,_sicontheme,"");self._ai._floating = true;self._theme = _sicontheme;self._direction = self._app._enumfabdirection._top;self._visibility = _svisibility;self._hoverenabled = true;self._toolbarenabled = false;self._buttons.length=0;self._buttons.length=0;self._instance = "" + self._id + "inst";};this.addclass= function(_sclass) {if (self==null) self=this;self._ai.addclass(_sclass);if (_sclass.contains("pulse")) {self._pulse = true;}return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._ai.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._ai.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._ai.removeattribute(_attr);return self;};this.addbutton= function(_btnid,_btnicon,_btnnav2,_btntheme) {if (self==null) self=this;var _li;var _b;_li= new banano_uoebanano_uoehtml();_li.initialize("","li");_b= new banano_uoebanano_uoebutton();_b.initialize(self._app,_btnid,"",_btntheme);_b.setbuttontype(self._app._enumbuttontype._floating);_b._href = _btnnav2;_b.addicon(_btnicon,"",_btntheme,false,false);_b._waveseffect = false;_b._fitwidth = false;_li.addcontent(_b.tostring());self._buttons.push(_li.html());};this.tostring= function() {if (self==null) self=this;self._ai._id = self._id;if (self._theme == "") {self._theme = self._app._theme;}self._ai._a._id = self._id;_banano_uoebanano_moduoe.materialaddicon(self._app,self._ai._a,self._iconname,"",self._icontheme,true,false,false,false,false);self._ai._a.materialpulse(self._pulse);self._ai._a.materialvisibility(self._visibility);self._ai._a.materialbuttonsize(self._size);self._ai._click2toggle = self._click2toggle;self._ai._horizontal = self._toolbarenabled;self._ai._buttons = self._buttons;self._ai._isfab = true;self._ai._istoolbar = self._toolbarenabled;self._app.applytooltip(self._id,self._ai._a);return self._ai.tostring();};this.open= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "div'); \n	var " + self._instance + " = M.FloatingActionButton.getInstance(inst" + self._id + "); \n	" + self._instance + ".open();";eval(_script);};this.close= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "div'); \n	var " + self._instance + " = M.FloatingActionButton.getInstance(inst" + self._id + "); \n	" + self._instance + ".close();";eval(_script);};this.getsettings= function() {if (self==null) self=this;var _dpsettings;var _strds;_dpsettings={};_dpsettings={};_dpsettings={};_dpsettings["id"]=self._id;_dpsettings["instance"]="floatingActionButton";_dpsettings["hoverEnabled"]=self._hoverenabled;_dpsettings["direction"]=self._direction;_dpsettings["toolbarEnabled"]=self._toolbarenabled;_strds=self._app.map2json(_dpsettings);return _strds;};}function banano_uoebanano_uoefeature() {var self;this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._enabled=false;this._id='';this._theme='';this._visibility='';this._zdepth='';this._title='';this._description='';this._ttc= new banano_uoebanano_uoehtml();this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_mvarid,_stitle,_sdescription,_sthemename,_targetfab) {if (self==null) self=this;_targetfab = _targetfab.toLowerCase();self._app = _thisapp;self._id = _mvarid.toLowerCase();self._element.initialize(self._id,"div");self._element.addclass("tap-target");self._element.addattribute("data-target",_targetfab);self._ttc.initialize("","div");self._ttc.addclass("tap-target-content");self._enabled = true;self._theme = _sthemename;self._visibility = "";self._zdepth = "";self._title = _stitle;self._description = _sdescription;};this.tostring= function() {if (self==null) self=this;self._ttc.addheading(5,self._title);self._ttc.addparagraph(self._description);self._app.materialusetheme(self._theme,self._ttc);self._element._id = self._id;self._element.sethref("");self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addelement(self._ttc);return self._element.html();};this.open= function() {if (self==null) self=this;var _f;_f=null;_f = self._app._jq("#" + self._id + "");_f["tapTarget"]("open");};this.close= function() {if (self==null) self=this;var _f;_f=null;_f = self._app._jq("#" + self._id + "");_f["tapTarget"]("close");};}function banano_uoebanano_uoefile() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._fu= new banano_uoebanano_uoehtml();this._placeholder='';this._hoverable=false;this._theme='';this._enabled=false;this._zdepth='';this._visibility='';this._onchange='';this._fixcell=false;this._validate=false;this._helpertext='';this._errormsg='';this._successmsg='';this._btn= new banano_uoebanano_uoehtml();this._fpw= new banano_uoebanano_uoehtml();this._help= new banano_uoebanano_uoehtml();this._hideinput=false;this._fitwidth=false;this._title='';this._multiple=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._fu.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_splaceholder,_bmultiple,_stheme) {if (self==null) self=this;self._app = _thisapp;if (_stheme == "") {_stheme = self._app._theme;}self._id = _sid.toLowerCase();self._placeholder = _splaceholder;self._theme = _stheme;self._enabled = true;self._errormsg = "Error";self._successmsg = "Success";self._helpertext = "";self._onchange = "";self._hideinput = false;self._fitwidth = false;self._title = _stitle;self._theme = _stheme;self._multiple = _bmultiple;};this.addclass= function(_sclass) {if (self==null) self=this;self._fu.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._fu.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._fu.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._fu.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _spn;var _inp;var _fa;if (self._fitwidth) {self._hideinput = true;}if (self._hideinput) {self._helpertext = "";}self._help.initialize(self._id+"-span","span");self._help.addclass("helper-text");self._fu.initialize(self._id+"div","div");self._fu.addclass("file-field");self._fu.addclass("input-field");self._fu.addclass("col");self._fu.addclass("s12");self._fu.addclass("m12");self._fu.addclass("l12");self._btn.initialize(self._id+"btn","div");self._btn.addclass("btn");self._btn.addstyleattributeoncondition(self._fitwidth,"width","100%");_spn= new banano_uoebanano_uoehtml();_spn.initialize(self._id+"-span","span");_spn.addcontent(self._title);self._btn.addelement(_spn);_inp= new banano_uoebanano_uoehtml();_inp.initialize(self._id,"input");_inp.settype("file");_inp.addlooseattributeoncondition(self._multiple,"multiple");self._btn.addelement(_inp);self._app.materialusetheme(self._theme,self._btn);self._fu.addelement(self._btn);self._fpw.initialize("","div");self._fpw.addclass("file-path-wrapper");self._fu.materialvisibility(self._visibility);self._fu.materialhoverable(self._hoverable);self._fu.materialzdepth(self._zdepth);self._app.applytooltip(self._id,self._fu);self._help.addattribute("data-error",self._errormsg);self._help.addattribute("data-success",self._successmsg);self._help.addcontent(self._helpertext);_inp= new banano_uoebanano_uoehtml();_inp.initialize("","input");_inp.addclass("file-path");_inp.addclassoncondition(self._validate,"validate");_inp.settype("text");_inp.addattribute("placeholder",self._placeholder);_inp.addstyleattributeoncondition(self._hideinput,"display","none");self._fpw.addelement(_inp);_fa= new banano_uoebanano_uoehtml();_fa.initialize("","form");_fa.addattribute("action","#");_fa.addelement(self._fu);return _fa.html();};}function banano_uoebanano_uoefooter() {var self;this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._theme='';this._visibility='';this._fixedfooter=false;this._content= new banano_uoebanano_uoecontainer();this._hascopyrights=false;this._fcenter=false;this._id='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_bcenter,_bfixedfooter,_bhascopyrights,_stheme,_sclass) {if (self==null) self=this;self._id = "footer";self._app = _thisapp;self._theme = _stheme;self._element.initialize("footer","footer");self._element.addclass("page-footer");self._content.initialize(self._app,"footer-content",_bcenter,_stheme);self._app.materialusetheme(_stheme,self._element);self._hascopyrights = _bhascopyrights;self._fixedfooter = _bfixedfooter;self._fcenter = _bcenter;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _foot;self._element.addcontent(self._content.tostring());if (self._hascopyrights) {_foot= new banano_uoebanano_uoecopyrights();_foot.initialize(self._app,"pgcopyrights",self._theme);_foot.addtermsandconditions();_foot.adddisclaimer();_foot.addprivacypolicy();self._element.addcontent(_foot.tostring());}return self._element.tostring();};}function banano_uoebanano_uoegrid() {var self;this._rows={};this._columns={};this._lastrow=0;this._colclass={"s":"s", "m":"m", "l":"l"};this._padclass={"pt":"padding-top:", "pb":"padding-bottom:", "pl":"padding-left:", "pr":"padding-right:"};this._marclass={"mt":"margin-top:", "mb":"margin-bottom:", "ml":"margin-left:", "mr":"margin-right:"};this._offclass={"s":"offset-s", "m":"offset-m", "l":"offset-l"};this._rc={};this._rowclass="row";this._cellclass="col";this._showid=false;this._parentid='';this._components={};this._rowclasses={};this._columnclasses={};this._app= new banano_uoebanano_uoeapp();this._rowpadding={};this._rowmargins={};this.cstr= function(_o) {if (self==null) self=this;return ""+_o;};this.addrowsmv= function(_rows2add,_margintoppx,_marginbottompx,_rvisibility,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,0,0,0,0,0,0,_themename,_rvisibility,_classname);return self;};this.addrowsmv2= function(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,_rvisibility,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,0,0,0,0,_themename,_rvisibility,_classname);return self;};this.addrowsm2= function(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,_marginleftpx,_marginrightpx,0,0,0,0,_themename,"",_classname);return self;};this.addrowsm= function(_rows2add,_margintoppx,_marginbottompx,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,_margintoppx,_marginbottompx,0,0,0,0,0,0,_themename,"",_classname);return self;};this.addrowsv= function(_rows2add,_rvisibility,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,0,20,0,0,0,0,0,0,_themename,_rvisibility,_classname);return self;};this.addrows= function(_rows2add,_themename,_classname) {if (self==null) self=this;self.addrowsmpv(_rows2add,0,20,0,0,0,0,0,0,_themename,"",_classname);return self;};this.setrowclass= function(_rowpos,_classname) {if (self==null) self=this;var _rowc;var _rowkey;_rowc={};_rowkey="r" + _rowpos + "";if ((_rowkey in self._rowclasses)) {_rowc = self._rowclasses[_rowkey];} else {_rowc={};_rowc={};}_rowc[_classname]=_classname;self._rowclasses[_rowkey]=_rowc;};this.setcolumnmargins= function(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;var _srow;var _scol;var _rowkey;var _rowcy;_srow=self.cstr(_rowpos);_scol=self.cstr(_colpos);_rowkey="r" + _srow + "c" + _scol + "";_rowcy={"mt":self.cstr(_margintop), "mb":self.cstr(_marginbottom), "ml":self.cstr(_marginleft), "mr":self.cstr(_marginright)};self._rowmargins[_rowkey]=_rowcy;};this.setrowmargins= function(_rowpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;var _srow;var _rowkey;var _rowcb;_srow=self.cstr(_rowpos);_rowkey="r" + _srow + "";_rowcb={"mt":self.cstr(_margintop), "mb":self.cstr(_marginbottom), "ml":self.cstr(_marginleft), "mr":self.cstr(_marginright)};self._rowmargins[_rowkey]=_rowcb;};this.setcolumnpadding= function(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;var _srow;var _scol;var _rowkey;var _rowcx;_srow=self.cstr(_rowpos);_scol=self.cstr(_colpos);_rowkey="r" + _srow + "c" + _scol + "";_rowcx={"pt":self.cstr(_paddingtop), "pb":self.cstr(_paddingbottom), "pl":self.cstr(_paddingleft), "pr":self.cstr(_paddingright)};self._rowpadding[_rowkey]=_rowcx;};this.setcolumnpadding1= function(_rowpos,_colpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;var _srow;var _scol;var _rowkey;var _rowcx;var _str;var _el;_srow=self.cstr(_rowpos);_scol=self.cstr(_colpos);_rowkey="#" + self._parentid + "r" + _srow + "c" + _scol + "";_rowcx={};_rowcx={};_rowcx={};_rowcx["padding-top"]=self.cstr(_paddingtop)+"px";_rowcx["padding-bottom"]=self.cstr(_paddingbottom)+"px";_rowcx["padding-left"]=self.cstr(_paddingleft)+"px";_rowcx["padding-right"]=self.cstr(_paddingright)+"px";_str=self._app.map2json(_rowcx);_el=null;_el = u(_rowkey);_el.css(JSON.parse(_str));};this.setrowpadding1= function(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;var _srow;var _rowkey;var _rowcx;var _str;var _el;_srow=self.cstr(_rowpos);_rowkey="#" + self._parentid + "r" + _srow + "";_rowcx={};_rowcx={};_rowcx={};_rowcx["padding-top"]=self.cstr(_paddingtop)+"px";_rowcx["padding-bottom"]=self.cstr(_paddingbottom)+"px";_rowcx["padding-left"]=self.cstr(_paddingleft)+"px";_rowcx["padding-right"]=self.cstr(_paddingright)+"px";_str=self._app.map2json(_rowcx);_el=null;_el = u(_rowkey);_el.css(JSON.parse(_str));};this.setcolumnmargins1= function(_rowpos,_colpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;var _srow;var _scol;var _rowkey;var _rowcx;var _str;var _el;_srow=self.cstr(_rowpos);_scol=self.cstr(_colpos);_rowkey="#" + self._parentid + "r" + _srow + "c" + _scol + "";_rowcx={};_rowcx={};_rowcx={};_rowcx["margin-top"]=self.cstr(_margintop)+"px";_rowcx["margin-bottom"]=self.cstr(_marginbottom)+"px";_rowcx["margin-left"]=self.cstr(_marginleft)+"px";_rowcx["margin-right"]=self.cstr(_marginright)+"px";_str=self._app.map2json(_rowcx);_el=null;_el = u(_rowkey);_el.css(JSON.parse(_str));};this.setrowmargins1= function(_rowpos,_margintop,_marginbottom,_marginleft,_marginright) {if (self==null) self=this;var _srow;var _rowkey;var _rowcx;var _str;var _el;_srow=self.cstr(_rowpos);_rowkey="#" + self._parentid + "r" + _srow + "";_rowcx={};_rowcx={};_rowcx={};_rowcx["margin-top"]=self.cstr(_margintop)+"px";_rowcx["margin-bottom"]=self.cstr(_marginbottom)+"px";_rowcx["margin-left"]=self.cstr(_marginleft)+"px";_rowcx["margin-right"]=self.cstr(_marginright)+"px";_str=self._app.map2json(_rowcx);_el=null;_el = u(_rowkey);_el.css(JSON.parse(_str));};this.setrowpadding= function(_rowpos,_paddingtop,_paddingbottom,_paddingleft,_paddingright) {if (self==null) self=this;var _srow;var _rowkey;var _rowca;_srow=self.cstr(_rowpos);_rowkey="r" + _srow + "";_rowca={"pt":self.cstr(_paddingtop), "pb":self.cstr(_paddingbottom), "pl":self.cstr(_paddingleft), "pr":self.cstr(_paddingright)};self._rowpadding[_rowkey]=_rowca;};this.setcolumnclass= function(_rowpos,_columnpos,_classname) {if (self==null) self=this;var _rowc;var _rowkey;_rowc={};_rowkey="r" + _rowpos + "c" + _columnpos + "";if ((_rowkey in self._columnclasses)) {_rowc = self._columnclasses[_rowkey];} else {_rowc={};_rowc={};}_rowc[_classname]=_classname;self._columnclasses[_rowkey]=_rowc;};this.createrow= function(_rows2add,_margintop,_marginbottom,_marginleft,_marginright,_paddingtop,_paddingbottom,_paddingleft,_paddingright,_visibility,_themename,_centerinpage,_classname) {if (self==null) self=this;var _nr;_nr= new banano_uoebanano_uoerow();_nr.initialize();_nr._marginbottom = _marginbottom;_nr._marginleft = _marginleft;_nr._marginright = _marginright;_nr._margintop = _margintop;_nr._paddingbottom = _paddingbottom;_nr._paddingleft = _paddingleft;_nr._paddingright = _paddingright;_nr._paddingtop = _paddingtop;_nr._themename = _themename;_nr._visibility = _visibility;_nr._classname = _classname;_nr._rows = _rows2add;return _nr;};this.createcolumn= function(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_offsetxlarge,_spansmall,_spanmedium,_spanlarge,_spanxlarge,_margintop,_marginbottom,_marginleft,_marginright,_paddingtop,_paddingbottom,_paddingleft,_paddingright,_theme,_visibility,_classname) {if (self==null) self=this;var _ncell;_ncell= new banano_uoebanano_uoecolumn();_ncell.initialize();_ncell._columns = _columns2add;_ncell._offsetsmall = _offsetsmall;_ncell._offsetmedium = _offsetmedium;_ncell._offsetlarge = _offsetlarge;_ncell._spansmall = _spansmall;_ncell._spanmedium = _spanmedium;_ncell._spanlarge = _spanlarge;_ncell._margintop = _margintop;_ncell._marginbottom = _marginbottom;_ncell._marginleft = _marginleft;_ncell._marginright = _marginright;_ncell._paddingbottom = _paddingbottom;_ncell._paddingleft = _paddingleft;_ncell._paddingtop = _paddingtop;_ncell._paddingright = _paddingright;_ncell._visibility = _visibility;_ncell._classname = _classname;_ncell._theme = _theme;return _ncell;};this.initialize= function(_thisapp,_parent) {if (self==null) self=this;self._app = _thisapp;self._rows={};self._rows={};self._lastrow = 0;self._rc={};self._rc={};self._columns={};self._columns={};self._showid = false;self._parentid = _parent.toLowerCase();self._components={};self._components={};self._rowclasses={};self._rowclasses={};self._columnclasses={};self._columnclasses={};self._rowpadding={};self._rowpadding={};self._rowmargins={};self._rowmargins={};};this.addrowsmpv= function(_irows,_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_sthemename,_svisibility,_sclassname) {if (self==null) self=this;var _nrow;var _rowkey;self._lastrow = Object.keys(self._rows).length;_nrow= new banano_uoebanano_uoerow();_nrow.initialize();_nrow = self.createrow(_irows,_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_svisibility,_sthemename,false,_sclassname);_rowkey="r" + self._lastrow + "";self._rows[_rowkey]=_nrow;return self;};this.addcolumnosmpv= function(_icolumns,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_sthemename,_svisibility,_sclassname) {if (self==null) self=this;var _ncell;var _rowkey;var _oldrow;var _cols;_ncell= new banano_uoebanano_uoecolumn();_ncell.initialize();_ncell = self.createcolumn(_icolumns,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,0,_isizesmall,_isizemedium,_isizelarge,0,_imargintop,_imarginbottom,_imarginleft,_imarginright,_ipaddingtop,_ipaddingbottom,_ipaddingleft,_ipaddingright,_sthemename,_svisibility,_sclassname);_rowkey="r" + self._lastrow + "";if ((_rowkey in self._rows)) {_oldrow= new banano_uoebanano_uoerow();_oldrow.initialize();_oldrow = self._rows[_rowkey];_cols=_oldrow._columns;_cols.push(_ncell);self._rows[_rowkey]=_oldrow;} else {console.log("UOEGrid - AddColumnOSMPV: A row has not been added yet to the grid!");}return self;};this.addcolumnsos= function(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,0,0,0,0,0,0,0,0,_sthemename,"",_classname);return self;};this.addcolumns12mpv= function(_columns2add,_imargintoppx,_imarginbottompx,_ipaddingleftpx,_ipaddingrightpx,_svisibility,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,12,12,12,_imargintoppx,_imarginbottompx,0,0,0,0,_ipaddingleftpx,_ipaddingrightpx,_sthemename,_svisibility,_classname);return self;};this.addcolumns12mp= function(_columns2add,_imargintoppx,_imarginbottompx,_ipaddingleftpx,_ipaddingrightpx,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,12,12,12,_imargintoppx,_imarginbottompx,_ipaddingleftpx,_ipaddingrightpx,0,0,0,0,_sthemename,"",_classname);return self;};this.addcolumnsosmpv= function(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_margintoppx,_marginbottompx,_paddingleftpx,_paddingrightpx,_svisibility,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_margintoppx,_marginbottompx,0,0,0,0,_paddingleftpx,_paddingrightpx,_sthemename,_svisibility,_classname);return self;};this.addcolumnssp= function(_columns2add,_sizesmall,_sizemedium,_sizelarge,_rpaddingleft,_rpaddingright,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,_sizesmall,_sizemedium,_sizelarge,0,0,0,0,0,0,_rpaddingleft,_rpaddingright,_sthemename,"",_classname);return self;};this.addcolumnsosmp= function(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_rmargintop,_rmarginbottom,_rpaddingleft,_rpaddingright,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,_offsetsmall,_offsetmedium,_offsetlarge,_sizesmall,_sizemedium,_sizelarge,_rmargintop,_rmarginbottom,0,0,0,0,_rpaddingleft,_rpaddingright,_sthemename,"",_classname);return self;};this.addcolumns12v= function(_columns2add,_svisibility,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,12,12,12,0,0,0,0,0,0,0,0,_sthemename,_svisibility,_classname);return self;};this.addcolumns12= function(_columns2add,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,12,12,12,0,0,0,0,0,0,0,0,_sthemename,"",_classname);return self;};this.addcolumns= function(_columns2add,_spansmall,_spanmedium,_spanlarge,_themename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,0,0,0,_spansmall,_spanmedium,_spanlarge,0,0,0,0,0,0,0,0,_themename,"",_classname);return self;};this.addcolumnsosv= function(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,_svisibility,_sthemename,_classname) {if (self==null) self=this;self.addcolumnosmpv(_columns2add,_ioffsetsmall,_ioffsetmedium,_ioffsetlarge,_isizesmall,_isizemedium,_isizelarge,0,0,0,0,0,0,0,0,_sthemename,_svisibility,_classname);return self;};this.tostring= function() {if (self==null) self=this;var _sb;var _rowcnt;var _rowtot;var _rowkey;var _currentrow;var _strrow;self._lastrow = 0;_sb=new StringBuilder();_sb.isinitialized=true;_rowcnt=0;_rowtot=Object.keys(self._rows).length-1;for (_rowcnt=0;_rowcnt<=_rowtot;_rowcnt++) {_rowkey=banano_getB4JKeyAt(self._rows,_rowcnt);_currentrow= new banano_uoebanano_uoerow();_currentrow.initialize();_currentrow = self._rows[_rowkey];_strrow=self.buildrow(_currentrow);_sb.append(_strrow);_sb.append("\n");}return _sb.toString();};this.replacerc= function(_rowpos,_colpos,_elhtml) {if (self==null) self=this;var _cellkey;var _elbody;_cellkey="#" + self._parentid + "r" + _rowpos + "c" + _colpos + "";_elbody=null;_elbody = u(_cellkey);if (_elbody!=null) {_elbody.empty();_elbody.html(_elhtml);}};this.addcomponent= function(_rowpos,_colpos,_elhtml) {if (self==null) self=this;var _cellkey;var _lst;_cellkey="" + self._parentid + "r" + _rowpos + "c" + _colpos + "";_lst=[];if ((_cellkey in self._components)) {_lst = self._components[_cellkey];} else {_lst.length=0;_lst.length=0;}_lst.push(_elhtml);self._components[_cellkey]=_lst;};this.mapkeys2delim= function(_m,_delim) {if (self==null) self=this;var _sb;var _ktot;var _kcnt;var _strkey;_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(_m).length-1;_kcnt=0;_strkey=banano_getB4JKeyAt(_m,0);_sb.append(_strkey);for (_kcnt=1;_kcnt<=_ktot;_kcnt++) {_strkey=banano_getB4JKeyAt(_m,_kcnt);_sb.append(_delim).append(_strkey);}return _sb.toString();};this.buildrow= function(_row) {if (self==null) self=this;var _rowtot;var _rowcnt;var _sb;var _rowkey;var _trow;var _strrowclass;var _strrowstyle;var _classkey;var _cm;var _cols;var _colcnt;var _coltot;var _lastcolumn;var _column;var _colcnt1;var _coltot1;var _cellkey;var _tcolumn;var _strcolumnclass;var _strcolumnstyle;var _lst;var _strrow;_rowtot=_row._rows;_rowcnt=0;_sb=new StringBuilder();_sb.isinitialized=true;for (_rowcnt=1;_rowcnt<=_rowtot;_rowcnt++) {self._lastrow = self._lastrow+1;_row._row = self._lastrow;_rowkey="" + self._parentid + "r" + self._lastrow + "";_trow= new banano_uoebanano_uoehtml();_trow.initialize(_rowkey,"div");_strrowclass=self.buildrowclass();_strrowstyle=self.buildrowstyle(_row);_trow.addclass(_strrowclass);_trow.addattribute("style",_strrowstyle);_trow.addclass(_row._classname);self._app.materialusetheme(_row._themename,_trow);_classkey="r" + self._lastrow + "";if ((_classkey in self._rowclasses)) {_cm=self._rowclasses[_classkey];_trow.addclass(self.mapkeys2delim(_cm," "));}_cols=_row._columns;_colcnt=0;_coltot=_cols.length-1;_lastcolumn=0;for (_colcnt=0;_colcnt<=_coltot;_colcnt++) {_column= new banano_uoebanano_uoecolumn();_column.initialize();_column = _cols[_colcnt];_colcnt1=0;_coltot1=_column._columns;for (_colcnt1=1;_colcnt1<=_coltot1;_colcnt1++) {_lastcolumn = _lastcolumn+1;_column._row = self._lastrow;_column._col = _lastcolumn;_cellkey="" + _rowkey + "c" + _lastcolumn + "";self._rc[_cellkey]=_cellkey;_tcolumn= new banano_uoebanano_uoehtml();_tcolumn.initialize(_cellkey,"div");_strcolumnclass=self.buildcolumnclass(_column);_strcolumnstyle=self.buildcolumnstyle(_column);_tcolumn.addclass(_strcolumnclass);_tcolumn.addattribute("style",_strcolumnstyle);_tcolumn.addclass(_column._classname);self._app.materialusetheme(_column._theme,_tcolumn);_classkey="r" + self._lastrow + "c" + _lastcolumn + "";if ((_classkey in self._columnclasses)) {_cm=self._columnclasses[_classkey];_tcolumn.addclass(self.mapkeys2delim(_cm," "));}if ((_cellkey in self._components)) {_lst=self._components[_cellkey];_tcolumn.addcontentlist(_lst);}_trow.addelement(_tcolumn);}}_strrow=_trow.tostring();_sb.append(_strrow).append("\n");}return _sb.toString();};this.buildcolumnclass= function(_col) {if (self==null) self=this;var _strspans;var _stroffsets;var _sb;_strspans=self.buildspans(_col._spansmall,_col._spanmedium,_col._spanlarge);_stroffsets=self.buildoffsets(_col._offsetsmall,_col._offsetmedium,_col._offsetlarge);_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("" + self._cellclass + " ");_sb.append(_strspans);_sb.append(_stroffsets);return _sb.toString().trim();};this.buildrowstyle= function(_row) {if (self==null) self=this;var _rowc;var _rowkey;var _hasrow;var _strmargins;var _strpadding;var _sb;_rowc={};_rowc={};_rowc={};_rowkey="r" + _row._row + "";_hasrow=(_rowkey in self._rowpadding);if (_hasrow) {_rowc = self._rowpadding[_rowkey];_row._paddingtop = _rowc["pt"];_row._paddingbottom = _rowc["pb"];_row._paddingleft = _rowc["pl"];_row._paddingright = _rowc["pr"];}_hasrow=(_rowkey in self._rowmargins);if (_hasrow) {_rowc = self._rowmargins[_rowkey];_row._margintop = _rowc["mt"];_row._marginbottom = _rowc["mb"];_row._marginleft = _rowc["ml"];_row._marginright = _rowc["mr"];}_strmargins=self.buildmargins(_row._margintop,_row._marginbottom,_row._marginleft,_row._marginright);_strpadding=self.buildpadding(_row._paddingtop,_row._paddingbottom,_row._paddingleft,_row._paddingright);_sb=new StringBuilder();_sb.isinitialized=true;_sb.append(_strmargins);_sb.append(_strpadding);return _sb.toString().trim();};this.buildcolumnstyle= function(_col) {if (self==null) self=this;var _rowc;var _rowkey;var _hascolumn;var _strmargins;var _strpadding;var _sb;_rowc={};_rowc={};_rowc={};_rowkey="r" + _col._row + "c" + _col._col + "";_hascolumn=(_rowkey in self._rowpadding);if (_hascolumn) {_rowc = self._rowpadding[_rowkey];_col._paddingtop = _rowc["pt"];_col._paddingbottom = _rowc["pb"];_col._paddingleft = _rowc["pl"];_col._paddingright = _rowc["pr"];}_hascolumn=(_rowkey in self._rowmargins);if (_hascolumn) {_rowc = self._rowmargins[_rowkey];_col._margintop = _rowc["mt"];_col._marginbottom = _rowc["mb"];_col._marginleft = _rowc["ml"];_col._marginright = _rowc["mr"];}_strmargins=self.buildmargins(_col._margintop,_col._marginbottom,_col._marginleft,_col._marginright);_strpadding=self.buildpadding(_col._paddingtop,_col._paddingbottom,_col._paddingleft,_col._paddingright);_sb=new StringBuilder();_sb.isinitialized=true;_sb.append(_strmargins);_sb.append(_strpadding);return _sb.toString().trim();};this.buildrowclass= function() {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("" + self._rowclass + " ");return _sb.toString().trim();};this.buildspans= function(_ss,_sm,_sl) {if (self==null) self=this;var _sb;var _ktot;var _kcnt;var _colkey;var _colc;_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._colclass).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_colkey=banano_getB4JKeyAt(self._colclass,_kcnt);_colc=self._colclass[_colkey];_sb.append(_colc);switch ("" + _colkey) {case "" + "s":_sb.append(_ss);break;case "" + "m":_sb.append(_sm);break;case "" + "l":_sb.append(_sl);break;}_sb.append(" ");}return _sb.toString();};this.buildoffsets= function(_os,_om,_ol) {if (self==null) self=this;var _pvalue;var _sb;var _ktot;var _kcnt;var _colkey;var _colc;_pvalue="0";_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._offclass).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_colkey=banano_getB4JKeyAt(self._offclass,_kcnt);_colc=self._offclass[_colkey];switch ("" + _colkey) {case "" + "s":_pvalue = self.cstr(_os);break;case "" + "m":_pvalue = self.cstr(_om);break;case "" + "l":_pvalue = self.cstr(_ol);break;}_sb.append(_colc);_sb.append(_pvalue);_sb.append(" ");}return _sb.toString();};this.buildpadding= function(_pt,_pb,_pl,_pr) {if (self==null) self=this;var _pvalue;var _sb;var _ktot;var _kcnt;var _colkey;var _colc;_pvalue="0";_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._padclass).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_colkey=banano_getB4JKeyAt(self._padclass,_kcnt);_colc=self._padclass[_colkey];switch ("" + _colkey) {case "" + "pt":_pvalue = self.cstr(_pt);break;case "" + "pb":_pvalue = self.cstr(_pb);break;case "" + "pl":_pvalue = self.cstr(_pl);break;case "" + "pr":_pvalue = self.cstr(_pr);break;}_sb.append(_colc);_sb.append(_pvalue);_sb.append("px !important; ");}return _sb.toString();};this.buildmargins= function(_mt,_mb,_ml,_mr) {if (self==null) self=this;var _pvalue;var _sb;var _ktot;var _kcnt;var _colkey;var _colc;_pvalue="0";_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._marclass).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_colkey=banano_getB4JKeyAt(self._marclass,_kcnt);_colc=self._marclass[_colkey];switch ("" + _colkey) {case "" + "mt":_pvalue = self.cstr(_mt);break;case "" + "mb":_pvalue = self.cstr(_mb);break;case "" + "ml":_pvalue = self.cstr(_ml);break;case "" + "mr":_pvalue = self.cstr(_mr);break;}_sb.append(_colc);_sb.append(_pvalue);_sb.append("px !important; ");}return _sb.toString();};this.rowexists= function(_rowpos) {if (self==null) self=this;var _rowcol;_rowcol="r" + _rowpos + "";return (_rowcol in self._rows);};this.columnexists= function(_rowpos,_colpos) {if (self==null) self=this;var _rowcol;_rowcol="r" + _rowpos + "c" + _colpos + "";return (_rowcol in self._rc);};this.howmanyrows= function() {if (self==null) self=this;return self._lastrow;};}function banano_uoebanano_uoehtml() {var self;this._id='';this._tag='';this._properties={};this._contents=[];this._classes={};this._styles={};this._looseattributes=[];this._dontbreak=[];this._prefix='';this._doaproperclose=false;this._required=false;this._enabled=false;this._inline=false;this._readonly=false;this._cssrule={};this._singlequote=[];this._parentid='';this._text='';this._textafter=false;this._divider='';this.getstyleattribute= function(_attr) {if (self==null) self=this;var _hasitem;_attr = _attr.toLowerCase();_attr = self.remdelim(_attr,":").trim();_hasitem=(_attr in self._styles);if (_hasitem) {return self._styles[_attr];} else {return "";}};this.setcontents= function(_value) {if (self==null) self=this;self._contents.length=0;self._contents.length=0;if (_value.length>0) {_value = self.formattext(_value);self._contents.push(_value);}return self;};this.addelementline= function(_el) {if (self==null) self=this;var _scode;if (_el!=null) {_scode=_el.html();self.addcontent(_scode);}return self;};this.setrole= function(_svalue) {if (self==null) self=this;self.addattribute("role",_svalue);return self;};this.addcontentline= function(_value) {if (self==null) self=this;if (_value!="") {_value = _value.split("\n").join("");_value = self.formattext(_value);self._contents.push(_value);}return self;};this.materialadddivider= function(_svisibility,_themename) {if (self==null) self=this;var _li;_li= new banano_uoebanano_uoehtml();_li.initialize("","li");_li.addclass("divider");_li.materialvisibility(_svisibility);self._divider = _li.html();return self;};this.materialadddivideroncondition= function(_bstatus,_svisibility,_themename) {if (self==null) self=this;if (_bstatus == true) {self.materialadddivider(_svisibility,_themename);}return self;};this.materialbutton= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"btn");return self;};this.settypenumbers= function() {if (self==null) self=this;self.addattribute("type","1");return self;};this.settypeuppercase= function() {if (self==null) self=this;self.addattribute("type","A");return self;};this.settypelowercase= function() {if (self==null) self=this;self.addattribute("type","a");return self;};this.settypeuppercaseroman= function() {if (self==null) self=this;self.addattribute("type","I");return self;};this.settypelowercaseroman= function() {if (self==null) self=this;self.addattribute("type","i");return self;};this.setliststylecircle= function() {if (self==null) self=this;self.addstyleattribute("list-style-type","circle");return self;};this.setliststyledisk= function() {if (self==null) self=this;self.addstyleattribute("list-style-type","disk");return self;};this.setliststylenone= function() {if (self==null) self=this;self.addstyleattribute("list-style-type","none");return self;};this.setliststylesquare= function() {if (self==null) self=this;self.addstyleattribute("list-style-type","square");return self;};this.addheading= function(_ssize,_scontent) {if (self==null) self=this;var _hdr;var _hkey;_hdr= new banano_uoebanano_uoehtml();_hkey="h"+_ssize;_hdr.initialize("",_hkey);_hdr.addcontent(_scontent);self.addcontent(_hdr.html());return self;};this.addparagraph= function(_scontent) {if (self==null) self=this;var _p;_p= new banano_uoebanano_uoehtml();_p.initialize("","p");_p.addcontent(_scontent);self.addcontent(_p.html());return self;};this.addlooseattributeonfalsecondition= function(_bstatus,_value) {if (self==null) self=this;self.removeattr(_value);if (_bstatus == false) {self.addlooseattribute(_value);}return self;};this.setelementtypeoncondition= function(_bstatus,_selementtype) {if (self==null) self=this;if (_bstatus) {self._tag = _selementtype;}return self;};this.materialcollectionitem= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"collection-item");return self;};this.materialmodalclose= function() {if (self==null) self=this;self.addclass("modal-action");self.addclass("modal-close");return self;};this.materialavatar= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"avatar");return self;};this.materialsecondarycontent= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"secondary-content");return self;};this.materialcollectionheader= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"collection-header");return self;};this.materialcollapsibleheader= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"collapsible-header");return self;};this.setzindex= function(_zindex) {if (self==null) self=this;self.addstyleattribute("z-index",_zindex);return self;};this.addcontentlistreverse= function(_lst) {if (self==null) self=this;var _ltot;var _lcnt;var _strcontent;_ltot=_lst.length-1;_lcnt=0;for (_lcnt=_ltot;_lcnt>=0;_lcnt-=1) {_strcontent=_lst[_lcnt];self.addcontent(_strcontent);}return self;};this.setfor= function(_sfor) {if (self==null) self=this;self.addattribute("for",_sfor);return self;};this.setvalue= function(_svalue) {if (self==null) self=this;self.addattribute("value",_svalue);return self;};this.setname= function(_sname) {if (self==null) self=this;self.addattribute("name",_sname);return self;};this.settype= function(_svalue) {if (self==null) self=this;self.addattribute("type",_svalue);return self;};this.updateattribute= function(_name,_propvalue) {if (self==null) self=this;var _svalue;if ((_name in self._properties)) {_svalue=self._properties[_name];_svalue = _svalue+";"+_propvalue;self._properties[_name]=_svalue;} else {self._properties[_name]=_propvalue;}return self;};this.addlooseattributeoncondition= function(_bstatus,_value) {if (self==null) self=this;self.removeattr(_value);if (_bstatus == true) {self.addattribute(_value,"true");}return self;};this.addlooseattribute= function(_value) {if (self==null) self=this;self.removeattr(_value);self.addattribute(_value,"true");return self;};this.makepx= function(_svalue) {if (self==null) self=this;if (_svalue.endsWith("%")) {return _svalue;} else {if (_svalue.endsWith("px")) {return _svalue;} else {_svalue = _svalue.trim();_svalue = _svalue.split("px").join("");_svalue = "" + _svalue + "px";if (_svalue == "px") {_svalue = "";}return _svalue;}}};this.materialtextcolor= function(_scolor) {if (self==null) self=this;_scolor = _scolor.trim();if (_scolor == "") { return self;}if (_scolor.endsWith("-text") == false) {_scolor = _scolor+"-text";}self.addclass(_scolor);return self;};this.adddataattribute= function(_attribute,_value) {if (self==null) self=this;if (_attribute.startsWith("data-")) {self.addattribute(_attribute,_value);} else {self.addattribute("data-"+_attribute,_value);}return self;};this.adddataattributeoncondition= function(_bcondition,_attribute,_value) {if (self==null) self=this;self.removeattrdata(_attribute);if (_bcondition == false) {return self;}self.adddataattribute(_attribute,_value);return self;};this.materialboxed= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"materialboxed");return self;};this.materialresponsive= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"responsive-img");if (_bstatus == true) {self.addcursor();}return self;};this.setsrc= function(_svalue,_static) {if (self==null) self=this;var _tmpfile;_tmpfile=self.mvfield(_svalue,1,"?");if (_static) {_svalue = _tmpfile;} else {_svalue = _tmpfile+"?"+DateTime.Now();}self.addattribute("src",_svalue);return self;};this.setalt= function(_svalue) {if (self==null) self=this;self.addattribute("alt",_svalue);return self;};this.materialcircle= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"circle");return self;};this.setwidthpx= function(_width) {if (self==null) self=this;if (_width!="") {self.addstyleattribute("width",self.makepx(_width));}return self;};this.setheightpx= function(_height) {if (self==null) self=this;if (_height!="") {self.addstyleattribute("height",self.makepx(_height));}return self;};this.materialtoolbar= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"toolbar");return self;};this.materialhorizontal= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"horizontal");return self;};this.materialclick2toggle= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"click-to-toggle");return self;};this.addstyleattributeoncondition= function(_bcondition,_attr,_value) {if (self==null) self=this;self.removestyle(_attr);if (_bcondition == true) {self.addstyleattribute(_attr,_value);}return self;};this.addattributeoncondition= function(_bcondition,_attr,_value) {if (self==null) self=this;self.removeattr(_attr);if (_bcondition == true) {self.addattribute(_attr,_value);}return self;};this.materialbuttonsize= function(_ssize) {if (self==null) self=this;if (_ssize.length>0) {self.removeclass("btn-small");self.removeclass("btn-large");self.removeclass("btn-medium");self.addclass(_ssize);self.addclass("btn");}return self;};this.materialbuttonfloating= function(_bstatus) {if (self==null) self=this;if (_bstatus) {self.removeclass("fixed-action-btn");self.removeclass("btn-flat");self.removeclass("btn-raised");self.removeclass("halfway-fab");self.addclassoncondition(_bstatus,"btn-floating");}return self;};this.materialpulse= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"pulse");return self;};this.materialbuttontype= function(_btntype) {if (self==null) self=this;if (_btntype.length>0) {self.removeclass("fixed-action-btn");self.removeclass("btn-flat");self.removeclass("btn-raised");self.removeclass("halfway-fab");self.removeclass("btn-floating");self.addclass(_btntype);}return self;};this.getattribute= function(_attr) {if (self==null) self=this;_attr = _attr.toLowerCase();if ((_attr in self._properties)) {return self._properties[_attr];} else {return "";}};this.classexists= function(_value) {if (self==null) self=this;_value = _value.trim();if (_value.length>0) {return (_value in self._classes);}return false;};this.html= function() {if (self==null) self=this;var _sout;_sout=self.tostring();return _sout;};this.materialwaveseffect= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"waves-effect");return self;};this.materialwavestype= function(_stype) {if (self==null) self=this;if (_stype.length>0) {self.removeclass("waves-green");self.removeclass("waves-light");self.removeclass("waves-orange");self.removeclass("waves-purple");self.removeclass("waves-red");self.removeclass("waves-teal");self.removeclass("waves-yellow");self.addclass(_stype);}return self;};this.materialwavescircle= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("waves-circle");self.removeclass("waves-block");self.addclass("waves-circle");}return self;};this.materialwavesblock= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("waves-circle");self.removeclass("waves-block");self.addclass("waves-block");}return self;};this.materialwaveslight= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"waves-light");return self;};this.materialsettooltip= function(_position,_delay,_tooltip) {if (self==null) self=this;_delay = self.cstr(_delay);_position = self.cstr(_position);_tooltip = self.cstr(_tooltip);if (_tooltip.length>0) {self.addclass("tooltipped");self.addattribute("data-position",_position);self.addattribute("data-delay",_delay);self.addattribute("data-tooltip",_tooltip);} else {self.removeclass("tooltipped");self.removeclass("data-position");self.removeclass("data-delay");self.removeclass("data-tooltip");}return self;};this.pointer= function() {if (self==null) self=this;return "cursor:pointer";};this.addcursor= function() {if (self==null) self=this;self.addstyleattribute("cursor","pointer");return self;};this.sethref= function(_value) {if (self==null) self=this;self.addattribute("href",_value);return self;};this.addclassonvalue= function(_ivalue,_sclass) {if (self==null) self=this;if (_ivalue>0) {self.addclass(_sclass);}return self;};this.addclassoncondition= function(_bcondition,_sclass) {if (self==null) self=this;self.removeclass(_sclass);if (_bcondition == true) {self.addclass(_sclass);}return self;};this.addclassonfalsecondition= function(_bcondition,_sclass) {if (self==null) self=this;self.removeclass(_sclass);if (_bcondition == false) {self.addclass(_sclass);}return self;};this.removeclassoncondition= function(_bcondition,_sclass) {if (self==null) self=this;if (_bcondition == true) {self.removeclass(_sclass);}return self;};this.removeclassonfalsecondition= function(_bcondition,_sclass) {if (self==null) self=this;if (_bcondition == false) {self.removeclass(_sclass);}return self;};this.addcontentlist= function(_lst) {if (self==null) self=this;var _strcontent;for (var _strcontentindex=0;_strcontentindex<_lst.length;_strcontentindex++) {_strcontent=_lst[_strcontentindex];self.addcontent(_strcontent);}return self;};this.settext= function(_stext,_bafter) {if (self==null) self=this;self._text = _stext;self._textafter = _bafter;return self;};this.setprefix= function(_sprefix) {if (self==null) self=this;self._prefix = _sprefix;return self;};this.setid= function(_sid) {if (self==null) self=this;_sid = _sid.toLowerCase();self._id = _sid;return self;};this.settag= function(_stag) {if (self==null) self=this;self._tag = _stag;return self;};this.setparentid= function(_sparentid) {if (self==null) self=this;self._parentid = _sparentid;return self;};this.setreadonly= function(_breadonly) {if (self==null) self=this;self._readonly = _breadonly;return self;};this.setinline= function(_binline) {if (self==null) self=this;self._inline = _binline;return self;};this.setenabled= function(_benabled) {if (self==null) self=this;self._enabled = _benabled;return self;};this.setrequired= function(_brequired) {if (self==null) self=this;self._required = _brequired;return self;};this.initialize= function(_elid,_eltag) {if (self==null) self=this;self._id = _elid.toLowerCase();self._properties={};self._properties={};self._contents.length=0;self._contents.length=0;self._styles={};self._styles={};self._classes={};self._classes={};self._looseattributes.length=0;self._looseattributes.length=0;self._parentid = "";self._dontbreak.length=0;self._dontbreak.length=0;self._dontbreak.push("li");self._dontbreak.push("a");self._dontbreak.push("i");self._dontbreak.push("span");self._dontbreak.push("img");self._tag = _eltag;self._prefix = "";self._doaproperclose = true;self._required = false;self._enabled = true;self._inline = false;self._readonly = false;self._cssrule={};self._cssrule={};self._singlequote.length=0;self._singlequote.length=0;self._text = "";self._textafter = false;};this.removeattrdata= function(_sdata) {if (self==null) self=this;_sdata = "data-" + _sdata + "";self.removeattr(_sdata);return self;};this.materialenable= function(_benabled) {if (self==null) self=this;self._enabled = _benabled;return self;};this.materialrequired= function(_brequired) {if (self==null) self=this;self._required = _brequired;return self;};this.materialinline= function(_binline) {if (self==null) self=this;self._inline = _binline;return self;};this.removeattribute= function(_prop) {if (self==null) self=this;self.removeattr(_prop);return self;};this.removeattr= function(_sname) {if (self==null) self=this;var _sitems;var _strstyle;_sname = _sname.toLowerCase();_sname = _sname.split(" ").join(";");_sitems=self.strparse(";",_sname);for (var _strstyleindex=0;_strstyleindex<_sitems.length;_strstyleindex++) {_strstyle=_sitems[_strstyleindex];_strstyle = _strstyle.trim();if ((_strstyle in self._properties)) {delete self._properties[_strstyle];}}return self;};this.removestyle= function(_stylename) {if (self==null) self=this;var _sitems;var _strstyle;_stylename = _stylename.trim();_stylename = _stylename.toLowerCase();_stylename = _stylename.split(" ").join(";");_sitems=self.strparse(";",_stylename);for (var _strstyleindex=0;_strstyleindex<_sitems.length;_strstyleindex++) {_strstyle=_sitems[_strstyleindex];_strstyle = _strstyle.trim();if ((_strstyle in self._styles)) {delete self._styles[_strstyle];}}return self;};this.setattrloose= function(_value) {if (self==null) self=this;self.addattribute(_value,"true");return self;};this.getcomponentbuilder= function() {if (self==null) self=this;var _sb;var _sout;_sb=new StringBuilder();_sb.isinitialized=true;if (self._prefix.length>0) {_sb.append(self._prefix);_sb.append("\n");}_sb.append("<");_sb.append(self._tag);_sb.append(" ");if (self._id.length>0) {_sb.append(self.toproperty("id",self._id));}_sb.append(">");switch ("" + self._tag.toLowerCase()) {case "" + "img":case "" + "link":case "" + "meta":case "" + "input":case "" + "source":self._doaproperclose = false;break;}if (self._doaproperclose == true) {_sb.append("</");_sb.append(self._tag);_sb.append(">");}_sb.append("\n");_sout=_sb.toString();_sout = _sout.trim();return _sout;};this.toproperty= function(_sname,_svalue) {if (self==null) self=this;var _script;_sname = self.cstr(_sname);_svalue = self.cstr(_svalue);_sname = _sname.split("null").join("");_sname = _sname.split("undefined").join("");_svalue = _svalue.split("null").join("");_svalue = _svalue.split("undefined").join("");_sname = _sname.trim();_svalue = _svalue.trim();if (_sname.length>0) {_script="" + _sname + "=\"" + _svalue + "\"";_script = _script.trim();return _script;} else {return "";}};this.setattrdata= function(_prop,_value) {if (self==null) self=this;if (_prop.startsWith("data-")) {self.addattribute(_prop,_value);} else {self.addattribute("data-"+_prop,_value);}return self;};this.cstr= function(_o) {if (self==null) self=this;return ""+_o;};this.addcontent= function(_value) {if (self==null) self=this;_value = self.cstr(_value);if (_value.length>0) {_value = self.formattext(_value);self._contents.push(_value);}return self;};this.removeclass= function(_classname) {if (self==null) self=this;var _sitems;var _strstyle;_classname = _classname.trim();_classname = _classname.split(" ").join(";");_sitems=self.strparse(";",_classname);for (var _strstyleindex=0;_strstyleindex<_sitems.length;_strstyleindex++) {_strstyle=_sitems[_strstyleindex];_strstyle = _strstyle.trim();if ((_strstyle in self._classes)) {delete self._classes[_strstyle];}}return self;};this.addelement= function(_el) {if (self==null) self=this;var _scode;if (_el!=null) {_scode=_el.tostring();self.addcontent(_scode);}return self;};this.buildclass= function() {if (self==null) self=this;var _sb;var _ktot;var _kcnt;var _strclass;_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._classes).length-1;_kcnt=0;_strclass=banano_getB4JKeyAt(self._classes,0);_sb.append(_strclass);for (_kcnt=1;_kcnt<=_ktot;_kcnt++) {_strclass=banano_getB4JKeyAt(self._classes,_kcnt);_sb.append(" ");_sb.append(_strclass);}return _sb.toString();};this.buildstyle= function() {if (self==null) self=this;var _sb;var _kcnt;var _ktot;var _strkey;var _strvalue;var _strline;_sb=new StringBuilder();_sb.isinitialized=true;_kcnt=0;_ktot=Object.keys(self._styles).length-1;_strkey=banano_getB4JKeyAt(self._styles,0);_strvalue=self._styles[_strkey];_strline=self.tostyle(_strkey,_strvalue);_sb.append(_strline);for (_kcnt=1;_kcnt<=_ktot;_kcnt++) {_strkey=banano_getB4JKeyAt(self._styles,_kcnt);_strvalue=self._styles[_strkey];_strline=self.tostyle(_strkey,_strvalue);_sb.append(" ");_sb.append(_strline);}return _sb.toString();};this.tostyle= function(_sname,_value) {if (self==null) self=this;var _sout;if (_sname.length>0 && _value.length>0) {if (_sname.endsWith(":")) {_sname = self.mvfield(_sname,1,":");}_sout="" + _sname + ":" + _value + ";";if (_sout == ":;") {_sout = "";}return _sout;} else {return "";}};this.mvfieldfrom= function(_svalue,_iposition,_delimiter) {if (self==null) self=this;var _mvalues;var _tvalues;var _sb;var _startcnt;if (_svalue.length == 0) { return "";}_mvalues=[];_tvalues=0;if (_svalue.endsWith(_delimiter)) {_svalue = _svalue+" ";}_mvalues = self.strparse(_delimiter,_svalue);_tvalues = _mvalues.length-1;if (_tvalues<_iposition) {return _mvalues[_tvalues];}_sb=new StringBuilder();_sb.isinitialized=true;_startcnt=0;_sb.append(_mvalues[_iposition]);for (_startcnt=_iposition+1;_startcnt<=_tvalues;_startcnt++) {_sb.append(_delimiter);_sb.append(_mvalues[_startcnt]);}return _sb.toString();};this.materialbuildicon= function(_iconname,_iconpos) {if (self==null) self=this;_iconname = _iconname.toLowerCase();if (_iconname.startsWith("mdi-")) {self.addclass("material-icons");_iconname = self.mvfieldfrom(_iconname,2,"-");_iconname = _iconname.split("-").join("_");self.addcontent(_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;}if (_iconname.startsWith("ggle-")) {_iconname = self.mvfieldfrom(_iconname,2,"-");self.addcontent(_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;}if (_iconname.startsWith("fa-")) {self.addclass("fa "+_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;}if (_iconname.startsWith("fa fa-")) {self.addclass(_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;}if (_iconname.startsWith("fa ")) {self.addclass(_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;}self.addclass(_iconname);if (_iconpos.length>0) {self.addclass(_iconpos);}return self;};this.materialclose= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"close");return self;};this.materialiconsize= function(_ssize) {if (self==null) self=this;if (_ssize.length>0) {self.removeclass("large");self.removeclass("tiny");self.removeclass("small");self.removeclass("medium");self.addclass(_ssize);}return self;};this.open= function() {if (self==null) self=this;var _thisclass;var _thisstyle;var _strvalue;var _sb;var _thisattr;if (self._required == true) {self.setattrloose("required");}if (self._enabled == false) {self.setattrloose("disabled");}if (self._inline == true) {self.setattrloose("inline");}if (self._readonly == true) {self.setattrloose("readonly");}_thisclass=self.buildclass();_thisclass = _thisclass.trim();if (_thisclass.length>0) {self.addattribute("class",_thisclass);}_thisstyle=self.buildstyle();_thisstyle = _thisstyle.trim();if (_thisstyle.length>0) {self.addattribute("style",_thisstyle);}_strvalue='';_sb=new StringBuilder();_sb.isinitialized=true;if (self._prefix.length>0) {_sb.append(self._prefix);_sb.append("\n");}_sb.append("<");_sb.append(self._tag);_sb.append(" ");if (self._id.length>0) {_sb.append(self.toproperty("id",self._id));_sb.append(" ");}_thisattr=self.buildattributes();_thisattr = _thisattr.trim();if (_thisattr.length>0) {_sb.append(_thisattr);}_sb.append(">");_sb.append("\n");return _sb.toString();};this.buildattributes= function() {if (self==null) self=this;var _sb;var _ktot;var _kcnt;var _strkey;var _strvalue;_sb=new StringBuilder();_sb.isinitialized=true;_ktot=Object.keys(self._properties).length-1;_kcnt=0;_strkey=banano_getB4JKeyAt(self._properties,0);_strvalue=self._properties[_strkey];if (self._singlequote.indexOf(_strkey) == -1) {_sb.append(self.toproperty(_strkey,_strvalue));} else {_sb.append(self.tosinglequoteproperty(_strkey,_strvalue));}for (_kcnt=1;_kcnt<=_ktot;_kcnt++) {_strkey = banano_getB4JKeyAt(self._properties,_kcnt);_strvalue = self._properties[_strkey];_sb.append(" ");if (self._singlequote.indexOf(_strkey) == -1) {_sb.append(self.toproperty(_strkey,_strvalue));} else {_sb.append(self.tosinglequoteproperty(_strkey,_strvalue));}}return _sb.toString();};this.tosinglequoteproperty= function(_sname,_svalue) {if (self==null) self=this;var _script;_script="" + _sname + "='" + _svalue + "'";_script = _script.trim();if (_script == "=''") {_script = "";}return _script;};this.formattext= function(_stext) {if (self==null) self=this;var _rm;var _ktot;var _kcnt;var _strvalue;var _strrep;_rm={};_rm={};_rm={};_rm["{U}"]="<ins>";_rm["{/U}"]="</ins>";_rm["¢"]="&cent;";_rm["£"]="&pound;";_rm["{SUP}"]="<sup>";_rm["{/SUP}"]="</sup>";_rm["¥"]="&yen;";_rm["€"]="&euro;";_rm["©"]="&copy;";_rm["®"]="&reg;";_rm["{POUND}"]="&pound;";_rm["{/B}"]="</b>";_rm["{I}"]="<i>";_rm["{YEN}"]="&yen;";_rm["{EURO}"]="&euro;";_rm["{CODE}"]="<code>";_rm["{/CODE}"]="</code>";_rm["{COPYRIGHT}"]="&copy;";_rm["{REGISTERED}"]="&reg;";_rm["®"]="&reg;";_rm["{B}"]="<b>";_rm["{SMALL}"]="<small>";_rm["{/SMALL}"]="</small>";_rm["{EM}"]="<em>";_rm["{/EM}"]="</em>";_rm["{MARK}"]="<mark>";_rm["{/MARK}"]="</mark>";_rm["{/I}"]="</i>";_rm["{SUB}"]="<sub>";_rm["{/SUB}"]="</sub>";_rm["{BR}"]="<br/>";_rm["{WBR}"]="<wbr>";_rm["{STRONG}"]="<strong>";_rm["{/STRONG}"]="</strong>";_rm["{NBSP}"]="&nbsp;";_rm["“"]="";_rm["”"]="";_rm["’"]="'";_ktot=Object.keys(_rm).length-1;_kcnt=0;for (_kcnt=0;_kcnt<=_ktot;_kcnt++) {_strvalue=banano_getB4JKeyAt(_rm,_kcnt);_strrep=_rm[_strvalue];_stext = _stext.split(_strvalue).join(_strrep);}return _stext;};this.remdelim= function(_svalue,_delim) {if (self==null) self=this;var _ldelim;var _nvalue;if (_svalue.endsWith(_delim)) {_ldelim=_delim.length;_nvalue=_svalue;if (_nvalue.endsWith(_delim)) {_nvalue = _nvalue.substring(0,_nvalue.length-_ldelim);}return _nvalue;} else {return _svalue;}};this.addstyleattribute= function(_sprop,_svalue) {if (self==null) self=this;_sprop = _sprop.toLowerCase();_sprop = _sprop.trim();_svalue = _svalue.trim();_sprop = self.remdelim(_sprop,":");_svalue = self.remdelim(_svalue,";");_sprop = _sprop.trim();_svalue = _svalue.trim();if (_svalue.length>0 && _sprop.length>0) {if (_svalue.endsWith("!important") == false) {_svalue = _svalue+" !important";}self._styles[_sprop]=_svalue;}return self;};this.mvfield= function(_svalue,_iposition,_delimiter) {if (self==null) self=this;var _xpos;var _mvalues;var _tvalues;var _sb;var _startcnt;if (_svalue.length == 0) { return "";}_xpos=_svalue.indexOf(_delimiter);if (_xpos == -1) { return _svalue;}_mvalues=self.strparse(_delimiter,_svalue);_tvalues=0;_tvalues = _mvalues.length-1;switch ("" + _iposition) {case "" + -1:return _mvalues[_tvalues];case "" + -2:return _mvalues[_tvalues-1];case "" + -3:_sb=new StringBuilder();_sb.isinitialized=true;_startcnt=0;_sb.append(_mvalues[1]);for (_startcnt=2;_startcnt<=_tvalues;_startcnt++) {_sb.append(_delimiter);_sb.append(_mvalues[_startcnt]);}return _sb.toString();default:_iposition = _iposition-1;if (_iposition<=-1) {return _mvalues[_tvalues];}if (_iposition>_tvalues) {return "";}return _mvalues[_iposition];}};this.addclass= function(_value) {if (self==null) self=this;var _spclasses;var _strclass;_value = _value.split(" ").join(";");_spclasses=self.strparse(";",_value);for (var _strclassindex=0;_strclassindex<_spclasses.length;_strclassindex++) {_strclass=_spclasses[_strclassindex];_strclass = _strclass.trim();if (_strclass.length>0) {self._classes[_strclass]=_strclass;}}return self;};this.addattribute= function(_skey,_svalue) {if (self==null) self=this;_skey = self.cstr(_skey);_svalue = self.cstr(_svalue);_skey = _skey.split("undefined").join("");_skey = _skey.split("null").join("");_svalue = _svalue.split("undefined").join("");_svalue = _svalue.split("null").join("");_skey = _skey.trim();_svalue = _svalue.trim();if (_skey.length>0 && _svalue.length>0) {self._properties[_skey]=_svalue;} else {delete self._properties[_skey];}return self;};this.strparse= function(_delim,_inputstring) {if (self==null) self=this;var _outlist;var _commaloc;var _leftside;var _rightside;_outlist=[];_commaloc=0;_outlist.length=0;_outlist.length=0;_commaloc = _inputstring.indexOf(_delim);while (_commaloc>-1) {_leftside='';_leftside = _inputstring.substring(0,_commaloc);_rightside='';_rightside = _inputstring.substring(_commaloc+1);_outlist.push(_leftside);_inputstring = _rightside;_commaloc = _inputstring.indexOf(_delim);}_outlist.push(_inputstring);return _outlist;};this.close= function() {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;switch ("" + self._tag.toLowerCase()) {case "" + "img":case "" + "link":case "" + "meta":case "" + "input":case "" + "source":case "" + "hr":case "" + "br":self._doaproperclose = false;break;}if (self._doaproperclose == true) {_sb.append("</");_sb.append(self._tag);_sb.append(">");}_sb.append("\n");return _sb.toString();};this.getattr= function(_attr) {if (self==null) self=this;_attr = _attr.toLowerCase();if ((_attr in self._properties)) {return self._properties[_attr];} else {return "";}};this.tostring= function() {if (self==null) self=this;var _imgurl;var _lnk;var _sb;var _strcontent;var _sout;if (self._parentid!="") {self._id = self._parentid+self._id;}switch ("" + self._tag) {case "" + "img":case "" + "script":_imgurl=self.getattr("src");if (_imgurl.length>0) {_imgurl = _imgurl.toLowerCase();}break;case "" + "link":_lnk=self.getattr("href");if (_lnk.length>0) {_lnk = _lnk.toLowerCase();}break;}_sb=new StringBuilder();_sb.isinitialized=true;_sb.append(self.open());if (self._textafter == true) {self._contents.push(self._text);} else {self._contents.splice.apply(self._contents,[0,0].concat(self._text));}for (var _strcontentindex=0;_strcontentindex<self._contents.length;_strcontentindex++) {_strcontent=self._contents[_strcontentindex];if (_strcontent.length>0) {_sb.append(_strcontent);}}_sb.append(self.close());_sout=_sb.toString();if (self._dontbreak.indexOf(self._tag)!=-1) {_sout = _sout.split("\n").join("");}_sout = _sout.split("\n").join("");return _sout;};this.materialhoverable= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"hoverable");return self;};this.materialtruncate= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"truncate");return self;};this.materialfloatleft= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("right");self.removeclass("left");self.addclass("left");}return self;};this.materialflowtext= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"flow-text");return self;};this.materialfloatright= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("left");self.removeclass("right");self.addclass("right");}return self;};this.materialtextalign= function(_textalign) {if (self==null) self=this;if (_textalign.length>0) {self.removeclass("center-align");self.removeclass("right-align");self.removeclass("left-align");self.addclass(_textalign);}return self;};this.materialleftaligntext= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("center-align");self.removeclass("right-align");self.removeclass("left-align");self.addclass("left-align");}return self;};this.materialcenteraligntext= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("center-align");self.removeclass("right-align");self.removeclass("left-align");self.addclass("center-align");}return self;};this.materialrightaligntext= function(_bstatus) {if (self==null) self=this;if (_bstatus == true) {self.removeclass("center-align");self.removeclass("right-align");self.removeclass("left-align");self.addclass("right-align");}return self;};this.materialaligntext= function(_salignment) {if (self==null) self=this;if (_salignment.length>0) {self.removeclass("center-align");self.removeclass("right-align");self.removeclass("left-align");self.addclass(_salignment);}return self;};this.materialzdepth= function(_szdepth) {if (self==null) self=this;if (_szdepth.length>0) {self.removeclass("z-depth-1");self.removeclass("z-depth-2");self.removeclass("z-depth-3");self.removeclass("z-depth-4");self.removeclass("z-depth-5");self.addclass(_szdepth);}return self;};this.materialverticalalign= function(_bstatus) {if (self==null) self=this;self.addclassoncondition(_bstatus,"valign-wrapper");return self;};this.materialvisibility= function(_svisibility) {if (self==null) self=this;if (_svisibility.length>0) {self.removeclass("hide-on-small-only");self.removeclass("hide-on-med-only");self.removeclass("hide-on-med-and-down");self.removeclass("hide-on-med-and-up");self.removeclass("hide-on-large-only");self.removeclass("show-on-large");self.removeclass("show-on-small");self.removeclass("show-on-medium");self.removeclass("show-on-medium-and-up");self.removeclass("show-on-medium-and-down");self.removeclass("hide");self.addclass(_svisibility);}return self;};}function banano_uoebanano_uoehtml5video() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._url='';this._visibility='';this._zdepth='';this._element= new banano_uoebanano_uoehtml();this._enabled=false;this._source= new banano_uoebanano_uoehtml();this._responsive=false;this._showcontrols=false;this._videotype='';this._height='';this._width='';this._hoverable=false;this._loopit=false;this._autoplay=false;this._allowfullscreen=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_surl) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._responsive = true;self._showcontrols = true;self._width = "100%";self._height = "100%";self._videotype = "video/mp4";self._element.initialize(self._id,"video");self._autoplay = false;self._loopit = false;self._enabled = true;self._zdepth = "";self._visibility = "";self._allowfullscreen = false;self._url = _surl;self._source.initialize("","source");};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._source.addattribute("type",self._videotype);self._source.addattribute("src",self._url);self._element.addstyleattribute("width",self._element.makepx(self._width));self._element.addstyleattribute("height",self._element.makepx(self._height));self._element.addlooseattribute("playsinline");self._element.addlooseattributeoncondition(self._showcontrols,"controls");self._element.addlooseattributeoncondition(self._loopit,"loop");self._element.addlooseattributeoncondition(self._autoplay,"autoplay");self._element.addclassoncondition(self._responsive,"responsive-video");self._element.addlooseattributeoncondition(self._allowfullscreen,"allowfullscreen");self._element.addcontent(self._source.html());self._element.materialvisibility(self._visibility);self._element.materialzdepth(self._zdepth);self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);self._element.materialhoverable(self._hoverable);return self._element.html();};}function banano_uoebanano_uoeimage() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._responsive=false;this._circle=false;this._url='';this._alt='';this._element= new banano_uoebanano_uoehtml();this._zdepth='';this._visibility='';this._hoverable=false;this._materialboxed=false;this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._enabled=false;this._activator=false;this._static=false;this.setmargintop= function(_stop) {if (self==null) self=this;self.addstyleattribute("margin-top",_stop);return self;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_sid,_imgurl,_imgalt,_bstatic) {if (self==null) self=this;self._app = _thisapp;self._responsive = false;self._activator = false;self._circle = false;self._url = _imgurl;self._alt = _imgalt;self._id = _sid.toLowerCase();self._enabled = true;self._zdepth = "";self._visibility = "";self._hoverable = false;self._materialboxed = false;self._element.initialize(self._id,"img");self._waveseffect = true;self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._static = _bstatic;};this.setsize= function(_imgheight,_imgwidth) {if (self==null) self=this;self._element.setheightpx(_imgheight);self._element.setwidthpx(_imgwidth);return self;};this.tostring= function() {if (self==null) self=this;self._waveseffect = self._responsive;self._element._id = self._id;self._element.materialvisibility(self._visibility);self._element.materialhoverable(self._hoverable);self._element.materialzdepth(self._zdepth);self._element.materialcircle(self._circle);self._element.setalt(self._alt);self._element.setsrc(self._url,self._static);self._element.materialhoverable(self._hoverable);self._element.materialresponsive(self._responsive);self._element.materialboxed(self._materialboxed);self._element.materialwaveseffect(self._waveseffect);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);self._element.adddataattribute("caption",self._alt);self._element.addclassoncondition(self._activator,"activator");return self._element.html();};}function banano_uoebanano_uoeinput() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._title='';this._validate=false;this._theme='';this._placeholder='';this._div= new banano_uoebanano_uoehtml();this._inp= new banano_uoebanano_uoehtml();this._lbl= new banano_uoebanano_uoehtml();this._help= new banano_uoebanano_uoehtml();this._inptype='';this._enabled=false;this._errormsg='';this._successmsg='';this._iconname='';this._maxlength=0;this._required=false;this._hoverable=false;this._zdepth='';this._visibility='';this._helpertext='';this._inline=false;this._text='';this._autofocus=false;this._hasautocomplete=false;this._items=[];this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._inp.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_splaceholder,_sinputtype,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._title = _stitle;self._validate = false;self._theme = _themename;self._placeholder = _splaceholder;self._inptype = _sinputtype;self._enabled = true;self._required = false;self._errormsg = "Error";self._successmsg = "Success";self._text = "";self._div.initialize(self._id+"p","div");self._div.addclass("input-field");self._div.addclass("col");self._div.addclass("s12");self._div.addclass("m12");self._div.addclass("l12");self._inp.initialize(self._id,"input");self._inp.addattribute("placeholder",self._placeholder);self._inp.addattribute("type",self._inptype);self._lbl.initialize("","label");self._lbl.addattribute("for",self._id);self._lbl.addcontent(self._title);self._lbl.addclass("active");self._help.initialize("","span");self._help.addclass("helper-text");self._helpertext = "";self._inline = false;self._hasautocomplete = false;self._maxlength = 0;self._autofocus = false;self._items.length=0;self._items.length=0;self._instance = "" + self._id + "inst";};this.additem= function(_itemtext,_itemurl) {if (self==null) self=this;var _im;self._hasautocomplete = true;_im={"id":_itemurl, "text":_itemtext};self._items.push(_im);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._div.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._div.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._div.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._div.removeattribute(_attr);return self;};this.setmessages= function(_onerror,_onsuccess) {if (self==null) self=this;self._errormsg = _onerror;self._successmsg = _onsuccess;return self;};this.tostring= function() {if (self==null) self=this;self._div.materialvisibility(self._visibility);self._div.materialhoverable(self._hoverable);self._div.materialzdepth(self._zdepth);self._app.applytooltip(self._id,self._div);self._div.addclassoncondition(self._inline,"inline");self._div.addstyleattributeoncondition(self._inline,"display","inline-block");self._div.addattributeoncondition(self._autofocus,"autofocus","true");self._inp.addclassoncondition(self._validate,"validate");self._inp.materialrequired(self._required);self._inp.addclassoncondition(self._hasautocomplete,"autocomplete");self._inp.addlooseattributeonfalsecondition(self._enabled,"disabled");self._inp.addattribute("name",self._id);self.addredstar(self._required,self._lbl);self._help.addattribute("data-error",self._errormsg);self._help.addattribute("data-success",self._successmsg);self._help.addcontent(self._helpertext);_banano_uoebanano_moduoe.materialaddicon(self._app,self._div,self._iconname,"",self._theme,false,false,false,true,false);switch ("" + self._inptype) {case "" + self._app._enuminputtype._textarea:self._inp.removeattribute("type");self._inp.settag("textarea");self._inp.addclass("materialize-textarea");self._inp.removeclass("validate");break;}self._inp.addattribute("data-length",self._maxlength);self._inp.addattribute("data-instance",self._inp._tag);self._inp.addattribute("value",self._text);self._div.addcontent(self._inp.html());self._div.addcontent(self._lbl.html());self._div.addelement(self._help);return self._div.html();};this.addredstar= function(_brequired,_element) {if (self==null) self=this;var _span;if (_brequired == true) {_span= new banano_uoebanano_uoehtml();_span.initialize("","span");_span.addcontent("{NBSP}").addcontent("*");self._app.materialusetheme("redtransparent",_span);_element.addcontent(_span.html());}return _element;};this.selectoption= function(_varname) {if (self==null) self=this;var _script;_script="" + self._instance + ".selectOption(" + _varname + ");";return _script;};this.updatedata= function(_varname) {if (self==null) self=this;var _script;_script="" + self._instance + ".updateData(" + _varname + ");";return _script;};this.getactiveindex= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = " + self._instance + ".activeIndex;";return _script;};this.buildautocomplete= function() {if (self==null) self=this;var _sb;var _kcnt;var _ktot;var _ac;var _mk;var _mv;var _script;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("data: {");_sb.append("\n");_kcnt=0;_ktot=self._items.length-1;_ac=self._items[0];_mk=_ac["id"];_mv=_ac["text"];_script="\"" + _mv + "\":" + _mk + "";_sb.append(_script);for (_kcnt=1;_kcnt<=_ktot;_kcnt++) {_ac=self._items[_kcnt];_mk=_ac["id"];_mv=_ac["text"];_script="\"" + _mv + "\":" + _mk + "";_sb.append(",");_sb.append(_script);}_sb.append("}");return _sb.toString();};}function banano_uoebanano_moduoe() {var self;this._resources={};this.prepareresources= function() {if (self==null) self=this;self._resources={};self._resources={};self.addresource("materialfont.css");self.addresource("materialize.min.css");self.addresource("preloader.css");self.addresource("jquery-3.3.1.min.js");self.addresource("jquery.timeago.min.js");self.addresource("materialize.min.js");self.addresource("all.min.css");self.addresource("all.min.js");self.addresource("nouislider.css");self.addresource("nouislider.min.js");self.addresource("jquery.sweet-modal.min.css");self.addresource("jquery.sweet-modal.min.js");self.addresource("Blob.min.js");self.addresource("canvas-toBlob.js");self.addresource("dom-to-image.min.js");self.addresource("FileSaver.min.js");self.addresource("printThis.js");self.addresource("jquery.toolbar.css");self.addresource("jquery.toolbar.min.js");self.addresource("billboard.min.css");self.addresource("billboard.pkgd.min.js");self.addresource("tableHTMLExport.js");};this.addresource= function(_sfile) {if (self==null) self=this;self._resources[_sfile]=_sfile;};this.materialaddicon= function(_thisapp,_element,_iconname,_iconpos,_icontheme,_iconcircle,_bwave,_bcursor,_bprefix,_bclose) {if (self==null) self=this;var _iconid;var _icn;_iconid=_element._id+"-icon";if (_element.classexists("fixed-action-btn") == true) {_iconcircle = true;} else if (_element.classexists("halfway-fab") == true) {_iconcircle = true;} else if (_element.classexists("btn-floating") == true) {_iconcircle = true;}if (_iconname.length>0) {_icn= new banano_uoebanano_uoeicon();_icn.initialize(_thisapp,_iconid,_iconname,_icontheme);_icn._iconname = _iconname;_icn._alignment = _iconpos;_icn._addcursor = _bcursor;_icn._circle = _iconcircle;_icn._waveseffect = _bwave;_icn._prefix = _bprefix;_icn._theme = _icontheme;_icn._close = _bclose;_element.addcontent(_icn.tostring());}return _element;};this.materialaddimage= function(_thisapp,_element,_imgurl,_imgalt,_imgheight,_imgwidth,_imgcircle,_imgresponsive,_imgstatic,_topmargin) {if (self==null) self=this;var _img;if (_imgurl.length>0) {_img= new banano_uoebanano_uoeimage();_img.initialize(_thisapp,_element._id+"-img",_imgurl,_imgalt,_imgstatic);_img.setsize(_imgheight,_imgwidth);_img._circle = _imgcircle;_img.setmargintop(_topmargin);_img._responsive = _imgresponsive;_img._static = _imgstatic;_element.addcontent(_img.tostring());}return _element;};this.materialaddbadge= function(_thisapp,_element,_stext,_bnew,_svisibility,_bcircle,_stheme,_baddclass1) {if (self==null) self=this;var _badge;_badge= new banano_uoebanano_uoebadge();_badge.initialize(_thisapp,_element._id+"-badge",_stext,_bnew,_stheme);_badge._circle = _bcircle;_badge._element.materialvisibility(_svisibility);if (_baddclass1 == true) {_badge._element.addclass("badge1");_badge._element.removeclass("badge");}_element.addcontent(_badge.tostring());return _element;};}function banano_uoebanano_uoelabel() {var self;this._id='';this._zdepth='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._truncate=false;this._verticalalign=false;this._visibility='';this._hoverable=false;this._text='';this._flowtext=false;this._alignment='';this._blockquote=false;this._verticallyalign=false;this._blockquotewidth=0;this._app= new banano_uoebanano_uoeapp();this.initialize= function(_thisapp,_pid,_psize,_ptext,_ptheme,_pclass) {if (self==null) self=this;self._app = _thisapp;self._id = _pid.toLowerCase();self._theme = _ptheme;self._element.initialize(self._id,_psize);self._element.addclass(_pclass);self._hoverable = false;self._text = _ptext;self._alignment = "";self._blockquote = false;self._element.addcontent(_ptext);self._verticallyalign = false;self._blockquotewidth = 5;};this.addcolor= function(_value,_color) {if (self==null) self=this;var _span;_span= new banano_uoebanano_uoehtml();_span.initialize("","span");_span.addcontent(_value);_span.materialtextcolor(_color);self._element.addcontent(_span.html());return self;};this.addspan= function(_pid,_ptext,_ptheme,_pclass) {if (self==null) self=this;var _ml;_pid = _pid.toLowerCase();_ml= new banano_uoebanano_uoelabel();_ml.initialize(self._app,_pid,"span",_ptext,_ptheme,_pclass);self._element.addcontent(_ml.tostring());return self;};this.addmailto= function(_emailaddress,_subject,_caption) {if (self==null) self=this;var _a;_subject = _subject.split(" ").join("%20");_a= new banano_uoebanano_uoehtml();_a.initialize("","a");_a.sethref("mailto:" + _emailaddress + "?subject=" + _subject + "").addcontent(_caption);self._element.addcontent(_a.tostring());return self;};this.addtext= function(_stext) {if (self==null) self=this;self._element.addcontent(_stext);return self;};this.addbold= function(_value) {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("{B}").append(_value).append("{/B}");self._element.addcontent(_sb.toString());return self;};this.additalic= function(_value) {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("{I}").append(_value).append("{/I}");self._element.addcontent(_sb.toString());return self;};this.addunderline= function(_value) {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("{U}").append(_value).append("{/U}");self._element.addcontent(_sb.toString());return self;};this.addsubscript= function(_value) {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("{SUB}").append(_value).append("{/SUB}");self._element.addcontent(_sb.toString());return self;};this.addsuperscript= function(_value) {if (self==null) self=this;var _sb;_sb=new StringBuilder();_sb.isinitialized=true;_sb.append("{SUP}").append(_value).append("{/SUP}");self._element.addcontent(_sb.toString());return self;};this.addbreak= function() {if (self==null) self=this;self._element.addcontent("{BR}");return self;};this.addlink= function(_href,_caption) {if (self==null) self=this;var _a;_a= new banano_uoebanano_uoehtml();_a.initialize("","a");_a.sethref(_href).addcontent(_caption);self._element.addelement(_a);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattr= function(_attr) {if (self==null) self=this;self._element.removeattr(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _fcolor;self._element.materialtruncate(self._truncate);self._element.materialvisibility(self._visibility);self._element.materialhoverable(self._hoverable);self._element.materialflowtext(self._flowtext);self._element.materialverticalalign(self._verticalalign);self._element.materialzdepth(self._zdepth);self._element.materialverticalalign(self._verticallyalign);self._element.materialtextalign(self._alignment);self._app.materialusetheme(self._theme,self._element);if (self._blockquote == true) {self._element.settag("blockquote");_fcolor=self._app.getforecolorhex(self._theme);self._element.addstyleattribute("border-left","" + self._blockquotewidth + "px solid " + _fcolor + "");}self._app.applytooltip(self._id,self._element);return self._element.tostring();};}function banano_uoebanano_uoelist() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._visibility='';this._element= new banano_uoebanano_uoehtml();this._order=false;this._items=[];this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.ascircles= function() {if (self==null) self=this;self._element.setliststylecircle();return self;};this.asdisk= function() {if (self==null) self=this;self._element.setliststyledisk();return self;};this.asnone= function() {if (self==null) self=this;self._element.setliststylenone();return self;};this.assquare= function() {if (self==null) self=this;self._element.setliststylesquare();return self;};this.shownumbers= function() {if (self==null) self=this;self._element.settypenumbers();return self;};this.showuppercase= function() {if (self==null) self=this;self._element.settypeuppercase();return self;};this.showlowercase= function() {if (self==null) self=this;self._element.settypelowercase();return self;};this.showuppercaseroman= function() {if (self==null) self=this;self._element.settypeuppercaseroman();return self;};this.showlowercaseroman= function() {if (self==null) self=this;self._element.settypelowercaseroman();return self;};this.initialize= function(_thisapp,_sid,_border,_binline) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._visibility = "";self._order = _border;self._element.initialize(_sid,"ul");if (self._order) {self._element.settag("ol");}self._items.length=0;self._items.length=0;};this.addlink= function(_lnkid,_lnktext,_lnkhref,_lnktheme) {if (self==null) self=this;var _li;var _a;_li= new banano_uoebanano_uoehtml();_li.initialize(self._id+_lnkid,"li");_a= new banano_uoebanano_uoehtml();_a.initialize(_lnkid,"a");_a.sethref(_lnkhref);_a.addcontent(_lnktext);self._app.materialusetheme(_lnktheme,_a);_li.addelement(_a);self._items.push(_li.html());};this.additem= function(_txtid,_txttext,_txttheme) {if (self==null) self=this;var _li;var _p;_li= new banano_uoebanano_uoehtml();_li.initialize(self._id+_txtid,"li");_p= new banano_uoebanano_uoehtml();_p.initialize(_txtid+"-span","span");_p.addcontent(_txttext);self._app.materialusetheme(_txttheme,_p);_li.addelement(_p);self._items.push(_li.html());};this.addimage= function(_itemid,_imgurl,_imgcircle,_imgheight,_imgwidth,_topmargin) {if (self==null) self=this;var _skey;var _md;_itemid = _itemid.toLowerCase();_skey="" + self._id + "" + _itemid + "";_md= new banano_uoebanano_uoehtml();_md.initialize(_skey,"li");_banano_uoebanano_moduoe.materialaddimage(self._app,_md,_imgurl,"",_imgheight,_imgwidth,_imgcircle,true,true,_topmargin);self._items.push(_md.html());};this.adddivider= function(_themename) {if (self==null) self=this;var _div;_div= new banano_uoebanano_uoehtml();_div.initialize("","li");_div.addclass("divider");self._app.materialusetheme(_themename,_div);self._items.push(_div.html());return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element.addcontentlist(self._items);self._element._id = self._id;self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);return self._element.html();};}function banano_uoebanano_uoelistview() {var self;this._id='';this._theme='';this._element= new banano_uoebanano_uoehtml();this._app= new banano_uoebanano_uoeapp();this._visibility='';this._zdepth='';this._enabled=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_itemid,_itemtheme) {if (self==null) self=this;self._app = _thisapp;self._id = _itemid.toLowerCase();self._theme = _itemtheme;self._enabled = true;self._element.initialize(self._id,"ul");self._element.addclass("collapsible");self._element.addattribute("data-collapsible",self._app._enumcollapsibletype._accordion);self._visibility = "";self._zdepth = "";};this.additem= function(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme) {if (self==null) self=this;var _div;var _li;_itemid = _itemid.toLowerCase();_div= new banano_uoebanano_uoeanchor();_div.initialize(self._app,_itemid+"a");_div._element.materialcollapsibleheader(true);_banano_uoebanano_moduoe.materialaddicon(self._app,_div._element,_itemicon,"",_icontheme,false,false,false,false,false);_div._element.addcontent(_itemtext);_banano_uoebanano_moduoe.materialaddbadge(self._app,_div._element,_itembadge,_badgenew,self._app._enumvisibility._visible,true,"",false);_div._waveseffect = true;_div._wavestype = self._app._enumwavestype._light;_div._textvisible = true;_div._theme = _itemtheme;_div._href = _itemnavigateto;_li= new banano_uoebanano_uoehtml();_li.initialize(_itemid,"li");_li.addcontent(_div.tostring());self._element.addelement(_li);};this.addcontainer= function(_itemid,_cont) {if (self==null) self=this;var _li;_li= new banano_uoebanano_uoehtml();_li.initialize(_itemid,"li");_li.addcontent(_cont.tostring());self._element.addelement(_li);};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);return self._element.html();};}function banano_uoebanano_uoemodal() {var self;this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._id='';this._enabled=false;this._visibility='';this._content= new banano_uoebanano_uoecontainer();this._dismissible=false;this._preventscrolling=false;this._fixedfooter=false;this._footer= new banano_uoebanano_uoecontainer();this._header= new banano_uoebanano_uoecontainer();this._isbottomsheet=false;this._startingtop='';this._endingtop='';this._theme='';this._instance='';this._fields=[];this._hidescrollbar=false;this.initialize= function(_thisapp,_mvarid,_mtheme) {if (self==null) self=this;self._app = _thisapp;self._id = _mvarid.toLowerCase();self._element.initialize(self._id,"div");self._enabled = true;self._theme = _mtheme;self._header.initialize(self._app,self._id+"header",false,"");self._content.initialize(self._app,self._id+"content",false,"");self._content.addclass("modal-content");self._footer.initialize(self._app,self._id+"footer",false,"");self._footer.addclass("modal-footer");self._preventscrolling = true;self._dismissible = false;self._fixedfooter = false;self._isbottomsheet = false;self._startingtop = "4%";self._endingtop = "10%";self._instance = "" + self._id + "inst";self._fields.length=0;self._fields.length=0;self._hidescrollbar = true;};this.getcss= function() {if (self==null) self=this;var _sel;var _cssmap;var _strcss;_sel="#" + self._id + "";_cssmap={};_cssmap={};_cssmap={};_cssmap["overflow"]="hidden";_cssmap["id"]=_sel;_strcss=self._app.map2json(_cssmap);return _strcss;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.addclass("modal");self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialvisibility(self._visibility);self._element.addcontent(self._header.tostring());self._element.addcontent(self._content.tostring());self._element.addcontent(self._footer.tostring());if (self._fixedfooter) {self._element.addclass("modal-fixed-footer");}if (self._isbottomsheet) {self._element.addclass("bottom-sheet");}return self._element.html();};this.getsettings= function() {if (self==null) self=this;var _ms;var _str;_ms={};_ms={};_ms={};_ms["id"]=self._id;_ms["instance"]="modal";_ms["startingTop"]=self._startingtop;_ms["endingTop"]=self._endingtop;_ms["dismissible"]=self._dismissible;_ms["preventScrolling"]=self._preventscrolling;_str=self._app.map2json(_ms);return _str;};this.open= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".open();";eval(_script);};this.destroy= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".destroy();";eval(_script);};this.close= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Modal.getInstance(inst" + self._id + "); \n	" + self._instance + ".close();";eval(_script);};}function banano_uoebanano_uoenavbar() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._visibility='';this._nw= new banano_uoebanano_uoehtml();this._logo= new banano_uoebanano_uoehtml();this._leftmenu= new banano_uoebanano_uoehtml();this._rightmenu= new banano_uoebanano_uoehtml();this._leftmenuvisibility='';this._rightmenuvisibility='';this._logoposition='';this._pcol= new banano_uoebanano_uoehtml();this._fixed=false;this._dropdowns={};this._content= new banano_uoebanano_uoecontainer();this._hascontents=false;this._drawer= new banano_uoebanano_uoesidebar();this._showmenuonlarge=false;this._hastabs=false;this._tabs= new banano_uoebanano_uoehtml();this.addtab= function(_tabid,_tabtext,_tabdisabled,_tabcont) {if (self==null) self=this;var _li;var _a;var _dv;self._hastabs = true;self._hascontents = true;_li= new banano_uoebanano_uoehtml();_li.initialize(_tabid+"li","li");_li.addclass("tab");_li.addclassoncondition(_tabdisabled,"disabled");_a= new banano_uoebanano_uoehtml();_a.initialize(_tabid,"a");_a.sethref("#"+_tabid+"dv");_a.addcontent(_tabtext);_li.addelement(_a);self._tabs.addelement(_li);_dv= new banano_uoebanano_uoehtml();_dv.initialize(_tabid+"dv","div");if (_tabcont!=null) {_dv.addcontent(_tabcont.tostring());}self._content.addcontent(_dv.html());};this.initialize= function(_thisapp,_sid,_stitle,_stitleposition,_bfixed,_bfixdrawer,_stheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._theme = _stheme;self._element.initialize(self._id,"nav");self._element.setrole("navigation");self._nw.initialize("navwrapper","div");self._nw.addclass("nav-wrapper");self._logo.initialize("brandlogo","a");self._logo.addclass("brand-logo");self._logo.addcontent(_stitle);self._logo.materialvisibility(self._app._enumvisibility._showonmediumandup);self._leftmenu.initialize(self._id+"leftmenu","ul");self._rightmenu.initialize(self._id+"rightmenu","ul");self._rightmenu.addclass("right");self._pcol.initialize("pcol"+self._id,"div");self._pcol.addclass("col");self._pcol.addclass("s12");self._logoposition = _stitleposition;self._leftmenuvisibility = self._app._enumvisibility._hideonmedanddown;self._rightmenuvisibility = self._app._enumvisibility._hideonmedanddown;self._fixed = _bfixed;self._dropdowns={};self._dropdowns={};self._content.initialize(self._app,"navcontent"+self._id,false,"");self._content.addclass("nav-content");self._hascontents = false;self._hastabs = false;self._drawer.initialize(self._app,self._id+"drawer",_bfixdrawer,false,"");self._showmenuonlarge = !(_bfixdrawer);self._tabs.initialize("navtabs"+self._id,"ul");self._tabs.addclass("tabs");self._tabs.addclass("tabs-transparent");};this.addsubtitle= function(_stitle) {if (self==null) self=this;var _el;_el= new banano_uoebanano_uoehtml();_el.initialize("","span");_el.addcontent(_stitle);_el.addclass("nav-title");self._content.addcontent(_el.html());};this.addfab= function(_sid,_iconname,_bsize,_href,_bpulse,_bvisibility,_btheme) {if (self==null) self=this;var _btn;_sid = _sid.toLowerCase();_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_sid,"",_btheme);_btn.setbuttontype(self._app._enumbuttontype._halfwayfab);_btn.addicon(_iconname,"","",false,false);_btn._size = _bsize;_btn._href = _href;_btn._visibility = _bvisibility;_btn._pulsing = _bpulse;self._content.addcontent(_btn.tostring());self._hascontents = true;};this.adddividerr= function(_themename) {if (self==null) self=this;var _div;_div= new banano_uoebanano_uoehtml();_div.initialize("","li");_div.addclass("divider");self._app.materialusetheme(_themename,_div);self._rightmenu.addcontentline(_div.html());};this.adddividerl= function(_themename) {if (self==null) self=this;var _div;_div= new banano_uoebanano_uoehtml();_div.initialize("","li");_div.addclass("divider");self._app.materialusetheme(_themename,_div);self._leftmenu.addcontentline(_div.html());};this.builddropdownstructures= function() {if (self==null) self=this;var _strkey;var _ditems;var _li;var _items;var _strkeyKeys = Object.keys(self._dropdowns);for (var _strkeyindex=0;_strkeyindex<_strkeyKeys.length;_strkeyindex++) {_strkey=_strkeyKeys[_strkeyindex];_ditems=_strkey+"items";_li= new banano_uoebanano_uoehtml();_li.initialize(_ditems,"ul");_li.addclass("dropdown-content");_items=self._dropdowns[_strkey];_li.addcontentlist(_items);self._element.addcontent(_li.html());}};this.additemleft= function(_iid,_href,_itext,_itheme) {if (self==null) self=this;self.additem(_iid,_href,_itext,"",self._app._enummenupos._left,false,_itheme);};this.additemright= function(_iid,_href,_itext,_itheme) {if (self==null) self=this;self.additem(_iid,_href,_itext,"",self._app._enummenupos._right,false,_itheme);};this.additem= function(_iid,_ihref,_itext,_ivisibility,_ileftorright,_bactive,_itheme) {if (self==null) self=this;var _skey;var _item;var _a;_skey="" + self._id + "" + _iid + "";_item= new banano_uoebanano_uoehtml();_item.initialize(_skey+"li","li");_item.addclassoncondition(_bactive,"active");_a= new banano_uoebanano_uoehtml();_a.initialize(_iid,"a");_a.sethref(_ihref);_a.addcontent(_itext);_a.materialvisibility(_ivisibility);_item.addelement(_a);switch ("" + _ileftorright) {case "" + "left":self._leftmenu.addelementline(_item);break;case "" + "right":self._rightmenu.addelementline(_item);break;}};this.adddropdownitem= function(_pid,_iid,_ihref,_itext,_ivisibility,_itheme) {if (self==null) self=this;var _pkey;var _skey;var _item;var _a;var _items;var _scode;if (_ihref == "") {_ihref = "#!";}_pkey="" + self._id + "" + _pid + "";if ((_pkey in self._dropdowns) == false) { return ;}_skey="" + _pkey + "" + _iid + "";_item= new banano_uoebanano_uoehtml();_item.initialize(_skey+"li","li");_a= new banano_uoebanano_uoehtml();_a.initialize(_iid,"a");_a.sethref(_ihref);_a.addcontent(_itext);_a.materialvisibility(_ivisibility);_item.addelement(_a);_items=self._dropdowns[_pkey];_scode=_item.tostring();_scode = _scode.split("\n").join("");_items.push(_scode);self._dropdowns[_pkey]=_items;};this.adddropdownitem1= function(_parentid,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_bhasdivider,_itemtheme) {if (self==null) self=this;var _pkey;var _dpi;var _items;var _scode;_itemid = _itemid.toLowerCase();_parentid = _parentid.toLowerCase();if (_itemnavigateto == "") {_itemnavigateto = "#!";}_pkey="" + self._id + "" + _parentid + "";if ((_pkey in self._dropdowns) == false) { return ;}_itemicon = "";_dpi= new banano_uoebanano_uoedropdownitem();_dpi.initialize(self._app,_pkey,_itemid,_itemicon,_itemtext,_itemnavigateto,_itemactive,_itemtheme);_dpi._li.materialadddivideroncondition(_bhasdivider,self._app._enumvisibility._visible,_itemtheme);_items=self._dropdowns[_pkey];_scode=_dpi.tostring();_scode = _scode.split("\n").join("");_items.push(_scode);self._dropdowns[_pkey]=_items;};this.adddropdowndivider= function(_pid) {if (self==null) self=this;var _pkey;var _md;var _items;var _scode;_pkey="" + self._id + "" + _pid + "";if ((_pkey in self._dropdowns) == false) { return ;}_md= new banano_uoebanano_uoehtml();_md.initialize("","li");_md.addclass("divider");_items=self._dropdowns[_pkey];_scode=_md.tostring();_scode = _scode.split("\n").join("");_items.push(_scode);self._dropdowns[_pkey]=_items;};this.addimagel= function(_itemid,_imgurl,_imgcircle,_imgheight,_imgwidth,_topmargin) {if (self==null) self=this;var _skey;var _md;_itemid = _itemid.toLowerCase();_skey="" + self._id + "" + _itemid + "";_md= new banano_uoebanano_uoehtml();_md.initialize(_skey,"li");_banano_uoebanano_moduoe.materialaddimage(self._app,_md,_imgurl,"",_imgheight,_imgwidth,_imgcircle,true,true,_topmargin);self._leftmenu.addcontentline(_md.html());};this.adddropdownavatar= function(_itemid,_imgurl,_imgcircle,_itemtext,_itempos,_itemvisibility,_bconstrainwidth,_itemtheme) {if (self==null) self=this;var _skey;var _dp;var _drpitems;_itemid = _itemid.toLowerCase();_skey="" + self._id + "" + _itemid + "";_dp= new banano_uoebanano_uoedropdown();_dp.initialize(self._app,_skey,_itemtext,_itemvisibility,false,_bconstrainwidth,_itemtheme);_banano_uoebanano_moduoe.materialaddimage(self._app,_dp._a,_imgurl,"",self._app._itemheight,self._app._itemheight,_imgcircle,true,true,"5px");if (_itempos.toLowerCase() == "right") {self._rightmenu.addcontentline(_dp.tostring());} else {self._leftmenu.addcontentline(_dp.tostring());}_drpitems=[];_drpitems.length=0;_drpitems.length=0;self._dropdowns[_skey]=_drpitems;};this.additembadge= function(_itemid,_iconname,_iconalign,_itemtext,_href,_textvisible,_itemactive,_badgetext,_badgenew,_itemvisibility,_itempos,_itemtheme,_badgetheme) {if (self==null) self=this;var _skey;var _li;var _ai;_itemid = _itemid.toLowerCase();_skey="" + self._id + "" + _itemid + "";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_li.materialvisibility(_itemvisibility);if (_itemactive == true) {_li.addclass("active");}_ai= new banano_uoebanano_uoeanchoricon();_ai.initialize(self._app,_itemid,_iconname,_iconalign,false,_itemtext,_href,_textvisible,_itemtheme,"");_banano_uoebanano_moduoe.materialaddbadge(self._app,_ai._a,_badgetext,_badgenew,self._app._enumvisibility._visible,true,_badgetheme,false);_li.addcontent(_ai.tostring());if (_itempos.toLowerCase() == "right") {self._rightmenu.addcontentline(_li.html());} else {self._leftmenu.addcontentline(_li.html());}};this.addicon= function(_itemid,_iconname,_itemnavigateto,_itemactive,_itempos,_itemvisibility,_itemtheme) {if (self==null) self=this;var _skey;var _li;var _ai;_skey="" + self._id + "" + _itemid + "";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_li.materialvisibility(_itemvisibility);if (_itemactive == true) {_li.addclass("active");}_ai= new banano_uoebanano_uoeanchoricon();_ai.initialize(self._app,_itemid,_iconname,"",false,"",_itemnavigateto,false,_itemtheme,"");_li.addcontent(_ai.tostring());if (_itempos.toLowerCase() == "right") {self._rightmenu.addcontentline(_li.html());} else {self._leftmenu.addcontentline(_li.html());}};this.addiconbadge= function(_itemid,_iconname,_itemnavigateto,_itemactive,_itempos,_itemvisibility,_itemtheme,_sbadge) {if (self==null) self=this;var _skey;var _li;var _ai;_skey="" + self._id + "" + _itemid + "";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_li.materialvisibility(_itemvisibility);if (_itemactive == true) {_li.addclass("active");}_ai= new banano_uoebanano_uoeanchoricon();_ai.initialize(self._app,_itemid,_iconname,"",false,"",_itemnavigateto,false,_itemtheme,"");_banano_uoebanano_moduoe.materialaddbadge(self._app,_ai._a,_sbadge,false,self._app._enumvisibility._visible,false,"",true);_li.addcontent(_ai.tostring());if (_itempos.toLowerCase() == "right") {self._rightmenu.addcontentline(_li.html());} else {self._leftmenu.addcontentline(_li.html());}};this.addavatar= function(_itemid,_itemimageurl,_bcircle,_itemtext,_itemnavigateto,_textvisible,_itempos,_itemvisibility,_itemtheme) {if (self==null) self=this;var _skey;var _li;var _a;var _st;_itemid = _itemid.toLowerCase();_skey="" + self._id + "" + _itemid + "";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_a= new banano_uoebanano_uoeanchoricon();_a.initialize(self._app,_itemid,"","",false,"",_itemnavigateto,_textvisible,_itemtheme,"");_banano_uoebanano_moduoe.materialaddimage(self._app,_a._a,_itemimageurl,"",self._app._itemheight,self._app._itemheight,_bcircle,true,true,self._app._imagetopmargin);_st= new banano_uoebanano_uoespan();_st.initialize(self._app,_itemid+"st",_itemtext,true,self._app._enumvisibility._visible,_itemtheme);_a._text = _st.tostring();_banano_uoebanano_moduoe.materialaddbadge(self._app,_a._a,"",false,self._app._enumvisibility._hide,true,"",false);_li.materialvisibility(_itemvisibility);_li.addcontent(_a.tostring());if (_itempos.toLowerCase() == "right") {self._rightmenu.addcontentline(_li.html());} else {self._leftmenu.addcontentline(_li.html());}};this.addbutton= function(_btnid,_btntext,_btniconname,_btniconalign,_btnnavigateto,_btnsize,_btnvisibility,_btntheme,_icontheme,_btnpos) {if (self==null) self=this;var _skey;var _li;var _btn;_btnid = _btnid.toLowerCase();_skey="" + self._id + "" + _btnid + "";_li= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_btn= new banano_uoebanano_uoebutton();_btn.initialize(self._app,_btnid,_btntext,_btntheme);_btn._visibility = _btnvisibility;_btn._href = _btnnavigateto;_btn.setbuttontype(self._app._enumbuttontype._raised);_btn.addicon(_btniconname,_btniconalign,_icontheme,false,false);_btn._size = _btnsize;_li.addcontent(_btn.tostring());if (_btnpos.toLowerCase() == "right") {self._rightmenu.addcontentline(_li.html());} else {self._leftmenu.addcontentline(_li.html());}};this.adddropdown= function(_iid,_itext,_ivisibility,_ileftorright,_bhover,_bcovertrigger,_closeonclick,_constrainwidth,_itheme) {if (self==null) self=this;var _skey;var _li;var _a;var _i;var _items;_skey="" + self._id + "" + _iid + "";_li= new banano_uoebanano_uoehtml();_a= new banano_uoebanano_uoehtml();_i= new banano_uoebanano_uoehtml();_li.initialize(_skey+"li","li");_a.initialize(_iid,"a");_a.addattribute("data-target",_skey+"items");_a.addcontent(_itext);_a.addclass("dropdown-trigger");_i.initialize("","i");_i.addclass("material-icons");_i.addclass("right");_i.addcontent("keyboard_arrow_right");_a.addelement(_i);_li.addelement(_a);_items=[];_items.length=0;_items.length=0;self._dropdowns[_skey]=_items;switch ("" + _ileftorright) {case "" + "left":self._leftmenu.addelementline(_li);break;case "" + "right":self._rightmenu.addelementline(_li);break;}};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);};this.tostring= function() {if (self==null) self=this;var _menu;var _i;var _df;if (self._theme == "") {self._theme = self._app._theme;}self.builddropdownstructures();self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.materialvisibility(self._visibility);self._logo.addclass(self._logoposition);self._nw.addelement(self._logo);_menu= new banano_uoebanano_uoehtml();_menu.initialize("navmenu","a");_menu.sethref("#");_menu.addattribute("data-target",self._id+"drawer");_menu.addclassoncondition(self._showmenuonlarge,"show-on-large");_menu.addclass("sidenav-trigger");_i= new banano_uoebanano_uoehtml();_i.initialize("","i");_i.addclass("material-icons");_i.addcontent("menu");_menu.addelement(_i);self._nw.addelement(_menu);self._leftmenu.materialvisibility(self._leftmenuvisibility);self._rightmenu.materialvisibility(self._rightmenuvisibility);self._nw.addelement(self._leftmenu);self._nw.addelement(self._rightmenu);self._element.addclassoncondition(self._hascontents,"nav-extended");self._pcol.addelement(self._nw);if (self._hascontents) {self._pcol.addcontent(self._content.tostring());}self._element.addelement(self._pcol);if (self._fixed) {_df= new banano_uoebanano_uoehtml();_df.initialize(self._id+"fixed","div");_df.addclass("navbar-fixed");_df.addelement(self._element);return _df.html();} else {return self._element.html();}};}function banano_uoebanano_uoepage() {var self;this._theme='';this._app= new banano_uoebanano_uoeapp();this._id='';this._pagemain= new banano_uoebanano_uoehtml();this._content= new banano_uoebanano_uoecontainer();this._pageheader= new banano_uoebanano_uoehtml();this._pagefooter= new banano_uoebanano_uoehtml();this._footer= new banano_uoebanano_uoecontainer();this._hasfooter=false;this._fixedfooter=false;this._hascopyright=false;this._backgroundimage='';this._navbar= new banano_uoebanano_uoenavbar();this._drawer= new banano_uoebanano_uoesidebar();this._autosizelogo=false;this.callmethod= function(_sappname,_sclassname,_smethod) {if (self==null) self=this;var _script;_sappname = _sappname.toLowerCase();_sclassname = _sclassname.toLowerCase();_smethod = _smethod.toLowerCase();_script="_banano_" + _sappname + "_" + _sclassname + "." + _smethod + "";_script = _script.split("__").join("_");return _script;};this.printthis= function(_elid) {if (self==null) self=this;var _j;var _script;_elid = _elid.toLowerCase();_j="$";_script="" + _j + "('#" + _elid + "').printThis();";return _script;};this.getlocalstorage= function(_skey) {if (self==null) self=this;var _svalue;_skey = _skey.toLowerCase();_svalue=vault.get(_skey);_svalue = self._app.cstr(_svalue);_svalue = _svalue.split("undefined").join("");_svalue = _svalue.split("null").join("");_svalue = _svalue.trim();return _svalue;};this.setlocalstorage= function(_skey,_svalue) {if (self==null) self=this;_skey = _skey.toLowerCase();vault.set(_skey,_svalue);};this.toasterror= function(_serror) {if (self==null) self=this;self.execute(self.showerror(_serror));};this.toastsuccess= function(_ssuccess) {if (self==null) self=this;self.execute(self.showsuccess(_ssuccess));};this.gettextbox= function(_elid) {if (self==null) self=this;var _elkey;var _stext;_elid = _elid.toLowerCase();_elkey="#" + _elid + "";_stext=u(_elkey).value();_stext = _stext.trim();return _stext;};this.settextbox= function(_elid,_txtvalue) {if (self==null) self=this;var _j;var _el;var _slength;var _itype;var _sbcode;var _script;_j="$";_elid = _elid.toLowerCase();_elid = "#" + _elid + "";_el=u(_elid);_el.value(_txtvalue);_slength=_el.attr("data-length");_itype=_el.attr("data-instance");if (_itype == "textarea") {_sbcode=new StringBuilder();_sbcode.isinitialized=true;_script="M.textareaAutoResize(" + _j + "('" + _elid + "'));";_sbcode.append(_script);if (_slength!="0") {_script="" + _j + "('textarea" + _elid + "').characterCounter();";_sbcode.append(_script);}eval(_sbcode.toString());} else if (_itype == "input") {if (_slength!="0") {_script="" + _j + "('input" + _elid + "').characterCounter();";eval(_script);}}};this.setradio= function(_elid,_elvalue) {if (self==null) self=this;BANanoExec("setRadio", window, _elid,_elvalue);};this.getelementbyname= function(_elid) {if (self==null) self=this;var _el;_el=u("[name='" + _elid + "']");return _el;};this.getradio= function(_elid) {if (self==null) self=this;var _svalue;_elid = _elid.toLowerCase();_svalue='';_svalue = BANanoExec("getRadio", window, _elid);return _svalue;};this.sweetmodalalert= function(_stitle,_scontent) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal('" + _stitle + "', '" + _scontent + "');";return _script;};this.sweetmodal= function(_stitle,_scontent) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal({ \n	title: '" + _stitle + "', \n	content: '" + _scontent + "' \n});";self.execute(_script);};this.sweetmodalwarning= function(_stitle,_scontent) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_WARNING \n	});";self.execute(_script);};this.sweetmodalsuccess= function(_stitle,_scontent) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_SUCCESS \n	});";self.execute(_script);};this.sweetmodalerror= function(_stitle,_scontent) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal({ \n	content: '" + _scontent + "', \n	title: '" + _stitle + "', \n	icon: " + _j + ".sweetModal.ICON_ERROR \n	});";self.execute(_script);};this.sweetmodalconfirm= function(_stitle,_scontent,_onyes,_oncancel) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal.confirm('" + _stitle + "', '" + _scontent + "', function() { \n	" + _onyes + " \n}, function() { \n	" + _oncancel + " \n});";self.execute(_script);};this.sweetmodalprompt= function(_stitle,_scontent,_sdefault,_onval) {if (self==null) self=this;var _j;var _script;_j="$";_script="" + _j + ".sweetModal.prompt('" + _stitle + "', '" + _scontent + "', '" + _sdefault + "', function(val) { \n	" + _onval + " \n});";self.execute(_script);};this.initialize= function(_thisapp,_sid,_bcenter,_snavbartitle,_snavbartitleposition,_bnavbarfixed,_bfixdrawer,_stheme,_sclass) {if (self==null) self=this;self._app = _thisapp;self._app.newpage();self._id = _sid.toLowerCase();self._theme = _stheme;self._pagemain.initialize("main","main");self._pageheader.initialize("header","header");self._content.initialize(self._app,_sid,_bcenter,_stheme);self._content.addclass(_sclass);self._pagefooter.initialize("footer","footer");self._pagefooter.addclass("page-footer");self._footer.initialize(self._app,"footer"+_sid,_bcenter,_stheme);self._hasfooter = false;self._fixedfooter = false;self._hascopyright = false;self._backgroundimage = "";self._navbar.initialize(self._app,"navbar",_snavbartitle,_snavbartitleposition,_bnavbarfixed,_bfixdrawer,_stheme);self._drawer = self._navbar._drawer;};this.addtooltip1= function(_sid,_text) {if (self==null) self=this;self.addtooltip(_sid,_text,"",-1);};this.addtooltip= function(_sid,_text,_position,_delay) {if (self==null) self=this;var _tt;_sid = _sid.toLowerCase();if (_position == "") {_position = self._app._tooltipposition;}if (_delay == -1 || _delay == 0) {_delay = self._app._tooltipdelay;}_tt= new banano_uoebanano_uoetooltip();_tt.initialize(_sid,_text,_position,_delay,"");self._app._tooltips[_sid]=_tt;};this.enable= function(_elid,_bstatus) {if (self==null) self=this;var _elkey;_elid = _elid.toLowerCase();_elkey="#" + _elid + "";if (_bstatus) {self.removeattr(_elid,"disabled");} else {u(_elkey).attr("disabled","true");}};this.removeattr1= function(_elid,_attrname) {if (self==null) self=this;var _ekey;_elid = _elid.toLowerCase();_ekey="#" + _elid + "";u(_ekey).attr(_attrname,null);};this.removeattr= function(_elid,_attrname) {if (self==null) self=this;_elid = _elid.toLowerCase();self._app._jq("#" + _elid + "")["removeAttr"](_attrname);};this.showsuccess= function(_scontent) {if (self==null) self=this;var _script;_script=self.showtoast(_scontent,3000,true,"white.green");return _script;};this.showerror= function(_scontent) {if (self==null) self=this;var _script;_script=self.showtoast(_scontent,3000,true,"white.red");return _script;};this.showtoast= function(_scontent,_duration,_brounded,_themename) {if (self==null) self=this;var _tclass;var _div;var _srounded;var _sout;var _str;_tclass=self._app.materialgettheme(_themename);_div= new banano_uoebanano_uoehtml();_div.initialize("","div");_div.addcontent(_scontent);_srounded="";_srounded = self._app.iif(_brounded,"rounded","");_sout=_div.html();_sout = _sout.split("\n").join("");_str="M.toast({html:'" + _sout + "', displayLength:" + _duration + ", classes:'" + _srounded + " " + _tclass + "'});";return _str;};this.showsuccess1= function(_varname) {if (self==null) self=this;var _script;_script="M.toast({html:" + _varname + ", displayLength:3000, classes:'rounded white-text green'});";return _script;};this.showerror1= function(_varname) {if (self==null) self=this;var _script;_script="M.toast({html:" + _varname + ", displayLength:3000, classes:'rounded white-text red'});";return _script;};this.execute= function(_jscode) {if (self==null) self=this;eval(_jscode);};this.create= function(_eventsmethod,_eventhandler) {if (self==null) self=this;var _fcolor;var _bcolor;var _body;var _sdrawer;var _strx;var _foot;var _sbody;var _elbody;var _jsonstyle;var _dptot;var _dpcnt;var _strds;var _dpmap;var _instancetype;var _instanceid;var _dp;var _jstot;var _jscnt;var _jscode;var _csstot;var _csscnt;var _strcss;var _cssmap;var _cssid;var _cssobj;_fcolor=self._app.getforecolorhex(self._theme);_bcolor=self._app.getbackgroundcolorhex(self._theme);if (self._footer._theme == "") {self._footer._theme = self._app._theme;}_body=new StringBuilder();_body.isinitialized=true;self._pagemain.addcontent(self._content.tostring());_sdrawer=self._drawer.tostring();_strx=self._drawer.getsettings();self._app._components.push(_strx);self._drawer.getcss();self._pageheader.addcontent(_sdrawer);self._pageheader.addcontent(self._navbar.tostring());_body.append(self._pageheader.html());_body.append(self._pagemain.html());if (self._hasfooter) {self._app.materialusetheme(self._footer._theme,self._footer._element);self._app.materialusetheme(self._footer._theme,self._pagefooter);self._pagefooter.addcontent(self._footer.tostring());if (self._hascopyright) {_foot= new banano_uoebanano_uoecopyrights();_foot.initialize(self._app,"foot",self._footer._theme);_foot.addtermsandconditions();_foot.adddisclaimer();_foot.addprivacypolicy();self._pagefooter.addcontent(_foot.tostring());}_body.append(self._pagefooter.html());}_sbody=_body.toString();_elbody=u("#body");_elbody.empty();_elbody.html(_sbody);_elbody.addClass(_bcolor);eval("M.AutoInit();");if (self._autosizelogo) {_jsonstyle="{ \"font-size\": \"2.1vw\", \"font-weight\": \"bold\" }";u("#navbar").css(JSON.parse(_jsonstyle));}_jsonstyle="{ \"padding-top\": \"0px\" }";u(".page-footer").css(JSON.parse(_jsonstyle));if (self._fixedfooter) {_jsonstyle="{ \"display\": \"flex\", \"min-height\": \"100vh\", \"flex-direction\": \"column\" }";u("body").css(JSON.parse(_jsonstyle));_jsonstyle="{ \"flex\": \"1 0 auto\" }";u("main").css(JSON.parse(_jsonstyle));}eval("M.updateTextFields();");_dptot=self._app._components.length-1;_dpcnt=0;for (_dpcnt=0;_dpcnt<=_dptot;_dpcnt++) {_strds=self._app._components[_dpcnt];_dpmap=self._app.json2map(_strds);_instancetype=_dpmap["instance"];_instanceid=_dpmap["id"];delete _dpmap["instance"];delete _dpmap["id"];_dp=null;_dp = self._app._jq("#" + _instanceid + "");_dp[_instancetype](_dpmap);}_jstot=self._app._js.length-1;_jscnt=0;for (_jscnt=0;_jscnt<=_jstot;_jscnt++) {_jscode=self._app._js[_jscnt];eval(_jscode);}_csstot=self._app._css.length-1;_csscnt=0;for (_csscnt=0;_csscnt<=_csstot;_csscnt++) {_strcss=self._app._css[_csscnt];_cssmap=self._app.json2map(_strcss);_cssid=_cssmap["id"];delete _cssmap["id"];_strcss = self._app.map2json(_cssmap);_cssobj=null;_cssobj = u(_cssid);_cssobj.css(JSON.parse(_strcss));}self._app.bindevents(_eventsmethod,_eventhandler);};this.pulse= function(_elid,_bstatus) {if (self==null) self=this;var _elkey;_elid = _elid.toLowerCase();_elkey="#" + _elid + "";if (_bstatus) {u(_elkey).addClass("pulse");} else {u(_elkey).removeClass("pulse");}};} function setRadio(vRadioObj, vValue) {     var radios = document.getElementsByName(vRadioObj);     for (var j = 0; j < radios.length; j++) {         if (radios[j].value == vValue) {             radios[j].checked = true;             break;         }     } }  function getRadio(vRadioObj) {     var radios = document.getElementsByName(vRadioObj);     for (var j = 0; j < radios.length; j++) {         if(radios[j].checked) { 			return radios[j].value; 		}  	} 	return ""; } function banano_uoebanano_uoepagination() {var self;this._id='';this._theme='';this._app= new banano_uoebanano_uoeapp();this._visibility='';this._enabled=false;this._el= new banano_uoebanano_uoehtml();this._hoverable=false;this._ptot=0;this._activepagenumber=0;this._links={};this._showarrows=false;this._texts={};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._el.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_totpages,_themename,_classname) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._el.initialize(self._id,"ul");self._el.addclass("pagination");self._el.addclass(_classname);self._enabled = true;self._activepagenumber = 0;self._ptot = _totpages;self._links={};self._links={};self._texts={};self._texts={};self._showarrows = true;self._theme = _themename;self._app.materialusetheme(self._theme,self._el);};this.addlink= function(_pglink) {if (self==null) self=this;var _pgnumber;var _pkey;_pgnumber=Object.keys(self._links).length+1;_pkey="" + self._id + "page" + _pgnumber + "";self._links[_pkey]=_pglink;return self;};this.addlink2= function(_pgtext) {if (self==null) self=this;var _pgnumber;var _pkey;_pgnumber=Object.keys(self._texts).length+1;_pkey="" + self._id + "page" + _pgnumber + "";self._texts[_pkey]=_pgtext;};this.addlinks= function(_lst) {if (self==null) self=this;var _strlink;if (_lst!=null) {for (var _strlinkindex=0;_strlinkindex<_lst.length;_strlinkindex++) {_strlink=_lst[_strlinkindex];self.addlink(_strlink);}}return self;};this.addtexts= function(_lst) {if (self==null) self=this;var _strlink;if (_lst!=null) {for (var _strlinkindex=0;_strlinkindex<_lst.length;_strlinkindex++) {_strlink=_lst[_strlinkindex];self.addlink2(_strlink);}}return self;};this.addlink1= function(_pgnumber,_pglink) {if (self==null) self=this;var _pkey;_pkey="" + self._id + "page" + _pgnumber + "";self._links[_pkey]=_pglink;return self;};this.tostring= function() {if (self==null) self=this;var _la;var _pkey;var _i;var _a;var _pcnt;var _ep;var _href;var _haspkey;var _hastext;var _txt;var _ra;self._el._id = self._id;self._el.materialenable(self._enabled);self._el.materialvisibility(self._visibility);_la= new banano_uoebanano_uoehtml();_pkey="" + self._id + "pagefirst";_la.initialize(self._id+"first","li");_i= new banano_uoebanano_uoehtml();_i.initialize("","i");_i.addclass("waves-effect");_i.addclass("material-icons");_i.addclass("disabled");_i.addcontent("chevron_left");_a= new banano_uoebanano_uoehtml();_a.initialize(_pkey,"a");_a.sethref("#!");_a.addelement(_i);_la.addelement(_a);if (self._showarrows) {self._el.addelement(_la);}_pcnt=0;self._ptot = Object.keys(self._links).length;for (_pcnt=1;_pcnt<=self._ptot;_pcnt++) {_pkey = "" + self._id + "page" + _pcnt + "";_ep= new banano_uoebanano_uoehtml();_ep.initialize("","li");_ep.addclass("waves-effect");_a= new banano_uoebanano_uoehtml();_href="#!";_a.initialize(_pkey,"a");_a.addcontent(_pcnt);_haspkey=(_pkey in self._links);if (_haspkey) {_href = (self._links[_pkey] || "#!");_a.sethref(_href);} else {_a.sethref(_href);}_hastext=(_pkey in self._texts);if (_hastext) {_txt=self._texts[_pkey];_a.materialsettooltip("bottom","300",_txt);}_ep.addelement(_a);if (self._activepagenumber == _pcnt) {_ep.addclass("active");}self._el.addelement(_ep);}_ra= new banano_uoebanano_uoehtml();_pkey = "" + self._id + "pagelast";_ra.initialize(self._id+"last","li");_a= new banano_uoebanano_uoehtml();_a.initialize(_pkey,"a");_a.sethref("#!");_i= new banano_uoebanano_uoehtml();_i.initialize("","i");_i.addclass("waves-effect");_i.addclass("material-icons");_i.addcontent("chevron_right");_a.addelement(_i);_ra.addelement(_a);if (self._showarrows) {self._el.addelement(_ra);}return self._el.html();};this.addclass= function(_sclass) {if (self==null) self=this;self._el.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._el.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._el.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._el.removeattribute(_attr);return self;};}function banano_uoebanano_uoeparallax() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._image='';this._enabled=false;this._element= new banano_uoebanano_uoehtml();this._visibility='';this._instance='';this._height=0;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_simage) {if (self==null) self=this;var _div;var _img;self._app = _thisapp;self._id = _sid.toLowerCase();self._enabled = true;self._image = _simage;self._element.initialize(self._id,"div");_div= new banano_uoebanano_uoehtml();_div.initialize("","div");_div.addclass("parallax");_img= new banano_uoebanano_uoehtml();_img.initialize("","img");_img.setsrc(self._image,true);_div.addelement(_img);self._element.addelement(_div);self._instance = "" + self._id + "inst";self._height = 500;};this.addcontainer= function(_cont) {if (self==null) self=this;self._element.addcontent(_cont.tostring());return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.materialenable(self._enabled).addclass("parallax-container");self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);return self._element.html();};}function banano_uoebanano_uoepreloader() {var self;this._id='';this._app= new banano_uoebanano_uoeapp();this._el= new banano_uoebanano_uoehtml();this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._el.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._el.initialize(self._id,"div");self._el.addclass("preloader-wrapper").addclass("big").addclass("active");};this.tostring= function() {if (self==null) self=this;var _script;self._el._id = self._id;_script="<div class=\"spinner-layer spinner-blue\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-red\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-yellow\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div> \n \n      <div class=\"spinner-layer spinner-green\"> \n        <div class=\"circle-clipper left\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"gap-patch\"> \n          <div class=\"circle\"></div> \n        </div><div class=\"circle-clipper right\"> \n          <div class=\"circle\"></div> \n        </div> \n      </div>";self._el.addcontent(_script);return self._el.html();};this.addclass= function(_sclass) {if (self==null) self=this;self._el.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._el.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._el.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._el.removeattribute(_attr);return self;};}function banano_uoebanano_uoeprogress() {var self;this._id='';this._theme='';this._app= new banano_uoebanano_uoeapp();this._visibility='';this._el= new banano_uoebanano_uoehtml();this._percentage=0;this._perc= new banano_uoebanano_uoehtml();this._mdeterminate=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._el.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_determinate,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._el.initialize(self._id,"div");self._el.addclass("progress");self._mdeterminate = _determinate;self._percentage = 0;self._theme = _themename;return self;};this.tostring= function() {if (self==null) self=this;self._el.materialvisibility(self._visibility);self._perc.initialize("","div");self._perc.addclassoncondition(self._mdeterminate,"determinate");self._perc.addstyleattribute("width","" + self._percentage + "%");if (self._mdeterminate == false) {self._perc.addclassonfalsecondition(false,"indeterminate");}self._el.addelement(self._perc);self._app.applytooltip(self._id,self._perc);return self._el.html();};this.addclass= function(_sclass) {if (self==null) self=this;self._el.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._el.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._el.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._el.removeattribute(_attr);return self;};}function banano_uoebanano_uoeanchor() {var self;this._id='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._enabled=false;this._textvisible=false;this._text='';this._href='';this._visibility='';this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._zdepth='';this._hoverable=false;this._isdiv=false;this._app= new banano_uoebanano_uoeapp();this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._href = "#!";self._text = "";self._visibility = "";self._enabled = true;self._textvisible = true;self._theme = "";self._zdepth = "";self._isdiv = false;self._element.initialize(self._id,"a");self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._waveseffect = true;return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.addcontent= function(_stext) {if (self==null) self=this;self._element.addcontent(_stext);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.sethref(self._href);self._app.materialusetheme(self._theme,self._element);if (self._isdiv == true) {self._element.settag("div");}self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.materialwaveseffect(self._waveseffect);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);if (self._textvisible == true) {self._element.addcontent(self._text);}return self._element.tostring();};}function banano_uoebanano_uoeradio() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._theme='';this._enabled=false;this._hoverable=false;this._withgap=false;this._checked=false;this._visibility='';this._element= new banano_uoebanano_uoehtml();this._zdepth='';this._lbl= new banano_uoebanano_uoehtml();this._inp= new banano_uoebanano_uoehtml();this._spn= new banano_uoebanano_uoehtml();this._inline=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_sname,_svalue,_stitle,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._theme = _themename;self._checked = false;self._enabled = true;self._visibility = "";self._withgap = false;self._element.initialize(self._id,"p");self._lbl.initialize(self._id+"lbl","label");self._inp.initialize(self._id+"inp","input");self._inp.settype("radio");self._inp.setname(_sname);self._inp.setvalue(_svalue);self._spn.initialize(self._id+"-span","span");self._spn.addcontent(_stitle+"{NBSP}{NBSP}");self._inline = false;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.materialhoverable(self._hoverable);self._inp.addattributeoncondition(!(self._enabled),"disabled","disabled");self._inp.addattributeoncondition(self._checked,"checked","checked");self._inp.addclassoncondition(self._withgap,"with-gap");self._lbl.addelement(self._inp);self._lbl.addelement(self._spn);self._element.addelement(self._lbl);self._element.addclassoncondition(self._inline,"inline");self._element.addstyleattributeoncondition(self._inline,"display","inline-block");self._element.addstyleattributeoncondition(self._inline,"padding","0 12px");return self._element.html();};}function banano_uoebanano_uoeradiogroup() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._title='';this._theme='';this._enabled=false;this._container= new banano_uoebanano_uoehtml();this._visibility='';this._zdepth='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._container.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_btitlevisible,_themename) {if (self==null) self=this;var _lbl;self._app = _thisapp;self._id = _sid.toLowerCase();self._theme = _themename;self._enabled = true;self._container.initialize(self._id,"div");if (_btitlevisible) {_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id).addcontent(_stitle);self._app.materialusetheme(_themename,_lbl);self._container.addelement(_lbl);}};this.addclass= function(_sclass) {if (self==null) self=this;self._container.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._container.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._container.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._container.removeattribute(_attr);return self;};this.additem= function(_itemid,_itemvalue,_itemtext,_withgap,_binline,_benabled,_bselected) {if (self==null) self=this;var _rad;_rad= new banano_uoebanano_uoeradio();_rad.initialize(self._app,_itemid,self._id,_itemvalue,_itemtext,"");_rad._checked = _bselected;_rad._enabled = _benabled;_rad._inline = _binline;_rad._withgap = _withgap;self._container.addcontent(_rad.tostring());};this.tostring= function() {if (self==null) self=this;self._container.materialvisibility(self._visibility).materialenable(self._enabled);self._app.materialusetheme(self._theme,self._container);self._container.materialzdepth(self._zdepth).materialvisibility(self._visibility);self._app.applytooltip(self._id,self._container);return self._container.html();};}function banano_uoebanano_uoerange() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._minvalue=0;this._maxvalue=0;this._value=0;this._stepwith=0;this._range= new banano_uoebanano_uoehtml();this._hoverable=false;this._title='';this._enabled=false;this._visibility='';this._zdepth='';this._theme='';this._showtitle=false;this._container= new banano_uoebanano_uoehtml();this.addstyleattribute= function(_attribute,_svalue) {if (self==null) self=this;self._range.addstyleattribute(_attribute,_svalue);return self;};this.initialize= function(_thisapp,_sid,_stitle,_sminvalue,_smaxvalue,_svalue,_sstep,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._maxvalue = _smaxvalue;self._minvalue = _sminvalue;self._value = _svalue;self._title = _stitle;self._stepwith = _sstep;self._range.initialize(self._id+"inp","input");self._range.addattribute("min",self._minvalue);self._range.addattribute("max",self._maxvalue);self._range.addattribute("type","range");self._range.addattribute("step",self._stepwith);self._range.setname(self._id).setvalue(_svalue);self._enabled = true;self._visibility = "";self._theme = _themename;self._showtitle = true;self._container.initialize(self._id,"p");self._container.addclass("range-field");};this.addclass= function(_sclass) {if (self==null) self=this;self._range.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._range.removeclass(_sclass);return self;};this.addattribute= function(_attr,_svalue) {if (self==null) self=this;self._range.addattribute(_attr,_svalue);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._range.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _lbl;self._range.materialenable(self._enabled);self._range.materialzdepth(self._zdepth);self._range.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._range);if (self._showtitle == true) {_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id);_lbl.addcontent(self._title);self._app.materialusetheme(self._theme,_lbl);self._container.addelement(_lbl);}self._container.addcontent(self._range.html());return self._container.html();};}function banano_uoebanano_uoerangeslider() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._minvalue=0;this._maxvalue=0;this._range= new banano_uoebanano_uoehtml();this._hoverable=false;this._title='';this._enabled=false;this._visibility='';this._zdepth='';this._theme='';this._connect=false;this._startat=0;this._stopat=0;this._stepa=0;this._orientation='';this._decimals=0;this._showtitle=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._range.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_lstart,_lstop,_sminvalue,_smaxvalue,_lstep,_bconnect,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._maxvalue = _smaxvalue;self._minvalue = _sminvalue;self._connect = _bconnect;self._startat = _lstart;self._stopat = _lstop;self._stepa = _lstep;self._title = _stitle;self._range.initialize(self._id,"div");self._enabled = true;self._visibility = "";self._theme = _themename;self._orientation = self._app._enumsliderorientation._horizontal;self._decimals = 0;self._showtitle = true;};this.addclass= function(_sclass) {if (self==null) self=this;self._range.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._range.removeclass(_sclass);return self;};this.addattribute= function(_attr,_svalue) {if (self==null) self=this;self._range.addattribute(_attr,_svalue);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._range.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _p;var _lbl;self._range.materialenable(self._enabled);self._range.materialzdepth(self._zdepth);self._range.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._range);if (self._showtitle) {_p= new banano_uoebanano_uoehtml();_p.initialize(self._id+"parent","p");_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id);_lbl.addcontent(self._title);self._app.materialusetheme(self._theme,_lbl);_p.addelement(_lbl);_p.addcontent(self._range.html());return _p.html();} else {return self._range.html();}};this.getsettings= function() {if (self==null) self=this;var _bconnect;var _script;_bconnect=self._app.iif(self._connect,"true","false");_script="var slider" + self._id + " = document.getElementById('" + self._id + "'); \n  noUiSlider.create(slider" + self._id + ", { \n   start: [" + self._startat + ", " + self._stopat + "], \n   connect: " + _bconnect + ", \n   step: " + self._stepa + ", \n   orientation: '" + self._orientation + "', \n   range: { \n	'min': " + self._minvalue + ", \n	'max': " + self._maxvalue + " \n   }, \n   format: wNumb({ \n     decimals: " + self._decimals + " \n   }) \n  });";return _script;};}function banano_uoebanano_uoeselect() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._title='';this._theme='';this._prompt='';this._div= new banano_uoebanano_uoehtml();this._sel= new banano_uoebanano_uoehtml();this._lbl= new banano_uoebanano_uoehtml();this._enabled=false;this._inline=false;this._iconname='';this._multiple=false;this._items=[];this._isicons=false;this._hoverable=false;this._visibility='';this._zdepth='';this._autofocus=false;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._div.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_sicon,_stitle,_sprompt,_bmultiple,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._title = _stitle;self._theme = _themename;self._prompt = _sprompt;self._inline = false;self._enabled = true;self._multiple = _bmultiple;self._iconname = _sicon;self._items.length=0;self._items.length=0;self._isicons = false;self._autofocus = false;self._div.initialize(self._id+"p","div");self._div.addclass("input-field").addclass("col").addclass("s12").addclass("m12").addclass("l12");self._instance = "" + self._id + "inst";return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._div.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._div.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._div.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._div.removeattribute(_attr);return self;};this.additem= function(_itemid,_itemvalue,_itemtext) {if (self==null) self=this;var _opt;_opt= new banano_uoebanano_uoehtml();_opt.initialize(_itemid,"option");_opt.addattribute("value",_itemvalue);_opt.addcontent(_itemtext);self._items.push(_opt.html());return self;};this.addimage= function(_itemid,_itemvalue,_itemtext,_itemimageurl,_itemalignment,_itemcircle) {if (self==null) self=this;var _opt;self._isicons = true;_opt= new banano_uoebanano_uoehtml();_opt.initialize(_itemid,"option");_opt.addattribute("value",_itemvalue);_opt.addattribute("data-icon",_itemimageurl);_opt.addclassoncondition(_itemcircle,"circle");_opt.addclass(_itemalignment);_opt.addcontent(_itemtext);self._items.push(_opt.html());return self;};this.tostring= function() {if (self==null) self=this;var _opt;self._div.materialenable(self._enabled);self._div.materialzdepth(self._zdepth);self._div.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._div);self._div.addclassoncondition(self._inline,"inline");self._sel.initialize(self._id,"select");self._sel.addattributeoncondition(self._autofocus,"autofocus","true");if (self._multiple == true) {self._sel.addlooseattribute("multiple");}self._sel.addclassoncondition(self._isicons,"icons").materialenable(self._enabled);if (self._prompt.length>0) {_opt= new banano_uoebanano_uoehtml();_opt.initialize("","option");_opt.addlooseattribute("disabled").addlooseattribute("selected");_opt.addcontent(self._prompt).addattribute("value","");self._sel.addcontent(_opt.html());}self._sel.addcontentlist(self._items);self._lbl.initialize("","label");self._lbl.addcontent(self._title);_banano_uoebanano_moduoe.materialaddicon(self._app,self._div,self._iconname,"",self._theme,false,false,false,true,false);self._div.addcontent(self._sel.html());self._div.addcontent(self._lbl.html());return self._div.html();};this.getselectedvalues= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = " + self._instance + ".getSelectedValues();";return _script;};}function banano_uoebanano_uoesidebar() {var self;this._id='';this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._items=[];this._drawerwidth=0;this._edge='';this._activesideid='';this._enabled=false;this._theme='';this._visibility='';this._isopen=false;this._isfixed=false;this._draggable=false;this._preventscrolling=false;this._hascollapse=false;this._mc= new banano_uoebanano_uoecollapsible();this.addheader1= function(_itemid,_itemicon,_itemtext,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;self._mc.addheader(_itemid,_itemicon,_itemtext,"",false,"",_itemtheme,_icontheme,_hasdivider);return self;};this.addheaderitem1= function(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;self._mc.addheaderitem(_parentid,_itemid,_itemicon,_itemtext,_itemgoto,"",false,_hasdivider,_itemtheme,_icontheme);return self;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);};this.initialize= function(_thisapp,_sid,_bfixed,_bopen,_stheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._enabled = true;self._visibility = "";self._theme = _stheme;self._isopen = _bopen;self._activesideid = "";self._edge = "left";self._draggable = true;self._isfixed = _bfixed;self._preventscrolling = true;self._hascollapse = false;self._drawerwidth = 300;self._items.length=0;self._items.length=0;self._mc.initialize(self._app,self._id+"collapse",self._app._enumcollapsibletype._accordion,true,"");self._element.initialize(self._id,"ul");self._element.addclass("sidenav");};this.open= function(_idx) {if (self==null) self=this;};this.close= function(_idx) {if (self==null) self=this;};this.getsettings= function() {if (self==null) self=this;var _ms;var _str;_ms={};_ms={};_ms={};_ms["id"]=self._id;_ms["instance"]="sidenav";_ms["draggable"]=self._draggable;_ms["preventScrolling"]=self._preventscrolling;_ms["edge"]=self._edge;_str=self._app.map2json(_ms);return _str;};this.tostring= function() {if (self==null) self=this;var _strsideitem;self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.addclassoncondition(self._isfixed,"sidenav-fixed");self._element.materialenable(self._enabled);self._element.materialvisibility(self._visibility);self._element.addstyleattribute("width",self._drawerwidth+"px");for (var _strsideitemindex=0;_strsideitemindex<self._items.length;_strsideitemindex++) {_strsideitem=self._items[_strsideitemindex];if (_strsideitem == self._id+"collapse") {self._element.addcontent(self._mc.tostring());} else {self._element.addcontent(_strsideitem);}}return self._element.html();};this.getcss= function() {if (self==null) self=this;var _strsize;var _css;var _str;if (self._isfixed) {_strsize="" + self._drawerwidth + "px";_css={};_css={};_css={};_css["id"]="header";_css["padding-left"]=_strsize;_css["width"]="100%";_str=self._app.map2json(_css);self._app._css.push(_str);_css["id"]="main";_str=self._app.map2json(_css);self._app._css.push(_str);_css["id"]="footer";_str=self._app.map2json(_css);self._app._css.push(_str);}};this.getlinks= function(_header) {if (self==null) self=this;var _lst;var _hdrlinks;_lst=[];_lst.length=0;_lst.length=0;_header = _header.toLowerCase();_hdrlinks=self._mc._links;if ((_header in _hdrlinks)) {_lst = _hdrlinks[_header];}return _lst;};this.gettexts= function(_header) {if (self==null) self=this;var _lst;var _hdrnames;_lst=[];_lst.length=0;_lst.length=0;_header = _header.toLowerCase();_hdrnames=self._mc._itemnames;if ((_header in _hdrnames)) {_lst = _hdrnames[_header];}return _lst;};this.addheader= function(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme,_hasdivider) {if (self==null) self=this;if (self._hascollapse == false) {self.addcollapsible();}self._mc.addheader(_itemid,_itemicon,_itemtext,_itembadge,_badgenew,_itemnavigateto,_itemtheme,_icontheme,_hasdivider);};this.addheaderitem= function(_parentid,_itemid,_iconname,_itemtext,_itemnavigateto,_itembadge,_badgenew,_bhasdivider,_itemtheme,_icontheme) {if (self==null) self=this;self._mc.addheaderitem(_parentid,_itemid,_iconname,_itemtext,_itemnavigateto,_itembadge,_badgenew,_bhasdivider,_itemtheme,_icontheme);};this.adduserview= function(_username,_useremail,_userimageurl,_backgroundimageurl) {if (self==null) self=this;var _uli;var _udiv;var _bdiv;var _ui;var _ui1;var _span;var _ui2;var _span1;_uli= new banano_uoebanano_uoehtml();_uli.initialize(self._id+"user","li");_udiv= new banano_uoebanano_uoehtml();_udiv.initialize("","div");_udiv.addclass("user-view");_bdiv= new banano_uoebanano_uoehtml();_bdiv.initialize("","div");_bdiv.addclass("background");_banano_uoebanano_moduoe.materialaddimage(self._app,_bdiv,_backgroundimageurl,"","","",false,false,true,"0px");_udiv.addcontent(_bdiv.html());_ui= new banano_uoebanano_uoeanchor();_ui.initialize(self._app,"");_ui._href = "#!user";_banano_uoebanano_moduoe.materialaddimage(self._app,_ui._element,_userimageurl,"","","",true,true,true,"0px");_udiv.addcontent(_ui.tostring());_ui1= new banano_uoebanano_uoehtml();_ui1.initialize("","a");_ui1.addattribute("href","#!name");_span= new banano_uoebanano_uoehtml();_span.initialize("","span");_span.addclass("white-text name");_span.addcontent(_username);_ui1.addcontent(_span.html());_udiv.addcontent(_ui1.html());_ui2= new banano_uoebanano_uoehtml();_ui2.initialize("","a");_ui2.addattribute("href","mailto:" + _useremail + "");_span1= new banano_uoebanano_uoehtml();_span1.initialize("","span");_span1.addclass("white-text email");_span1.addcontent(_useremail);_ui2.addcontent(_span1.html());_udiv.addcontent(_ui2.html());_uli.addcontent(_udiv.html());self._items.push(_uli.html());};this.adddivider= function() {if (self==null) self=this;var _md;_md= new banano_uoebanano_uoedivider();_md.initialize(self._app,"","");self._items.push(_md.tostring());};this.additem= function(_itemid,_iconname,_itemtext,_itemnavigateto,_bhasdivider,_itemtheme,_icontheme) {if (self==null) self=this;if (self._hascollapse == false) {self.addcollapsible();}self._mc.additem(_itemid,_iconname,_itemtext,"",false,_itemnavigateto,_itemtheme,_icontheme,_bhasdivider);};this.additemimage= function(_itemid,_imgurl,_imgcircle,_itemtext,_href,_bhasdivider,_itemtheme) {if (self==null) self=this;var _li;var _span;_itemid = _itemid.toLowerCase();_li= new banano_uoebanano_uoehtml();_li.initialize(_itemid,"li");_li.addclass("avatar");_li.addclass("no-padding");_li.materialwaveseffect(true);_banano_uoebanano_moduoe.materialaddimage(self._app,_li,_imgurl,"",self._app._imagehw,self._app._imagehw,_imgcircle,true,true,self._app._imagetopmargin);_li.addclass("waves-effect");self._app.materialusetheme(_itemtheme,_li);_li.addattribute("href",_href);_span= new banano_uoebanano_uoehtml();_span.initialize(_itemid+"-title","span");_span.addclass("title");_span.addcontent(_itemtext);self._app.materialusetheme(_itemtheme,_span);_span.addstyleattribute("vertical-align","top");_li.addcontent(_span.html());_li.materialadddivideroncondition(_bhasdivider,self._app._enumvisibility._visible,_itemtheme);self._items.push(_li.html());};this.addcollapsible= function() {if (self==null) self=this;var _skey;var _kpos;_skey="" + self._id + "collapse";_kpos=self._items.indexOf(_skey);if (_kpos == -1) {self._items.push(self._id+"collapse");}};}function banano_uoebanano_uoeslider() {var self;this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._items=[];this._enabled=false;this._id='';this._theme='';this._visibility='';this._zdepth='';this._slides= new banano_uoebanano_uoehtml();this._indicators=false;this._height='';this._transition='';this._interval='';this._hoverable=false;this._fullscreen=false;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_mvarid) {if (self==null) self=this;self._app = _thisapp;self._id = _mvarid.toLowerCase();self._element.initialize(self._id,"div");self._items.length=0;self._items.length=0;self._enabled = true;self._indicators = true;self._transition = "500";self._height = "400";self._interval = "6000";self._theme = "";self._visibility = "";self._zdepth = "";self._slides.initialize(self._id+"slides","ul");self._slides.addclass("slides");self._fullscreen = false;self._instance = "" + self._id + "inst";};this.addslide= function(_slideid,_imgurl,_title,_alignment,_description,_titletheme,_descriptiontheme) {if (self==null) self=this;var _li;var _img;var _content;var _h3;var _h5;_li= new banano_uoebanano_uoehtml();_li.initialize(_slideid,"li");_img= new banano_uoebanano_uoeimage();_img.initialize(self._app,_slideid+"img",_imgurl,"",true);_img._element.addstyleattribute("object-fit","contain");_li.addcontent(_img.tostring());_content= new banano_uoebanano_uoehtml();_content.initialize(_slideid+"content","div");_content.addclass("caption");_content.materialaligntext(_alignment);_h3= new banano_uoebanano_uoehtml();_h3.initialize("","h3");_h3.addcontent(_title);self._app.materialusetheme(_titletheme,_h3);_h5= new banano_uoebanano_uoehtml();_h5.initialize("","h5");_h5.addcontent(_description);self._app.materialusetheme(_descriptiontheme,_h5);_content.addcontent(_h3.html());_content.addcontent(_h5.html());_li.addcontent(_content.html());self._slides.addcontent(_li.html());};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._slides._id = self._id+"slides";self._element.addclass("slider");self._element.addclassoncondition(self._fullscreen,"fullscreen");self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addcontent(self._slides.html());return self._element.html();};this.getsettings= function() {if (self==null) self=this;var _ms;var _str;_ms={};_ms={};_ms={};_ms["id"]=self._id;_ms["instance"]="slider";_ms["indicators"]=self._indicators;_ms["height"]=self._height;_ms["transition"]=self._transition;_ms["interval"]=self._interval;_str=self._app.map2json(_ms);return _str;};this.nextslide= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".next();";return _script;};this.previousslide= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".prev();";return _script;};this.start= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".start();";return _script;};this.pause= function() {if (self==null) self=this;var _script;_script="" + self._instance + ".pause();";return _script;};}function banano_uoebanano_uoespan() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._span= new banano_uoebanano_uoehtml();this._verticalalign=false;this._visibility='';this._text='';this._theme='';this._hoverable=false;this.initialize= function(_thisapp,_sid,_stext,_bverticalalign,_svisibility,_themename) {if (self==null) self=this;self._app = _thisapp;self._span.initialize(_sid,"span");self._verticalalign = _bverticalalign;self._text = _stext;self._theme = _themename;self._visibility = _svisibility;return self;};this.tostring= function() {if (self==null) self=this;self._span._id = self._id;self._span.addstyleattributeoncondition(self._verticalalign,"vertical-align","top");self._span.materialvisibility(self._visibility);self._span.addcontent(self._text);self._app.materialusetheme(self._theme,self._span);return self._span.html();};this.removeclass= function(_sclass) {if (self==null) self=this;self._span.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._span.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._span.removeattribute(_attr);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._span.addclass(_sclass);return self;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._span.addstyleattribute(_attribute,_value);return self;};}function banano_uoebanano_uoeswitch() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._ontext='';this._offtext='';this._enabled=false;this._switch= new banano_uoebanano_uoehtml();this._hoverable=false;this._title='';this._visibility='';this._zdepth='';this._theme='';this._showtitle=false;this._checked=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._switch.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stitle,_sontext,_sofftext,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._ontext = _sontext;self._offtext = _sofftext;self._switch.initialize(self._id,"div");self._switch.addclass("switch");self._title = _stitle;self._theme = _themename;self._enabled = true;self._showtitle = true;self._checked = false;};this.removeclass= function(_sclass) {if (self==null) self=this;self._switch.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._switch.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._switch.removeattribute(_attr);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._switch.addclass(_sclass);return self;};this.tostring= function() {if (self==null) self=this;var _lbl;var _inp;var _span;var _p;self._switch.materialenable(self._enabled);self._switch.materialzdepth(self._zdepth);self._switch.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._switch);self._switch._id = self._id;_lbl= new banano_uoebanano_uoehtml();_lbl.initialize("","label");_lbl.addcontent(self._offtext);_inp= new banano_uoebanano_uoehtml();_inp.initialize("" + self._id + "inp","input");_inp.addattribute("type","checkbox");_inp.addattributeoncondition(!(self._enabled),"disabled","true");_inp.addattributeoncondition(self._checked,"checked","checked");_span= new banano_uoebanano_uoehtml();_span.initialize(self._id+"-span","span");_span.addclass("lever");_lbl.addcontent(_inp.html());_lbl.addcontent(_span.html());_lbl.addcontent(self._ontext);self._switch.addcontent(_lbl.html());if (self._showtitle == false) { return self._switch.html();}_p= new banano_uoebanano_uoehtml();_p.initialize("","p");_lbl= new banano_uoebanano_uoehtml();_lbl.initialize(self._id+"lbl","label");_lbl.setfor(self._id).addcontent(self._title);self._app.materialusetheme(self._theme,_lbl);_p.addelement(_lbl);_p.addcontent(self._switch.html());return _p.html();};}function banano_uoebanano_uoetable() {var self;this._id='';this._app= new banano_uoebanano_uoeapp();this._zdepth='';this._visibility='';this._enabled=false;this._el= new banano_uoebanano_uoehtml();this._hoverable=false;this._thead= new banano_uoebanano_uoehtml();this._tbody= new banano_uoebanano_uoehtml();this._rows=[];this._striped=false;this._highlight=false;this._centered=false;this._responsive=false;this._tfoot= new banano_uoebanano_uoehtml();this._ptable= new banano_uoebanano_uoecontainer();this._headers={};this._hasborder=false;this._overflow=false;this._onrowclick='';this._activerow='';this._caption='';this._headerrows=[];this._footerrows=[];this._canexport=false;this._j="$";this._fields=[];this._columns={};this.gettableheading= function(_colname) {if (self==null) self=this;var _hdr;var _hdrcnt;var _hdrstr;_hdr= new banano_uoebanano_uoetableheading();_hdrcnt=self._fields.indexOf(_colname);if (_hdrcnt>=0) {_hdrstr="head" + _hdrcnt + "";_hdr = self._columns[_hdrstr];}return _hdr;};this.export2json= function() {if (self==null) self=this;var _script;self._canexport = true;_script="" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'json',filename:'" + self._id + ".json'});";return _script;};this.export2csv= function() {if (self==null) self=this;var _script;self._canexport = true;_script="" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'csv',filename:'" + self._id + ".csv'});";return _script;};this.export2txt= function() {if (self==null) self=this;var _script;self._canexport = true;_script="" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'txt',filename:'" + self._id + ".txt'});";return _script;};this.export2pdf= function() {if (self==null) self=this;var _script;self._canexport = true;_script="" + self._j + "(\"#" + self._id + "\").tableHTMLExport({type:'pdf',filename:'" + self._id + ".pdf'});";return _script;};this.tableexport= function() {if (self==null) self=this;var _script;_script="" + self._j + "(\"" + self._id + "\").tableExport();";return _script;};this.getrows= function(_varname) {if (self==null) self=this;var _script;_script="" + _varname + " = getRows" + self._id + "();";return _script;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._el.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_cclass) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._ptable.initialize(self._app,self._id+"p",false,"");self._ptable.addrowsm(1,0,0,"","").addcolumnsosmp(1,0,0,0,12,12,12,0,0,0,0,"","");self._el.initialize(self._id,"table");self._el.addclass(_cclass).setname(self._id);self._el.addstyleattribute("border-collapse","collapse");self._thead.initialize("" + self._id + "thead","thead");self._tbody.initialize("" + self._id + "body","tbody");self._tfoot.initialize("" + self._id + "foot","tfoot");self._fields.length=0;self._fields.length=0;self._rows.length=0;self._rows.length=0;self._columns={};self._columns={};self._enabled = true;self._striped = false;self._highlight = false;self._headers={};self._headers={};self._hasborder = true;self._overflow = false;self._onrowclick = "";self._activerow = "activerow";self._caption = "";self._headerrows.length=0;self._headerrows.length=0;self._footerrows.length=0;self._footerrows.length=0;self._canexport = false;};this.addheading= function(_rowfield,_rowtitle,_rowalignment,_rowtheme,_rowclass,_colspan,_coltag) {if (self==null) self=this;var _rtot;var _rkey;var _hr;var _hdrtot;var _hdrcnt;var _fldname;var _td;var _strcolspan;var _scode;_rtot=self._headerrows.length+1;_rkey="rh" + _rtot + "";_hr= new banano_uoebanano_uoehtml();_hr.initialize(_rkey,"tr");_hdrtot=_rowfield.length-1;_hdrcnt=0;for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_fldname=_rowfield[_hdrcnt];_td= new banano_uoebanano_uoehtml();_td.initialize("","td");_td.setname(_fldname);_td.addclass(_fldname);if (_coltag!=null && _hdrcnt<=_coltag.length) {_td.settag(_coltag[_hdrcnt]);}if (_rowtitle!=null && _hdrcnt<=_rowtitle.length) {_td.addcontent(_rowtitle[_hdrcnt]);}if (_rowtheme!=null && _hdrcnt<=_rowtheme.length) {self._app.materialusetheme(_rowtheme[_hdrcnt],_td);}if (_rowalignment!=null && _hdrcnt<=_rowalignment.length) {_td.addstyleattribute("text-align",_rowalignment[_hdrcnt]);}if (_rowclass!=null && _hdrcnt<=_rowclass.length) {_td.addclass(_rowclass[_hdrcnt]);}if (_colspan!=null && _hdrcnt<=_colspan.length) {_strcolspan=_colspan[_hdrcnt];if (_strcolspan.length>0) {_td.addattribute("colspan",_strcolspan);}}_hr.addelement(_td);}_scode=_hr.tostring();_scode = _scode.split("\n").join("");self._headerrows.push(_scode);};this.addbody= function(_rowfield,_rowtitle,_rowalignment,_rowtheme,_rowclass,_colspan,_coltag) {if (self==null) self=this;var _rtot;var _rkey;var _hr;var _hdrtot;var _hdrcnt;var _fldname;var _td;var _strcolspan;var _scode;_rtot=self._rows.length+1;_rkey="rb" + _rtot + "";_hr= new banano_uoebanano_uoehtml();_hr.initialize(_rkey,"tr");_hdrtot=_rowfield.length-1;_hdrcnt=0;for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_fldname=_rowfield[_hdrcnt];_td= new banano_uoebanano_uoehtml();_td.initialize("","td");_td.setname(_fldname);_td.addclass(_fldname);if (_coltag!=null && _hdrcnt<=_coltag.length) {_td.settag(_coltag[_hdrcnt]);}if (_rowtitle!=null && _hdrcnt<=_rowtitle.length) {_td.addcontent(_rowtitle[_hdrcnt]);}if (_rowtheme!=null && _hdrcnt<=_rowtheme.length) {self._app.materialusetheme(_rowtheme[_hdrcnt],_td);}if (_rowalignment!=null && _hdrcnt<=_rowalignment.length) {_td.addstyleattribute("text-align",_rowalignment[_hdrcnt]);}if (_rowclass!=null && _hdrcnt<=_rowclass.length) {_td.addclass(_rowclass[_hdrcnt]);}if (_colspan!=null && _hdrcnt<=_colspan.length) {_strcolspan=_colspan[_hdrcnt];if (_strcolspan.length>0) {_td.addattribute("colspan",_strcolspan);}}_hr.addelement(_td);}_scode=_hr.tostring();_scode = _scode.split("\n").join("");self._rows.push(_scode);};this.addfooter= function(_rowfield,_rowtitle,_rowalignment,_rowtheme,_rowclass,_colspan,_coltag) {if (self==null) self=this;var _rtot;var _rkey;var _hr;var _hdrtot;var _hdrcnt;var _fldname;var _td;var _strcolspan;var _scode;_rtot=self._footerrows.length+1;_rkey="rb" + _rtot + "";_hr= new banano_uoebanano_uoehtml();_hr.initialize(_rkey,"tr");_hdrtot=_rowfield.length-1;_hdrcnt=0;for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_fldname=_rowfield[_hdrcnt];_td= new banano_uoebanano_uoehtml();_td.initialize("","td");_td.setname(_fldname);_td.addclass(_fldname);if (_coltag!=null && _hdrcnt<=_coltag.length) {_td.settag(_coltag[_hdrcnt]);}if (_rowtitle!=null && _hdrcnt<=_rowtitle.length) {_td.addcontent(_rowtitle[_hdrcnt]);}if (_rowtheme!=null && _hdrcnt<=_rowtheme.length) {self._app.materialusetheme(_rowtheme[_hdrcnt],_td);}if (_rowalignment!=null && _hdrcnt<=_rowalignment.length) {_td.addstyleattribute("text-align",_rowalignment[_hdrcnt]);}if (_rowclass!=null && _hdrcnt<=_rowclass.length) {_td.addclass(_rowclass[_hdrcnt]);}if (_colspan!=null && _hdrcnt<=_colspan.length) {_strcolspan=_colspan[_hdrcnt];if (_strcolspan.length>0) {_td.addattribute("colspan",_strcolspan);}}_hr.addelement(_td);}_scode=_hr.tostring();_scode = _scode.split("\n").join("");self._footerrows.push(_scode);};this.addfootercontainer= function(_cont) {if (self==null) self=this;self._tfoot.addcontent(_cont.tostring());return self;};this.addheadercontainer= function(_cont) {if (self==null) self=this;self._ptable.addcontainer(1,1,_cont);return self;};this.addheadingsthemes= function(_colthemes) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th1;var _th;var _hasheader;_hdrtot=_colthemes.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colthemes[_hdrcnt];if (_hdrname == "") {_hdrname = self._app._theme;}_th1= new banano_uoebanano_uoetableheading();_th= new banano_uoebanano_uoehtml();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}self._app.materialusetheme(_hdrname,_th);_th1._theme = _hdrname;self._headers[_hdrstr]=_th;self._columns[_hdrstr]=_th1;}return self;};this.addheadings= function(_coltitles) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th1;var _th;var _hasheader;_hdrtot=_coltitles.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _coltitles[_hdrcnt];_th1= new banano_uoebanano_uoetableheading();_th= new banano_uoebanano_uoehtml();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.addcontent(_hdrname);_th1._title = _hdrname;self._headers[_hdrstr]=_th;self._columns[_hdrstr]=_th1;}return self;};this.addheadingsfields= function(_colfields) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colfields.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colfields[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.setname(_hdrname);_th.addclass(_hdrname);self._headers[_hdrstr]=_th;self._fields.push(_hdrname);_th1._fieldname = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.addheadingsheights= function(_colheights) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colheights.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colheights[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.addstyleattribute("height",_hdrname+"px");self._headers[_hdrstr]=_th;_th1._height = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.addheadingsalignment= function(_colalign) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colalign.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colalign[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.addstyleattribute("text-align",_hdrname);self._headers[_hdrstr]=_th;_th1._alignment = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.addheadingsclasses= function(_colclass) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colclass.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colclass[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.addclass(_hdrname);self._headers[_hdrstr]=_th;_th1._classname = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.addheadingswidths= function(_colwidths) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colwidths.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colwidths[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.addstyleattribute("width",_hdrname+"px");self._headers[_hdrstr]=_th;_th1._width = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.addheadingsvisibility= function(_colvisibility) {if (self==null) self=this;var _hdrtot;var _hdrcnt;var _hdrstr;var _hdrname;var _th;var _th1;var _hasheader;_hdrtot=_colvisibility.length-1;_hdrcnt=0;_hdrstr='';_hdrname='';for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr = "head" + _hdrcnt + "";_hdrname = _colvisibility[_hdrcnt];_th= new banano_uoebanano_uoehtml();_th1= new banano_uoebanano_uoetableheading();_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th = self._headers[_hdrstr];_th1 = self._columns[_hdrstr];} else {_th.initialize(_hdrstr,"th");_th1.initialize();}_th.materialvisibility(_hdrname);self._headers[_hdrstr]=_th;_th1._visibility = _hdrname;self._columns[_hdrstr]=_th1;}return self;};this.deleterow= function(_rowpos) {if (self==null) self=this;var _script;_script="document.getElementById(\"" + self._id + "\").deleteRow(" + _rowpos + ");";return _script;};this.addrow= function(_data,_datatheme,_dataclass) {if (self==null) self=this;var _rtot;var _rkey;var _tr1;var _scode;_rtot=self._rows.length+1;_rkey="" + self._id + "_r" + _rtot + "";_tr1=self.newrow(_rkey,_data,_datatheme,_dataclass);_scode=_tr1.tostring();_scode = _scode.split("\n").join("");self._rows.push(_scode);return self;};this.getrowscount= function(_varname) {if (self==null) self=this;var _script;_script="var tbl = " + self._j + "('#" + self._id + " tbody tr'); \n" + _varname + " = tbl.length;";return _script;};this.newrow= function(_rkey,_data,_datatheme,_dataclass) {if (self==null) self=this;var _tr1;var _hdrtot;var _hdrcnt;var _cell;var _dkey;var _hdrstr;var _td;var _hasheader;var _th;var _colalignment;var _colfield;var _tdtheme;var _tdclass;_tr1= new banano_uoebanano_uoehtml();_tr1.initialize(_rkey,"tr");_hdrtot=_data.length-1;_hdrcnt=0;for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_cell=_data[_hdrcnt];_dkey="" + _rkey + "_c" + _hdrcnt + "";_hdrstr="head" + _hdrcnt + "";_td= new banano_uoebanano_uoehtml();_td.initialize(_dkey,"td");_td.addcontent(_cell);_hasheader=(_hdrstr in self._headers);if (_hasheader) {_th=self._headers[_hdrstr];_colalignment=_th.getstyleattribute("text-align");_colfield=_th.getattribute("name");_td.addstyleattribute("text-align",_colalignment);_td.setname(_colfield);_td.addclass(_colfield);}if (_datatheme!=null && _hdrcnt<=_datatheme.length) {_tdtheme=_datatheme[_hdrcnt];self._app.materialusetheme(_tdtheme,_td);}if (_dataclass!=null && _hdrcnt<=_dataclass.length) {_tdclass=_dataclass[_hdrcnt];_td.addclass(_tdclass);}_tr1.addelement(_td);}return _tr1;};this.addrow1= function(_pos,_data,_datatheme,_dataclass) {if (self==null) self=this;var _rkey;var _tr1;var _srow;var _script;_rkey="" + self._id + "_r" + DateTime.Now() + "";_tr1=self.newrow(_rkey,_data,_datatheme,_dataclass);switch ("" + _pos) {case "" + -1:_srow=_tr1.tostring();_srow = _srow.split("\n").join("");_script="var newRow = '" + _srow + "'; \n		var tbl = " + self._j + "('#" + self._id + "'); \n		tbl.append(newRow);";return _script;default:_script="var newRow = '" + _srow + "'; \n		$('#" + self._id + " > tbody > tr').eq(" + _pos + "-1).before(newRow);";return _script;}};this.clear= function() {if (self==null) self=this;var _script;_script="" + self._j + "('#" + self._id + " tbody tr').remove();";return _script;};this.tostring= function() {if (self==null) self=this;var _mtot;var _tr;var _mcnt;var _hdrstr;var _hasheader;var _hdr;var _cap;self._ptable._zdepth = self._zdepth;self._el.materialenable(self._enabled);self._el.materialvisibility(self._visibility);self._el.addclassoncondition(self._striped,"striped");self._el.addclassoncondition(self._highlight,"highlight");self._el.addclassoncondition(self._centered,"centered");self._el.addclassoncondition(self._responsive,"responsive-table");_mtot=Object.keys(self._headers).length-1;if (Object.keys(self._headers).length>=0) {_tr= new banano_uoebanano_uoehtml();_tr.initialize("","tr");_mcnt=0;for (_mcnt=0;_mcnt<=_mtot;_mcnt++) {_hdrstr="head" + _mcnt + "";_hasheader=(_hdrstr in self._headers);if (_hasheader) {_hdr=self._headers[_hdrstr];_tr.addelement(_hdr);}}self._thead.addelement(_tr);}self._thead.addcontentlist(self._headerrows);if (self._caption.length>0) {_cap= new banano_uoebanano_uoehtml();_cap.initialize("","caption");_cap.addcontent(self._caption);self._el.addelement(_cap);}self._el.addelement(self._thead);self._tfoot.addcontentlist(self._footerrows);self._el.addelement(self._tfoot);self._tbody.addcontentlist(self._rows);self._el.addelement(self._tbody);self._ptable.addcomponent(1,1,self._el.html());self._ptable.addstyleattributeoncondition(self._overflow,"overflow-x","auto");return self._ptable.tostring();};this.hidecolumn= function(_colfieldname) {if (self==null) self=this;var _script;_script="var tbl" + self._id + " = " + self._j + "(\"#" + self._id + "\"); \n    var tblhead" + self._id + " = " + self._j + "(\"#" + self._id + " th\"); \n	var colToHide" + self._id + " = tblhead" + self._id + ".filter(\"." + _colfieldname + "\"); \n    var index" + self._id + " = colToHide" + self._id + ".index(); \n    tbl" + self._id + ".find('tr :nth-child(' + (index" + self._id + " + 1) + ')').toggle();";return _script;};this.getrowsinternal= function() {if (self==null) self=this;var _hdrcnt;var _hdrtot;var _sb;var _hdrstr;var _hdr;var _colfield;var _script;_hdrcnt=0;_hdrtot=Object.keys(self._headers).length-1;_sb=new StringBuilder();_sb.isinitialized=true;for (_hdrcnt=0;_hdrcnt<=_hdrtot;_hdrcnt++) {_hdrstr="head" + _hdrcnt + "";_hdr=self._headers[_hdrstr];_colfield=_hdr.getattribute("name");if (_colfield.length>0) {_script="var v" + _colfield + " = " + self._id + "row.find(\"[name=" + _colfield + "]\").text(); \n			" + self._id + "obj['" + _colfield + "'] = v" + _colfield + "; \n			" + self._id + "obj['index'] = index;";_sb.append(_script).append("\n");}}_script="var " + self._id + "data = []; \n	" + self._id + "rows = " + self._j + "(\"#" + self._id + " tbody tr\"); \n" + self._id + "rows.each(function (index) { \n    var " + self._id + "row = " + self._j + "(this); \n 	var " + self._id + "obj = {}; \n	" + _sb.toString() + " \n	" + self._id + "data.push(" + self._id + "obj); \n}); \nreturn " + self._id + "data;";};this.addclass= function(_sclass) {if (self==null) self=this;self._el.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._el.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._el.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._el.removeattribute(_attr);return self;};}function banano_uoebanano_uoebadge() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._theme='';this._text='';this._isnew=false;this._visibility='';this._zdepth='';this._circle=false;this._element= new banano_uoebanano_uoehtml();this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._enabled=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_btext,_bisnew,_btheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._text = _btext;self._isnew = _bisnew;self._circle = false;self._element.initialize(self._id,"span");self._element.addclass("badge");self._enabled = true;self._theme = _btheme;self._visibility = self._app._enumvisibility._hide;self._zdepth = "";self._wavestype = "";self._waveseffect = false;self._wavescircle = false;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;if (self._text.length>0) {self._visibility = self._app._enumvisibility._visible;}self._element._id = self._id;self._app.materialusethemeoncondition(!(self._isnew),self._theme,self._element);self._element.materialvisibility(self._visibility).materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle).materialwaveseffect(self._waveseffect).materialzdepth(self._zdepth);self._element.addcontent(self._text).addclassoncondition(self._circle,"circle");self._element.addclassoncondition(self._isnew,"new");self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);return self._element.html();};}function banano_uoebanano_uoetoast() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._text='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._callbackfunction='';this._buttontext='';this._isround=false;this._duration=0;this.initialize= function(_thisapp,_tid,_ttext,_tbuttontext,_tcallback,_tround,_tduration,_ttheme) {if (self==null) self=this;self._app = _thisapp;self._text = _ttext;self._id = _tid.toLowerCase();self._theme = _ttheme;self._element.initialize(self._id,"span");self._callbackfunction = _tcallback;self._buttontext = _tbuttontext;self._isround = _tround;self._duration = _tduration;};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _sb;var _btn;var _tclass;var _srounded;var _js;var _scontent;if (self._theme == "") {self._theme = self._app._theme;}_sb=new StringBuilder();_sb.isinitialized=true;self._element._id = self._id;self._element.addcontent(self._text);_sb.append(self._element.html());if (self._buttontext.length>0) {_btn= new banano_uoebanano_uoehtml();_btn.initialize(self._id+"btn","button");_btn.addclass("btn-flat");_btn.addclass("toast-action");_sb.append(_btn.html());}_tclass=self._app.materialgettheme(self._theme);_srounded="";_srounded = self._app.iif(self._isround,"rounded","");_js='';_scontent=_sb.toString();_scontent = _scontent.split("\n").join("");if (self._callbackfunction == "") {_js = "M.toast({ \n		html:'" + _scontent + "',  \n		displayLength:" + self._duration + ",  \n		classes:'" + _srounded + " " + _tclass + "' \n		});";} else {_js = "M.toast({ \n		html:'" + _scontent + "',  \n		completeCallback:" + self._callbackfunction + ",  \n		displayLength:" + self._duration + ",  \n		classes:'" + _srounded + " " + _tclass + "' \n		});";}return _js;};}function banano_uoebanano_uoetoc() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._visibility='';this._element= new banano_uoebanano_uoehtml();this._items=[];this._theme='';this._events={};this.initialize= function(_thisapp,_sid,_stheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._visibility = "";self._theme = _stheme;self._element.initialize(_sid,"ul");self._element.addclass("section").addclass("table-of-contents");self._items.length=0;self._items.length=0;self._events={};self._events={};};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addlink= function(_lnkid,_lnktext,_lnkhref,_lnktheme) {if (self==null) self=this;var _li;var _a;_li= new banano_uoebanano_uoehtml();_li.initialize(_lnkid+"li","li");_a= new banano_uoebanano_uoehtml();_a.initialize(_lnkid,"a");_a.sethref(_lnkhref).addcontent(_lnktext);self._app.materialusetheme(_lnktheme,_a);_li.addelement(_a);self._items.push(_li.tostring());self.addevent(_lnkid,"click");};this.removeevent= function(_elid) {if (self==null) self=this;var _strevent;var _strkey;var _elm;var _em;var _strsuffix;_elid = _elid.toLowerCase();if ((_elid in self._events)) {_strevent=self._events[_elid];_strkey="#" + _elid + "";delete self._events[_elid];_elm=u(_strkey);_elm.off(_strevent);_em=[];_em.length=0;_em.splice(_em.length,0,["icon","img","badge","title","badge"]);for (var _strsuffixindex=0;_strsuffixindex<_em.length;_strsuffixindex++) {_strsuffix=_em[_strsuffixindex];_strkey="" + _elid + "-" + _strsuffix + "";delete self._events[_strkey];_strkey = "#" + _strkey + "";_elm=u(_strkey);_elm.off(_strevent);}}};this.addevent= function(_elid,_elevent) {if (self==null) self=this;var _em;var _strsuffix;var _strkey;_elid = _elid.toLowerCase();_elid = _elid.trim();_elevent = _elevent.trim();if (_elid.length>0 && _elevent.length>0) {self._events[_elid]=_elevent;_em=[];_em.length=0;_em.splice(_em.length,0,["icon","img","badge","title","badge"]);for (var _strsuffixindex=0;_strsuffixindex<_em.length;_strsuffixindex++) {_strsuffix=_em[_strsuffixindex];_strkey="" + _elid + "-" + _strsuffix + "";self._events[_strkey]=_elevent;}}};this.bindevents= function(_elmethod,_eventhandler) {if (self==null) self=this;var _mtot;var _mcnt;var _elid;var _elevent;var _btnevent;var _elkey;var _elm;_mtot=Object.keys(self._events).length-1;_mcnt=0;for (_mcnt=0;_mcnt<=_mtot;_mcnt++) {_elid=banano_getB4JKeyAt(self._events,_mcnt);_elevent=self._events[_elid];_elid = _elid.trim();_elevent = _elevent.trim();if (_elid.length>0 && _elevent.length>0) {_btnevent="" + _elid + "_" + _elevent + "";_elkey="#" + _elid + "";if (_elmethod.length>0) {_btnevent = _elmethod.toLowerCase();}if (_eventhandler!=null) {_elm=u(_elkey);_elm.off(_elevent);_elm.handle(_elevent, function(event) {if (typeof _eventhandler[_btnevent]==="function") {return _eventhandler[_btnevent](event)}});}}}};this.bindevent= function(_elid,_elevent,_elmethod,_eventhandler) {if (self==null) self=this;var _btnevent;var _skey;var _elm;_elid = _elid.toLowerCase();_elid = _elid.trim();_elevent = _elevent.trim();_btnevent="" + _elid + "_" + _elevent + "";_skey="#" + _elid + "";if (_elid.length>0 && _elevent.length>0) {if (_elmethod.length>0) {_btnevent = _elmethod.toLowerCase();}if (_eventhandler!=null) {_elm=u(_skey);_elm.off(_elevent);_elm.handle(_elevent, function(event) {if (typeof _eventhandler[_btnevent]==="function") {return _eventhandler[_btnevent](event)}});}}};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;if (self._theme == "") {self._theme = self._app._theme;}self._element.addcontentlist(self._items);self._element._id = self._id;self._element.materialvisibility(self._visibility);return self._element.tostring();};}function banano_uoebanano_uoevideo() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._url='';this._visibility='';this._zdepth='';this._element= new banano_uoebanano_uoehtml();this._enabled=false;this._frameborder='';this._width=0;this._height=0;this._iframe= new banano_uoebanano_uoehtml();this._allowfullscreen=false;this._hoverable=false;this._autoplay=false;this._loopit=false;this._showcontrols=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_surl) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._element.initialize(self._id,"div");self._element.addclass("video-container");self._enabled = true;self._zdepth = "";self._visibility = "";self._frameborder = "0";self._width = "853";self._height = "480";self._url = _surl;self._iframe.initialize("","iframe");self._allowfullscreen = true;self._autoplay = false;self._loopit = false;self._showcontrols = true;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._iframe.addstyleattribute("width",self._iframe.makepx(self._width));self._iframe.addstyleattribute("height",self._iframe.makepx(self._height));self._iframe.addattribute("src",self._url);self._iframe.addattribute("frameborder",self._frameborder);self._iframe.addlooseattributeoncondition(self._allowfullscreen,"allowfullscreen");self._iframe.addlooseattribute("playsinline");self._iframe.addattribute("allow","accelerometer");if (self._autoplay) {self._iframe.updateattribute("allow","autoplay");}self._iframe.updateattribute("allow","encrypted-media; gyroscope; picture-in-picture");self._iframe.addlooseattributeoncondition(self._showcontrols,"controls");self._iframe.addlooseattributeoncondition(self._loopit,"loop");self._iframe.addlooseattributeoncondition(self._autoplay,"autoplay");self._element.addcontent(self._iframe.html());self._element.materialvisibility(self._visibility);self._element.materialzdepth(self._zdepth);self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);self._element.materialhoverable(self._hoverable);return self._element.html();};}function banano_uoebanano_uoecolumn() {var self;this._columns=0;this._offsetsmall=0;this._offsetmedium=0;this._offsetlarge=0;this._spansmall=0;this._spanmedium=0;this._spanlarge=0;this._margintop=0;this._marginbottom=0;this._marginleft=0;this._marginright=0;this._paddingtop=0;this._paddingbottom=0;this._paddingleft=0;this._paddingright=0;this._theme='';this._visibility='';this._classname='';this._row=0;this._col=0;this.initialize= function() {if (self==null) self=this;self._columns = 1;self._offsetsmall = 0;self._offsetmedium = 0;self._offsetlarge = 0;self._spansmall = 12;self._spanmedium = 12;self._spanlarge = 12;self._margintop = 0;self._marginbottom = 0;self._marginleft = 0;self._marginright = 0;self._paddingtop = 0;self._paddingbottom = 0;self._paddingright = 0;self._paddingleft = 0;self._theme = "";self._visibility = "";self._classname = "";self._row = 0;self._col = 0;};}function banano_uoebanano_uoerow() {var self;this._rows=0;this._margintop=0;this._marginbottom=0;this._marginleft=0;this._marginright=0;this._paddingtop=0;this._paddingbottom=0;this._paddingleft=0;this._paddingright=0;this._columns=[];this._visibility='';this._themename='';this._classname='';this._row=0;this.initialize= function() {if (self==null) self=this;self._columns.length=0;self._columns.length=0;self._rows = 1;self._margintop = 0;self._marginbottom = 20;self._marginleft = 0;self._marginright = 0;self._paddingtop = 0;self._paddingbottom = 0;self._paddingleft = 0;self._paddingright = 0;self._visibility = "";self._themename = "";self._classname = "";self._row = 0;};}function banano_uoebanano_uoesection() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._content= new banano_uoebanano_uoecontainer();this.initialize= function(_thisapp,_sid,_themename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._content.initialize(self._app,self._id,false,_themename);self._content._section = true;self._content._theme = _themename;};this.tostring= function() {if (self==null) self=this;return self._content.tostring();};}function banano_uoebanano_uoesweetmodal() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._tabs=new StringBuilder();this._tabcontent=new StringBuilder();this._showclosebutton=false;this._title='';this._content='';this._blocking=false;this._width='';this._icon='';this._timeout='';this._j="$";this._icon_success="" + self._j + ".sweetModal.ICON_SUCCESS";this._icon_warning="" + self._j + ".sweetModal.ICON_WARNING";this._icon_error="" + self._j + ".sweetModal.ICON_ERROR";this._hastabs=false;this._tabcount=0;this._buttons=new StringBuilder();this._hasbuttons=false;this._buttontheme_secondaryb="secondaryB";this._buttontheme_redb="redB";this._buttontheme_blueb="blueB";this._buttontheme_greenb="greenB";this._buttontheme_darkgreyb="darkGreyB";this._buttontheme_lightgreyb="lightGreyB";this._buttontheme_yellowb="yellowB";this._buttontheme_purpleb="purpleB";this._buttontheme_tealb="tealB";this._buttontheme_brownb="brownB";this._buttontheme_orangeb="orangeB";this._buttontheme_pinkb="pinkB";this.initialize= function(_thisapp,_sid) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._tabs.isinitialized=true;self._tabcontent.isinitialized=true;self._width = "auto";self._blocking = false;self._hastabs = false;self._icon = "''";self._timeout = "null";self._tabcount = 0;self._buttons.isinitialized=true;self._hasbuttons = false;self._showclosebutton = true;};this.addcontainer= function(_scontent) {if (self==null) self=this;var _scode;self._content = "";if (_scontent!=null) {_scode=_scontent.tostring();_scode = _scode.split("\n").join("");self._content = _scode;}};this.addtab= function(_stitle,_sicon,_scontent) {if (self==null) self=this;var _scode;var _script;_scode="";if (_scontent!=null) {_scode = _scontent.tostring();_scode = _scode.split("\n").join("");}self._tabcount = self._tabcount+1;_script="tab" + self._tabcount + ": {label: '" + _stitle + "', icon: '" + _sicon + "'},";self._tabs.append(_script).append("\n");_script = "tab" + self._tabcount + ": '" + _scode + "',";self._tabcontent.append(_script).append("\n");self._hastabs = true;};this.buildcontent= function() {if (self==null) self=this;var _script;var _delim;var _sout;_script='';if (self._hastabs) {_delim=","+"\n";_sout=self._tabcontent.toString();_delim = self._app.remdelim(_sout,_delim);_script = "{" + _delim + "}";} else {_script = "'" + self._content + "'";}return _script;};this.buildtitle= function() {if (self==null) self=this;var _script;var _delim;var _sout;_script='';if (self._hastabs) {_delim=","+"\n";_sout=self._tabs.toString();_delim = self._app.remdelim(_sout,_delim);_script = "{" + _delim + "}";} else {_script = "'" + self._title + "'";}return _script;};this.buildbuttons= function() {if (self==null) self=this;var _script;var _delim;var _sout;_script='';if (self._hasbuttons) {_delim=","+"\n";_sout=self._buttons.toString();_delim = self._app.remdelim(_sout,_delim);_script = "{" + _delim + "}";} else {_script = "{}";}return _script;};this.addbutton= function(_btnid,_btntitle,_btnclasses,_btnonclick) {if (self==null) self=this;var _vars;var _script;self._hasbuttons = true;_vars="";if (_btnclasses!=null) {_vars = self._app.join(",",_btnclasses);}if (_btnonclick.endsWith(";")) {} else {_btnonclick = _btnonclick+";";}_script="" + _btnid + ": { \n			label: '" + _btntitle + "', \n			classes: '" + _vars + "', \n			action: function() { \n				return " + _btnonclick + " \n			} \n		},";self._buttons.append(_script);self._buttons.append("\n");};this.tostring= function() {if (self==null) self=this;var _sshowclosebutton;var _sblocking;var _script;_sshowclosebutton=self._app.iif(self._showclosebutton,"true","false");_sblocking=self._app.iif(self._blocking,"true","false");_script="" + self._j + ".sweetModal({ \n	title: " + self.buildtitle() + ", \n	content: " + self.buildcontent() + " , \n	icon: " + self._icon + ", \n	showCloseButton: " + _sshowclosebutton + ", \n	blocking: " + _sblocking + ",	 \n	timeout: " + self._timeout + ", \n	width: '" + self._width + "', \n	buttons: " + self.buildbuttons() + " \n});";return _script;};}function banano_uoebanano_uoealignment() {var self;this._center="center";this._left="left";this._right="right";this._top="top";this._bottom="bottom";this._valign="valign-wrapper";this._centerdiv="centerdiv";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoebuttonsize() {var self;this._small="btn-small";this._medium="btn-medium";this._large="btn-large";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoebuttontype() {var self;this._flat="btn-flat";this._raised="btn-raised";this._floating="btn-floating";this._fab="btn-fab";this._halfwayfab="halfwayfab";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoebreadcrumbs() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._theme='';this._element= new banano_uoebanano_uoehtml();this._buttons=[];this._enabled=false;this._visibility='';this._zdepth='';this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_sid,_stheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._theme = _stheme;self._element.initialize(self._id,"nav");self._buttons.length=0;self._buttons.length=0;self._enabled = true;self._visibility = "";self._zdepth = "";self._wavestype = "";self._waveseffect = false;self._wavescircle = false;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.addbutton= function(_btnid,_btntext,_btnnav2) {if (self==null) self=this;var _a;_a= new banano_uoebanano_uoehtml();_a.initialize(_btnid,"a");_a.addattribute("href",_btnnav2);_a.addclass("breadcrumb").addcontent(_btntext);self._buttons.push(_a.html());return self;};this.tostring= function() {if (self==null) self=this;var _wrapper;var _div;if (self._theme == "") {self._theme = self._app._theme;}self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.materialvisibility(self._visibility);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);self._element.materialwaveseffect(self._waveseffect);self._element.materialzdepth(self._zdepth);self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);_wrapper= new banano_uoebanano_uoehtml();_wrapper.initialize("","div");_wrapper.addclass("nav-wrapper");_div= new banano_uoebanano_uoehtml();_div.initialize("","div");_div.addclass("col s12");_div.addcontentlist(self._buttons);_wrapper.addcontent(_div.html());self._element.addcontent(_wrapper.html());return self._element.html();};}function banano_uoebanano_uoecardsize() {var self;this._small="small";this._medium="medium";this._large="large";this._normal="";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoecardtype() {var self;this._basic="basic";this._image="image";this._reveal="reveal";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoecollapsibletype() {var self;this._accordion="accordion";this._expandable="expandable";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoecolor() {var self;this._amber="amber";this._black="black";this._blue="blue";this._bluegrey="blue-grey";this._brown="brown";this._cyan="cyan";this._deeporange="deep-orange";this._deeppurple="deep-purple";this._green="green";this._grey="grey";this._indigo="indigo";this._lightblue="light-blue";this._lightgreen="light-green";this._lime="lime";this._orange="orange";this._pink="pink";this._purple="purple";this._red="red";this._teal="teal";this._transparent="transparent";this._white="white";this._normal="";this._yellow="yellow";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoedatetimetype() {var self;this._datepicker="datepicker";this._timepicker="timepicker";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoeevents() {var self;this._click="click";this._input="input";this._blur="blur";this._change="change";this._keypress="keypress";this._keydown="keydown";this._keyup="keyup";this._dblclick="dblclick";this._mouseover="mouseover";this._mousemove="mousemove";this._mousedown="mousedown";this._load="load";this._unload="unload";this._error="error";this._resize="resize";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoefabdirection() {var self;this._top="top";this._right="right";this._bottom="bottom";this._left="left";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoefloattype() {var self;this._left="left";this._right="right";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoeiconsize() {var self;this._large="large";this._medium="medium";this._small="small";this._tiny="tiny";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoeinputtype() {var self;this._password="password";this._text="text";this._email="email";this._textarea="textarea";this._color="color";this._date="date";this._datetimelocal="datetime-local";this._month="month";this._number="number";this._range="range";this._search="search";this._tel="tel";this._time="time";this._url="url";this._week="week";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoebutton() {var self;this._id='';this._text='';this._enabled=false;this._size='';this._buttontype='';this._pulsing=false;this._app= new banano_uoebanano_uoeapp();this._href='';this._element= new banano_uoebanano_uoehtml();this._theme='';this._zdepth='';this._visibility='';this._isfab=false;this._click2toggle=false;this._horizontal=false;this._istoolbar=false;this._buttons=[];this._waveseffect=false;this._wavestype='';this._wavescircle=false;this._hoverable=false;this._modaltrigger=false;this._modalclose=false;this._modalname='';this._autofocus=false;this._fitwidth=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_sid,_btext,_btheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._text = _btext;self._buttontype = self._app._enumbuttontype._raised;self._pulsing = false;self._enabled = true;self._href = "#";self._zdepth = "";self._size = self._app._enumbuttonsize._medium;self._isfab = false;self._click2toggle = false;self._horizontal = false;self._istoolbar = false;self._visibility = "";self._waveseffect = true;self._buttons.length=0;self._buttons.length=0;self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._theme = _btheme;self._element.initialize(self._id,"a");self._modalclose = false;self._modaltrigger = false;self._autofocus = false;self._fitwidth = false;return self;};this.setbuttontype= function(_btntype) {if (self==null) self=this;self._buttontype = _btntype;self._element.materialbuttontype(self._buttontype);return self;};this.addjusticon= function(_iconname) {if (self==null) self=this;if (_iconname == "") { return self;}self.addicon(_iconname,"",self._theme,false,false);return self;};this.addiconwithcolors= function(_iconname,_forecolor,_backcolor) {if (self==null) self=this;self.addicon(_iconname,"",self._id+"theme",false,false);return self;};this.addicon= function(_siconname,_siconalign,_sicontheme,_biconcircle,_bwave) {if (self==null) self=this;switch ("" + self._buttontype) {case "" + self._app._enumbuttontype._fab:_siconalign = "";_biconcircle = true;break;case "" + self._app._enumbuttontype._floating:_siconalign = "";_biconcircle = true;break;case "" + self._app._enumbuttontype._halfwayfab:_siconalign = "";_biconcircle = true;break;}_banano_uoebanano_moduoe.materialaddicon(self._app,self._element,_siconname,_siconalign,_sicontheme,_biconcircle,_bwave,false,false,false);return self;};this.tostring= function() {if (self==null) self=this;var _themeexist;var _fab;var _li;var _strbutton;if (self._theme == "") {self._theme = self._app._theme;}_themeexist=self._app.themeexist(self._theme);if (_themeexist == false) {if (self._theme.length>0) {console.log("UOEButton: theme '" + self._theme + "' DOES NOT exist!");}}self._element.addclass("btn");if (self._buttontype == "") {self._buttontype = self._app._enumbuttontype._raised;}self._element.materialbuttontype(self._buttontype);switch ("" + self._buttontype) {case "" + self._app._enumbuttontype._fab:self._text = "";self._element.removeclass("btn");break;case "" + self._app._enumbuttontype._floating:self._text = "";self._element.removeclass("btn");break;case "" + self._app._enumbuttontype._halfwayfab:self._text = "";self._element.addclass("btn-floating").addclass("halfway-fab");break;}self._element.materialwaveseffect(self._waveseffect);self._element.sethref(self._href);self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addclass(self._buttontype);self._element.materialpulse(self._pulsing);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);self._element.materialbuttonsize(self._size);self._element.addcontent(self._text);self._element.addclassoncondition(self._modaltrigger,"modal-trigger");self._element.addattributeoncondition(self._autofocus,"autofocus","true");if (self._modalname!="") {self._element.sethref("#" + self._modalname + "");self._element.addattribute("data-target",self._modalname);}self._element.addclassoncondition(self._modalclose,"modal-close");if (self._isfab == true) {_fab= new banano_uoebanano_uoehtml();_fab.initialize(self._id+"div","div");_fab.addclass("fixed-action-btn");_fab.addcontent(self._element.html());_fab.materialclick2toggle(self._click2toggle);_fab.materialhorizontal(self._horizontal);_fab.materialtoolbar(self._istoolbar);_li= new banano_uoebanano_uoehtml();_li.initialize("","ul");for (var _strbuttonindex=0;_strbuttonindex<self._buttons.length;_strbuttonindex++) {_strbutton=self._buttons[_strbuttonindex];_li.addcontent(_strbutton);}_fab.addcontent(_li.html());return _fab.html();} else {return self._element.html();}};}function banano_uoebanano_uoeintensity() {var self;this._normal="";this._lighten5="lighten-5";this._lighten4="lighten-4";this._lighten3="lighten-3";this._lighten2="lighten-2";this._lighten1="lighten-1";this._darken1="darken-1";this._darken2="darken-2";this._darken3="darken-3";this._darken4="darken-4";this._accent1="accent-1";this._accent2="accent-2";this._accent3="accent-3";this._accent4="accent-4";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoelabelsize() {var self;this._h1="h1";this._h2="h2";this._h3="h3";this._h4="h4";this._h5="h5";this._h6="h6";this._span="span";this._paragraph="p";this._blockquote="blockquote";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoelogoposition() {var self;this._center="center";this._right="right";this._left="left";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoemenuposition() {var self;this._left="left";this._right="right";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoescaletype() {var self;this._scalein="in";this._scaleout="out";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoetableheading() {var self;this._theme='';this._classname='';this._fieldname='';this._height='';this._width='';this._visibility='';this._alignment='';this._title='';this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoetarget() {var self;this._self="_self";this._blank="_blank";this._parent="_parent";this._top="_top";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoetextalignment() {var self;this._center="center-align";this._left="left-align";this._right="right-align";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoetheme() {var self;this._fc='';this._fci='';this._bc='';this._bci='';this._fcname='';this._fciname='';this._id='';this._classdef='';this.initialize= function(_sid,_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity) {if (self==null) self=this;_sid = _sid.toLowerCase();self._id = _sid;self._fcname = _sforecolor;self._fciname = _sforecolorintensity;self._bc = _sbackcolor;self._bci = _sbackcolorintensity;self._fc = "" + _sforecolor + "-text";self._fci = "text-" + _sforecolorintensity + "";if (_sforecolor == "") {self._fc = "";}if (_sforecolorintensity == "") {self._fci = "";}self._classdef = self.getthemeclass(_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity);};this.getthemeclass= function(_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity) {if (self==null) self=this;var _sbc;var _sbci;var _sfc;var _sfci;var _script;_sbc=_sbackcolor;_sbci=_sbackcolorintensity;_sfc="" + _sforecolor + "-text";_sfci="text-" + _sforecolorintensity + "";if (_sforecolor == "") {_sfc = "";}if (_sforecolorintensity == "") {_sfci = "";}_script="" + _sfc + " " + _sfci + " " + _sbc + " " + _sbci + "";_script = _script.trim();return _script;};}function banano_uoebanano_uoethemes() {var self;this._primary="primary";this._danger="danger";this._warn="warn";this._success="success";this._info="info";this._muted="muted";this._default="default";this._primarytext="primarytext";this._dangertext="dangertext";this._warntext="warntext";this._successtext="successtext";this._infotext="infotext";this._mutedtext="mutedtext";this._defaulttext="defaulttext";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoecard() {var self;this._card= new banano_uoebanano_uoehtml();this._actions= new banano_uoebanano_uoehtml();this._content= new banano_uoebanano_uoehtml();this._imageurl='';this._app= new banano_uoebanano_uoeapp();this._id='';this._cardtype='';this._cardsize='';this._visibility='';this._zdepth='';this._hoverable=false;this._image= new banano_uoebanano_uoehtml();this._horizontal=false;this._stacked= new banano_uoebanano_uoehtml();this._reveal= new banano_uoebanano_uoehtml();this._breveal=false;this._hasactions=false;this._stickyaction=false;this._hastabs=false;this._tabs= new banano_uoebanano_uoehtml();this._ul= new banano_uoebanano_uoehtml();this._uldata= new banano_uoebanano_uoehtml();this._panel=false;this._small=0;this._medium=0;this._large=0;this.initialize= function(_thisapp,_sid,_simageurl,_scardtype,_scardtheme,_scontenttheme) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._imageurl = _simageurl;self._cardtype = _scardtype;self._cardsize = self._app._enumcardsize._normal;self._card.initialize(self._id,"div");self._card.addclass("card");self._app.materialusetheme(_scardtheme,self._card);self._content.initialize("","div");self._content.addclass("card-content");self._app.materialusetheme(_scontenttheme,self._content);self._actions.initialize("","div");self._actions.addclass("card-action");self._image.initialize("","div");self._image.addclass("card-image");self._stacked.initialize("","div");self._stacked.addclass("card-stacked");self._reveal.initialize("","div");self._reveal.addclass("card-reveal");self._tabs.initialize("","div");self._tabs.addclass("card-tabs");self._ul.initialize("","ul");self._ul.addclass("tabs tabs-fixed-width");self._uldata.initialize("","div");self._uldata.addclass("card-content");self._horizontal = false;self._breveal = false;if (self._cardtype == self._app._enumcardtype._reveal) {self._horizontal = false;self._breveal = true;}self._hasactions = false;self._stickyaction = false;self._hastabs = false;self._panel = false;self._small = 12;self._medium = 12;self._large = 12;};this.setsizes= function(_ismall,_imedium,_ilarge) {if (self==null) self=this;self._small = _ismall;self._medium = _imedium;self._large = _ilarge;self._card.addclass("col");self._card.addclass("s" + self._small + "");self._card.addclass("m" + self._medium + "");self._card.addclass("l" + self._large + "");return self;};this.addtab= function(_tabid,_tabtext,_tabdisabled,_tabcont) {if (self==null) self=this;var _li;var _a;var _dv;self._hastabs = true;_li= new banano_uoebanano_uoehtml();_li.initialize(_tabid+"li","li");_li.addclass("tab");_li.addclassoncondition(_tabdisabled,"disabled");_a= new banano_uoebanano_uoehtml();_a.initialize(_tabid,"a");_a.sethref("#"+_tabid+"dv").addcontent(_tabtext);_li.addelement(_a);self._ul.addelement(_li);_dv= new banano_uoebanano_uoehtml();_dv.initialize(_tabid+"dv","div");if (_tabcont!=null) {_dv.addcontent(_tabcont.tostring());}self._uldata.addcontent(_dv.html());return self;};this.addfab= function(_btnid,_btnicon,_btnurl,_btnsize,_btntheme) {if (self==null) self=this;var _a;_a= new banano_uoebanano_uoehtml();_a.initialize(_btnid,"a");_a.addclass("btn-floating");_a.addclass("halfway-fab");_a.materialwaveseffect(true);_a.materialwaveslight(true);_a.setzindex("999");self._app.materialusetheme(_btntheme,_a);_banano_uoebanano_moduoe.materialaddicon(self._app,_a,_btnicon,"",_btntheme,false,true,false,false,false);_a.materialbuttonsize(_btnsize);switch ("" + self._cardtype) {case "" + self._app._enumcardtype._basic:break;default:self._image.addelement(_a);break;}self._app.addevent(_btnid,"click");return self;};this.addtitle= function(_stitle,_themename,_classname) {if (self==null) self=this;var _span;var _img;var _spanc;_span= new banano_uoebanano_uoehtml();_span.initialize("","span");_span.addclass("card-title").addcontent(_stitle).addclass(_classname);self._app.materialusetheme(_themename,_span);switch ("" + self._cardtype) {case "" + self._app._enumcardtype._basic:self._content.addcontent(_span.html());break;case "" + self._app._enumcardtype._image:_img= new banano_uoebanano_uoehtml();_img.initialize("","img");_img.setsrc(self._imageurl,true);self._image.addelement(_img);self._image.addelement(_span);break;case "" + self._app._enumcardtype._reveal:_img= new banano_uoebanano_uoehtml();_img.initialize("","img");_img.setsrc(self._imageurl,true);_img.addclassoncondition(self._breveal,"activator");self._image.addelement(_img);_span.addclass("activator");_banano_uoebanano_moduoe.materialaddicon(self._app,_span,"mdi-more_vert","right","",false,false,false,false,false);self._content.addelement(_span);_spanc= new banano_uoebanano_uoehtml();_spanc.initialize("","span");_spanc.addclass("card-title").addcontent(_stitle).addclass(_classname);_banano_uoebanano_moduoe.materialaddicon(self._app,_spanc,"mdi-close","right","",false,false,false,false,false);self._app.materialusetheme(_themename,_spanc);self._reveal.addelement(_spanc);break;}return self;};this.addparagraph= function(_ptext,_ptheme,_pclass) {if (self==null) self=this;var _span;_span= new banano_uoebanano_uoehtml();_span.initialize("","p");_span.addclass(_pclass).addcontent(_ptext);self._app.materialusetheme(_ptheme,_span);switch ("" + self._cardtype) {case "" + self._app._enumcardtype._reveal:self._reveal.addcontent(_span.html());break;default:self._content.addcontent(_span.html());break;}return self;};this.addlink= function(_aid,_atitle,_ahref) {if (self==null) self=this;var _a;var _p;_a= new banano_uoebanano_uoehtml();_a.initialize(_aid,"a");_a.sethref(_ahref).addcontent(_atitle);_p= new banano_uoebanano_uoehtml();_p.initialize("","p");_p.addelement(_a);self._content.addelement(_p);self._app.addevent(_aid,"click");return self;};this.addaction= function(_aid,_atitle,_ahref) {if (self==null) self=this;var _a;_a= new banano_uoebanano_uoehtml();_a.initialize(_aid,"a");_a.sethref(_ahref).addcontent(_atitle);self._actions.addcontent(_a.html());self._hasactions = true;self._app.addevent(_aid,"click");return self;};this.tostring= function() {if (self==null) self=this;if (self._panel) {self._card.removeclass("card").addclass("card-panel");}self._card.materialzdepth(self._zdepth);self._card.materialvisibility(self._visibility);self._card.materialhoverable(self._hoverable);self._card.addclassoncondition(self._horizontal,"horizontal");self._card.addclassoncondition(self._stickyaction,"sticky-action");self._image.addclassoncondition(self._breveal,"waves-effect waves-block waves-light");self._tabs.addelement(self._ul);switch ("" + self._cardtype) {case "" + self._app._enumcardtype._basic:if (self._horizontal) {self._stacked.addelement(self._content);if (self._hastabs) {self._card.addelement(self._tabs);self._card.addelement(self._uldata);}self._stacked.addelement(self._actions);self._card.addelement(self._stacked);} else {self._card.addelement(self._content);if (self._hastabs) {self._card.addelement(self._tabs);self._card.addelement(self._uldata);}if (self._hasactions) {self._card.addelement(self._actions);}}break;case "" + self._app._enumcardtype._image:self._card.addelement(self._image);if (self._horizontal) {self._stacked.addelement(self._content);if (self._hastabs) {self._card.addelement(self._tabs);self._card.addelement(self._uldata);}if (self._hasactions) {self._stacked.addelement(self._actions);}self._card.addelement(self._stacked);} else {self._card.addelement(self._content);if (self._hastabs) {self._card.addelement(self._tabs);self._card.addelement(self._uldata);}if (self._hasactions) {self._card.addelement(self._actions);}}break;case "" + self._app._enumcardtype._reveal:self._card.addelement(self._image);self._card.addelement(self._content);if (self._hastabs) {self._card.addelement(self._tabs);self._card.addelement(self._uldata);}if (self._hasactions) {self._card.addelement(self._actions);}self._card.addelement(self._reveal);break;}self._app.applytooltip(self._id,self._card);return self._card.html();};this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._card.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._card.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._card.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._card.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._card.removeattribute(_attr);return self;};}function banano_uoebanano_uoetooltip() {var self;this._position="";this._text="";this._delay=50;this._id="";this._theme="";this.initialize= function(_sid,_stext,_sposition,_idelay,_stheme) {if (self==null) self=this;self._id = _sid;self._position = _sposition;self._text = _stext;self._delay = _idelay;self._theme = _stheme;};}function banano_uoebanano_uoetooltippos() {var self;this._bottom="bottom";this._left="left";this._right="right";this._top="top";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoevideotype() {var self;this._mp4="video/mp4";this._webm="video/webm";this._ogg="video/ogg";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoevisibility() {var self;this._visible="";this._hide="hide";this._hideonsmallonly="hide-on-small-only";this._hideonmedonly="hide-on-med-only";this._hideonmedanddown="hide-on-med-and-down";this._hideonmedandup="hide-on-med-and-up";this._hideonlargeonly="hide-on-large-only";this._showonlargeonly="show-on-large";this._showonsmallonly="show-on-small";this._showonmediumonly="show-on-medium";this._showonmediumandup="show-on-medium-and-up";this._showonmediumanddown="show-on-medium-and-down";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoewavestype() {var self;this._green="waves-green";this._light="waves-light";this._normal="";this._orange="waves-orange";this._purple="waves-purple";this._red="waves-red";this._teal="waves-teal";this._yellow="waves-yellow";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoezdepth() {var self;this._zdepth_1="z-depth-1";this._zdepth_2="z-depth-2";this._zdepth_3="z-depth-3";this._zdepth_4="z-depth-4";this._zdepth_5="z-depth-5";this._zdepth_none="";this.initialize= function() {if (self==null) self=this;};}function banano_uoebanano_uoeapp() {var self;this._theme='';this._appname='';this._enumcardtype= new banano_uoebanano_uoecardtype();this._enumtarget= new banano_uoebanano_uoetarget();this._enumlogoposition= new banano_uoebanano_uoelogoposition();this._enumintensity= new banano_uoebanano_uoeintensity();this._enumlabelsize= new banano_uoebanano_uoelabelsize();this._enummenupos= new banano_uoebanano_uoemenuposition();this._enumsliderorientation= new banano_uoebanano_uoesliderorientation();this._enumfabdirection= new banano_uoebanano_uoefabdirection();this._enumtextalignment= new banano_uoebanano_uoetextalignment();this._enumtooltippos= new banano_uoebanano_uoetooltippos();this._enumalignment= new banano_uoebanano_uoealignment();this._enumbuttonsize= new banano_uoebanano_uoebuttonsize();this._enumbuttontype= new banano_uoebanano_uoebuttontype();this._enumcardsize= new banano_uoebanano_uoecardsize();this._enumiconsize= new banano_uoebanano_uoeiconsize();this._enuminputtype= new banano_uoebanano_uoeinputtype();this._enumvisibility= new banano_uoebanano_uoevisibility();this._enumzdepth= new banano_uoebanano_uoezdepth();this._enumcolor= new banano_uoebanano_uoecolor();this._enumvideotype= new banano_uoebanano_uoevideotype();this._enumdatetimetype= new banano_uoebanano_uoedatetimetype();this._enumfloattype= new banano_uoebanano_uoefloattype();this._enumscaletype= new banano_uoebanano_uoescaletype();this._enumcollapsibletype= new banano_uoebanano_uoecollapsibletype();this._enumwavestype= new banano_uoebanano_uoewavestype();this._enumthemes= new banano_uoebanano_uoethemes();this._tooltipdelay=50;this._tooltipposition="top";this._themesmap={};this._colormap={};this._copyrights='';this._termsandconditionsurl='';this._disclaimerurl='';this._privacypolicyurl='';this._imagehw='';this._imagetopmargin='';this._itemheight='';this._css=[];this._js=[];this._tooltips={};this._components=[];this._m=null;this._jq=null;this._events={};this.functiondothis= function(_funcname,_varlist,_dothis) {if (self==null) self=this;var _vars;var _script;_vars="";if (_varlist!=null) {_vars = self.join(",",_varlist);}_script='';_script = "function " + _funcname + "(" + _vars + "){ \n	" + _dothis + " \n}";return _script;};this.cstr= function(_o) {if (self==null) self=this;return ""+_o;};this.removeevent= function(_elid) {if (self==null) self=this;var _strkey;var _strevent;var _elm;var _em;var _strsuffix;_strkey='';_strevent='';_elid = _elid.toLowerCase();if ((_elid in self._events)) {_strevent = self._events[_elid];delete self._events[_elid];_strkey = "#" + _elid + "";_elm=u(_strkey);_elm.off(_strevent);_em=[];_em.length=0;_em.splice(_em.length,0,["icon","img","badge","title","badge"]);for (var _strsuffixindex=0;_strsuffixindex<_em.length;_strsuffixindex++) {_strsuffix=_em[_strsuffixindex];_strkey="" + _elid + "-" + _strsuffix + "";delete self._events[_strkey];_strkey = "#" + _strkey + "";_elm=u(_strkey);_elm.off(_strevent);}}};this.addevent= function(_elid,_elevent) {if (self==null) self=this;var _em;var _strsuffix;var _strkey;_elid = _elid.toLowerCase();_elid = _elid.trim();_elevent = _elevent.trim();if (_elid.length>0 && _elevent.length>0) {self._events[_elid]=_elevent;_em=[];_em.length=0;_em.splice(_em.length,0,["icon","img","badge","title","badge"]);for (var _strsuffixindex=0;_strsuffixindex<_em.length;_strsuffixindex++) {_strsuffix=_em[_strsuffixindex];_strkey="" + _elid + "-" + _strsuffix + "";self._events[_strkey]=_elevent;}}};this.bindevents= function(_elmethod,_eventhandler) {if (self==null) self=this;var _mtot;var _mcnt;var _elid;var _elevent;var _btnevent;var _elkey;var _elm;_mtot=Object.keys(self._events).length-1;_mcnt=0;for (_mcnt=0;_mcnt<=_mtot;_mcnt++) {_elid=banano_getB4JKeyAt(self._events,_mcnt);_elevent=self._events[_elid];_elid = _elid.trim();_elevent = _elevent.trim();if (_elid.length>0 && _elevent.length>0) {_btnevent="" + _elid + "_" + _elevent + "";_elkey="#" + _elid + "";if (_elmethod.length>0) {_btnevent = _elmethod.toLowerCase();}if (_eventhandler!=null) {_elm=u(_elkey);_elm.off(_elevent);_elm.handle(_elevent, function(event) {if (typeof _eventhandler[_btnevent]==="function") {return _eventhandler[_btnevent](event)}});}}}};this.bindevent= function(_elid,_elevent,_elmethod,_eventhandler) {if (self==null) self=this;var _btnevent;var _skey;var _elm;_elid = _elid.toLowerCase();_elid = _elid.trim();_elevent = _elevent.trim();_btnevent="" + _elid + "_" + _elevent + "";_skey="#" + _elid + "";if (_elid.length>0 && _elevent.length>0) {if (_elmethod.length>0) {_btnevent = _elmethod.toLowerCase();}if (_eventhandler!=null) {_elm=u(_skey);_elm.off(_elevent);_elm.handle(_elevent, function(event) {if (typeof _eventhandler[_btnevent]==="function") {return _eventhandler[_btnevent](event)}});}}};this.newpage= function() {if (self==null) self=this;self._css.length=0;self._css.length=0;self._js.length=0;self._js.length=0;self._tooltips={};self._tooltips={};self._components.length=0;self._components.length=0;self._events={};self._events={};};this.join= function(_delim,_lst) {if (self==null) self=this;var _ltot;var _lcnt;var _lstr;_ltot=0;_lcnt=0;_lstr=new StringBuilder();_lstr.isinitialized=true;_ltot = _lst.length-1;for (_lcnt=0;_lcnt<=_ltot;_lcnt++) {_lstr.append(_lst[_lcnt]);if (_lcnt!=_ltot) {_lstr.append(_delim);}}return _lstr.toString();};this.remdelim= function(_svalue,_delim) {if (self==null) self=this;var _ldelim;var _nvalue;if (_svalue.endsWith(_delim)) {_ldelim=_delim.length;_nvalue=_svalue;if (_nvalue.endsWith(_delim)) {_nvalue = _nvalue.substring(0,_nvalue.length-_ldelim);}return _nvalue;} else {return _svalue;}};this.remdelimsb= function(_delimiter,_value) {if (self==null) self=this;var _delimlen;if (_value.toString().endsWith(_delimiter) == true) {_delimlen=_delimiter.length;_value.remove(_value.length()-_delimlen, _value.length());}return;};this.iif= function(_expression2evaluate,_returniftrue,_returniffalse) {if (self==null) self=this;if (_expression2evaluate == true) { return _returniftrue;} else {_returniffalse;}};this.gettheme= function(_themename) {if (self==null) self=this;var _tt;_themename = _themename.toLowerCase();_tt=self._themesmap[_themename];return _tt;};this.addtheme= function(_themename,_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity) {if (self==null) self=this;var _tt;_themename = _themename.toLowerCase();_tt= new banano_uoebanano_uoetheme();_tt.initialize(_themename,_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity);self._themesmap[_themename]=_tt;};this.themeexist= function(_themename) {if (self==null) self=this;var _bexist;_themename = _themename.toLowerCase();_bexist=(_themename in self._themesmap);return _bexist;};this.materialusetheme= function(_sthemename,_el) {if (self==null) self=this;var _tt;var _script;if (_sthemename == "") { return _el;}if (self.themeexist(_sthemename)) {_tt= new banano_uoebanano_uoetheme();_tt = self.gettheme(_sthemename);_script=_tt._classdef;_el.addclass(_script);}return _el;};this.materialgettheme= function(_stheme) {if (self==null) self=this;var _thist;var _script;_stheme = _stheme.trim();if (self.themeexist(_stheme)) {_thist= new banano_uoebanano_uoetheme();_thist = self.gettheme(_stheme);_script=_thist._classdef;return _script;} else {return "";}};this.strparse= function(_delim,_inputstring) {if (self==null) self=this;var _outlist;var _commaloc;var _leftside;var _rightside;_outlist=[];_commaloc=0;_outlist.length=0;_outlist.length=0;_commaloc = _inputstring.indexOf(_delim);while (_commaloc>-1) {_leftside='';_leftside = _inputstring.substring(0,_commaloc);_rightside='';_rightside = _inputstring.substring(_commaloc+1);_outlist.push(_leftside);_inputstring = _rightside;_commaloc = _inputstring.indexOf(_delim);}_outlist.push(_inputstring);return _outlist;};this.mvfield= function(_svalue,_iposition,_delimiter) {if (self==null) self=this;var _xpos;var _mvalues;var _tvalues;var _sb;var _startcnt;if (_svalue.length == 0) { return "";}_xpos=_svalue.indexOf(_delimiter);if (_xpos == -1) { return _svalue;}_mvalues=self.strparse(_delimiter,_svalue);_tvalues=0;_tvalues = _mvalues.length-1;switch ("" + _iposition) {case "" + -1:return _mvalues[_tvalues];case "" + -2:return _mvalues[_tvalues-1];case "" + -3:_sb=new StringBuilder();_sb.isinitialized=true;_startcnt=0;_sb.append(_mvalues[1]);for (_startcnt=2;_startcnt<=_tvalues;_startcnt++) {_sb.append(_delimiter);_sb.append(_mvalues[_startcnt]);}return _sb.toString();default:_iposition = _iposition-1;if (_iposition<=-1) {return _mvalues[_tvalues];}if (_iposition>_tvalues) {return "";}return _mvalues[_iposition];}};this.getthemeclass= function(_sforecolor,_sforecolorintensity,_sbackcolor,_sbackcolorintensity) {if (self==null) self=this;var _bc;var _bci;var _fc;var _fci;var _script;_bc=_sbackcolor;_bci=_sbackcolorintensity;_fc="" + _sforecolor + "-text";_fci="text-" + _sforecolorintensity + "";if (_sforecolor == "") {_fc = "";}if (_sforecolorintensity == "") {_fci = "";}_script="" + _fc + " " + _fci + " " + _bc + " " + _bci + "";_script = _script.trim();return _script;};this.map2json= function(_mp) {if (self==null) self=this;var _json;_json={};_json=_mp;return JSON.stringify(_json);};this.object2json= function(_mp) {if (self==null) self=this;var _json;_json={};_json=_mp;return JSON.stringify(_json);};this.list2json= function(_mp) {if (self==null) self=this;var _json;_json={};_json=_mp;return JSON.stringify(_json);};this.json2map= function(_strjson) {if (self==null) self=this;var _json;var _map1;_json={};_map1={};_map1={};_map1={};try {if (_strjson.length>0) {_json=JSON.parse(_strjson);_map1 = _json;}return _map1;} catch(err) {return _map1;}};this.json2list= function(_strvalue) {if (self==null) self=this;var _lst;var _parser;_lst=[];_lst.length=0;_lst.length=0;if (_strvalue.length == 0) {return _lst;}try {_parser={};_parser=JSON.parse(_strvalue);return _parser;} catch(err) {return _lst;}};this.getcolorhex= function(_color,_intensity) {if (self==null) self=this;var _skey;var _scolor;_skey=_color+" "+_intensity;_skey = _skey.trim();if (_skey == "") { return "";}if ((_skey in self._colormap)) {_scolor=(self._colormap[_skey] || "");return _scolor;} else {return "";}};this.getforecolorhex= function(_stheme) {if (self==null) self=this;var _thist;_stheme = _stheme.trim();if (self.themeexist(_stheme)) {_thist= new banano_uoebanano_uoetheme();_thist = self.gettheme(_stheme);return self.getcolorhex(_thist._fcname,_thist._fciname);} else {return "";}};this.getbackgroundcolorhex= function(_stheme) {if (self==null) self=this;var _thist;_stheme = _stheme.trim();if (self.themeexist(_stheme)) {_thist= new banano_uoebanano_uoetheme();_thist = self.gettheme(_stheme);return self.getcolorhex(_thist._bc,_thist._bci);} else {return "";}};this.initialize= function(_sappname,_stheme) {if (self==null) self=this;self._m=M;self._jq=$;self.newpage();self._colormap={};self._colormap={};self._theme = _stheme;self._enumthemes.initialize();self._appname = _sappname;self._themesmap={};self._themesmap={};self.initcolormap();self._enumcolor.initialize();self._enumcardtype.initialize();self._enumtarget.initialize();self._enumlogoposition.initialize();self._enumintensity.initialize();self._enumlabelsize.initialize();self._enummenupos.initialize();self._enumsliderorientation.initialize();self._enumfabdirection.initialize();self._enumtextalignment.initialize();self._enumtooltippos.initialize();self._enumalignment.initialize();self._enumbuttonsize.initialize();self._enumbuttontype.initialize();self._enumcardsize.initialize();self._enumiconsize.initialize();self._enuminputtype.initialize();self._enumvisibility.initialize();self._enumzdepth.initialize();self._enumvideotype.initialize();self._enumdatetimetype.initialize();self._enumfloattype.initialize();self._enumscaletype.initialize();self._enumcollapsibletype.initialize();self._enumwavestype.initialize();self.addtheme("primary","white","","blue","");self.addtheme("danger","white","","red","");self.addtheme("warn","white","","orange","");self.addtheme("success","white","","green","");self.addtheme("info","white","","light-blue","");self.addtheme("muted","white","","black","");self.addtheme("default","white","","light-blue","");self.addtheme("primarytext","blue","","transparent","");self.addtheme("dangertext","red","","transparent","");self.addtheme("warntext","orange","","transparent","");self.addtheme("successtext","green","","transparent","");self.addtheme("infotext","light-blue","","transparent","");self.addtheme("mutedtext","black","","transparent","");self.addtheme("defaulttext","light-blue","","transparent","");self.addtheme("white.amber","white","","amber","");self.addtheme("white.black","white","","black","");self.addtheme("white.blue","white","","blue","");self.addtheme("white.bluegrey","white","",self._enumcolor._bluegrey,"");self.addtheme("white.brown","white","","brown","");self.addtheme("white.cyan","white","","cyan","");self.addtheme("black.deeporange","black","",self._enumcolor._deeporange,"");self.addtheme("white.deeppurple","while","",self._enumcolor._deeppurple,"");self.addtheme("white.green","while","","green","");self.addtheme("black.grey","black","","green","");self.addtheme("white.indigo","white","","indigo","");self.addtheme("white.lightblue","white","",self._enumcolor._lightblue,"");self.addtheme("black.lightgreen","white","",self._enumcolor._lightgreen,"");self.addtheme("black.lime","white","",self._enumcolor._lime,"");self.addtheme("white.pink","white","",self._enumcolor._pink,"");self.addtheme("white.orange",self._enumcolor._white,self._enumintensity._normal,self._enumcolor._orange,self._enumintensity._normal);self.addtheme("black.orange","black","",self._enumcolor._orange,"");self.addtheme("white.purple","white","",self._enumcolor._purple,"");self.addtheme("white.red","white","",self._enumcolor._red,"");self.addtheme("white.teal","white","",self._enumcolor._teal,"");self.addtheme("white.black","white","",self._enumcolor._black,"");self.addtheme("black.white","black","",self._enumcolor._white,"");self.addtheme("white.yellow","white","",self._enumcolor._yellow,"");self.addtheme("black.yellow","black","",self._enumcolor._yellow,"");self._imagetopmargin = "8px";self._imagehw = "32px";self._itemheight = "43px";};this.tooltipexist= function(_ttname) {if (self==null) self=this;_ttname = _ttname.toLowerCase();return (_ttname in self._tooltips);};this.gettooltip= function(_ttname) {if (self==null) self=this;var _tt;_ttname = _ttname.toLowerCase();_tt=self._tooltips[_ttname];return _tt;};this.applytooltip= function(_elid,_el) {if (self==null) self=this;var _texist;var _tt;_texist=self.tooltipexist(_elid);if (_texist) {_tt=self.gettooltip(_elid);_el.materialsettooltip(_tt._position,_tt._delay,_tt._text);}};this.materialusethemeoncondition= function(_bstatus,_themename,_element) {if (self==null) self=this;if (_bstatus == true) {self.materialusetheme(_themename,_element);}};this.getelement= function(_elid) {if (self==null) self=this;var _skey;_elid = _elid.toLowerCase();_skey="#" + _elid + "";return u(_skey);};this.initcolormap= function() {if (self==null) self=this;self._colormap={};self._colormap={};self._colormap["maroon"]="#800000";self._colormap["red"]="#f44336";self._colormap["orange"]="#ff9800";self._colormap["yellow"]="#ffeb3b";self._colormap["olive"]="#808000";self._colormap["green"]="#4caf50";self._colormap["purple"]="#9c27b0";self._colormap["fuchsia"]="#ff00ff";self._colormap["lime"]="#cddc39";self._colormap["teal"]="#009688";self._colormap["aqua"]="#00ffff";self._colormap["grey"]="#9e9e9e";self._colormap["pink"]="#e91e63";self._colormap["blue"]="#2196f3";self._colormap["brown"]="#795548";self._colormap["deep-purple"]="#673ab7";self._colormap["indigo"]="#3f51b5";self._colormap["light-blue"]="#03a9f4";self._colormap["cyan"]="#00bcd4";self._colormap["light-green"]="#8bc34a";self._colormap["amber"]="#ffc107";self._colormap["deep-orange"]="#ff5722";self._colormap["blue-grey"]="#607d8b";self._colormap["black"]="#000000";self._colormap["navy"]="#000080";self._colormap["silver"]="#c0c0c0";self._colormap["aquamarine"]="#7fffd4";self._colormap["white"]="#ffffff";self._colormap["blueviolet"]="#8a2be2";self._colormap["burlywood"]="#deb887";self._colormap["cadetblue"]="#5f9ea0";self._colormap["chartreuse"]="#7fff00";self._colormap["chocolate"]="#d2691e";self._colormap["coral"]="#ff7f50";self._colormap["cornflowerblue"]="#6495ed";self._colormap["forestgreen"]="#228b22";self._colormap["gold"]="#ffd700";self._colormap["goldenrod"]="#daa520";self._colormap["khaki"]="#f0e68c";self._colormap["lavendar"]="#e6e6fa";self._colormap["lightcoral"]="#f08080";self._colormap["lightseagreen"]="#20b2aa";self._colormap["rosybrown"]="#bc8f8f";self._colormap["steelblue"]="#4682b4";self._colormap["yellowgreen"]="#9acd32";self._colormap["red lighten-5"]="#ffebee";self._colormap["red lighten-4"]="#ffcdd2";self._colormap["red lighten-3"]="#ef9a9a";self._colormap["red lighten-2"]="#e57373";self._colormap["red lighten-1"]="#ef5350";self._colormap["red"]="#f44336";self._colormap["red darken-1"]="#e53935";self._colormap["red darken-2"]="#d32f2f";self._colormap["red darken-3"]="#c62828";self._colormap["red darken-4"]="#b71c1c";self._colormap["red accent-1"]="#ff8a80";self._colormap["red accent-2"]="#ff5252";self._colormap["red accent-3"]="#ff1744";self._colormap["red accent-4"]="#d50000";self._colormap["pink lighten-5"]="#fce4ec";self._colormap["pink lighten-4"]="#f8bbd0";self._colormap["pink lighten-3"]="#f48fb1";self._colormap["pink lighten-2"]="#f06292";self._colormap["pink lighten-1"]="#ec407a";self._colormap["pink"]="#e91e63";self._colormap["pink darken-1"]="#d81b60";self._colormap["pink darken-2"]="#c2185b";self._colormap["pink darken-3"]="#ad1457";self._colormap["pink darken-4"]="#880e4f";self._colormap["pink accent-1"]="#ff80ab";self._colormap["pink accent-2"]="#ff4081";self._colormap["pink accent-3"]="#f50057";self._colormap["pink accent-4"]="#c51162";self._colormap["purple lighten-5"]="#f3e5f5";self._colormap["purple lighten-4"]="#e1bee7";self._colormap["purple lighten-3"]="#ce93d8";self._colormap["purple lighten-2"]="#ba68c8";self._colormap["purple lighten-1"]="#ab47bc";self._colormap["purple"]="#9c27b0";self._colormap["purple darken-1"]="#8e24aa";self._colormap["purple darken-2"]="#7b1fa2";self._colormap["purple darken-3"]="#6a1b9a";self._colormap["purple darken-4"]="#4a148c";self._colormap["purple accent-1"]="#ea80fc";self._colormap["purple accent-2"]="#e040fb";self._colormap["purple accent-3"]="#d500f9";self._colormap["purple accent-4"]="#aa00ff";self._colormap["deep-purple lighten-5"]="#ede7f6";self._colormap["deep-purple lighten-4"]="#d1c4e9";self._colormap["deep-purple lighten-3"]="#b39ddb";self._colormap["deep-purple lighten-2"]="#9575cd";self._colormap["deep-purple lighten-1"]="#7e57c2";self._colormap["deep-purple"]="#673ab7";self._colormap["deep-purple darken-1"]="#5e35b1";self._colormap["deep-purple darken-2"]="#512da8";self._colormap["deep-purple darken-3"]="#4527a0";self._colormap["deep-purple darken-4"]="#311b92";self._colormap["deep-purple accent-1"]="#b388ff";self._colormap["deep-purple accent-2"]="#7c4dff";self._colormap["deep-purple accent-3"]="#651fff";self._colormap["deep-purple accent-4"]="#6200ea";self._colormap["indigo lighten-5"]="#e8eaf6";self._colormap["indigo lighten-4"]="#c5cae9";self._colormap["indigo lighten-3"]="#9fa8da";self._colormap["indigo lighten-2"]="#7986cb";self._colormap["indigo lighten-1"]="#5c6bc0";self._colormap["indigo"]="#3f51b5";self._colormap["indigo darken-1"]="#3949ab";self._colormap["indigo darken-2"]="#303f9f";self._colormap["indigo darken-3"]="#283593";self._colormap["indigo darken-4"]="#1a237e";self._colormap["indigo accent-1"]="#8c9eff";self._colormap["indigo accent-2"]="#536dfe";self._colormap["indigo accent-3"]="#3d5afe";self._colormap["indigo accent-4"]="#304ffe";self._colormap["blue lighten-5"]="#e3f2fd";self._colormap["blue lighten-4"]="#bbdefb";self._colormap["blue lighten-3"]="#90caf9";self._colormap["blue lighten-2"]="#64b5f6";self._colormap["blue lighten-1"]="#42a5f5";self._colormap["blue"]="#2196f3";self._colormap["blue darken-1"]="#1e88e5";self._colormap["blue darken-2"]="#1976d2";self._colormap["blue darken-3"]="#1565c0";self._colormap["blue darken-4"]="#0d47a1";self._colormap["blue accent-1"]="#82b1ff";self._colormap["blue accent-2"]="#448aff";self._colormap["blue accent-3"]="#2979ff";self._colormap["blue accent-4"]="#2962ff";self._colormap["light-blue lighten-5"]="#e1f5fe";self._colormap["light-blue lighten-4"]="#b3e5fc";self._colormap["light-blue lighten-3"]="#81d4fa";self._colormap["light-blue lighten-2"]="#4fc3f7";self._colormap["light-blue lighten-1"]="#29b6f6";self._colormap["light-blue"]="#03a9f4";self._colormap["light-blue darken-1"]="#039be5";self._colormap["light-blue darken-2"]="#0288d1";self._colormap["light-blue darken-3"]="#0277bd";self._colormap["light-blue darken-4"]="#01579b";self._colormap["light-blue accent-1"]="#80d8ff";self._colormap["light-blue accent-2"]="#40c4ff";self._colormap["light-blue accent-3"]="#00b0ff";self._colormap["light-blue accent-4"]="#0091ea";self._colormap["cyan lighten-5"]="#e0f7fa";self._colormap["cyan lighten-4"]="#b2ebf2";self._colormap["cyan lighten-3"]="#80deea";self._colormap["cyan lighten-2"]="#4dd0e1";self._colormap["cyan lighten-1"]="#26c6da";self._colormap["cyan"]="#00bcd4";self._colormap["cyan darken-1"]="#00acc1";self._colormap["cyan darken-2"]="#0097a7";self._colormap["cyan darken-3"]="#00838f";self._colormap["cyan darken-4"]="#006064";self._colormap["cyan accent-1"]="#84ffff";self._colormap["cyan accent-2"]="#18ffff";self._colormap["cyan accent-3"]="#00e5ff";self._colormap["cyan accent-4"]="#00b8d4";self._colormap["teal lighten-5"]="#e0f2f1";self._colormap["teal lighten-4"]="#b2dfdb";self._colormap["teal lighten-3"]="#80cbc4";self._colormap["teal lighten-2"]="#4db6ac";self._colormap["teal lighten-1"]="#26a69a";self._colormap["teal"]="#009688";self._colormap["teal darken-1"]="#00897b";self._colormap["teal darken-2"]="#00796b";self._colormap["teal darken-3"]="#00695c";self._colormap["teal darken-4"]="#004d40";self._colormap["teal accent-1"]="#a7ffeb";self._colormap["teal accent-2"]="#64ffda";self._colormap["teal accent-3"]="#1de9b6";self._colormap["teal accent-4"]="#00bfa5";self._colormap["green lighten-5"]="#e8f5e9";self._colormap["green lighten-4"]="#c8e6c9";self._colormap["green lighten-3"]="#a5d6a7";self._colormap["green lighten-2"]="#81c784";self._colormap["green lighten-1"]="#66bb6a";self._colormap["green"]="#4caf50";self._colormap["green darken-1"]="#43a047";self._colormap["green darken-2"]="#388e3c";self._colormap["green darken-3"]="#2e7d32";self._colormap["green darken-4"]="#1b5e20";self._colormap["green accent-1"]="#b9f6ca";self._colormap["green accent-2"]="#69f0ae";self._colormap["green accent-3"]="#00e676";self._colormap["green accent-4"]="#00c853";self._colormap["light-green lighten-5"]="#f1f8e9";self._colormap["light-green lighten-4"]="#dcedc8";self._colormap["light-green lighten-3"]="#c5e1a5";self._colormap["light-green lighten-2"]="#aed581";self._colormap["light-green lighten-1"]="#9ccc65";self._colormap["light-green"]="#8bc34a";self._colormap["light-green darken-1"]="#7cb342";self._colormap["light-green darken-2"]="#689f38";self._colormap["light-green darken-3"]="#558b2f";self._colormap["light-green darken-4"]="#33691e";self._colormap["light-green accent-1"]="#ccff90";self._colormap["light-green accent-2"]="#b2ff59";self._colormap["light-green accent-3"]="#76ff03";self._colormap["light-green accent-4"]="#64dd17";self._colormap["lime lighten-5"]="#f9fbe7";self._colormap["lime lighten-4"]="#f0f4c3";self._colormap["lime lighten-3"]="#e6ee9c";self._colormap["lime lighten-2"]="#dce775";self._colormap["lime lighten-1"]="#d4e157";self._colormap["lime"]="#cddc39";self._colormap["lime darken-1"]="#c0ca33";self._colormap["lime darken-2"]="#afb42b";self._colormap["lime darken-3"]="#9e9d24";self._colormap["lime darken-4"]="#827717";self._colormap["lime accent-1"]="#f4ff81";self._colormap["lime accent-2"]="#eeff41";self._colormap["lime accent-3"]="#c6ff00";self._colormap["lime accent-4"]="#aeea00";self._colormap["yellow lighten-5"]="#fffde7";self._colormap["yellow lighten-4"]="#fff9c4";self._colormap["yellow lighten-3"]="#fff59d";self._colormap["yellow lighten-2"]="#fff176";self._colormap["yellow lighten-1"]="#ffee58";self._colormap["yellow"]="#ffeb3b";self._colormap["yellow darken-1"]="#fdd835";self._colormap["yellow darken-2"]="#fbc02d";self._colormap["yellow darken-3"]="#f9a825";self._colormap["yellow darken-4"]="#f57f17";self._colormap["yellow accent-1"]="#ffff8d";self._colormap["yellow accent-2"]="#ffff00";self._colormap["yellow accent-3"]="#ffea00";self._colormap["yellow accent-4"]="#ffd600";self._colormap["amber lighten-5"]="#fff8e1";self._colormap["amber lighten-4"]="#ffecb3";self._colormap["amber lighten-3"]="#ffe082";self._colormap["amber lighten-2"]="#ffd54f";self._colormap["amber lighten-1"]="#ffca28";self._colormap["amber"]="#ffc107";self._colormap["amber darken-1"]="#ffb300";self._colormap["amber darken-2"]="#ffa000";self._colormap["amber darken-3"]="#ff8f00";self._colormap["amber darken-4"]="#ff6f00";self._colormap["amber accent-1"]="#ffe57f";self._colormap["amber accent-2"]="#ffd740";self._colormap["amber accent-3"]="#ffc400";self._colormap["amber accent-4"]="#ffab00";self._colormap["orange lighten-5"]="#fff3e0";self._colormap["orange lighten-4"]="#ffe0b2";self._colormap["orange lighten-3"]="#ffcc80";self._colormap["orange lighten-2"]="#ffb74d";self._colormap["orange lighten-1"]="#ffa726";self._colormap["orange"]="#ff9800";self._colormap["orange darken-1"]="#fb8c00";self._colormap["orange darken-2"]="#f57c00";self._colormap["orange darken-3"]="#ef6c00";self._colormap["orange darken-4"]="#e65100";self._colormap["orange accent-1"]="#ffd180";self._colormap["orange accent-2"]="#ffab40";self._colormap["orange accent-3"]="#ff9100";self._colormap["orange accent-4"]="#ff6d00";self._colormap["deep-orange lighten-5"]="#fbe9e7";self._colormap["deep-orange lighten-4"]="#ffccbc";self._colormap["deep-orange lighten-3"]="#ffab91";self._colormap["deep-orange lighten-2"]="#ff8a65";self._colormap["deep-orange lighten-1"]="#ff7043";self._colormap["deep-orange"]="#ff5722";self._colormap["deep-orange darken-1"]="#f4511e";self._colormap["deep-orange darken-2"]="#e64a19";self._colormap["deep-orange darken-3"]="#d84315";self._colormap["deep-orange darken-4"]="#bf360c";self._colormap["deep-orange accent-1"]="#ff9e80";self._colormap["deep-orange accent-2"]="#ff6e40";self._colormap["deep-orange accent-3"]="#ff3d00";self._colormap["deep-orange accent-4"]="#dd2c00";self._colormap["brown lighten-5"]="#efebe9";self._colormap["brown lighten-4"]="#d7ccc8";self._colormap["brown lighten-3"]="#bcaaa4";self._colormap["brown lighten-2"]="#a1887f";self._colormap["brown lighten-1"]="#8d6e63";self._colormap["brown"]="#795548";self._colormap["brown darken-1"]="#6d4c41";self._colormap["brown darken-2"]="#5d4037";self._colormap["brown darken-3"]="#4e342e";self._colormap["brown darken-4"]="#3e2723";self._colormap["grey lighten-5"]="#fafafa";self._colormap["grey lighten-4"]="#f5f5f5";self._colormap["grey lighten-3"]="#eeeeee";self._colormap["grey lighten-2"]="#e0e0e0";self._colormap["grey lighten-1"]="#bdbdbd";self._colormap["grey"]="#9e9e9e";self._colormap["grey darken-1"]="#757575";self._colormap["grey darken-2"]="#616161";self._colormap["grey darken-3"]="#424242";self._colormap["grey darken-4"]="#212121";self._colormap["blue-grey lighten-5"]="#eceff1";self._colormap["blue-grey lighten-4"]="#cfd8dc";self._colormap["blue-grey lighten-3"]="#b0bec5";self._colormap["blue-grey lighten-2"]="#90a4ae";self._colormap["blue-grey lighten-1"]="#78909c";self._colormap["blue-grey"]="#607d8b";self._colormap["blue-grey darken-1"]="#546e7a";self._colormap["blue-grey darken-2"]="#455a64";self._colormap["blue-grey darken-3"]="#37474f";self._colormap["blue-grey darken-4"]="#263238";self._colormap["black"]="#000000";self._colormap["white"]="#ffffff";self._colormap["transparent"]="transparent";self._colormap["lightslategrey"]="#778899";self._colormap["darkviolet"]="#9400D3";self._colormap["cyan"]="#00FFFF";self._colormap["darkslateblue"]="#483D8B";self._colormap["bisque"]="#FFE4C4";self._colormap["lightgrey"]="#D3D3D3";self._colormap["khaki"]="#F0E68C";self._colormap["darkgray"]="#A9A9A9";self._colormap["saddlebrown"]="#8B4513";self._colormap["blanchedalmond"]="#FFEBCD";self._colormap["darkblue"]="#00008B";self._colormap["lightcoral"]="#F08080";self._colormap["orangered"]="#FF4500";self._colormap["moccasin"]="#FFE4B5";self._colormap["azure"]="#F0FFFF";self._colormap["lightgoldenrodyellow"]="#FAFAD2";self._colormap["skyblue"]="#87CEEB";self._colormap["deepskyblue"]="#00BFFF";self._colormap["chartreuse"]="#7FFF00";self._colormap["mediumpurple"]="#9370DB";self._colormap["lightyellow"]="#FFFFE0";self._colormap["violet"]="#EE82EE";self._colormap["palevioletred"]="#DB7093";self._colormap["dimgrey"]="#696969";self._colormap["rosybrown"]="#BC8F8F";self._colormap["honeydew"]="#F0FFF0";self._colormap["mediumblue"]="#0000CD";self._colormap["darkseagreen"]="#8FBC8F";self._colormap["limegreen"]="#32CD32";self._colormap["paleturquoise"]="#AFEEEE";self._colormap["mediumorchid"]="#BA55D3";self._colormap["burlywood"]="#DEB887";self._colormap["silver"]="#C0C0C0";self._colormap["papayawhip"]="#FFEFD5";self._colormap["chocolate"]="#D2691E";self._colormap["lightsteelblue"]="#B0C4DE";self._colormap["pink"]="#FFC0CB";self._colormap["darkgreen"]="#006400";self._colormap["sienna"]="#A0522D";self._colormap["seashell"]="#FFF5EE";self._colormap["thistle"]="#D8BFD8";self._colormap["yellow"]="#FFFF00";self._colormap["lightseagreen"]="#20B2AA";self._colormap["cornsilk"]="#FFF8DC";self._colormap["blueviolet"]="#8A2BE2";self._colormap["tomato"]="#FF6347";self._colormap["cornflowerblue"]="#6495ED";self._colormap["sandybrown"]="#F4A460";self._colormap["gold"]="#FFD700";self._colormap["springgreen"]="#00FF7F";self._colormap["gray"]="#808080";self._colormap["slategrey"]="#708090";self._colormap["mediumvioletred"]="#C71585";self._colormap["crimson"]="#DC143C";self._colormap["darkcyan"]="#008B8B";self._colormap["ivory"]="#FFFFF0";self._colormap["darkmagenta"]="#8B008B";self._colormap["wheat"]="#F5DEB3";self._colormap["indianred"]="#CD5C5C";self._colormap["darkorchid"]="#9932CC";self._colormap["whitesmoke"]="#F5F5F5";self._colormap["mintcream"]="#F5FFFA";self._colormap["lightpink"]="#FFB6C1";self._colormap["black"]="#000000";self._colormap["teal"]="#008080";self._colormap["cadetblue"]="#5F9EA0";self._colormap["beige"]="#F5F5DC";self._colormap["darkkhaki"]="#BDB76B";self._colormap["blue"]="#0000FF";self._colormap["darkslategray"]="#2F4F4F";self._colormap["royalblue"]="#4169E1";self._colormap["seagreen"]="#2E8B57";self._colormap["purple"]="#800080";self._colormap["orchid"]="#DA70D6";self._colormap["forestgreen"]="#228B22";self._colormap["darksalmon"]="#E9967A";self._colormap["palegreen"]="#98FB98";self._colormap["navy"]="#000080";self._colormap["lightslategray"]="#778899";self._colormap["rebeccapurple"]="#663399";self._colormap["greenyellow"]="#ADFF2F";self._colormap["red"]="#FF0000";self._colormap["aqua"]="#00FFFF";self._colormap["white"]="#FFFFFF";self._colormap["dodgerblue"]="#1E90FF";self._colormap["lightblue"]="#ADD8E6";self._colormap["olive"]="#808000";self._colormap["coral"]="#FF7F50";self._colormap["peachpuff"]="#FFDAB9";self._colormap["darkolivegreen"]="#556B2F";self._colormap["darkturquoise"]="#00CED1";self._colormap["darkgrey"]="#A9A9A9";self._colormap["lavender"]="#E6E6FA";self._colormap["lightgray"]="#D3D3D3";self._colormap["gainsboro"]="#DCDCDC";self._colormap["tan"]="#D2B48C";self._colormap["plum"]="#DDA0DD";self._colormap["midnightblue"]="#191970";self._colormap["powderblue"]="#B0E0E6";self._colormap["dimgray"]="#696969";self._colormap["lemonchiffon"]="#FFFACD";self._colormap["salmon"]="#FA8072";self._colormap["lightgreen"]="#90EE90";self._colormap["brown"]="#A52A2A";self._colormap["goldenrod"]="#DAA520";self._colormap["steelblue"]="#4682B4";self._colormap["lightsalmon"]="#FFA07A";self._colormap["darkred"]="#8B0000";self._colormap["snow"]="#FFFAFA";self._colormap["olivedrab"]="#6B8E23";self._colormap["yellowgreen"]="#9ACD32";self._colormap["indigo"]="#4B0082";self._colormap["lawngreen"]="#7CFC00";self._colormap["magenta"]="#FF00FF";self._colormap["aquamarine"]="#7FFFD4";self._colormap["floralwhite"]="#FFFAF0";self._colormap["antiquewhite"]="#FAEBD7";self._colormap["hotpink"]="#FF69B4";self._colormap["turquoise"]="#40E0D0";self._colormap["peru"]="#CD853F";self._colormap["fuchsia"]="#FF00FF";self._colormap["firebrick"]="#B22222";self._colormap["aliceblue"]="#F0F8FF";self._colormap["darkgoldenrod"]="#B8860B";self._colormap["navajowhite"]="#FFDEAD";self._colormap["lavenderblush"]="#FFF0F5";self._colormap["mediumspringgreen"]="#00FA9A";self._colormap["slategray"]="#708090";self._colormap["mistyrose"]="#FFE4E1";self._colormap["linen"]="#FAF0E6";self._colormap["darkorange"]="#FF8C00";self._colormap["slateblue"]="#6A5ACD";self._colormap["lightcyan"]="#E0FFFF";self._colormap["lightskyblue"]="#87CEFA";self._colormap["mediumseagreen"]="#3CB371";self._colormap["mediumturquoise"]="#48D1CC";self._colormap["deeppink"]="#FF1493";self._colormap["ghostwhite"]="#F8F8FF";self._colormap["green"]="#008000";self._colormap["lime"]="#00FF00";self._colormap["mediumaquamarine"]="#66CDAA";self._colormap["oldlace"]="#FDF5E6";self._colormap["grey"]="#808080";self._colormap["orange"]="#FFA500";self._colormap["darkslategrey"]="#2F4F4F";self._colormap["mediumslateblue"]="#7B68EE";self._colormap["maroon"]="#800000";self._colormap["palegoldenrod"]="#EEE8AA";self._colormap["indigo"]="#6610f2";self._colormap["primary"]="#007bff";self._colormap["secondary"]="#6c757d";self._colormap["success"]="#28a745";self._colormap["info"]="#17a2b8";self._colormap["warning"]="#ffc107";self._colormap["danger"]="#dc3545";self._colormap["light"]="#f8f9fa";self._colormap["dark"]="#343a40";};this.sethtml= function(_elid,_elcontent) {if (self==null) self=this;var _el;_elid = _elid.toLowerCase();_el=null;_el = u("#" + _elid + "");_el.empty();_el.html(_elcontent);};this.setvalue= function(_elid,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").value(_elcontent);};this.getvalue= function(_elid) {if (self==null) self=this;var _svalue;_elid = _elid.toLowerCase();_svalue=u("#" + _elid + "").value();return _svalue;};this.setstyle= function(_elid,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").css(JSON.parse(_elcontent));};this.addclass= function(_elid,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").addClass(_elcontent);};this.setattr= function(_elid,_elprop,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").attr(_elcontent,_elcontent);};this.empty= function(_elid) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").empty();};this.append= function(_elid,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").append(_elcontent);};this.settext= function(_elid,_elcontent) {if (self==null) self=this;_elid = _elid.toLowerCase();u("#" + _elid + "").text(_elcontent);};this.eval= function(_elcontent) {if (self==null) self=this;eval(_elcontent);};this.evalwithresult= function(_elcontent) {if (self==null) self=this;return eval(_elcontent);};}function banano_uoebanano_uoeanchoricon() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._a= new banano_uoebanano_uoehtml();this._theme='';this._enabled=false;this._textvisible=false;this._text='';this._href='';this._isfab=false;this._click2toggle=false;this._horizontal=false;this._istoolbar=false;this._buttons=[];this._iconname='';this._iconalignment='';this._iconcircle=false;this._icontheme='';this._waveseffect=false;this._visibility='';this._wavestype='';this._wavescircle=false;this._zdepth='';this._activator=false;this._floating=false;this._alignment='';this._inlist=false;this._inline=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._a.addstyleattribute(_attribute,_value);return self;};this.initialize= function(_thisapp,_itemid,_itemicon,_itemiconalign,_itemiconcircle,_itemtext,_itemnavigateto,_btextvisible,_itemtheme,_itemicontheme) {if (self==null) self=this;self._app = _thisapp;self._alignment = "";self._inlist = false;self._inline = false;self._activator = false;self._floating = false;self._id = _itemid.toLowerCase();self._href = _itemnavigateto;self._textvisible = _btextvisible;self._text = _itemtext;self._theme = _itemtheme;self._isfab = false;self._click2toggle = false;self._horizontal = false;self._istoolbar = false;self._enabled = true;self._visibility = "";self._zdepth = "";self._iconname = _itemicon;self._iconalignment = _itemiconalign;self._icontheme = _itemicontheme;self._iconcircle = _itemiconcircle;self._buttons.length=0;self._buttons.length=0;self._a.initialize(self._id,"a");self._wavestype = self._app._enumwavestype._light;self._wavescircle = false;self._waveseffect = true;};this.addclass= function(_sclass) {if (self==null) self=this;self._a.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._a.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._a.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._a.removeattribute(_attr);return self;};this.tostring= function() {if (self==null) self=this;var _fab;var _li;var _strbutton;self._a._id = self._id;self._a.materialwaveseffect(self._waveseffect);self._a.sethref(self._href);self._app.materialusetheme(self._theme,self._a);self._a.materialenable(self._enabled);self._a.materialzdepth(self._zdepth);self._a.materialvisibility(self._visibility);if (self._a.classexists("fixed-action-btn") == true) {self._iconcircle = true;}if (self._a.classexists("halfway-fab") == true) {self._iconcircle = true;}if (self._a.classexists("btn-floating") == true) {self._iconcircle = true;}_banano_uoebanano_moduoe.materialaddicon(self._app,self._a,self._iconname,self._iconalignment,self._icontheme,self._iconcircle,false,false,false,false);self._a.materialwavestype(self._wavestype);self._a.materialwavescircle(self._wavescircle);self._a.addclassoncondition(self._activator,"activator");self._a.addclassoncondition(self._floating,"btn-floating");self._a.addclass(self._alignment);if (self._textvisible == true) {self._a.addcontent(self._text);}if (self._isfab == true) {_fab= new banano_uoebanano_uoehtml();_fab.initialize(self._id+"div","div");_fab.addclass("fixed-action-btn");_fab.addcontent(self._a.html());_fab.materialclick2toggle(self._click2toggle);_fab.materialhorizontal(self._horizontal);_fab.materialtoolbar(self._istoolbar);_li= new banano_uoebanano_uoehtml();_li.initialize("","ul");for (var _strbuttonindex=0;_strbuttonindex<self._buttons.length;_strbuttonindex++) {_strbutton=self._buttons[_strbuttonindex];_li.addcontent(_strbutton);}_fab.addcontent(_li.html());return _fab.html();} else {if (self._inlist == true) {_li= new banano_uoebanano_uoehtml();_li.initialize("","li");if (self._inline == true) {_li.addstyleattribute("display","inline");}_li.addcontent(self._a.html());return _li.html();} else {return self._a.html();}}};}function banano_uoebanano_uoeicon() {var self;this._app= new banano_uoebanano_uoeapp();this._id='';this._iconname='';this._theme='';this._element= new banano_uoebanano_uoehtml();this._alignment='';this._addcursor=false;this._circle=false;this._waveeffects=false;this._prefix=false;this._waveseffect=false;this._visibility='';this._wavestype='';this._wavescircle=false;this._zdepth='';this._enabled=false;this._iconsize='';this._close=false;this._hoverable=false;this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_sid,_siconname,_sthemename) {if (self==null) self=this;self._app = _thisapp;self._id = _sid.toLowerCase();self._close = false;self._iconname = _siconname;self._prefix = false;self._circle = false;self._addcursor = false;self._theme = _sthemename;self._waveeffects = true;self._alignment = "";self._element.initialize(self._id,"i");self._enabled = true;self._visibility = "";self._zdepth = "";self._wavestype = self._app._enumwavestype._light;self._iconsize = "";self._waveseffect = true;self._wavescircle = false;return self;};this.removewave= function() {if (self==null) self=this;self._waveeffects = false;self._wavestype = "";self._wavescircle = false;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._app.materialusetheme(self._theme,self._element);self._element.materialbuildicon(self._iconname,self._alignment);self._element.materialcircle(self._circle);self._element.materialwaveseffect(self._waveeffects);self._element.addclassoncondition(self._prefix,"prefix");self._element.materialvisibility(self._visibility);self._element.materialwavestype(self._wavestype);self._element.materialwavescircle(self._wavescircle);self._element.materialwaveseffect(self._waveseffect);self._element.materialzdepth(self._zdepth);self._element.materialenable(self._enabled);self._app.applytooltip(self._id,self._element);self._element.materialiconsize(self._iconsize);self._element.materialclose(self._close);if (self._addcursor == true) {self._element.addcursor();}return self._element.html();};}function banano_uoebanano_uoecarousel() {var self;this._id='';this._theme='';this._visibility='';this._zdepth='';this._enabled=false;this._app= new banano_uoebanano_uoeapp();this._element= new banano_uoebanano_uoehtml();this._items=[];this._isslider=false;this._duration=0;this._dist=0;this._shift=0;this._padding=0;this._fullwidth=false;this._indicators=false;this._nowrap=false;this._center=false;this._hoverable=false;this._interval=0;this._numvisible=0;this._instance='';this.addstyleattribute= function(_attribute,_value) {if (self==null) self=this;self._element.addstyleattribute(_attribute,_value);return self;};this.addclass= function(_sclass) {if (self==null) self=this;self._element.addclass(_sclass);return self;};this.removeclass= function(_sclass) {if (self==null) self=this;self._element.removeclass(_sclass);return self;};this.addattribute= function(_attr,_value) {if (self==null) self=this;self._element.addattribute(_attr,_value);return self;};this.removeattribute= function(_attr) {if (self==null) self=this;self._element.removeattribute(_attr);return self;};this.initialize= function(_thisapp,_mvarid) {if (self==null) self=this;self._app = _thisapp;self._id = _mvarid.toLowerCase();self._element.initialize(self._id,"div");self._theme = "";self._center = false;self._visibility = "";self._zdepth = "";self._enabled = true;self._items.length=0;self._items.length=0;self._isslider = false;self._duration = 200;self._dist = -100;self._shift = 0;self._padding = 0;self._fullwidth = true;self._indicators = true;self._nowrap = false;self._interval = 2000;self._numvisible = 5;self._instance = "" + self._id + "inst";};this.addcarouselfixeditem= function() {if (self==null) self=this;var _fi;_fi= new banano_uoebanano_uoehtml();_fi.initialize("","div");_fi.addclass("carousel-fixed-item");_fi.addclass("center");self._items.push(_fi.html());return self;};this.additem= function(_itemid,_itemhtml) {if (self==null) self=this;var _div;_div= new banano_uoebanano_uoehtml();_div.initialize(_itemid,"div");_div.addclass("carousel-item");_div.addcontent(_itemhtml);self._items.push(_div.html());return self;};this.addcontainer= function(_cont) {if (self==null) self=this;var _div;_div= new banano_uoebanano_uoehtml();_div.initialize(_cont._id+"parent","div");_div.addclass("carousel-item");_div.addcursor();if (_cont!=null) {_div.addcontent(_cont.tostring());}self._items.push(_div.html());return self;};this.addslide= function(_itemid,_href,_imgurl) {if (self==null) self=this;var _slideitem;_slideitem= new banano_uoebanano_uoeanchor();_slideitem.initialize(self._app,_itemid);_slideitem.addclass("carousel-item");_slideitem._href = _href;_banano_uoebanano_moduoe.materialaddimage(self._app,_slideitem._element,_imgurl,"","","",false,true,true,"");_slideitem._waveseffect = false;self._items.push(_slideitem.tostring());return self;};this.tostring= function() {if (self==null) self=this;self._element._id = self._id;self._element.addclass("carousel");self._element.addclassoncondition(self._isslider,"carousel-slider");self._element.addattributeoncondition(self._indicators,"data-indicators","true");self._element.addclassoncondition(self._center,"center");self._app.materialusetheme(self._theme,self._element);self._element.materialenable(self._enabled);self._element.materialzdepth(self._zdepth);self._element.materialvisibility(self._visibility);self._app.applytooltip(self._id,self._element);self._element.addcontentlist(self._items);return self._element.html();};this.nextslide= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".next();";eval(_script);};this.previousslide= function() {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".prev();";eval(_script);};this.setslide= function(_slidepos) {if (self==null) self=this;var _script;_script="var inst" + self._id + " = document.getElementById('" + self._id + "'); \n	var " + self._instance + " = M.Carousel.getInstance(inst" + self._id + "); \n	" + self._instance + ".set(" + _slidepos + ");";eval(_script);};this.getsettings= function() {if (self==null) self=this;var _dpsettings;var _strds;_dpsettings={};_dpsettings={};_dpsettings={};_dpsettings["id"]=self._id;_dpsettings["instance"]="carousel";_dpsettings["fullwidth"]=self._fullwidth;_dpsettings["duration"]=self._duration;_dpsettings["numVisible"]=self._numvisible;_dpsettings["dist"]=self._dist;_dpsettings["shift"]=self._shift;_dpsettings["padding"]=self._padding;_dpsettings["indicators"]=self._indicators;_dpsettings["nowrap"]=self._nowrap;_strds=self._app.map2json(_dpsettings);return _strds;};}
// =========================== BANano jCore ===========================
var bananoglobal=this;var DateTime;var _BANUnique=0;const sleep = (milliseconds) => {return new Promise(resolve => setTimeout(resolve, milliseconds))};function BANAnoMethodVarsToMap(m,b,n) {if (b) {m['subname']=n;}return m;};function BANanoExec(functionName, context, args) {var args = Array.prototype.slice.call(arguments, 2);var namespaces = functionName.split('.');var func = namespaces.pop();for(var i = 0; i < namespaces.length; i++) {context = context[namespaces[i]];}return context[func].apply(context, args);};function BANanoSuffixFromID(id) {var i=id.lastIndexOf('_');if (i>0) {return id.substring(i+1);}return -1;};function banano_isconnected(tag, returnMethod, obj) {var img = document.createElement('img');img.onerror = function() {obj[returnMethod](tag, false);};img.onload = function() {obj[returnMethod](tag, true);};img.src = './assets/donotdelete.gif?rand=' +((new Date()).getTime());}async function banano_isconnectedWait() {return new Promise(function (resolve, reject) {var img = document.createElement('img');img.onerror = function() {resolve(false);};img.onload = function() {resolve(true);};img.src = './assets/donotdelete.gif?rand=' +((new Date()).getTime());})};function setStyle(el, property, value) {el.style[property] = value;}function getStyle(el, property) {var style = window.getComputedStyle ? getComputedStyle(el, null) : el.currentStyle;return style[property];}(function () {var DateFormat = "MM/dd/yyyy";var TimeFormat = "HH:mm:ss";var _TZOffset = new Date().getTimezoneOffset()*-1/60;var self = this;var DateTime = {DateParse: function(s) {var ddres = Date.parse(s);return DateTime.WithTZ(ddres).getTime();},TimeParse: function(s) {var dd = new Date();s = dd.format('yyyy-MM-dd') + ' ' + s;var ddres = Date.parse(s);return DateTime.WithTZ(ddres).getTime();},Date: function(n) {var ddres = DateTime.WithTZ(n);return ddres.format(DateFormat);},Time: function(n) {var ddres = DateTime.WithTZ(n);return ddres.format(TimeFormat);},GetDateFormat: function() {return DateFormat;},SetDateFormat: function(s) {DateFormat=s;},GetTimeFormat: function() {return TimeFormat;},SetTimeFormat: function(s) {TimeFormat=s;},Add: function(dd, y, m, d) {var ddres = DateTime.WithTZ(dd);var res = DateTime.InnerAdd(ddres, y, 'y');res = DateTime.InnerAdd(res, m, 'm');res = DateTime.InnerAdd(res, d, 'd');return res.getTime();},InnerAdd: function(d, c, t){c = (c === undefined) ? 0 : c;var result = null;switch(t){case 'mill':result = new Date(d.setMilliseconds(d.getMilliseconds()+c));break;case 's':result = new Date(d.setSeconds(d.getSeconds()+c));break;case 'min':result = new Date(d.setMinutes(d.getMinutes()+c));break;case 'h':result = new Date(d.setHours(d.getHours()+c));break;case 'd':result = new Date(d.setDate(d.getDate()+c));break;case 'm':result = new Date(d.setMonth(d.getMonth()+c));break;case 'y':result = new Date(d.setFullYear(d.getFullYear()+c));break;default:console.error("[timeSolver.js] Input Type Error");break;}return result;},WithTZ: function(n) {if (_TZOffset!=new Date().getTimezoneOffset()*-1/60) {var d = DateTime.InnerAdd(new Date(n),new Date(n).getTimezoneOffset()/60, 'h');d = DateTime.InnerAdd(d, _TZOffset, 'h');return d;} else {return new Date(n);}},Now: function() {return new Date().getTime();},		GetYear: function(n) {return DateTime.WithTZ(new Date(n)).getFullYear();},GetMonth: function(n) {return DateTime.WithTZ(new Date(n)).getMonth()+1;},GetDayOfMonth: function(n) {return DateTime.WithTZ(new Date(n)).getDate();},GetDayOfYear: function(n) {var t = new Date(n);var dayCount = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];var mn = t.getMonth();var dn = t.getDate();var dayOfYear = dayCount[mn] + dn;var year = t.getFullYear();var isLeap=false;if((year & 3) != 0) {isLeap=false;} else {isLeap = ((year % 100) != 0 || (year % 400) == 0);}if(mn > 1 && isLeap) dayOfYear++;return dayOfYear;},GetDayOfWeek: function(n) {return DateTime.WithTZ(new Date(n)).getDay()+1;},GetHour: function(n) {return DateTime.WithTZ(new Date(n)).getHours();},GetMinute: function(n) {return DateTime.WithTZ(new Date(n)).getMinutes();},GetSecond: function(n) {return DateTime.WithTZ(new Date(n)).getSeconds();},GetTimeZoneOffsetAt: function(n) {if (_TZOffset!=new Date().getTimezoneOffset()*-1/60) {return _TZOffset;} else {return new Date(n).getTimezoneOffset()*-1/60;}},GetWeekInYear: function(n) {var onejan = new Date(n.getFullYear(), 0, 1);return Math.ceil( (((n - onejan) / 86400000) + onejan.getDay() + 1) / 7 );},GetWeekInMonth: function(n, exact) {var month = n.getMonth(), year = n.getFullYear(), firstWeekday = new Date(year, month, 1).getDay(), lastDateOfMonth = new Date(year, month + 1, 0).getDate(), offsetDate = n.getDate() + firstWeekday - 1, index = 1, weeksInMonth = index + Math.ceil((lastDateOfMonth + firstWeekday - 7) / 7), week = index + Math.floor(offsetDate / 7);if (exact || week < 2 + index) return week;return week === weeksInMonth ? index + 5 : week;},TicksPerDay: function() {return 86400000;},TicksPerHour: function() {return 3600000;},TicksPerMinute: function() {return 60000;},TicksPerSecond: function() {return 1000;},TimeZoneOffset: function() {return _TZOffset;},SetTimeZone: function(n) {_TZOffset = n;}};	if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {module.exports = DateTime;} else {if (typeof window !== 'undefined') {window.DateTime = DateTime;} else {bananoglobal.DateTime = DateTime;}}})();var dateFormat = function () {var token = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,timezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,timezoneClip = /[^-+\dA-Z]/g,pad = function (val, len) {val = String(val);len = len || 2;while (val.length < len) val = "0" + val;return val;};return function (date, mask, utc) {var dF = dateFormat;if (arguments.length == 1 && Object.prototype.toString.call(date) == "[object String]" && !/\d/.test(date)) {mask = date;date = undefined;}date = date ? new Date(date) : new Date;if (isNaN(date)) throw SyntaxError("invalid date");if (mask.slice(0, 4) == "UTC:") {mask = mask.slice(4);utc = true;}var	_ = utc ? "getUTC" : "get",d = date[_ + "Date"](),D = date[_ + "Day"](),m = date[_ + "Month"](),y = date[_ + "FullYear"](),H = date[_ + "Hours"](),M = date[_ + "Minutes"](),s = date[_ + "Seconds"](),L = date[_ + "Milliseconds"](),o = utc ? 0 : date.getTimezoneOffset(),DD = DateTime.GetDayOfYear(date),w = DateTime.GetWeekInYear(date),W = DateTime.GetWeekInMonth(date, true),flags = {d: d,dd: pad(d),E: dF.i18n.dayNames[D],EE: dF.i18n.dayNames[D + 7],M: m + 1,MM: pad(m + 1),MMM: dF.i18n.monthNames[m],MMMM: dF.i18n.monthNames[m + 12],yy: String(y).slice(2),yyyy: y,h: H % 12 || 12,K: pad(H % 12 || 12),H: H,HH: pad(H),m: M,mm: pad(M),s: s,ss: pad(s),S: pad(L > 99 ? Math.round(L / 10) : L),a: H < 12 ? "AM" : "PM",Z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),z: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),X: utc ? "UTC" : (String(date).match(timezone) || [""]).pop().replace(timezoneClip, ""),o: (o > 0 ? "-" : "+") + pad(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),u: D,D: DD,w: w,W: W};return mask.replace(token, function ($0) {return $0 in flags ? flags[$0] : $0.slice(1, $0.length - 1);});};}();dateFormat.i18n = {dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]};Date.prototype.format = function (mask, utc) {return dateFormat(this, mask, utc);};String.prototype.equalsIgnoreCase = function(otherString) {return (this.toUpperCase().localeCompare(otherString.toUpperCase())===0);};String.prototype.contains = function(otherString) {return (this.indexOf(otherString)>-1);};String.prototype.getBytes = function() {var utf8 = [];var str = this;for (var i=0; i < str.length; i++) {var charcode = str.charCodeAt(i);if (charcode < 0x80) utf8.push(charcode);else if (charcode < 0x800) {utf8.push(0xffffffc0 | (charcode >> 6), 0xffffff80 | (charcode & 0x3f));} else if (charcode < 0xd800 || charcode >= 0xe000) {utf8.push(0xffffffe0 | (charcode >> 12), 0xffffff80 | ((charcode>>6) & 0x3f), 0xffffff80 | (charcode & 0x3f));} else {utf8.push(0xef, 0xbf, 0xbd);}}return utf8;};function banano_bytesToString(array) {var str = '',i;var data = new Uint8Array(array);for (i = 0; i < data.length; i++) {var value = data[i];if (value < 0x80) {str += String.fromCharCode(value);} else if (value > 0xBF && value < 0xE0) {str += String.fromCharCode((value & 0x1F) << 6 | data[i + 1] & 0x3F);i += 1;} else if (value > 0xDF && value < 0xF0) {str += String.fromCharCode((value & 0x0F) << 12 | (data[i + 1] & 0x3F) << 6 | data[i + 2] & 0x3F);i += 2;}}return str;};function banano_getB4JKeyAt(outof, index) {var getkeyatkeycounter=0;for (var getkeyatkey in outof) {if (outof.hasOwnProperty(getkeyatkey)) {if (getkeyatkeycounter==index) {return getkeyatkey;}getkeyatkeycounter++;}}return '';};function banano_getB4JValueAt(outof, index) {var getkeyatkeycounter=0;for (var getkeyatkey in outof) {if (outof.hasOwnProperty(getkeyatkey)) {if (getkeyatkeycounter==index) {return outof[getkeyatkey];}getkeyatkeycounter++;}}return '';};function StringBuilder() {this.strings = new Array("");};StringBuilder.prototype.append = function (value) {var self=this;if (value) {this.strings.push(value);}return self;};StringBuilder.prototype.insert = function (offset, value) {var self=this;var str = this.strings.join("");this.strings = new Array("");this.strings.push([str.slice(0, offset), value, str.slice(offset)].join(''));return self;};StringBuilder.prototype.remove = function (startoffset, endoffset) {var self=this;var str = this.strings.join("");this.strings = new Array("");this.strings.push([str.slice(0, startoffset), str.slice(endoffset)].join(''));return self;};StringBuilder.prototype.length = function() {return this.strings.join("").length;};StringBuilder.prototype.toString = function () {return this.strings.join("");};function Param(obj) {if (typeof (obj) === 'string' || Object.prototype.toString.call(obj) === '[object FormData]') return obj;if (/application\/json/i.test(settings.headers['Content-type']) || Object.prototype.toString.call(obj) === '[object Array]') return JSON.stringify(obj);var encoded = [];for (var prop in obj) {if (obj.hasOwnProperty(prop)) {encoded.push(encodeURIComponent(prop) + '=' + encodeURIComponent(obj[prop]));}}return encoded.join('&');};function banano_sf(_text,_onlynbsp){try {var _s=new StringBuilder();var _v='' + _text;if (_onlynbsp) {_v = _v.split("{NBSP}").join(" ");} else {_v = _v.split("(\r\n|\n\r|\r|\n)").join("<br>");_v = _v.split("{B}").join("<b>");_v = _v.split("{/B}").join("</b>");_v = _v.split("{I}").join("<i>");_v = _v.split("{/I}").join("</i>");_v = _v.split("{U}").join("<ins>");_v = _v.split("{/U}").join("</ins>");_v = _v.split("{SUB}").join("<sub>");_v = _v.split("{/SUB}").join("</sub>");_v = _v.split("{SUP}").join("<sup>");_v = _v.split("{/SUP}").join("</sup>");_v = _v.split("{BR}").join("<br>");_v = _v.split("{WBR}").join("<wbr>");_v = _v.split("{NBSP}").join("&nbsp;");_v = _v.split("{AL}").join("<a rel=\"nofollow\" target=\"_blank\" href=\"");_v = _v.split("{AT}").join("\">");_v = _v.split("{/AL}").join("</a>");_v = _v.split("{AS}").join(" title=\"");_v = _v.split("{/AS}").join("\"");while (_v.indexOf("{C:")>-1) {_v = self.replacefirst(_v,"{C:","<span style=\"color:");_v = self.replacefirst(_v,"}","\">");_v = self.replacefirst(_v,"{/C}","</span>");}_v = _v.split("{CODE}").join("<pre><code>");_v = _v.split("{/CODE}").join("</code></pre>");while (_v.indexOf("{ST:")>-1) {_v = self.replacefirst(_v,"{ST:","<span style=\"");_v = self.replacefirst(_v,"}","\">");_v = self.replacefirst(_v,"{/ST}","</span>");}var _start=_v.indexOf("{IC:");while (_start>-1) {var _stop=_v.indexOf("{/IC}");var _vv="";if (_stop>0) {_vv = _v.substring(_start,_stop+5);} else {break;}var _iconcolor=_vv.substring(4,11);var _iconname=_vv.substring(12,_vv.length-5);var _repl="";switch (_iconname.substring(0,3).toLowerCase()) {case "mdi":_repl = "<i style=\"color: "+_iconcolor+"\" class=\""+_iconname+"\"></i>";break;case "fa ":_repl = "<i style=\"color: "+_iconcolor+"\" class=\""+_iconname+"\"></i>";break;case "fa-":_repl = "<i style=\"color: "+_iconcolor+"\" class=\""+_iconname+"\"></i>";break;default:_repl = "<i style=\"color: "+_iconcolor+"\" class=\"material-icons\">"+_iconname+"</i>";break;}_v = _v.split(_vv).join(_repl);_start = _v.indexOf("{IC:");}}_s.append(_v);return _s.toString();}catch(err) {console.log(err.message + ' ' + err.stack);}};function replacefirst(_s,_searchfor,_replacewith){try {var _i=_s.indexOf(_searchfor);if (_i>-1) {return _s.substring(0,_i)+_replacewith+_s.substring(_i+_searchfor.length);} else {return _s;}}catch(err) {console.log(err.message + ' ' + err.stack);}};
var _banano_uoebananodemo = new banano_uoebananodemo();
var _banano_uoebananodemo_modbanano = new banano_uoebananodemo_modbanano();
var _banano_uoebananodemo_pgindex = new banano_uoebananodemo_pgindex();
var _banano_uoebananodemo_pgcard = new banano_uoebananodemo_pgcard();
var _banano_uoebananodemo_pgnavigation = new banano_uoebananodemo_pgnavigation();
var _banano_uoebananodemo_pgfeature = new banano_uoebananodemo_pgfeature();
var _banano_uoebananodemo_pgtooltips = new banano_uoebananodemo_pgtooltips();
var _banano_uoebananodemo_pgbreadcrumbs = new banano_uoebananodemo_pgbreadcrumbs();
var _banano_uoebananodemo_pgtabs = new banano_uoebananodemo_pgtabs();
var _banano_uoebananodemo_pgcarousel = new banano_uoebananodemo_pgcarousel();
var _banano_uoebananodemo_pgcheckbox = new banano_uoebananodemo_pgcheckbox();
var _banano_uoebananodemo_pgchip = new banano_uoebananodemo_pgchip();
var _banano_uoebananodemo_pglist = new banano_uoebananodemo_pglist();
var _banano_uoebananodemo_pgcollapsible = new banano_uoebananodemo_pgcollapsible();
var _banano_uoebananodemo_pgdatetime = new banano_uoebananodemo_pgdatetime();
var _banano_uoebananodemo_pgselect = new banano_uoebananodemo_pgselect();
var _banano_uoebananodemo_pgdropdown = new banano_uoebananodemo_pgdropdown();
var _banano_uoebananodemo_pgfile = new banano_uoebananodemo_pgfile();
var _banano_uoebananodemo_pgvideo = new banano_uoebananodemo_pgvideo();
var _banano_uoebananodemo_pgicons = new banano_uoebananodemo_pgicons();
var _banano_uoebananodemo_pgimage = new banano_uoebananodemo_pgimage();
var _banano_uoebananodemo_pginput = new banano_uoebananodemo_pginput();
var _banano_uoebananodemo_pgparallax = new banano_uoebananodemo_pgparallax();
var _banano_uoebananodemo_pgblockquote = new banano_uoebananodemo_pgblockquote();
var _banano_uoebananodemo_pgpreloader = new banano_uoebananodemo_pgpreloader();
var _banano_uoebananodemo_pgprogress = new banano_uoebananodemo_pgprogress();
var _banano_uoebananodemo_pgradio = new banano_uoebananodemo_pgradio();
var _banano_uoebananodemo_pgrange = new banano_uoebananodemo_pgrange();
var _banano_uoebananodemo_pgslider = new banano_uoebananodemo_pgslider();
var _banano_uoebananodemo_pgswitch = new banano_uoebananodemo_pgswitch();
var _banano_uoebananodemo_pgbuttons = new banano_uoebananodemo_pgbuttons();
var _banano_uoebananodemo_pgpagination = new banano_uoebananodemo_pgpagination();
var _banano_uoebananodemo_pgmodal = new banano_uoebananodemo_pgmodal();
var _banano_uoebananodemo_pgcollections = new banano_uoebananodemo_pgcollections();
var _banano_uoebananodemo_pgcopyrights = new banano_uoebananodemo_pgcopyrights();
var _banano_uoebananodemo_pggrid = new banano_uoebananodemo_pggrid();
var _banano_uoebanano_moduoe = new banano_uoebanano_moduoe();
// =========================== modBANano  ===========================
function banano_uoebananodemo_modbanano() {
var self;
this._r1c2=null;

this._app= new banano_uoebanano_uoeapp();

// [9] Sub AddTOC(thisApp As UOEApp, bodyID As String) 
this.addtoc= function(_thisapp,_bodyid) {
if (self==null) self=this;
var _toc;
// [10]  App = thisApp 
self._app = _thisapp;
// [11]  bodyID = bodyID.tolowercase 
_bodyid = _bodyid.toLowerCase();
// [13]  r1c2 = BANano.GetElement( {0} ) 
self._r1c2 = u("#" + _bodyid + "r1c2");
// [15]  Dim toc As UOETOC 
_toc= new banano_uoebanano_uoetoc();
// [16]  toc.Initialize(App, {2} , {3} ) 
_toc.initialize(self._app,"toc","");
// [17]  toc.AddLink( {4} , {5} , {6} , {7} ) 
_toc.addlink("gobuttons","BM Buttons","","");
// [18]  toc.AddLink( {8} , {9} , {10} , {11} ) 
_toc.addlink("gobq","BM Blockquote","","");
// [19]  toc.AddLink( {12} , {13} , {14} , {15} ) 
_toc.addlink("gobc","BM BreadCrumbs","","");
// [20]  toc.AddLink( {16} , {17} , {18} , {19} ) 
_toc.addlink("gocards","BM Cards","","");
// [21]  toc.AddLink( {20} , {21} , {22} , {23} ) 
_toc.addlink("gocarousel","BM Carousel","","");
// [22]  toc.AddLink( {24} , {25} , {26} , {27} ) 
_toc.addlink("gocheckbox","BM CheckBox","","");
// [23]  toc.AddLink( {28} , {29} , {30} , {31} ) 
_toc.addlink("gochipx","BM Chip","","");
// [24]  toc.AddLink( {32} , {33} , {34} , {35} ) 
_toc.addlink("gocollapse","BM Collapsible","","");
// [25]  toc.AddLink( {36} , {37} , {38} , {39} ) 
_toc.addlink("godatetime","BM DateTime","","");
// [26]  toc.AddLink( {40} , {41} , {42} , {43} ) 
_toc.addlink("godropdown","BM Dropdown","","");
// [27]  toc.AddLink( {44} , {45} , {46} , {47} ) 
_toc.addlink("gofeature","BM Feature","","");
// [28]  toc.AddLink( {48} , {49} , {50} , {51} ) 
_toc.addlink("gofile","BM File","","");
// [29]  toc.AddLink( {52} , {53} , {54} , {55} ) 
_toc.addlink("gocopyrights","BM Footer","","");
// [30]  toc.AddLink( {56} , {57} , {58} , {59} ) 
_toc.addlink("gogrid","BM Grid","#","");
// [31]  toc.AddLink( {60} , {61} , {62} , {63} ) 
_toc.addlink("goicons","BM Icons","","");
// [32]  toc.AddLink( {64} , {65} , {66} , {67} ) 
_toc.addlink("goimages","BM Images","","");
// [33]  toc.AddLink( {68} , {69} , {70} , {71} ) 
_toc.addlink("golabels","BM Label","#","");
// [34]  toc.AddLink( {72} , {73} , {74} , {75} ) 
_toc.addlink("golist","BM List","","");
// [35]  toc.AddLink( {76} , {77} , {78} , {79} ) 
_toc.addlink("gocollections","BM ListView","","");
// [36]  toc.AddLink( {80} , {81} , {82} , {83} ) 
_toc.addlink("gomodal","BM Modal","","");
// [37]  toc.AddLink( {84} , {85} , {86} , {87} ) 
_toc.addlink("gonavbar","BM NavBar","","");
// [38]  toc.AddLink( {88} , {89} , {90} , {91} ) 
_toc.addlink("gopagination","BM Pagination","","");
// [39]  toc.AddLink( {92} , {93} , {94} , {95} ) 
_toc.addlink("goparallax","BM Parallax","","");
// [40]  toc.AddLink( {96} , {97} , {98} , {99} ) 
_toc.addlink("gopreloader","BM Preloader","","");
// [41]  toc.AddLink( {100} , {101} , {102} , {103} ) 
_toc.addlink("goprogress","BM Progress","","");
// [42]  toc.AddLink( {104} , {105} , {106} , {107} ) 
_toc.addlink("goradio","BM Radio","","");
// [43]  toc.AddLink( {108} , {109} , {110} , {111} ) 
_toc.addlink("gorange","BM Range","","");
// [44]  toc.AddLink( {112} , {113} , {114} , {115} ) 
_toc.addlink("goselect","BM Select","","");
// [45]  toc.AddLink( {116} , {117} , {118} , {119} ) 
_toc.addlink("goslider","BM Slider","","");
// [46]  toc.AddLink( {120} , {121} , {122} , {123} ) 
_toc.addlink("goswitch","BM Switch","","");
// [47]  toc.AddLink( {124} , {125} , {126} , {127} ) 
_toc.addlink("gotabs","BM Tabs","","");
// [48]  toc.AddLink( {128} , {129} , {130} , {131} ) 
_toc.addlink("gotext","BM Textboxes & Textarea","","");
// [49]  toc.AddLink( {132} , {133} , {134} , {135} ) 
_toc.addlink("gott","BM Tooltips","","");
// [50]  toc.AddLink( {136} , {137} , {138} , {139} ) 
_toc.addlink("govideo","BM Video","","");
// [53]  r1c2.SetHTML(toc.ToString) 
self._r1c2.html(_toc.tostring());
// [57]  toc.BindEvents( {140} , Me) 
_toc.bindevents("tocButtons",self);
// [60]  App.RemoveEvent( {141} ) 
self._app.removeevent("getb4j");
// [61]  App.RemoveEvent( {142} ) 
self._app.removeevent("lib");
// [62]  App.RemoveEvent( {143} ) 
self._app.removeevent("getmaterial");
// [63]  App.RemoveEvent( {144} ) 
self._app.removeevent("Components");
// [64]  App.RemoveEvent( {145} ) 
self._app.removeevent("downloads");
// End Sub
};

// [67] Sub tocButtons(event As BANanoEvent) 
this.tocbuttons= function(_event) {
if (self==null) self=this;
var _strevent;
var _elkey;
var _el;
// [68]  event.StopPropagation 
_event.stopPropagation();
// [69]  Dim strEvent As String = event.ID 
_strevent=_event.target.id;
// [70]  If strEvent.StartsWith( {146} ) Then 
if (_strevent.startsWith("go")) {
// [71]  Dim elKey As String = {1} 
_elkey="#" + _strevent + "";
// [72]  Dim el As BANanoElement = BANano.GetElement(elKey) 
_el=u(_elkey);
// [73]  el.AddClass( {147} ) 
_el.addClass("active");
// [74]  End If 
}
// [75]  Select Case App.MvField(event.ID,1, {148} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [76]  Case {149} 
case "" + "goprogress":
// [77]  pgProgress.Init(App) 
_banano_uoebananodemo_pgprogress.init(self._app);
// [78]  Case {150} 
break;
case "" + "goswitch":
// [79]  pgSwitch.Init(App) 
_banano_uoebananodemo_pgswitch.init(self._app);
// [80]  Case {151} 
break;
case "" + "goslider":
// [81]  pgSlider.Init(App) 
_banano_uoebananodemo_pgslider.init(self._app);
// [82]  Case {152} 
break;
case "" + "gorange":
// [83]  pgRange.Init(App) 
_banano_uoebananodemo_pgrange.init(self._app);
// [84]  Case {153} 
break;
case "" + "goradio":
// [85]  pgRadio.Init(App) 
_banano_uoebananodemo_pgradio.init(self._app);
// [86]  Case {154} 
break;
case "" + "gopreloader":
// [87]  pgPreloader.Init(App) 
_banano_uoebananodemo_pgpreloader.init(self._app);
// [88]  Case {155} 
break;
case "" + "goparallax":
// [89]  pgParallax.Init(App) 
_banano_uoebananodemo_pgparallax.init(self._app);
// [90]  Case {156} 
break;
case "" + "gopagination":
// [91]  pgPagination.Init(App) 
_banano_uoebananodemo_pgpagination.init(self._app);
// [92]  Case {157} 
break;
case "" + "gomodal":
// [93]  pgModal.Init(App) 
_banano_uoebananodemo_pgmodal.init(self._app);
// [94]  Case {158} 
break;
case "" + "golist":
// [95]  pgList.Init(App) 
_banano_uoebananodemo_pglist.init(self._app);
// [96]  Case {159} 
break;
case "" + "gotext":
// [97]  pgInput.Init(App) 
_banano_uoebananodemo_pginput.init(self._app);
// [98]  Case {160} 
break;
case "" + "goimages":
// [99]  pgImage.Init(App) 
_banano_uoebananodemo_pgimage.init(self._app);
// [100]  Case {161} 
break;
case "" + "goicons":
// [101]  pgIcons.Init(App) 
_banano_uoebananodemo_pgicons.init(self._app);
// [102]  Case {162} 
break;
case "" + "govideo":
// [103]  pgVideo.Init(App) 
_banano_uoebananodemo_pgvideo.init(self._app);
// [104]  Case {163} 
break;
case "" + "gofeature":
// [105]  pgFeature.Init(App) 
_banano_uoebananodemo_pgfeature.init(self._app);
// [106]  Case {164} 
break;
case "" + "gofile":
// [107]  pgFile.Init(App) 
_banano_uoebananodemo_pgfile.init(self._app);
// [108]  Case {165} 
break;
case "" + "godropdown":
// [109]  pgDropdown.Init(App) 
_banano_uoebananodemo_pgdropdown.init(self._app);
// [110]  Case {166} 
break;
case "" + "goselect":
// [111]  pgSelect.Init(App) 
_banano_uoebananodemo_pgselect.init(self._app);
// [112]  Case {167} 
break;
case "" + "gonavbar":
// [113]  pgNavigation.Init(App) 
_banano_uoebananodemo_pgnavigation.init(self._app);
// [114]  Case {168} 
break;
case "" + "godatetime":
// [115]  pgDateTime.Init(App) 
_banano_uoebananodemo_pgdatetime.init(self._app);
// [116]  Case {169} 
break;
case "" + "gocopyrights":
// [117]  pgCopyRights.Init(App) 
_banano_uoebananodemo_pgcopyrights.init(self._app);
// [118]  Case {170} 
break;
case "" + "gocollections":
// [119]  pgCollections.Init(App) 
_banano_uoebananodemo_pgcollections.init(self._app);
// [120]  Case {171} 
break;
case "" + "gocollapse":
// [121]  pgCollapsible.Init(App) 
_banano_uoebananodemo_pgcollapsible.init(self._app);
// [122]  Case {172} 
break;
case "" + "gochipx":
// [123]  pgchip.Init(App) 
_banano_uoebananodemo_pgchip.init(self._app);
// [124]  Case {173} 
break;
case "" + "gocheckbox":
// [125]  pgcheckbox.Init(App) 
_banano_uoebananodemo_pgcheckbox.init(self._app);
// [126]  Case {174} 
break;
case "" + "gocarousel":
// [127]  pgcarousel.init(App) 
_banano_uoebananodemo_pgcarousel.init(self._app);
// [128]  Case {175} 
break;
case "" + "gogrid":
// [129]  pgGrid.Init(App) 
_banano_uoebananodemo_pggrid.init(self._app);
// [130]  Case {176} 
break;
case "" + "golabels":
// [131]  pgIndex.Init(App) 
_banano_uoebananodemo_pgindex.init(self._app);
// [132]  Case {177} 
break;
case "" + "gobuttons":
// [133]  pgButtons.Init(App) 
_banano_uoebananodemo_pgbuttons.init(self._app);
// [134]  Case {178} 
break;
case "" + "gobq":
// [135]  pgBlockQuote.Init(App) 
_banano_uoebananodemo_pgblockquote.init(self._app);
// [136]  Case {179} 
break;
case "" + "gott":
// [137]  pgTooltips.Init(App) 
_banano_uoebananodemo_pgtooltips.init(self._app);
// [138]  Case {180} 
break;
case "" + "gobc":
// [139]  pgBreadCrumbs.Init(App) 
_banano_uoebananodemo_pgbreadcrumbs.init(self._app);
// [140]  Case {181} 
break;
case "" + "gocards":
// [141]  pgCard.Init(App) 
_banano_uoebananodemo_pgcard.init(self._app);
// [142]  Case {182} 
break;
case "" + "gotabs":
// [143]  pgTabs.Init(App) 
_banano_uoebananodemo_pgtabs.init(self._app);
// [144]  End Select 
break;
}
// End Sub
};

// [148] Sub AddSideBar(pg As UOEPage) 
this.addsidebar= function(_pg) {
if (self==null) self=this;
// [149]  If pg = Null Then Return 
if (_pg == null) { return ;}
// [153]  pg.NavBar.Drawer.DrawerWidth = 350 
_pg._navbar._drawer._drawerwidth = 350;
// [155]  pg.NavBar.Drawer.AddUserView( {183} , {184} , {185} , {186} ) 
_pg._navbar._drawer.adduserview("UOEBANano","anele@mbangas.com","assets/sponge.png","assets/background.png");
// [156]  pg.NavBar.Drawer.AddHeader( {187} , {188} , {189} , {190} ,False, {191} , {192} , {193} ,True) 
_pg._navbar._drawer.addheader("components","","Components","",false,"","","",true);
// [160]  pg.NavBar.Drawer.AddHeaderItem1( {194} , {195} , {196} , {197} , {198} , {199} , {200} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gobuttons","","Buttons","button.html","","",true);
// [161]  pg.NavBar.Drawer.AddHeaderItem1( {201} , {202} , {203} , {204} , {205} , {206} , {207} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gobq","","BlockQuote","container.html","","",true);
// [162]  pg.NavBar.Drawer.AddHeaderItem1( {208} , {209} , {210} , {211} , {212} , {213} , {214} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gobc","","BreadCrumbs","breadcrumbs.html","","",true);
// [163]  pg.NavBar.Drawer.AddHeaderItem1( {215} , {216} , {217} , {218} , {219} , {220} , {221} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocards","","Cards","card.html","","",true);
// [164]  pg.NavBar.Drawer.AddHeaderItem1( {222} , {223} , {224} , {225} , {226} , {227} , {228} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocarousel","","Carousel","carousel.html","","",true);
// [165]  pg.NavBar.Drawer.AddHeaderItem1( {229} , {230} , {231} , {232} , {233} , {234} , {235} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocheckbox","","CheckBox","checkbox.html","","",true);
// [166]  pg.NavBar.Drawer.AddHeaderItem1( {236} , {237} , {238} , {239} , {240} , {241} , {242} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gochipx","","Chip","chip.html","","",true);
// [167]  pg.NavBar.Drawer.AddHeaderItem1( {243} , {244} , {245} , {246} , {247} , {248} , {249} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocollapse","","Collapsible","collapsible.html","","",true);
// [168]  pg.NavBar.Drawer.AddHeaderItem1( {250} , {251} , {252} , {253} , {254} , {255} , {256} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","godatetime","","DatePicker","datepicker.html","","",true);
// [169]  pg.NavBar.Drawer.AddHeaderItem1( {257} , {258} , {259} , {260} , {261} , {262} , {263} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","godropdown","","Dropdown","dropdown.html","","",true);
// [170]  pg.NavBar.Drawer.AddHeaderItem1( {264} , {265} , {266} , {267} , {268} , {269} , {270} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gofeature","","Feature","feature.html","","",true);
// [171]  pg.NavBar.Drawer.AddHeaderItem1( {271} , {272} , {273} , {274} , {275} , {276} , {277} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gofile","","File","file.html","","",true);
// [172]  pg.NavBar.Drawer.AddHeaderItem1( {278} , {279} , {280} , {281} , {282} , {283} , {284} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocopyrights","","Footer","copyrights.html","","",true);
// [173]  pg.NavBar.Drawer.AddHeaderItem1( {285} , {286} , {287} , {288} , {289} , {290} , {291} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gogrid","","Grid","copyrights.html","","",true);
// [174]  pg.NavBar.Drawer.AddHeaderItem1( {292} , {293} , {294} , {295} , {296} , {297} , {298} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goicons","","Icons","icon.html","","",true);
// [175]  pg.NavBar.Drawer.AddHeaderItem1( {299} , {300} , {301} , {302} , {303} , {304} , {305} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goimages","","Images","image.html","","",true);
// [176]  pg.NavBar.Drawer.AddHeaderItem1( {306} , {307} , {308} , {309} , {310} , {311} , {312} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","golabels","","Labels","badge.html","","",true);
// [177]  pg.NavBar.Drawer.AddHeaderItem1( {313} , {314} , {315} , {316} , {317} , {318} , {319} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","golist","","List","list.html","","",true);
// [178]  pg.NavBar.Drawer.AddHeaderItem1( {320} , {321} , {322} , {323} , {324} , {325} , {326} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gocollections","","ListView","collections.html","","",true);
// [179]  pg.NavBar.Drawer.AddHeaderItem1( {327} , {328} , {329} , {330} , {331} , {332} , {333} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gomodal","","Modal","modal.html","","",true);
// [180]  pg.NavBar.Drawer.AddHeaderItem1( {334} , {335} , {336} , {337} , {338} , {339} , {340} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gonavbar","","NavBar","nav.html","","",true);
// [181]  pg.NavBar.Drawer.AddHeaderItem1( {341} , {342} , {343} , {344} , {345} , {346} , {347} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gopagination","","Pagination","pagination.html","","",true);
// [182]  pg.NavBar.Drawer.AddHeaderItem1( {348} , {349} , {350} , {351} , {352} , {353} , {354} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goparallax","","Parallax","parallax.html","","",true);
// [183]  pg.NavBar.Drawer.AddHeaderItem1( {355} , {356} , {357} , {358} , {359} , {360} , {361} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gopreloader","","Preloader","preloader.html","","",true);
// [184]  pg.NavBar.Drawer.AddHeaderItem1( {362} , {363} , {364} , {365} , {366} , {367} , {368} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goprogress","","Progress","progress.html","","",true);
// [185]  pg.NavBar.Drawer.AddHeaderItem1( {369} , {370} , {371} , {372} , {373} , {374} , {375} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goradio","","Radio","radio.html","","",true);
// [186]  pg.NavBar.Drawer.AddHeaderItem1( {376} , {377} , {378} , {379} , {380} , {381} , {382} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gorange","","Range","range.html","","",true);
// [187]  pg.NavBar.Drawer.AddHeaderItem1( {383} , {384} , {385} , {386} , {387} , {388} , {389} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goselect","","Select","select.html","","",true);
// [188]  pg.NavBar.Drawer.AddHeaderItem1( {390} , {391} , {392} , {393} , {394} , {395} , {396} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goslider","","Slider","slider.html","","",true);
// [189]  pg.NavBar.Drawer.AddHeaderItem1( {397} , {398} , {399} , {400} , {401} , {402} , {403} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","goswitch","","Switch","switch.html","","",true);
// [190]  pg.NavBar.Drawer.AddHeaderItem1( {404} , {405} , {406} , {407} , {408} , {409} , {410} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","Table","","Table","table.html","","",true);
// [191]  pg.NavBar.Drawer.AddHeaderItem1( {411} , {412} , {413} , {414} , {415} , {416} , {417} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gotabs","","Tabs","tabs.html","","",true);
// [192]  pg.NavBar.Drawer.AddHeaderItem1( {418} , {419} , {420} , {421} , {422} , {423} , {424} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gotext","","Textbox & Textarea","tabs.html","","",true);
// [193]  pg.NavBar.Drawer.AddHeaderItem1( {425} , {426} , {427} , {428} , {429} , {430} , {431} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","gott","","ToolTip","tooltip.html","","",true);
// [194]  pg.NavBar.Drawer.AddHeaderItem1( {432} , {433} , {434} , {435} , {436} , {437} , {438} ,True) 
_pg._navbar._drawer.addheaderitem1("Components","govideo","","Video","video.html","","",true);
// [197]  pg.NavBar.Drawer.AddHeader( {439} , {440} , {441} , {442} ,False, {443} , {444} , {445} ,True) 
_pg._navbar._drawer.addheader("downloads","","Downloads","",false,"","","",true);
// [198]  pg.NavBar.Drawer.AddHeaderItem( {446} , {447} , {448} , {449} , {450} , {451} ,False,True, {452} , {453} ) 
_pg._navbar._drawer.addheaderitem("downloads","getb4j","","B4J","https://www.idevaffiliate.com/33168/74.html","",false,true,"","");
// [199]  pg.NavBar.Drawer.AddHeaderItem( {454} , {455} , {456} , {457} , {458} , {459} ,False,True, {460} , {461} ) 
_pg._navbar._drawer.addheaderitem("downloads","lib","","UOEBANano on GitHub","https://github.com/Mashiane/UOEBANano","",false,true,"","");
// [200]  pg.NavBar.Drawer.AddHeaderItem( {462} , {463} , {464} , {465} , {466} , {467} ,False,True, {468} , {469} ) 
_pg._navbar._drawer.addheaderitem("downloads","getmaterial","","Learn Materialize","https://materializecss.com/","",false,true,"","");
// [202]  pg.HasCopyright = True 
_pg._hascopyright = true;
// [203]  pg.FixedFooter = True 
_pg._fixedfooter = true;
// [204]  pg.HasFooter = True 
_pg._hasfooter = true;
// [205]  pg.Footer.CenterInPage = False 
_pg._footer._centerinpage = false;
// [206]  pg.Footer.Theme = App.Theme 
_pg._footer._theme = self._app._theme;
// [207]  pg.footer.AddRowsM(1,0,0, {470} , {471} ).AddColumnsSP(1,12,12,12,0,0, {472} , {473} ) 
_pg._footer.addrowsm(1,0,0,"","").addcolumnssp(1,12,12,12,0,0,"","");
// [208]  pg.Footer.AddParagraph(1,1, {474} , {475} , {476} , {477} ) 
_pg._footer.addparagraph(1,1,"","UOEBANano is being developed using B4J from Anywhere Software for BANano by Mashy","","");
// End Sub
};

}
// =========================== pgIndex  ===========================
function banano_uoebananodemo_pgindex() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _lbl;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Labels",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [16]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  Page.Content.AddH1(1,1, {10} , {11} , {12} , {13} ) 
self._page._content.addh1(1,1,"h1","H1...","","");
// [19]  Page.Content.AddH2(1,1, {14} , {15} , {16} , {17} ) 
self._page._content.addh2(1,1,"h2","H2...","","");
// [20]  Page.Content.AddH3(1,1, {18} , {19} , {20} , {21} ) 
self._page._content.addh3(1,1,"h3","H3...","","");
// [21]  Page.Content.AddH4(1,1, {22} , {23} , {24} , {25} ) 
self._page._content.addh4(1,1,"h4","H4...","","");
// [22]  Page.Content.AddH5(1,1, {26} , {27} , {28} , {29} ) 
self._page._content.addh5(1,1,"h5","H5...","","");
// [23]  Page.Content.AddH6(1,1, {30} , {31} , {32} , {33} ) 
self._page._content.addh6(1,1,"h6","H6...","","");
// [24]  Page.Content.AddDivider(1,1, {34} ) 
self._page._content.adddivider(1,1,"");
// [27]  Dim lbl As UOELabel 
_lbl= new banano_uoebanano_uoelabel();
// [28]  lbl.Initialize(App, {35} , {36} , {37} , {38} , {39} ) 
_lbl.initialize(self._app,"lbl1","p","Paragraph 1{NBSP}","","");
// [29]  lbl.AddItalic( {40} ) 
_lbl.additalic("Italic{NBSP}");
// [30]  lbl.AddUnderline( {41} ) 
_lbl.addunderline("This is underlined{NBSP}");
// [31]  lbl.AddMailTo( {42} , {43} , {44} ) 
_lbl.addmailto("anele@mbangas.com","UOE","Email Me");
// [32]  lbl.AddSubScript( {45} ) 
_lbl.addsubscript("{NBSP}Subscript");
// [33]  lbl.AddBold( {46} ) 
_lbl.addbold("{NBSP}Something Bold");
// [34]  lbl.AddSuperScript( {47} ) 
_lbl.addsuperscript("{NBSP}Super Script");
// [35]  lbl.AddText( {48} ) 
_lbl.addtext("{NBSP}Click{NBSP}");
// [36]  lbl.AddLink( {49} , {50} ) 
_lbl.addlink("http://google.com","here");
// [37]  lbl.AddText( {51} ) 
_lbl.addtext("{NBSP}to go to Google.");
// [38]  Page.Content.AddLabel(1,1,lbl) 
self._page._content.addlabel(1,1,_lbl);
// [41]  Page.Content.AddHiddenParagraph(1,1, {52} , {53} ) 
self._page._content.addhiddenparagraph(1,1,"hideit","Hidden Paragraph");
// [42]  Page.Content.AddLink(1,1, {54} , {55} , {56} ) 
self._page._content.addlink(1,1,"","Anywhere Software","http://www.b4x.com");
// [43]  Page.Content.AddParagraph(1,1, {57} , {58} ,App.EnumThemes.warntext, {59} ) 
self._page._content.addparagraph(1,1,"ptext1","Warning",self._app._enumthemes._warntext,"");
// [44]  Page.Content.AddParagraph(1,1, {60} , {61} ,App.EnumThemes.dangertext, {62} ) 
self._page._content.addparagraph(1,1,"ptext2","Danger",self._app._enumthemes._dangertext,"");
// [45]  Page.Content.AddParagraph(1,1, {63} , {64} ,App.EnumThemes.defaulttext, {65} ) 
self._page._content.addparagraph(1,1,"ptext3","Default",self._app._enumthemes._defaulttext,"");
// [46]  Page.Content.AddParagraph(1,1, {66} , {67} ,App.EnumThemes.infotext, {68} ) 
self._page._content.addparagraph(1,1,"ptext4","Info",self._app._enumthemes._infotext,"");
// [47]  Page.Content.AddParagraph(1,1, {69} , {70} ,App.EnumThemes.mutedtext, {71} ) 
self._page._content.addparagraph(1,1,"ptext5","Muted",self._app._enumthemes._mutedtext,"");
// [48]  Page.Content.AddParagraph(1,1, {72} , {73} ,App.EnumThemes.primarytext, {74} ) 
self._page._content.addparagraph(1,1,"ptext6","Primary",self._app._enumthemes._primarytext,"");
// [49]  Page.Content.AddParagraph(1,1, {75} , {76} ,App.EnumThemes.successtext, {77} ) 
self._page._content.addparagraph(1,1,"ptext7","Success",self._app._enumthemes._successtext,"");
// [52]  Page.Create( {78} , Me) 
self._page.create("labelEvents",self);
// [54]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [57] Sub labelEvents(event As BANanoEvent) 
this.labelevents= function(_event) {
if (self==null) self=this;
// [58]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// End Sub
};

}
// =========================== pgCard  ===========================
function banano_uoebananodemo_pgcard() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _nc;
var _nc1;
var _nc2;
var _nc3;
var _nc4;
var _nc5;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Cards",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} ,App.EnumColor.BLUEGREY, {13} ) 
self._app.addtheme("transparent.bluegrey","transparent","",self._app._enumcolor._bluegrey,"");
// [20]  App.AddTheme( {14} , {15} , {16} , {17} , {18} ) 
self._app.addtheme("white.transparent","white","","transparent","");
// [21]  App.AddTheme( {19} , {20} , {21} , {22} , {23} ) 
self._app.addtheme("black.transparent","black","","transparent","");
// [23]  Dim nc As UOECard 
_nc= new banano_uoebanano_uoecard();
// [24]  nc.Initialize(App, {24} , {25} ,App.EnumCardType.Basic, {26} , {27} ) 
_nc.initialize(self._app,"nc","assets/2.jpg",self._app._enumcardtype._basic,"transparent.bluegrey","white.transparent");
// [25]  nc.SetSizes(4,4,4) 
_nc.setsizes(4,4,4);
// [26]  nc.AddTitle( {28} , {29} , {30} ) 
_nc.addtitle("Card Title","white.transparent","");
// [27]  nc.AddParagraph( {31} , {32} , {33} ) 
_nc.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [28]  nc.AddAction( {34} , {35} , {36} ) 
_nc.addaction("act1","Action 1","#");
// [29]  nc.AddAction( {37} , {38} , {39} ) 
_nc.addaction("act2","Action 2","#");
// [30]  Page.Content.AddCard(1,1,nc) 
self._page._content.addcard(1,1,_nc);
// [32]  Dim nc1 As UOECard 
_nc1= new banano_uoebanano_uoecard();
// [33]  nc1.Initialize(App, {40} , {41} ,App.EnumCardType.Image, {42} , {43} ) 
_nc1.initialize(self._app,"nc1","assets/3.jpg",self._app._enumcardtype._image,"","");
// [34]  nc1.SetSizes(4,4,4) 
_nc1.setsizes(4,4,4);
// [35]  nc1.AddTitle( {44} , {45} , {46} ) 
_nc1.addtitle("Card Title","white.transparent","");
// [36]  nc1.AddParagraph( {47} , {48} , {49} ) 
_nc1.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [37]  nc1.AddAction( {50} , {51} , {52} ) 
_nc1.addaction("act1","Action 1","#");
// [38]  Page.Content.AddCard(1,1,nc1) 
self._page._content.addcard(1,1,_nc1);
// [41]  Dim nc2 As UOECard 
_nc2= new banano_uoebanano_uoecard();
// [42]  nc2.Initialize(App, {53} , {54} ,App.EnumCardType.Image, {55} , {56} ) 
_nc2.initialize(self._app,"nc2","assets/4.jpg",self._app._enumcardtype._image,"","");
// [43]  nc2.SetSizes(4,4,4) 
_nc2.setsizes(4,4,4);
// [44]  nc2.AddTitle( {57} , {58} , {59} ) 
_nc2.addtitle("Card Title","black.transparent","");
// [45]  nc2.AddParagraph( {60} , {61} , {62} ) 
_nc2.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [46]  nc2.AddFAB( {63} , {64} , {65} ,App.EnumButtonSize.large, {66} ) 
_nc2.addfab("add","mdi-add","",self._app._enumbuttonsize._large,"white.red");
// [47]  nc2.AddAction( {67} , {68} , {69} ) 
_nc2.addaction("act1","Action 1","#");
// [48]  Page.Content.AddCard(1,1,nc2) 
self._page._content.addcard(1,1,_nc2);
// [51]  Dim nc3 As UOECard 
_nc3= new banano_uoebanano_uoecard();
// [52]  nc3.Initialize(App, {70} , {71} ,App.EnumCardType.Image, {72} , {73} ) 
_nc3.initialize(self._app,"nc3","assets/yuna.jpg",self._app._enumcardtype._image,"","");
// [53]  nc3.SetSizes(6,6,6) 
_nc3.setsizes(6,6,6);
// [54]  nc3.Horizontal = True 
_nc3._horizontal = true;
// [55]  nc3.AddTitle( {74} , {75} , {76} ) 
_nc3.addtitle("Horizontal Card","black.transparent","");
// [56]  nc3.AddParagraph( {77} , {78} , {79} ) 
_nc3.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [57]  nc3.AddAction( {80} , {81} , {82} ) 
_nc3.addaction("act1","This is a link","#");
// [58]  Page.Content.AddCard(1,1,nc3) 
self._page._content.addcard(1,1,_nc3);
// [60]  Dim nc4 As UOECard 
_nc4= new banano_uoebanano_uoecard();
// [61]  nc4.Initialize(App, {83} , {84} ,App.EnumCardType.Reveal, {85} , {86} ) 
_nc4.initialize(self._app,"nc4","assets/39.jpg",self._app._enumcardtype._reveal,"","");
// [62]  nc4.SetSizes(6,6,6) 
_nc4.setsizes(6,6,6);
// [63]  nc4.AddTitle( {87} , {88} , {89} ) 
_nc4.addtitle("Reveal Card","black.transparent","");
// [64]  nc4.AddParagraph( {90} , {91} , {92} ) 
_nc4.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [65]  nc4.AddLink( {93} , {94} , {95} ) 
_nc4.addlink("act1","This is a link","#");
// [66]  Page.Content.AddCard(1,1,nc4) 
self._page._content.addcard(1,1,_nc4);
// [68]  Dim nc5 As UOECard 
_nc5= new banano_uoebanano_uoecard();
// [69]  nc5.Initialize(App, {96} , {97} ,App.EnumCardType.Basic, {98} , {99} ) 
_nc5.initialize(self._app,"nc5","assets/background.png",self._app._enumcardtype._basic,"","");
// [70]  nc5.SetSizes(12,12,12) 
_nc5.setsizes(12,12,12);
// [71]  nc5.AddTitle( {100} , {101} , {102} ) 
_nc5.addtitle("Card Title","","");
// [72]  nc5.AddParagraph( {103} , {104} , {105} ) 
_nc5.addparagraph("I am a very simple card. I am good at containing small bits of information. I am convenient because I require little markup To use effectively.","","");
// [73]  nc5.AddTab( {106} , {107} ,False,Null) 
_nc5.addtab("first","Tab 1",false,null);
// [74]  nc5.AddTab( {108} , {109} ,False,Null) 
_nc5.addtab("second","Tab 2",false,null);
// [75]  nc5.AddTab( {110} , {111} ,False,Null) 
_nc5.addtab("third","Tab 3",false,null);
// [76]  Page.Content.AddCard(1,1,nc5) 
self._page._content.addcard(1,1,_nc5);
// [78]  Page.Create( {112} , Me) 
self._page.create("cardEvents",self);
// [80]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [83] Sub cardEvents(event As BANanoEvent) 
this.cardevents= function(_event) {
if (self==null) self=this;
// [84]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [85]  Log(event.ID) 
console.log(_event.target.id);
// [86]  Select Case App.MvField(event.ID,1, {113} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [87]  End Select 
}
// End Sub
};

}
// =========================== pgNavigation  ===========================
function banano_uoebananodemo_pgnavigation() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _nav;
var _lal;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Navigation",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Page.NavBar.AddIcon( {10} , {11} , {12} ,False,App.EnumAlignment.right, App.EnumVisibility.visible, {13} ) 
self._page._navbar.addicon("dp1","mdi-search","#",false,self._app._enumalignment._right,self._app._enumvisibility._visible,"red");
// [21]  Page.NavBar.AddIcon( {14} , {15} , {16} ,False,App.EnumAlignment.right, App.EnumVisibility.visible, {17} ) 
self._page._navbar.addicon("dp2","mdi-view_module","#",false,self._app._enumalignment._right,self._app._enumvisibility._visible,"yellow");
// [22]  Page.NavBar.AddIcon( {18} , {19} , {20} ,False,App.EnumAlignment.right, App.EnumVisibility.visible, {21} ) 
self._page._navbar.addicon("dp3","mdi-refresh","#",false,self._app._enumalignment._right,self._app._enumvisibility._visible,"white");
// [23]  Page.NavBar.AddIcon( {22} , {23} , {24} ,False,App.EnumAlignment.right, App.EnumVisibility.visible, {25} ) 
self._page._navbar.addicon("dp4","mdi-more_vert","#",false,self._app._enumalignment._right,self._app._enumvisibility._visible,"orange");
// [24]  Page.NavBar.AddIconBadge( {26} , {27} , {28} ,False, App.EnumAlignment.Right,App.EnumVisibility.visible, {29} , {30} ) 
self._page._navbar.addiconbadge("dp5","fa-address-card","#",false,self._app._enumalignment._right,self._app._enumvisibility._visible,"","10");
// [27]  Dim nav As UOENavBar 
_nav= new banano_uoebanano_uoenavbar();
// [28]  nav.Initialize(App, {31} , {32} ,App.enumLogoposition.Left,False,False, {33} ) 
_nav.initialize(self._app,"navx","Navigation Bar",self._app._enumlogoposition._left,false,false,"");
// [29]  nav.RightMenuVisibility = Page.App.EnumVisibility.hideonmedanddown 
_nav._rightmenuvisibility = self._page._app._enumvisibility._hideonmedanddown;
// [30]  nav.AddItem( {34} , {35} , {36} , {37} ,Page.App.EnumMenuPos.Right,False, {38} ) 
_nav.additem("sass","","Sass","",self._page._app._enummenupos._right,false,"");
// [31]  nav.AddItem( {39} , {40} , {41} , {42} ,Page.App.EnumMenuPos.Right,False, {43} ) 
_nav.additem("components","","Components","",self._page._app._enummenupos._right,false,"");
// [32]  nav.AddItem( {44} , {45} , {46} , {47} ,Page.App.EnumMenuPos.Right,False, {48} ) 
_nav.additem("js","","JavaScript","",self._page._app._enummenupos._right,false,"");
// [33]  nav.ShowMenuOnLarge = False 
_nav._showmenuonlarge = false;
// [35]  Page.Content.AddNavBar(1,1,nav) 
self._page._content.addnavbar(1,1,_nav);
// [36]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [39]  Dim lal As UOENavBar 
_lal= new banano_uoebanano_uoenavbar();
// [40]  lal.Initialize(App, {54} , {55} ,App.EnumLogoposition.Right,False,False, {56} ) 
_lal.initialize(self._app,"lal","Left Aligned Links",self._app._enumlogoposition._right,false,false,"");
// [41]  lal.LeftMenuVisibility = Page.App.EnumVisibility.hideonmedanddown 
_lal._leftmenuvisibility = self._page._app._enumvisibility._hideonmedanddown;
// [42]  lal.ShowMenuOnLarge = False 
_lal._showmenuonlarge = false;
// [43]  lal.AddItem( {57} , {58} , {59} , {60} ,Page.App.EnumMenuPos.Left,False, {61} ) 
_lal.additem("sass","","Sass","",self._page._app._enummenupos._left,false,"");
// [44]  lal.AddItem( {62} , {63} , {64} , {65} ,Page.App.EnumMenuPos.Left,False, {66} ) 
_lal.additem("cpt","","Components","",self._page._app._enummenupos._left,false,"");
// [45]  lal.AddItem( {67} , {68} , {69} , {70} ,Page.App.EnumMenuPos.Left,False, {71} ) 
_lal.additem("js","","JavaScript","",self._page._app._enummenupos._left,false,"");
// [46]  lal.AddDropDown( {72} , {73} , {74} ,Page.App.EnumMenuPos.Left,False,False,True,False, {75} ) 
_lal.adddropdown("dd","Drop Down","",self._page._app._enummenupos._left,false,false,true,false,"");
// [47]  lal.AddDropDownItem( {76} , {77} , {78} , {79} , {80} , {81} ) 
_lal.adddropdownitem("dd","one","","One","","");
// [48]  lal.AddDropDownItem( {82} , {83} , {84} , {85} , {86} , {87} ) 
_lal.adddropdownitem("dd","two","","Two","","");
// [49]  lal.AddDropDownItem( {88} , {89} , {90} , {91} , {92} , {93} ) 
_lal.adddropdownitem("dd","three","","Three","","");
// [50]  lal.AddDropDownDivider( {94} ) 
_lal.adddropdowndivider("dd");
// [51]  lal.AddDropDownItem( {95} , {96} , {97} , {98} , {99} , {100} ) 
_lal.adddropdownitem("dd","four","","Four","","");
// [52]  Page.Content.AddNavBar(1,1,lal) 
self._page._content.addnavbar(1,1,_lal);
// [55]  Page.Create( {101} , Me) 
self._page.create("navEvents",self);
// [57]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [60] Sub navEvents(event As BANanoEvent) 
this.navevents= function(_event) {
if (self==null) self=this;
// [61]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [62]  Select Case App.MvField(event.ID,1, {102} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [63]  End Select 
}
// End Sub
};

}
// =========================== pgFeature  ===========================
function banano_uoebananodemo_pgfeature() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

this._feat= new banano_uoebanano_uoefeature();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _fab;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Feature",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [18]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  App.AddTheme( {10} ,App.EnumColor.WHITE, {11} ,App.EnumColor.CYAN, {12} ) 
self._app.addtheme("whitecyan",self._app._enumcolor._white,"",self._app._enumcolor._cyan,"");
// [22]  feat.Initialize(App, {13} , {14} , {15} , {16} , {17} ) 
self._feat.initialize(self._app,"feat","Whats New","Some new products have been developed and are coming out soon...","whitecyan","fab");
// [23]  Page.Content.AddFeature(feat) 
self._page._content.addfeature(self._feat);
// [26]  Dim fab As UOEFAB 
_fab= new banano_uoebanano_uoefab();
// [27]  fab.Initialize(App, {18} , {19} , {20} , App.EnumButtonSize.LARGE, {21} , {22} ) 
_fab.initialize(self._app,"fab","","mdi-menu",self._app._enumbuttonsize._large,"","whitecyan");
// [28]  Page.Content.AddFAB(fab) 
self._page._content.addfab(_fab);
// [32]  Page.Create( {23} , Me) 
self._page.create("featureEvents",self);
// [34]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [37] Sub featureEvents(event As BANanoEvent) 
this.featureevents= function(_event) {
if (self==null) self=this;
// [38]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [39]  Log(event.ID) 
console.log(_event.target.id);
// [40]  Select Case App.MvField(event.ID,1, {24} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [41]  Case {25} 
case "" + "fab":
// [42]  feat.Open 
self._feat.open();
// [43]  End Select 
break;
}
// End Sub
};

}
// =========================== pgTooltips  ===========================
function banano_uoebananodemo_pgtooltips() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"ToolTips",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [18]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Page.AddTooltip( {10} , {11} ,App.EnumTooltipPos.Right,50) 
self._page.addtooltip("btnFloating1","New document...",self._app._enumtooltippos._right,50);
// [21]  Page.content.AddFloatingButton(1,1, {12} , {13} , {14} , {15} ,App.EnumThemes.info, {16} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating1","mdi-add","","#",self._app._enumthemes._info,"");
// [22]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [24]  Page.AddTooltip( {17} , {18} ,App.EnumTooltipPos.Left,50) 
self._page.addtooltip("btnFloating2","Insert chart...",self._app._enumtooltippos._left,50);
// [25]  Page.content.AddFloatingButton(1,1, {19} , {20} , {21} , {22} ,App.EnumThemes.danger, {23} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating2","mdi-insert_chart","","#",self._app._enumthemes._danger,"");
// [26]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [28]  Page.AddTooltip( {24} , {25} ,App.EnumTooltipPos.Top,50) 
self._page.addtooltip("btnFloating3","Format quote...",self._app._enumtooltippos._top,50);
// [29]  Page.content.AddFloatingButton(1,1, {26} , {27} , {28} , {29} ,App.EnumThemes.warn, {30} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating3","mdi-format_quote","","#",self._app._enumthemes._warn,"");
// [30]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [32]  Page.AddTooltip( {31} , {32} ,App.EnumTooltipPos.Bottom,50) 
self._page.addtooltip("btnFloating4","Publish...",self._app._enumtooltippos._bottom,50);
// [33]  Page.content.AddFloatingButton(1,1, {33} , {34} , {35} , {36} ,App.EnumThemes.muted, {37} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating4","mdi-publish","","#",self._app._enumthemes._muted,"");
// [34]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [36]  Page.AddTooltip( {38} , {39} ,App.EnumTooltipPos.Right,50) 
self._page.addtooltip("btnFloating5","Attach file...",self._app._enumtooltippos._right,50);
// [37]  Page.content.AddFloatingButton(1,1, {40} , {41} , {42} , {43} ,App.EnumThemes.primary, {44} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating5","mdi-attach_file","","#",self._app._enumthemes._primary,"");
// [38]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [40]  Page.Create( {45} , Me) 
self._page.create("ttButtons",self);
// [42]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [46] Sub ttButtons(event As BANanoEvent) 
this.ttbuttons= function(_event) {
if (self==null) self=this;
// [47]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [48]  Log(event.ID) 
console.log(_event.target.id);
// [49]  Select Case App.MvField(event.ID,1, {46} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [51]  End Select 
}
// End Sub
};

}
// =========================== pgBreadCrumbs  ===========================
function banano_uoebananodemo_pgbreadcrumbs() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _bcx;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"BreadCrumbs",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [16]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  Dim bcx As UOEBreadCrumbs 
_bcx= new banano_uoebanano_uoebreadcrumbs();
// [19]  bcx.Initialize(App, {10} ,App.EnumThemes.default) 
_bcx.initialize(self._app,"bcx",self._app._enumthemes._default);
// [20]  bcx.AddButton( {11} , {12} , {13} ) 
_bcx.addbutton("grid","BM Grid","#");
// [21]  bcx.AddButton( {14} , {15} , {16} ) 
_bcx.addbutton("labels","BM Labels","#");
// [22]  bcx.AddButton( {17} , {18} , {19} ) 
_bcx.addbutton("butons","BM Button","#");
// [23]  Page.Content.AddBreadCrumbs(1,1,bcx) 
self._page._content.addbreadcrumbs(1,1,_bcx);
// [24]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [26]  Dim bcx As UOEBreadCrumbs 
_bcx= new banano_uoebanano_uoebreadcrumbs();
// [27]  bcx.Initialize(App, {20} ,App.EnumThemes.warn) 
_bcx.initialize(self._app,"bcx1",self._app._enumthemes._warn);
// [28]  bcx.AddButton( {21} , {22} , {23} ) 
_bcx.addbutton("grid1","BM Grid","#");
// [29]  bcx.AddButton( {24} , {25} , {26} ) 
_bcx.addbutton("labels1","BM Labels","#");
// [30]  bcx.AddButton( {27} , {28} , {29} ) 
_bcx.addbutton("butons1","BM Button","#");
// [31]  Page.Content.AddBreadCrumbs(1,1,bcx) 
self._page._content.addbreadcrumbs(1,1,_bcx);
// [32]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [34]  Dim bcx As UOEBreadCrumbs 
_bcx= new banano_uoebanano_uoebreadcrumbs();
// [35]  bcx.Initialize(App, {30} ,App.EnumThemes.danger) 
_bcx.initialize(self._app,"bcx2",self._app._enumthemes._danger);
// [36]  bcx.AddButton( {31} , {32} , {33} ) 
_bcx.addbutton("grid2","BM Grid","#");
// [37]  bcx.AddButton( {34} , {35} , {36} ) 
_bcx.addbutton("labels2","BM Labels","#");
// [38]  bcx.AddButton( {37} , {38} , {39} ) 
_bcx.addbutton("butons2","BM Button","#");
// [39]  Page.Content.AddBreadCrumbs(1,1,bcx) 
self._page._content.addbreadcrumbs(1,1,_bcx);
// [40]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [42]  Dim bcx As UOEBreadCrumbs 
_bcx= new banano_uoebanano_uoebreadcrumbs();
// [43]  bcx.Initialize(App, {40} ,App.EnumThemes.muted) 
_bcx.initialize(self._app,"bcx3",self._app._enumthemes._muted);
// [44]  bcx.AddButton( {41} , {42} , {43} ) 
_bcx.addbutton("grid3","BM Grid","#");
// [45]  bcx.AddButton( {44} , {45} , {46} ) 
_bcx.addbutton("labels3","BM Labels","#");
// [46]  bcx.AddButton( {47} , {48} , {49} ) 
_bcx.addbutton("butons3","BM Button","#");
// [47]  Page.Content.AddBreadCrumbs(1,1,bcx) 
self._page._content.addbreadcrumbs(1,1,_bcx);
// [48]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [50]  Dim bcx As UOEBreadCrumbs 
_bcx= new banano_uoebanano_uoebreadcrumbs();
// [51]  bcx.Initialize(App, {50} ,App.EnumThemes.success) 
_bcx.initialize(self._app,"bcx4",self._app._enumthemes._success);
// [52]  bcx.AddButton( {51} , {52} , {53} ) 
_bcx.addbutton("grid4","BM Grid","#");
// [53]  bcx.AddButton( {54} , {55} , {56} ) 
_bcx.addbutton("labels4","BM Labels","#");
// [54]  bcx.AddButton( {57} , {58} , {59} ) 
_bcx.addbutton("butons4","BM Button","#");
// [55]  Page.Content.AddBreadCrumbs(1,1,bcx) 
self._page._content.addbreadcrumbs(1,1,_bcx);
// [56]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [59]  Page.Create( {60} , Me) 
self._page.create("collapsibleEvents",self);
// [61]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [64] Sub collapsibleEvents(event As BANanoEvent) 
this.collapsibleevents= function(_event) {
if (self==null) self=this;
// [65]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// End Sub
};

}
// =========================== pgTabs  ===========================
function banano_uoebananodemo_pgtabs() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _tabs;
var _testcont;
var _testcont1;
var _testcont2;
var _testcont3;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Tabs",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim tabs As UOETabs 
_tabs= new banano_uoebanano_uoetabs();
// [21]  tabs.Initialize(App, {10} ,True, {11} , {12} ) 
_tabs.initialize(self._app,"tabs1",true,"","");
// [23]  Dim testCont As UOEContainer 
_testcont= new banano_uoebanano_uoecontainer();
// [24]  testCont.Initialize(App, {13} ,False, {14} ) 
_testcont.initialize(self._app,"testcont",false,"white.red");
// [25]  testCont.AddRows(5, {15} , {16} ).AddColumnsSP(1,12,12,12,0,0, {17} , {18} ) 
_testcont.addrows(5,"","").addcolumnssp(1,12,12,12,0,0,"","");
// [26]  testCont.AddParagraph(2,1, {19} , {20} , {21} , {22} ) 
_testcont.addparagraph(2,1,"p1","Nice here","","");
// [28]  Dim testCont1 As UOEContainer 
_testcont1= new banano_uoebanano_uoecontainer();
// [29]  testCont1.Initialize(App, {23} ,False, {24} ) 
_testcont1.initialize(self._app,"test1cont",false,"white.blue");
// [30]  testCont1.AddRows(5, {25} , {26} ).AddColumnsSP(1,12,12,12,0,0, {27} , {28} ) 
_testcont1.addrows(5,"","").addcolumnssp(1,12,12,12,0,0,"","");
// [31]  testCont1.AddParagraph(2,1, {29} , {30} , {31} , {32} ) 
_testcont1.addparagraph(2,1,"p2","Tab 2","","");
// [33]  Dim testCont2 As UOEContainer 
_testcont2= new banano_uoebanano_uoecontainer();
// [34]  testCont2.Initialize(App, {33} ,False, {34} ) 
_testcont2.initialize(self._app,"test2cont",false,"white.orange");
// [35]  testCont2.AddRows(5, {35} , {36} ).AddColumnsSP(1,12,12,12,0,0, {37} , {38} ) 
_testcont2.addrows(5,"","").addcolumnssp(1,12,12,12,0,0,"","");
// [36]  testCont2.AddParagraph(2,1, {39} , {40} , {41} , {42} ) 
_testcont2.addparagraph(2,1,"p3","Tab X","","");
// [38]  Dim testCont3 As UOEContainer 
_testcont3= new banano_uoebanano_uoecontainer();
// [39]  testCont3.Initialize(App, {43} ,False, {44} ) 
_testcont3.initialize(self._app,"test3cont",false,"white.green");
// [40]  testCont3.AddRows(5, {45} , {46} ).AddColumnsSP(1,12,12,12,0,0, {47} , {48} ) 
_testcont3.addrows(5,"","").addcolumnssp(1,12,12,12,0,0,"","");
// [41]  testCont3.AddParagraph(2,1, {49} , {50} , {51} , {52} ) 
_testcont3.addparagraph(2,1,"p4","Tab Z","","");
// [43]  tabs.AddTab( {53} , {54} ,True,False,3,3,3,testCont) 
_tabs.addtab("test1","Test 1",true,false,3,3,3,_testcont);
// [44]  tabs.AddTab( {55} , {56} ,False,False,3,3,3,testCont1) 
_tabs.addtab("test2","Test 2",false,false,3,3,3,_testcont1);
// [45]  tabs.AddTab( {57} , {58} ,False,True,3,3,3,testCont2) 
_tabs.addtab("test3","Test 3",false,true,3,3,3,_testcont2);
// [46]  tabs.AddTab( {59} , {60} ,False,False,3,3,3,testCont3) 
_tabs.addtab("test4","Test 4",false,false,3,3,3,_testcont3);
// [47]  Page.Content.AddTabs(1,1,tabs) 
self._page._content.addtabs(1,1,_tabs);
// [50]  Page.Create( {61} , Me) 
self._page.create("tabEvents",self);
// [52]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [56] Sub tabEvents(event As BANanoEvent) 
this.tabevents= function(_event) {
if (self==null) self=this;
// [57]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [58]  Select Case App.MvField(event.ID,1, {62} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [59]  End Select 
}
// End Sub
};

}
// =========================== pgcarousel  ===========================
function banano_uoebananodemo_pgcarousel() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._carousel= new banano_uoebanano_uoecarousel();

this._page= new banano_uoebanano_uoepage();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _carousel1;
var _slide0;
var _slide1;
var _carousel2;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Carousel",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [18]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  carousel.Initialize(App, {10} ) 
self._carousel.initialize(self._app,"car1");
// [20]  carousel.AddSlide( {11} , {12} , {13} ) 
self._carousel.addslide("","#one!","assets/1.jpg");
// [21]  carousel.AddSlide( {14} , {15} , {16} ) 
self._carousel.addslide("","#two!","assets/2.jpg");
// [22]  carousel.AddSlide( {17} , {18} , {19} ) 
self._carousel.addslide("","#three!","assets/3.jpg");
// [23]  carousel.AddSlide( {20} , {21} , {22} ) 
self._carousel.addslide("","#four!","assets/4.jpg");
// [24]  carousel.AddSlide( {23} , {24} , {25} ) 
self._carousel.addslide("","#five!","assets/5.jpg");
// [26]  Page.AddToolTip( {26} , {27} ,App.EnumTooltipPos.Top,50) 
self._page.addtooltip("btnPrev","Move to the previous slide",self._app._enumtooltippos._top,50);
// [27]  Page.content.AddFloatingButton(1,1, {28} , {29} , {30} , {31} , {32} , {33} ) 
self._page._content.addfloatingbutton(1,1,"btnPrev","mdi-arrow_back","","","","");
// [29]  Page.AddToolTip( {34} , {35} ,App.EnumTooltipPos.Top,50) 
self._page.addtooltip("btnNext","Move to the next slide",self._app._enumtooltippos._top,50);
// [30]  Page.content.AddFloatingButton(1,1, {36} , {37} , {38} , {39} , {40} , {41} ) 
self._page._content.addfloatingbutton(1,1,"btnNext","mdi-arrow_forward","","","","");
// [32]  Page.AddToolTip( {42} , {43} ,App.EnumTooltipPos.Top,50) 
self._page.addtooltip("btn3","Go to slide 3",self._app._enumtooltippos._top,50);
// [33]  Page.content.AddRaisedButton(1,1, {44} , {45} , {46} , {47} , {48} , {49} ) 
self._page._content.addraisedbutton(1,1,"btn3","Slide 3","","","","");
// [35]  Page.content.AddCarousel(1,1,carousel) 
self._page._content.addcarousel(1,1,self._carousel);
// [37]  Dim carousel1 As UOECarousel 
_carousel1= new banano_uoebanano_uoecarousel();
// [38]  carousel1.Initialize(App, {50} ) 
_carousel1.initialize(self._app,"car0");
// [39]  carousel1.AddSlide( {51} , {52} , {53} ) 
_carousel1.addslide("","#one!","assets/1.jpg");
// [40]  carousel1.AddSlide( {54} , {55} , {56} ) 
_carousel1.addslide("","#two!","assets/2.jpg");
// [41]  carousel1.AddSlide( {57} , {58} , {59} ) 
_carousel1.addslide("","#three!","assets/3.jpg");
// [42]  carousel1.AddSlide( {60} , {61} , {62} ) 
_carousel1.addslide("","#four!","assets/4.jpg");
// [43]  carousel1.AddSlide( {63} , {64} , {65} ) 
_carousel1.addslide("","#five!","assets/5.jpg");
// [44]  carousel1.IsSlider = True 
_carousel1._isslider = true;
// [45]  carousel1.FullWidth = True 
_carousel1._fullwidth = true;
// [46]  carousel1.Indicators = True 
_carousel1._indicators = true;
// [47]  Page.content.AddCarousel(1,1,carousel1) 
self._page._content.addcarousel(1,1,_carousel1);
// [49]  App.AddTheme( {66} , {67} , {68} , {69} , {70} ) 
self._app.addtheme("transparent.green","transparent","","green","");
// [50]  App.AddTheme( {71} , {72} , {73} , {74} , {75} ) 
self._app.addtheme("transparent.yellow","transparent","","yellow","");
// [52]  Dim slide0 As UOEContainer 
_slide0= new banano_uoebanano_uoecontainer();
// [53]  slide0.Initialize(App, {76} ,False, {77} ) 
_slide0.initialize(self._app,"slide0",false,"transparent.green");
// [54]  slide0.AddRows(5, {78} , {79} ).AddColumns12(1, {80} , {81} ) 
_slide0.addrows(5,"","").addcolumns12(1,"","");
// [55]  slide0.AddParagraph(1,1, {82} , {83} , {84} , {85} ) 
_slide0.addparagraph(1,1,"p1","This is slide 1","black.transparent","");
// [57]  Dim slide1 As UOEContainer 
_slide1= new banano_uoebanano_uoecontainer();
// [58]  slide1.Initialize(App, {86} ,False, {87} ) 
_slide1.initialize(self._app,"slide1",false,"transparent.yellow");
// [59]  slide1.AddRows(5, {88} , {89} ).AddColumns12(1, {90} , {91} ) 
_slide1.addrows(5,"","").addcolumns12(1,"","");
// [60]  slide1.AddParagraph(1,1, {92} , {93} , {94} , {95} ) 
_slide1.addparagraph(1,1,"p2","This is slide 2","black.transparent","");
// [61]  slide1.AddRaisedButton(1,1, {96} , {97} , {98} , {99} , {100} , {101} ) 
_slide1.addraisedbutton(1,1,"btn2","Button on Slide 2","","","","");
// [63]  Dim carousel2 As UOECarousel 
_carousel2= new banano_uoebanano_uoecarousel();
// [64]  carousel2.Initialize(App, {102} ) 
_carousel2.initialize(self._app,"car2");
// [65]  carousel2.Indicators = True 
_carousel2._indicators = true;
// [66]  carousel2.ZDepth = App.enumzdepth.zdepth_2 
_carousel2._zdepth = self._app._enumzdepth._zdepth_2;
// [67]  carousel2.AddContainer(slide0) 
_carousel2.addcontainer(_slide0);
// [68]  carousel2.AddContainer(slide1) 
_carousel2.addcontainer(_slide1);
// [69]  carousel2.IsSlider = True 
_carousel2._isslider = true;
// [70]  carousel2.FullWidth = True 
_carousel2._fullwidth = true;
// [71]  Page.Content.AddCarousel(3,1,carousel2) 
self._page._content.addcarousel(3,1,_carousel2);
// [74]  Page.Create( {103} , Me) 
self._page.create("carouselButtons",self);
// [76]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [79] Sub carouselButtons(event As BANanoEvent) 
this.carouselbuttons= function(_event) {
if (self==null) self=this;
// [80]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [81]  Log(event.ID) 
console.log(_event.target.id);
// [82]  Select Case App.MvField(event.ID,1, {104} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [83]  Case {105} 
case "" + "btnprev":
// [84]  carousel.PreviousSlide 
self._carousel.previousslide();
// [85]  Case {106} 
break;
case "" + "btnnext":
// [86]  carousel.NextSlide 
self._carousel.nextslide();
// [87]  Case {107} 
break;
case "" + "btn3":
// [88]  carousel.SetSlide(3) 
self._carousel.setslide(3);
// [89]  End Select 
break;
}
// End Sub
};

}
// =========================== pgcheckbox  ===========================
function banano_uoebananodemo_pgcheckbox() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _c1;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"CheckBox",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [18]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  Page.Content.AddCheckBox1(1,1, {10} , {11} , {12} ,False,False,True, {13} , {14} ) 
self._page._content.addcheckbox1(1,1,"chk1","0","CheckBox 1",false,false,true,"","");
// [20]  Page.Content.AddCheckBox1(1,1, {15} , {16} , {17} ,True,False,True, {18} , {19} ) 
self._page._content.addcheckbox1(1,1,"chk2","0","CheckBox 2",true,false,true,"","");
// [21]  Page.Content.AddCheckBox1(1,1, {20} , {21} , {22} ,True,True,True, {23} , {24} ) 
self._page._content.addcheckbox1(1,1,"chk3","0","CheckBox 3",true,true,true,"","");
// [22]  Page.Content.AddCheckBox1(1,1, {25} , {26} , {27} ,False,False,False, {28} , {29} ) 
self._page._content.addcheckbox1(1,1,"chk4","0","CheckBox 4",false,false,false,"","");
// [24]  Dim c1 As UOECheckBoxGroup 
_c1= new banano_uoebanano_uoecheckboxgroup();
// [25]  c1.Initialize(App, {30} , {31} ,True, {32} ) 
_c1.initialize(self._app,"c1","Checkbox Group",true,"");
// [26]  c1.AddItem( {33} ,0, {34} ,True,True,True) 
_c1.additem("poor",0,"Poor",true,true,true);
// [27]  c1.AddItem( {35} ,1, {36} ,True,True,False) 
_c1.additem("rich",1,"Rich",true,true,false);
// [28]  c1.AddItem( {37} ,2, {38} ,True,True,False) 
_c1.additem("sad",2,"Sad",true,true,false);
// [29]  Page.Content.AddCheckboxGroup(1,1,c1) 
self._page._content.addcheckboxgroup(1,1,_c1);
// [31]  Page.Create( {39} , Me) 
self._page.create("checkboxButtons",self);
// [33]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [36] Sub checkboxButtons(event As BANanoEvent) 
this.checkboxbuttons= function(_event) {
if (self==null) self=this;
// [37]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [38]  Select Case App.MvField(event.ID,1, {40} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [39]  End Select 
}
// End Sub
};

}
// =========================== pgchip  ===========================
function banano_uoebananodemo_pgchip() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _chip;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Chip",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  Dim chip As UOEChip 
_chip= new banano_uoebanano_uoechip();
// [19]  chip.Initialize(App, {10} , {11} , {12} , {13} , {14} ) 
_chip.initialize(self._app,"chip","Anele Mbanga","assets/sponge.png","","white.green");
// [20]  chip.CanClose = True 
_chip._canclose = true;
// [21]  Page.Content.AddChip(1,1,chip) 
self._page._content.addchip(1,1,_chip);
// [22]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [24]  Dim chip As UOEChip 
_chip= new banano_uoebanano_uoechip();
// [25]  chip.Initialize(App, {15} , {16} , {17} , {18} , {19} ) 
_chip.initialize(self._app,"chip1","Kenny","assets/kenny.png","","");
// [26]  Page.Content.AddChip(1,1,chip) 
self._page._content.addchip(1,1,_chip);
// [27]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [29]  Page.Content.AddChip1(1,1, {20} , {21} , {22} ,True, {23} , {24} ) 
self._page._content.addchip1(1,1,"chip2","Another simple chip","assets/eric.png",true,"white.blue","");
// [30]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [32]  Page.Create( {25} , Me) 
self._page.create("chipEvents",self);
// [34]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [37] Sub chipEvents(event As BANanoEvent) 
this.chipevents= function(_event) {
if (self==null) self=this;
// [38]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [39]  Select Case App.MvField(event.ID,1, {26} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [40]  End Select 
}
// End Sub
};

}
// =========================== pgList  ===========================
function banano_uoebananodemo_pglist() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _explainlist;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"List",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim explainList As UOEList 
_explainlist= new banano_uoebanano_uoelist();
// [21]  explainList.Initialize(App, {10} ,True,False) 
_explainlist.initialize(self._app,"explain",true,false);
// [22]  explainList.AsCircles 
_explainlist.ascircles();
// [23]  explainList.AddItem( {11} , {12} , {13} ) 
_explainlist.additem("","On line 25, we defined the Page title, that you see on the browser page title","");
// [24]  explainList.AddItem( {14} , {15} , {16} ) 
_explainlist.additem("","Line 29, added 5 rows each with a single column spanning 12 spaces","");
// [25]  explainList.AddItem( {17} , {18} , {19} ) 
_explainlist.additem("","We then added a breadcrumb control with 3 buttons and added that breadcrumb at R2C1","");
// [26]  explainList.AddItem( {20} , {21} , {22} ) 
_explainlist.additem("","Do you see the blockquote titled IMPORTANT CONSIDERATIONS?, We add it also in the same R2C1. Components added this way are added in sequence.","");
// [27]  explainList.AddItem( {23} , {24} , {25} ) 
_explainlist.additem("","In line 38, we create an ordered list with content","");
// [28]  explainList.AddItem( {26} , {27} , {28} ) 
_explainlist.additem("","In line 46, we create another list and add it to the page","");
// [29]  explainList.AddItem( {29} , {30} , {31} ) 
_explainlist.additem("","A code block is added in line 55 using Prism. The contents of that code block are read from an asset file.","");
// [30]  explainList.AddItem( {32} , {33} , {34} ) 
_explainlist.additem("","In line 68, a label is created and added.","");
// [31]  Page.Content.AddList(1,1,explainList) 
self._page._content.addlist(1,1,_explainlist);
// [33]  Dim explainList As UOEList 
_explainlist= new banano_uoebanano_uoelist();
// [34]  explainList.Initialize(App, {35} ,True,False) 
_explainlist.initialize(self._app,"explain1",true,false);
// [35]  explainList.AsSquare 
_explainlist.assquare();
// [36]  explainList.AddItem( {36} , {37} , {38} ) 
_explainlist.additem("","On line 25, we defined the Page title, that you see on the browser page title","");
// [37]  explainList.AddItem( {39} , {40} , {41} ) 
_explainlist.additem("","Line 29, added 5 rows each with a single column spanning 12 spaces","");
// [38]  explainList.AddItem( {42} , {43} , {44} ) 
_explainlist.additem("","We then added a breadcrumb control with 3 buttons and added that breadcrumb at R2C1","");
// [39]  explainList.AddItem( {45} , {46} , {47} ) 
_explainlist.additem("","Do you see the blockquote titled IMPORTANT CONSIDERATIONS?, We add it also in the same R2C1. Components added this way are added in sequence.","");
// [40]  explainList.AddItem( {48} , {49} , {50} ) 
_explainlist.additem("","In line 38, we create an ordered list with content","");
// [41]  explainList.AddItem( {51} , {52} , {53} ) 
_explainlist.additem("","In line 46, we create another list and add it to the page","");
// [42]  explainList.AddItem( {54} , {55} , {56} ) 
_explainlist.additem("","A code block is added in line 55 using Prism. The contents of that code block are read from an asset file.","");
// [43]  explainList.AddItem( {57} , {58} , {59} ) 
_explainlist.additem("","In line 68, a label is created and added.","");
// [44]  Page.Content.AddList(1,1,explainList) 
self._page._content.addlist(1,1,_explainlist);
// [46]  Dim explainList As UOEList 
_explainlist= new banano_uoebanano_uoelist();
// [47]  explainList.Initialize(App, {60} ,True,False) 
_explainlist.initialize(self._app,"explain2",true,false);
// [48]  explainList.ShowUpperCaseRoman 
_explainlist.showuppercaseroman();
// [49]  explainList.AddItem( {61} , {62} , {63} ) 
_explainlist.additem("","On line 25, we defined the Page title, that you see on the browser page title","");
// [50]  explainList.AddItem( {64} , {65} , {66} ) 
_explainlist.additem("","Line 29, added 5 rows each with a single column spanning 12 spaces","");
// [51]  explainList.AddItem( {67} , {68} , {69} ) 
_explainlist.additem("","We then added a breadcrumb control with 3 buttons and added that breadcrumb at R2C1","");
// [52]  explainList.AddItem( {70} , {71} , {72} ) 
_explainlist.additem("","Do you see the blockquote titled IMPORTANT CONSIDERATIONS?, We add it also in the same R2C1. Components added this way are added in sequence.","");
// [53]  explainList.AddItem( {73} , {74} , {75} ) 
_explainlist.additem("","In line 38, we create an ordered list with content","");
// [54]  explainList.AddItem( {76} , {77} , {78} ) 
_explainlist.additem("","In line 46, we create another list and add it to the page","");
// [55]  explainList.AddItem( {79} , {80} , {81} ) 
_explainlist.additem("","A code block is added in line 55 using Prism. The contents of that code block are read from an asset file.","");
// [56]  explainList.AddItem( {82} , {83} , {84} ) 
_explainlist.additem("","In line 68, a label is created and added.","");
// [57]  Page.Content.AddList(1,1,explainList) 
self._page._content.addlist(1,1,_explainlist);
// [60]  Page.Create( {85} , Me) 
self._page.create("listEvents",self);
// [62]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [65] Sub listEvents(event As BANanoEvent) 
this.listevents= function(_event) {
if (self==null) self=this;
// [66]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [67]  Select Case App.MvField(event.ID,1, {86} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [68]  End Select 
}
// End Sub
};

}
// =========================== pgCollapsible  ===========================
function banano_uoebananodemo_pgcollapsible() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._col= new banano_uoebanano_uoecollapsible();

this._page= new banano_uoebanano_uoepage();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _col1;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Collapsible",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  Page.Content.AddRaisedButton(1,1, {10} , {11} , {12} , {13} , {14} , {15} ) 
self._page._content.addraisedbutton(1,1,"btnClose","Close @ 1","","","white.red","");
// [20]  Page.Content.AddRaisedButton(1,1, {16} , {17} , {18} , {19} , {20} , {21} ) 
self._page._content.addraisedbutton(1,1,"btnOpen","Open @ 1","","","white.green","");
// [22]  col.Initialize(App, {22} ,App.EnumCollapsibleType.accordion,False, {23} ) 
self._col.initialize(self._app,"col",self._app._enumcollapsibletype._accordion,false,"");
// [23]  col.AddHeader( {24} , {25} , {26} , {27} ,True, {28} , {29} , {30} ,False) 
self._col.addheader("first","mdi-filter_drama","First","4",true,"#","green","red",false);
// [24]  col.AddHeaderBody( {31} , {32} ) 
self._col.addheaderbody("first","This is a collapsible test...");
// [25]  col.AddHeader( {33} , {34} , {35} , {36} ,False, {37} , {38} , {39} ,False) 
self._col.addheader("second","mdi-place","Location","1",false,"#","blue","green",false);
// [26]  col.AddHeaderBody( {40} , {41} ) 
self._col.addheaderbody("second","This is a collapsible test 1...");
// [27]  col.popout = True 
self._col._popout = true;
// [28]  Page.Content.AddCollapsible(1,1,col) 
self._page._content.addcollapsible(1,1,self._col);
// [30]  Dim col1 As UOECollapsible 
_col1= new banano_uoebanano_uoecollapsible();
// [31]  col1.Initialize(App, {42} ,App.EnumCollapsibleType.expandable,False, {43} ) 
_col1.initialize(self._app,"col1",self._app._enumcollapsibletype._expandable,false,"");
// [32]  col1.AddHeader( {44} , {45} , {46} , {47} ,True, {48} , {49} , {50} ,False) 
_col1.addheader("first1","mdi-filter_drama","First","4",true,"#","green","red",false);
// [33]  col1.AddHeaderBody( {51} , {52} ) 
_col1.addheaderbody("first1","This is a collapsible test...");
// [34]  col1.AddHeader( {53} , {54} , {55} , {56} ,False, {57} , {58} , {59} ,False) 
_col1.addheader("second1","mdi-place","Location","1",false,"#","blue","green",false);
// [35]  col1.AddHeaderBody( {60} , {61} ) 
_col1.addheaderbody("second1","This is a collapsible test 1...");
// [36]  Page.Content.AddCollapsible(1,1,col1) 
self._page._content.addcollapsible(1,1,_col1);
// [39]  Page.Create( {62} , Me) 
self._page.create("collapsibleEvents",self);
// [41]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [44] Sub collapsibleEvents(event As BANanoEvent) 
this.collapsibleevents= function(_event) {
if (self==null) self=this;
// [45]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [46]  Select Case App.MvField(event.ID,1, {63} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [47]  Case {64} 
case "" + "btnopen":
// [48]  col.Open(0) 
self._col.open(0);
// [49]  Case {65} 
break;
case "" + "btnclose":
// [50]  col.Close(0) 
self._col.close(0);
// [51]  End Select 
break;
}
// End Sub
};

}
// =========================== pgDateTime  ===========================
function banano_uoebananodemo_pgdatetime() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _dp;
var _dp1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Date & Time",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  Dim dp As UOEDatePicker 
_dp= new banano_uoebanano_uoedatepicker();
// [20]  dp.Initialize(App, {10} , {11} ,Page.App.EnumDateTimeType.datepicker, {12} ) 
_dp.initialize(self._app,"dp","Date",self._page._app._enumdatetimetype._datepicker,"");
// [21]  Page.Content.AddDatePicker(1,1,dp) 
self._page._content.adddatepicker(1,1,_dp);
// [23]  Dim dp1 As UOEDatePicker 
_dp1= new banano_uoebanano_uoedatepicker();
// [24]  dp1.Initialize(App, {13} , {14} ,Page.App.EnumDateTimeType.timepicker, {15} ) 
_dp1.initialize(self._app,"dp1","Time",self._page._app._enumdatetimetype._timepicker,"");
// [25]  Page.Content.AddDatePicker(1,1,dp1) 
self._page._content.adddatepicker(1,1,_dp1);
// [29]  Page.Create( {16} , Me) 
self._page.create("dateEvents",self);
// [31]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [34] Sub dateEvents(event As BANanoEvent) 
this.dateevents= function(_event) {
if (self==null) self=this;
// [35]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [36]  Select Case App.MvField(event.ID,1, {17} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [37]  End Select 
}
// End Sub
};

}
// =========================== pgSelect  ===========================
function banano_uoebananodemo_pgselect() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _cbo;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Select",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  Dim cbo As UOESelect 
_cbo= new banano_uoebanano_uoeselect();
// [20]  cbo.Initialize(App, {10} , {11} , {12} , {13} ,True, {14} ) 
_cbo.initialize(self._app,"cbo","mdi-phone","Select Box","Choose your option",true,"");
// [21]  cbo.AddItem( {15} , {16} , {17} ) 
_cbo.additem("opt1","1","Option 1");
// [22]  cbo.AddItem( {18} , {19} , {20} ) 
_cbo.additem("opt2","2","Option 2");
// [23]  cbo.AddItem( {21} , {22} , {23} ) 
_cbo.additem("opt3","3","Option 3");
// [24]  Page.Content.AddSelect(1,1,cbo) 
self._page._content.addselect(1,1,_cbo);
// [26]  Dim cbo As UOESelect 
_cbo= new banano_uoebanano_uoeselect();
// [27]  cbo.Initialize(App, {24} , {25} , {26} , {27} ,False, {28} ) 
_cbo.initialize(self._app,"imgs","mdi-phone","Images Combo","Choose your option",false,"");
// [28]  cbo.AddImage( {29} , {30} , {31} , {32} ,Page.App.EnumAlignment.left,True) 
_cbo.addimage("opt1","1","Sponge","assets/sponge.png",self._page._app._enumalignment._left,true);
// [29]  cbo.AddImage( {33} , {34} , {35} , {36} ,Page.App.EnumAlignment.left,True) 
_cbo.addimage("opt2","2","Eric","assets/eric.png",self._page._app._enumalignment._left,true);
// [30]  cbo.AddImage( {37} , {38} , {39} , {40} ,Page.App.EnumAlignment.left,True) 
_cbo.addimage("opt3","3","Kenny","assets/kenny.png",self._page._app._enumalignment._left,true);
// [31]  Page.Content.AddSelect(1,1,cbo) 
self._page._content.addselect(1,1,_cbo);
// [33]  Dim cbo As UOESelect 
_cbo= new banano_uoebanano_uoeselect();
// [34]  cbo.Initialize(App, {41} , {42} , {43} , {44} ,True, {45} ) 
_cbo.initialize(self._app,"imgs1","mdi-phone","Images Combo","Choose your option",true,"");
// [35]  cbo.Enabled = False 
_cbo._enabled = false;
// [36]  cbo.AddImage( {46} , {47} , {48} , {49} ,Page.App.EnumAlignment.left,False) 
_cbo.addimage("opt1","1","Sponge","assets/sponge.png",self._page._app._enumalignment._left,false);
// [37]  cbo.AddImage( {50} , {51} , {52} , {53} ,Page.App.EnumAlignment.right,False) 
_cbo.addimage("opt2","2","Eric","assets/eric.png",self._page._app._enumalignment._right,false);
// [38]  cbo.AddImage( {54} , {55} , {56} , {57} ,Page.App.EnumAlignment.right,False) 
_cbo.addimage("opt3","3","Kenny","assets/kenny.png",self._page._app._enumalignment._right,false);
// [39]  Page.Content.AddSelect(1,1,cbo) 
self._page._content.addselect(1,1,_cbo);
// [43]  Page.Create( {58} , Me) 
self._page.create("navEvents",self);
// [45]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [48] Sub navEvents(event As BANanoEvent) 
this.navevents= function(_event) {
if (self==null) self=this;
// [49]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [50]  Select Case App.MvField(event.ID,1, {59} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [51]  End Select 
}
// End Sub
};

}
// =========================== pgDropdown  ===========================
function banano_uoebananodemo_pgdropdown() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _dp;
var _dp1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Dropdown",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("redbadge","red","","transparent","");
// [20]  Dim dp As UOEDropDown 
_dp= new banano_uoebanano_uoedropdown();
// [21]  dp.Initialize(App, {15} , {16} ,App.EnumVisibility.visible,True,True, {17} ) 
_dp.initialize(self._app,"dpx","Dropdown Menu",self._app._enumvisibility._visible,true,true,"");
// [22]  dp.AddItemBadge( {18} , {19} , {20} ,True, {21} ,False,False, {22} , {23} ) 
_dp.additembadge("b1","Alan","#",true,"1",false,false,"","");
// [23]  dp.AddItemBadge( {24} , {25} , {26} ,False, {27} ,True,True, {28} , {29} ) 
_dp.additembadge("b2","Alan","#",false,"4",true,true,"","");
// [24]  dp.AddItemBadge( {30} , {31} , {32} ,False, {33} ,False,True, {34} , {35} ) 
_dp.additembadge("b3","Alan","#",false,"5",false,true,"","redbadge");
// [25]  dp.AddItem( {36} , {37} , {38} , {39} ,False,True, {40} ) 
_dp.additem("icon","mdi-add","New","",false,true,"");
// [26]  Page.Content.AddDropDown(1,1,dp) 
self._page._content.adddropdown(1,1,_dp);
// [27]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [29]  Dim dp1 As UOEDropDown 
_dp1= new banano_uoebanano_uoedropdown();
// [30]  dp1.Initialize(App, {41} , {42} ,Page.App.EnumVisibility.visible,True,False, {43} ) 
_dp1.initialize(self._app,"dp","Dropdown Menu",self._page._app._enumvisibility._visible,true,false,"");
// [31]  dp1.closeOnClick = True 
_dp1._closeonclick = true;
// [32]  dp1.coverTrigger = False 
_dp1._covertrigger = false;
// [33]  dp1.Hoverable = False 
_dp1._hoverable = false;
// [34]  dp1.AddItemBadge( {44} , {45} , {46} ,False, {47} ,False,False, {48} , {49} ) 
_dp1.additembadge("b1","Alan","#",false,"1",false,false,"","");
// [35]  dp1.AddItemBadge( {50} , {51} , {52} ,False, {53} ,False,True, {54} , {55} ) 
_dp1.additembadge("b2","Alan","#",false,"4",false,true,"","");
// [36]  dp1.AddItemBadge( {56} , {57} , {58} ,False, {59} ,False,True, {60} , {61} ) 
_dp1.additembadge("b3","Alan","#",false,"5",false,true,"","redbadge");
// [37]  Page.Content.AddDropDown(1,1,dp1) 
self._page._content.adddropdown(1,1,_dp1);
// [38]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [42]  Page.Create( {62} , Me) 
self._page.create("navEvents",self);
// [44]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [47] Sub navEvents(event As BANanoEvent) 
this.navevents= function(_event) {
if (self==null) self=this;
// [48]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [49]  Log(event.ID) 
console.log(_event.target.id);
// [50]  Select Case App.MvField(event.ID,1, {63} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [51]  End Select 
}
// End Sub
};

}
// =========================== pgFile  ===========================
function banano_uoebananodemo_pgfile() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _fu;
var _fu1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"File",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("redbadge","red","","transparent","");
// [20]  Dim fu As UOEFile 
_fu= new banano_uoebanano_uoefile();
// [21]  fu.Initialize(App, {15} , {16} , {17} ,False, {18} ) 
_fu.initialize(self._app,"fu","Browse","Upload one or more files...",false,"");
// [22]  fu.HelperText = {19} 
_fu._helpertext = "Do this...";
// [23]  Page.Content.AddFile(1,1,fu) 
self._page._content.addfile(1,1,_fu);
// [24]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [26]  Dim fu1 As UOEFile 
_fu1= new banano_uoebanano_uoefile();
// [27]  fu1.Initialize(App, {20} , {21} , {22} ,False, {23} ) 
_fu1.initialize(self._app,"fu1","Select File","Upload one or more files...",false,"");
// [28]  fu1.HideInput = True 
_fu1._hideinput = true;
// [29]  fu1.FitWidth = True 
_fu1._fitwidth = true;
// [30]  Page.Content.AddFile(1,1,fu1) 
self._page._content.addfile(1,1,_fu1);
// [31]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [35]  Page.Create( {24} , Me) 
self._page.create("navEvents",self);
// [37]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [40] Sub navEvents(event As BANanoEvent) 
this.navevents= function(_event) {
if (self==null) self=this;
// [41]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [42]  Log(event.ID) 
console.log(_event.target.id);
// [43]  Select Case App.MvField(event.ID,1, {25} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [44]  End Select 
}
// End Sub
};

}
// =========================== pgVideo  ===========================
function banano_uoebananodemo_pgvideo() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _vid;
var _vid1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Video",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim vid As UOEVideo 
_vid= new banano_uoebanano_uoevideo();
// [21]  vid.Initialize(App, {10} , {11} ) 
_vid.initialize(self._app,"vid","assets/night.mp4");
// [22]  vid.AutoPlay = False 
_vid._autoplay = false;
// [23]  vid.AllowFullScreen = True 
_vid._allowfullscreen = true;
// [24]  vid.FrameBorder = 0 
_vid._frameborder = 0;
// [25]  vid.AutoPlay = False 
_vid._autoplay = false;
// [26]  vid.LoopIt = False 
_vid._loopit = false;
// [27]  vid.ShowControls = True 
_vid._showcontrols = true;
// [28]  Page.Content.AddVideo(1,1,vid) 
self._page._content.addvideo(1,1,_vid);
// [30]  Dim vid1 As UOEHTML5Video 
_vid1= new banano_uoebanano_uoehtml5video();
// [31]  vid1.Initialize(App, {12} , {13} ) 
_vid1.initialize(self._app,"vid1","assets/night.mp4");
// [32]  vid1.AutoPlay = True 
_vid1._autoplay = true;
// [33]  vid1.AllowFullScreen = True 
_vid1._allowfullscreen = true;
// [34]  vid1.VideoType = Page.App.EnumVideoType.mp4 
_vid1._videotype = self._page._app._enumvideotype._mp4;
// [35]  vid1.ShowControls = True 
_vid1._showcontrols = true;
// [36]  vid1.LoopIT = True 
_vid1._loopit = true;
// [37]  Page.Content.AddHTML5Video(1,1,vid1) 
self._page._content.addhtml5video(1,1,_vid1);
// [39]  Page.Create( {14} , Me) 
self._page.create("videoEvents",self);
// [41]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [44] Sub videoEvents(event As BANanoEvent) 
this.videoevents= function(_event) {
if (self==null) self=this;
// [45]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [46]  Log(event.ID) 
console.log(_event.target.id);
// [47]  Select Case App.MvField(event.ID,1, {15} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [48]  End Select 
}
// End Sub
};

}
// =========================== pgIcons  ===========================
function banano_uoebananodemo_pgicons() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _icon;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Icons",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("green.transparent","green","","transparent","");
// [21]  App.AddTheme( {15} , {16} , {17} , {18} , {19} ) 
self._app.addtheme("blue.transparent","blue","","transparent","");
// [22]  App.AddTheme( {20} , {21} , {22} , {23} , {24} ) 
self._app.addtheme("orange.transparent","orange","","transparent","");
// [23]  App.AddTheme( {25} , {26} , {27} , {28} , {29} ) 
self._app.addtheme("yellow.transparent","yellow","","transparent","");
// [25]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [26]  icon.Initialize(App, {30} , {31} , {32} ) 
_icon.initialize(self._app,"icn1","mdi-3d_rotation","");
// [27]  icon.IconSize = App.EnumIconSize.tiny 
_icon._iconsize = self._app._enumiconsize._tiny;
// [28]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [30]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [31]  icon.Initialize(App, {33} , {34} , {35} ) 
_icon.initialize(self._app,"icn2","mdi-ac_unit","");
// [32]  icon.IconSize = Page.App.EnumIconSize.small 
_icon._iconsize = self._page._app._enumiconsize._small;
// [33]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [35]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [36]  icon.Initialize(App, {36} , {37} , {38} ) 
_icon.initialize(self._app,"icn3","mdi-access-alarm","");
// [37]  icon.IconSize = Page.App.EnumIconSize.medium 
_icon._iconsize = self._page._app._enumiconsize._medium;
// [38]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [40]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [41]  icon.Initialize(App, {39} , {40} , {41} ) 
_icon.initialize(self._app,"icn4","mdi-accessible","green.transparent");
// [42]  icon.IconSize = Page.App.EnumIconSize.large 
_icon._iconsize = self._page._app._enumiconsize._large;
// [43]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [45]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [46]  icon.Initialize(App, {42} , {43} , {44} ) 
_icon.initialize(self._app,"icn5","mdi-adjust","blue.transparent");
// [47]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [49]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [50]  icon.Initialize(App, {45} , {46} , {47} ) 
_icon.initialize(self._app,"icn6","mdi-apps","orange.transparent");
// [51]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [53]  Dim icon As UOEIcon 
_icon= new banano_uoebanano_uoeicon();
// [54]  icon.Initialize(App, {48} , {49} , {50} ) 
_icon.initialize(self._app,"icn7","mdi-art_track","yellow.transparent");
// [55]  Page.Content.AddIcon(1,1,icon) 
self._page._content.addicon(1,1,_icon);
// [58]  Page.Create( {51} , Me) 
self._page.create("iconEvents",self);
// [60]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [63] Sub iconEvents(event As BANanoEvent) 
this.iconevents= function(_event) {
if (self==null) self=this;
// [64]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [65]  Log(event.ID) 
console.log(_event.target.id);
// [66]  Select Case App.MvField(event.ID,1, {52} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [67]  End Select 
}
// End Sub
};

}
// =========================== pgImage  ===========================
function banano_uoebananodemo_pgimage() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _img;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Images",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim img As UOEImage 
_img= new banano_uoebanano_uoeimage();
// [21]  img.Initialize(App, {10} , {11} , {12} ,True) 
_img.initialize(self._app,"img","assets/79.jpg","Very nice kids shoes",true);
// [22]  img.Setsize( {13} , {14} ) 
_img.setsize("100","100");
// [23]  img.zdepth = App.enumzdepth.ZDepth_3 
_img._zdepth = self._app._enumzdepth._zdepth_3;
// [24]  img.responsive = True 
_img._responsive = true;
// [25]  img.MaterialBoxed = True 
_img._materialboxed = true;
// [26]  Page.content.addimage(1,1,img) 
self._page._content.addimage(1,1,_img);
// [27]  Page.content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [29]  Dim img As UOEImage 
_img= new banano_uoebanano_uoeimage();
// [30]  img.Initialize(App, {15} , {16} , {17} ,True) 
_img.initialize(self._app,"img1","assets/1.jpg","",true);
// [31]  img.circle = True 
_img._circle = true;
// [32]  img.Responsive = False 
_img._responsive = false;
// [33]  img.Setsize( {18} , {19} ) 
_img.setsize("200","200");
// [34]  img.ZDepth = Page.App.enumzdepth.ZDepth_5 
_img._zdepth = self._page._app._enumzdepth._zdepth_5;
// [35]  Page.content.addimage(1,1,img) 
self._page._content.addimage(1,1,_img);
// [36]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [39]  Page.Create( {20} , Me) 
self._page.create("iconEvents",self);
// [41]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [44] Sub iconEvents(event As BANanoEvent) 
this.iconevents= function(_event) {
if (self==null) self=this;
// [45]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [46]  Log(event.ID) 
console.log(_event.target.id);
// [47]  Select Case App.MvField(event.ID,1, {21} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [48]  End Select 
}
// End Sub
};

}
// =========================== pgInput  ===========================
function banano_uoebananodemo_pginput() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _inp;
var _autoc;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Textbox & Textarea",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim inp As UOEInput 
_inp= new banano_uoebanano_uoeinput();
// [21]  inp.Initialize(App, {10} , {11} , {12} ,App.EnumInputType.password, {13} ) 
_inp.initialize(self._app,"pwd","Password","",self._app._enuminputtype._password,"");
// [22]  inp.Inline = True 
_inp._inline = true;
// [23]  inp.Required = True 
_inp._required = true;
// [24]  inp.HelperText = {14} 
_inp._helpertext = "Enter your email here";
// [25]  Page.Content.AddInput(1,1,inp) 
self._page._content.addinput(1,1,_inp);
// [27]  Dim inp As UOEInput 
_inp= new banano_uoebanano_uoeinput();
// [28]  inp.Initialize(App, {15} , {16} , {17} ,App.EnumInputType.text, {18} ) 
_inp.initialize(self._app,"dsa","Disabled","",self._app._enuminputtype._text,"");
// [29]  inp.Enabled = False 
_inp._enabled = false;
// [30]  Page.Content.AddInput(1,1,inp) 
self._page._content.addinput(1,1,_inp);
// [32]  Dim inp As UOEInput 
_inp= new banano_uoebanano_uoeinput();
// [33]  inp.Initialize(App, {19} , {20} , {21} ,App.EnumInputType.email, {22} ) 
_inp.initialize(self._app,"em","Email","",self._app._enuminputtype._email,"");
// [34]  inp.IconName = {23} 
_inp._iconname = "mdi-account_circle";
// [35]  Page.Content.AddInput(1,1,inp) 
self._page._content.addinput(1,1,_inp);
// [37]  Dim inp As UOEInput 
_inp= new banano_uoebanano_uoeinput();
// [38]  inp.Initialize(App, {24} , {25} , {26} ,App.EnumInputType.Tel, {27} ) 
_inp.initialize(self._app,"tel","Phone","",self._app._enuminputtype._tel,"");
// [39]  inp.IconName = {28} 
_inp._iconname = "mdi-phone";
// [40]  Page.Content.AddInput(1,1,inp) 
self._page._content.addinput(1,1,_inp);
// [42]  Dim inp As UOEInput 
_inp= new banano_uoebanano_uoeinput();
// [43]  inp.Initialize(App, {29} , {30} , {31} ,App.EnumInputType.textarea, {32} ) 
_inp.initialize(self._app,"tarea","Text Area","",self._app._enuminputtype._textarea,"");
// [44]  inp.IconName = {33} 
_inp._iconname = "mdi-comment";
// [45]  inp.MaxLength = 120 
_inp._maxlength = 120;
// [46]  Page.Content.AddInput(1,1,inp) 
self._page._content.addinput(1,1,_inp);
// [48]  Dim autoc As UOEInput 
_autoc= new banano_uoebanano_uoeinput();
// [49]  autoc.Initialize(App, {34} , {35} , {36} ,App.EnumInputType.Text, {37} ) 
_autoc.initialize(self._app,"autoc","Auto Complete","",self._app._enuminputtype._text,"");
// [50]  autoc.AddItem( {38} , {39} ) 
_autoc.additem("Apple","null");
// [51]  autoc.AddItem( {40} , {41} ) 
_autoc.additem("Google","'http://www.google.com'");
// [52]  autoc.AddItem( {42} , {43} ) 
_autoc.additem("Microsoft","null");
// [53]  Page.Content.AddInput(1,1,autoc) 
self._page._content.addinput(1,1,_autoc);
// [58]  Page.Create( {44} , Me) 
self._page.create("txtEvents",self);
// [60]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [63] Sub txtEvents(event As BANanoEvent) 
this.txtevents= function(_event) {
if (self==null) self=this;
// [64]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [65]  Select Case App.MvField(event.ID,1, {45} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [66]  End Select 
}
// End Sub
};

}
// =========================== pgParallax  ===========================
function banano_uoebananodemo_pgparallax() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _par;
var _pc;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Parallax",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("white.transparent","white","","transparent","");
// [21]  Dim par As UOEParallax 
_par= new banano_uoebanano_uoeparallax();
// [22]  par.Initialize(App, {15} , {16} ) 
_par.initialize(self._app,"par","assets/39.jpg");
// [24]  Dim pc As UOEContainer 
_pc= new banano_uoebanano_uoecontainer();
// [25]  pc.Initialize(App, {17} ,True, {18} ) 
_pc.initialize(self._app,"",true,"");
// [26]  pc.AddRows(1, {19} , {20} ).AddColumns(1,12,12,12, {21} , {22} ) 
_pc.addrows(1,"","").addcolumns(1,12,12,12,"white.transparent","center");
// [27]  pc.AddH1(1,1, {23} , {24} , {25} , {26} ) 
_pc.addh1(1,1,"","{B}QUOTE{/B}","","");
// [28]  pc.AddH4(1,1, {27} , {28} , {29} , {30} ) 
_pc.addh4(1,1,"","Don’t be trapped by dogma - which is living with the results of other people’s thinking.{BR}Don’t let the noise of other’s opinions drown out your own inner voice.","","");
// [29]  par.AddContainer(pc) 
_par.addcontainer(_pc);
// [30]  Page.content.addparallax(1,1,par) 
self._page._content.addparallax(1,1,_par);
// [33]  Page.Create( {31} , Me) 
self._page.create("parEvents",self);
// [35]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [38] Sub parEvents(event As BANanoEvent) 
this.parevents= function(_event) {
if (self==null) self=this;
// [39]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [40]  Select Case App.MvField(event.ID,1, {32} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [41]  End Select 
}
// End Sub
};

}
// =========================== pgBlockQuote  ===========================
function banano_uoebananodemo_pgblockquote() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"BlockQuote",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [14]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [16]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  Page.Content.AddBlockQuote(1,1, {10} , {11} ,6,App.EnumThemes.dangertext, {12} ) 
self._page._content.addblockquote(1,1,"bq6","Block Quote",6,self._app._enumthemes._dangertext,"");
// [19]  Page.Content.AddBlockQuote(1,1, {13} , {14} ,7,App.EnumThemes.infotext, {15} ) 
self._page._content.addblockquote(1,1,"bq7","Block Quote",7,self._app._enumthemes._infotext,"");
// [20]  Page.Content.AddBlockQuote(1,1, {16} , {17} ,8,App.EnumThemes.defaulttext, {18} ) 
self._page._content.addblockquote(1,1,"bq8","Block Quote",8,self._app._enumthemes._defaulttext,"");
// [21]  Page.Content.AddBlockQuote(1,1, {19} , {20} ,9,App.EnumThemes.mutedtext, {21} ) 
self._page._content.addblockquote(1,1,"bq9","Block Quote",9,self._app._enumthemes._mutedtext,"");
// [22]  Page.Content.AddBlockQuote(1,1, {22} , {23} ,10,App.EnumThemes.primarytext, {24} ) 
self._page._content.addblockquote(1,1,"bq10","Block Quote",10,self._app._enumthemes._primarytext,"");
// [23]  Page.Content.AddBlockQuote(1,1, {25} , {26} ,11,App.EnumThemes.successtext, {27} ) 
self._page._content.addblockquote(1,1,"bq11","Block Quote",11,self._app._enumthemes._successtext,"");
// [24]  Page.Content.AddBlockQuote(1,1, {28} , {29} ,12,App.EnumThemes.warntext, {30} ) 
self._page._content.addblockquote(1,1,"bq12","Block Quote",12,self._app._enumthemes._warntext,"");
// [26]  Page.Create( {31} , Me) 
self._page.create("bqEvents",self);
// [28]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [31] Sub bqEvents(event As BANanoEvent) 
this.bqevents= function(_event) {
if (self==null) self=this;
// [32]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [33]  Select Case App.MvField(event.ID,1, {32} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [35]  End Select 
}
// End Sub
};

}
// =========================== pgPreloader  ===========================
function banano_uoebananodemo_pgpreloader() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _prl;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Preloader",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("white.transparent","white","","transparent","");
// [22]  Dim prl As UOEPreloader 
_prl= new banano_uoebanano_uoepreloader();
// [23]  prl.Initialize(App, {15} ) 
_prl.initialize(self._app,"prl");
// [24]  Page.Content.AddPreloader(1,1,prl) 
self._page._content.addpreloader(1,1,_prl);
// [27]  Page.Create( {16} , Me) 
self._page.create("parEvents",self);
// [29]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [32] Sub parEvents(event As BANanoEvent) 
this.parevents= function(_event) {
if (self==null) self=this;
// [33]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [34]  Select Case App.MvField(event.ID,1, {17} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [35]  End Select 
}
// End Sub
};

}
// =========================== pgProgress  ===========================
function banano_uoebananodemo_pgprogress() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _prg;
var _prg1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Progress",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("red.blue","red","","blue","");
// [20]  App.AddTheme( {15} , {16} , {17} , {18} , {19} ) 
self._app.addtheme("green.orange","green","","orange","");
// [22]  Dim prg As UOEProgress 
_prg= new banano_uoebanano_uoeprogress();
// [23]  prg.Initialize(App, {20} ,True, {21} ) 
_prg.initialize(self._app,"prg",true,"red.blue");
// [24]  prg.Percentage = 70 
_prg._percentage = 70;
// [25]  Page.Content.AddProgress(1,1,prg) 
self._page._content.addprogress(1,1,_prg);
// [26]  Page.Content.addbreak(1,1) 
self._page._content.addbreak(1,1);
// [28]  Dim prg1 As UOEProgress 
_prg1= new banano_uoebanano_uoeprogress();
// [29]  prg1.Initialize(App, {22} ,False, {23} ) 
_prg1.initialize(self._app,"prg1",false,"green.orange");
// [30]  Page.Content.AddProgress(1,1,prg1) 
self._page._content.addprogress(1,1,_prg1);
// [31]  Page.Content.addbreak(1,1) 
self._page._content.addbreak(1,1);
// [34]  Page.Create( {24} , Me) 
self._page.create("prgEvents",self);
// [36]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [39] Sub prgEvents(event As BANanoEvent) 
this.prgevents= function(_event) {
if (self==null) self=this;
// [40]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [41]  Select Case App.MvField(event.ID,1, {25} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [42]  End Select 
}
// End Sub
};

}
// =========================== pgRadio  ===========================
function banano_uoebananodemo_pgradio() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _c1;
var _c2;
var _c3;
var _c6;
var _rgh;
var _rga;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Radio",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("red.blue","red","","blue","");
// [20]  App.AddTheme( {15} , {16} , {17} , {18} , {19} ) 
self._app.addtheme("green.orange","green","","orange","");
// [22]  Dim c1 As UOERadio 
_c1= new banano_uoebanano_uoeradio();
// [23]  c1.Initialize(App, {20} , {21} , {22} , {23} , {24} ) 
_c1.initialize(self._app,"c1","c1","0","Red","");
// [24]  Page.Content.AddRadio(1,1,c1) 
self._page._content.addradio(1,1,_c1);
// [25]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [27]  Dim c2 As UOERadio 
_c2= new banano_uoebanano_uoeradio();
// [28]  c2.Initialize(App, {25} , {26} ,0, {27} , {28} ) 
_c2.initialize(self._app,"c2","c2",0,"Yellow","");
// [29]  c2.Checked = True 
_c2._checked = true;
// [30]  Page.Content.AddRadio(1,1,c2) 
self._page._content.addradio(1,1,_c2);
// [31]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [33]  Dim c3 As UOERadio 
_c3= new banano_uoebanano_uoeradio();
// [34]  c3.Initialize(App, {29} , {30} ,0, {31} , {32} ) 
_c3.initialize(self._app,"c3","c3",0,"With Gap & Checked","");
// [35]  c3.Checked = True 
_c3._checked = true;
// [36]  c3.WithGap = True 
_c3._withgap = true;
// [37]  Page.Content.AddRadio(1,1,c3) 
self._page._content.addradio(1,1,_c3);
// [38]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [40]  Dim c6 As UOERadio 
_c6= new banano_uoebanano_uoeradio();
// [41]  c6.Initialize(App, {33} , {34} ,0, {35} , {36} ) 
_c6.initialize(self._app,"c6","c4",0,"Disabled","");
// [42]  c6.enabled = False 
_c6._enabled = false;
// [43]  Page.Content.AddRadio(1,1,c6) 
self._page._content.addradio(1,1,_c6);
// [44]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [46]  Dim rgh As UOERadioGroup 
_rgh= new banano_uoebanano_uoeradiogroup();
// [47]  rgh.Initialize(App, {37} , {38} ,True, {39} ) 
_rgh.initialize(self._app,"rgh","Gender (horizontal)",true,"");
// [48]  rgh.AddItem( {40} ,0, {41} ,True,False,True,True) 
_rgh.additem("male",0,"Male",true,false,true,true);
// [49]  rgh.AddItem( {42} ,1, {43} ,True,False,True,False) 
_rgh.additem("female",1,"Female",true,false,true,false);
// [50]  Page.Content.AddRadioGroup(1,1,rgh) 
self._page._content.addradiogroup(1,1,_rgh);
// [51]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [53]  Dim rga As UOERadioGroup 
_rga= new banano_uoebanano_uoeradiogroup();
// [54]  rga.Initialize(App, {44} , {45} ,True, {46} ) 
_rga.initialize(self._app,"rg","Radio Group",true,"");
// [55]  rga.AddItem( {47} ,0, {48} ,True,True,True,True) 
_rga.additem("male",0,"Male",true,true,true,true);
// [56]  rga.AddItem( {49} ,1, {50} ,True,True,True,False) 
_rga.additem("female",1,"Female",true,true,true,false);
// [57]  Page.Content.AddRadioGroup(1,1,rga) 
self._page._content.addradiogroup(1,1,_rga);
// [61]  Page.Create( {51} , Me) 
self._page.create("radioEvents",self);
// [63]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [66] Sub radioEvents(event As BANanoEvent) 
this.radioevents= function(_event) {
if (self==null) self=this;
// [67]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [68]  Select Case App.MvField(event.ID,1, {52} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [69]  End Select 
}
// End Sub
};

}
// =========================== pgRange  ===========================
function banano_uoebananodemo_pgrange() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _range;
var _slider;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Range",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("red.blue","red","","blue","");
// [20]  App.AddTheme( {15} , {16} , {17} , {18} , {19} ) 
self._app.addtheme("green.orange","green","","orange","");
// [22]  Dim range As UOERange 
_range= new banano_uoebanano_uoerange();
// [23]  range.Initialize(App, {20} , {21} , 0,100,42,1, {22} ) 
_range.initialize(self._app,"range","My Range",0,100,42,1,"");
// [24]  Page.Content.AddRange(1,1,range) 
self._page._content.addrange(1,1,_range);
// [25]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [27]  Dim slider As UOERangeSlider 
_slider= new banano_uoebanano_uoerangeslider();
// [28]  slider.Initialize(App, {23} , {24} , 10,100,0,200,1,False, {25} ) 
_slider.initialize(self._app,"slider","My Slider",10,100,0,200,1,false,"");
// [29]  Page.Content.AddRangeSlider(1,1,slider) 
self._page._content.addrangeslider(1,1,_slider);
// [30]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [33]  Page.Create( {26} , Me) 
self._page.create("radioEvents",self);
// [35]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [38] Sub radioEvents(event As BANanoEvent) 
this.radioevents= function(_event) {
if (self==null) self=this;
// [39]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [40]  Select Case App.MvField(event.ID,1, {27} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [41]  End Select 
}
// End Sub
};

}
// =========================== pgSlider  ===========================
function banano_uoebananodemo_pgslider() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _imageslider;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Slider",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [18]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("red.transparent","red","","transparent","");
// [19]  App.AddTheme( {15} , {16} , {17} , {18} , {19} ) 
self._app.addtheme("blue.transparent","blue","","transparent","");
// [20]  App.AddTheme( {20} , {21} , {22} , {23} , {24} ) 
self._app.addtheme("teal.transparent","teal","","transparent","");
// [23]  Dim imageslider As UOESlider 
_imageslider= new banano_uoebanano_uoeslider();
// [24]  imageslider.Initialize(App, {25} ) 
_imageslider.initialize(self._app,"imgslider");
// [25]  imageslider.AddSlide( {26} , {27} , {28} ,App.EnumTextAlignment.center, {29} , {30} , {31} ) 
_imageslider.addslide("slide1","assets/1.jpg","Slide 1",self._app._enumtextalignment._center,"Slide 1 Description","red.transparent","blue.transparent");
// [26]  imageslider.AddSlide( {32} , {33} , {34} ,App.EnumTextAlignment.left, {35} , {36} , {37} ) 
_imageslider.addslide("slide2","assets/2.jpg","Slide 2",self._app._enumtextalignment._left,"Slide 2 Description","teal.transparent","blue.transparent");
// [27]  imageslider.AddSlide( {38} , {39} , {40} ,App.EnumTextAlignment.right, {41} , {42} , {43} ) 
_imageslider.addslide("slide3","assets/3.jpg","Slide 3",self._app._enumtextalignment._right,"Slide 3 Description","blue.transparent","teal.transparent");
// [28]  Page.Content.AddSlider(1,1,imageslider) 
self._page._content.addslider(1,1,_imageslider);
// [31]  Page.Create( {44} , Me) 
self._page.create("radioEvents",self);
// [33]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [36] Sub radioEvents(event As BANanoEvent) 
this.radioevents= function(_event) {
if (self==null) self=this;
// [37]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [38]  Select Case App.MvField(event.ID,1, {45} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [39]  End Select 
}
// End Sub
};

}
// =========================== pgSwitch  ===========================
function banano_uoebananodemo_pgswitch() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _switch;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Switch",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [19]  Dim switch As UOESwitch 
_switch= new banano_uoebanano_uoeswitch();
// [20]  switch.Initialize(App, {10} , {11} , {12} , {13} , {14} ) 
_switch.initialize(self._app,"switch","My Switch","On","Off","");
// [22]  Page.Content.addswitch(1,1,switch) 
self._page._content.addswitch(1,1,_switch);
// [24]  Page.Create( {15} , Me) 
self._page.create("radioEvents",self);
// [26]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [29] Sub radioEvents(event As BANanoEvent) 
this.radioevents= function(_event) {
if (self==null) self=this;
// [30]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [31]  Select Case App.MvField(event.ID,1, {16} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [32]  End Select 
}
// End Sub
};

}
// =========================== pgButtons  ===========================
function banano_uoebananodemo_pgbuttons() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._fab= new banano_uoebanano_uoefab();

this._page= new banano_uoebanano_uoepage();

// [11] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _btn;
// [12]  App = thisApp 
self._app = _thisapp;
// [13]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Buttons",self._app._enumlogoposition._center,true,true,"","");
// [14]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [16]  Page.Content.AddRows(15, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(15,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim btn As UOEButton 
_btn= new banano_uoebanano_uoebutton();
// [21]  btn.Initialize(App, {10} , {11} , {12} ) 
_btn.initialize(self._app,"btn","My Button","default");
// [22]  btn.SetButtonType(App.enumbuttontype.raised) 
_btn.setbuttontype(self._app._enumbuttontype._raised);
// [23]  btn.Size = App.EnumButtonSize.large 
_btn._size = self._app._enumbuttonsize._large;
// [24]  btn.AddIcon( {13} ,App.EnumAlignment.left, {14} ,False,False) 
_btn.addicon("mdi-cloud",self._app._enumalignment._left,"icon",false,false);
// [25]  Page.Content.AddButton(1,1,btn) 
self._page._content.addbutton(1,1,_btn);
// [26]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [27]  Page.Content.AddButton1(1,1, {15} , {16} , {17} ,App.EnumButtonType.raised, {18} ,App.EnumButtonSize.large,True,False,True,App.EnumThemes.primary, {19} ) 
self._page._content.addbutton1(1,1,"btn1","Button 1","#",self._app._enumbuttontype._raised,"",self._app._enumbuttonsize._large,true,false,true,self._app._enumthemes._primary,"");
// [28]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [29]  Page.Content.AddRaisedButton(1,1, {20} , {21} , {22} , {23} ,App.EnumThemes.danger, {24} ) 
self._page._content.addraisedbutton(1,1,"btnraised","Raised Button","","#",self._app._enumthemes._danger,"");
// [30]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [31]  Page.Content.AddFlatButton(1,1, {25} , {26} , {27} , {28} ,App.EnumThemes.default, {29} ) 
self._page._content.addflatbutton(1,1,"btnFlat","Flat","","#",self._app._enumthemes._default,"");
// [32]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [33]  Page.Content.AddFloatingButton(1,1, {30} , {31} , {32} , {33} ,App.EnumThemes.info, {34} ) 
self._page._content.addfloatingbutton(1,1,"btnFloating","mdi-add","","#",self._app._enumthemes._info,"");
// [34]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [35]  Page.Content.AddRaisedButton(1,1, {35} , {36} , {37} , {38} ,App.EnumThemes.muted, {39} ) 
self._page._content.addraisedbutton(1,1,"btnStop","Stop Pulse","","#",self._app._enumthemes._muted,"");
// [36]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [37]  Page.Content.AddRaisedButton(1,1, {40} , {41} , {42} , {43} ,App.EnumThemes.success, {44} ) 
self._page._content.addraisedbutton(1,1,"btnStart","Start Pulse","","#",self._app._enumthemes._success,"");
// [38]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [39]  Page.Content.AddRaisedButton(1,1, {45} , {46} , {47} , {48} ,App.EnumThemes.warn, {49} ) 
self._page._content.addraisedbutton(1,1,"btnEnable","Disabled","","#",self._app._enumthemes._warn,"");
// [40]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [41]  Page.Content.AddRaisedButton(1,1, {50} , {51} , {52} , {53} ,App.EnumThemes.warn, {54} ) 
self._page._content.addraisedbutton(1,1,"openFAB","Open FAB","","#",self._app._enumthemes._warn,"");
// [42]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [43]  Page.Content.AddRaisedButton(1,1, {55} , {56} , {57} , {58} , {59} , {60} ) 
self._page._content.addraisedbutton(1,1,"closeFAB","Close FAB","","#","","");
// [44]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [48]  Page.AddTooltip1( {61} , {62} ) 
self._page.addtooltip1("fabbtn","Hover me...");
// [49]  fab.Initialize(App, {63} , {64} , {65} ,App.EnumButtonSize.large, App.EnumVisibility.visible, {66} ) 
self._fab.initialize(self._app,"fabbtn","#","mdi-add",self._app._enumbuttonsize._large,self._app._enumvisibility._visible,"white.red");
// [50]  fab.zdepth = App.enumzdepth.ZDepth_2 
self._fab._zdepth = self._app._enumzdepth._zdepth_2;
// [51]  fab.Direction = App.EnumFABDirection.left 
self._fab._direction = self._app._enumfabdirection._left;
// [52]  Page.AddTooltip1( {67} , {68} ) 
self._page.addtooltip1("insert_chart","Insert chart...");
// [53]  Page.AddTooltip1( {69} , {70} ) 
self._page.addtooltip1("format_quote","Format quote...");
// [54]  Page.AddTooltip1( {71} , {72} ) 
self._page.addtooltip1("publish","Publish...");
// [55]  Page.AddTooltip1( {73} , {74} ) 
self._page.addtooltip1("attach_file","Attach file...");
// [57]  fab.AddButton( {75} , {76} , {77} , {78} ) 
self._fab.addbutton("insert_chart","mdi-insert_chart","#","white.red");
// [58]  fab.AddButton( {79} , {80} , {81} , {82} ) 
self._fab.addbutton("format_quote","mdi-format_quote","#","white.green");
// [59]  fab.AddButton( {83} , {84} , {85} , {86} ) 
self._fab.addbutton("publish","mdi-publish","#","white.yellow");
// [60]  fab.AddButton( {87} , {88} , {89} , {90} ) 
self._fab.addbutton("attach_file","mdi-attach_file","#","white.blue");
// [61]  Page.Content.AddFAB(fab) 
self._page._content.addfab(self._fab);
// [64]  Page.Create( {91} , Me) 
self._page.create("buttonEvents",self);
// [66]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// [70]  Page.Enable( {92} ,False) 
self._page.enable("btnEnable",false);
// [72]  Page.Pulse( {93} ,True) 
self._page.pulse("btnfloating",true);
// End Sub
};

// [76] Sub buttonEvents(Event As BANanoEvent) 
this.buttonevents= function(_event) {
if (self==null) self=this;
var _str;
var _script;
// [77]  modBANano.tocButtons(Event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [78]  Log(Event.ID) 
console.log(_event.target.id);
// [79]  Select Event.ID 
switch ("" + _event.target.id) {
// [80]  Case {94} 
case "" + "btn1":
// [81]  Dim str As String = Event.id 
_str=_event.target.id;
// [82]  Dim script As String = Page.ShowSuccess(str) 
_script=self._page.showsuccess(_str);
// [83]  BANano.Eval(script) 
eval(_script);
// [84]  Case {95} 
break;
case "" + "btn":
// [85]  Dim script As String = Page.ShowSuccess( {96} ) 
_script=self._page.showsuccess("A has been clicked!");
// [86]  BANano.Eval(script) 
eval(_script);
// [87]  Case {97} 
break;
case "" + "openfab":
// [88]  fab.Open 
self._fab.open();
// [89]  Case {98} 
break;
case "" + "closefab":
// [90]  fab.close 
self._fab.close();
// [91]  Case {99} 
break;
case "" + "btnraised":
// [92]  Dim script As String = Page.ShowError( {100} ) 
_script=self._page.showerror("A button has been clicked!");
// [93]  BANano.Eval(script) 
eval(_script);
// [94]  Case {101} 
break;
case "" + "insert_chart":
// [95]  Case {102} 
break;
case "" + "format_quote":
// [96]  Case {103} 
break;
case "" + "publish":
// [97]  Case {104} 
break;
case "" + "attach_file":
// [98]  Case {105} 
break;
case "" + "btnstop":
// [100]  Page.Pulse( {106} , False) 
self._page.pulse("btnfloating",false);
// [101]  Case {107} 
break;
case "" + "btnstart":
// [102]  Page.Pulse( {108} ,True) 
self._page.pulse("btnfloating",true);
// [103]  Case {109} 
break;
case "" + "btnfloating":
// [104]  Page.Enable( {110} ,True) 
self._page.enable("btnEnable",true);
// [105]  End Select 
break;
}
// End Sub
};

}
// =========================== pgPagination  ===========================
function banano_uoebananodemo_pgpagination() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _tbl;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Pagination",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim tbl As UOEPagination 
_tbl= new banano_uoebanano_uoepagination();
// [22]  tbl.Initialize(App, {10} ,10, {11} , {12} ) 
_tbl.initialize(self._app,"pgn",10,"black.transparent","");
// [24]  tbl.ShowArrows = True 
_tbl._showarrows = true;
// [26]  tbl.AddClass( {13} ) 
_tbl.addclass("center");
// [28]  tbl.AddLink( {14} ) 
_tbl.addlink("UOEapp.html");
// [29]  tbl.AddLink( {15} ) 
_tbl.addlink("UOEpage.html");
// [30]  tbl.AddLink( {16} ) 
_tbl.addlink("UOEcontainer.html");
// [31]  tbl.AddLink( {17} ) 
_tbl.addlink("UOEbadge.html");
// [32]  tbl.AddLink( {18} ) 
_tbl.addlink("UOEbreadcrumbs.html");
// [33]  tbl.AddLink( {19} ) 
_tbl.addlink("UOEbutton.html");
// [34]  tbl.AddLink( {20} ) 
_tbl.addlink("UOEcard.html");
// [35]  tbl.AddLink( {21} ) 
_tbl.addlink("UOEcarousel.html");
// [36]  tbl.AddLink( {22} ) 
_tbl.addlink("UOEcheckbox.html");
// [37]  Page.Content.AddPagination(1,1,tbl) 
self._page._content.addpagination(1,1,_tbl);
// [39]  Page.Create( {23} , Me) 
self._page.create("navEvents",self);
// [41]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [44] Sub navEvents(event As BANanoEvent) 
this.navevents= function(_event) {
if (self==null) self=this;
// [45]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [46]  Select Case App.MvField(event.ID,1, {24} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [47]  End Select 
}
// End Sub
};

}
// =========================== pgModal  ===========================
function banano_uoebananodemo_pgmodal() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

this._modalp= new banano_uoebanano_uoemodal();

this._modalp1= new banano_uoebanano_uoemodal();

this._modalp2= new banano_uoebanano_uoemodal();

// [13] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
// [14]  App = thisApp 
self._app = _thisapp;
// [15]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Modal",self._app._enumlogoposition._center,true,true,"","");
// [16]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [18]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [20]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [23]  modalP.Initialize(App, {10} , {11} ) 
self._modalp.initialize(self._app,"modalp","");
// [24]  modalP.Header.AddRows(1, {12} , {13} ).AddColumns12(1, {14} , {15} ) 
self._modalp._header.addrows(1,"","").addcolumns12(1,"","");
// [25]  modalP.Content.AddRows(2, {16} , {17} ).AddColumns12(1, {18} , {19} ) 
self._modalp._content.addrows(2,"","").addcolumns12(1,"","");
// [26]  modalP.Footer.AddRows(1, {20} , {21} ).AddColumns12(1, {22} , {23} ) 
self._modalp._footer.addrows(1,"","").addcolumns12(1,"","");
// [27]  modalP.Header.AddH4(1,1, {24} , {25} , {26} , {27} ) 
self._modalp._header.addh4(1,1,"h4","Heading 4","black.transparent","center-align");
// [28]  modalP.Content.AddParagraph(1,1, {28} , {29} , {30} , {31} ) 
self._modalp._content.addparagraph(1,1,"lbl","This is a label of the modal","","");
// [29]  modalP.Footer.AddRaisedButton(1,1, {32} , {33} , {34} , {35} , {36} , {37} ) 
self._modalp._footer.addraisedbutton(1,1,"btnAgree","Agree","","","","");
// [30]  modalP.Footer.AddRaisedButton(1,1, {38} , {39} , {40} , {41} , {42} , {43} ) 
self._modalp._footer.addraisedbutton(1,1,"btnCancel","Cancel","","","","");
// [31]  Page.Content.AddModal(modalP) 
self._page._content.addmodal(self._modalp);
// [32]  Page.Content.AddRaisedButton(1,1, {44} , {45} , {46} , {47} , {48} , {49} ) 
self._page._content.addraisedbutton(1,1,"btnOpen","Open Modal","","","","");
// [33]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [35]  modalP1.Initialize(App, {50} , {51} ) 
self._modalp1.initialize(self._app,"modalp1","");
// [36]  modalP1.fixedFooter = True 
self._modalp1._fixedfooter = true;
// [37]  modalP1.Content.AddRows(2, {52} , {53} ).AddColumns12(1, {54} , {55} ) 
self._modalp1._content.addrows(2,"","").addcolumns12(1,"","");
// [38]  modalP1.Footer.AddRows(1, {56} , {57} ).AddColumns12(1, {58} , {59} ) 
self._modalp1._footer.addrows(1,"","").addcolumns12(1,"","");
// [39]  modalP1.Content.AddH4(1,1, {60} , {61} , {62} , {63} ) 
self._modalp1._content.addh4(1,1,"head1","Heading","","");
// [40]  modalP1.Content.AddParagraph(2,1, {64} , {65} , {66} , {67} ) 
self._modalp1._content.addparagraph(2,1,"lbl1","This is a label of the modal","","");
// [41]  modalP1.Footer.AddRaisedButton(1,1, {68} , {69} , {70} , {71} , {72} , {73} ) 
self._modalp1._footer.addraisedbutton(1,1,"btnAgree1","Agree","","","","");
// [42]  modalP1.Footer.AddRaisedButton(1,1, {74} , {75} , {76} , {77} , {78} , {79} ) 
self._modalp1._footer.addraisedbutton(1,1,"btnCancel1","Cancel","","","","");
// [43]  Page.Content.AddModal(modalP1) 
self._page._content.addmodal(self._modalp1);
// [44]  Page.Content.AddRaisedButton(1,1, {80} , {81} , {82} , {83} , {84} , {85} ) 
self._page._content.addraisedbutton(1,1,"btnOpen1","Open Modal (Fixed Footer)","","","","");
// [45]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [47]  modalP2.Initialize(App, {86} , {87} ) 
self._modalp2.initialize(self._app,"modalp2","");
// [48]  modalP2.IsBottomSheet = True 
self._modalp2._isbottomsheet = true;
// [49]  modalP2.Header.AddRows(1, {88} , {89} ).AddColumns12(1, {90} , {91} ) 
self._modalp2._header.addrows(1,"","").addcolumns12(1,"","");
// [50]  modalP2.Content.AddRows(2, {92} , {93} ).AddColumns12(1, {94} , {95} ) 
self._modalp2._content.addrows(2,"","").addcolumns12(1,"","");
// [51]  modalP2.Footer.AddRows(1, {96} , {97} ).AddColumns12(1, {98} , {99} ) 
self._modalp2._footer.addrows(1,"","").addcolumns12(1,"","");
// [52]  modalP2.Header.AddH4(1,1, {100} , {101} , {102} , {103} ) 
self._modalp2._header.addh4(1,1,"h4","Heading 4","black.transparent","right-align");
// [53]  modalP2.Content.AddParagraph(1,1, {104} , {105} , {106} , {107} ) 
self._modalp2._content.addparagraph(1,1,"lbl","This is a label of the modal","","");
// [54]  modalP2.Footer.AddRaisedButton(1,1, {108} , {109} , {110} , {111} , {112} , {113} ) 
self._modalp2._footer.addraisedbutton(1,1,"btnAgree2","Agree","","","","");
// [55]  modalP2.Footer.AddRaisedButton(1,1, {114} , {115} , {116} , {117} , {118} , {119} ) 
self._modalp2._footer.addraisedbutton(1,1,"btnCancel2","Cancel","","","","");
// [56]  Page.Content.AddModal(modalP2) 
self._page._content.addmodal(self._modalp2);
// [57]  Page.Content.AddRaisedButton(1,1, {120} , {121} , {122} , {123} , {124} , {125} ) 
self._page._content.addraisedbutton(1,1,"btnOpen2","Open Modal (Bottom Sheet)","","","","");
// [58]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [60]  Page.Create( {126} , Me) 
self._page.create("modalEvents",self);
// [62]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [65] Sub modalEvents(event As BANanoEvent) 
this.modalevents= function(_event) {
if (self==null) self=this;
// [66]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [67]  Select Case App.MvField(event.ID,1, {127} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [68]  Case {128} 
case "" + "btnagree":
// [69]  modalP.close 
self._modalp.close();
// [70]  Case {129} 
break;
case "" + "btncancel":
// [71]  modalP.close 
self._modalp.close();
// [72]  Case {130} 
break;
case "" + "btnopen":
// [73]  modalP.open 
self._modalp.open();
// [74]  Case {131} 
break;
case "" + "btnagree1":
// [75]  modalP1.open 
self._modalp1.open();
// [76]  Case {132} 
break;
case "" + "btncancel1":
// [77]  modalP1.close 
self._modalp1.close();
// [78]  Case {133} 
break;
case "" + "btnopen1":
// [79]  modalP1.open 
self._modalp1.open();
// [80]  Case {134} 
break;
case "" + "btnagree2":
// [81]  modalP2.close 
self._modalp2.close();
// [82]  Case {135} 
break;
case "" + "btncancel2":
// [83]  modalP2.close 
self._modalp2.close();
// [84]  Case {136} 
break;
case "" + "btnopen2":
// [85]  modalP2.open 
self._modalp2.open();
// [86]  End Select 
break;
}
// End Sub
};

}
// =========================== pgCollections  ===========================
function banano_uoebananodemo_pgcollections() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _mlv;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Collections",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  Page.Content.AddBreak(1,1) 
self._page._content.addbreak(1,1);
// [20]  Dim mlv As UOEListView 
_mlv= new banano_uoebanano_uoelistview();
// [21]  mlv.Initialize(App, {10} , {11} ) 
_mlv.initialize(self._app,"mlv","");
// [22]  mlv.AddItem( {12} , {13} , {14} , {15} ,True, {16} , {17} , {18} ) 
_mlv.additem("pgn","mdi-add","Pagination","2",true,"#","","");
// [23]  mlv.AddItem( {19} , {20} , {21} , {22} ,False, {23} , {24} , {25} ) 
_mlv.additem("tbl","mdi-cloud","Table","",false,"#","","");
// [24]  mlv.AddItem( {26} , {27} , {28} , {29} ,False, {30} , {31} , {32} ) 
_mlv.additem("lnk10","mdi-place","Cards","",false,"#","blue","");
// [25]  Page.content.AddListView(1,1,mlv) 
self._page._content.addlistview(1,1,_mlv);
// [27]  Page.Create( {33} , Me) 
self._page.create("collectionEvents",self);
// [29]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [32] Sub collectionEvents(event As BANanoEvent) 
this.collectionevents= function(_event) {
if (self==null) self=this;
// [33]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [34]  Select Case App.MvField(event.ID,1, {34} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [35]  End Select 
}
// End Sub
};

}
// =========================== pgCopyRights  ===========================
function banano_uoebananodemo_pgcopyrights() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Footer & Copyrights",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(6, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(6,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [16]  Page.Create( {10} , Me) 
self._page.create("crEvents",self);
// [18]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [21] Sub crEvents(event As BANanoEvent) 
this.crevents= function(_event) {
if (self==null) self=this;
// [22]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [23]  Select Case App.MvField(event.ID,1, {11} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [24]  End Select 
}
// End Sub
};

}
// =========================== pgGrid  ===========================
function banano_uoebananodemo_pggrid() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._page= new banano_uoebanano_uoepage();

// [10] Sub Init(thisApp As UOEApp) 
this.init= function(_thisapp) {
if (self==null) self=this;
var _lblcolor;
var _grid1;
// [11]  App = thisApp 
self._app = _thisapp;
// [12]  Page.Initialize(App, {0} ,False, {1} ,App.EnumLogoPosition.Center,True,True, {2} , {3} ) 
self._page.initialize(self._app,"cpy",false,"Grid",self._app._enumlogoposition._center,true,true,"","");
// [13]  modBANano.AddSideBar(Page) 
_banano_uoebananodemo_modbanano.addsidebar(self._page);
// [15]  Page.Content.AddRows(5, {4} , {5} ).AddColumnsOSMP(1,0,0,0,10,10,10,0,0,20,20, {6} , {7} ).AddColumnsOSMP(1,0,0,0,2,2,2,0,0,0,0, {8} , {9} ) 
self._page._content.addrows(5,"","").addcolumnsosmp(1,0,0,0,10,10,10,0,0,20,20,"","").addcolumnsosmp(1,0,0,0,2,2,2,0,0,0,0,"","");
// [17]  App.AddTheme( {10} , {11} , {12} , {13} , {14} ) 
self._app.addtheme("yellow.transparent","yellow","","transparent","");
// [18]  Dim lblColor As UOELabel 
_lblcolor= new banano_uoebanano_uoelabel();
// [19]  lblColor.Initialize(App, {15} ,App.EnumLabelSize.paragraph, {16} , {17} , {18} ) 
_lblcolor.initialize(self._app,"aColor",self._app._enumlabelsize._paragraph,"Anele Mashy Mbanga is creating{NBSP}","","");
// [20]  lblColor.AddColor( {19} ,App.EnumColor.YELLOW) 
_lblcolor.addcolor("{B}BANano{/B}",self._app._enumcolor._yellow);
// [21]  lblColor.AddColor( {20} ,App.EnumColor.BLUEGREY) 
_lblcolor.addcolor("{B}Material{/B}",self._app._enumcolor._bluegrey);
// [22]  Page.Content.AddLabel(1,1,lblColor) 
self._page._content.addlabel(1,1,_lblcolor);
// [25]  Dim grid1 As UOEContainer 
_grid1= new banano_uoebanano_uoecontainer();
// [26]  grid1.Initialize(App, {21} ,False, {22} ) 
_grid1.initialize(self._app,"grid1",false,"white.lightblue");
// [27]  grid1.AddRows(1, {23} , {24} ).AddColumns12(1, {25} , {26} ) 'r1 
_grid1.addrows(1,"","").addcolumns12(1,"","");
// [28]  grid1.AddRows(1, {27} , {28} ).AddColumnsOS(2,0,0,0,6,6,6, {29} , {30} ) 'r2 
_grid1.addrows(1,"","").addcolumnsos(2,0,0,0,6,6,6,"","");
// [29]  grid1.AddRows(1, {31} , {32} ).AddColumnsOS(3,0,0,0,4,4,4, {33} , {34} ) 'r3 
_grid1.addrows(1,"","").addcolumnsos(3,0,0,0,4,4,4,"","");
// [30]  grid1.AddRows(1, {35} , {36} ).AddColumnsOS(4,0,0,0,3,3,3, {37} , {38} ) 'r4 
_grid1.addrows(1,"","").addcolumnsos(4,0,0,0,3,3,3,"","");
// [31]  grid1.AddRows(1, {39} , {40} ).AddColumnsOS(1,0,0,0,1,1,1, {41} , {42} ).AddColumnsOS(1,0,0,0,11,11,11, {43} , {44} ) 'r5 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,1,1,1,"","").addcolumnsos(1,0,0,0,11,11,11,"","");
// [32]  grid1.AddRows(1, {45} , {46} ).AddColumnsOS(1,0,0,0,2,2,2, {47} , {48} ).AddColumnsOS(1,0,0,0,10,10,10, {49} , {50} ) 'r6 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,2,2,2,"","").addcolumnsos(1,0,0,0,10,10,10,"","");
// [33]  grid1.AddRows(1, {51} , {52} ).AddColumnsOS(1,0,0,0,3,3,3, {53} , {54} ).AddColumnsOS(1,0,0,0,9,9,9, {55} , {56} ) 'r7 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,3,3,3,"","").addcolumnsos(1,0,0,0,9,9,9,"","");
// [34]  grid1.AddRows(1, {57} , {58} ).AddColumnsOS(1,0,0,0,4,4,4, {59} , {60} ).AddColumnsOS(1,0,0,0,8,8,8, {61} , {62} ) 'r8 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,4,4,4,"","").addcolumnsos(1,0,0,0,8,8,8,"","");
// [35]  grid1.AddRows(1, {63} , {64} ).AddColumnsOS(1,0,0,0,5,5,5, {65} , {66} ).AddColumnsOS(1,0,0,0,7,7,7, {67} , {68} ) 'r9 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,5,5,5,"","").addcolumnsos(1,0,0,0,7,7,7,"","");
// [36]  grid1.AddRows(1, {69} , {70} ).AddColumnsOS(1,0,0,0,7,7,7, {71} , {72} ).AddColumnsOS(1,0,0,0,5,5,5, {73} , {74} ) 'r10 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,7,7,7,"","").addcolumnsos(1,0,0,0,5,5,5,"","");
// [37]  grid1.AddRows(1, {75} , {76} ).AddColumnsOS(1,0,0,0,8,8,8, {77} , {78} ).AddColumnsOS(1,0,0,0,4,4,4, {79} , {80} ) 'r10 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,8,8,8,"","").addcolumnsos(1,0,0,0,4,4,4,"","");
// [38]  grid1.AddRows(1, {81} , {82} ).AddColumnsOS(1,0,0,0,9,9,9, {83} , {84} ).AddColumnsOS(1,0,0,0,3,3,3, {85} , {86} ) 'r10 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,9,9,9,"","").addcolumnsos(1,0,0,0,3,3,3,"","");
// [39]  grid1.AddRows(1, {87} , {88} ).AddColumnsOS(1,0,0,0,10,10,10, {89} , {90} ).AddColumnsOS(1,0,0,0,2,2,2, {91} , {92} ) 'r10 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,10,10,10,"","").addcolumnsos(1,0,0,0,2,2,2,"","");
// [40]  grid1.AddRows(1, {93} , {94} ).AddColumnsOS(1,0,0,0,11,11,11, {95} , {96} ).AddColumnsOS(1,0,0,0,1,1,1, {97} , {98} ) 'r10 
_grid1.addrows(1,"","").addcolumnsos(1,0,0,0,11,11,11,"","").addcolumnsos(1,0,0,0,1,1,1,"","");
// [41]  grid1.AddRows(1, {99} , {100} ).AddColumnsOS(12,0,0,0,1,1,1, {101} , {102} ) 
_grid1.addrows(1,"","").addcolumnsos(12,0,0,0,1,1,1,"","");
// [44]  grid1.AddParagraph(1,1, {103} , {104} , {105} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(1,1,"","R1C1 = 12","",self._app._enumtextalignment._center);
// [46]  grid1.AddParagraph(2,1, {106} , {107} , {108} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(2,1,"","R2C1 = 6","",self._app._enumtextalignment._center);
// [47]  grid1.AddParagraph(2,2, {109} , {110} , {111} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(2,2,"","R2C2 = 6","",self._app._enumtextalignment._center);
// [49]  grid1.AddParagraph(3,1, {112} , {113} , {114} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(3,1,"","R3C1 = 4","",self._app._enumtextalignment._center);
// [50]  grid1.AddParagraph(3,2, {115} , {116} , {117} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(3,2,"","R3C2 = 4","",self._app._enumtextalignment._center);
// [51]  grid1.AddParagraph(3,3, {118} , {119} , {120} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(3,3,"","R3C3 = 4","",self._app._enumtextalignment._center);
// [53]  grid1.AddParagraph(4,1, {121} , {122} , {123} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(4,1,"","R4C1 = 3","",self._app._enumtextalignment._center);
// [54]  grid1.AddParagraph(4,2, {124} , {125} , {126} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(4,2,"","R4C2 = 3","",self._app._enumtextalignment._center);
// [55]  grid1.AddParagraph(4,3, {127} , {128} , {129} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(4,3,"","R4C3 = 3","",self._app._enumtextalignment._center);
// [56]  grid1.AddParagraph(4,4, {130} , {131} , {132} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(4,4,"","R4C4 = 3","",self._app._enumtextalignment._center);
// [58]  grid1.AddParagraph(5,1, {133} , {134} , {135} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(5,1,"","R5C1 = 1","",self._app._enumtextalignment._center);
// [59]  grid1.AddParagraph(5,2, {136} , {137} , {138} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(5,2,"","R5C2 = 11","",self._app._enumtextalignment._center);
// [61]  grid1.AddParagraph(6,1, {139} , {140} , {141} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(6,1,"","R6C1 = 2","",self._app._enumtextalignment._center);
// [62]  grid1.AddParagraph(6,2, {142} , {143} , {144} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(6,2,"","R6C2 = 10","",self._app._enumtextalignment._center);
// [64]  grid1.AddParagraph(7,1, {145} , {146} , {147} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(7,1,"","R7C1 = 3","",self._app._enumtextalignment._center);
// [65]  grid1.AddParagraph(7,2, {148} , {149} , {150} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(7,2,"","R7C2 = 9","",self._app._enumtextalignment._center);
// [67]  grid1.AddParagraph(8,1, {151} , {152} , {153} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(8,1,"","R8C1 = 4","",self._app._enumtextalignment._center);
// [68]  grid1.AddParagraph(8,2, {154} , {155} , {156} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(8,2,"","R8C2 = 8","",self._app._enumtextalignment._center);
// [70]  grid1.AddParagraph(9,1, {157} , {158} , {159} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(9,1,"","R9C1 = 5","",self._app._enumtextalignment._center);
// [71]  grid1.AddParagraph(9,2, {160} , {161} , {162} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(9,2,"","R9C2 = 9","",self._app._enumtextalignment._center);
// [73]  grid1.AddParagraph(10,1, {163} , {164} , {165} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(10,1,"","R10C1 = 7","",self._app._enumtextalignment._center);
// [74]  grid1.AddParagraph(10,2, {166} , {167} , {168} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(10,2,"","R10C2 = 5","",self._app._enumtextalignment._center);
// [76]  grid1.AddParagraph(11,1, {169} , {170} , {171} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(11,1,"","R11C1 = 8","",self._app._enumtextalignment._center);
// [77]  grid1.AddParagraph(11,2, {172} , {173} , {174} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(11,2,"","R11C2 = 4","",self._app._enumtextalignment._center);
// [79]  grid1.AddParagraph(12,1, {175} , {176} , {177} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(12,1,"","R12C1 = 9","",self._app._enumtextalignment._center);
// [80]  grid1.AddParagraph(12,2, {178} , {179} , {180} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(12,2,"","R12C2 = 3","",self._app._enumtextalignment._center);
// [82]  grid1.AddParagraph(13,1, {181} , {182} , {183} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(13,1,"","R13C1 = 10","",self._app._enumtextalignment._center);
// [83]  grid1.AddParagraph(13,2, {184} , {185} , {186} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(13,2,"","R13C2 = 2","",self._app._enumtextalignment._center);
// [85]  grid1.AddParagraph(14,1, {187} , {188} , {189} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(14,1,"","R14C1 = 11","",self._app._enumtextalignment._center);
// [86]  grid1.AddParagraph(14,2, {190} , {191} , {192} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(14,2,"","R14C2 = 1","",self._app._enumtextalignment._center);
// [88]  grid1.AddParagraph(15,1, {193} , {194} , {195} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,1,"","R15C1 = 1","",self._app._enumtextalignment._center);
// [89]  grid1.AddParagraph(15,2, {196} , {197} , {198} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,2,"","R15C2 = 1","",self._app._enumtextalignment._center);
// [90]  grid1.AddParagraph(15,3, {199} , {200} , {201} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,3,"","R15C3 = 1","",self._app._enumtextalignment._center);
// [91]  grid1.AddParagraph(15,4, {202} , {203} , {204} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,4,"","R15C4 = 1","",self._app._enumtextalignment._center);
// [92]  grid1.AddParagraph(15,5, {205} , {206} , {207} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,5,"","R15C5 = 1","",self._app._enumtextalignment._center);
// [93]  grid1.AddParagraph(15,6, {208} , {209} , {210} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,6,"","R15C6 = 1","",self._app._enumtextalignment._center);
// [94]  grid1.AddParagraph(15,7, {211} , {212} , {213} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,7,"","R15C7 = 1","",self._app._enumtextalignment._center);
// [95]  grid1.AddParagraph(15,8, {214} , {215} , {216} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,8,"","R15C8 = 1","",self._app._enumtextalignment._center);
// [96]  grid1.AddParagraph(15,9, {217} , {218} , {219} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,9,"","R15C9 = 1","",self._app._enumtextalignment._center);
// [97]  grid1.AddParagraph(15,10, {220} , {221} , {222} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,10,"","R15C10 = 1","",self._app._enumtextalignment._center);
// [98]  grid1.AddParagraph(15,11, {223} , {224} , {225} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,11,"","R15C11 = 1","",self._app._enumtextalignment._center);
// [99]  grid1.AddParagraph(15,12, {226} , {227} , {228} ,App.EnumTextAlignment.center) 
_grid1.addparagraph(15,12,"","R15C12 = 1","",self._app._enumtextalignment._center);
// [101]  Page.Content.AddContainer(1,1,grid1) 
self._page._content.addcontainer(1,1,_grid1);
// [104]  Page.Create( {229} , Me) 
self._page.create("gridEvents",self);
// [106]  modBANano.AddTOC(App,Page.ID) 
_banano_uoebananodemo_modbanano.addtoc(self._app,self._page._id);
// End Sub
};

// [109] Sub gridEvents(event As BANanoEvent) 
this.gridevents= function(_event) {
if (self==null) self=this;
// [110]  modBANano.tocButtons(event) 
_banano_uoebananodemo_modbanano.tocbuttons(_event);
// [111]  Log(event.ID) 
console.log(_event.target.id);
// [112]  Select Case App.MvField(event.ID,1, {230} ) 
switch ("" + self._app.mvfield(_event.target.id,1,"-")) {
// [114]  End Select 
}
// End Sub
};

}
// =========================== UOEBANanoDemo  ===========================
function banano_uoebananodemo() {
var self;
this._app= new banano_uoebanano_uoeapp();

this._appname="UOEBANanoDemo";

// [47] Sub UOEBANanoDemo_Ready() 
this.uoebananodemo_ready= function() {
if (self==null) self=this;
// [48]  App.Initialize(AppName, {7} ) 
self._app.initialize(self._appname,"white.black");
// [49]  App.Copyrights = {1} 
self._app._copyrights = "2019 " + self._appname + ", All Rights Reserved, powered by BANano";
// [50]  App.TermsAndConditionsURL = {8} 
self._app._termsandconditionsurl = "";
// [51]  App.DisclaimerURL = {9} 
self._app._disclaimerurl = "";
// [52]  App.PrivacyPolicyURL = {10} 
self._app._privacypolicyurl = "";
// [54]  pgGrid.Init(App) 
_banano_uoebananodemo_pggrid.init(self._app);
// End Sub
};

}
_banano_uoebananodemo.uoebananodemo_ready();
