<?php
header("Content-type: text/plain");
set_time_limit(0);
if (isset($_REQUEST['action'])){$action=trim($_REQUEST['action']);} else {$action="";}
if (isset($_REQUEST['filepath'])){$filepath=trim($_REQUEST['filepath']);} else {$filepath="";}

switch ($action)
{
	case "upload":
		$filepath = $filepath . basename( $_FILES['processfile']['name']);
		if(move_uploaded_file($_FILES['processfile']['tmp_name'], $filepath)) {
        		echo "success";
    		} else{
        		echo "fail";
    		}
}
?>